using System;
using System.Globalization;
using System.Windows.Data;

public class _ycZJcMr8qPM0V24AWABVNIMQC4R : IValueConverter
{
	public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	object IValueConverter.Convert(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Convert
		return this.Convert(value, targetType, parameter, culture);
	}

	public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x6F97196B
	}

	object IValueConverter.ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//ILSpy generated this explicit interface implementation from .override directive in ConvertBack
		return this.ConvertBack(value, targetType, parameter, culture);
	}

	public _ycZJcMr8qPM0V24AWABVNIMQC4R()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static Type _206E_200E_206E_200D_200C_206D_202A_202B_206F_200D_206D_206A_200E_206F_206B_202E_202C_200E_206C_202B_200F_202A_202D_202A_206D_200B_202B_206E_206C_200E_200D_202A_206D_202A_202C_202D_200C_200E_206E_202E_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xFB*/;
	}

	static bool _206A_206D_202B_206B_202B_206A_206F_206B_200D_206C_202A_202D_200E_202C_200D_206B_200C_200B_200F_200F_200E_206F_202C_206A_206A_200D_206E_200B_206E_202A_200F_200F_206C_206E_206B_206C_200F_200C_200F_202C_202E(Type P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x91
	}

	static object _202E_206A_200C_206E_200E_206B_200D_206D_200E_202D_200D_202E_202E_206E_200D_206D_202E_206F_206E_200D_206D_200B_206A_200C_206C_202E_202A_202A_206F_202E_206F_206E_202D_200B_206C_202A_200E_206C_202D_200E_202E(Type P_0, string P_1)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static bool _200C_202E_206A_206E_200B_200E_202D_206D_202A_200C_200D_200D_200F_200B_202B_202B_206A_206B_200E_202E_206E_200F_200F_202E_206C_202D_202E_200E_206C_202C_202A_206D_200B_200B_206B_200D_206B_200B_202C_202A_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}
}
