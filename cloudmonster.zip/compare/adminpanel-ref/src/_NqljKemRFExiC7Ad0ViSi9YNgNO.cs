using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;

public class _NqljKemRFExiC7Ad0ViSi9YNgNO : Application
{
	private bool _yDt87OiBbvp48poyGpJneAvGUST;

	[MethodImpl(MethodImplOptions.NoInlining)]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.10.0")]
	public void _CGs0W6pR9GqgQoWONJZO8zvykZA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x15
	}

	[STAThread]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.10.0")]
	public static void _IO5ddxbcS51nJzjaSkR8Yinbatm()
	{
		/*Error near IL_0001: Invalid metadata token*/;
	}

	public _NqljKemRFExiC7Ad0ViSi9YNgNO()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x73 0x7D
	}

	static Uri _200C_200B_202B_206C_202D_200F_202B_200E_202A_206E_200B_200E_200C_206F_200B_202E_206E_200C_202B_202C_202C_206F_202E_206B_200D_206D_206E_200C_200D_200F_202A_200D_202E_202E_206C_206E_202C_200B_200D_206A_202E(string P_0, UriKind P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static void _206E_202D_206F_200C_206A_206F_206F_206F_206F_200D_202E_202C_200D_202B_200B_206B_206C_202C_200E_202E_202D_206B_202E_202E_202A_206B_200C_206A_206B_206A_202A_200E_202B_200D_206F_202A_202D_206A_202C_200D_202E(Application P_0, Uri P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD3 0x00
	}

	static void _200E_202B_200D_202D_202A_202A_200B_200B_200C_206A_206F_206C_202D_206D_200E_200C_206F_202C_200E_202B_206A_206C_202E_206B_200B_206E_200C_206E_200F_206C_200E_206E_200E_202B_206D_200E_206F_200B_200B_200D_202E(object P_0, Uri P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1D
	}

	static int _206D_200D_200F_206F_200E_202E_206E_206A_200D_202E_202D_206D_202C_206D_202D_202B_206F_206A_200D_200B_206C_200F_200F_202A_206F_202E_202D_206A_202D_200D_200D_200D_202D_200E_202C_206F_206C_206B_206E_206D_202E(Application P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}
}
