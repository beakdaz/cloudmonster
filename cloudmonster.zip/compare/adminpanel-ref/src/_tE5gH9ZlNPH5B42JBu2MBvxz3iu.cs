using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using xNet;

public class _tE5gH9ZlNPH5B42JBu2MBvxz3iu : Exception
{
	[CompilerGenerated]
	private readonly string _lwrm9kUAivLpE7QixfhllaT3QLb;

	public string _gVr57enwDRD12imcDviDQtdTOzq
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0x77
		}
	}

	public _tE5gH9ZlNPH5B42JBu2MBvxz3iu(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8F 0x05
	}

	public _tE5gH9ZlNPH5B42JBu2MBvxz3iu(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFF 0xA3
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _tE5gH9ZlNPH5B42JBu2MBvxz3iu(string P_0, HttpResponse P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFC
	}

	public virtual string _JcA5cTOIzYiIo3H3fG6PU4hBVnt()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9B 0x4C
	}

	static StringBuilder _202B_206B_202E_200B_200E_200F_202D_202B_206F_206A_200C_200F_202C_206E_206C_206C_206D_206B_200D_206E_206A_200B_206E_200E_200F_206B_206E_206C_206C_202B_206E_206F_200E_206A_202B_202A_202A_202A_202C_200E_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF1
	}

	static StringBuilder _200D_200E_202A_202B_206A_200B_206C_206D_202C_200C_202B_206B_200D_206A_206A_206B_200C_206E_202C_202C_202E_200C_200C_200D_206E_206B_200E_206F_206A_206D_206C_206D_200C_200F_206C_202D_206E_202E_202A_202E_202E(StringBuilder P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static string _202C_200C_202C_200D_206C_202B_206D_200C_206D_206E_206E_200E_206E_200F_202D_202D_200B_200E_206B_206E_202D_202A_202A_202B_200D_206C_200E_202D_206F_202E_206A_202E_206A_202B_206B_206C_206A_200F_200E_206F_202E(char P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9D
	}

	static StringBuilder _200B_202D_200B_200D_206E_202C_200D_202B_202E_206C_206F_200C_206D_200E_202D_200F_202D_202D_202E_200B_206E_206A_200E_202A_206A_206D_206D_202E_206D_200E_206E_202A_202B_202E_200E_200E_202E_200D_202D_206E_202E(StringBuilder P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x55E81196
	}

	unsafe static Uri _206A_200D_206E_200E_206E_200D_206A_202E_200F_206F_202C_206B_206D_202E_206F_200C_202B_202E_202E_206A_206F_202C_206B_206B_206C_202C_200E_202C_200B_206F_202B_202E_206B_202E_202B_200D_202C_200F_200E_200C_202E(HttpResponse P_0)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		checked
		{
			_ = /*Error near IL_0003: Stack underflow*/+ *unchecked((ushort*)(nint)/*Error near IL_0002: Stack underflow*/);
			/*Error near IL_0003: stloc 3 (out-of-bounds)*/;
			/*Error near IL_0004: Unknown opcode: 0xE7*/;
		}
	}

	static string _200D_206E_206A_202B_206A_202B_206B_202E_200C_206F_202B_206C_200D_206D_202A_200F_202E_206B_200D_202A_200F_206B_202A_202B_202E_202C_206D_202A_202B_206A_206E_206B_206F_202B_202D_200B_206B_202B_206F_202C_202E(Uri P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x70
	}

	static HttpStatusCode _200D_202A_206C_206C_200F_200D_206C_206E_202B_206C_202D_202A_206F_202A_206E_206F_202A_206C_200B_200C_200C_206C_206B_206F_206C_206A_206A_206D_202C_202D_202B_200B_200F_200E_206E_206E_200F_200D_206F_200F_202E(HttpResponse P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x38
	}

	static string _200B_202C_206F_200F_202B_206F_206E_202D_200F_200D_206F_206D_200D_202D_206D_206F_202A_200D_206E_202D_200C_202E_206B_200F_202E_200D_200C_202D_206A_206F_200D_200B_206A_200D_206F_206B_200C_202C_200C_206D_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static Dictionary<string, string>.Enumerator _202C_200C_200C_200E_206F_206D_200D_206A_202C_202E_200E_206C_206C_200C_206F_206C_202D_206C_200F_206D_206B_200E_202B_206B_200B_200F_200E_200E_206E_202B_200D_206D_200B_200B_202B_200B_206A_202B_202C_200F_202E(HttpResponse P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0x07
	}

	static CookieCollection _206E_200F_206D_202B_200C_200F_202D_202C_202B_200B_206C_200E_206E_206C_206B_200E_202A_202C_206C_206F_206E_200F_206D_200B_200D_200D_200F_202E_200E_206F_200C_202A_202E_202E_206C_200E_206F_200B_200D_202E_202E(HttpResponse P_0)
	{
		_ = ((object[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
		/*Error near IL_0001: Invalid metadata token*/;
	}

	static IEnumerator _206C_206D_206A_206A_206B_202B_202B_206D_200F_206C_202B_206C_200E_206E_206C_206F_206F_202A_206F_200D_206E_202B_202C_202A_202C_200F_202C_206E_202E_202E_200F_200B_202A_200D_200E_200D_206B_202E_206A_202A_202E(CookieCollection P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF1
	}

	static object _200E_202C_206A_206D_206F_206E_206A_200D_206B_200F_206B_202A_200B_200C_206A_200C_206D_202D_206C_202E_206E_202B_202D_200F_202B_206C_206D_206D_206C_206A_200B_202B_200F_200C_206F_200B_200F_202D_202D_206E_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4C
	}

	static string _200B_200B_206E_206A_200E_200D_206E_202E_202C_200F_206D_200B_202B_202D_202E_206C_206B_206C_206E_202A_202C_206C_200C_202D_200F_206B_206C_200B_200C_202A_200E_206E_206E_202D_202C_200C_206C_200D_200E_206C_202E(Cookie P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	static string _202B_202D_202B_206D_206C_202D_200C_206B_206D_202A_206B_206B_202E_202A_202B_206F_202A_200C_200E_200D_202D_202C_200F_202D_202C_202C_206C_206F_202A_202B_206B_206D_200C_206C_202D_202B_202C_200C_200E_200D_202E(Cookie P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF7 0x46
	}

	static bool _206A_206C_200B_206C_206B_200B_200F_200D_200C_206D_200C_206A_202C_200F_200C_202A_206D_206C_200E_206E_206B_202B_202C_206A_206D_206E_206A_200D_200F_206B_206F_200D_206B_206B_206E_202D_206C_202B_202A_200C_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x03
	}

	unsafe static void _202E_206E_200D_202A_200F_202C_206B_202C_206D_206C_200E_202E_206C_202E_206B_206B_206F_200F_200D_202B_202B_202E_202A_202C_200F_206B_202D_206A_206F_206A_206A_206B_206E_202D_206A_202B_200E_200F_202B_202B_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}

	static string _200C_206D_200F_200D_206C_206F_202A_202C_200D_200D_206A_202A_200D_200C_200C_206A_206A_206E_202D_206F_200F_202C_200F_202E_200E_200B_206F_206B_202C_206D_206F_202D_200B_200B_206C_206F_202B_200F_202A_206C_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6C
	}

	static bool _206F_202A_200C_200D_202C_200D_202A_206D_206C_200E_206F_200C_202B_202A_200E_202A_200D_206D_206E_200C_202B_206B_202E_200F_206F_200C_206E_202B_200C_202D_202C_200B_200D_200F_200E_200D_206F_206E_206C_202E_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xFC*/;
	}

	static string _206C_202C_200E_200C_202C_202D_200E_206D_206C_202B_202B_206D_202A_202D_202B_206F_200D_200C_206B_206A_200E_206B_200C_206A_202B_200E_202D_200B_202E_200C_200E_200E_206B_200E_206B_200C_200B_202B_206F_206A_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x78
	}

	static string _200F_206E_206C_200B_200F_202E_200E_206E_200C_202D_206C_200E_206B_202D_202C_206B_200F_206D_202D_206A_200F_202D_206D_200F_202E_202E_200E_202B_200C_200D_200F_202E_200B_206B_206C_202C_200E_206A_200C_200E_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}
}
