using System;
using System.Runtime.CompilerServices;

[CompilerGenerated]
[_LSqiEwNalDrxh8dYc4wUW1AXErN]
[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
internal sealed class _CX7aMIwe0k49FlwyALPtEnuWYqP : Attribute
{
	public readonly int _We0bDTh5OF1piEKdm7XfIwcBS3uA;

	public _CX7aMIwe0k49FlwyALPtEnuWYqP(int P_0)
	{
		/*Error: Invalid metadata token*/;
	}
}
