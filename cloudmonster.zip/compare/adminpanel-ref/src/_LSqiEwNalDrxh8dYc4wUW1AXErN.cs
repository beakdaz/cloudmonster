using System;
using System.Runtime.CompilerServices;

[CompilerGenerated]
[_LSqiEwNalDrxh8dYc4wUW1AXErN]
internal sealed class _LSqiEwNalDrxh8dYc4wUW1AXErN : Attribute
{
	public _LSqiEwNalDrxh8dYc4wUW1AXErN()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD9
	}
}
