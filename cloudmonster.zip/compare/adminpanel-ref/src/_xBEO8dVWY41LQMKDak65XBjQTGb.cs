public enum _xBEO8dVWY41LQMKDak65XBjQTGb
{
	Bad,
	Good,
	Unknown,
	Invalid
}
