public interface _l1MK2azd6kuCMX7grms9ifmVfbDA
{
	string _tLkb1vTk9XEGoGf4Sac02vo4V5b { get; }

	int _A5EDNUFdioIPtpCqrcbeARuVV7k { get; set; }

	bool _gHMAm9Wc4g3ZVpouUthFjfB6WMo(string P_0);

	string _JcA5cTOIzYiIo3H3fG6PU4hBVnt();
}
