using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal static class _KQcCd2fgCjFH4UbX9Sjb1rwUJMr
{
	private static object _0RRPE64jVDDcwgSDEb86NovCWWW;

	private static Dictionary<string, bool> _pKC46A48xBVBWD1fFyFvW7LohQK;

	private static Dictionary<string, string> _jIqMzlEcxTpEnj3OMWmqxBadTqN;

	private static Dictionary<string, string> _AGrb40qjhRc0cFGyprpoLqXrGNQ;

	private static int _704LsJAQ5NDVFwltsyJu3WFPpGF;

	private static string _tEMfSbHau1hNyFXmKIQrbXRyD4M(CultureInfo P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC5
	}

	private static Assembly _MZ7kAGgDO4uFmSNsGswZfShDD3d(AssemblyName P_0)
	{
		/*Error: Unknown opcode: 0xF8*/;
	}

	private static void _KiOan7BBEkEAbAYM8Fy0SHjXwtU(Stream P_0, Stream P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF3 0xC4
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static Stream _RfaAEHBqBZSaUlThJXSp1DEGkad(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}

	private static Stream _RfaAEHBqBZSaUlThJXSp1DEGkad(Dictionary<string, string> P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xE7*/;
	}

	private unsafe static byte[] _a16KbnHKGphsMaQzZxfhJxkS8Cg(Stream P_0)
	{
		*(sbyte*)(nint)/*Error near IL_0002: Stack underflow*/ = (sbyte)checked((nint)/*Error near IL_0001: Stack underflow*/);
		((int[])/*Error near IL_0004: Stack underflow*/)[/*Error near IL_0004: Stack underflow*/] = checked((sbyte)/*Error near IL_0003: Stack underflow*/);
		/*Error near IL_0004: Unknown opcode: 0xA8*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static Assembly _Axytr1CguSmaGF4AeILyR8csMjt(Dictionary<string, string> P_0, Dictionary<string, string> P_1, AssemblyName P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x71
	}

	public static Assembly _7nxedc0O5mIBglgYIAUAx0lczSq(object P_0, ResolveEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE0
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	static _KQcCd2fgCjFH4UbX9Sjb1rwUJMr()
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	public static void _lD414PUIJoqjYsGqLT2SQp5dfCN()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static string _200B_200E_202E_206B_200F_202C_206C_206E_206D_202C_206C_200F_206C_202D_200D_200D_202B_206D_206B_200F_200D_200D_200F_206D_200E_202D_200B_202B_200E_206A_200B_206C_206F_200C_206A_206F_202A_202C_202C_200C_202E(CultureInfo P_0)
	{
		_ = null;
		/*Error near IL_0001: Invalid metadata token*/;
	}

	static AppDomain _202C_200B_206D_202B_200D_202A_200C_202B_202A_202B_206F_200C_202E_202D_200F_200D_202C_202E_202C_200D_206F_200C_202D_206D_202C_206B_206B_202C_202E_200C_206F_206D_200C_200E_206E_200C_202D_206D_206E_206C_202E()
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x1F5FC90F
	}

	static Assembly[] _200B_200E_200D_206C_202D_206E_206A_202E_202D_202D_200C_200E_200C_200E_200C_200B_202A_202E_206F_206A_202C_202A_200E_206F_202A_200F_206E_200F_206F_200C_202A_202E_200B_202B_202D_200E_200D_202B_206E_206F_202E(AppDomain P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC3 0x74
	}

	static AssemblyName _200C_202E_206D_206E_200B_206F_200D_206D_206D_206E_206A_206E_200F_200D_206D_206A_206D_200E_200C_206E_206B_202D_202C_200D_200C_206E_202E_206B_200D_200C_206B_206E_200C_202C_200D_200B_200C_206A_206E_202E_202E(Assembly P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF3 0xD9
	}

	static string _206F_206F_206A_200C_202D_202D_202D_202E_206A_202E_200C_202C_202C_202C_202E_200D_206C_202E_202E_200B_206C_200E_200F_206E_206E_202D_200E_202C_206C_206D_200B_200E_206B_202B_202C_206C_202C_206E_200C_202E_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xE471B71B
	}

	static bool _206B_200F_206D_206E_206A_206D_202C_202B_202B_206A_206C_202E_202A_206B_206E_202E_200D_200D_206F_202E_206A_206E_200C_200B_206D_206D_200E_202C_200E_206B_202E_202E_202D_200B_200E_202A_200E_206E_206C_206E_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static CultureInfo _206F_202E_200F_200F_206A_202D_206A_200D_202A_206F_206E_200F_206A_206D_200D_200D_200D_200F_200C_200C_200E_202D_202B_200D_206F_202D_206D_206D_206B_206E_200C_206A_202A_202A_206E_202C_206E_206E_206D_202B_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0F 0x08
	}

	static void _200B_200E_200E_206B_206E_206E_206F_202D_200D_202C_202D_200D_206F_206D_202E_206C_200C_200B_200E_202C_202A_202E_206A_202A_200C_206D_202A_206F_206E_206A_202E_206D_206E_206D_202E_206F_200B_200E_200B_200C_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
	{
		_ = ((Array)/*Error near IL_0001: Stack underflow*/).LongLength;
		/*Error near IL_0001: Invalid metadata token*/;
	}

	static int _200F_206D_200C_202A_200C_200F_202E_206A_206B_202C_200F_202C_202B_202C_202A_206F_206B_202C_206C_202C_206F_200F_206B_202D_202C_206A_206C_206C_206B_206F_200B_202A_200B_202B_206C_200C_200D_200F_200C_206A_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x08
	}

	static Assembly _206B_200F_202C_202E_202A_206A_202D_206A_200B_202A_202D_206F_200E_206A_206E_200B_206D_206C_200E_200F_202D_202E_200B_206A_202A_202C_206E_206B_202D_202E_202E_206F_206C_206A_202C_202E_200B_202E_200F_206E_202E()
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xE2C04B09
	}

	static bool _202C_202E_200B_206A_206E_206C_202A_206A_206A_206C_206B_200B_202B_206A_206F_200E_202D_200F_202B_200F_206E_206E_206D_202E_206E_200D_206F_202C_200D_206B_200F_202A_206E_202D_200D_200D_200F_206B_200F_200D_202E(string P_0, string P_1)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static Stream _202C_202A_200E_206A_206C_200D_202E_200B_200F_206E_206B_206B_200C_206E_200C_200B_202D_206D_206B_202C_206E_202A_206A_206A_200B_206A_200F_206B_206E_202E_202A_202B_202B_206F_206F_200C_202B_200E_200C_206A_202E(Assembly P_0, string P_1)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static DeflateStream _200C_206A_206B_202E_202A_200D_202C_202B_206B_206C_200B_200B_202D_200C_200C_206F_202D_202C_202E_202C_200E_206C_200F_202C_206F_202B_200C_200D_202C_202D_206D_202D_206B_200C_200E_202C_200C_206A_200F_206B_202E(Stream P_0, CompressionMode P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC9
	}

	static MemoryStream _206D_200D_200F_202E_206A_200E_206F_200E_202E_206D_206F_206E_202E_206B_206F_206E_206A_202C_206D_206D_200B_202B_206B_202C_206A_202B_200F_206F_206D_206F_206F_200F_202D_202B_206A_200E_200C_202D_206E_202E_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x40
	}

	static void _206C_200C_206D_202E_200E_206E_206D_202D_206F_206D_200C_200B_200D_206E_206E_200B_202D_202A_206C_206F_200C_206A_200C_200C_206F_200B_202A_206F_206F_200D_206A_202D_206E_200C_206B_200D_206D_202A_200C_206D_202E(Stream P_0, long P_1)
	{
		/*Error near IL_0001: Invalid metadata token*/;
	}

	unsafe static void _200B_206F_200D_206C_206E_200E_206A_206A_206E_200B_202A_206B_206C_202B_200E_206C_206C_206F_202E_202C_206D_200D_200B_206B_200E_200D_200D_200D_200E_206D_206F_202C_200F_202E_202B_200B_206B_200C_200D_202E_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}

	static long _202C_206C_200F_200B_200B_206C_202E_202A_200B_200E_206B_200C_202D_202C_206C_206E_202B_206B_200F_202B_200B_206D_202B_202C_200D_202B_202D_206F_206D_206C_202D_206E_202D_206E_202A_202B_200F_200F_200D_202E_202E(Stream P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x95
	}

	static string _200B_202A_200E_202C_202C_206D_206F_206A_202A_206A_206B_206D_206F_200B_206C_206C_200D_202C_206B_200F_206A_206B_206D_202B_206D_202E_206A_202B_206D_206E_200F_202C_200F_202A_206A_206E_202A_200D_200D_200D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	static bool _202C_202A_206B_200F_206A_200C_206B_200D_200C_206A_202E_200E_202A_202A_206D_200F_202C_202E_206A_200D_202A_200E_202C_206E_202B_202C_206C_206D_200D_202C_200B_206D_202B_200F_200C_206B_206B_202E_202D_202C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCF 0xAB
	}

	static string _200F_200C_202C_206C_202E_200C_200D_200D_200C_202E_202B_200B_202D_206A_206F_206C_206E_200B_202A_200F_202A_202B_202D_202E_206C_200E_206B_202D_200F_200E_206B_206C_206C_200F_206C_206F_206B_200B_206F_202D_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static Assembly _200B_202C_200E_206A_202C_200B_200D_202A_200E_200E_206E_202C_202B_206E_206C_206D_200C_200E_200F_200F_206B_206A_200D_200D_206F_202E_202C_202B_206B_200C_206D_202C_200B_206D_206C_200E_200C_206D_206F_202C_202E(byte[] P_0, byte[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7C
	}

	static Assembly _200E_200C_200B_206B_206E_202A_200E_202E_206C_206B_200B_206E_202B_202B_202C_206D_200B_206E_200E_200D_200F_200D_206F_202C_206B_206E_206A_202A_202B_200B_200C_202E_202E_202D_200D_206B_200D_206E_200D_206A_202E(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x73 0x72
	}

	static void _202C_206F_202A_206E_206D_206F_202A_206F_200C_202B_206B_206A_206E_200B_200D_206B_206A_206E_202A_202B_206C_206F_200E_206F_206C_200D_206C_202E_206E_206C_200B_206A_202C_202C_200C_206D_206B_200D_202B_206A_202E(object P_0, ref bool P_1)
	{
		checked
		{
			_ = (short)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Invalid metadata token*/;
		}
	}

	static string _202B_200E_206B_206C_206C_202C_200B_206A_200C_202C_202D_200E_206D_202A_200C_206E_202C_206A_202A_200E_200D_206D_206B_206E_202A_202B_200E_206D_202A_206E_202A_200E_202E_206C_206A_202C_202B_206B_206F_202B_202E(ResolveEventArgs P_0)
	{
		//IL_0001: Invalid comparison between Unknown and I
		if ((nint)/*Error near IL_0003: Stack underflow*/ > checked((nint)/*Error near IL_0001: Stack underflow*/))
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0003: ldarg 3 (out-of-bounds)*/;
		/*Error near IL_0004: Unknown opcode: 0xFF*/;
	}

	static void _202C_206B_206C_202D_206D_202D_206F_200B_206D_202D_200B_200C_200B_200B_206D_200C_206F_206E_202A_202B_202E_200D_206D_200B_200F_206F_200E_206D_202A_206F_200B_202D_206D_206A_206B_206B_200B_202A_206F_200E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8F 0xE3
	}

	static AssemblyName _200E_200B_202C_202E_200D_202A_200F_206B_200B_200E_202C_202A_206B_202A_202B_200B_200C_202B_200C_206F_206E_202A_206B_206E_202B_200F_202E_206A_200D_200D_200E_206F_206D_200E_206B_202A_202B_206B_200E_206E_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}

	static AssemblyNameFlags _206E_202D_206B_206B_206B_202E_202E_206A_206C_202C_202A_206F_202D_202B_202A_206B_202A_206D_206A_206A_206D_200B_202E_202C_206F_200D_200E_200E_206C_206F_202A_206B_202C_200D_200B_206C_206C_206A_202B_200D_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF9
	}

	static Assembly _206B_206F_202D_206C_200F_202C_200C_202A_202B_206C_202A_206D_200F_206A_202E_206A_206B_202C_200F_206C_202E_200F_202B_202B_202A_206B_202C_206F_200F_206F_200B_200D_200D_206F_200E_200C_206A_202E_206C_202D_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6F 0x00
	}

	static object _202D_206C_200C_206D_200B_202C_202D_206F_202B_202A_206D_206F_206F_206C_206F_206C_206C_202B_202B_200B_202C_202B_206F_206C_206F_206F_202A_206B_202E_200F_200B_206B_206D_206C_202E_202C_202E_200E_202E_202B_202E()
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x13625B0A
	}

	static int _200E_200D_202E_206A_206E_200B_206A_202A_200D_206D_202D_200D_202B_206E_206F_206A_206B_200C_206F_202C_202D_200B_200E_202D_200C_206C_202A_206C_202A_202C_202D_206D_200D_200D_202A_206C_202A_200D_200C_206F_202E(ref int P_0, int P_1)
	{
		//IL_0007: Expected O, but got I
		if (/*Error near IL_0005: Stack underflow*/ <= /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = ((Array)checked((nuint)/*Error near IL_0006: Stack underflow*/)).LongLength;
		/*Error near IL_0007: Unknown opcode: 0xBB*/;
	}

	static void _202D_206C_206B_206B_206E_206E_206E_202B_202D_206D_202C_202C_202A_202C_200C_206E_206F_202A_200E_206E_206E_200E_206E_206E_206D_200F_202B_200B_202D_202A_206F_206D_200D_200B_200F_202A_200E_202E_206F_200D_202E(AppDomain P_0, ResolveEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}
}
