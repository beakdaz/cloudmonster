using System;
using System.Collections.Generic;
using System.Management;
using System.Runtime.CompilerServices;

public static class _EAAU6GAc4kABCcnVXoEKtrlcrm1
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _6YggH9eIaJIeCP8bKLTdDQhpJyl
	{
		public static readonly _6YggH9eIaJIeCP8bKLTdDQhpJyl _003C_003E9;

		public static Func<_1yt6KTtbR2I75eswbNrbIP2z0NK, IEnumerable<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>> _003C_003E9__3_0;

		static _6YggH9eIaJIeCP8bKLTdDQhpJyl()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAB 0xFC
		}

		public _6YggH9eIaJIeCP8bKLTdDQhpJyl()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal IEnumerable<_hG2EdJQQbFzEpDbEbXP1KllPgBaA> _l0XEdWNpdgICd9BHEMitVMM2BJQ(_1yt6KTtbR2I75eswbNrbIP2z0NK P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x24
		}
	}

	[CompilerGenerated]
	private sealed class _WNfELHtkj1ebF7JwWVKwKxYPlyi
	{
		public ManagementBaseObject _WulnkPudjz8IYoyKbNEjs5TsBHE;

		public ManagementObject _7CsA9ym04qmP4JfEl8Tiz90WpcN;

		public _WNfELHtkj1ebF7JwWVKwKxYPlyi()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal _hG2EdJQQbFzEpDbEbXP1KllPgBaA _L2g1k2jWP8W3YWiHe9VBLzt2Xmc(PropertyData P_0)
		{
			/*Error: Invalid metadata token*/;
		}

		static ManagementPath _206F_200D_200F_200E_206A_200C_200D_206D_206E_200B_202B_202A_206C_202D_200D_200F_200F_202A_202E_202A_202C_206B_202D_206F_206A_200C_206C_202D_202B_202E_206D_206D_206D_206D_200F_200D_202A_200C_200E_202B_202E(ManagementBaseObject P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x89
		}

		static string _202D_206A_202A_200B_206F_206C_202E_202C_202E_206B_200E_206C_202A_206E_206C_206B_202D_200C_202B_202E_200F_206C_206C_200D_200D_206A_206F_200F_200C_200D_206D_200B_202A_200C_200E_200B_206D_200C_200F_200D_202E(ManagementPath P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}

		static ManagementScope _202C_200F_202D_206D_206F_202A_200F_206B_200D_200E_202E_200C_206B_200E_202D_206F_206C_206A_200D_206A_206F_202C_206B_202A_206D_200C_202B_202B_206B_202B_206B_202A_206A_200E_200B_206C_200D_202C_200B_202A_202E(ManagementObject P_0)
		{
			/*Error: Invalid calli metadata token*/;
		}

		static ManagementPath _206A_202C_200E_202B_206B_202E_206D_206D_206C_206C_200D_202D_206A_202D_200C_202E_202A_202B_206F_206F_200B_206A_200D_200B_206A_202D_200D_206D_202A_202D_200D_206B_206C_200D_200D_206D_200C_206A_202E(ManagementScope P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x29
		}

		static string _200C_200F_202B_202C_200D_206F_202C_206B_202A_202D_206D_202D_206D_202B_206E_202D_200C_200E_200E_202C_200B_202E_202B_202B_202C_206B_202D_202C_200C_206B_206E_202A_200E_200D_206C_202C_206C_206A_200B_206E_202E(ManagementPath P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8F 0x8E
		}
	}

	public static _O5OTbfPJg1Xl1LFJimOQf125jI2 _E9ycTdt4mOFlRt4bHMk22MDc7LJ(string P_0, string[] P_1 = null, string P_2 = null, ManagementScope P_3 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x48
	}

	public static _O5OTbfPJg1Xl1LFJimOQf125jI2 _oy36y5Bm5gnaBuCoOxbecuaPuAo(ObjectQuery P_0, ManagementScope P_1 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x14
	}

	public static _O5OTbfPJg1Xl1LFJimOQf125jI2 _oy36y5Bm5gnaBuCoOxbecuaPuAo(string P_0, ManagementScope P_1 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8C
	}

	public static _hG2EdJQQbFzEpDbEbXP1KllPgBaA _Np39U857yskXLQDqlugHMjvG96H(string P_0, string P_1, string P_2 = null, ManagementScope P_3 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}

	public static _0001 _Np39U857yskXLQDqlugHMjvG96H<_0001>(string P_0, string P_1, string P_2 = null, ManagementScope P_3 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x98
	}

	private static ManagementObjectCollection _RXicdwtVYcF6y0CRW4ZT8nYaGbl(ObjectQuery P_0, ManagementScope P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE3 0x21
	}

	private static ManagementObjectCollection _RXicdwtVYcF6y0CRW4ZT8nYaGbl(string P_0, ManagementScope P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCB 0x11
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static ManagementObjectCollection _RXicdwtVYcF6y0CRW4ZT8nYaGbl(string P_0, string[] P_1, string P_2, ManagementScope P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7C
	}

	private static ManagementObjectCollection _RXicdwtVYcF6y0CRW4ZT8nYaGbl(string P_0, string P_1, string P_2, ManagementScope P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBF 0x5E
	}

	private static _O5OTbfPJg1Xl1LFJimOQf125jI2 _bF0gcrx9SoIpjaV3DmfjABEL1S(ManagementObjectCollection P_0)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Invalid comparison between Unknown and O
		object obj = ((object[])/*Error near IL_0004: Stack underflow*/)[checked(/*Error near IL_0003: Stack underflow*/ * /*Error: ldloca 136 (out-of-bounds)*/)];
		if (System.Runtime.CompilerServices.Unsafe.As<_003F, UIntPtr>(ref /*Error near IL_0006: Stack underflow*/) <= System.Runtime.CompilerServices.Unsafe.As<object, UIntPtr>(ref obj))
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0006: Unknown opcode: 0xBE*/;
	}

	static ObjectQuery _206B_202D_200F_202D_202B_202C_206C_206B_200B_202A_206E_206B_200D_206F_206E_202B_200B_200B_206C_202A_206F_206E_202A_200F_202C_206F_200B_202C_206C_200C_202A_206C_200B_202B_202A_202B_206A_200C_206B_200C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0C
	}

	static ManagementObjectSearcher _200F_202A_206B_206A_200E_202B_202C_202E_206F_200D_200B_200F_202C_200F_200E_206C_206D_202A_202C_202B_206A_206B_206B_206C_202C_206A_202E_206A_200E_206A_202C_206E_202B_202E_206F_200F_202C_206B_200B_200F_202E(ManagementScope P_0, ObjectQuery P_1)
	{
		/*Error: ldloc 0 (out-of-bounds)*/;
		/*Error near IL_0001: Unknown opcode: 0xE5*/;
	}

	static ManagementObjectCollection _202D_200D_200F_202D_206F_206C_200F_206C_202C_200C_206C_206B_202A_206D_206C_206D_202E_206F_200B_200B_200D_202E_206F_206D_200F_200B_206E_206F_200B_202A_206B_206A_202C_206B_202B_206C_200D_202D_200D_202D_202E(ManagementObjectSearcher P_0)
	{
		/*Error: Unknown opcode: 0x24*/;
	}

	unsafe static void _202A_200C_200E_202B_200C_200C_206E_202A_200D_206D_200C_200F_206E_206B_200B_202A_206C_206F_202D_202C_206F_206E_200F_200B_202C_206D_202C_206C_200D_206C_202E_202D_202D_206A_202A_206B_200B_206E_200D_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}

	static string _200C_206C_202E_202D_200F_206F_200B_200F_206A_202E_202E_200F_200C_202D_202E_206A_200F_206C_202D_202E_206D_202B_202B_206C_206C_200C_206A_202E_200C_206D_202E_202B_200E_206D_200F_200D_202A_206B_202D_202B_202E(string P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	static bool _200B_206F_206F_200D_202B_200B_206E_206D_202A_200C_202A_202C_206B_200B_202E_206A_200D_200D_200F_200B_206D_202D_202E_206B_200D_206B_206F_206E_202D_206B_202D_206E_200E_206E_200C_200F_202A_200E_202A_202B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCF 0xAB
	}

	static string _202B_202E_202A_200B_202E_206F_200D_202C_200D_206A_200B_200D_200C_200D_206B_202C_200D_206F_206D_200F_206D_206D_202C_206A_202E_202A_200E_200E_200D_206A_206D_200D_200C_200B_206C_206F_200F_200F_200B_202A_202E(string P_0, string P_1, string P_2, string P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA8
	}

	static string _202A_202C_202E_202A_206B_206B_206D_206A_200D_202A_202B_200C_206D_206B_200F_206F_200C_202D_202E_200C_200D_206E_206D_200C_206E_202A_206C_202C_206A_202C_206C_200C_202B_200D_200B_206A_200C_206D_206D_206C_202E(string[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF0
	}

	static int _200F_206D_202A_202D_206B_200B_200C_206D_202B_200F_202D_202C_200C_202C_206A_206E_202A_200C_206F_200D_206B_200B_200F_202D_200C_200B_206F_206B_202C_206E_206D_200E_200C_206C_206F_202A_206A_202C_206A_206B_202E(ManagementObjectCollection P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	static ManagementObjectCollection.ManagementObjectEnumerator _202C_202C_202C_200C_202A_202C_202B_206F_206C_200C_202E_206E_206D_206F_202B_202C_202E_200D_200E_202E_206D_206D_202B_200C_206F_200F_202A_200C_200C_206B_206E_202B_206C_206E_206B_206F_200C_206C_200E_206D_202E(ManagementObjectCollection P_0)
	{
		if (/*Error near IL_0005: Stack underflow*/ != /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0005: Unknown opcode: 0xFF*/;
	}

	static ManagementBaseObject _202B_200B_200C_202D_206A_206B_200D_200E_200B_202A_200D_200B_206D_200C_206E_206E_202E_202D_202B_206E_200D_202B_206D_202A_206F_206D_200E_206E_202A_202C_206D_200F_202E_200B_202C_202D_200F_202B_206D_202D_202E(ManagementObjectCollection.ManagementObjectEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x39
	}

	static PropertyDataCollection _202B_200F_200F_206F_200F_200B_200B_200D_202D_200D_206B_202D_202D_202E_200B_200F_206E_202E_206A_200F_202B_206A_200C_200D_202B_206E_200F_206C_200B_206F_200C_206C_206B_206C_206F_200F_206E_206E_206A_202D_202E(ManagementBaseObject P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x98
	}

	static bool _206F_200B_202C_202D_202B_202E_202D_206C_202C_202D_206E_206E_202D_202D_202E_206D_206F_200B_200C_206A_200F_200D_202A_202C_200B_202A_200E_206F_202E_202C_202A_200D_206A_206F_206C_206C_202A_206D_202E_206A_202E(ManagementObjectCollection.ManagementObjectEnumerator P_0)
	{
		((object[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (object)/*Error near IL_0001: Stack underflow*/;
		((int[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/] = (int)/*Error near IL_0002: Stack underflow*/;
		if ((int)/*Error near IL_0007: Stack underflow*/ != 0)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error: End of method reached without returning.*/;
	}

	static void _200E_206F_202C_202D_206F_202A_200F_206E_206D_206E_200B_202B_206C_202C_206B_202C_202D_202D_202A_206F_200B_202D_206B_200B_202B_200C_206F_206C_202C_202E_202D_206E_202C_202D_202E_202A_206F_206F_202B_200E_202E(ManagementObjectCollection P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x35
	}
}
