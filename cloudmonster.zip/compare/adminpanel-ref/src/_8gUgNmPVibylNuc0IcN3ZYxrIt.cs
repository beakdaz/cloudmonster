using System;
using System.Runtime.CompilerServices;

internal class _8gUgNmPVibylNuc0IcN3ZYxrIt : _ylbC3VMOqJzTQdzb7jYbxNmnxve
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _HPvaIGoITjXFoOv4sRRah4f8oqx
	{
		public static readonly _HPvaIGoITjXFoOv4sRRah4f8oqx _003C_003E9;

		public static Func<char, bool> _003C_003E9__24_0;

		static _HPvaIGoITjXFoOv4sRRah4f8oqx()
		{
			_ = (short)/*Error near IL_0001: Stack underflow*/;
			/*Error: End of method reached without returning.*/;
		}

		public _HPvaIGoITjXFoOv4sRRah4f8oqx()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal bool _CNOaxoB0mtBdEkaXew0dTKdca2kA(char P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}
	}

	[CompilerGenerated]
	private string _9re4XnDk08dR3CNlxT0gDl7JSLo;

	[CompilerGenerated]
	private int _wFe2YpH5dSBsBEfBJFLUQdjZ0GG;

	[CompilerGenerated]
	private int _tuL0QIVDv60JwYKxqW6d4oGzj1u;

	[CompilerGenerated]
	private Uri _y2cmVvcowxKaTCXmd0nFq9OAl2y;

	[CompilerGenerated]
	private string _czHUEote15bANtjtz5xTrw9FQ5c;

	[CompilerGenerated]
	private string _4CYp9F64mqPZCZ43FVIsRxOi8dg;

	public string _tLkb1vTk9XEGoGf4Sac02vo4V5b
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5F 0x8C
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEC
		}
	}

	public int _r48uVlmApDzNRTCsJ277gBhrBaJ
	{
		[CompilerGenerated]
		get
		{
			// ILSpy could not decompile this. Please report the exception below,
			// along with the assembly it came from, at https://github.com/icsharpcode/ILSpy/issues/new
			// System.ArgumentException: Invalid token. (Parameter 'token')
			//    at System.Reflection.Throw.InvalidToken()
			//    at System.Reflection.Metadata.Ecma335.MetadataTokens.EntityHandle(Int32 token)
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeMetadataToken() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 225
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeTypeReference() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 237
			//    at ICSharpCode.Decompiler.IL.ILReader.DecodeInstruction() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 1154
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadBlock(ImportedBlock block, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 537
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadInstructions(CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 504
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadIL(MethodDefinitionHandle method, MethodBodyBlock body, GenericContext genericContext, ILFunctionKind kind, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 724
			//    at ICSharpCode.Decompiler.CSharp.CSharpDecompiler.DecompileBody(IMethod method, EntityDeclaration entityDecl, DecompileRun decompileRun, ITypeResolveContext decompilationContext, ExtensionInfo extensionInfo) in /_/ICSharpCode.Decompiler/CSharp/CSharpDecompiler.cs:line 2282
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x58
		}
	}

	public int _OHUEWHxOAqkkLTlPhgek38NJD6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBC
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAC
		}
	}

	public Uri _vbnKRHY5bPW0CVdr9GAdAY3YcKG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}
		[CompilerGenerated]
		private set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0002: Stack underflow*/>> (int)checked((byte)/*Error near IL_0001: Stack underflow*/);
			_ = 6;
			/*Error near IL_0003: Invalid branch target*/;
		}
	}

	public string _5u15pRivXgDMBcvfm36XC4DB5mI
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA3 0xC5
		}
		[CompilerGenerated]
		private set
		{
			/*Error: Invalid metadata token*/;
		}
	}

	public string _lSQPhmbfCSOp8mdwcpRdQBzDogN
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x57 0xD1
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public bool _gHMAm9Wc4g3ZVpouUthFjfB6WMo(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBF 0x14
	}

	bool _ylbC3VMOqJzTQdzb7jYbxNmnxve._gHMAm9Wc4g3ZVpouUthFjfB6WMo(string P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _gHMAm9Wc4g3ZVpouUthFjfB6WMo
		return this._gHMAm9Wc4g3ZVpouUthFjfB6WMo(P_0);
	}

	public virtual string _JcA5cTOIzYiIo3H3fG6PU4hBVnt()
	{
		/*Error: Unknown opcode: 0xC5*/;
	}

	string _ylbC3VMOqJzTQdzb7jYbxNmnxve._JcA5cTOIzYiIo3H3fG6PU4hBVnt()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _JcA5cTOIzYiIo3H3fG6PU4hBVnt
		return this._JcA5cTOIzYiIo3H3fG6PU4hBVnt();
	}

	public _8gUgNmPVibylNuc0IcN3ZYxrIt()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x79
	}

	static string _202E_206D_202A_202B_206D_200D_200F_202D_200C_200F_206C_202D_202C_202D_206A_206E_206A_200D_200F_202A_200D_206E_202B_206F_206D_200D_202E_200E_200D_206E_206A_206C_206C_200E_202C_206F_206D_200F_200C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x48
	}

	static bool _206F_202C_202D_206A_206B_202B_200F_202D_200C_200D_202B_202C_200C_200D_200B_200D_202A_202C_206E_206D_206C_202E_200B_202E_200E_206A_202C_202A_200B_206D_202E_200D_202A_206D_206B_200D_202D_206A_206E_200D_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xFC*/;
	}

	static bool _202E_202E_206B_206B_202A_202A_202A_200F_202C_200E_206D_200B_200C_200F_202E_206D_200E_202C_200D_202A_200F_206A_206A_200B_206F_206A_206E_200C_202D_206B_206F_200B_202A_202B_206C_200D_200F_200E_202B_206D_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBB 0xAB
	}

	unsafe static int _206A_202E_206E_206A_200E_200B_206E_206D_200D_202A_206A_206A_206C_200E_202B_206C_206C_206E_206B_202C_200F_206D_200E_206A_200D_200B_202E_206C_206B_200F_200B_206F_206A_202B_200D_206D_206D_206B_202A_202B_202E(string P_0, char P_1)
	{
		*(sbyte*)(nint)/*Error near IL_0002: Stack underflow*/ = (sbyte)(*(ushort*)(nint)/*Error near IL_0001: Stack underflow*/);
		switch ((int)/*Error near IL_000e: Stack underflow*/)
		{
		default:
			/*Error: End of method reached without returning.*/;
		case 0:
			/*Error: Invalid branch target*/;
		}
	}

	static int _202D_206E_206E_202E_202E_202D_206B_206D_200F_200E_202C_206D_206A_206E_200F_206A_200B_206C_200B_206B_206D_206E_202A_200C_206E_202C_206C_200C_202E_200F_202E_206E_202C_202C_202C_206A_202A_206A_200E_206E_202E(string P_0, char P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA1
	}

	static string _202B_206B_206A_206A_200F_206B_206F_202E_206F_200B_200C_206D_200E_206C_200F_200D_202D_202B_202E_206A_202E_206E_200D_200B_200B_200C_202C_200E_200D_206B_206E_206C_206E_200C_206B_206F_202C_202D_200B_202B_202E(string P_0, int P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB5
	}

	static bool _200C_206E_202D_206E_202C_202D_206A_206A_202B_202D_202B_200C_200C_202D_206D_206C_200E_202B_206F_200E_200C_206C_206A_202E_206D_206B_200F_206F_200C_200D_202C_206C_200E_206D_202E_202B_200C_202E_206A_202D_202E(string P_0, UriKind P_1, ref Uri P_2)
	{
		checked
		{
			_ = (nint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xC8*/;
		}
	}

	static string _202B_200E_200F_206C_200D_202E_200F_206E_202C_206B_206F_202D_200B_202B_200B_206B_200F_202C_200F_206C_200B_202D_202B_202A_202D_200D_202C_200D_200F_206A_200F_200B_200C_206A_202E_206A_202B_202E_206C_200C_202E(string P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x73 0x44
	}

	static string _200C_202A_206A_200B_200E_200E_202A_206D_206A_200F_200C_202D_200C_200D_206E_206B_206C_202A_206F_200B_206B_202C_200F_206B_202E_202E_202B_200C_202A_200C_200E_206A_202A_200B_206E_202A_200F_200F_206E_200F_202E(string P_0, char[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0x2A
	}

	static int _202C_206D_200B_206A_206A_200C_206C_206F_200E_202C_202A_202B_206B_206E_200E_206A_206D_200C_206F_200F_202D_206E_202E_202B_200D_200E_206D_206D_200F_200B_206D_202D_202E_206B_200C_202D_202E_206C_206C_206E_202E(string P_0)
	{
		//IL_0002: Invalid comparison between Unknown and I8
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		if ((long)/*Error near IL_0007: Stack underflow*/ <= ((long[])/*Error near IL_0002: Stack underflow*/)[checked((nint)/*Error near IL_0001: Stack underflow*/)])
		{
			/*Error: Invalid branch target*/;
		}
		_ = /*Error near IL_000a: Stack underflow*/>> (int)/*Error near IL_0008: ldloc 0 (out-of-bounds)*/;
		/*Error near IL_000a: Unknown opcode: 0xA6*/;
	}
}
