using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_DiskDrive")]
public sealed class _yirjcqLRhZxIR4SlHyCZc5P49wh : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _kuvA6FWK0DhATZf9TCQY28FgavaA;

	[CompilerGenerated]
	private string _BomhOxmAcnumfrv8Fuqu1lPhDC4;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _P2teFQjUF0Gwbu9vuj5yBrGXPCh;

	[CompilerGenerated]
	private string _ZqjM3DLwRp6DRVC3M3O1iyRu3Hh;

	[CompilerGenerated]
	private string _wneuDK3DCEulfPPbtL2sj3cQtVLA;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("PNPDeviceID", _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true)]
	public string _73yocnM47xmu5tgeXKmP95jZcZA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x87 0xD8
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xCB
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Model", _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true, _ouek40mfEZcKAiuBOCraP5DTnRQ = true)]
	public string _MclCFJbl3tOBdizGXqhORJWRvjK
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA9
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x38
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD3 0x75
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x58
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Manufacturer")]
	public string _x9LQFtjAmgtdxpWocRgMLYM03Wz
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x14
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("InterfaceType")]
	public string _eZdjnkq5YRkTf4fv3OSWQOpGQIG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x05
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("SerialNumber")]
	public string _hyT42trMGkdEbd3NQlrBtHvEQnA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBF 0xD1
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x20
		}
	}

	protected override bool _XUDlD5OKhFe8yOU6UqXNbLmod9D
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x5D
		}
	}

	private _yirjcqLRhZxIR4SlHyCZc5P49wh()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}

	static bool _200E_202E_206F_200D_200D_200E_200D_206E_202C_200D_202B_206D_206E_202B_202A_206C_200F_200E_200F_206E_200F_200D_206C_202B_206D_200B_206B_202A_202E_206F_202C_202B_200E_206F_200B_200B_200F_206C_206D_200E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDF 0x50
	}
}
