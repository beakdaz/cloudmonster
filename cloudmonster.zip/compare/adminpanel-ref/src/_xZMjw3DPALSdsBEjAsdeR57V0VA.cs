using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

public abstract class _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _h38DtfbpMKSX5XxpB3j3PpbU1iP
	{
		public static readonly _h38DtfbpMKSX5XxpB3j3PpbU1iP _003C_003E9;

		public static Func<PropertyInfo, bool> _003C_003E9__4_0;

		static _h38DtfbpMKSX5XxpB3j3PpbU1iP()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x49
		}

		public _h38DtfbpMKSX5XxpB3j3PpbU1iP()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal bool _GCUzXvMfcQ8VUQtAGrZQ4CmAGxx(PropertyInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x45
		}

		static bool _206A_202A_206A_202B_206C_202E_200D_206F_200D_200E_200F_200C_202C_202C_202E_206E_200C_206B_206F_200B_206F_200F_202A_202B_200E_202D_206E_202A_202C_206D_202A_206F_200E_200B_200E_202D_206B_206A_202C_202E(PropertyInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFB 0xE3
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _Y4cIT0UDhRERybiAbarjWJMGSyZ<_0001> where _0001 : _xZMjw3DPALSdsBEjAsdeR57V0VA
	{
		public static readonly _Y4cIT0UDhRERybiAbarjWJMGSyZ<_0001> _003C_003E9;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute), string> _003C_003E9__3_0;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute), bool> _003C_003E9__3_2;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute), bool> _003C_003E9__3_1;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute), bool> _003C_003E9__3_3;

		static _Y4cIT0UDhRERybiAbarjWJMGSyZ()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x71
		}

		public _Y4cIT0UDhRERybiAbarjWJMGSyZ()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal string _QxusSFOE77Xly8txcIWghaRKUgR((string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4D
		}

		internal bool _WDGAzCkCQ944qeULmASU74OBD78((string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x1D496E70
		}

		internal bool _gWb7PW706uVyhSiNmdfNYpvIEhb((string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD0
		}

		internal bool _vOCbs5hNLM0TprkJk6SVypXhWSf((string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x5A211195
		}
	}

	[CompilerGenerated]
	private sealed class _JoWF6LO8ZYKn9d7ouu78OW4AbxG<_0001> where _0001 : _xZMjw3DPALSdsBEjAsdeR57V0VA
	{
		public (string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) _pLBgu2i0efKtP27sjcRHtVsPGX;

		public _JoWF6LO8ZYKn9d7ouu78OW4AbxG()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal object _k5EC9ZPcMJt6CVdqb3B1W4vZGDz(_0001 P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x45
		}

		static object _200D_202E_202B_206C_202B_200C_206D_206C_200D_200D_206C_202C_202D_206C_200E_200C_202D_206F_200E_202B_202C_206C_200C_206D_202B_200F_200D_206C_202B_200F_200C_202A_206B_202B_202E_200C_206E_202E_202A_206F_202E(PropertyInfo P_0, object P_1, object[] P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA4
		}
	}

	[CompilerGenerated]
	private sealed class _V3X0WqrzD1ODj4MhWtEadI4wGXI : IEnumerable<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute)>, IEnumerator<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute)>, IEnumerator, IDisposable, IEnumerable
	{
		private int _9GEJZGYJ68mAnt4VNfzJl5b6MGF;

		private (string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) _MCVhfg7xzMo4af2c0dGA3h7LTNY;

		private int _stBDpNzy3StyRhYtkhHTxJBbe4i;

		private Type _lASeOritSZbdSkTtux6t34uO8ZB;

		public Type _uGL5Go9XvFvbTS9qrxGDXR6ybNu;

		private IEnumerator<PropertyInfo> _tlsr0FkYM80RAtsZTF8g9u3UV8F;

		(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute) IEnumerator<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute)>._ArLqzdecRa4ViJnE580lu0eiblK
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x5D
			}
		}

		object IEnumerator._UbxdXEvUhyYdjB0rl2K2XQq4u6q
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x33 0xCC
			}
		}

		[DebuggerHidden]
		public _V3X0WqrzD1ODj4MhWtEadI4wGXI(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}

		private bool MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x63
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		private void _rYecFX3e2K28F8JGuobsDXdjP0mA()
		{
			/*Error: Unknown opcode: 0xAB*/;
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			/*Error: Unknown opcode: 0xCA*/;
		}

		[DebuggerHidden]
		IEnumerator<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute)> IEnumerable<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute)>.GetEnumerator()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x65
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}

		static int _206B_200C_200C_206D_206F_202A_200C_206C_206A_200C_202A_202E_206E_202A_202C_202B_200D_202E_206C_206E_200E_206C_200B_200B_200F_206C_206E_206E_206A_200C_200C_206A_200F_206A_200C_206A_202A_202B_206F_206D_202E()
		{
			/*Error: Not a type handle*/;
		}

		static PropertyInfo[] _202B_200E_200F_202B_206A_206C_206B_200E_206E_202E_200C_206D_206C_200E_206A_200C_206D_202A_206A_202D_206E_206B_200D_206A_202A_200F_200E_200B_206C_202C_206E_202B_206A_202E_200E_202A_202B_206F_200D_206F_202E(Type P_0, BindingFlags P_1)
		{
			_ = (nuint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xA8*/;
		}

		static string _200F_202E_202C_206A_202D_200D_200D_206F_202E_202A_206A_206F_200E_206C_200D_202C_206B_206F_202A_206A_206C_200E_206B_202A_200E_206A_200B_206E_206E_200B_202B_202E_200D_206E_200E_202D_206A_200B_200B_206D_202E(MemberInfo P_0)
		{
			/*Error: Read out of bounds.*/;
		}

		static bool _202B_200D_200B_206F_206A_200F_206E_200D_200B_200C_206C_202A_202D_206D_202A_202C_206B_200B_202A_206F_206D_206F_200E_206C_200B_200E_200D_200E_200F_202A_200D_200F_200C_206E_206B_202A_200F_200F_202B_206C_202E(IEnumerator P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x03
		}

		unsafe static void _202D_202C_200C_202A_202E_200C_206D_202D_200D_202C_206B_206A_206C_202D_206B_206B_202E_206E_202D_202D_200B_206B_206F_202B_206A_206F_202D_202B_202C_200E_206B_200F_206F_206F_206E_206D_202C_206D_202D_200F_202E(IDisposable P_0)
		{
			_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
			/*Error near IL_0003: Unknown opcode: 0xCC*/;
		}

		static NotSupportedException _206B_200F_200B_202E_206B_200D_206D_202B_202B_202C_202B_202D_200B_206B_206F_206A_206A_206E_206A_206D_202D_206A_206F_200F_200C_202E_202B_200D_200D_206C_202A_202C_206A_200F_202B_206D_200D_206C_206B_206F_202E()
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x92D93F56
		}
	}

	protected virtual bool _XUDlD5OKhFe8yOU6UqXNbLmod9D
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x14
		}
	}

	public static _0001 _XdwVt6xEhWMaAmf1ayxFNF3GvYO<_0001>() where _0001 : _xZMjw3DPALSdsBEjAsdeR57V0VA
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static IEnumerable<_0001> _gVLzkcUClkI2env3L4d9ozCdcfZ<_0001>() where _0001 : _xZMjw3DPALSdsBEjAsdeR57V0VA
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x58
	}

	[IteratorStateMachine(typeof(_V3X0WqrzD1ODj4MhWtEadI4wGXI))]
	private static IEnumerable<(string PropertyName, PropertyInfo PropertyInfo, _2WWuZkVyeGvbWUepNxM3hrTLo0Q PropertyAttribute)> _34k1MCIVTxf7H9JyD08iMQlfSYh(Type P_0)
	{
		/*Error: Unknown opcode: 0xCD*/;
	}

	protected _xZMjw3DPALSdsBEjAsdeR57V0VA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static Type _202E_200F_206A_200E_206B_206E_206F_202B_202E_202D_206B_200D_202A_202C_206B_202D_202A_200B_200C_206E_206E_200D_202D_206B_200D_200D_202E_202B_200D_206E_200E_200D_200C_202C_200C_200D_200C_206F_202C_200D_202E(RuntimeTypeHandle P_0)
	{
		if (/*Error near IL_0005: Stack underflow*/ >= /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0005: Unknown opcode: 0xC4*/;
	}

	static object _202E_202B_200F_202D_206F_202E_202B_202B_202C_202E_206F_200D_200D_206A_202C_202D_200D_200E_206B_200E_202E_200E_206B_206D_202D_206B_200E_200F_206F_206F_206F_200D_202A_206A_206B_206F_200B_200B_202A_206A_202E(Type P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}

	static string _206C_202D_202A_206B_206E_202D_202C_206F_202E_200C_206D_202D_206C_206C_206A_200D_206E_200D_206A_202A_206C_206B_200B_206B_206A_206D_200E_206B_202E_202E_202D_202D_200F_200D_206C_206E_202B_200F_206B_202C_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD0
	}

	static string _202E_202E_202E_206E_200D_202E_206E_202B_202E_202C_202E_200F_206F_200C_206C_202B_202B_200D_206A_206B_200D_200F_206D_206C_206E_206E_200C_202C_206C_206A_202B_206D_200E_206F_202C_206D_206A_200C_206D_202B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x48
	}

	static void _200D_200F_200B_200B_200E_200F_200D_202E_206B_202E_202C_206F_202B_206A_206B_206B_206C_202D_206F_202B_200F_202B_200B_206D_206F_206E_202C_200F_206A_206C_202B_202C_206C_202D_206C_200B_200B_206A_200D_202E_202E(PropertyInfo P_0, object P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x15
	}

	static bool _206B_206D_202A_200C_200E_206C_200D_206C_206F_206F_202B_200E_206B_206D_202D_206B_202D_206F_206D_206D_200C_200F_206D_206A_206D_206C_206A_206D_206E_206E_200C_202E_202C_202B_206E_200B_206E_202D_200D_200F_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x03
	}

	unsafe static void _200F_206D_206A_206D_206B_200D_206E_202B_206F_206F_206D_200F_200B_202B_202D_206A_200E_200F_202B_202B_206C_200F_206E_206C_200E_200F_206B_202C_202D_200F_200B_200B_202C_206C_206E_200E_202C_202E_206F_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}

	static object _202D_206C_200F_200B_202D_200D_200B_206B_206F_206E_202A_202C_202C_202B_200C_202C_206C_206E_200F_206F_200F_206C_200F_206B_202E_200F_200E_202D_202C_202E_206F_206C_202B_200F_200E_202E_202E_206B_206E_202D_202E(PropertyInfo P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3D
	}

	static bool _206A_206F_200E_200E_200D_206F_200D_202E_206D_206A_202D_206D_202B_202A_200F_202A_206F_206E_206D_206D_206C_206D_200D_206A_202B_206A_202B_202E_202D_200D_206A_206D_200E_200C_206A_206E_200F_206E_206E_202A_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCF 0xAB
	}
}
