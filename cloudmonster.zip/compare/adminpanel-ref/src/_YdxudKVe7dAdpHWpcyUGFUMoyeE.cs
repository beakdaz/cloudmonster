using System;
using System.Runtime.CompilerServices;

[AttributeUsage(AttributeTargets.Class)]
public sealed class _YdxudKVe7dAdpHWpcyUGFUMoyeE : Attribute
{
	[CompilerGenerated]
	private readonly string _aNVEblQIbz1M6j98PTUDrNJqIG5;

	public string _rka1bBkjj60yV85at5nQaDZXAmy
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}
	}

	public _YdxudKVe7dAdpHWpcyUGFUMoyeE(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x61
	}
}
