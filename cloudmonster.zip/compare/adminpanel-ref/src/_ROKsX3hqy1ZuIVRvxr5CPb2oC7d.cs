using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

public class _ROKsX3hqy1ZuIVRvxr5CPb2oC7d
{
	[CompilerGenerated]
	private sealed class _HxFNpy0k8gw8lZujiPYrgjqTTQG : IEnumerable<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d>, IEnumerator<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d>, IEnumerator, IDisposable, IEnumerable
	{
		private int _9GEJZGYJ68mAnt4VNfzJl5b6MGF;

		private _ROKsX3hqy1ZuIVRvxr5CPb2oC7d _MCVhfg7xzMo4af2c0dGA3h7LTNY;

		private int _stBDpNzy3StyRhYtkhHTxJBbe4i;

		private string _boBdB0ZEtDIcxoXdRXsum7z4H6;

		public string _UhpimNNqwzR5O5VYjO59UIrTBaF;

		private string[] _tlsr0FkYM80RAtsZTF8g9u3UV8F;

		private int _6dwJhK1fGtQbc55VGChBhff515c;

		_ROKsX3hqy1ZuIVRvxr5CPb2oC7d IEnumerator<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d>._SEEquTJ3BHgC4D4TRUcjWMVJG7C
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x53 0xCA
			}
		}

		object IEnumerator._UbxdXEvUhyYdjB0rl2K2XQq4u6q
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x53 0xCA
			}
		}

		[DebuggerHidden]
		public _HxFNpy0k8gw8lZujiPYrgjqTTQG(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEF 0x86
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
			if ((int)/*Error near IL_0002: Stack underflow*/ != 0)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0002: Unknown opcode: 0xC7*/;
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		private bool MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCD
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			if (/*Error near IL_0005: Stack underflow*/ > /*Error near IL_0005: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			((long[])/*Error near IL_0006: Stack underflow*/)[/*Error near IL_0006: Stack underflow*/] = (long)/*Error near IL_0006: Stack underflow*/;
			checked
			{
				_ = (ulong)/*Error near IL_0007: Stack underflow*/;
				/*Error near IL_0007: Unknown opcode: 0xC4*/;
			}
		}

		[DebuggerHidden]
		IEnumerator<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d> IEnumerable<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d>.GetEnumerator()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA4
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x28
		}

		static int _206C_202A_202D_202D_200E_200E_200E_202E_200B_202E_206B_202C_206F_206B_200E_200D_202A_202C_206F_202A_202A_200F_200C_200F_200F_206B_202E_202D_202A_200E_200D_206D_202A_202B_206A_206B_200F_202E_202A_206A_202E()
		{
			/*Error: Not a type handle*/;
		}

		static string[] _200C_202D_206C_200E_206A_206A_206E_202B_202B_202B_206E_206F_202E_202E_200F_200F_206C_202C_202C_200F_200B_200D_206F_200F_202C_202B_206C_200E_200D_206E_202C_206A_206E_202E_202C_202D_206A_202A_202A_200C_202E(string P_0, string[] P_1, StringSplitOptions P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}

		static NotSupportedException _206E_202C_206B_200D_202B_200E_202E_200C_200F_206E_200B_206C_200F_200F_206C_206B_200C_206C_200B_206F_202A_200B_206E_206E_206A_202B_202B_200F_202E_206C_206B_206A_206F_206B_200D_200E_206A_206F_200C_206A_202E()
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x92D93F56
		}
	}

	private const string _3X4YgC68HNmFKjZh8WnpqmPsr2c = "^(\\d{1,3}\\.){3}\\d{1,3}:(\\d+)$";

	[CompilerGenerated]
	private readonly string _2TMGbdWiBDblPHkjcsdKf2F1Z7Ob;

	[CompilerGenerated]
	private string _uJP6Wl5zNM4YgowAIbekk8Xd5GT;

	[CompilerGenerated]
	private int _5a9gKqWrPd3SwAFBHXtuBlSfeDC;

	[CompilerGenerated]
	private string _czHUEote15bANtjtz5xTrw9FQ5c;

	[CompilerGenerated]
	private string _4CYp9F64mqPZCZ43FVIsRxOi8dg;

	[CompilerGenerated]
	private int _JQp7dH0V73rtVTbGYDWR0fXKoyd;

	public string _Oky2NoDXN6f1nmRnFkxHJv65FtA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFD
		}
	}

	public string _NppCklD2KSgW8wx2PWGYokuGLlO
	{
		[CompilerGenerated]
		get
		{
			((sbyte[])/*Error near IL_0003: Stack underflow*/)[/*Error near IL_0003: Stack underflow*/] = (sbyte)/*Error: ldarg 197 (out-of-bounds)*/;
			/*Error near IL_0003: Unknown opcode: 0xF1*/;
		}
		[CompilerGenerated]
		internal set
		{
			((long[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (long)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0002: Handle with invalid row number.*/;
		}
	}

	public int _iiCNdcbnBvzdR0z8fi2dDexxQPk
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x38
		}
		[CompilerGenerated]
		internal set
		{
			/*Error: stloc 2 (out-of-bounds)*/;
			/*Error near IL_0001: Invalid metadata token*/;
		}
	}

	public string _5u15pRivXgDMBcvfm36XC4DB5mI
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0C
		}
		[CompilerGenerated]
		internal set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x49
		}
	}

	public string _lSQPhmbfCSOp8mdwcpRdQBzDogN
	{
		[CompilerGenerated]
		get
		{
			/*Error: Stack underflow*/;
			_ = 4u;
			/*Error near IL_0003: Unknown opcode: 0xCC*/;
		}
		[CompilerGenerated]
		internal set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4C
		}
	}

	public int _38s9YASbeqmByU7LwZwVrgYfRYc
	{
		[CompilerGenerated]
		get
		{
			/*Error: Invalid field token*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBC
		}
	}

	internal _ROKsX3hqy1ZuIVRvxr5CPb2oC7d()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	internal _ROKsX3hqy1ZuIVRvxr5CPb2oC7d(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x73 0xE7
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static bool _tZDL3ORTz6AORcHpEI0cEo3Tij(string P_0, out _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	[IteratorStateMachine(typeof(_HxFNpy0k8gw8lZujiPYrgjqTTQG))]
	public static IEnumerable<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d> _lMgWU3tcb65LHBvgilI5Qz9amHf(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x77 0x7D
	}

	public int _lDAGfFn8AH4KeIcDk2MM5uRBKbJ(int P_0 = 1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x01
	}

	public int _NEFB1ZpblWbgvYu9DqhNv2a5AzvA(int P_0 = 1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x43 0xC7
	}

	public virtual string _JcA5cTOIzYiIo3H3fG6PU4hBVnt()
	{
		/*Error: Unknown opcode: 0xAF*/;
	}

	public virtual int _6Vqzq2u1Bn2iVnKhMXeTF4WkbFj()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x58
	}

	public virtual bool _1i8hQdhaFXFJiAFCkS5pDg25Tm6(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE0
	}

	static bool _200D_200F_206B_200F_202B_200F_200C_200B_200F_200F_200C_206A_202C_206D_200F_202D_200D_200E_202C_206A_206B_206F_206A_206B_206C_206A_200C_202D_200C_206B_202A_200B_202B_206F_200D_206B_206F_200E_202D_202C_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xFC*/;
	}

	static string[] _202D_206A_200B_200C_206A_200F_206C_200B_202D_202B_200C_202E_200B_202B_206D_202C_202A_200F_200E_206D_206B_206C_206E_200C_206B_202C_206E_200D_200D_202C_200F_202B_200D_202C_202D_200E_200F_200D_206C_206E_202E(string P_0, char[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4B 0x8A
	}

	static string _200C_202C_202D_206B_200B_200C_202E_206F_200D_202D_202B_200E_206D_206A_202B_202E_200F_202D_206C_206B_206A_202D_202B_206F_200E_202D_200B_200E_200C_202E_202E_206D_200F_200C_206A_200B_206A_202C_206B_200C_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static int _200B_200E_206C_206D_206C_206B_200D_206F_200E_202B_200E_202C_206B_200D_200C_206B_206F_200C_202B_206B_206F_202E_206D_202D_202B_200E_206D_200C_202C_202E_202B_206B_202E_200E_206B_206E_202A_202C_206B_206D_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x34
	}

	static Type _206C_200D_202D_206A_206B_206C_206E_206E_200C_206D_200D_200B_200D_206E_202E_200D_202B_200C_202B_202C_202D_206A_200D_200F_202B_202E_202E_202D_202E_206B_200D_202B_206B_206B_206A_202C_206A_200C_202E_202D_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xFB*/;
	}

	static Type _200D_206A_200E_206A_202D_206C_206A_206E_206B_200E_206A_200D_202D_206E_202A_206D_202D_206D_202B_202E_206D_206D_200C_200C_202E_206E_200D_200B_206C_206E_202C_202D_206C_200D_206C_202C_200B_200E_206A_202C_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	static bool _206B_200D_206D_206D_202A_202A_200F_202E_200E_200E_206A_202C_206A_200C_206E_202E_200B_206F_206A_200E_200D_200C_202E_202A_202D_206A_202E_200F_202D_206D_200C_200F_200F_206D_206A_206D_200C_200D_202A_202B_202E(Type P_0, Type P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static bool _206F_202A_202D_206A_206D_206D_206D_202B_206A_206A_202D_206E_202C_200E_206B_206D_202B_206D_202B_200C_202D_202E_206C_206A_206C_202E_206B_202B_202C_206A_200B_206C_206E_200F_202E_202E_206C_206E_206E_206E_202E(string P_0, string P_1)
	{
		/*Error: Not a type handle*/;
	}

	static bool _206C_202E_200F_200F_206B_206C_200B_200C_202D_206D_200D_200E_202E_200D_200F_200D_202D_200C_202D_206C_200B_200D_200C_206D_200D_200B_200E_206F_200C_200E_202E_202C_206D_200B_200C_202C_200E_206C_206E_202B_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}
}
