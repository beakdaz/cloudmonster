using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Input;

public class _BZqvkdLY4dPI6b30wfL1VivCfyG : ICommand
{
	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _FVC9URqWXFzdDbihu0RMwjrPZmu : IAsyncStateMachine
	{
		public int _9GEJZGYJ68mAnt4VNfzJl5b6MGF;

		public AsyncTaskMethodBuilder _aHiI51deYTr44VDecb3BGvtoMal;

		public _BZqvkdLY4dPI6b30wfL1VivCfyG _BdhCADRkuGneNk31bMQ4Ub3HhtX;

		private TaskAwaiter _eJGWHxhKuZg5DUMzSWcGKzBa7xH;

		private unsafe void MoveNext()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0002: Stack underflow*/>> (int)(*(sbyte*)(nint)/*Error near IL_0001: Stack underflow*/);
			/*Error near IL_0002: stloc 1 (out-of-bounds)*/;
			/*Error near IL_0003: Unknown opcode: 0x24*/;
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x79
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static TaskAwaiter _200F_202D_206D_206F_202D_206F_200E_202D_206E_202E_206C_206D_200B_206F_200F_202E_202B_200B_200D_202B_206E_206F_206B_200E_206C_200B_206C_200C_206E_202E_200D_206F_200E_200B_200C_200B_202B_206F_202E_202B_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _JdRFjRKXFVR5YqHpvoVi9NzdV4J : IAsyncStateMachine
	{
		public int _9GEJZGYJ68mAnt4VNfzJl5b6MGF;

		public AsyncVoidMethodBuilder _aHiI51deYTr44VDecb3BGvtoMal;

		public _BZqvkdLY4dPI6b30wfL1VivCfyG _BdhCADRkuGneNk31bMQ4Ub3HhtX;

		private TaskAwaiter _eJGWHxhKuZg5DUMzSWcGKzBa7xH;

		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2C
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5D
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static TaskAwaiter _206E_206B_200C_206F_206B_200F_206D_202D_202B_206C_206A_206A_202A_200F_206D_200C_200C_200F_200B_202E_200C_200E_206F_206A_200B_206E_200C_206C_200D_202E_200E_202B_200B_200D_202C_202D_206A_206C_202E_200D_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
	}

	private bool _huxc8mCV44Jdpdu1GLzBXHV67Je;

	private readonly Func<Task> _1FcY4vmVSEttI37QXYZpwB1aBXn;

	private readonly Func<bool> _5RzlBt1FY4Q1JglnGkEiXyl3CYT;

	private readonly Action<Exception> _VYKrTv0FmxreC0p1DlaANixlq8O;

	public event EventHandler CanExecuteChanged
	{
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC1
		}
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x93 0xD1
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _BZqvkdLY4dPI6b30wfL1VivCfyG(Func<Task> P_0, Func<bool> P_1 = null, Action<Exception> P_2 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}

	public bool _0OSGfAuCv6CxE4X4CFGFKSoL3vO()
	{
		checked
		{
			_ = (nuint)(uint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0002: Unknown opcode: 0xEE*/;
		}
	}

	[AsyncStateMachine(typeof(_FVC9URqWXFzdDbihu0RMwjrPZmu))]
	public Task _1meWBCyjQ9krwDN1CcbxRgbQbDl()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	public void _ETDmsrrgxr1tE99vPIVp4ojZgcg()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC5
	}

	bool ICommand.CanExecute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	[AsyncStateMachine(typeof(_JdRFjRKXFVR5YqHpvoVi9NzdV4J))]
	void ICommand.Execute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static ArgumentNullException _206A_200F_200B_200B_200F_202A_202D_200C_200C_206F_206D_202B_200F_200B_206A_206B_206A_206F_202D_202D_202C_200C_206C_206B_200D_202A_202D_200D_200B_206F_202C_206A_206F_206C_206C_200B_206D_206E_200B_202A_202E(string P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xE5*/;
	}

	static void _206C_200B_200D_200F_202E_200F_202A_200E_200F_202D_200B_200C_206F_206A_202C_200B_202A_200C_206E_200F_206B_206D_200E_202B_206A_200B_200D_200E_202D_200E_206F_206F_206E_206C_206F_206D_206C_206B_206C_200D_202E(EventHandler P_0)
	{
		/*Error: Unknown opcode: 0xC9*/;
	}

	static void _200B_202E_200D_206A_206E_206D_202E_200D_206C_206F_206D_206A_206B_206E_200E_202D_202C_200B_206D_206A_202B_202B_200B_200F_206C_202C_202E_200F_206D_200E_202C_202D_202A_202A_200C_206C_202C_200E_200C_206E_202E(EventHandler P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}

	static void _206E_200F_200B_202C_200F_200D_206C_206F_200F_206E_206B_206A_202C_202A_202C_202A_202A_206D_206B_200B_206E_202A_206E_206A_202C_200C_202D_202E_206E_202E_202A_206F_202D_206E_206C_206C_202C_200D_200F_206D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA1
	}
}
