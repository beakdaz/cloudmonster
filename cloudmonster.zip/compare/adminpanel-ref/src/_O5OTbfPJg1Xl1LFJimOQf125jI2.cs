using System.Collections;
using System.Collections.Generic;
using System.Reflection;

[DefaultMember("Item")]
public sealed class _O5OTbfPJg1Xl1LFJimOQf125jI2 : ICollection<_1yt6KTtbR2I75eswbNrbIP2z0NK>, IEnumerable<_1yt6KTtbR2I75eswbNrbIP2z0NK>, IEnumerable
{
	private readonly List<_1yt6KTtbR2I75eswbNrbIP2z0NK> _d9SDAbXed5Mcjkx8Vn54XpC8KZJ;

	public bool IsReadOnly
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
	}

	public int Count
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDD
		}
	}

	// C# has no syntax for parameterized property '_6iQrWjiGHcPmhRUzlPuIV50j3zB'.
	public _1yt6KTtbR2I75eswbNrbIP2z0NK _gQLdNrq85mKGHnEpXofpB1osQnf(int P_0)
	{
		/*Error: Unknown opcode: 0xF8*/;
	}

	public _O5OTbfPJg1Xl1LFJimOQf125jI2()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE1
	}

	public _O5OTbfPJg1Xl1LFJimOQf125jI2(IEnumerable<_1yt6KTtbR2I75eswbNrbIP2z0NK> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x68
	}

	public void Add(_1yt6KTtbR2I75eswbNrbIP2z0NK item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	void ICollection<_1yt6KTtbR2I75eswbNrbIP2z0NK>.Add(_1yt6KTtbR2I75eswbNrbIP2z0NK item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Add
		this.Add(item);
	}

	public void _MUBdjNXCBFoE0kpV8M9gDph3Mwj(IEnumerable<_hG2EdJQQbFzEpDbEbXP1KllPgBaA> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	public void Clear()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2D
	}

	void ICollection<_1yt6KTtbR2I75eswbNrbIP2z0NK>.Clear()
	{
		//ILSpy generated this explicit interface implementation from .override directive in Clear
		this.Clear();
	}

	public bool Contains(_1yt6KTtbR2I75eswbNrbIP2z0NK item)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	bool ICollection<_1yt6KTtbR2I75eswbNrbIP2z0NK>.Contains(_1yt6KTtbR2I75eswbNrbIP2z0NK item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Contains
		return this.Contains(item);
	}

	public void CopyTo(_1yt6KTtbR2I75eswbNrbIP2z0NK[] array, int arrayIndex)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA0
	}

	void ICollection<_1yt6KTtbR2I75eswbNrbIP2z0NK>.CopyTo(_1yt6KTtbR2I75eswbNrbIP2z0NK[] array, int arrayIndex)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CopyTo
		this.CopyTo(array, arrayIndex);
	}

	public IEnumerator<_1yt6KTtbR2I75eswbNrbIP2z0NK> GetEnumerator()
	{
		/*Error: Unknown opcode: 0xCE*/;
	}

	IEnumerator<_1yt6KTtbR2I75eswbNrbIP2z0NK> IEnumerable<_1yt6KTtbR2I75eswbNrbIP2z0NK>.GetEnumerator()
	{
		//ILSpy generated this explicit interface implementation from .override directive in GetEnumerator
		return this.GetEnumerator();
	}

	public bool Remove(_1yt6KTtbR2I75eswbNrbIP2z0NK item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	bool ICollection<_1yt6KTtbR2I75eswbNrbIP2z0NK>.Remove(_1yt6KTtbR2I75eswbNrbIP2z0NK item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Remove
		return this.Remove(item);
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		/*Error: Unknown opcode: 0xCE*/;
	}
}
