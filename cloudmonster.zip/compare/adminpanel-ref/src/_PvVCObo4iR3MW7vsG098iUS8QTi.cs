using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_Processor")]
public sealed class _PvVCObo4iR3MW7vsG098iUS8QTi : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _012ZSrRRLfbndnjAEoWtUneReGm;

	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _o1FOX1r0O9LRVaLJAy4gCZoysJg;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _P2teFQjUF0Gwbu9vuj5yBrGXPCh;

	[CompilerGenerated]
	private string _0CHM24oBzEVx8mohx53c2gaDAyd;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("ProcessorId", _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true, _ouek40mfEZcKAiuBOCraP5DTnRQ = true)]
	public string _bkn9FQtr8rCF1qKMuMLrNaAxwIh
	{
		[CompilerGenerated]
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0001: Stack underflow*/>> (int)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xEB*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD0
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name")]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x24
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDD
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("UniqueId")]
	public string _bIQiRZkXzUkaIn8RSQ3DdBWZc9L
	{
		[CompilerGenerated]
		get
		{
			/*Error: Not a type handle*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x37 0x82
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x65
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0xDC
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Manufacturer")]
	public string _x9LQFtjAmgtdxpWocRgMLYM03Wz
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x53 0x56
		}
		[CompilerGenerated]
		set
		{
			checked
			{
				_ = (ulong)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xF0*/;
			}
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("SocketDesignation")]
	public string _o2NaxdD9Aq43hF3zwBRM96cvV1e
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x39
		}
		[CompilerGenerated]
		set
		{
			// ILSpy could not decompile this. Please report the exception below,
			// along with the assembly it came from, at https://github.com/icsharpcode/ILSpy/issues/new
			// System.ArgumentException: Invalid token. (Parameter 'token')
			//    at System.Reflection.Throw.InvalidToken()
			//    at System.Reflection.Metadata.Ecma335.MetadataTokens.EntityHandle(Int32 token)
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeMetadataToken() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 225
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeFieldReference() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 249
			//    at ICSharpCode.Decompiler.IL.ILReader.DecodeInstruction() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 1225
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadBlock(ImportedBlock block, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 537
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadInstructions(CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 504
			//    at ICSharpCode.Decompiler.IL.ILReader.ReadIL(MethodDefinitionHandle method, MethodBodyBlock body, GenericContext genericContext, ILFunctionKind kind, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 724
			//    at ICSharpCode.Decompiler.CSharp.CSharpDecompiler.DecompileBody(IMethod method, EntityDeclaration entityDecl, DecompileRun decompileRun, ITypeResolveContext decompilationContext, ExtensionInfo extensionInfo) in /_/ICSharpCode.Decompiler/CSharp/CSharpDecompiler.cs:line 2282
		}
	}

	private _PvVCObo4iR3MW7vsG098iUS8QTi()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}
}
