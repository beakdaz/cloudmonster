using System;
using System.Security.Cryptography;

public sealed class _ig3zSoN8ndHmOTSVAIHkf2LKmxy : HashAlgorithm
{
	public const uint _9mQXMBGKRInYCNVKlwRNo18gGT = 3988292384u;

	public const uint _RtYF6zqZ8pjEsJMEe6dqC6DBaun = uint.MaxValue;

	private static readonly uint[] _LWIuF2Oywb2kEullygmxyxvaEfC;

	private readonly uint _O7kZuGgCrUP9hAjIsruj3WAB6Uu;

	private readonly uint[] _UBeCE0rLRwj5LP2WykwWhVFHWgaA;

	private uint _CdhYfyaI515KIWuVn9ZgxRNj6AD;

	public override int HashSize
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}
	}

	public _ig3zSoN8ndHmOTSVAIHkf2LKmxy()
	{
		/*Error: Unknown opcode: 0xC1*/;
	}

	public _ig3zSoN8ndHmOTSVAIHkf2LKmxy(uint P_0, uint P_1)
	{
		checked
		{
			_ = (short)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xC1*/;
		}
	}

	public void _ldTXahQq7LRyKViow7gqyDqgdik()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	protected void _9ikiiwrwKT2bBizbBPRvLlJnnWK(byte[] P_0, int P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE0
	}

	protected byte[] _C8YaLlDdQagtpDB6shicvKl89qW()
	{
		/*Error: Unknown opcode: 0xAA*/;
	}

	public static uint _SBdIH0leP20bEKvOmaTbArNmK49(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x23 0x4E
	}

	public static uint _SBdIH0leP20bEKvOmaTbArNmK49(uint P_0, byte[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}

	public static uint _SBdIH0leP20bEKvOmaTbArNmK49(uint P_0, uint P_1, byte[] P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2F 0x46
	}

	private static uint[] _PSZ8YCwWEkiuUYgOTOJYGBK6Jse(uint P_0)
	{
		switch ((int)/*Error near IL_0037: Stack underflow*/)
		{
		default:
			/*Error: End of method reached without returning.*/;
		case 0:
			/*Error: Invalid branch target*/;
		case 1:
			/*Error: Invalid branch target*/;
		case 2:
			/*Error: Invalid branch target*/;
		case 3:
			/*Error: Invalid branch target*/;
		case 4:
			/*Error: Invalid branch target*/;
		case 5:
			/*Error: Invalid branch target*/;
		case 6:
			/*Error: Invalid branch target*/;
		case 7:
			/*Error: Invalid branch target*/;
		case 8:
			/*Error: Invalid branch target*/;
		case 9:
			/*Error: Invalid branch target*/;
		case 10:
			/*Error: Invalid branch target*/;
		case 11:
			/*Error: Invalid branch target*/;
		}
	}

	private static uint _5kQw5r3Mjf8qcONs0UnHWU0MAAJ(uint[] P_0, uint P_1, byte[] P_2, int P_3, int P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB7 0x03
	}

	private static byte[] _5w0u2vxQA9TDFigZwhpe39DamDD(uint P_0)
	{
		checked
		{
			if ((long)/*Error near IL_0001: Stack underflow*/ == 0L)
			{
				/*Error: Invalid branch target*/;
			}
			_ = (ushort)/*Error near IL_0007: Stack underflow*/;
			/*Error near IL_0008: Unknown opcode: 0xAD*/;
		}
	}

	static _ig3zSoN8ndHmOTSVAIHkf2LKmxy()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x78
	}

	static byte[] _200F_206B_202E_200D_206B_206E_202C_206B_200C_206C_200C_200F_206C_202B_202D_202B_200B_202B_202D_200C_206D_200F_200F_206B_200F_202B_202B_200B_200F_206A_202D_206A_200B_206F_206B_202E_202D_206C_206A_202C_202E(uint P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0xFC
	}

	static void _202A_202C_206B_202D_202A_206B_206D_202A_200D_202D_206E_202D_202C_202D_202A_200B_200B_202B_206B_202D_200D_200C_200F_200F_200C_202E_202D_200B_202B_206B_200E_202D_202C_206E_206E_206F_206F_202D_206C_206A_202E(Array P_0)
	{
	}

	static void _200B_200D_202E_202C_200D_202B_202C_206C_202E_200C_206C_206A_200D_202C_200E_206F_206A_206C_206F_202C_206D_206D_206A_206D_206B_206A_202C_206D_202A_202B_202E_206C_206E_206A_202D_206E_206E_200D_202B_202A_202E(Array P_0, RuntimeFieldHandle P_1)
	{
		/*Error: Invalid metadata token*/;
	}
}
