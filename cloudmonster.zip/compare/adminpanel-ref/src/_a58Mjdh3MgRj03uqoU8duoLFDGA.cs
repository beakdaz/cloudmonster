using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_BIOS")]
public sealed class _a58Mjdh3MgRj03uqoU8duoLFDGA : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _ZFQfrfff2m907zHawoz8UtG7CCJ;

	[CompilerGenerated]
	private string _I0vaHOuhw0CAW6uSA0DqIwES8FX;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _P2teFQjUF0Gwbu9vuj5yBrGXPCh;

	[CompilerGenerated]
	private string _wneuDK3DCEulfPPbtL2sj3cQtVLA;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name", _ouek40mfEZcKAiuBOCraP5DTnRQ = true)]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x53 0x2A
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Version")]
	public string _We0bDTh5OF1piEKdm7XfIwcBS3uA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x73 0xDD
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0C
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Caption")]
	public string _WVZCeL07h3KQ3QyLtbqAFyMsWVW
	{
		[CompilerGenerated]
		get
		{
			//IL_0005: Invalid comparison between Unknown and I4
			if ((int)/*Error near IL_000a: Stack underflow*/ >= -1943700290)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_000a: stloc 3 (out-of-bounds)*/;
			/*Error near IL_000b: Unknown opcode: 0xE8*/;
		}
		[CompilerGenerated]
		private set
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0001: Stack underflow*/<< (int)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xAE*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2B 0x7A
		}
		[CompilerGenerated]
		private set
		{
			/*Error: Unknown opcode: 0xCE*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Manufacturer")]
	public string _x9LQFtjAmgtdxpWocRgMLYM03Wz
	{
		[CompilerGenerated]
		get
		{
			_ = ((sbyte[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
			/*Error near IL_0001: Read out of bounds.*/;
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x03 0x9A
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("SerialNumber")]
	public string _hyT42trMGkdEbd3NQlrBtHvEQnA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x47 0x1B
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}
	}

	private _a58Mjdh3MgRj03uqoU8duoLFDGA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}
}
