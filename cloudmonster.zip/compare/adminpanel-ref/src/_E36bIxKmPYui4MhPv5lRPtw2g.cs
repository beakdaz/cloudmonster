using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _E36bIxKmPYui4MhPv5lRPtw2g : INotifyPropertyChanged, _6dtVmsdt1s30i5sdGYKOQK2KfHD
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _jr0dAHD9kNMn8NCor16bTkcLdiC
	{
		public static readonly _jr0dAHD9kNMn8NCor16bTkcLdiC _003C_003E9;

		public static Func<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d, Guid> _003C_003E9__15_0;

		static _jr0dAHD9kNMn8NCor16bTkcLdiC()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE4
		}

		public _jr0dAHD9kNMn8NCor16bTkcLdiC()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal Guid _6BKo4faC5aHAZW8ltcW3bi9yiOt(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}
	}

	private readonly object _5C1OnHFLMY7jrPOfUkQtdvdSOCE;

	private readonly List<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d> _wSpL6IMX5BrdztlLPxz8oJF5zEj;

	private int _egRNXJVq64uoMQ6OLecGLEsBigG;

	private int _i4a0Arhs8gdQ7L1wwyzRKkJeNrG;

	[CompilerGenerated]
	private PropertyChangedEventHandler _z3AhFEA6ZqXlGSFrZ8X3z8BQncC;

	public int Current
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}
	}

	public bool IsEmpty
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD8
		}
	}

	public int Count
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB8
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0F 0x99
		}
		[CompilerGenerated]
		remove
		{
			/*Error: Unknown opcode: 0xF5*/;
		}
	}

	public void _hNNor7qU8jzR9dZM9zJzDxTmTRd(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		if ((int)/*Error near IL_0002: Stack underflow*/ != 0)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0002: Unknown opcode: 0xC7*/;
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._hNNor7qU8jzR9dZM9zJzDxTmTRd(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _hNNor7qU8jzR9dZM9zJzDxTmTRd
		this._hNNor7qU8jzR9dZM9zJzDxTmTRd(P_0);
	}

	public void _SEPoZ1xBSyOgFjtGxo4pDlYitdL(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		if ((int)/*Error near IL_0002: Stack underflow*/ != 0)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0002: Unknown opcode: 0xC7*/;
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._SEPoZ1xBSyOgFjtGxo4pDlYitdL(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _SEPoZ1xBSyOgFjtGxo4pDlYitdL
		this._SEPoZ1xBSyOgFjtGxo4pDlYitdL(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _MUBdjNXCBFoE0kpV8M9gDph3Mwj(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0F 0xBC
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._MUBdjNXCBFoE0kpV8M9gDph3Mwj(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _MUBdjNXCBFoE0kpV8M9gDph3Mwj
		this._MUBdjNXCBFoE0kpV8M9gDph3Mwj(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _try5vwTmAHzwoXVYW9gYEPJ1oMe(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x8F
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._try5vwTmAHzwoXVYW9gYEPJ1oMe(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d[] P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _try5vwTmAHzwoXVYW9gYEPJ1oMe
		this._try5vwTmAHzwoXVYW9gYEPJ1oMe(P_0);
	}

	public bool _sqPyBgKQDukbMCUWmksA1FgD5waA(out _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x43 0xD0
	}

	bool _6dtVmsdt1s30i5sdGYKOQK2KfHD._sqPyBgKQDukbMCUWmksA1FgD5waA(out _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _sqPyBgKQDukbMCUWmksA1FgD5waA
		return this._sqPyBgKQDukbMCUWmksA1FgD5waA(out P_0);
	}

	public void _n7WDunegbRYqu1M2NPHesKvL4mG()
	{
		/*Error: Unknown opcode: 0xAB*/;
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._n7WDunegbRYqu1M2NPHesKvL4mG()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _n7WDunegbRYqu1M2NPHesKvL4mG
		this._n7WDunegbRYqu1M2NPHesKvL4mG();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _qRdFlCSYKfluRgLUjieaObAJw2f()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._qRdFlCSYKfluRgLUjieaObAJw2f()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _qRdFlCSYKfluRgLUjieaObAJw2f
		this._qRdFlCSYKfluRgLUjieaObAJw2f();
	}

	protected virtual void _rIyM7anFSgcDzLC5j2AuaUf03KP(string P_0 = null)
	{
		/*Error: Invalid metadata token*/;
	}

	public _E36bIxKmPYui4MhPv5lRPtw2g()
	{
		/*Error: Unknown opcode: 0xC4*/;
	}

	static void _200C_200B_200D_200B_206E_206C_206A_206C_206C_206B_200E_206B_206B_206C_206F_202A_200C_202A_200B_202A_206E_206B_202C_200E_202D_206A_206F_206E_200D_206A_206B_206E_200D_202A_202D_202B_206F_206D_206B_202C_202E(object P_0, ref bool P_1)
	{
		checked
		{
			_ = (short)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Invalid metadata token*/;
		}
	}

	static void _202B_200D_202D_202B_206A_200E_206E_202A_206A_202C_206D_200F_200D_200C_202A_200E_200E_206B_202D_206D_206E_206D_206F_206A_202D_202B_200E_206E_206B_202B_202C_200B_206A_202D_200B_200E_202A_200C_206D_202E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8F 0xE3
	}

	static int _202D_202D_202C_206B_200D_200F_200E_206E_206A_206C_206F_200E_200D_206B_206D_200E_206C_206B_202B_202A_200F_200F_202B_206A_202D_206C_206E_200B_200E_202B_206A_200F_200B_206F_202A_202E_202C_202B_206C_206B_202E(ref int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}

	static bool _200D_206D_206E_206A_206B_200E_200E_206D_200B_200C_200C_206B_202D_200F_206A_202E_202D_200C_202C_206F_202C_206F_202B_206B_202B_200E_200C_200E_206C_202B_206F_202A_200F_206C_200C_200D_206D_206E_200E_202D_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x03
	}

	unsafe static void _200F_202E_200F_202B_202C_206C_206A_206A_206D_206A_200E_202E_200B_202D_200F_202B_202C_202C_206B_200C_200E_200E_202A_202B_202C_200F_206F_206D_200F_200B_202B_200F_200E_206F_200F_200C_206B_200D_206A_202A_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}

	static void _200E_200E_206A_200E_206C_206D_202E_200F_202A_206A_206A_200B_202D_206B_202C_202E_200F_202A_206E_200F_202D_206D_206D_200B_200F_202C_206E_202B_206C_200E_202A_206F_202D_206B_200E_200D_202C_202A_206D_202C_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x88
	}

	static int _202E_202C_206C_200D_202C_202A_200E_200E_206E_202C_202B_206C_206D_206A_206D_206A_206F_202D_200B_206A_200B_200F_206E_202A_200D_206F_200B_206A_206C_206B_206D_200C_202A_206F_202B_206D_206C_202D_202D_202D_202E(ref int P_0, int P_1)
	{
		//IL_0007: Expected O, but got I
		if (/*Error near IL_0005: Stack underflow*/ <= /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = ((Array)checked((nuint)/*Error near IL_0006: Stack underflow*/)).LongLength;
		/*Error near IL_0007: Unknown opcode: 0xBB*/;
	}

	static Delegate _206B_200C_206B_206D_200C_206D_202D_202D_202A_206B_206A_202E_206B_200E_202D_202A_202E_202E_206F_200E_206B_200D_200B_206E_200F_206A_200B_206E_200B_200C_202A_202A_200C_202D_200C_200F_206B_206F_202D_200D_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2F 0x7B
	}

	static Delegate _202A_200E_202D_200D_206A_206F_202D_200B_202E_202E_200D_206A_200D_206B_202A_206E_206A_202C_200D_200C_206C_200B_202A_206F_202D_202B_200C_202E_206D_202B_206B_200D_202E_206D_202E_206C_206A_202A_206F_200D_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF7 0xE3
	}

	static PropertyChangedEventArgs _206C_202B_206B_206E_202E_200D_206D_200F_202D_200F_200C_200C_206A_206F_200C_202C_202E_202B_206B_200F_206E_206F_206D_206B_206C_206A_206B_202C_206F_206A_206D_202A_200D_200B_202C_206E_206D_200E_200B_206C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x10
	}

	static object _202A_206B_206D_202C_202B_206C_206C_206F_206E_202B_206C_202E_202A_206B_202A_202A_200F_206D_200B_206D_206C_202A_200D_202D_200C_200D_202C_202C_202A_202E_206F_200C_206D_200B_202C_202D_200F_206A_200F_200D_202E()
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x13625B0A
	}
}
