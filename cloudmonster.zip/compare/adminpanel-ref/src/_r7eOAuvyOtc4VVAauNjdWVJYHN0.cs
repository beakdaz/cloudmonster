using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _r7eOAuvyOtc4VVAauNjdWVJYHN0 : INotifyPropertyChanged
{
	[CompilerGenerated]
	private PropertyChangedEventHandler _z3AhFEA6ZqXlGSFrZ8X3z8BQncC;

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD9
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE9
		}
	}

	protected virtual void _LAJeXA4CZgUIESVXUriGPGdDcfQA([CallerMemberName] string P_0 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x00
	}

	public _r7eOAuvyOtc4VVAauNjdWVJYHN0()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static Delegate _200C_206D_200B_206D_206F_200B_202C_202D_202D_202A_206B_202C_202A_200D_206A_202D_206A_206B_206C_206B_200E_202D_206F_206B_202A_202C_202E_202A_206E_206D_202D_200C_200E_202A_200D_206D_206F_200B_200D_202D_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2F 0x7B
	}

	static Delegate _200F_206E_206E_200B_206C_200E_200D_206E_206D_200D_200C_206D_206B_202B_206C_206F_206A_200C_202C_202C_206F_200B_200E_206B_202E_200C_206F_200B_200F_200C_206B_202C_202C_200D_206C_206A_200D_200F_206C_206C_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF7 0xE3
	}

	static PropertyChangedEventArgs _200B_206F_202A_206B_206D_206C_202B_206E_202C_200D_202A_200F_200C_206C_206C_200B_202B_206B_200B_206F_200F_206C_206F_202B_202A_200B_206F_206D_202D_200C_200E_206F_206E_200D_206E_202A_200B_202A_200B_206B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x10
	}
}
