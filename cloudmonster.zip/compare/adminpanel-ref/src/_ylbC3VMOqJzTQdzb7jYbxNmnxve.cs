public interface _ylbC3VMOqJzTQdzb7jYbxNmnxve
{
	string _tLkb1vTk9XEGoGf4Sac02vo4V5b { get; }

	int _r48uVlmApDzNRTCsJ277gBhrBaJ { get; set; }

	int _OHUEWHxOAqkkLTlPhgek38NJD6A { get; set; }

	bool _gHMAm9Wc4g3ZVpouUthFjfB6WMo(string P_0);

	string _JcA5cTOIzYiIo3H3fG6PU4hBVnt();
}
