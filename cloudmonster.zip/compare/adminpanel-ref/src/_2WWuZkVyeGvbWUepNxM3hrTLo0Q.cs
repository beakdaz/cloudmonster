using System;
using System.Runtime.CompilerServices;

[AttributeUsage(AttributeTargets.Property)]
public sealed class _2WWuZkVyeGvbWUepNxM3hrTLo0Q : Attribute
{
	[CompilerGenerated]
	private readonly string _hS7x8eJzrT2e97dMPp9AlrBBCpo;

	[CompilerGenerated]
	private bool _l5E9j47klt0opHslaY9wSMGbgxM;

	[CompilerGenerated]
	private bool _MjXuXJScyaKrjYrD98G0Pi2jmt6;

	public string _IlvHxFPQ0jBSV5UQMIuBctJoY4W
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA5
		}
	}

	public bool _ouek40mfEZcKAiuBOCraP5DTnRQ
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5B 0xCE
		}
		[CompilerGenerated]
		set
		{
			/*Error: Invalid field token*/;
		}
	}

	public bool _iQXDdbL1WVTLjaCAiHBR5kPilK5
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7D
		}
		[CompilerGenerated]
		set
		{
			((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (IntPtr)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xE5*/;
		}
	}

	public _2WWuZkVyeGvbWUepNxM3hrTLo0Q()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD9
	}

	public _2WWuZkVyeGvbWUepNxM3hrTLo0Q(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x47 0x0A
	}
}
