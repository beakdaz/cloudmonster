using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Markup;

[DebuggerNonUserCode]
[GeneratedCode("PresentationBuildTasks", "7.0.10.0")]
[EditorBrowsable(EditorBrowsableState.Never)]
public sealed class _XGUld3KiFEfau0ovJT3J9I5AEQCA : InternalTypeHelper
{
	protected object _VSIctdREWcHL2lglK2XMYFtxDo4(Type P_0, CultureInfo P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x57 0x7F
	}

	protected object _aqzgTZSN1Phbd2CQIg4cg80Yfit(PropertyInfo P_0, object P_1, CultureInfo P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9C
	}

	protected void _RP2qt7Jqm6BydKP4FxdgrD1R5Zf(PropertyInfo P_0, object P_1, object P_2, CultureInfo P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x58
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected Delegate _A0QNeuGhCMp3phgccZ1mFZLiPAS(Type P_0, object P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x18
	}

	protected void _Rbfd7ua8Dto3IRuM0a6yV6TWYmq(EventInfo P_0, object P_1, Delegate P_2)
	{
		/*Error: Unknown opcode: 0xF8*/;
	}

	public _XGUld3KiFEfau0ovJT3J9I5AEQCA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static object _200F_206F_200D_200D_206E_200E_206C_202A_202C_206C_206E_200D_202D_202D_206B_206A_202E_206D_206B_206B_206B_200E_202E_206F_206D_206F_206A_200B_202E_200C_206F_202C_200C_202B_200C_200E_206A_202B_206B_206D_202E(Type P_0, BindingFlags P_1, Binder P_2, object[] P_3, CultureInfo P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x78
	}

	static object _202C_206C_206B_202A_200B_202D_206F_202B_206D_202B_206C_200B_206C_206B_200F_200F_202D_206E_206D_200C_200E_202C_200D_200D_202E_200D_200B_202C_200E_200C_202A_202E_206C_202C_200F_202D_202B_206A_200E_202E_202E(PropertyInfo P_0, object P_1, BindingFlags P_2, Binder P_3, object[] P_4, CultureInfo P_5)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x67 0xA1
	}

	static void _202E_206D_202E_200E_202E_202B_202B_202B_206E_202C_202B_202C_200D_206F_206F_202B_200E_202B_200C_206A_200B_200C_206F_206C_206E_200B_206A_200C_206C_206F_206E_206A_202B_200C_200B_202A_206D_202E_206F_202C_202E(PropertyInfo P_0, object P_1, object P_2, BindingFlags P_3, Binder P_4, object[] P_5, CultureInfo P_6)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static Type _202E_206B_200F_206C_206B_202A_202C_202E_202E_200E_202C_206E_202A_202E_200B_202E_200B_206E_200F_202D_200F_200E_202A_206E_206E_206C_200E_200C_202B_202B_200F_202A_200C_200F_202C_206A_200E_200F_200C_206C_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xFB*/;
	}

	static object _200D_202D_202E_200B_200E_202B_206B_206B_202C_202C_200B_200D_200F_202B_206C_202D_206E_206E_202D_200D_206E_200C_202C_200F_200D_206B_202C_202D_206E_202A_200B_206B_206D_202A_200D_206B_206C_206B_202E_206D_202E(Type P_0, string P_1, BindingFlags P_2, Binder P_3, object P_4, object[] P_5, CultureInfo P_6)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5F 0x0D
	}

	static void _202C_206E_202E_206F_200D_206B_200F_202D_206E_206E_202B_206C_206B_206E_202E_200C_202D_206A_206F_206E_206F_206A_202D_200E_202B_202D_200F_202C_202D_200E_206D_202B_202C_200C_202C_206C_200D_200C_206D_200D_202E(EventInfo P_0, object P_1, Delegate P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBF 0x1B
	}
}
