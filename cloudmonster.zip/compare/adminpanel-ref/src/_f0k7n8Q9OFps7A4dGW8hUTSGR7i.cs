using System;
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;

internal static class _f0k7n8Q9OFps7A4dGW8hUTSGR7i
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _h1BuZnHqSXH2C54hCYO5i5yk6sd<_0001>
	{
		public static readonly _h1BuZnHqSXH2C54hCYO5i5yk6sd<_0001> _003C_003E9;

		public static Func<_0001, Guid> _003C_003E9__1_0;

		static _h1BuZnHqSXH2C54hCYO5i5yk6sd()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x73 0x27
		}

		public _h1BuZnHqSXH2C54hCYO5i5yk6sd()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal Guid _pk2Qz23A7zR6CXfWeu18obISmCO(_0001 P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}
	}

	public static void _Gx5uI00AAQZOdppNJi7FO1MQYyW<_0001>(this ConcurrentQueue<_0001> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBC
	}

	public unsafe static void _n7WDunegbRYqu1M2NPHesKvL4mG<_0001>(this ConcurrentQueue<_0001> P_0)
	{
		_ = *(sbyte*)(nint)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Not a type handle*/;
	}

	public static bool _JbardCaaFGKsHaUhl0ByJrxMO7u(this string P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xEF*/;
	}

	static int _202A_206A_206F_200E_202B_202A_200C_202B_200E_206F_206C_206F_202A_206C_200F_202C_206D_206E_206A_206F_206B_206F_206D_202A_202E_206B_206B_200B_202E_206A_200D_200D_200C_206A_200B_206C_200D_200F_206C_206D_202E(string P_0, string P_1, StringComparison P_2)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0001: Stack underflow*/& /*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Unknown opcode: 0xED*/;
	}
}
