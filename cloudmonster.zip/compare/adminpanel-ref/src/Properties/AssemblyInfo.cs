using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Windows;

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyCompany("AdminPanel")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("AdminPanel")]
[assembly: AssemblyTitle("AdminPanel")]
[assembly: AssemblyVersion("1.0.0.0")]
[module: _CX7aMIwe0k49FlwyALPtEnuWYqP(11)]
