using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_NetworkAdapter")]
public sealed class _6sVLI807UQETwYjU8f33xYHYscG : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _cZEpYHixuQeIG8UI3CybmhXpD8q;

	[CompilerGenerated]
	private string _kuvA6FWK0DhATZf9TCQY28FgavaA;

	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _I0vaHOuhw0CAW6uSA0DqIwES8FX;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _E1xP366vKefBNNaAEtSfTdPOPZX;

	[CompilerGenerated]
	private string _zfNmYp5zxweI9RuaMZERICyevQn;

	[CompilerGenerated]
	private string _P2teFQjUF0Gwbu9vuj5yBrGXPCh;

	[CompilerGenerated]
	private ushort _hb3sqTPOyTmHSDVBNXrJ3omym5L;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("MACAddress", _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true)]
	public unsafe string _BZJbWn1MLUYOBarKVxaaG8h343I
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x71
		}
		[CompilerGenerated]
		set
		{
			//IL_0004: Expected I8, but got I4
			if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			*(long*)(nint)/*Error near IL_0004: Stack underflow*/ = (int)(byte)/*Error near IL_0003: Stack underflow*/;
			checked
			{
				_ = (byte)/*Error near IL_0005: Stack underflow*/;
				/*Error near IL_0005: Unknown opcode: 0xFF*/;
			}
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("PNPDeviceID", _ouek40mfEZcKAiuBOCraP5DTnRQ = true, _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true)]
	public string _73yocnM47xmu5tgeXKmP95jZcZA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9C
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1F 0xEA
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name")]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA5
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Caption")]
	public string _WVZCeL07h3KQ3QyLtbqAFyMsWVW
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE5
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x79
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD8
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x97 0x1E
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("ProductName")]
	public string _aRx7SVal0pXMrmBzjKLjqQt9CfD
	{
		[CompilerGenerated]
		get
		{
			/*Error: Read out of bounds.*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1C
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("ServiceName")]
	public string _ti4OMGUCGrivtwUcGKjMQpECi8aA
	{
		[CompilerGenerated]
		get
		{
			/*Error: Not a type handle*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x79
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Manufacturer")]
	public string _x9LQFtjAmgtdxpWocRgMLYM03Wz
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA0
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1B 0x63
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("AdapterTypeId")]
	public ushort _tmtX86acBqJRBBfC7ukFpxCLdjXA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE9
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE1
		}
	}

	protected override bool _XUDlD5OKhFe8yOU6UqXNbLmod9D
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x08
		}
	}

	private _6sVLI807UQETwYjU8f33xYHYscG()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}

	static bool _200E_206F_202E_206F_206C_200C_206A_206B_202D_206A_200F_200D_202D_200F_200F_200E_206E_200E_202B_200D_200B_200E_200C_206A_202B_206A_202C_206F_206A_200F_202A_202B_200F_206A_202C_200C_202E_202E_206F_206E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}
}
