using System;
using System.Runtime.CompilerServices;

internal class _TqYWirMEGd9eBzFBbHGDuN4hT25 : _AixgjHMRszOaPQS7i2aBc3qDrCc<int>
{
	[MethodImpl(MethodImplOptions.NoInlining)]
	public int _lDAGfFn8AH4KeIcDk2MM5uRBKbJ()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAC
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public int _NEFB1ZpblWbgvYu9DqhNv2a5AzvA()
	{
		/*Error: Unknown opcode: 0xE3*/;
	}

	[SpecialName]
	public static _TqYWirMEGd9eBzFBbHGDuN4hT25 _FTokbVj8XQxEgROkdF0y90Y7NXF(_TqYWirMEGd9eBzFBbHGDuN4hT25 P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}

	[SpecialName]
	public static _TqYWirMEGd9eBzFBbHGDuN4hT25 _M0yNBzeLMIaEaIYBayI2yffNWSC(_TqYWirMEGd9eBzFBbHGDuN4hT25 P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x41
	}

	[SpecialName]
	public static bool _T0Db87Upbtb37Lc0WXiPtvMWXiC(_TqYWirMEGd9eBzFBbHGDuN4hT25 P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x00
	}

	[SpecialName]
	public static bool _0A2zA6FIhkOSlsOCKmzkREAW7NMA(_TqYWirMEGd9eBzFBbHGDuN4hT25 P_0, int P_1)
	{
		/*Error: Unknown opcode: 0xC7*/;
	}

	protected unsafe bool _1i8hQdhaFXFJiAFCkS5pDg25Tm6(_TqYWirMEGd9eBzFBbHGDuN4hT25 P_0)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		_ = /*Error near IL_0004: Stack underflow*// checked((sbyte)unchecked((nuint)(nint)((IntPtr[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/]));
		_ = *(uint*)(int)checked((ushort)/*Error near IL_0004: ldloc 0 (out-of-bounds)*/);
		/*Error near IL_0007: Invalid branch target*/;
	}

	public virtual bool _1i8hQdhaFXFJiAFCkS5pDg25Tm6(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x47 0x80
	}

	public virtual int _6Vqzq2u1Bn2iVnKhMXeTF4WkbFj()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x24
	}

	public _TqYWirMEGd9eBzFBbHGDuN4hT25()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x03 0xF2
	}

	static int _200E_200D_202A_200E_202A_200B_206E_200C_202B_200D_200D_202C_200C_206A_200B_206E_200E_200B_200D_202C_206B_202B_200D_202B_206A_206E_200B_206C_206D_200F_200E_200F_200D_206D_202B_206D_200F_200F_206F_206A_202E(ref int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}

	static int _206D_202E_202D_206A_202B_200E_206B_202C_206C_206E_200F_206C_202B_200E_206C_200E_206B_200C_202C_200B_200C_206E_202D_202D_200D_200B_200E_200C_206D_200C_202A_200D_202B_202B_206F_206F_202E_200C_202C_200F_202E(ref int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	static Type _200C_200D_200F_206A_200D_202C_206F_200B_206D_206E_206B_206B_202E_202B_200D_206E_200C_200D_202A_202C_200D_202C_206D_206B_200E_206B_202E_206F_206A_206B_206E_202A_200F_202D_206B_202A_200D_200B_206C_200D_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xFB*/;
	}

	static Type _200B_202E_200D_202A_206A_200C_200E_206C_206F_206C_206A_206F_202B_206B_200F_200E_206F_206E_202D_206F_206C_206B_200C_206B_206A_200E_206B_206B_200E_206E_200E_206D_200D_206D_202C_202E_206C_202D_206E_202E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	static bool _200E_206D_200D_206A_206E_206D_200C_200E_200B_200E_206B_206F_206E_202D_206D_202A_202D_202B_200C_206F_206C_206B_202C_202C_200E_206E_200E_200B_200E_200D_202A_200E_202A_200D_202B_206D_200D_200E_202E_200D_202E(Type P_0, Type P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}
}
