using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_VideoController")]
public sealed class _KON64vmS3jrPrPMe7FHgR0ybDOn : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _kuvA6FWK0DhATZf9TCQY28FgavaA;

	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _I0vaHOuhw0CAW6uSA0DqIwES8FX;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _EFW8o2XwNYKrvDVb1NkDQTR6Yvm;

	[CompilerGenerated]
	private string _8Fh4l7MnQOkOyzwSSeuCsdnccrH;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("PNPDeviceID", _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true)]
	public string _73yocnM47xmu5tgeXKmP95jZcZA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD7 0x43
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x39
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name", _ouek40mfEZcKAiuBOCraP5DTnRQ = true, _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true)]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA5
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x38
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Caption")]
	public string _WVZCeL07h3KQ3QyLtbqAFyMsWVW
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xF3*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE3 0xEA
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			return (string)/*OpCode not supported: Nop*/;
		}
		[CompilerGenerated]
		set
		{
			/*Error: Metadata token must be either a methoddef, memberref or methodspec*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("VideoProcessor")]
	public string _KZJPDWKJabNRfwhE0y5DkF9Lf2DA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE4
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD7 0x53
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("AdapterCompatibility")]
	public string _h3oQsKhhq3NOQS4YSgv0UtRJ4Sh
	{
		[CompilerGenerated]
		get
		{
			checked
			{
				_ = (short)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xC7*/;
			}
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x59
		}
	}

	protected override bool _XUDlD5OKhFe8yOU6UqXNbLmod9D
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x59
		}
	}

	private _KON64vmS3jrPrPMe7FHgR0ybDOn()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}

	static bool _202C_202B_200C_206A_200B_206B_200D_200D_206D_200C_206F_200F_206B_202D_202A_200E_200B_202A_206E_202D_206C_202D_206A_206E_206B_200C_202C_202D_202A_200C_202C_206F_202B_202D_202B_200D_200B_200E_202D_202E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}
}
