using System;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

internal class _mCCr8GLiyOBl6QpfsKCpYO4fgji : _r7eOAuvyOtc4VVAauNjdWVJYHN0
{
	private class _XSoI6A9XkKtbLcEgjRN0MpRvA6E : JObject
	{
		public _XSoI6A9XkKtbLcEgjRN0MpRvA6E()
		{
			checked
			{
				_ = (short)/*Error near IL_0001: Stack underflow*/;
			}
			_ = (ushort)/*Error near IL_0004: Stack underflow*/;
			/*Error near IL_0004: Unknown opcode: 0xB1*/;
		}

		private _XSoI6A9XkKtbLcEgjRN0MpRvA6E(JObject P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x74
		}

		public void _N22sPG49HPAe3brTAATQpJSFdIt(Stream P_0)
		{
			/*Error: Invalid branch target*/;
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		public static _XSoI6A9XkKtbLcEgjRN0MpRvA6E _6WZ5GvI63H8amYOZ9Njqm0Cw01c(Stream P_0)
		{
			_ = ((short[])/*Error near IL_0006: Stack underflow*/)[134217610f];
			/*Error near IL_0006: Invalid metadata token*/;
		}

		static Encoding _202D_200C_200E_206D_200D_200F_206E_202B_200D_202C_200D_206B_200B_202A_200B_206F_202D_202E_206E_202D_202B_202A_200B_200D_200F_202C_200C_206E_206E_202D_206C_206E_202C_206B_206C_202A_202D_206B_202E_206A_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE9
		}

		static string _200D_200D_200B_200C_206A_206F_206D_206B_206B_202E_202B_200F_202E_206C_202D_206A_206C_200C_200C_206B_200B_202D_202E_206F_202E_206D_202B_200C_202E_200E_206F_202D_200F_202C_206E_200B_206C_200C_206B_200F_202E(JToken P_0, Formatting P_1, JsonConverter[] P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB8
		}

		static byte[] _202B_206B_206D_202B_202B_206F_202E_202A_206A_200E_202B_202A_202C_202B_200C_200C_206A_200C_206C_206D_202C_202B_202D_202E_200D_206B_206B_202D_206C_206C_202D_200D_202C_200C_206E_202A_202B_202A_200F_206A_202E(Encoding P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC5
		}

		static byte[] _202E_200D_206D_202D_206C_200B_206B_202E_206E_206E_202E_206C_206C_202E_206F_206F_200F_200C_200C_202B_206E_202B_202C_200B_200D_202A_202A_200C_200F_202C_200C_202E_202C_202A_200B_200D_206E_206C_206D_206D_202E(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x94
		}

		static void _206A_202A_200F_206F_200C_202C_206F_200D_206D_202B_206C_202E_206D_206E_206D_202E_200F_202C_206E_206C_206B_202B_206E_206D_200F_200D_200F_200F_206A_202E_206B_200B_206E_202A_202D_206A_200D_202A_200E_202D_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
		{
			_ = ((Array)/*Error near IL_0001: Stack underflow*/).LongLength;
			/*Error near IL_0001: Invalid metadata token*/;
		}

		static int _200E_202A_206B_206F_200B_202A_206A_202B_202C_202C_206C_200C_206C_206B_200F_202D_206A_202E_206E_206A_202D_200D_202C_206C_200E_206C_200B_202B_206E_206D_200B_206B_202A_206C_202B_206C_206C_206C_206D_206A_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x08
		}

		static int _202A_206B_202E_206E_200C_206A_206E_206A_202D_202E_206F_206B_206E_200C_202A_206F_206E_200E_206C_202C_202E_200E_200C_202C_200D_200E_206A_200F_206D_202B_202B_206A_202E_202B_202A_202C_202A_206C_202C_206C_202E(byte[] P_0, int P_1)
		{
			((float[])/*Error near IL_000a: Stack underflow*/)[/*Error near IL_000a: Stack underflow*/] = float.NegativeInfinity;
			_ = (ulong)/*Error near IL_000b: Stack underflow*/;
			/*Error near IL_000b: Unknown opcode: 0xAE*/;
		}

		static Exception _206E_206B_202A_206C_202A_202D_206C_206A_202E_206A_206B_206A_206D_206B_202D_200C_200B_202A_206B_200C_202B_202D_206F_202C_206F_200B_206E_200C_200E_200E_200B_200C_202B_200D_202A_206C_200E_202C_200C_202E_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5D
		}

		static string _200B_200C_202C_202C_206B_206D_200E_206A_202B_202B_200B_200B_206A_200E_206C_200C_200F_206E_200B_202B_202B_206E_206E_202C_200C_202C_206C_200F_202E_206C_200F_200E_202C_206A_206C_202B_206D_206A_202E_206E_202E(Encoding P_0, byte[] P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEC
		}

		static JObject _202B_202D_200F_206B_202B_206F_202A_206D_202E_202B_202E_206F_206B_200F_206D_206E_206D_206A_200F_200C_200C_202C_202C_206F_200E_200B_206C_200E_202B_206D_202C_200F_206F_206C_200D_206A_200E_202B_200E_202D_202E(string P_0)
		{
			long num = (long)/*Error: ldarg 2 (out-of-bounds)*/;
			if (num < num)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0005: Not a type handle*/;
		}
	}

	[CompilerGenerated]
	private static class _0t49n2FnzT00IKUAFA5HJoyNtsF
	{
		public static RemoteCertificateValidationCallback _8kXMRkWdXNAZC7DuMc5Dx19jpue;
	}

	[CompilerGenerated]
	private sealed class _CKtB1Bn0zNgIYjIcEwx4n51zCZe
	{
		public string _eqGMfd7AbGvKZUfA8LYN1SbSfAIA;

		public _CKtB1Bn0zNgIYjIcEwx4n51zCZe()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal void _c1jq0mMXcDpiWviDBj1fD3bHlnl()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD3 0xDF
		}

		static void _200E_200B_206F_200E_206E_206C_202A_206F_206A_206B_206B_200D_202C_202E_206E_202C_202C_202C_206A_200E_206B_202A_206B_202D_206A_206B_200E_202E_202A_200D_200B_206B_202B_200C_200D_206B_206D_202A_206A_202E_202E(string P_0)
		{
			/*Error near IL_0001: stloc 0 (out-of-bounds)*/;
			/*Error near IL_0002: Read out of bounds.*/;
		}
	}

	private TcpClient _0ljofHlyQAcLGF26cJZzCNdeVRM;

	private Stream _EckrSco8gbVAHEpXPP9utj2RxFb;

	[CompilerGenerated]
	private bool _R62DBsZRzCNrnLyCbq25G0kBGuL;

	[CompilerGenerated]
	private object _gVwCW82q9roG4PqNkNLrY5iAhub;

	[CompilerGenerated]
	private Visibility _4KnKNjzyvRZmyyoHX2KKFgHswxf;

	protected bool IsAuthentificated
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEC
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}
	}

	public object BusyAnimation
	{
		[CompilerGenerated]
		get
		{
			_ = (double)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0x78*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAD
		}
	}

	public Visibility IsBusy
	{
		[CompilerGenerated]
		get
		{
			if (/*Error near IL_0005: Stack underflow*/ < /*Error near IL_0005: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			_ = ((uint[])/*Error near IL_0006: Stack underflow*/)[/*Error near IL_0006: Stack underflow*/];
			/*Error near IL_0006: Unknown opcode: 0xC9*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			if (/*Error near IL_0002: Stack underflow*/ <= /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			_ = /*Error near IL_0003: Stack underflow*// /*Error near IL_0003: Stack underflow*/;
			/*Error near IL_0003: Unknown opcode: 0xA6*/;
		}
	}

	protected _mCCr8GLiyOBl6QpfsKCpYO4fgji()
	{
		checked
		{
			_ = (uint)unchecked((long)checked((ulong)/*Error near IL_0001: Stack underflow*/));
			/*Error: End of method reached without returning.*/;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private void _dueguIISjrxvFVEad3ofxbrmjAz()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0xB6
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private _XSoI6A9XkKtbLcEgjRN0MpRvA6E _hRq6xF1xkx2NarYbWqfzOfJUojB(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x03 0x7D
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static bool _KX2VMMnUo7BTRAUIYCCmdT5xyNe(object P_0, X509Certificate P_1, X509Chain P_2, SslPolicyErrors P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x01
	}

	static bool _206D_200D_206C_200D_206C_206F_206C_200D_206E_202A_200E_200E_202E_202C_202E_202D_206A_200D_200E_202B_200D_206C_202D_202D_202A_200F_202E_206B_200C_200C_202A_200C_206E_206A_206F_202A_202E_206F_200D_202A_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}

	unsafe static TcpClient _200D_200E_200B_206E_200F_202C_202B_200E_206D_202E_206F_200B_200E_206C_206A_202D_206E_206C_206C_202B_202D_202E_202D_202E_200B_202E_206F_206D_202B_206B_206E_206D_202B_206A_200C_202C_200E_202D_200C_200E_202E()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Expected I, but got Unknown
		((int[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (int)/*Error near IL_0001: Stack underflow*/;
		*(IntPtr*)(nint)/*Error near IL_0004: Stack underflow*/ = (IntPtr)(/*Error near IL_0003: Stack underflow*/ >> (int)(ushort)/*Error near IL_0002: Stack underflow*/);
		/*Error near IL_0004: Metadata token must be either a methoddef, memberref or methodspec*/;
	}

	static void _202D_202C_206D_206D_206D_200F_202A_200B_202B_200F_206E_202C_200F_200E_202E_206C_202B_202A_202D_202A_202D_202C_200E_206B_202A_200D_202C_200E_206C_200C_200E_206E_206D_200E_206A_206D_200E_206F_206E_206E_202E(TcpClient P_0, string P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static NetworkStream _206A_202A_202A_206C_206C_206F_200D_202B_202C_206D_206A_206C_206C_206D_206F_200E_200C_206A_200E_200E_202B_206E_206E_206C_202A_200B_200D_206F_202B_200E_200D_206C_200C_202A_202B_200F_200B_206B_200E_206D_202E(TcpClient P_0)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static SslStream _200F_206C_202D_206C_206D_200F_200F_202B_206D_200F_200F_202B_202A_206F_200D_200D_206A_202D_202E_206C_206B_200E_206C_206F_202A_200F_202D_200D_202D_200B_202A_202A_206C_206F_200E_206D_206F_206F_206D_202E(Stream P_0, bool P_1, RemoteCertificateValidationCallback P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	static void _200B_206D_200E_206E_206D_200E_200D_200F_200F_206D_206D_202B_206A_206F_200E_200E_206D_206D_202D_202C_202A_206C_200E_202B_202C_200E_206D_206A_202A_200D_206E_200C_206F_200D_202C_206E_202A_200F_206D_202E_202E(Stream P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x79
	}

	static void _206B_206C_200B_202B_200E_206C_202D_202D_206B_202B_206E_200C_202A_200F_202B_202D_202D_200D_202C_200C_206F_200D_202D_206A_202C_200E_206D_206A_206A_200F_202D_200B_206B_206D_200F_200C_206D_200C_202D_202C_202E(Stream P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x08
	}

	unsafe static void _202A_202A_200E_206A_200E_200D_202E_200D_200F_202E_206D_206D_200B_206A_202B_200E_202A_206E_206F_206E_200E_200F_206A_206A_206B_202A_202C_202A_202A_202B_202D_206F_206E_200D_200C_202A_202C_206F_200C_206F_202E(SslStream P_0, string P_1, X509CertificateCollection P_2, SslProtocols P_3, bool P_4)
	{
		if (/*Error near IL_0002: Stack underflow*/ == /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		*(_003F*)(nint)/*Error near IL_0003: Stack underflow*/ = /*Error near IL_0003: Stack underflow*/;
		/*Error near IL_0003: ldloc 0 (out-of-bounds)*/;
		/*Error near IL_0004: Unknown opcode: 0xC0*/;
	}

	static MessageBoxResult _202B_206B_202D_202B_200F_200E_202E_206D_202C_206F_200E_206A_200E_206D_202A_202B_200D_202D_200F_202E_200E_200E_206C_206C_200D_200B_206D_206D_200B_206A_206A_206C_206C_202A_200D_206B_200F_206B_206A_206B_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static void _200F_200D_206F_202E_200E_202C_206B_206E_206C_202D_202E_200E_206D_200C_202D_200C_200B_202C_202C_200F_206A_206E_202A_206F_206C_202E_200D_206C_206F_202D_200C_206D_206F_200B_202C_200C_202C_202B_206F_202A_202E(int P_0)
	{
		/*Error: Unknown opcode: 0xC4*/;
	}

	static bool _202E_206C_202A_206F_206D_206B_200C_200F_206A_206E_200E_200C_202A_200F_200F_202C_206A_202A_206E_206A_200F_206A_202D_202E_200F_200D_202E_206C_202C_206B_202D_206C_200C_200C_206F_202A_206D_202E_206A_206E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	static void _202E_200C_200E_206E_206C_206C_206D_206E_200E_206C_200E_206E_206C_202E_200B_200B_200E_200B_202D_202B_206F_206C_202A_206C_200E_200F_206C_200B_206D_200B_200E_202D_202D_206C_200E_202E_206F_202D_206E_206B_202E(Action P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF4
	}

	unsafe static MessageBoxResult _202B_202C_206C_202B_202E_202A_206F_206E_206F_206C_200C_200E_206F_200D_200C_206C_206B_200E_202B_200E_200B_200F_206D_200D_200D_206A_200C_200D_202E_206A_206B_200B_202E_202C_202E_206E_200C_202D_206E_200E_202E(string P_0, string P_1)
	{
		//IL_0002: Expected I8, but got I4
		*(long*)(nint)/*Error near IL_0002: Stack underflow*/ = (int)(uint)/*Error near IL_0001: Stack underflow*/;
		_ = ((short[])/*Error near IL_0004: Stack underflow*/)[-1];
		return (MessageBoxResult)/*OpCode not supported: Nop*/;
	}

	static MessageBoxResult _200F_202B_202B_200F_200E_206A_202D_206C_206A_202D_202A_202B_206A_202A_202A_206D_200F_200E_202D_206D_200F_202E_200C_206F_200E_200E_202C_202B_200B_200C_200F_202E_206D_200F_206D_202E_206A_200E_202E(string P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xFA*/;
	}

	static string _206D_206C_202D_202D_202C_202B_206A_206A_200E_206F_200B_200B_202E_206E_206C_202D_202D_200B_206E_200C_202C_202D_200D_206F_206A_206B_206C_206E_206D_200C_202C_206F_200B_206C_206E_206E_206A_202A_202D_202A_202E(string P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC8
	}

	static Exception _202E_206E_206D_202B_206E_200E_206B_200C_200E_206E_202D_206D_202C_200B_206D_206B_202A_200B_200E_200C_206A_200C_206C_206A_200D_200B_206F_200C_206F_206F_202B_200E_200E_206A_206D_200D_200D_202E_202C_206B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5D
	}

	static string _200D_206E_202B_202E_206B_200C_202A_206E_202C_202E_200D_206F_206B_206C_206D_206B_202B_202B_202E_202E_206D_202C_200F_206A_206E_200C_202C_206E_206D_206E_206C_206F_200D_200B_200B_206E_206D_206A_202B_206E_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x78
	}

	static string _206F_200B_200C_202A_200E_202E_200B_206A_200C_206C_206A_206D_200D_200C_206D_206F_200E_202D_206B_200F_200E_200C_206C_206A_200E_202C_206D_206B_200C_206E_206C_200D_200C_206D_200D_206A_206F_206E_202E_202E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE1
	}

	static void _200B_206E_206E_202E_206D_202E_206F_202E_200C_200B_206F_202D_206A_206A_206A_200B_200F_202E_206B_200C_202D_200B_200B_206B_206C_206E_202B_202E_202E_200D_202B_202A_200F_206F_206E_200D_206C_206B_206D_206E_202E(TcpClient P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x21
	}

	static Assembly _206B_202D_206B_202B_202B_200D_206A_200D_202D_200C_202B_200B_202B_202B_202D_206A_206F_200E_200D_200E_202E_200D_206C_206E_200B_202E_202A_200F_206A_200F_202E_206B_200F_206D_200B_206C_206E_206D_206A_202B_202E()
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xE2C04B09
	}

	static AssemblyName _206C_202B_202B_202C_206B_202B_206E_206E_206D_200E_202A_200E_200F_206D_206B_206C_202C_202B_206B_202A_206E_200D_200E_206E_202E_200E_202E_200E_202A_206B_202C_200D_200E_206D_202B_202A_200D_202C_202D_206B_202E(Assembly P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF3 0xD9
	}

	static JToken _200E_200D_200B_202D_206D_200B_202B_200C_202C_202A_202A_200B_202D_202D_206A_202C_202A_202A_200B_206C_202B_202B_202A_200F_206C_202B_202B_202C_206F_206D_200B_206C_206A_206F_200E_206D_206B_200E_202B_200D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	static void _206C_200F_202A_200C_202D_202A_206C_200C_206F_200B_206F_202C_202B_200B_206F_200D_206D_206C_200B_200F_202C_206E_200C_202C_206E_206C_206F_206E_202D_200E_202B_200E_200E_206E_202A_206E_200C_202C_200E_202D_202E(JObject P_0, string P_1, JToken P_2)
	{
		switch ((int)/*Error near IL_0019: Stack underflow*/)
		{
		default:
			/*Error: End of method reached without returning.*/;
		case 0:
			/*Error: Invalid branch target*/;
		case 1:
			/*Error: Invalid branch target*/;
		case 2:
			/*Error: Invalid branch target*/;
		case 3:
			/*Error: Invalid branch target*/;
		case 4:
			/*Error: Invalid branch target*/;
		}
	}

	static string _200C_206D_202A_206F_202D_200C_200D_202A_200F_202C_206D_206D_206D_200B_206B_206D_206B_202D_206F_200D_202C_200D_206C_202E_202C_202A_206E_202B_202E_206A_202C_200F_206A_206C_206F_206C_202C_206E_200C_200D_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xE471B71B
	}

	static Version _202D_200F_200B_206C_200C_202A_200C_202C_206A_200B_202E_206C_202A_202D_200D_206E_206E_202A_206D_206E_202E_202A_206F_206F_202A_206B_206E_202A_202D_202A_202E_200E_206D_206A_202C_206C_206B_206E_200B_206E_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x95
	}

	static string _206B_202D_200B_206F_202D_202B_206B_200F_202C_202C_206E_200E_200D_200E_206A_202C_200E_206D_200F_206D_200E_202C_200F_206F_202A_206E_200D_206E_206F_206E_206D_202B_200B_200E_200B_200F_200D_202B_202C_206F_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6C
	}

	static string _206D_200D_206B_200E_200E_200D_202C_202B_206B_206C_200D_206A_206A_206C_200C_206F_206E_202A_200C_206B_206C_206B_200C_206E_206B_200D_202D_206F_202E_206F_206A_206D_200D_200E_202B_200E_200E_206B_200D_202C_202E(X509Certificate P_0)
	{
		/*Error: ldloc 2 (out-of-bounds)*/;
		/*Error near IL_0001: Read out of bounds.*/;
	}

	static int _206C_202A_200F_200F_200B_200D_206F_200B_206A_200E_202D_206C_202A_202D_202B_202A_202A_200F_206B_202C_206C_202B_202C_206A_202E_200F_206A_202A_206C_202D_202C_200B_206A_200F_202A_202B_206F_206D_200D_202C_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x84
	}
}
