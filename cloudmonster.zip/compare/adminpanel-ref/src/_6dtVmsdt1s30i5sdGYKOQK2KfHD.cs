using System.ComponentModel;

internal interface _6dtVmsdt1s30i5sdGYKOQK2KfHD : INotifyPropertyChanged
{
	int Current { get; }

	bool IsEmpty { get; }

	int Count { get; }

	void _hNNor7qU8jzR9dZM9zJzDxTmTRd(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0);

	void _SEPoZ1xBSyOgFjtGxo4pDlYitdL(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0);

	void _MUBdjNXCBFoE0kpV8M9gDph3Mwj(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0);

	void _try5vwTmAHzwoXVYW9gYEPJ1oMe(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d[] P_0);

	bool _sqPyBgKQDukbMCUWmksA1FgD5waA(out _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0);

	void _n7WDunegbRYqu1M2NPHesKvL4mG();

	void _qRdFlCSYKfluRgLUjieaObAJw2f();
}
