using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _AixgjHMRszOaPQS7i2aBc3qDrCc<_0001> : INotifyPropertyChanged
{
	protected _0001 _VDj3b1auPf3MOEZbsLIPgMmzYMn;

	[CompilerGenerated]
	private PropertyChangedEventHandler _z3AhFEA6ZqXlGSFrZ8X3z8BQncC;

	public unsafe _0001 Value
	{
		get
		{
			//IL_0002: Expected F8, but got I4
			*(double*)(nint)/*Error near IL_0002: Stack underflow*/ = ((short[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
			checked
			{
				_ = (uint)/*Error near IL_0003: Stack underflow*/;
				/*Error near IL_0003: Unknown opcode: 0x78*/;
			}
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			/*Error: Unknown opcode: 0xCB*/;
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x33 0xAB
		}
	}

	protected void _LAJeXA4CZgUIESVXUriGPGdDcfQA(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x77 0xB0
	}

	public _AixgjHMRszOaPQS7i2aBc3qDrCc()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static bool _200E_206C_202D_200E_206C_202C_200E_206C_206E_200F_202B_206B_206B_200B_206C_206D_206E_200B_200F_206A_200D_206D_202B_206E_200D_206F_202C_206D_200C_202C_202C_202D_200D_202A_202C_200F_200B_200F_200C_206B_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}

	static Delegate _200C_202E_200C_200F_200F_200C_206E_206B_206A_206B_200E_200D_206F_200B_206E_200D_200C_200E_200C_206D_206D_206E_206A_202D_200C_200C_202A_206D_206B_202B_206E_200F_202B_202A_206D_206A_202C_200C_200B_200F_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2F 0x7B
	}

	static Delegate _202A_202C_200D_200F_202D_202E_200B_200E_200F_202E_202C_200C_200C_200E_200F_206D_200E_206D_206F_206E_200B_202C_202B_200F_206A_200F_206B_200E_206D_206E_202B_200F_202E_200E_206A_200B_206F_200E_206F_200C_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF7 0xE3
	}

	static PropertyChangedEventArgs _206F_200E_206E_206F_200D_206E_202D_202C_206D_200D_200B_202D_202E_206D_206C_206B_202A_206C_200E_200D_206A_206C_206E_206E_202A_200B_200E_206C_200F_200B_206F_206B_202E_200E_200D_202C_202A_200F_200B_206A_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x10
	}
}
