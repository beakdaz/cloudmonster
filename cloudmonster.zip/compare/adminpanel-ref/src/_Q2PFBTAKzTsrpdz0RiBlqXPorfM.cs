using System;
using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_SystemEnclosure")]
public sealed class _Q2PFBTAKzTsrpdz0RiBlqXPorfM : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _WSmgd9QhmFWHnlW4k5VRoMnrNpj;

	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _I0vaHOuhw0CAW6uSA0DqIwES8FX;

	[CompilerGenerated]
	private string _ZFQfrfff2m907zHawoz8UtG7CCJ;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _wneuDK3DCEulfPPbtL2sj3cQtVLA;

	[CompilerGenerated]
	private string _P2teFQjUF0Gwbu9vuj5yBrGXPCh;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("SMBIOSAssetTag")]
	public string _Z9wgq0YqEqv2s9EGxG6LosGvEgf
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3F 0x65
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name")]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xFD*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x70
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Caption")]
	public string _WVZCeL07h3KQ3QyLtbqAFyMsWVW
	{
		[CompilerGenerated]
		get
		{
			_ = 6;
			/*Error near IL_0001: Unknown opcode: 0xF1*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x169AD0E1
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Version")]
	public string _We0bDTh5OF1piEKdm7XfIwcBS3uA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x80
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			checked
			{
				_ = (long)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xE3*/;
			}
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xE1*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("SerialNumber")]
	public unsafe string _hyT42trMGkdEbd3NQlrBtHvEQnA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCB 0xD8
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Expected native int or pointer, but got F8
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0004: Stack underflow*/+ (/*Error near IL_0003: Stack underflow*/ >> unchecked((int)(nint)(*(IntPtr*)(nint)(*(double*)(nint)/*Error near IL_0001: Stack underflow*/))));
				/*Error near IL_0004: Unknown opcode: 0xE1*/;
			}
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Manufacturer")]
	public string _x9LQFtjAmgtdxpWocRgMLYM03Wz
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD1
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x31
		}
	}

	private _Q2PFBTAKzTsrpdz0RiBlqXPorfM()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}
}
