using System.Runtime.CompilerServices;
using xNet;

internal abstract class _cyFs5JnrBy8dojQJgYd79hXSWKj : _Vq5iZ8mJGi34eQAJEDQcgoBdiab
{
	internal class _uxAV235iSW9wbgjb3LlHCoG04Gj
	{
		[CompilerGenerated]
		private readonly int _s1fdt3aoC4MdeFctXxnve0nhCLT;

		[CompilerGenerated]
		private readonly int _ErWTODCh7rRDCh3tZgFVr6v9Id;

		[CompilerGenerated]
		private readonly int _O51CfaGYFt8KZAqxdea0hfJsUZp;

		[CompilerGenerated]
		private readonly int _wdWcI27iVAVqwirm3mF2XM5F7SI;

		public int _606dk7mJVQpdBjIxScTrpP4E0XS
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x98
			}
		}

		public int _JdRD5peem2FkyPCyKecPpSf4nuK
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xD4
			}
		}

		public int _2G3XbJ7fAi0aXDUj5jNiHocOstn
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x9D
			}
		}

		public int _ZjiDX2VBsSkxHLW4jhYjyEjMr2l
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xC9
			}
		}

		public _uxAV235iSW9wbgjb3LlHCoG04Gj()
		{
			/*Error: Unknown opcode: 0xEA*/;
		}
	}

	internal class _69ytbDF3X4Sbk3en19G74oGa3Db
	{
		[CompilerGenerated]
		private readonly int _Xw2INdvqJcNBnT5IDZnsA8OFfCV;

		[CompilerGenerated]
		private readonly int _3QbvtN4b7HFWwYWUkFWM2ohtTfj;

		[CompilerGenerated]
		private readonly int _AxXAZ00YM2LMG6fzzvokmhXBq5H;

		[CompilerGenerated]
		private readonly int _2X9MdHWK4pCR6MEuFXy3OATPvdd;

		public int _a5H8HJojnGiKhYqGd77iLHBW3CD
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xDC
			}
		}

		public int _1GEpSqnoAF7fybjd685hbOVemC2
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x39
			}
		}

		public int _UCCCMbsWEHaFnxIulLFvBKbZh2i
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xD4
			}
		}

		public int _uETibkuBbE0aCK2hLszV7wpzMRj
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xA3 0x99
			}
		}

		public _69ytbDF3X4Sbk3en19G74oGa3Db()
		{
			/*Error: Invalid field token*/;
		}
	}

	private _69ytbDF3X4Sbk3en19G74oGa3Db _V2WXlmi8dsvlHtJEhQDFTnaTEkmA;

	private _uxAV235iSW9wbgjb3LlHCoG04Gj _BIM78ciWJqPdvak3Av1q0FRInXE;

	public _69ytbDF3X4Sbk3en19G74oGa3Db _WWCIxd0OP441jvGrZ6stiFvst7E
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1F 0xC1
		}
	}

	public _uxAV235iSW9wbgjb3LlHCoG04Gj _8qbtteRrHnFeNZVfHmPj61mLODq
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA0
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected unsafe _cyFs5JnrBy8dojQJgYd79hXSWKj(ProxyClient P_0)
	{
		//IL_0001: Invalid comparison between Unknown and F4
		if ((float)/*Error near IL_0006: Stack underflow*/ > *(float*)(nint)/*Error near IL_0001: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = (uint)((double[])/*Error near IL_0007: Stack underflow*/)[/*Error near IL_0007: Stack underflow*/];
		/*Error near IL_0008: Unknown opcode: 0xFA*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected static string _KCkJ0uI98w7c6aa1fYDPbTFqxch()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x27 0x6A
	}

	static void _200B_202C_202E_200C_200D_200C_202B_202E_206F_202B_200B_206C_200F_200C_206F_206A_202C_200E_200F_200B_206A_206B_200B_206A_200B_206A_202E_206E_202C_200D_206D_200C_206D_202A_206A_206C_202A_200E_206D_206D_202E(HttpRequest P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x13 0x7C
	}

	static void _200B_206B_200B_206A_206F_200F_202E_206B_202B_206F_202E_206F_200B_206C_200B_202E_206B_206A_202D_206D_200C_202E_200E_200B_202B_200C_202A_202A_206B_206D_206F_202B_200E_206E_202A_200B_200E_206F_206C_202D_202E(HttpRequest P_0, string P_1, string P_2)
	{
		/*Error: stloc 25 (out-of-bounds)*/;
		/*Error near IL_0002: Unknown opcode: 0xFD*/;
	}

	static void _202C_200C_200B_200E_206F_200C_200B_202B_200D_200B_206B_202C_206C_206E_206F_200B_200F_206A_206B_206F_206A_206D_202E_200C_200C_200F_202B_206D_206E_200E_200F_202D_206C_200C_202D_202D_206F_200C_206F_200C_202E(HttpRequest P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF4
	}

	static string _200C_200B_206C_202E_202A_200C_202C_202D_200D_200D_206D_202B_200F_202B_200F_202A_202C_202D_206F_202B_200B_200C_200F_200D_200C_202A_202B_206E_200C_202E_202E_202C_206B_202D_200F_202D_206A_206E_202C_200C_202E(string[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF0
	}
}
