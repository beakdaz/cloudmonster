using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;

public static class _oYcPdtJ9qGiyNLsPbGaeAbdAt3f
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _TFEIxnOQN0a8klOHcHvbZttTBGr
	{
		public static readonly _TFEIxnOQN0a8klOHcHvbZttTBGr _003C_003E9;

		public static Func<string, char> _003C_003E9__11_0;

		public static Func<string, char> _003C_003E9__12_0;

		public static Func<string, char> _003C_003E9__13_0;

		public static Func<string, char> _003C_003E9__14_0;

		public static Func<int, int, int> _003C_003E9__17_1;

		public static Func<int, int, int> _003C_003E9__17_2;

		static _TFEIxnOQN0a8klOHcHvbZttTBGr()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF8
		}

		public _TFEIxnOQN0a8klOHcHvbZttTBGr()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal char _kEEO7iT1w15CPnQvc43HKvn37KE(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x81
		}

		internal char _t9IHaGwHWMNfK5QCiIlTSrxnQXC(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x81
		}

		internal char _r02DNy7WxVGOv5cChEjfjFgfpvo(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x81
		}

		internal char _eDJSsSl5yoGYViDcsbSkmlJZ7pK(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x81
		}

		internal int _mZ9DCXnelVafAA2A6AKX30jAloP(int P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0F 0xCE
		}

		internal int _Ib4ibZm8BEDDCSoAkpVBgGBeIuqA(int P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}

		internal Random _yIT70T88VwquMxWcHOiUXIZrFQe()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x88
		}

		static int _206E_200D_202E_200F_200C_206C_202B_206B_206A_200C_206F_200B_200C_202D_200B_200E_200D_202D_206F_200E_206E_202B_206A_206C_206D_206C_200C_202E_202D_206C_202C_202A_202C_200B_200E_200C_202E_200B_206D_202D_202E(string P_0)
		{
			//IL_0002: Invalid comparison between Unknown and I8
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			if ((long)/*Error near IL_0007: Stack underflow*/ <= ((long[])/*Error near IL_0002: Stack underflow*/)[checked((nint)/*Error near IL_0001: Stack underflow*/)])
			{
				/*Error: Invalid branch target*/;
			}
			_ = /*Error near IL_000a: Stack underflow*/>> (int)/*Error near IL_0008: ldloc 0 (out-of-bounds)*/;
			/*Error near IL_000a: Unknown opcode: 0xA6*/;
		}

		static char _202E_206A_206E_206E_206D_206A_206D_206E_206F_200C_202D_206C_206B_202B_200C_206D_200F_200B_202C_200C_202A_206B_206D_206C_200B_202D_206E_202C_202E_202E_206D_202B_202C_202C_206E_200E_202E_200B_200C_202E_202E(string P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x13 0x9B
		}

		static int _206C_206A_206D_200C_206C_200D_206B_206C_202C_206A_202D_206C_202E_202C_202D_206A_206E_206D_206F_200E_200B_200E_206F_200E_206D_200C_206C_206D_200F_202E_202A_202B_206D_202C_202E_206C_202E_200F_206D_200F_202E(ref int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5C
		}

		static Random _202E_206E_206D_206B_202D_200E_200B_206D_202E_200D_202C_206F_206B_200D_206C_206C_202A_202B_206E_202C_206B_206A_200D_200C_202A_206B_202B_206D_206E_200E_200D_206B_200C_202C_206B_202D_206A_202B_206A_202E(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x93 0x65
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _5MQaF30zmBDWjRWuqyyaYuea2ck<_0001>
	{
		public static readonly _5MQaF30zmBDWjRWuqyyaYuea2ck<_0001> _003C_003E9;

		public static Func<_0001, Guid> _003C_003E9__10_0;

		static _5MQaF30zmBDWjRWuqyyaYuea2ck()
		{
			if (/*Error near IL_0002: Stack underflow*/ == /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			_ = (float)/*Error near IL_0003: Stack underflow*/;
			/*Error near IL_0003: Not a type handle*/;
		}

		public _5MQaF30zmBDWjRWuqyyaYuea2ck()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal Guid _ckP6WZkHunhXCjqaZ7v0aWC41Zf(_0001 P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}
	}

	private static int _O7kZuGgCrUP9hAjIsruj3WAB6Uu;

	private static readonly ThreadLocal<Random> _nR1briD1XlescVRvNfngHBkmzpc;

	public static int _xxSeQHBLFohTsemBzVwjyMXL0gN(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCC
	}

	public static int _xxSeQHBLFohTsemBzVwjyMXL0gN(int P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0x54
	}

	public static byte _rFaGo4ZMXXE8TiRfT3QbbOxxwsL()
	{
		/*Error: Unknown opcode: 0xE4*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static void _0jjKhqylKBhkGprYIJFTkTxY5RE(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x37 0x23
	}

	public static double _3jHJrFLT0PuZ8UOlKZgUuWRDETE()
	{
		checked
		{
			_ = (nint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Invalid branch target*/;
		}
	}

	public static double _3jHJrFLT0PuZ8UOlKZgUuWRDETE(double P_0, double P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x25
	}

	public unsafe static float _8lGyiyWprlwAbO59tCSEVhzyVIK(float P_0, float P_1)
	{
		System.Runtime.CompilerServices.Unsafe.Write((void*)(nint)/*Error near IL_0001: Stack underflow*/, /*Error near IL_0001: Stack underflow*/);
		*(byte*)(nint)/*Error near IL_0003: Stack underflow*/ = checked((byte)/*Error near IL_0002: Stack underflow*/);
		if (/*Error near IL_0008: Stack underflow*/ != /*Error near IL_0008: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0008: ldloc 3 (out-of-bounds)*/;
		/*Error near IL_0009: starg 66 (out-of-bounds)*/;
		/*Error near IL_000b: stloc 1 (out-of-bounds)*/;
		checked
		{
			_ = (ulong)/*Error near IL_000d: Stack underflow*/;
			/*Error near IL_000d: Unknown opcode: 0xF7*/;
		}
	}

	public static bool _6CcxIsP9mEHiJMlRqSb2Rqi3dUI(int P_0 = 50)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x43 0xD7
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static _0001 _P9Wwgo9Fwc5zqY8agSMk8dAw5UV<_0001>(IEnumerable<_0001> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x28
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _WcLqgFbR7gwTontLZyIp2tdahFp(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x41
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _CDfrfKwMbvWJdyobeqNEyxuzZqV(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x23 0xE7
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _PFLdgxTDGoaOiRswooa8MRTx2M3A(int P_0)
	{
		/*Error: Read out of bounds.*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _CL4lZoAdgk5EFvOuK72bJLzFYNO(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x96
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _BZJbWn1MLUYOBarKVxaaG8h343I()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x28
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public unsafe static long _c1dP4a7D620KhbKOCOXlr7dgH62(long P_0, long P_1)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Expected O, but got Unknown
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Expected I8, but got Unknown
		((object[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/] = /*Error near IL_0001: Stack underflow*/* /*Error near IL_0001: Stack underflow*/;
		byte num;
		_003F val;
		checked
		{
			num = (byte)unchecked((nuint)checked((nint)(double)(/*Error near IL_0003: Stack underflow*/ >> unchecked((int)/*Error near IL_0003: Stack underflow*/))));
			val = /*Error near IL_0006: ldarg 2 (out-of-bounds)*/;
		}
		*(long*)(int)num = val - val;
		/*Error near IL_000b: Unknown opcode: 0xB1*/;
	}

	public static string _ouNgm6hoFcXZYbgd2pKGAsavmtI(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x4F890B5A
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _NtVO0ZyTc9PHHrJlaC7Alb4wPSe(bool P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8D
	}

	public static string _3i2vqMAdBcm106uZ6gqiXAxg5yT(bool P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC7 0x9D
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _Ev9joibuDvZdlatvuqK8qww0H3N()
	{
		switch ((int)/*Error near IL_0015: Stack underflow*/)
		{
		default:
			/*Error: End of method reached without returning.*/;
		case 0:
			/*Error: Invalid branch target*/;
		case 1:
			/*Error: Invalid branch target*/;
		case 2:
			/*Error: Invalid branch target*/;
		case 3:
			/*Error: Invalid branch target*/;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _HytRbSqLneWaOaYXVOsJgdDtzCnA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2D
	}

	static _oYcPdtJ9qGiyNLsPbGaeAbdAt3f()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC9
	}

	[CompilerGenerated]
	internal static char _NpkNH4ZH2KShYrxKVmXx4YwiyxC(char P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x60
	}

	static int _202B_206A_202B_200B_202A_200C_200D_200E_202E_202E_206C_202E_206D_202A_206A_206B_200B_206A_202E_202B_202B_202B_202D_200E_206F_202D_206C_202C_200D_206D_202D_206D_206D_202A_202D_202C_202D_202E_202A_206B_202E(Random P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAD
	}

	static int _202D_206D_202B_202D_206A_206B_202A_202D_206A_206B_200F_206B_202B_206F_200B_206F_202E_200E_206C_200C_200B_206C_202C_202E_200C_202A_202E_206C_206F_202C_202D_200E_206A_206A_206A_200F_206D_206E_200D_206E_202E(Random P_0, int P_1, int P_2)
	{
		/*Error: Invalid metadata token*/;
	}

	static ArgumentNullException _206A_200F_200B_202D_206F_206A_202A_206D_206A_202A_202A_206F_206C_202B_206E_206D_200E_200B_206D_202E_206B_200D_206E_200B_206F_206F_206B_200F_206D_200B_202C_206B_202E_206E_206E_200C_206C_200F_206D_206F_202E(string P_0)
	{
		/*Error: stloc 0 (out-of-bounds)*/;
		checked
		{
			_ = (ushort)unchecked((long)(ulong)/*Error near IL_0002: Stack underflow*/);
			/*Error near IL_0003: Invalid metadata token*/;
		}
	}

	static void _206F_202A_206E_200C_202C_202C_206D_206F_200B_206E_202E_206C_202B_206C_202A_206C_206C_206D_200D_206A_202B_200B_206B_200E_200D_206A_200F_206E_206C_206A_200C_206A_200B_206B_200D_206E_206B_206D_202E_206B_202E(Random P_0, byte[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x20
	}

	static double _206B_206D_206F_202D_200C_202C_206A_202B_202E_200F_206C_206E_202A_200B_200E_206B_200D_206F_200B_200E_206A_200D_206C_206D_206D_206D_202E_200B_200B_200E_206F_200B_206B_206D_206B_202D_200B_200B_202C_200F_202E(Random P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD5
	}

	static string _202D_206A_206E_206F_202A_200B_206D_200E_200C_200E_200F_206F_206B_206C_202B_202D_200B_200B_206F_202C_202C_200F_206F_200C_206D_202E_202C_206D_200B_200F_200E_202A_200E_206A_206B_206D_200F_206A_200E_202B_202E(char[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static string _206B_206C_200B_202B_200C_206E_200E_206A_200E_200D_202A_202A_202A_202D_202A_202B_200D_206A_200E_206A_202A_200E_200D_202E_206C_202E_200E_202B_206C_202D_200B_200B_206F_206C_206B_206F_202D_206D_200B_200D_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE1
	}

	unsafe static Random _200D_200F_200D_200F_200E_202B_202A_202A_200D_206C_206A_206F_206D_200C_200D_202C_202C_200D_206E_200D_202C_200B_202C_202B_206A_200E_200E_202C_202E_206F_202B_206B_200B_206B_206A_206B_202B_202E_206A_206D_202E()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Expected O, but got I4
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		System.Runtime.CompilerServices.Unsafe.Write((void*)(nint)(/*Error near IL_0001: Stack underflow*/ ^ /*Error near IL_0001: Stack underflow*/), (object)(-1));
		if (/*Error near IL_0008: Stack underflow*/ < /*Error near IL_0008: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		if (/*Error near IL_000e: Stack underflow*/ <= /*Error near IL_0009: Stack underflow*/% /*Error near IL_0009: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		if (/*Error near IL_0013: Stack underflow*/ != /*Error near IL_0013: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0013: Unknown opcode: 0xE6*/;
	}

	static string _206F_202E_200B_200F_206F_206A_202B_206E_206D_200F_200F_202E_202E_200B_206F_206F_200B_206E_200E_200E_200C_202C_206C_202D_206A_202D_202A_200D_202A_206C_206A_200B_202E_200D_200B_200B_200E_200B_202E_206B_202E(byte[] P_0)
	{
		if (0 == 0)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0003: Unknown opcode: 0xE9*/;
	}

	static string _206A_200B_202E_206C_200D_202C_202A_200F_206D_202E_202A_200E_200D_206C_206C_202E_202D_202D_202D_202A_202E_206A_206F_200F_206A_200C_200B_202C_206D_202D_202C_200E_202D_206F_206B_200D_206B_200F_200B_206B_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static string _202A_202A_202D_206F_206D_202C_206C_202A_206F_202B_206C_200B_200B_202E_202B_206C_206B_206E_202E_206D_206E_202E_200E_200B_200F_202C_202C_202B_202D_200D_200E_206C_200E_200F_206F_206E_206E_200E_206C_200F_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xD8ED06FC
	}

	static ArgumentOutOfRangeException _202E_206D_200B_202D_206A_206E_202C_200B_200D_202E_202B_206A_202C_206D_200C_200F_202A_206A_200C_206C_200F_200D_206F_202E_200C_206A_206D_202D_202C_202C_200B_206D_202D_200D_206F_202A_200B_202D_200F_200D_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8C
	}

	static long _202A_202C_200F_200F_206E_206C_206A_206F_202C_202E_202C_202E_200E_202E_206C_206A_200B_200F_206F_202B_202B_206A_200D_200C_200D_206F_202C_202E_206B_206E_206B_200D_206D_206B_206B_206B_206D_206A_202A_206C_202E(byte[] P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	static string _200C_206B_202E_202B_206E_200F_202A_206A_200E_200E_206E_206B_200B_206F_202C_200C_200B_206B_200D_202B_206C_202D_206B_202C_206F_202C_206A_200F_200E_202A_200F_202A_200D_202B_202A_206C_202A_206E_206C_200F_202E(string P_0, object[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB7 0x57
	}

	static IPAddress _206A_206A_206D_200C_206E_202B_200D_200D_202D_200C_206F_206F_200E_200F_200D_206F_200C_206E_206A_206F_206A_200F_200E_206F_202A_200F_200B_202E_202D_202A_206C_202B_206E_206D_206A_200C_206E_202E_206E_202D_202E(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x79
	}

	static string _200D_206C_200C_200E_202B_200E_206C_206A_202C_200B_202D_202A_202B_202A_200F_200F_206E_202D_206C_200E_206F_202A_206A_206D_206E_206E_206D_200E_206F_202B_206A_202A_206F_202A_200C_202E_206E_200B_202B_200E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6C
	}

	static int _206F_202C_200F_200E_202A_200C_202B_200B_200B_206B_202D_202D_206C_206C_202C_206F_206C_206C_200C_206D_200D_202E_200B_200D_206D_206D_202E_202C_202A_206F_202B_200C_206C_206E_206D_206E_206D_206F_202A_202A_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x41
	}

	static void _202D_206B_200E_202E_202E_200D_202E_200E_200F_202D_200C_200C_202B_202A_206F_206E_200E_206B_206B_200B_206C_206B_202A_206F_202D_206D_202D_206C_202C_206B_202C_206A_202D_206A_200C_200F_206D_200B_206D_202E_202E(Array P_0, RuntimeFieldHandle P_1)
	{
		/*Error: Invalid metadata token*/;
	}
}
