using System;
using System.Runtime.CompilerServices;
using xNet;

internal class _cJdOdhxjuLCcGfSML0V4ZhpECBn : _Q04tXOwCeYzbaJJlKXzOnww6yhi<_8gUgNmPVibylNuc0IcN3ZYxrIt>
{
	[MethodImpl(MethodImplOptions.NoInlining)]
	public _cJdOdhxjuLCcGfSML0V4ZhpECBn()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x29
	}

	protected override bool _LHrtlMqloGta9gjjw7awOk5hBEs()
	{
		/*Error: Unknown opcode: 0xBD*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected unsafe override void _RuVw9UgsQLaDDO9mcXfSjrKjxlI(_8gUgNmPVibylNuc0IcN3ZYxrIt P_0, _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_1 = null)
	{
		if (((int[])/*Error near IL_0002: Stack underflow*/)[*(float*)(nint)/*Error near IL_0001: Stack underflow*/] == 0)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error: End of method reached without returning.*/;
	}

	static ProxyClient _206E_202E_202E_200C_206A_202D_202E_200C_200B_202A_202B_200C_206A_206B_202C_200F_200C_200E_200D_202C_206D_200E_202E_206F_202C_200E_206D_206B_200E_202E_202C_202B_206D_206E_206F_200F_200B_206E_200F_206C_202E(ProxyType P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x31
	}

	static string _200D_206B_200C_206D_206F_200D_206B_202E_202E_206A_202E_200B_206F_200E_206D_202B_206D_200B_200F_202B_202C_200D_202C_202C_200E_200B_206A_200C_206F_206D_202B_202B_200E_200B_202A_202A_200B_200F_202C_202A_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static string _206A_202A_202E_206E_200E_206F_206D_200E_200C_206C_202D_206E_200C_200E_202D_206B_202E_202E_202D_200F_202C_206E_206C_200F_200E_206E_206A_202B_200C_200E_200F_206C_202D_206F_206B_200E_202C_200C_200C_206A_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6C
	}

	static string _200B_202B_200F_206D_206C_200B_202D_202D_206E_202B_200B_206D_206E_206D_202C_206A_206F_200F_202B_206D_206D_206A_200B_206E_200D_206C_206E_206A_206C_200F_202C_200C_200C_206C_202E_200F_206B_206C_202A_206F_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE1
	}

	unsafe static void _202D_200F_206B_200C_206F_202B_206E_206D_202D_200D_202E_202B_202C_200C_202D_202D_206D_200C_202A_206B_206E_200E_200B_200E_200D_200D_202B_202A_206E_206F_206B_200D_202E_200B_206D_202D_206A_200C_202E_202D_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}
}
