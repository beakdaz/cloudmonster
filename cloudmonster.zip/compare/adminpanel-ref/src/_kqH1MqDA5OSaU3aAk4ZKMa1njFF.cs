using System;
using System.Runtime.CompilerServices;
using System.Windows.Input;

public class _kqH1MqDA5OSaU3aAk4ZKMa1njFF<_0001> : ICommand
{
	private readonly Predicate<_0001> _5RzlBt1FY4Q1JglnGkEiXyl3CYT;

	private readonly Action<_0001> _1FcY4vmVSEttI37QXYZpwB1aBXn;

	public event EventHandler CanExecuteChanged
	{
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x18
		}
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF8
		}
	}

	public _kqH1MqDA5OSaU3aAk4ZKMa1njFF(Action<_0001> P_0)
	{
		/*Error: Unknown opcode: 0xC0*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _kqH1MqDA5OSaU3aAk4ZKMa1njFF(Action<_0001> P_0, Predicate<_0001> P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3B 0x7B
	}

	public bool CanExecute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x81
	}

	bool ICommand.CanExecute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CanExecute
		return this.CanExecute(parameter);
	}

	public void Execute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x65
	}

	void ICommand.Execute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Execute
		this.Execute(parameter);
	}

	static ArgumentNullException _202C_206E_202A_202C_202E_200F_200D_200F_206A_206D_200C_202C_200F_200C_200F_206C_200D_200C_200B_200F_202A_200C_206E_202D_202C_200C_206F_200C_206C_200E_200C_206E_200C_206A_202B_200B_200C_202A_200E_202C_202E(string P_0)
	{
		/*Error: stloc 0 (out-of-bounds)*/;
		checked
		{
			_ = (ushort)unchecked((long)(ulong)/*Error near IL_0002: Stack underflow*/);
			/*Error near IL_0003: Invalid metadata token*/;
		}
	}

	static void _202C_202B_202D_200C_206B_202E_202B_202D_200F_200B_206D_206A_202E_206E_202B_200B_206F_202E_200C_200B_206F_206D_200D_200F_202C_200B_206C_200F_206B_200B_202C_202A_206B_202D_206C_206F_206B_206F_202E_206A_202E(EventHandler P_0)
	{
		/*Error: Unknown opcode: 0xC9*/;
	}

	static void _200C_206B_202D_202E_200B_200B_202D_200E_202C_206B_200F_202E_200D_206B_202D_202B_202D_206B_202B_202B_200B_200E_206F_202E_202C_200C_206E_202B_202C_202E_200F_206A_202A_206A_206B_202A_200B_206D_202B_206E_202E(EventHandler P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}
}
public class _kqH1MqDA5OSaU3aAk4ZKMa1njFF : ICommand
{
	private readonly Func<bool> _5RzlBt1FY4Q1JglnGkEiXyl3CYT;

	private readonly Action _1FcY4vmVSEttI37QXYZpwB1aBXn;

	public event EventHandler CanExecuteChanged
	{
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x98
		}
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}
	}

	public _kqH1MqDA5OSaU3aAk4ZKMa1njFF(Action P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x64
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _kqH1MqDA5OSaU3aAk4ZKMa1njFF(Action P_0, Func<bool> P_1)
	{
		/*Error: Read out of bounds.*/;
	}

	public bool CanExecute(object parameter)
	{
		//IL_0003: Expected O, but got I4
		/*Error near IL_0002: Not a type handle*/;
	}

	bool ICommand.CanExecute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CanExecute
		return this.CanExecute(parameter);
	}

	public void Execute(object parameter)
	{
		checked
		{
			_ = (int)unchecked((ulong)checked((long)/*Error near IL_0001: Stack underflow*/));
			/*Error near IL_0002: Unknown opcode: 0xCA*/;
		}
	}

	void ICommand.Execute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Execute
		this.Execute(parameter);
	}

	static ArgumentNullException _202B_202A_206C_200D_206B_206A_202E_200E_200C_200B_200B_200C_200F_200C_200E_206C_202A_202C_206A_200F_200B_206D_202E_200B_200C_202D_200E_206E_202A_202B_206B_206E_202C_206E_206A_206D_202A_202A_202B_202A_202E(string P_0)
	{
		/*Error: stloc 0 (out-of-bounds)*/;
		checked
		{
			_ = (ushort)unchecked((long)(ulong)/*Error near IL_0002: Stack underflow*/);
			/*Error near IL_0003: Invalid metadata token*/;
		}
	}

	static void _206B_200C_206D_200F_206C_206D_202B_202C_202A_202E_200C_200D_200B_202E_202E_206B_200F_200F_206E_200E_202C_202C_200C_200B_206E_200C_200C_206A_206E_206E_202C_200B_206A_206A_206C_200C_200C_202E_202E_202A_202E(EventHandler P_0)
	{
		/*Error: Unknown opcode: 0xC9*/;
	}

	static void _202B_206A_200E_200F_200C_206C_206E_202D_202E_200E_206F_206D_202C_206E_202B_202C_206E_200C_206B_206D_206A_206E_200F_206D_206F_200B_200E_200B_202B_206F_200C_200F_206B_206E_206B_202B_206C_202D_202B_200F_202E(EventHandler P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}
}
