using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_ComputerSystemProduct")]
public sealed class _3QvgH9XL4srUBFaltCR2ytB9jgj : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _DlNPIoZ7okan7IR60cAS9rZhCxd;

	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _tzzcCrqL28yFNpioNcsofjArHGXA;

	[CompilerGenerated]
	private string _ZFQfrfff2m907zHawoz8UtG7CCJ;

	[CompilerGenerated]
	private string _I0vaHOuhw0CAW6uSA0DqIwES8FX;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _0tRuOY9fiZhlLcIKVTuD6Oscfyg;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("UUID", _ouek40mfEZcKAiuBOCraP5DTnRQ = true, _iQXDdbL1WVTLjaCAiHBR5kPilK5 = true)]
	public string _nTQOuat6jtZKVqBMDthLNrMWrsk
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3B 0x77
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name")]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3D
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD1
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Vendor")]
	public string _qR7176KXdRnagmgK6PZecvl19Fb
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x90
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF1
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Version")]
	public string _We0bDTh5OF1piEKdm7XfIwcBS3uA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x26
		}
		[CompilerGenerated]
		set
		{
			/*Error: ldarg 2 (out-of-bounds)*/;
			/*Error near IL_0001: ldarg 3 (out-of-bounds)*/;
			/*Error near IL_0002: Not a type handle*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Caption")]
	public string _WVZCeL07h3KQ3QyLtbqAFyMsWVW
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x31
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB9
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xF3*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("IdentifyingNumber")]
	public unsafe string _kF9QAb6Qs3GnimxBtdBieNyehrO
	{
		[CompilerGenerated]
		get
		{
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xBD*/;
		}
		[CompilerGenerated]
		set
		{
			/*Error near IL_0001: Invalid metadata token*/;
		}
	}

	private _3QvgH9XL4srUBFaltCR2ytB9jgj()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}
}
