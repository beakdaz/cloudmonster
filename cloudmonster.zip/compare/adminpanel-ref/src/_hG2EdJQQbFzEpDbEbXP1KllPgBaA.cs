using System;
using System.Management;
using System.Runtime.CompilerServices;

public sealed class _hG2EdJQQbFzEpDbEbXP1KllPgBaA
{
	private readonly PropertyData _Pnxi4LOQue2HDwzynf5uVnrDLfF;

	[CompilerGenerated]
	private readonly string _iYNOAl4CiUqfZtM4WLA190HRwhU;

	[CompilerGenerated]
	private readonly string _3NE0k38hn2WxVlRm7n73BFzbsjk;

	public string _rftap3TFrc5Nyjuae9Twpt846Mz
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x37 0xC2
		}
	}

	public string _ZazCCWtmaZfEncvcFBbX6Qcp3n5
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC0
		}
	}

	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0002: Stack underflow*/- ((object[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
				_ = 5;
				/*Error near IL_0003: Unknown opcode: 0xE6*/;
			}
		}
	}

	public object Value
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x43 0xDA
		}
	}

	public string _fG7np5G6IMyUfhAdpzRXplSWwip
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5C
		}
	}

	public Type _i25ZXN23azvBjeD7NKxKVKDm7Rk
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x41
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _hG2EdJQQbFzEpDbEbXP1KllPgBaA(string P_0, string P_1, PropertyData P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x29
	}

	private static Type _ydzaZgHtbIZw4DBLYrCA2qTgsa5(CimType P_0, bool P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x00
	}

	static string _206D_206E_206A_200B_206C_206F_206E_206C_202C_206B_200C_200C_200C_202C_206B_202C_200B_200D_206A_200B_200B_206A_202D_206B_202C_200D_206F_202D_200E_206E_202A_200B_206B_206D_206D_206C_200F_200E_202C_206D_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x90
	}

	static object _202E_202E_206B_206D_202C_200B_200D_206E_206F_206A_202C_206E_206E_200F_200C_202B_200D_206F_200D_202B_206F_202D_200E_200B_200D_206B_202A_200F_202D_206D_206A_200E_200B_202D_206A_206F_200B_206F_200B_202D_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static string _206A_202B_200E_200D_200C_206C_202A_206B_200B_202C_206F_200E_202A_206E_202B_200C_206B_200E_206B_202D_200C_202D_200B_206E_200B_202E_206C_202B_202B_206F_206B_206E_202D_206F_202E_206A_202B_202E_206C_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9B 0x45
	}

	static CimType _206C_206B_202E_202A_206A_200B_200B_200B_202C_206D_206E_206C_206B_202A_206F_202C_206B_200C_200C_200F_202D_206C_200D_202A_206D_200C_206D_206F_200C_206B_200B_206D_202E_206E_206C_206D_202B_200E_200F_202D_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x71
	}

	static bool _206A_200D_206B_200F_206E_202A_206E_202A_200D_206F_200E_200C_200B_206A_206A_200F_202E_206A_206B_206D_206E_200E_206B_206B_200F_200D_206C_206B_202D_200F_206C_202E_206A_202D_202C_200F_206E_202A_200D_206C_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA8
	}

	static Type _200D_200E_200C_200E_206D_200F_202D_200E_206B_200F_206B_200F_206C_202A_206D_202A_200E_202C_200D_206D_202D_202A_206F_200C_202B_200C_202A_202E_206A_200D_200E_206E_200F_202B_202D_202E_206D_206F_202E_206C_202E(RuntimeTypeHandle P_0)
	{
		if (/*Error near IL_0005: Stack underflow*/ >= /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0005: Unknown opcode: 0xC4*/;
	}

	static bool _202B_206B_202A_206E_200F_206E_206C_200F_202D_206B_202A_200F_202E_200F_206B_206F_206C_200D_206E_206A_202B_202A_206E_206E_206B_202E_200F_206B_202C_200E_206A_200E_200D_206C_206A_206D_200E_206D_202C_206D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCF 0xAB
	}

	static ArgumentException _200D_200B_200B_200E_202D_206D_206E_206F_202B_206B_206D_200D_200C_202C_200C_206D_200F_200D_202E_200B_206B_206C_200C_202E_206B_202E_200E_202C_206A_206A_206E_202A_206D_202A_206D_202B_202E_202E_200C_206A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x33 0xBD
	}

	static ArgumentNullException _202E_206A_202A_206C_206F_206F_206A_206D_202A_200C_200B_202E_200D_202A_200F_200D_202B_202B_206D_206D_206F_200C_200D_200E_200B_202D_202E_202C_206C_206E_200E_206A_206D_202A_202E_206C_202E_200D_202B_200F_202E(string P_0)
	{
		/*Error: stloc 0 (out-of-bounds)*/;
		checked
		{
			_ = (ushort)unchecked((long)(ulong)/*Error near IL_0002: Stack underflow*/);
			/*Error near IL_0003: Invalid metadata token*/;
		}
	}
}
