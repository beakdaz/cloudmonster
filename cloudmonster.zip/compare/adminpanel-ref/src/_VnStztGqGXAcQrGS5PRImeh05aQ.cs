using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using HandyControl.Controls;

public class _VnStztGqGXAcQrGS5PRImeh05aQ : Window, IComponentConnector
{
	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _LQNbUOjGEG9MKmUgq9SIXGsvj5c : IAsyncStateMachine
	{
		public int _9GEJZGYJ68mAnt4VNfzJl5b6MGF;

		public AsyncVoidMethodBuilder _aHiI51deYTr44VDecb3BGvtoMal;

		public DragEventArgs _X9IkpBMJzlGPP4MaLmryFxsPgyp;

		public _VnStztGqGXAcQrGS5PRImeh05aQ _BdhCADRkuGneNk31bMQ4Ub3HhtX;

		private TaskAwaiter _eJGWHxhKuZg5DUMzSWcGKzBa7xH;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x0E186A6E
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x71
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static IDataObject _202A_206B_202B_200B_202A_202D_200C_202D_206B_202E_206B_200D_206E_206E_202C_206B_206C_200F_200B_200E_200C_202D_202A_202E_200C_206F_206C_200E_206F_206B_202D_200E_202C_202E_206A_202D_202E_200F_200E_200C_202E(DragEventArgs P_0)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0002: Stack underflow*/^ /*Error: ldarg 3 (out-of-bounds)*/;
			/*Error near IL_0002: Invalid metadata token*/;
		}

		static object _206E_206C_202E_202A_200C_206F_200E_200F_206D_202B_200C_206B_202A_202D_206F_202C_200D_202C_200C_200B_206E_206C_206E_202C_206B_202D_200F_202A_200C_206C_200C_202D_206F_200E_200D_202A_206B_200F_206C_202A_202E(IDataObject P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x89
		}

		static object _200C_202E_200B_200C_200C_206D_202C_200F_206A_202E_206C_200E_206A_200C_202A_200E_206B_202B_200E_200F_200B_202B_206F_200C_206F_206F_206B_200F_200C_206B_206B_202D_206A_200F_206B_206E_206D_202D_200D_206F_202E(FrameworkElement P_0)
		{
			/*Error: Unknown opcode: 0xA9*/;
		}

		static FileAttributes _200B_206E_202B_206F_200F_206F_202A_200C_202B_200F_202D_200D_202D_206A_200B_206C_200F_206A_202A_206D_206F_202C_206E_206C_202B_206C_206A_206B_200D_200D_200F_200B_206D_200B_206D_200D_202A_200E_206B_206E_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}

		static bool _206A_202E_206C_200D_206D_202A_200B_206B_206A_200E_206C_200B_206D_206E_200E_206B_200D_202A_200D_206C_206E_202B_200B_200E_206A_200F_202C_200E_206F_206B_200F_202C_206C_200D_202E_206D_206D_200D_206D_206A_202E(Enum P_0, Enum P_1)
		{
			/*Error: Unknown opcode: 0xE2*/;
		}

		static string[] _202E_200E_200F_200F_200E_202E_206E_206F_206F_202E_206D_202D_200C_206B_202A_202E_202E_200C_200C_206B_200F_206A_202C_206E_206E_206B_202E_200B_202B_200F_202A_200C_200C_206B_206D_202B_202C_202C_200B_202B_202E(string P_0, string P_1, SearchOption P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB4
		}

		static TaskAwaiter _202C_202E_206E_206A_202B_200B_202D_200D_206E_200C_200F_202A_200B_202D_200B_200F_200C_200C_200B_200D_206F_200E_206D_202D_200C_200D_206C_202D_202C_200D_206E_206D_206C_200F_202C_200D_200F_206F_202D_200C_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
	}

	internal Border _jDHiKdPMigf07uAxN21hSprz6bb;

	private bool _yDt87OiBbvp48poyGpJneAvGUST;

	public _VnStztGqGXAcQrGS5PRImeh05aQ()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5F 0x24
	}

	[AsyncStateMachine(typeof(_LQNbUOjGEG9MKmUgq9SIXGsvj5c))]
	private void _Uv9WklYBGsPcGWLMYAzerFfLPOy(object P_0, DragEventArgs P_1)
	{
		/*Error: Read out of bounds.*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.10.0")]
	public void InitializeComponent()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3D
	}

	void IComponentConnector.InitializeComponent()
	{
		//ILSpy generated this explicit interface implementation from .override directive in InitializeComponent
		this.InitializeComponent();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.10.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD3 0x1D
	}

	static void _200B_202A_202C_202E_206E_200B_200D_206D_206E_206B_200C_202C_202B_206B_202C_202E_202C_202C_202A_202C_206A_200B_206B_202D_206B_206E_206E_200F_202A_200F_200F_202A_202E_206C_206E_202B_206B_200C_200B_206B_202E(UIElement P_0, DragEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x43 0xD0
	}

	static Uri _200B_202C_202A_206A_206D_202C_200E_200B_200E_206A_202E_206E_206D_202D_200D_202D_200B_200D_202C_200F_206E_200F_200F_202B_200D_200F_206A_206A_206C_206B_202C_200F_200D_202D_202B_200E_206E_202D_206C_202E_202E(string P_0, UriKind P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static void _206F_202C_202D_200D_206D_202E_202D_206C_202C_202B_206A_206C_200D_206F_206B_200B_200E_202C_200B_200E_202E_206E_200E_202E_200E_202E_200B_206D_206D_202B_202D_200B_200C_200E_200E_202E_202A_202A_200B_206D_202E(object P_0, Uri P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1D
	}
}
