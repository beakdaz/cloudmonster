using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using xNet;

internal abstract class _rBtvcVNscNSJGVSNDRhtiUa8Eny : _Vq5iZ8mJGi34eQAJEDQcgoBdiab
{
	internal class _erbqksqUbvRBx0mqzGiXuhaaNVH
	{
		private string _2IC1658froahwzMwgEWvwJSRMTB;

		private string _2vqn686povW808Romp16liudKWd;

		private string _pKKkCm339LQnbqQQN2vCiTLklDE;

		private string _SX5CR3IJ7T5I4T88TTs86NaYf4i;

		private string _v1M4OxB6rGid1M6c2hCDf8453Vn;

		private int _FsCeG2xKmdiBqvJPgfVHayEtZaK;

		private int _vLLfAboWRD3p3Zwntb0VPAunkfA;

		private int _5epkqgk1KcobnpZa2JaRuECVySf;

		private int _ppibAoMDzYpwl3OPz9kZJfXb9fIA;

		private int _6zHyz27aUzcgHlivy15gdg2FREAA;

		private static readonly string[] _bdOJEfhQa4ai82cXiwgwV4mvM8f;

		private static readonly Dictionary<string, string> _eHraDOAQ4s9J0chUP7ZcP80RhhH;

		private static readonly Dictionary<string, (int width, int height)> _IIJY2dvurGM7G4GqcU1CgFGUcXd;

		private static readonly Dictionary<string, (int width, int height)> _Rsar4GH6gPrhgLuP1TVHm2NeIhh;

		private static readonly Dictionary<string, int[]> _GikmT0JSeyy4hS4jzHH8S6goulD;

		public string _MclCFJbl3tOBdizGXqhORJWRvjK
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xE7 0x85
			}
		}

		public string _RHpH6UjpACgPd8dblQqDfRjU0Yf
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xFD
			}
		}

		public string _RkEUAAjryTbxFP4QftSxzATYGvF
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x4D
			}
		}

		public string _MA5wv9I6kPl6xrQbTVG6pU6vL4A
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x75
			}
		}

		public string _We0bDTh5OF1piEKdm7XfIwcBS3uA
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x9D
			}
		}

		public string _pJQSt8crtfFqur04zWHvnvh6ZTh
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x04
			}
		}

		public int _4XMPItxQ24Qg0WFfzIuBxvyCcyV
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xF3 0xBF
			}
		}

		public int _sGiY8KvwDvjmWnU2wzcAWtxhGyB
		{
			get
			{
				/*Error: Invalid metadata token*/;
			}
		}

		public int _5ufDx2N04yI0t4jJ40Kl1Nf1ZXf
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x93 0x62
			}
		}

		public int _1KxUqkSDHNHb6e6GqDcI0M2dSSN
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x7C
			}
		}

		public int _EGpGT5sJoxTInsDTOSaFQD2D40k
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xA7 0xC2
			}
		}

		public string _bn0GYypMnvDsZrIFKybPGFAAN8O
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x44
			}
		}

		public _erbqksqUbvRBx0mqzGiXuhaaNVH()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		static _erbqksqUbvRBx0mqzGiXuhaaNVH()
		{
			//IL_0002: Invalid comparison between Unknown and I8
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			/*OpCode not supported: DebugBreak*/;
			if ((long)/*Error near IL_0007: Stack underflow*/ >= checked((long)/*Error near IL_0002: Stack underflow*/))
			{
				/*Error: Invalid branch target*/;
			}
			_ = /*Error near IL_0008: Stack underflow*/* /*Error near IL_0008: Stack underflow*/;
			/*Error near IL_0008: stloc 3 (out-of-bounds)*/;
			if ((int)/*Error near IL_000e: Stack underflow*/ == 0)
			{
				/*Error: Invalid branch target*/;
			}
			_ = /*Error near IL_0010: Stack underflow*/>> (int)checked((nint)/*Error near IL_000f: Stack underflow*/);
			/*Error near IL_0010: Invalid field token*/;
		}

		static int _200B_206B_200C_206C_206A_200E_202E_206A_202B_202C_200F_200B_206F_200F_202D_200B_202E_206E_200F_202B_200D_200E_202D_202E_200F_200E_202A_200F_202C_202A_206A_200C_200B_202D_206D_200E_200C_200C_200C_200C_202E(string P_0)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			_ = ((uint[])/*Error near IL_0004: Stack underflow*/)[checked(/*Error near IL_0003: Stack underflow*/ + (sbyte)0)];
			/*Error near IL_0004: Unknown opcode: 0xF0*/;
		}

		static char _202A_202A_206A_202E_206D_206B_200D_200E_206D_206B_200B_202E_200C_206D_206E_200F_206D_202B_200F_206F_206B_202E_206D_202A_200C_202B_206B_200F_200C_202B_200B_200F_206A_206C_206D_206C_202D_200F_200C_200D_202E(string P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7C
		}

		static bool _206E_200E_206F_200B_206C_206A_202A_206C_202C_206D_206D_206A_202D_200D_202A_202A_206A_200C_206C_200F_206F_202A_200E_200E_206E_206F_200E_206D_200B_200E_202D_206D_206E_202D_200D_200D_200D_206B_206D_202C_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}

		static string _200C_202D_202D_206A_200F_200F_202A_200E_206B_200C_200F_206F_206F_206B_200D_206D_202C_200B_206B_206A_200E_202C_200C_202D_206D_200D_206A_200D_206C_202B_200F_200F_206F_200E_206C_200F_206C_206B_206C_206C_202E(string P_0)
		{
			/*Error: Unknown opcode: 0xF3*/;
		}

		static string _206E_200C_200B_206F_200F_206D_200E_200E_206C_202B_206A_202C_202B_202A_206B_200D_200C_200F_202B_206D_202D_200D_200B_200E_200C_206D_202A_200E_202E_206E_202D_202B_200E_202B_202A_206C_206B_200F_200C_202E(string P_0, char P_1, char P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2B 0x84
		}

		static string _202D_206B_206C_202A_200B_206B_206A_206A_206C_202B_206E_200C_206C_206A_206C_202B_206D_202B_206B_200C_202A_202A_206A_206D_206E_200F_200D_206F_202D_200C_200F_206E_206B_202B_200D_206D_202B_200B_202A_202B_202E(string[] P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF0
		}

		static void _202C_206E_200E_202B_202B_202A_202E_200F_200B_202A_202E_202B_202A_200F_206B_206E_206D_206E_202A_202A_206F_200D_202C_206F_202E_200C_200B_206D_202C_202C_206A_200D_206A_202B_200D_200E_200E_200D_206A_206C_202E(Array P_0, RuntimeFieldHandle P_1)
		{
			/*Error: Invalid metadata token*/;
		}
	}

	private _erbqksqUbvRBx0mqzGiXuhaaNVH _rzJOUq4GFuemQIYvJAi99rMXhuA;

	public _erbqksqUbvRBx0mqzGiXuhaaNVH _Ml9WMv4BkRjhAHH65AZOFeVGksP
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}
		protected set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD5
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected _rBtvcVNscNSJGVSNDRhtiUa8Eny(ProxyClient P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}

	static void _202C_202C_202A_206D_200F_206B_202E_206D_206A_206B_206D_200D_200B_206A_200F_200F_206E_202E_200F_200B_206F_202D_202D_206A_200F_206A_206F_206E_202B_200F_206E_206D_206E_200E_200F_200B_206C_202E_200F_206E_202E(HttpRequest P_0, string P_1, string P_2)
	{
		/*Error: stloc 25 (out-of-bounds)*/;
		/*Error near IL_0002: Unknown opcode: 0xFD*/;
	}
}
