using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _KkAxjtzK8ptaSmIrK7hKnyTCFvm : INotifyPropertyChanged, _6dtVmsdt1s30i5sdGYKOQK2KfHD
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _L6Zr7IzIMMImjvQ5erV7Xqm5pSC
	{
		public static readonly _L6Zr7IzIMMImjvQ5erV7Xqm5pSC _003C_003E9;

		public static Func<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d, Guid> _003C_003E9__14_0;

		static _L6Zr7IzIMMImjvQ5erV7Xqm5pSC()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD8
		}

		public _L6Zr7IzIMMImjvQ5erV7Xqm5pSC()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal Guid _RTyk0zH6twbKfyzPzxKQ0XqA1Tb(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}
	}

	private readonly ConcurrentQueue<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d> _qjoSB8o1bu07BZK3D33U0ReAJOl;

	private readonly HashSet<_ROKsX3hqy1ZuIVRvxr5CPb2oC7d> _wSpL6IMX5BrdztlLPxz8oJF5zEj;

	private int _i4a0Arhs8gdQ7L1wwyzRKkJeNrG;

	[CompilerGenerated]
	private PropertyChangedEventHandler _z3AhFEA6ZqXlGSFrZ8X3z8BQncC;

	public int Current
	{
		get
		{
			/*Error: ldloc 0 (out-of-bounds)*/;
			/*Error near IL_0001: Unknown opcode: 0xCC*/;
		}
	}

	public bool IsEmpty
	{
		get
		{
			/*Error: Invalid metadata token*/;
		}
	}

	public int Count
	{
		get
		{
			/*Error: Unknown opcode: 0xC7*/;
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x53
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA3 0xC1
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _hNNor7qU8jzR9dZM9zJzDxTmTRd(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._hNNor7qU8jzR9dZM9zJzDxTmTRd(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _hNNor7qU8jzR9dZM9zJzDxTmTRd
		this._hNNor7qU8jzR9dZM9zJzDxTmTRd(P_0);
	}

	public void _SEPoZ1xBSyOgFjtGxo4pDlYitdL(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x60
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._SEPoZ1xBSyOgFjtGxo4pDlYitdL(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _SEPoZ1xBSyOgFjtGxo4pDlYitdL
		this._SEPoZ1xBSyOgFjtGxo4pDlYitdL(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _MUBdjNXCBFoE0kpV8M9gDph3Mwj(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x97 0xFB
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._MUBdjNXCBFoE0kpV8M9gDph3Mwj(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _MUBdjNXCBFoE0kpV8M9gDph3Mwj
		this._MUBdjNXCBFoE0kpV8M9gDph3Mwj(P_0);
	}

	public void _try5vwTmAHzwoXVYW9gYEPJ1oMe(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._try5vwTmAHzwoXVYW9gYEPJ1oMe(_ROKsX3hqy1ZuIVRvxr5CPb2oC7d[] P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _try5vwTmAHzwoXVYW9gYEPJ1oMe
		this._try5vwTmAHzwoXVYW9gYEPJ1oMe(P_0);
	}

	public bool _sqPyBgKQDukbMCUWmksA1FgD5waA(out _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x93 0x23
	}

	bool _6dtVmsdt1s30i5sdGYKOQK2KfHD._sqPyBgKQDukbMCUWmksA1FgD5waA(out _ROKsX3hqy1ZuIVRvxr5CPb2oC7d P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _sqPyBgKQDukbMCUWmksA1FgD5waA
		return this._sqPyBgKQDukbMCUWmksA1FgD5waA(out P_0);
	}

	public void _n7WDunegbRYqu1M2NPHesKvL4mG()
	{
		/*Error: Unknown opcode: 0xE7*/;
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._n7WDunegbRYqu1M2NPHesKvL4mG()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _n7WDunegbRYqu1M2NPHesKvL4mG
		this._n7WDunegbRYqu1M2NPHesKvL4mG();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _qRdFlCSYKfluRgLUjieaObAJw2f()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC5
	}

	void _6dtVmsdt1s30i5sdGYKOQK2KfHD._qRdFlCSYKfluRgLUjieaObAJw2f()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _qRdFlCSYKfluRgLUjieaObAJw2f
		this._qRdFlCSYKfluRgLUjieaObAJw2f();
	}

	protected virtual void _rIyM7anFSgcDzLC5j2AuaUf03KP(string P_0 = null)
	{
		if (!float.IsFinite(/*Error near IL_0001: Stack underflow*/))
		{
			throw new ArithmeticException();
		}
		if (/*Error near IL_0006: Stack underflow*/ < /*Error near IL_0006: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0006: ldloc 2 (out-of-bounds)*/;
		/*Error near IL_0007: Invalid branch target*/;
	}

	public _KkAxjtzK8ptaSmIrK7hKnyTCFvm()
	{
		/*Error: Not a type handle*/;
	}

	static int _202A_206D_206D_202B_200D_206C_206A_206D_202C_202E_206A_200B_206C_202B_206C_206E_206F_202E_200B_200E_200B_206C_200C_202E_200F_200E_206E_202B_200B_202A_200C_202C_202A_200D_200F_206A_200E_202D_200B_206E_202E(ref int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	static int _206D_200C_202A_200C_202C_202A_206C_202D_200E_206C_200D_200F_200F_200F_206A_200F_200E_200D_206A_200B_202A_202E_200C_200E_200D_202D_206D_202E_206B_200F_202C_206E_200E_200D_200D_200E_200F_202A_200D_206F_202E(ref int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}

	static bool _200D_202C_202A_206F_202E_200F_206F_206A_206E_206E_202C_200E_206D_206D_206D_206D_202C_206D_206D_202B_206D_206B_202B_200B_202B_206D_200C_202A_200F_206F_206F_202D_206D_206C_206D_200D_206F_202E_206E_202E_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x03
	}

	unsafe static void _206A_200F_206A_206C_206E_200B_206F_206F_200F_206B_206B_200D_206A_206A_206E_200E_206A_200F_206D_202C_200C_206D_202B_206E_200E_206F_200F_200F_206F_206E_202E_202A_202E_206D_206D_206E_200C_202E_202A_206E_202E(IDisposable P_0)
	{
		_ = (int)checked((ushort)(*unchecked((long*)(nint)/*Error near IL_0001: Stack underflow*/)));
		/*Error near IL_0003: Unknown opcode: 0xCC*/;
	}

	static int _206F_206D_206F_200F_206A_202A_200B_206B_206C_200F_206E_202E_202E_202C_200D_202D_206C_202D_206C_202A_200E_206C_202A_206D_202B_206C_206A_200F_206E_206F_200E_206E_200E_206D_202C_200C_200E_206F_206E_200C_202E(ref int P_0, int P_1)
	{
		//IL_0007: Expected O, but got I
		if (/*Error near IL_0005: Stack underflow*/ <= /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = ((Array)checked((nuint)/*Error near IL_0006: Stack underflow*/)).LongLength;
		/*Error near IL_0007: Unknown opcode: 0xBB*/;
	}

	static Delegate _200D_200D_202C_200C_202D_202D_206B_206C_202C_206E_202B_206C_202A_206E_202B_202E_202B_202B_200C_206F_202A_206E_206A_202A_202A_206A_202D_206B_202A_200C_200E_202D_202D_202D_200C_202E_202E_200B_202C_202E_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2F 0x7B
	}

	static Delegate _206F_200C_200E_200E_200F_200F_200E_200F_206B_206F_202D_206A_202C_202A_202C_206C_206D_206F_202C_206C_200D_206E_206D_202C_202B_200E_206D_206C_202B_206D_206F_202D_202A_206E_200D_200B_206E_202E_206F_206D_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF7 0xE3
	}

	static PropertyChangedEventArgs _206C_206D_202E_202B_206F_206E_200E_200B_202A_202D_206C_200F_202D_206F_202C_200C_202E_206F_206D_206A_206F_206C_202E_206F_206D_206B_200E_200F_202E_200C_206A_202B_200C_206B_206D_200D_200F_200D_200C_200F_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x10
	}
}
