using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;

public class _EOPSeQyj2EyN5h9AYValzGjTRAI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _UI6v0G2VwFjAM1Gs8w1DvuISr2i
	{
		public static readonly _UI6v0G2VwFjAM1Gs8w1DvuISr2i _003C_003E9;

		public static Func<_yirjcqLRhZxIR4SlHyCZc5P49wh, string> _003C_003E9__28_0;

		public static Func<_PvVCObo4iR3MW7vsG098iUS8QTi, string> _003C_003E9__28_1;

		public static Func<_BiXAyZkhn4U8Ge4fyh3hsENAAqU, string> _003C_003E9__28_2;

		public static Func<_6sVLI807UQETwYjU8f33xYHYscG, string> _003C_003E9__28_3;

		public static Func<_KON64vmS3jrPrPMe7FHgR0ybDOn, string> _003C_003E9__28_4;

		public static Func<_3QvgH9XL4srUBFaltCR2ytB9jgj, string> _003C_003E9__28_5;

		public static Func<_a58Mjdh3MgRj03uqoU8duoLFDGA, string> _003C_003E9__28_6;

		public static Func<byte, string> _003C_003E9__29_0;

		static _UI6v0G2VwFjAM1Gs8w1DvuISr2i()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFF 0x8E
		}

		public _UI6v0G2VwFjAM1Gs8w1DvuISr2i()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _1kDCTTiHKNmLVYXALZSARLqEeoZ(_yirjcqLRhZxIR4SlHyCZc5P49wh P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCD
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _7AbNqIbB7bCJmaXdAcuwkb5BvjZ(_PvVCObo4iR3MW7vsG098iUS8QTi P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x31
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _AXE7P6ESIDMCdIKgcga5aAXXM2f(_BiXAyZkhn4U8Ge4fyh3hsENAAqU P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x79
		}

		internal string _QCvxdDejB0oxAl5d7JgJLHCEORrA(_6sVLI807UQETwYjU8f33xYHYscG P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x64
		}

		internal string _9UFmF3OPpgzZjYySPrmGlClNdrA(_KON64vmS3jrPrPMe7FHgR0ybDOn P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x81
		}

		internal string _ZOsSNvHGG8ka0EP9X3X2p2pUC6O(_3QvgH9XL4srUBFaltCR2ytB9jgj P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0x2E
		}

		internal unsafe string _I3fuxMW0hYgxwjWDDvXjU01VO5x(_a58Mjdh3MgRj03uqoU8duoLFDGA P_0)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Expected F4, but got I4
			*(float*)(nint)/*Error near IL_0003: Stack underflow*/ = *(short*)(nint)checked(/*Error near IL_0001: Stack underflow*/ * /*Error near IL_0001: Stack underflow*/);
			throw /*Error near IL_0004: Stack underflow*/;
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _6bw3tzxxd0pnjkHetwn0WzAJiab(byte P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE7 0xDC
		}

		internal unsafe _yirjcqLRhZxIR4SlHyCZc5P49wh[] _ougAaQWgunAVLvw3yBCynLk8Iys()
		{
			_ = *(double*)(nint)/*Error: ldloc 3 (out-of-bounds)*/;
			/*Error near IL_0002: Invalid metadata token*/;
		}

		internal _PvVCObo4iR3MW7vsG098iUS8QTi[] _zWjRmgxeA5gCGJAyYl8Iq3bM1kK()
		{
			if ((int)/*Error: ldarg 2 (out-of-bounds)*/ == 0)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0002: Read out of bounds.*/;
		}

		internal _BiXAyZkhn4U8Ge4fyh3hsENAAqU[] _vKZkfTI1pTN30lxzOezAOsLtnXn()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x74
		}

		internal _6sVLI807UQETwYjU8f33xYHYscG[] _5kmulOizogkvBuyfInwGMOcGiTo()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x67 0xFB
		}

		internal _KON64vmS3jrPrPMe7FHgR0ybDOn[] _Zo5Mo65EXBiDsj94yr0j6MkXbWe()
		{
			_ = 7;
			/*Error near IL_0002: Read out of bounds.*/;
		}

		internal _Q2PFBTAKzTsrpdz0RiBlqXPorfM[] _e8y1XU7kASJWRHgRu45MNpRGpUf()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC1
		}

		internal _3QvgH9XL4srUBFaltCR2ytB9jgj[] _JXVARorNZMZ2KEiy5u3iVWWfjVh()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFD
		}

		internal unsafe _a58Mjdh3MgRj03uqoU8duoLFDGA[] _ErOPiMB293omEW3klsHqjlr1K3G()
		{
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xED*/;
		}

		internal string _Rnp3d9WyTcRcOgtjOFPM8mAyksb()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAD
		}

		static string _202A_206A_206E_206B_200D_202B_202C_202D_200E_200B_202B_200F_202D_206A_200E_202B_206C_200E_206F_206A_206C_202A_206A_206E_200B_206C_206C_206E_200B_202B_202C_206A_206A_202C_202D_202E_202E_202A_206F_200D_202E(string P_0, string P_1, string P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB9
		}

		static WindowsIdentity _202E_202A_206A_200C_202D_200E_200B_200F_200E_200F_206A_206A_206B_202C_206C_202C_206D_200F_202B_200E_206E_202A_206B_206F_202B_200E_202A_202C_202C_200F_200C_206A_206C_202B_206C_206E_206B_206B_206B_202E_202E()
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			if ((int)/*Error near IL_0002: Stack underflow*/ == 0)
			{
				/*Error: Invalid branch target*/;
			}
			checked
			{
				_ = (long)(/*Error near IL_0003: Stack underflow*/ & /*Error near IL_0003: Stack underflow*/);
				/*Error near IL_0004: Invalid field token*/;
			}
		}

		static SecurityIdentifier _200D_206B_206C_206B_206B_200B_202A_206D_202B_200B_200F_206A_202A_206F_200B_200E_200F_206F_206C_200F_202B_200B_200F_206B_200F_202B_202C_200D_206F_206C_206B_200B_202C_206A_200F_206B_200B_206E_202E_202E_202E(WindowsIdentity P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x19
		}

		static string _206B_206A_206F_202B_202E_200E_206F_202B_200E_202B_206F_200D_206A_200F_206F_202E_200C_202C_200C_206F_206E_200F_206B_206D_206E_200C_200F_200C_202C_200D_202E_206E_206C_206A_202D_206D_206F_202D_206E_202E(IdentityReference P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x41
		}
	}

	[CompilerGenerated]
	private sealed class _84antjbmJ53p5PwJ0K4EJwIlJ3H
	{
		public int _4bMbvBebKeX9c9iaBPhczLCdZDZ;

		public _84antjbmJ53p5PwJ0K4EJwIlJ3H()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal string _tkCTWRZtJ3WWKeDjxSwQaIRWHDC(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0xD7
		}

		static bool _206B_202D_206C_206F_200F_202E_206C_202A_202E_200F_206E_200F_206A_200B_206A_206A_200D_206B_206B_200E_202C_206E_200B_202B_206A_200E_200F_206E_202B_200D_206E_200F_200D_200F_200D_206C_206B_202A_202D_206F_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCF 0xAB
		}

		static string _202B_202E_200C_206B_200C_206C_206B_202E_200B_200C_202A_200E_200F_206A_202D_202D_206B_206A_206F_200F_206A_200B_206F_202A_200D_202A_206F_206C_202E_200E_200D_202B_202E_202B_200E_206F_200E_206F_206E_202E_202E(char P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9D
		}
	}

	private const string _9eA9IrWCExKgYatCCFBmOIZIRBS = "-";

	private static readonly Lazy<_yirjcqLRhZxIR4SlHyCZc5P49wh[]> _7cTAF9600UP7Xg3F3Kg3vQXnjXB;

	private static readonly Lazy<_PvVCObo4iR3MW7vsG098iUS8QTi[]> _9CgIVpI3O8ijYTCaKupbOnGS6QR;

	private static readonly Lazy<_BiXAyZkhn4U8Ge4fyh3hsENAAqU[]> _NkwYxNV3ep9OPOuOTuNaid5f1zj;

	private static readonly Lazy<_6sVLI807UQETwYjU8f33xYHYscG[]> _6QIxlfLvbStcz6plUdgdyCEWUWw;

	private static readonly Lazy<_KON64vmS3jrPrPMe7FHgR0ybDOn[]> _s79EIowaWBHDSpSTy9uxARfXG1H;

	private static readonly Lazy<_Q2PFBTAKzTsrpdz0RiBlqXPorfM[]> _6FDcx3TAyQDuFxrbNPHcpnmDq0jA;

	private static readonly Lazy<_3QvgH9XL4srUBFaltCR2ytB9jgj[]> _RGKNuO1AGGKPabrDE6fNPqIpwn1;

	private static readonly Lazy<_a58Mjdh3MgRj03uqoU8duoLFDGA[]> _LXgDHopl3uHBnA99TYl05jpCStDA;

	private static readonly Lazy<string> _gtoV256oq2nBYgnY7yoyCdW3t0M;

	public static _yirjcqLRhZxIR4SlHyCZc5P49wh[] _NRzBVWwT3nY7JoXb5jQ0U6N7vho
	{
		get
		{
			/*Error: Unknown opcode: 0xF4*/;
		}
	}

	public static _PvVCObo4iR3MW7vsG098iUS8QTi[] _VFXbROInXCi0LRJzYeHFoYK8qBm
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x48
		}
	}

	public static _BiXAyZkhn4U8Ge4fyh3hsENAAqU[] _fwUp3Gfdlws0GcasEAiAWEFHc1DA
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5D
		}
	}

	public static _6sVLI807UQETwYjU8f33xYHYscG[] _KsMgIByAlqLcjZU95y0GvxK9m2DA
	{
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0001: Stack underflow*/% /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: stloc 3 (out-of-bounds)*/;
			_ = (nuint)/*Error near IL_0003: Stack underflow*/;
			/*Error near IL_0003: Unknown opcode: 0xE2*/;
		}
	}

	public static _KON64vmS3jrPrPMe7FHgR0ybDOn[] _YqXBSfaW6QAAghuRrnnNyhO9JJbA
	{
		get
		{
			//IL_0002: Invalid comparison between Unknown and I
			if ((nint)/*Error near IL_0007: Stack underflow*/ < checked((nint)unchecked((uint)checked((short)/*Error near IL_0001: Stack underflow*/))))
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0007: Invalid metadata token*/;
		}
	}

	public static _Q2PFBTAKzTsrpdz0RiBlqXPorfM[] _A1HJooOK9r1Pi66Bx6OUyyHeHaf
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x76
		}
	}

	public static _3QvgH9XL4srUBFaltCR2ytB9jgj[] _LXa8fEGkLIUAsgwIRAZzdOuz4up
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}
	}

	public static _a58Mjdh3MgRj03uqoU8duoLFDGA[] _m0iFOSzJATjTX2A69LwRIJTXePf
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x53 0xB0
		}
	}

	public static string _kbvIOfBbtGrXQ221hgaZy1Zjewb
	{
		get
		{
			/*Error: Unknown opcode: 0xF3*/;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _tRtMHPu2ZXcq128UFnr43M3ovZD()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	private static string _3oXYQlXj0b8uC0FBMOvJBPmtfwD(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAC
	}

	public _EOPSeQyj2EyN5h9AYValzGjTRAI()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static _EOPSeQyj2EyN5h9AYValzGjTRAI()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x71
	}

	static string _200B_200F_200F_206C_202D_206B_206D_202A_200E_206F_206F_202C_202C_200C_200D_200D_206A_202E_200D_202E_200D_202C_202D_206B_206D_206D_206D_200E_202D_200B_200D_202D_200C_200D_202B_206B_200F_202B_206C_202E(string P_0, IEnumerable<string> P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE1
	}

	static string _206C_202B_200D_202A_202C_202B_202B_202B_202A_202C_206B_206F_200E_202B_206C_200D_202E_206D_202B_200F_200D_202A_206F_200E_206D_202A_206B_202E_206C_200F_200D_202D_206C_206E_202D_206F_200B_206B_206D_206A_202E(string P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	static string _206F_202A_206A_200C_206E_200D_202D_202B_202C_202D_200B_206F_206B_206D_206C_202D_202C_206B_202E_202E_206A_202D_200F_202B_206C_200D_202A_202B_200F_200E_202B_202D_206E_200F_206F_202E_206A_200D_200C_200D_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static Encoding _202E_202B_200C_202C_202D_202D_206A_200B_202E_206F_200D_206C_202E_202E_200E_200B_206B_200C_200B_206A_206B_200E_206D_202E_206C_200F_206C_200C_206A_200E_200B_200F_202E_206E_206C_202C_206D_200F_200E_200C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	static byte[] _202B_202A_206D_206A_200D_206C_200D_206B_202E_200C_202A_206A_206C_206C_202E_206C_200F_200F_206F_206F_200E_206E_206F_200E_200C_202D_200D_206E_202A_200F_200F_202E_206B_202A_200D_206A_206C_206E_200B_200C_202E(Encoding P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC5
	}

	static byte[] _206A_200E_202D_202D_200B_206B_200D_202C_206B_200E_200D_200F_200B_202B_200F_206D_202E_206D_200B_206F_202E_202E_206F_200F_202B_200E_206B_200B_202D_200D_200B_202A_206E_206D_206D_202B_206C_202B_200E_202D_202E(HashAlgorithm P_0, byte[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC1
	}
}
