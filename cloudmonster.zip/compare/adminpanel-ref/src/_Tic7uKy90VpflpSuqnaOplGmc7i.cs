using System;
using System.Runtime.CompilerServices;
using xNet;

public class _Tic7uKy90VpflpSuqnaOplGmc7i : NetException
{
	[CompilerGenerated]
	private readonly string _lwrm9kUAivLpE7QixfhllaT3QLb;

	public unsafe string _gVr57enwDRD12imcDviDQtdTOzq
	{
		[CompilerGenerated]
		get
		{
			_ = *(int*)checked((short)/*Error near IL_0001: Stack underflow*/);
			/*Error near IL_0002: Read out of bounds.*/;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _Tic7uKy90VpflpSuqnaOplGmc7i()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x23 0x8C
	}

	public _Tic7uKy90VpflpSuqnaOplGmc7i(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x07 0xF7
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public unsafe override string _JcA5cTOIzYiIo3H3fG6PU4hBVnt()
	{
		//IL_0006: Expected F4, but got I4
		//IL_001d: Expected I4, but got I8
		if (/*Error near IL_0002: Stack underflow*/ == /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		*(float*)(nint)/*Error near IL_0006: Stack underflow*/ = (int)checked((byte)unchecked((long)((float[])/*Error near IL_0003: Stack underflow*/)[/*Error near IL_0003: Stack underflow*/]));
		if (/*Error near IL_000b: Stack underflow*/ < /*Error near IL_000b: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		switch ((uint)checked((ulong)/*Error near IL_000c: Stack underflow*/))
		{
		default:
			/*Error: End of method reached without returning.*/;
		case 0u:
			/*Error: Invalid branch target*/;
		case 1u:
			/*Error: Invalid branch target*/;
		case 2u:
			/*Error: Invalid branch target*/;
		}
	}

	static string _202B_200C_206E_200B_200C_206A_200E_200F_200C_202B_206D_200D_206D_202B_202E_200F_200B_206D_202C_202E_200F_206A_200B_200C_206D_200F_202D_200E_206D_202C_200B_200F_202A_202D_206D_200D_206D_206A_200B_202D_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x78
	}

	static string _202E_206A_206F_202D_200D_202E_202A_200F_200B_206B_200E_206E_202E_202A_200B_202B_202D_206A_202D_202D_200D_206D_200D_202D_206C_200D_206C_206A_206F_200D_200F_200F_200E_200C_206C_200C_206C_200C_202C_202C_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}
}
