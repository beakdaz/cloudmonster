using System.Runtime.CompilerServices;

[_YdxudKVe7dAdpHWpcyUGFUMoyeE("Win32_BaseBoard")]
public sealed class _BiXAyZkhn4U8Ge4fyh3hsENAAqU : _xZMjw3DPALSdsBEjAsdeR57V0VA
{
	[CompilerGenerated]
	private string _wneuDK3DCEulfPPbtL2sj3cQtVLA;

	[CompilerGenerated]
	private string _Lb29QfGKVBFEJnpQY2uIHvU44Rh;

	[CompilerGenerated]
	private string _BomhOxmAcnumfrv8Fuqu1lPhDC4;

	[CompilerGenerated]
	private string _kTf8npXuRSfa50BIiVInhCjdKRt;

	[CompilerGenerated]
	private string _I0vaHOuhw0CAW6uSA0DqIwES8FX;

	[CompilerGenerated]
	private string _NY4ybrvo7QGxhUvIVwSmgUt5stE;

	[CompilerGenerated]
	private string _P2teFQjUF0Gwbu9vuj5yBrGXPCh;

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("SerialNumber", _ouek40mfEZcKAiuBOCraP5DTnRQ = true)]
	public string _hyT42trMGkdEbd3NQlrBtHvEQnA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x08
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8C
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Name")]
	public string _Ev9joibuDvZdlatvuqK8qww0H3N
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3F 0x26
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAD
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Model")]
	public string _MclCFJbl3tOBdizGXqhORJWRvjK
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x69
		}
		[CompilerGenerated]
		set
		{
			/*Error: Not a type handle*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Product")]
	public string _tJ61odJvIbtBdSGBOGwRxqOIf4B
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4C
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Caption")]
	public string _WVZCeL07h3KQ3QyLtbqAFyMsWVW
	{
		[CompilerGenerated]
		get
		{
			/*Error: Invalid metadata token*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x95
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Description")]
	public string _DkZtYjkrXDKwPFYK0JzcJALBDfJ
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xCB*/;
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xB2*/;
		}
	}

	[_2WWuZkVyeGvbWUepNxM3hrTLo0Q("Manufacturer")]
	public string _x9LQFtjAmgtdxpWocRgMLYM03Wz
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x88
		}
	}

	private _BiXAyZkhn4U8Ge4fyh3hsENAAqU()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF8
	}
}
