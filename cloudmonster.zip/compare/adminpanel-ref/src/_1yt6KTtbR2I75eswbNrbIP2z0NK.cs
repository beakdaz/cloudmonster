using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

[DefaultMember("Item")]
public sealed class _1yt6KTtbR2I75eswbNrbIP2z0NK : ICollection<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>, IEnumerable<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>, IEnumerable
{
	[CompilerGenerated]
	private sealed class _xAhIYsn1mz42uhE3TmHcG5fNX5D
	{
		public string _LChE7i9Bv1c4awjBiuZgQm3Xj9A;

		public _xAhIYsn1mz42uhE3TmHcG5fNX5D()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal bool _7gUjOA3lt0rt2o6dK55WV43GkWq(_hG2EdJQQbFzEpDbEbXP1KllPgBaA P_0)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0001: Stack underflow*/- /*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Not a type handle*/;
			}
		}

		static bool _206C_202E_202A_200D_200B_206C_200E_206B_202A_200C_200F_206D_202E_202C_202E_200E_206D_202A_206B_200D_206B_200B_206F_206E_200C_206B_200C_202E_206C_200D_206B_202C_200E_206A_206B_200D_206F_200D_202E_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}
	}

	[CompilerGenerated]
	private sealed class _mvKS9V5H71MDD2rMjSFq1jPDPAK
	{
		public string _LChE7i9Bv1c4awjBiuZgQm3Xj9A;

		public _mvKS9V5H71MDD2rMjSFq1jPDPAK()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal bool _vD2OkzeA9lTuitOeqjCwYWDi2uM(_hG2EdJQQbFzEpDbEbXP1KllPgBaA P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB5
		}

		static bool _202D_200D_200E_202A_206A_206B_206A_200C_200C_202D_206B_200C_202A_202B_206E_206F_206A_200E_202B_206C_202D_206F_202C_206A_202A_206D_206F_206B_206B_206A_206F_202B_202D_200B_202A_206B_206C_202A_200E_200D_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}
	}

	[CompilerGenerated]
	private sealed class _pjTHGQC1TVkqNueAPfGjriWTZum
	{
		public string _LChE7i9Bv1c4awjBiuZgQm3Xj9A;

		public _pjTHGQC1TVkqNueAPfGjriWTZum()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD4
		}

		internal bool _8JotRL3Sdr1xp3d1E34X4uOXFIc(_hG2EdJQQbFzEpDbEbXP1KllPgBaA P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x55
		}

		static bool _202A_202A_200C_200D_200E_200C_206E_206F_200B_202B_206E_206F_202C_202D_200C_206C_202A_202C_200E_200E_202D_202B_206E_202A_200E_202C_206A_200C_206F_202A_200C_202E_202C_202D_206A_200B_200B_206B_200E_206D_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}
	}

	private readonly List<_hG2EdJQQbFzEpDbEbXP1KllPgBaA> _dPHOjGKPyMyUcwUSQf9iLzRKRiB;

	public bool IsReadOnly
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
	}

	public int Count
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x28
		}
	}

	// C# has no syntax for parameterized property '_6iQrWjiGHcPmhRUzlPuIV50j3zB'.
	[MethodImpl(MethodImplOptions.NoInlining)]
	public _hG2EdJQQbFzEpDbEbXP1KllPgBaA _gQLdNrq85mKGHnEpXofpB1osQnf(string P_0, bool P_1 = true)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB8
	}

	public _1yt6KTtbR2I75eswbNrbIP2z0NK(IEnumerable<_hG2EdJQQbFzEpDbEbXP1KllPgBaA> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC1
	}

	public IEnumerator<_hG2EdJQQbFzEpDbEbXP1KllPgBaA> GetEnumerator()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x89
	}

	IEnumerator<_hG2EdJQQbFzEpDbEbXP1KllPgBaA> IEnumerable<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>.GetEnumerator()
	{
		//ILSpy generated this explicit interface implementation from .override directive in GetEnumerator
		return this.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		/*Error: Unknown opcode: 0xE7*/;
	}

	public void Add(_hG2EdJQQbFzEpDbEbXP1KllPgBaA item)
	{
		/*Error: Invalid metadata token*/;
	}

	void ICollection<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>.Add(_hG2EdJQQbFzEpDbEbXP1KllPgBaA item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Add
		this.Add(item);
	}

	public void Clear()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD0
	}

	void ICollection<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>.Clear()
	{
		//ILSpy generated this explicit interface implementation from .override directive in Clear
		this.Clear();
	}

	public bool Contains(_hG2EdJQQbFzEpDbEbXP1KllPgBaA item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE0
	}

	bool ICollection<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>.Contains(_hG2EdJQQbFzEpDbEbXP1KllPgBaA item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Contains
		return this.Contains(item);
	}

	public unsafe bool _e1ZDj2BFp75CLr7XHA58d3D0TXdb(string P_0)
	{
		//IL_0002: Expected I4, but got O
		//IL_0005: Invalid comparison between Unknown and I4
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		*(int*)(nint)/*Error near IL_0002: Stack underflow*/ = (int)System.Runtime.CompilerServices.Unsafe.Read<object>((void*)(nint)/*Error near IL_0001: Stack underflow*/);
		if ((int)/*Error near IL_000a: Stack underflow*/ > (int)checked((ushort)unchecked((uint)(-8))))
		{
			/*Error: Invalid branch target*/;
		}
		checked
		{
			_ = /*Error near IL_000d: Stack underflow*/+ ((object[])/*Error near IL_000c: Stack underflow*/)[System.Runtime.CompilerServices.Unsafe.Read<object>(unchecked((void*)(nint)/*Error near IL_000b: Stack underflow*/))];
			/*Error near IL_000d: Unknown opcode: 0xBE*/;
		}
	}

	public void CopyTo(_hG2EdJQQbFzEpDbEbXP1KllPgBaA[] array, int arrayIndex)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5D
	}

	void ICollection<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>.CopyTo(_hG2EdJQQbFzEpDbEbXP1KllPgBaA[] array, int arrayIndex)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CopyTo
		this.CopyTo(array, arrayIndex);
	}

	public bool Remove(_hG2EdJQQbFzEpDbEbXP1KllPgBaA item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC8
	}

	bool ICollection<_hG2EdJQQbFzEpDbEbXP1KllPgBaA>.Remove(_hG2EdJQQbFzEpDbEbXP1KllPgBaA item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Remove
		return this.Remove(item);
	}

	public bool _rT0ADohotbET7cYrJ2TGxJRG0gd(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x01
	}

	static string _200B_206F_200B_202C_200C_200E_206B_202A_206D_206D_200E_200B_206A_200C_202D_200D_206A_202B_206C_206A_206E_206C_206A_206D_206A_200B_202A_200B_206D_202C_200E_202A_206D_200F_200D_202C_200C_206C_202B_200F_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB9
	}

	static IndexOutOfRangeException _206F_202B_206F_202E_206A_202D_202D_202E_202B_202C_200B_202E_206A_200F_200D_202E_200C_206D_206E_202D_200F_202A_202A_200C_202B_206C_206B_202B_206C_206B_202D_206C_206D_200E_200D_206D_202B_200C_206C_200D_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xAF*/;
	}

	static NotImplementedException _202E_206B_206C_206C_206E_202E_202E_200E_206C_202C_206C_200F_206F_202C_202E_202B_200B_206E_202A_200B_202D_206B_200F_206C_202C_202B_202B_202B_206A_200C_206B_206D_206B_206E_202B_200B_200F_200F_206E_202C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}
}
