# Сравнение AdminPanel.release.exe ↔ наша сборка (Rust)

Эталон: `C:\Users\beakd\Desktop\AdminPanel.release.exe` (**2 572 288 байт ≈ 2,45 МБ**).  
Для контекста: `PhpMyAdmin.release.exe` — **2 349 056 байт ≈ 2,24 МБ** (тот же стек).

## Декомпил (только сравнение)

| Шаг | Инструмент | Результат |
|-----|------------|-----------|
| Очистка obfuscator | `G:\ReversingTools\newtools\de4dot-cex\de4dot.exe` | **Падает** на control-flow (как на PhpMyAdmin в `de4dot_output.txt`) |
| Декомпил | `ilspycmd -p` | **54 `.cs`**, 8 методов с битым IL (Invalid token / Read out of bounds) |

Выход:

- `G:\cloudmonster\compare\adminpanel-ref\src\` — AdminPanel  
- `G:\cloudmonster\compare\phpmyadmin-ref\src\` — PhpMyAdmin (для сравнения семейства)

## Что видно без полного de4dot

Из `AdminPanel.release.csproj` (ILSpy):

- **.NET Framework 4.8**, **WPF** (`UseWPF`, `WinExe`)
- **Framework-dependent**: в exe **нет** WPF/BCL — они берутся из **GAC / установленного .NET 4.8 на Windows**
- Зависимости в манифесте: **Newtonsoft.Json**, **xNet**, **HandyControl**, **LiveCharts**, **System.Management**, плюс встроенная/обфусцированная сборка `yAudPgjFFkzGKXcnECIYkePnBALv`
- **Нет** `curl`, **нет** отдельного MEGA/cloud SDK в строках exe
- HTTP-стек: типично **xNet** + BCL (`System.Net`), не reqwest/rustls

PhpMyAdmin.release — тот же каркас (net48 WPF, xNet, HandyControl, LiveCharts), другая obfuscated DLL.

## Почему ~2,5 МБ vs ~30 МБ у нас

| AdminPanel (оригинал) | Наша `export-*-gui` (Rust) |
|----------------------|----------------------------|
| Тонкий managed exe + obfuscator | **Статически слинкованный** нативный exe |
| WPF/TLS/HTTP — **из системы** | **eframe/egui**, **wgpu/OpenGL**, свой рендер |
| xNet + JSON + UI libs в IL | **tokio**, **reqwest**, **rustls** (+ куча crypto) |
| Один продукт, check + файлы | **pma-net** тянет **curl-impersonate** и **mega** даже в «не-cloud» GUI |
| Нет встроенного Rust runtime | Полный **Rust std + panic/unwind** |

**2,5 МБ — это не «весь продукт на диске»**, а только их exe при **установленном .NET 4.8**.  
**~30 МБ — это «всё в одном файле»**, что нормально для release Rust GUI с TLS и сетевым стеком.

Уменьшение нашего размера (если понадобится отдельно): отдельный бинарь AdminPanel **без** mega/curl, `strip`, LTO, `opt-level=z`, не тащить cloud в `pma-net` для mixed-checker — но это уже инженерия сборки, не копия оригинала.

## Ограничение декомпила

Код сильно обфусцирован (имена типов `_VnStztGqGXAcQrGS5PRImeh05aQ`, битые тела методов). Для **логики Good_/Error.txt** нужен рабочий de4dot/UnConfuserEx или ручной dnSpy — в `G:\ReversingTools\newtools\UnConfuserEx` есть исходники, но автоматический прогон здесь не доведён до clean IL.

Дальше по задаче AdminPanel-like UI достаточно **формата выхода** (`G:\RESULTS`) и **поведения**; полный реверс не обязателен.
