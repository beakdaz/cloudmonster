using System;
using System.Runtime.CompilerServices;
using System.Windows.Input;

public class _zDKxFKYm2SsAwcwMm1S8kCb29wN<_0001> : ICommand
{
	private readonly Predicate<_0001> _LeeEC1BpvqkKqPuhkIYnKZGjWwd;

	private readonly Action<_0001> _Bi2o7B0aB3Seu67lRjBQlwtm0gf;

	public event EventHandler CanExecuteChanged
	{
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD1
		}
		remove
		{
			/*Error: Invalid branch target*/;
		}
	}

	public _zDKxFKYm2SsAwcwMm1S8kCb29wN(Action<_0001> P_0)
	{
		/*Error: Invalid metadata token*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _zDKxFKYm2SsAwcwMm1S8kCb29wN(Action<_0001> P_0, Predicate<_0001> P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDD
	}

	public bool CanExecute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5F 0xEA
	}

	bool ICommand.CanExecute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CanExecute
		return this.CanExecute(parameter);
	}

	public void Execute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4D
	}

	void ICommand.Execute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Execute
		this.Execute(parameter);
	}

	static ArgumentNullException _200E_202B_200D_202B_200F_206F_206D_200C_200F_200F_206A_202C_206C_202C_206C_206C_206F_202E_206E_200F_206C_206A_206B_202B_202E_206E_200C_202A_206B_202A_206E_206C_206E_202C_202A_206B_206D_200C_200F_206F_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xEF*/;
	}

	static void _202E_202E_206D_202D_202A_206D_206E_206F_202B_200C_202E_206E_200E_200E_206A_206E_202E_202E_206C_206E_202C_202B_206C_202B_202D_206B_202E_200B_202D_206F_206D_200D_202B_202C_206B_202C_206D_202C_200F_200D_202E(EventHandler P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9D
	}

	static void _202A_202D_206E_202A_200F_206D_202C_206F_200E_200D_206E_200B_200C_206C_206B_206A_200D_202D_206D_202C_206B_202E_200C_200D_200C_206F_202A_200E_200C_200F_202B_200C_206C_206D_200D_206F_202B_202D_200D_200E_202E(EventHandler P_0)
	{
		/*Error: Invalid metadata token*/;
	}
}
public class _zDKxFKYm2SsAwcwMm1S8kCb29wN : ICommand
{
	private readonly Func<bool> _LeeEC1BpvqkKqPuhkIYnKZGjWwd;

	private readonly Action _Bi2o7B0aB3Seu67lRjBQlwtm0gf;

	public event EventHandler CanExecuteChanged
	{
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA3 0x75
		}
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x43 0xF9
		}
	}

	public _zDKxFKYm2SsAwcwMm1S8kCb29wN(Action P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _zDKxFKYm2SsAwcwMm1S8kCb29wN(Action P_0, Func<bool> P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF9
	}

	public bool CanExecute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x24
	}

	bool ICommand.CanExecute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CanExecute
		return this.CanExecute(parameter);
	}

	public void Execute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE1
	}

	void ICommand.Execute(object parameter)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Execute
		this.Execute(parameter);
	}

	static ArgumentNullException _206E_206D_206A_202E_200B_202B_206F_202C_200F_206E_200C_206B_206C_200D_202B_206A_202E_206D_202C_200C_202C_206B_206E_206E_202B_200F_206D_206E_202D_206D_202C_206B_202A_200D_206D_202B_202E_200D_206E_206C_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xEF*/;
	}

	static void _202D_202B_206A_206C_202E_202A_202E_206B_200F_200D_206E_200E_206E_202E_206B_202A_206D_200C_206B_202D_202A_200B_202E_202A_200D_206F_200D_206C_200E_206A_206F_202C_200C_202C_202D_206F_200D_202B_206A_202D_202E(EventHandler P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9D
	}

	static void _200F_206A_206D_200E_206D_200F_206C_202C_206A_206B_200F_202D_206A_206F_200E_202A_202C_206A_200F_202A_202D_206A_200E_200E_202A_206A_200D_202D_200E_202B_200E_200F_206F_206F_206B_200F_206A_206E_202C_202C_202E(EventHandler P_0)
	{
		/*Error: Invalid metadata token*/;
	}
}
