using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _3LBKzY64OpTHsVWd3iaEu1vldEe : INotifyPropertyChanged, _6kowxIyI5s2v3oeCKgG6VfVftqH
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _0yTvwSkUuEuKn04VaFnd3i38oZj
	{
		public static readonly _0yTvwSkUuEuKn04VaFnd3i38oZj _003C_003E9;

		public static Func<_G4HZl6xJwrcuDmIkPCZEv6KhSrN, Guid> _003C_003E9__14_0;

		static _0yTvwSkUuEuKn04VaFnd3i38oZj()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCF 0x4F
		}

		public _0yTvwSkUuEuKn04VaFnd3i38oZj()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal Guid _WaeQDNYJEsIgP7jxrVAdwMCzfvP(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}
	}

	private readonly ConcurrentQueue<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> _dCcu0lbe7uODZeSdyhGg0fZWneV;

	private readonly HashSet<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> _rdk6rVWoYCUcDMb68VyWM00VD4E;

	private int _axmXH1iNrcQDmg1X4Ifo9PbaN1K;

	[CompilerGenerated]
	private PropertyChangedEventHandler _arY7kwXO7ug04fWaROU2eJhjkKx;

	public int Current
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x88
		}
	}

	public bool IsEmpty
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0C
		}
	}

	public int Count
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x80
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC7 0x02
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _m6DAZ1ofdlOESdCeekTkQDtVNc4(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0xC4
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._m6DAZ1ofdlOESdCeekTkQDtVNc4(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _m6DAZ1ofdlOESdCeekTkQDtVNc4
		this._m6DAZ1ofdlOESdCeekTkQDtVNc4(P_0);
	}

	public void _FjJJ9ndeYmontKzxcRaA7MzWXTd(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._FjJJ9ndeYmontKzxcRaA7MzWXTd(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _FjJJ9ndeYmontKzxcRaA7MzWXTd
		this._FjJJ9ndeYmontKzxcRaA7MzWXTd(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _3bUY0p3zUFObETvZgyMcoYUmBTh(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3B 0xAD
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._3bUY0p3zUFObETvZgyMcoYUmBTh(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _3bUY0p3zUFObETvZgyMcoYUmBTh
		this._3bUY0p3zUFObETvZgyMcoYUmBTh(P_0);
	}

	public void _gZt8iGTZTXOBzcLskqjIlwoAqsW(_G4HZl6xJwrcuDmIkPCZEv6KhSrN[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4B 0x50
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._gZt8iGTZTXOBzcLskqjIlwoAqsW(_G4HZl6xJwrcuDmIkPCZEv6KhSrN[] P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _gZt8iGTZTXOBzcLskqjIlwoAqsW
		this._gZt8iGTZTXOBzcLskqjIlwoAqsW(P_0);
	}

	public bool _b1ZRGWNavyIHO2DWwOmklrT0kCE(out _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0xD1
	}

	bool _6kowxIyI5s2v3oeCKgG6VfVftqH._b1ZRGWNavyIHO2DWwOmklrT0kCE(out _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _b1ZRGWNavyIHO2DWwOmklrT0kCE
		return this._b1ZRGWNavyIHO2DWwOmklrT0kCE(out P_0);
	}

	public void _gnCc21dXnVllE4PFosTLplU4rHE()
	{
		/*Error: Invalid field token*/;
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._gnCc21dXnVllE4PFosTLplU4rHE()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _gnCc21dXnVllE4PFosTLplU4rHE
		this._gnCc21dXnVllE4PFosTLplU4rHE();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _jzojlHFawgR2a37stEoWW9tukDJ()
	{
		if (/*Error near IL_0002: Stack underflow*/ > /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = -24421010f / (float)Math.PI;
		/*Error near IL_0007: Unknown opcode: 0xE9*/;
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._jzojlHFawgR2a37stEoWW9tukDJ()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _jzojlHFawgR2a37stEoWW9tukDJ
		this._jzojlHFawgR2a37stEoWW9tukDJ();
	}

	protected virtual void _sl4k5NzeijBrxuHECAXWFnCh2qd(string P_0 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	public _3LBKzY64OpTHsVWd3iaEu1vldEe()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC3 0x57
	}

	static int _200B_202E_200E_206D_206D_202E_206C_202C_202C_202E_200D_202E_202A_206A_200E_202C_200E_206A_202E_202E_202C_202D_200B_202A_202E_200D_202C_202C_202A_202B_206B_206C_206B_200F_202A_200C_200E_206C_200F_200C_202E(ref int P_0)
	{
		/*Error: Unknown opcode: 0xFD*/;
	}

	static int _200D_206F_206C_200F_202C_200F_206D_200F_206E_206E_206A_206A_200F_200C_202C_206D_200D_200C_206D_206D_200B_202A_200B_200C_202D_202D_202E_206A_206D_206C_200F_202C_206B_202A_202A_202A_200B_200E_206C_202B_202E(ref int P_0)
	{
		checked
		{
			_ = (int)(ref P_0);
			/*Error near IL_0002: Unknown opcode: 0xA7*/;
		}
	}

	static bool _206A_200D_200B_202D_202A_200E_202C_206F_206E_202C_202B_206B_200D_202B_206D_200F_200B_200F_206D_206C_200B_202C_202D_200D_206E_206A_202A_200B_202A_200D_200C_206F_200C_200C_202B_200E_202C_206D_200F_200E_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static void _200E_200C_202D_200C_200E_206A_200D_202A_206D_206D_200C_202A_202B_206F_202B_206B_206E_202D_200E_200F_206F_200F_202D_206B_200F_202D_206D_200D_206E_202C_200B_206D_202D_202E_206E_202D_200D_206D_200C_206A_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	static int _200B_202E_206C_206F_206A_206D_200D_202E_206B_202D_202C_200D_206F_206C_206D_206A_202A_206D_202E_200C_200B_206F_200B_206F_200E_206E_202A_206E_200C_200C_206E_206E_200F_202C_202D_200B_206B_200E_202D_202D_202E(ref int P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x27 0x65
	}

	static Delegate _206B_206C_202C_206F_206B_206B_206F_202D_200D_206B_206C_206E_206C_206E_200F_206F_202B_202D_200E_202C_202A_200E_200F_200E_206E_206B_206D_206B_200C_202B_200D_202E_206D_202A_206A_206D_200F_200B_202A_206B_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static Delegate _202B_200E_206D_202A_206B_200C_200E_202C_206E_202B_202E_206D_202C_206A_200C_200F_206C_202B_200C_202B_200D_206B_206C_206A_206E_200C_200B_206F_206C_202E_202E_206F_200C_206F_206F_202D_202E_206B_200C_202A_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static PropertyChangedEventArgs _200F_206D_202C_200F_200F_206C_202A_202D_202D_200F_202E_200E_200C_200E_200F_202B_202E_200C_200F_206D_206A_200D_202E_206B_200B_206B_206F_200C_200B_202C_206F_206F_202E_202C_206E_200E_202A_202B_206A_202C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}
}
