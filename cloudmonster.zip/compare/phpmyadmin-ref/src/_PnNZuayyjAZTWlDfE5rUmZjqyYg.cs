using System;
using System.Runtime.CompilerServices;

internal class _PnNZuayyjAZTWlDfE5rUmZjqyYg : _rK4z9b9leVLLJQwFvCMNZmVAKFM
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _S5mXlZbbiQAnLLYxWstsA3Rzgwk
	{
		public static readonly _S5mXlZbbiQAnLLYxWstsA3Rzgwk _003C_003E9;

		public static Func<char, bool> _003C_003E9__28_0;

		static _S5mXlZbbiQAnLLYxWstsA3Rzgwk()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD8
		}

		public _S5mXlZbbiQAnLLYxWstsA3Rzgwk()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal bool _ic8AdEmZ70Z6yVS5jW3lJPgLYPe(char P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6D
		}
	}

	[CompilerGenerated]
	private string _LEyQi5MRv8SSgtXLCw6F3Mu2zvD;

	[CompilerGenerated]
	private int _dgnPAiQHzjlz86tsasKcyRQXuzQ;

	[CompilerGenerated]
	private int _yBWPRsZJDfVpMjDEsfjRiExWZ8F;

	[CompilerGenerated]
	private int _Z2kZ9JJfpHM9OancGhWPz1qbZkD;

	[CompilerGenerated]
	private Uri _0pkXJH4Hq0iizIV5GUfVewqYXJB;

	[CompilerGenerated]
	private string _tTSsoM2T1NJdTKlINstMlNqbmhx;

	[CompilerGenerated]
	private string _ptEbVarFCospGmenlxLJQHqPFT9;

	public string _eaoBAdVCPFyZIM8mDx28SCXwEw1
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6D
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB4
		}
	}

	public int _iO0Mz10j4WWZ1vG7LBOz7sWUSSd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDF 0xB9
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x740D5828
		}
	}

	public int _XmYAk4f8tC1yaxh0zKqIBa6hwxW
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAF 0xBD
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE5
		}
	}

	public int _pEN74VIfhMSJ1TM8RHM1gtTG7Y
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCC
		}
		[CompilerGenerated]
		set
		{
			/*Error near IL_0001: Invalid metadata token*/;
		}
	}

	public Uri _wUlbppWeoXmPhylNJk3RByD4rpKA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x70
		}
		[CompilerGenerated]
		private set
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0001: Stack underflow*/^ /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xE9*/;
		}
	}

	public string _H9OjuT0PSK2aIX8qC6gL0EeJp5cA
	{
		[CompilerGenerated]
		get
		{
			/*Error: Invalid metadata token*/;
		}
		[CompilerGenerated]
		private set
		{
			/*Error: Unknown opcode: 0xED*/;
		}
	}

	public unsafe string _myFqcAsWVO6oKLldX1GeGpHfYRT
	{
		[CompilerGenerated]
		get
		{
			//IL_0003: Expected F4, but got I8
			*(float*)(nint)/*Error near IL_0003: Stack underflow*/ = checked((long)((sbyte[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]);
			/*Error near IL_0003: Handle with invalid row number.*/;
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x65
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public bool _peIMkkUB49hMDmauPUhLROcraYA(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	bool _rK4z9b9leVLLJQwFvCMNZmVAKFM._peIMkkUB49hMDmauPUhLROcraYA(string P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _peIMkkUB49hMDmauPUhLROcraYA
		return this._peIMkkUB49hMDmauPUhLROcraYA(P_0);
	}

	public virtual string _5RU6m6RQWG9zt0PKA8ncfFUmRLC()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEB 0xCF
	}

	string _rK4z9b9leVLLJQwFvCMNZmVAKFM._5RU6m6RQWG9zt0PKA8ncfFUmRLC()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _5RU6m6RQWG9zt0PKA8ncfFUmRLC
		return this._5RU6m6RQWG9zt0PKA8ncfFUmRLC();
	}

	public _PnNZuayyjAZTWlDfE5rUmZjqyYg()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static string _202D_200E_200D_200C_200F_206C_206C_206F_202B_202B_206B_202C_200C_200D_202C_200C_206C_202D_200B_206C_200B_206A_206E_200F_206B_202D_202C_200B_206C_200D_206F_206D_202A_206C_200C_206F_206B_200B_206B_206D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x77
	}

	static bool _200F_200E_202D_206A_200C_206C_202A_200D_206E_200F_202D_202C_202A_202A_200F_202B_200B_200F_206C_200F_202E_200B_200F_200F_202C_206B_206E_202C_202D_202D_202A_206C_202D_202B_202C_200B_206E_202B_200C_202A_202E(string P_0)
	{
		/*Error: Invalid field token*/;
	}

	static bool _206A_200C_206D_200C_206F_206B_202D_206B_206C_206A_202C_200B_200D_206F_200E_206A_206B_206A_206D_200F_206A_206D_206A_200F_200C_206D_206E_206D_206B_206F_202D_206F_200F_206B_200E_200F_200E_206C_206D_206E_202E(string P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static int _200E_202C_206B_206A_202C_200D_206B_200B_200C_202C_200C_206E_202E_206A_202E_200F_200E_202A_206E_206E_200D_206D_206E_200D_202D_202C_206F_200C_202A_200F_202C_206A_202E_200B_202A_202B_206B_206D_206A_202B_202E(string P_0, char P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x55
	}

	static int _202B_206E_200D_202A_202C_206D_200B_202A_206C_200F_206F_202B_200B_200F_202D_200C_206A_202E_202D_200E_206B_200C_206B_206E_200B_202C_206D_206B_206F_206D_206E_202A_200F_200F_206D_200E_206F_206D_200B_202E_202E(string P_0, char P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xD6D28C99
	}

	static string _202E_202B_200D_200D_206E_206D_202B_202E_200C_200D_202D_202D_206A_200D_206C_206B_200C_206C_202D_200D_202E_206B_206B_200E_206F_202D_200E_200E_200E_206B_206C_202C_206B_200E_202A_200B_200C_206C_200E_200C_202E(string P_0, int P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x55
	}

	static bool _202A_206A_200B_206D_202B_202B_206F_200F_202E_206E_202C_200F_200E_206C_206D_200E_200B_200F_202B_202E_200D_206B_206F_200B_202C_200B_202A_200C_200F_200D_206C_200B_200E_202B_206D_202D_200C_206A_206E_202D_202E(string P_0, UriKind P_1, ref Uri P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2C
	}

	static string _202C_202C_200B_202D_206F_206F_202A_200C_206D_206E_206D_200C_202E_202A_206F_206A_200E_202E_206A_202C_206B_200F_202B_200B_200F_202D_202C_200D_202E_206A_206D_200C_202A_206B_206B_202E_202C_200D_206F_200D_202E(string P_0, int P_1)
	{
		_ = (double)/*Error near IL_0001: Stack underflow*/;
		_ = 3uL;
		/*Error near IL_0004: Not a type handle*/;
	}

	static string _206E_206C_202C_200C_200B_200B_200B_206F_202A_202D_206B_202C_202C_206E_206F_202E_200E_202A_206B_202E_202B_200B_200E_200B_202A_200D_206F_202D_206C_206F_206A_202C_206E_202D_206B_202B_200F_202A_200D_200F_202E(string P_0, char[] P_1)
	{
		/*Error: Invalid branch target*/;
	}
}
