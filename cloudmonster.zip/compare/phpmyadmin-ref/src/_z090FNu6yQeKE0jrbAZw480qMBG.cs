using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_NetworkAdapter")]
public sealed class _z090FNu6yQeKE0jrbAZw480qMBG : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _iZJQPpwCaYDJsUTp3fwCm5e2tPi;

	[CompilerGenerated]
	private string _2BiPiSFTMBS9wDqohxXLtXfHZ1c;

	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _RSen2ZwPqotFSflgOZEpUTa7cXb;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _GY4psKbPb2ENWoasbIPAdAiEloR;

	[CompilerGenerated]
	private string _2gMQb1WNVgTJjah6KsKh4xJVIbf;

	[CompilerGenerated]
	private string _IR4UikgDdp8PuDPgCYLoVBhsdaV;

	[CompilerGenerated]
	private ushort _oKBYIwI4WT9CdyQpYygpYTTHVpF;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("MACAddress", _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true)]
	public string _DZDZz1MjAMj3tRmfNMlcaJ57syG
	{
		[CompilerGenerated]
		get
		{
			/*Error: Invalid metadata token*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3B 0x14
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("PNPDeviceID", _z9iGSNwAHN9WJNl40wnjovc9b6g = true, _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true)]
	public string _XQyaOXQZ5TUuzxjNDpcGpdH1d1v
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3B 0xA2
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name")]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x85
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x49
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Caption")]
	public string _VaEBso6OOri1y0w9IQvg5zajb6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6B 0x96
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public unsafe string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB4
		}
		[CompilerGenerated]
		set
		{
			System.Runtime.CompilerServices.Unsafe.Read<object>((void*)(nint)/*Error near IL_0001: Stack underflow*/);
			/*Error: End of method reached without returning.*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("ProductName")]
	public string _kCgthhxB7piALPU6IiSVCl9vd9P
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x84
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xCB*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("ServiceName")]
	public string _iFxlRe1bhyF43BWtqseh3FjHVGC
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5B 0x22
		}
		[CompilerGenerated]
		set
		{
			/*Error: Invalid metadata token*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Manufacturer")]
	public string _2LGcfWg9irJpfYK5B4taNm2rHsG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC9
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0F 0xE2
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("AdapterTypeId")]
	public ushort _iB6dLMt6kOnEjLg8DWwB7PiTTDd
	{
		[CompilerGenerated]
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Invalid comparison between Unknown and I4
			_ = /*Error near IL_0001: Stack underflow*/- /*Error near IL_0001: Stack underflow*/;
			if ((int)/*Error near IL_0001: ldloc 1 (out-of-bounds)*/ != 2)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0008: Read out of bounds.*/;
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0x77*/;
		}
	}

	protected override bool _7XSaEtGveaNphRXPJp1DwZ53W8u
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA9
		}
	}

	private _z090FNu6yQeKE0jrbAZw480qMBG()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}

	static bool _202C_200D_202B_202C_200F_200D_202D_206A_206C_202C_206B_202E_206D_202C_206E_202D_206D_200C_206D_202C_202C_202A_206D_200B_200F_206B_206D_202E_202B_202E_206E_206E_202E_202D_200C_202C_206E_200E_202E_200C_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAC
	}
}
