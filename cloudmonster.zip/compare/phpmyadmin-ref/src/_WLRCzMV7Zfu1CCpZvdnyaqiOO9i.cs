using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _WLRCzMV7Zfu1CCpZvdnyaqiOO9i : INotifyPropertyChanged, _6kowxIyI5s2v3oeCKgG6VfVftqH
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _wg2TqSsfitGSYfecPYfVDhZGprc
	{
		public static readonly _wg2TqSsfitGSYfecPYfVDhZGprc _003C_003E9;

		public static Func<_G4HZl6xJwrcuDmIkPCZEv6KhSrN, Guid> _003C_003E9__15_0;

		static _wg2TqSsfitGSYfecPYfVDhZGprc()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x13 0xDA
		}

		public _wg2TqSsfitGSYfecPYfVDhZGprc()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal Guid _ksDWMWpnfBsZbpxLVCVMPIg3DsE(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}
	}

	private readonly object _1K7uJdKBiZuEm8DCFNdS1GKR0m2A;

	private readonly List<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> _rdk6rVWoYCUcDMb68VyWM00VD4E;

	private int _rHMpcbZXyn1dgpzb4C07mkKLyZQ;

	private int _axmXH1iNrcQDmg1X4Ifo9PbaN1K;

	[CompilerGenerated]
	private PropertyChangedEventHandler _arY7kwXO7ug04fWaROU2eJhjkKx;

	public int Current
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}
	}

	public bool IsEmpty
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x53 0xBD
		}
	}

	public int Count
	{
		get
		{
			/*Error: Invalid field token*/;
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEF 0x6A
		}
		[CompilerGenerated]
		remove
		{
			_ = -1.1739259E-32f;
			_ = -111;
			/*Error near IL_0007: starg 248 (out-of-bounds)*/;
			/*Error near IL_0009: Unknown opcode: 0xE5*/;
		}
	}

	public void _m6DAZ1ofdlOESdCeekTkQDtVNc4(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._m6DAZ1ofdlOESdCeekTkQDtVNc4(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _m6DAZ1ofdlOESdCeekTkQDtVNc4
		this._m6DAZ1ofdlOESdCeekTkQDtVNc4(P_0);
	}

	public void _FjJJ9ndeYmontKzxcRaA7MzWXTd(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._FjJJ9ndeYmontKzxcRaA7MzWXTd(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _FjJJ9ndeYmontKzxcRaA7MzWXTd
		this._FjJJ9ndeYmontKzxcRaA7MzWXTd(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public unsafe void _3bUY0p3zUFObETvZgyMcoYUmBTh(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		checked
		{
			_ = /*Error near IL_0006: Stack underflow*/+ *unchecked((long*)85);
			/*Error near IL_0006: Unknown opcode: 0xB2*/;
		}
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._3bUY0p3zUFObETvZgyMcoYUmBTh(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _3bUY0p3zUFObETvZgyMcoYUmBTh
		this._3bUY0p3zUFObETvZgyMcoYUmBTh(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _gZt8iGTZTXOBzcLskqjIlwoAqsW(_G4HZl6xJwrcuDmIkPCZEv6KhSrN[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x78
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._gZt8iGTZTXOBzcLskqjIlwoAqsW(_G4HZl6xJwrcuDmIkPCZEv6KhSrN[] P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _gZt8iGTZTXOBzcLskqjIlwoAqsW
		this._gZt8iGTZTXOBzcLskqjIlwoAqsW(P_0);
	}

	public bool _b1ZRGWNavyIHO2DWwOmklrT0kCE(out _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		/*Error: Unknown opcode: 0xFD*/;
	}

	bool _6kowxIyI5s2v3oeCKgG6VfVftqH._b1ZRGWNavyIHO2DWwOmklrT0kCE(out _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0)
	{
		//ILSpy generated this explicit interface implementation from .override directive in _b1ZRGWNavyIHO2DWwOmklrT0kCE
		return this._b1ZRGWNavyIHO2DWwOmklrT0kCE(out P_0);
	}

	public void _gnCc21dXnVllE4PFosTLplU4rHE()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._gnCc21dXnVllE4PFosTLplU4rHE()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _gnCc21dXnVllE4PFosTLplU4rHE
		this._gnCc21dXnVllE4PFosTLplU4rHE();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _jzojlHFawgR2a37stEoWW9tukDJ()
	{
		if (/*Error near IL_0005: Stack underflow*/ != /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0005: Read out of bounds.*/;
	}

	void _6kowxIyI5s2v3oeCKgG6VfVftqH._jzojlHFawgR2a37stEoWW9tukDJ()
	{
		//ILSpy generated this explicit interface implementation from .override directive in _jzojlHFawgR2a37stEoWW9tukDJ
		this._jzojlHFawgR2a37stEoWW9tukDJ();
	}

	protected virtual void _sl4k5NzeijBrxuHECAXWFnCh2qd(string P_0 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x23 0x07
	}

	public _WLRCzMV7Zfu1CCpZvdnyaqiOO9i()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0x4E
	}

	static void _206D_202C_202B_206D_206B_206D_202B_202D_200F_202C_206D_206F_200C_200E_206C_202B_200D_206D_200E_206C_202D_200B_200D_202A_202A_202E_200D_202B_202D_202B_202A_206C_202D_202A_206B_206A_200C_200B_206C_200C_202E(object P_0, ref bool P_1)
	{
		/*Error: Unknown opcode: 0xE1*/;
	}

	static void _206A_206E_206A_202C_202B_200C_202E_206C_202E_200D_206C_200C_206E_206C_202B_200D_200D_202E_206F_206E_202C_206A_206B_202D_202B_202A_206A_206B_206E_200E_200E_202D_202E_206B_200B_206F_202A_200E_200D_200E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x01
	}

	static int _206E_202B_202D_200B_200F_200B_202B_200E_206E_202E_206E_202D_202E_206B_206D_202B_206A_202C_202C_202C_206F_206A_200E_206D_202D_200C_202B_202E_200D_206A_202D_200F_200C_200D_200D_200D_200D_202A_202D_200F_202E(ref int P_0)
	{
		checked
		{
			_ = (int)(ref P_0);
			/*Error near IL_0002: Unknown opcode: 0xA7*/;
		}
	}

	static bool _200B_202A_200F_202C_202D_200E_206E_200F_206C_202B_200C_202A_202D_202A_200B_202B_206B_200C_202B_202A_206A_200B_202A_206F_206C_200D_206C_206D_200B_206F_200F_206D_202A_206D_202A_206F_206D_200E_206E_202C_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static void _206D_200F_200C_202A_200B_202E_206C_202B_206B_200B_200D_202E_200C_202B_206C_202D_202C_200F_206F_200B_200B_206D_206C_206B_206F_206D_200F_200B_206A_206B_200F_202D_206D_206A_202A_206D_200B_202A_200B_200F_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	static void _206A_206B_200C_200B_202C_206D_202E_206A_206F_202D_202D_202E_202C_202D_206B_206C_206B_202A_200C_206D_206F_200E_206C_206A_202C_202C_200E_202E_200F_206B_200B_206E_200C_206E_200B_206B_202B_202B_200B_200E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2C
	}

	static int _200B_200F_206C_200D_202D_202B_202C_202C_200D_206F_206D_202D_202E_200F_202C_206D_202D_206A_200F_200C_202E_200D_200E_202C_200B_200B_202D_206C_202A_202E_202D_200C_202C_200B_206E_206E_202E_202E_206A_200F_202E(ref int P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x27 0x65
	}

	static Delegate _202E_200F_206C_202E_200F_206F_202E_200C_200C_206B_200E_206C_200B_206C_200C_200E_200C_206E_206A_206E_200C_200F_202A_200F_202C_202E_200F_200E_206F_202C_206A_206C_206F_200F_202E_206C_202C_200B_202E_200F_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static Delegate _202C_200F_200D_206E_206C_206B_206C_200F_206C_200D_200D_206A_200F_202D_206A_200C_202B_206D_200E_206B_202B_206D_200C_206E_202A_206E_206E_206C_206A_200E_200B_206A_202C_200D_206D_206D_200C_206B_200D_200C_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static PropertyChangedEventArgs _200D_206F_200E_202A_200C_200C_200F_202A_200F_202E_206F_202C_200E_202C_206C_206E_200D_206A_200E_200C_202A_202E_206B_206C_206C_206D_202D_202E_206A_200B_206C_200E_206D_200C_202E_200E_206A_206F_200F_202D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}

	static object _200D_206F_202D_206B_206A_202D_206C_202B_206A_206E_202D_206A_206D_200B_206C_206C_200C_202C_200F_202E_202A_206A_202C_200B_206D_206C_200E_206B_206D_202B_206A_202D_200F_202C_202A_200D_200F_206F_206C_202D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}
}
