using System;
using System.Runtime.CompilerServices;
using xNet;

internal class _tzYCdx01jabRi9YINoZruASmPDF : _xULUmRrI4p3f9lVXdlb81HoogZB
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _vKxCgicHgyoIbcIYpRcikE2gcOLA
	{
		public static readonly _vKxCgicHgyoIbcIYpRcikE2gcOLA _003C_003E9;

		public static Func<Cookie, bool> _003C_003E9__3_0;

		public static Func<Cookie, bool> _003C_003E9__3_1;

		static _vKxCgicHgyoIbcIYpRcikE2gcOLA()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}

		public _vKxCgicHgyoIbcIYpRcikE2gcOLA()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal bool _Dm5cI5sql9ISdyJG6jjYMwc4LyL(Cookie P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE4
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal bool _SJmjiunvcowz2r8qQV35lARnqhC(Cookie P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x48
		}

		static string _200F_206A_200B_200E_200E_202C_206D_202A_206F_206C_200F_202A_200C_200C_200F_206C_200B_200B_200B_202C_200F_202C_202C_206A_202E_200F_200D_200E_202C_206D_206D_206F_206B_202A_200D_200F_202E_200F_200C_206A_202E(Cookie P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0x87
		}

		static bool _200C_206E_200C_200B_200B_200E_202D_200D_200E_200B_200B_200F_202C_200F_200E_206D_200F_202D_202C_206A_206E_202C_206E_200F_202D_202A_202B_202C_200F_200C_200C_202E_200C_200E_200C_200D_206B_202E_200B_206B_202E(string P_0, string P_1)
		{
			/*Error: Unknown opcode: 0xE8*/;
		}

		static string _202A_202D_206B_206D_200D_206D_200F_200C_202E_202A_200E_202E_202A_200F_202C_202E_202A_206E_200F_206E_202B_200E_202D_200F_206C_206A_202C_200E_200F_200E_202A_206B_200E_200D_200B_206D_206F_206B_200D_206B_202E(Cookie P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE5
		}

		static bool _206D_200B_206E_202B_202D_202D_200C_200B_202A_202C_206A_200B_206D_200B_202C_206B_202A_202D_200D_200C_200B_202C_202D_202D_206B_202E_206B_206B_200B_202C_200E_206A_206C_206F_206C_206C_200D_206F_200F_200C_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA8
		}
	}

	[CompilerGenerated]
	private sealed class _8HbdULdKR6g1rnNQd00UmkWCbdP
	{
		public _EaiOCf05DLIbS55fQPcFQp389wO _bJdrEjnENY7j2pIAt0vBi4kBf0D;

		public _8HbdULdKR6g1rnNQd00UmkWCbdP()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _GHIuIE0xd4Sz3MUAxWIEqwAgk7dA(object P_0, DownloadProgressChangedEventArgs P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDF 0xA2
		}

		static long _200E_206C_200D_200D_202D_200B_202C_206E_202C_202B_200B_202C_200D_200C_202A_202D_200C_202D_202B_206B_206B_202B_200E_206C_206E_200C_200D_206A_206D_200F_206C_206F_202D_202E_202E_200B_206C_200B_200E_206F_202E(DownloadProgressChangedEventArgs P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDB 0xFC
		}
	}

	private string _S6QAklLL2Ug2pcuDnPDpDtJfiHX;

	private bool _iITih8YZDWbvEvuaTfZUsABtXeA;

	public _tzYCdx01jabRi9YINoZruASmPDF()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFC
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _WzzQf3bdg5M1xPP01AThAAOmtij _ah9rKousfjUi3Jopq18JbdslERH(Uri P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x29
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void _OLeauqCkKcHDDKXkjjKVrEjhZi2(string P_0, _EaiOCf05DLIbS55fQPcFQp389wO P_1)
	{
		/*Error: Invalid branch target*/;
	}

	static string _206C_200E_206D_202B_200D_202A_202A_200F_206D_200B_200F_202E_206B_202A_206D_202B_202E_206E_206F_206F_206D_200D_206C_200F_202E_206C_200E_200E_200C_206A_202E_200F_206B_206F_200F_202D_200C_206F_206B_202B_202E(Uri P_0)
	{
		/*Error: Invalid branch target*/;
	}

	static bool _200D_202D_200E_200C_206D_200C_202A_200E_206C_200F_202E_202D_200D_206A_206B_202B_202B_200F_200C_206D_200C_202B_206B_200F_202D_200F_206B_202D_202E_202B_202D_202C_202B_202E_200F_200E_200F_206E_200B_200F_202E(string P_0, string P_1)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static bool _200F_202C_200F_206F_206D_206A_202A_206C_200D_202D_202A_200B_200E_200E_206A_206C_202D_202E_202A_202B_200C_206E_200E_200E_206B_200D_206A_206A_200D_206E_206D_206A_206A_202C_206D_202E_202E_202E_202E_200F_202E(string P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static int _202B_202E_200C_206C_202A_202E_200E_206D_202A_200F_202A_200F_202C_200B_200B_202C_202A_206F_206E_200E_202D_206B_202A_206A_202E_200D_206D_206B_202A_202E_200E_200D_206E_200D_206B_206C_200B_200B_206D_206D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x70
	}

	static void _206D_200E_206B_202B_202D_206B_206A_202B_202D_200E_202B_206E_206E_206A_206A_206A_206C_202B_200F_206C_202B_206B_206D_202C_202E_202D_200F_202A_206B_206D_206F_202C_206B_200F_200E_202D_206A_206E_202A_202D_202E(HttpRequest P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static HttpRequest _206F_202C_206E_206E_200D_206E_200D_200C_206C_200D_202B_202D_206B_202D_206F_200E_202C_202E_202D_200F_200E_202E_202D_200B_206A_202C_200C_202A_206D_202A_202E_200C_202E_206E_206C_202D_206B_202E_206F_202E(HttpRequest P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1F 0xD5
	}

	static HttpResponse _200F_200D_206F_202A_206F_200D_200D_200B_206E_202E_202D_202B_202E_206D_202C_206F_200F_202E_206D_200B_200E_206A_202D_202C_202A_206F_206B_200E_200B_202C_206B_200B_200C_202B_202D_206F_206E_206C_206D_202D_202E(HttpRequest P_0, Uri P_1, RequestParams P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}

	static string _200D_202C_206F_206A_200E_206B_202E_206D_206D_206A_206B_206F_200C_202B_202D_200D_206F_206D_200E_202E_202D_200D_206F_200D_206D_200F_206A_202D_202A_200C_206C_206A_202E_200D_200B_202A_202B_202C_200B_200E_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static HttpResponse _206B_206C_206F_206C_200D_200B_206A_200C_200F_206B_202B_200E_202C_202B_206F_206B_206F_202C_206C_206E_200B_206A_206D_202C_202D_206F_202E_202B_206A_200F_202A_202E_206A_206E_206A_202C_200C_206F_200B_206E_202E(HttpRequest P_0)
	{
		/*Error: Invalid field token*/;
	}

	static HttpStatusCode _206F_202D_200F_206E_202E_202A_206A_200B_206E_200C_206F_200E_200F_202E_206C_206B_200B_200B_202D_206E_206F_202D_200E_202B_206E_206F_206D_200D_206C_206A_206F_200D_206F_206A_206B_200F_206E_200F_202E_206F_202E(HttpResponse P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1B 0xA1
	}

	static bool _200B_206D_206E_206B_200B_202B_200B_200C_206C_200F_206D_200D_206D_200F_202A_206C_202D_202B_200C_200E_200F_206F_200C_202E_206C_206E_202E_202A_200E_202A_202B_202E_206A_200E_206A_202D_206B_200E_200F_200C_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1D
	}

	unsafe static Uri _200B_202C_206B_202E_206B_202B_206C_202A_206F_202E_200C_206D_200B_206A_200F_202B_200D_202C_202B_206B_206E_202C_200E_206A_200F_202E_206F_206A_202C_206E_200E_202E_200E_202C_206C_200E_206F_206D_206F_206C_202E(HttpResponse P_0)
	{
		_ = *(IntPtr*)(nint)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Metadata token must be either a methoddef, memberref or methodspec*/;
	}

	static UriBuilder _206C_200C_206A_200F_202A_206F_206A_206E_206A_206C_200E_206C_200C_206A_200B_202E_202C_200E_206B_200D_202B_202D_206D_206A_202C_206C_200C_200C_200B_202C_206D_206E_200D_200F_200B_200E_206E_206A_200D_206B_202E(Uri P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x31
	}

	static string _202B_206F_206F_206C_202C_202D_202D_202A_202C_206D_202A_202E_202D_202C_200D_200F_202D_206E_200E_206E_206D_202D_206D_200C_206D_202E_202E_202C_200C_202B_206E_200F_202D_200C_202B_206B_206F_200B_206D_202E(UriBuilder P_0)
	{
		//IL_0003: Invalid comparison between Unknown and I4
		if (/*Error near IL_0002: Stack underflow*/ >= /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		if ((int)/*Error near IL_0005: Stack underflow*/ != checked((short)/*Error near IL_0003: Stack underflow*/))
		{
			/*Error: Invalid branch target*/;
		}
		if (/*Error near IL_000a: Stack underflow*/ >= /*Error near IL_000a: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		if (/*Error near IL_000c: Stack underflow*/ > /*Error near IL_000c: Stack underflow*/)
		{
			_ = ((uint[])/*Error near IL_000d: Stack underflow*/)[/*Error near IL_000d: Stack underflow*/];
			/*Error near IL_000d: Read out of bounds.*/;
		}
		/*Error near IL_000f: Read out of bounds.*/;
	}

	static bool _202A_206B_206A_200C_202B_202E_202A_200C_202D_202D_206F_206F_200D_202E_202B_200B_202D_202D_200F_202E_202A_200B_206C_206C_206C_200C_206F_200F_206C_206D_206D_200F_202C_202D_202E_206D_202A_206F_202D_200F_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static int _206C_206C_200E_206A_206C_206E_206A_202E_206F_206D_202D_200F_206A_206D_206E_202E_202E_202E_206A_206D_206A_202C_200B_206A_200E_202E_200D_200F_206E_200D_206A_202A_206D_200B_206A_200B_206F_200E_200E_206D_202E(string P_0, char P_1)
	{
		//IL_0002: Expected native int or pointer, but got O
		checked
		{
			_ = (ulong)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0002: Invalid metadata token*/;
		}
	}

	static string _202C_202E_200D_200D_206A_206F_206D_206D_202D_206C_200D_202A_202B_206D_206F_200E_200F_206A_202D_206F_206B_206F_202E_206E_202D_202C_202B_206E_202A_202C_200C_200E_206D_206F_206A_200E_200C_206D_206F_206B_202E(string P_0, int P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x55
	}

	static void _202E_206F_200B_200F_200E_200E_202A_200C_200F_206E_202E_200B_202A_202C_202D_200F_202D_200C_206E_202C_202E_206C_206F_206E_206B_200E_202D_200F_206E_206F_202A_202D_206D_202A_202B_200B_202E_200D_202B_206B_202E(UriBuilder P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xE5*/;
	}

	static int _206E_206A_202D_202B_202A_206D_200E_200E_206E_206C_202B_202D_200B_206B_206F_200B_206F_206D_206C_206C_206C_200E_206A_206C_206A_200E_200D_200F_200E_200C_202D_206E_206C_202D_206C_202A_202C_200B_200C_200F_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA3 0x6B
	}

	static int _202A_202B_206B_206F_200C_202E_206E_202D_202D_206B_206B_200D_202C_200D_202B_200E_206B_200B_206E_206E_200E_202D_200D_206D_202B_206D_206F_200B_200F_202A_202C_206E_202B_202E_206E_202B_200C_206B_206A_206C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0x82
	}

	static string _206F_202E_202D_202E_206C_206D_202E_202B_202D_202A_202E_206C_206C_206F_200E_202B_200E_200F_206F_206F_206F_202D_206D_202E_200C_206C_206C_200D_206B_206A_206A_200F_200C_206B_206C_200E_202B_206A_206F_206B_202E(string P_0, string P_1)
	{
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
		/*Error near IL_0002: Unknown opcode: 0xB1*/;
	}

	static string _206F_202E_200B_200D_206A_206E_200D_206A_206B_202A_200B_206D_200F_202A_200E_202E_200B_206A_206F_206D_202B_206C_206E_206A_206C_202D_200B_206F_202B_200E_206B_206E_200F_202C_206E_206B_202B_206C_206D_202E_202E(string P_0, char[] P_1)
	{
		/*Error: Invalid metadata token*/;
	}

	static string _202C_202A_200D_200E_206F_200B_200F_206F_202A_202D_202D_200D_206E_202C_206F_206F_206A_200B_200E_206F_202D_206B_200C_200C_206C_206D_200D_206E_206D_200D_200B_202C_206F_200E_206E_200B_206C_206A_202C_202E_202E(string P_0, string P_1, string P_2, StringComparison P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC9
	}

	static string _206B_206E_200F_202D_200F_206A_206B_202B_206E_206B_202E_206C_200E_200D_202B_202A_200F_200B_206F_206C_200E_200B_200E_206E_206C_206A_206F_200F_206E_206C_200F_202A_206A_200B_206D_200E_206E_202D_206E_202B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDB 0x9A
	}

	static bool _200B_202C_200B_206E_202B_206B_202C_206F_200C_200C_206E_200E_200D_202D_206B_202E_200D_202E_202A_206A_206F_206D_206A_202C_200E_202B_206A_202D_200E_202C_200E_206B_200F_202C_200E_200D_206D_200C_200F_206C_202E(string P_0)
	{
		/*Error: Invalid field token*/;
	}

	unsafe static Exception _206D_200B_206C_200D_200F_206E_200E_202D_206E_200B_200C_200B_202D_206F_206F_206C_202C_202D_200C_206F_202E_206E_200E_200D_202A_206D_200B_206B_202C_202E_200C_200D_200C_202C_202B_206E_200D_206E_206E_206A_202E(string P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		checked
		{
			_ = (byte)/*Error near IL_0002: Stack underflow*/;
			/*Error near IL_0002: ldloc 57 (out-of-bounds)*/;
			/*Error near IL_0004: Unknown opcode: 0xC5*/;
		}
	}

	static string _206B_200E_202D_200F_206D_202E_202E_202C_202A_202B_206E_206A_200D_200C_206F_200E_200F_200E_202C_202C_206D_206F_200F_206F_202C_200F_206D_206B_200F_206A_200D_206F_206A_200E_206E_206E_202D_202B_206A_202B_202E(Uri P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE0
	}

	static HttpRequest _202E_202C_202B_200F_200B_202A_200B_206E_200C_206D_206A_206B_200E_200C_200B_202B_202E_206A_200C_206D_202E_206E_206D_200B_206D_202E_206C_200C_206E_200C_206A_206D_200C_206C_202A_206C_206E_206A_200E_202B_202E(HttpRequest P_0, string P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF1
	}

	static Uri _206B_202C_200C_200E_202E_206F_202C_200E_200D_206D_200C_202C_200D_206C_200C_206F_206C_206B_200E_200D_202E_200B_206C_206E_206D_200C_200E_200C_206E_206C_206C_206A_202D_206C_206E_200D_202E_200D_202D_200C_202E(UriBuilder P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0xF2
	}

	static HttpResponse _206D_202E_200D_200B_200E_200B_200E_202E_206C_206E_200D_200F_206A_206A_202D_202B_200F_200C_200F_200C_206C_200B_206C_200C_206A_206B_202C_206C_202E_206A_202C_206A_206A_202E_200D_202E_200C_206D_206A_202E_202E(HttpRequest P_0, Uri P_1)
	{
		/*Error: stloc 217 (out-of-bounds)*/;
		/*Error near IL_0002: Unknown opcode: 0xF1*/;
	}

	static bool _202C_200E_202B_206E_200C_202B_202A_202D_206E_206D_200D_206E_206C_206A_200B_206F_206C_206D_202A_202A_206A_202A_202B_200B_206E_206C_206E_206D_202C_200E_206E_206E_206B_206D_200E_206B_200C_202C_202D_206B_202E(HttpResponse P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x19
	}

	static string _200F_206E_202C_200B_202C_206E_200B_206A_206B_200C_200D_200E_202A_206B_206A_200C_200D_206D_200F_202B_202C_200E_202E_206C_206E_206F_200D_200B_202D_202B_200B_200F_202A_202E_200E_200E_202E_206B_200C_200C_202E(HttpResponse P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x84
	}

	static string _202B_202E_202A_202E_206E_206D_200B_206F_202A_202A_202C_200C_206B_202B_200F_202C_206E_206B_206C_202E_202E_202B_206C_202E_200B_206B_202A_202A_202E_206F_206D_202A_206B_200F_202C_206B_200C_200C_200B_206D_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA7 0x87
	}

	static HttpResponse _206C_206E_206C_200B_200C_200E_206B_206F_200D_202A_202B_200D_202C_202C_206F_206D_206B_200B_206D_202E_206F_206B_202D_202E_206F_200D_206E_200B_206E_200B_202E_206E_202E_202A_200B_206C_206A_200D_206C_206A_202E(HttpRequest P_0, string P_1, RequestParams P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x09
	}

	static CookieCollection _202C_200D_202E_202C_206D_206F_202C_206F_202D_202D_206B_202D_206E_202E_206E_206A_202B_200F_200E_202A_200B_200C_200F_206C_202B_200B_206C_200F_200C_206E_200D_200B_206F_200C_206E_202A_206E_202C_206C_200E_202E(HttpResponse P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x21
	}

	static string _200C_202C_206B_200F_200F_202A_206F_200B_200C_202D_206A_200B_206F_200C_206D_200F_202A_202B_206C_202C_202E_206C_206E_200D_200B_200D_200C_200F_200B_202C_200E_202D_206C_206B_200C_202C_202D_206B_202E_206B_202E(Uri P_0, UriPartial P_1)
	{
		_ = (sbyte)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Invalid branch target*/;
	}

	static UriBuilder _200C_206C_202B_200E_200F_206E_200B_202A_202D_202A_200D_206D_202D_206C_200D_206F_202D_200F_200F_206D_200B_206E_206C_200F_206C_206B_200B_200B_202B_206C_200F_206D_200C_206F_202A_206E_200E_206A_206F_202C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD3 0x9F
	}

	static string[] _202A_202D_200D_202C_200C_206B_202D_202C_200E_206B_202A_206F_206B_206F_206C_202A_206C_202A_202D_202C_200D_202E_200E_202E_200C_200D_200B_206A_200B_206B_206D_200F_202E_206C_200C_200D_202D_200B_202A_202A_202E(string P_0, char[] P_1)
	{
		/*Error: Unknown opcode: 0xE5*/;
	}

	static string _202B_200B_200B_202A_206A_200E_202D_202D_200D_202D_202E_206D_206E_200B_202E_202C_200E_202B_206F_206E_200F_206A_206D_200E_200B_202D_200F_206E_206A_202E_200E_206E_202C_202C_200E_202B_206E_206B_200D_206D_202E(string P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	static HttpRequest _206B_200F_200E_202A_202A_206A_200B_200B_202A_206E_206B_200C_206F_202B_206B_206C_206D_206F_202E_200B_206B_202B_206D_200F_200F_202C_206B_206B_202C_200F_206D_206C_206E_202A_206F_200B_200C_200E_206D_200E_202E(HttpRequest P_0, string P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static string[] _200C_206C_200F_200B_206D_200B_206E_202A_206B_206F_202B_206C_202D_206E_200B_206B_202D_206F_206D_206C_206A_200F_202C_206D_206C_206E_200E_200C_202B_200C_200E_206D_202D_200D_202B_200B_200E_202C_206A_200E_202E(string P_0, string P_1, string P_2, StringComparison P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}

	static HttpRequest _202C_206A_202C_206D_202E_206A_202A_206B_206B_206C_200C_200E_202A_200F_206A_200C_202C_206A_202B_206E_202B_202C_202D_206B_202A_206A_202A_202B_206D_202D_202D_200F_202C_202A_200D_202A_206D_206A_200C_206D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE5
	}

	static string _202D_200D_202A_206C_202C_206E_206B_200C_206C_206E_206F_202D_202C_200C_206B_206B_206F_206F_206F_206B_200B_202D_206F_206F_200B_202C_200E_202E_206D_200E_206F_206E_206E_202B_202A_202B_200C_202B_206E_202D_202E(HttpRequest P_0)
	{
		/*Error: Unknown opcode: 0xBC*/;
	}

	static void _202B_200C_202B_206D_202D_202A_206F_206D_206F_206A_206A_202B_206A_200E_206B_200D_206A_200F_206D_206F_206C_200F_202D_202E_200C_206E_202C_206F_202A_202C_206E_206D_200F_200D_206E_202B_200D_202B_202C_202D_202E(HttpRequest P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static CookieCollection _206A_200C_202A_206E_200D_206D_206F_206F_200E_206B_202C_206A_200B_206F_206F_202B_200B_200C_206A_206E_206F_200D_200D_202A_202C_200D_202E_200F_202A_202D_202C_206F_206D_200B_200D_206B_206B_206C_206F_202E_202E(HttpRequest P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5F 0xEC
	}

	static void _200D_206B_206E_206F_206E_206B_202B_206A_206A_206B_206F_202B_202E_206B_202A_202C_202B_202D_200D_200C_202B_200E_202E_206D_200E_206A_202D_206D_200B_200D_206A_206C_206A_202A_200D_206F_202E_206F_206A_206B_202E(HttpRequest P_0, CookieCollection P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x25
	}

	static void _200F_206A_202A_202A_200B_200F_206C_200E_202A_202C_202C_206A_200C_206C_200D_200B_202E_206E_202A_200E_206C_206B_202A_202B_206C_206E_202E_200B_202D_206D_206C_206F_200B_200B_202D_206E_200B_200D_200C_202C_202E(HttpRequest P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB5
	}

	static void _206B_202B_206D_206F_200C_206E_202C_202B_202A_202C_202C_202B_200B_200C_206C_202A_206B_200F_202B_206C_206A_202B_202D_200D_202C_202A_206A_206A_200D_202C_200C_202C_206D_200C_200C_200D_200D_200E_206C_202D_202E(HttpRequest P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static void _206C_200E_202E_202E_200C_202D_206F_202D_206D_200C_206F_202B_200F_202E_202A_200C_206B_202A_202E_202C_202A_206E_206B_200C_206A_200D_206A_206F_202E_202B_200B_202E_200D_206A_200C_206A_206C_206B_202C_200D_202E(HttpRequest P_0, EventHandler<DownloadProgressChangedEventArgs> P_1)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		if (/*Error near IL_0007: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/% checked(/*Error near IL_0001: Stack underflow*/ + /*Error near IL_0001: Stack underflow*/))
		{
			/*Error: Invalid branch target*/;
		}
		if (/*Error near IL_0009: Stack underflow*/ > /*Error near IL_0009: Stack underflow*/)
		{
			/*Error near IL_0009: Unknown opcode: 0xE3*/;
		}
		throw checked((ushort)/*Error near IL_0029: Stack underflow*/);
	}

	static void _200E_200F_202C_200B_200E_202B_206D_200C_200E_200C_200C_206F_202D_200C_202D_200B_200F_206B_200B_202E_202B_200C_202B_200F_202A_200D_206E_200C_202A_206E_200E_202B_200B_202D_206A_206A_206E_206B_202E_206E_202E(HttpResponse P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	static void _200C_200F_206C_200B_202D_202C_206C_200B_206D_206D_206D_202A_200F_202C_206B_202B_202C_200E_206B_206C_200E_200E_202A_202D_206D_202E_206A_200F_200F_200E_200D_202A_206F_200E_206D_206D_200F_206D_202C_206C_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}
}
