using System;
using System.Runtime.CompilerServices;

[CompilerGenerated]
[_1deL5VKElKMneJuWCVicQneaaWP]
internal sealed class _1deL5VKElKMneJuWCVicQneaaWP : Attribute
{
	public _1deL5VKElKMneJuWCVicQneaaWP()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x33 0x7A
	}
}
