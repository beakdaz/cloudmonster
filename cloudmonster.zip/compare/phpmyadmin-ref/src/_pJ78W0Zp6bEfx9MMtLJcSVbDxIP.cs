using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using HandyControl.Controls;

public class _pJ78W0Zp6bEfx9MMtLJcSVbDxIP : Window, IComponentConnector
{
	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _NnKGD7Qrm7ByCkkLgl5ISdGAFDG : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncVoidMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public DragEventArgs _MuEPyhWb10qVM93qdBfxsKQAhJh;

		public _pJ78W0Zp6bEfx9MMtLJcSVbDxIP _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5B 0x2E
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCB 0x0A
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static IDataObject _200E_200F_202D_206E_206E_206A_200F_200B_206C_200F_200F_202C_206A_206F_202A_206B_206B_206C_202C_202E_206D_202B_202C_206A_202D_202E_206B_206C_202E_200E_206D_202B_202B_200F_202A_206A_206D_206F_206E_202E_202E(DragEventArgs P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAD
		}

		static object _202E_202E_206B_200E_200F_206A_202E_202E_200D_202C_200E_202A_206A_202B_206F_200D_202C_206D_202A_200D_200B_200C_206A_202B_206F_202C_206A_200F_200F_202B_202B_202E_200E_206D_202C_202C_206D_202A_206F_206E_202E(IDataObject P_0, string P_1)
		{
			_ = (double)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xE4*/;
		}

		static object _206D_206B_200E_202A_200F_200E_206E_200C_200B_202D_206D_206C_206D_200D_206B_202D_206B_200E_206F_206D_200C_202E_206C_206C_202D_206E_200F_200C_200D_200B_200B_202E_206B_200F_206B_206B_200F_202B_200F_206A_202E(FrameworkElement P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}

		static FileAttributes _200F_206A_200D_206E_200D_206A_202E_202A_206F_202B_200F_206F_206C_206D_206B_206E_202D_202B_206F_202C_200B_200C_206B_200B_200E_206B_206F_206F_200D_200D_206D_202A_200C_206D_202B_202D_206A_206B_202A_200D_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x24
		}

		static bool _206A_200B_202A_200B_202D_206C_206B_200B_200E_206D_200D_206F_200D_202C_200E_206C_206D_200D_200B_206D_200F_206D_206B_206B_202E_206B_202E_200C_206D_200F_200B_200D_206E_200C_202D_200B_200E_206D_206E_202B_202E(Enum P_0, Enum P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x68
		}

		static string[] _202A_202D_202C_202D_206D_206E_200D_206D_206D_202D_206F_206A_206B_206D_200C_200D_200C_206F_200B_206B_202E_206E_200E_202A_200C_202D_202E_206F_202D_202B_206B_202E_200B_202A_200D_200C_200D_206B_200F_200E_202E(string P_0, string P_1, SearchOption P_2)
		{
			checked
			{
				if (!float.IsFinite((ushort)unchecked((uint)(short)(long)/*Error near IL_0001: Stack underflow*/)))
				{
					throw new ArithmeticException();
				}
				/*Error near IL_0004: Unknown opcode: 0xE3*/;
			}
		}

		static TaskAwaiter _200E_202D_206E_200E_202B_202C_200F_200D_200F_200F_200F_206D_202E_206E_202D_202B_200B_206A_202A_206A_200B_206B_200D_202B_200F_202D_202A_202A_202E_202A_206B_206F_206A_202B_206C_206E_200D_202D_206A_202B_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	internal Border _85YDOgQqvsVBuzB93cNfVhAG3BDb;

	private bool _4HzZsGhVvtYrYG2qOrXTnyCtnTb;

	public _pJ78W0Zp6bEfx9MMtLJcSVbDxIP()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x04
	}

	[AsyncStateMachine(typeof(_NnKGD7Qrm7ByCkkLgl5ISdGAFDG))]
	private void _VAZoLPDroo8XybBn1qfU4dHhekF(object P_0, DragEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC8
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.1.0")]
	public void InitializeComponent()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4B 0xDA
	}

	void IComponentConnector.InitializeComponent()
	{
		//ILSpy generated this explicit interface implementation from .override directive in InitializeComponent
		this.InitializeComponent();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.1.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		/*Error: Unknown opcode: 0xCA*/;
	}

	static void _202E_202B_202D_200D_202B_202B_202D_200C_200D_206E_202B_200B_206A_206B_200F_206E_200E_206B_200D_202D_200E_200C_200D_202A_206E_206F_200D_206F_202C_200D_200F_202A_200E_202A_206B_200B_200E_202B_202E_202E(UIElement P_0, DragEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x61
	}

	unsafe static Uri _202E_206B_206F_202A_200B_202D_200F_202A_200B_206D_200F_202D_206C_200E_202D_200D_206D_206B_200D_206E_202D_202D_200D_202D_206F_202E_206B_202C_206F_202A_202B_200D_206D_200F_206E_206F_202B_200D_206D_202E(string P_0, UriKind P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0002: Stack underflow*/>> (int)(*(float*)(nint)/*Error near IL_0001: Stack underflow*/);
		/*Error near IL_0002: Unknown opcode: 0xF5*/;
	}

	static void _206F_200D_202A_206C_200C_200E_206E_206E_202A_200B_206E_206E_206B_206D_200F_202D_200C_200C_202E_202C_202A_206B_200C_200C_202A_206B_206A_206C_202A_202A_206A_200D_206F_206E_200B_206B_200F_206B_200F_206B_202E(object P_0, Uri P_1)
	{
		/*Error: Unknown opcode: 0xBC*/;
	}
}
