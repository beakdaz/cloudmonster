using System;
using System.Runtime.CompilerServices;
using xNet;

public class _SLsbrwswPjD8B75WDQg8PItZsqc : NetException
{
	[CompilerGenerated]
	private readonly string _mWdAOs3tzksEfaDFJ7exKTcezkyA;

	public string _tvdtQU69qNsPHFtGqUuwoMIx5Ae
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x00
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _SLsbrwswPjD8B75WDQg8PItZsqc()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6F 0x50
	}

	public _SLsbrwswPjD8B75WDQg8PItZsqc(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0xEA
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public override string _5RU6m6RQWG9zt0PKA8ncfFUmRLC()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0x4E
	}

	static string _202E_200D_202A_200B_206E_206C_206F_206E_202D_206A_206C_206E_200F_206D_202C_200C_202E_200F_206F_202B_206C_202B_202D_200F_200E_206A_206D_200E_200D_200C_200D_206D_202A_206C_206B_200E_206E_206B_206F_200E_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static string _206C_202A_206A_202B_206D_200B_202A_200E_202C_206E_202D_202D_202D_202B_200D_202A_200B_200B_200E_200C_202C_206A_200C_200C_206E_202D_206E_206F_200C_206E_200E_202D_202A_202A_202D_202C_202A_200D_200F_202D_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}
}
