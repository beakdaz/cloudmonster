using System;
using System.Runtime.CompilerServices;

[AttributeUsage(AttributeTargets.Property)]
public sealed class _2TZHKOVBqCRTojsrTXGYzWqT05c : Attribute
{
	[CompilerGenerated]
	private readonly string _dDXOcWOShXKoGt8dHSXluIjuPCi;

	[CompilerGenerated]
	private bool _4wIy5JBLblMgiutSarYdG6cYMUK;

	[CompilerGenerated]
	private bool _XKG5ct5WjhwzIjwnyDAppQ1AFBE;

	public string _NCidLvMp648UYoE4e0mG7YdkcWe
	{
		[CompilerGenerated]
		get
		{
			/*Error: Method body consists only of 'ret', but nothing is being returned. Decompiled assembly might be a reference assembly.*/;
		}
	}

	public bool _z9iGSNwAHN9WJNl40wnjovc9b6g
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xBD*/;
		}
	}

	public bool _tFy3PAFwXh22Af9Rd6EaVyvRwuA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2C
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x33 0x1B
		}
	}

	public _2TZHKOVBqCRTojsrTXGYzWqT05c()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x33 0x7A
	}

	public _2TZHKOVBqCRTojsrTXGYzWqT05c(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x64
	}
}
