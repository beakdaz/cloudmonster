using System;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using xNet;

internal abstract class _Ua0fX2zuqNT58B5Lzv7fFD4JQH6 : IDisposable
{
	[CompilerGenerated]
	private static class _FQ7p26LA0WRBNNmLydjIZUaJV09
	{
		public static Func<string, bool> _hU22pXXqxRrpiC6TrwDcv3bjdoi;
	}

	public HttpRequest _lsS5fsMttHH1dcXC9t7xUCvP1vg;

	protected _Ua0fX2zuqNT58B5Lzv7fFD4JQH6(ProxyClient P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBB 0x2E
	}

	protected virtual bool _mAClq84QhzwBwmov7vhKF8jlcCi(object P_0, X509Certificate P_1, X509Chain P_2, SslPolicyErrors P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF9
	}

	protected bool _eQ1C4rrbkvUUfSd1jD6c4hyCcPs(params string[] P_0)
	{
		/*Error: Unknown opcode: 0xF9*/;
	}

	public void Dispose()
	{
		checked
		{
			_ = (sbyte)((ushort[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
			/*Error near IL_0002: Invalid metadata token*/;
		}
	}

	void IDisposable.Dispose()
	{
		//ILSpy generated this explicit interface implementation from .override directive in Dispose
		this.Dispose();
	}

	protected virtual void _krTRNi52wC1AwV2psW0Of9EHeVO(bool P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0x72
	}

	static HttpRequest _200B_202A_206F_202D_200F_202B_202E_206E_200B_200B_206E_206B_200B_200F_200B_200F_200E_200B_202C_206C_206A_206C_206C_202E_200E_200E_206D_200C_200B_200E_202D_202C_202A_200F_202B_202C_200D_202D_206F_206C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE5
	}

	static CookieCollection _202B_202C_206C_200D_206A_202A_206F_206C_200F_206C_206F_206A_200E_200B_206F_206E_206A_202C_200F_202D_200D_202E_202B_206C_200C_206F_206E_206F_200F_200B_200F_206E_202D_202B_202B_202C_206A_200E_202A_200D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD7 0xA5
	}

	static void _206E_200F_206B_202D_202D_200C_200B_206C_202E_200E_200B_206A_206B_202B_206D_200C_200D_200E_202D_206B_202A_200C_200B_206D_200F_200C_206A_202B_206A_206A_206C_206A_206C_200E_206A_206B_206D_200D_200C_202C_202E(HttpRequest P_0, CookieCollection P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x25
	}

	static void _206B_200D_202A_202E_202B_200B_206B_202E_202C_206A_200B_206D_206F_202E_206C_206C_206A_206C_200C_202E_200E_200D_206F_202A_206B_200B_206C_206C_202B_200D_200D_202C_206A_200B_200B_206F_200D_206D_206F_202C_202E(HttpRequest P_0, bool P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static void _206A_200E_202C_200F_206E_202D_202D_202A_202C_206B_202A_206C_200C_206A_206F_206A_202C_202E_200E_206C_206A_202B_202C_200E_206E_200C_206D_202E_202B_200D_200B_206C_202A_200F_200B_200B_200F_206E_206F_206F_202E(HttpRequest P_0, bool P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xCB
	}

	static void _206C_202C_202A_200F_206A_200F_200B_202A_202E_206A_206E_202E_206E_202A_202B_202E_202B_206F_206E_200B_202C_202C_206E_206B_206F_200D_202E_206C_200B_200E_202C_206E_200E_206F_200B_202B_202C_200B_200C_202C_202E(HttpRequest P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static void _200E_206E_202B_202C_202A_206A_202A_200E_206A_206B_200D_200D_206D_206F_206D_206F_202E_206C_200F_202D_202D_206C_200D_200F_202A_206E_206E_206C_206D_200D_202B_200D_206D_206A_202E_206C_206D_200E_202B_202A_202E(HttpRequest P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB5
	}

	static void _206A_200D_200C_206B_206D_200F_206F_202E_206B_206E_200D_200D_202D_200B_206D_206C_206C_200C_206F_206E_206F_200D_202D_206A_200C_206E_200B_200B_200B_206F_200B_200C_200F_206D_202D_206A_200D_202C_202A_200D_202E(HttpRequest P_0, ProxyClient P_1)
	{
		/*Error: Invalid metadata token*/;
	}

	static ProxyClient _202E_200F_202C_202B_200E_206D_202D_200E_202C_200F_200F_202E_200B_200B_200E_206D_200F_206E_200F_200E_200B_202D_200D_200E_206B_200D_202D_200D_206B_202D_206E_202C_200B_200E_206B_206F_200C_206E_206D_202B_202E(HttpRequest P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x04
	}

	static void _200B_206D_206C_202A_202A_202D_206F_200F_200E_202B_206B_206B_200C_202C_202B_202B_206D_206E_202D_206C_202B_206A_202A_206C_202B_202B_202D_202D_206C_206E_202B_202E_202B_202A_200D_200B_202A_202C_206D_200E_202E(ProxyClient P_0, int P_1)
	{
		//IL_0003: Expected I8, but got I
		((long[])/*Error near IL_0003: Stack underflow*/)[/*Error near IL_0003: Stack underflow*/] = checked((short)/*Error near IL_0001: Stack underflow*/);
		/*Error near IL_0003: Read out of bounds.*/;
	}

	static void _206D_206C_202C_202B_202B_206D_206C_206C_202E_206B_206C_202D_200F_202A_202A_200D_200F_202A_206E_206E_206D_202B_206E_200D_206B_202E_206A_202B_206F_202D_206E_200E_206B_206D_200C_202E_202D_206C_200D_202E(ProxyClient P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x00
	}

	static void _202E_200F_202D_200E_200C_206F_202D_200F_206E_200C_202A_200F_202D_200C_202D_206B_206F_200D_200C_200C_200D_202A_200B_202B_206B_200E_206F_206C_206D_200D_202B_206F_206E_200F_202C_200E_206C_206B_202E_206C_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x24
	}

	void _206E_202C_202E_202C_202B_200D_200F_200D_206D_202A_206C_206E_202A_206F_206A_202A_206F_206C_206E_202E_202E_206D_202D_202B_200F_200E_206B_206B_206D_200B_206B_202D_202C_200E_202E_206A_206F_206D_200F_202E()
	{
		_ = (long)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: starg 165 (out-of-bounds)*/;
		_ = ((sbyte[])/*Error near IL_0004: Stack underflow*/)[/*Error near IL_0004: Stack underflow*/];
		/*Error near IL_0004: Invalid branch target*/;
	}
}
