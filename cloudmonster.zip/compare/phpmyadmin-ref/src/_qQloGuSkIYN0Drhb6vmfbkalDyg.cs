using System;
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;

internal static class _qQloGuSkIYN0Drhb6vmfbkalDyg
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _W4e0XWafv8fYHjkZsgxt0OJA5Ek<_0001>
	{
		public static readonly _W4e0XWafv8fYHjkZsgxt0OJA5Ek<_0001> _003C_003E9;

		public static Func<_0001, Guid> _003C_003E9__1_0;

		static _W4e0XWafv8fYHjkZsgxt0OJA5Ek()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD9
		}

		public _W4e0XWafv8fYHjkZsgxt0OJA5Ek()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal Guid _0Ju6AvPmcy0B69r7ATFHEYzH4ob(_0001 P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}
	}

	public static void _A8TCgCymqXwydIfuHMT8ytblSSe<_0001>(this ConcurrentQueue<_0001> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	public static void _gnCc21dXnVllE4PFosTLplU4rHE<_0001>(this ConcurrentQueue<_0001> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0xAD
	}

	public static bool _MKr1okt0TJsPEMVE8BDey1U272D(this string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBC
	}

	static int _202C_200F_206A_206D_206A_206F_206A_200B_200F_202D_202C_202B_202D_202C_200C_202D_202A_206A_202D_206D_202E_206B_206E_206F_200D_206A_202C_202A_200E_200E_202A_202B_200D_206E_202C_202E_200B_200C_206E_200D_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}
}
