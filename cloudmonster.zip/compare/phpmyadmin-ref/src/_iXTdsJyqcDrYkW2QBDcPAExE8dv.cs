using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_BIOS")]
public sealed class _iXTdsJyqcDrYkW2QBDcPAExE8dv : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _OoFKkHoW42hf63ZSRPqYhC2iCyf;

	[CompilerGenerated]
	private string _RSen2ZwPqotFSflgOZEpUTa7cXb;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _IR4UikgDdp8PuDPgCYLoVBhsdaV;

	[CompilerGenerated]
	private string _tIzOxqAveP3uc4ROcd6D3llDGiD;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name", _z9iGSNwAHN9WJNl40wnjovc9b6g = true)]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA4
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x97 0xD5
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Version")]
	public string _NP0mfera5Nd2qLHDs05gNUwtwuB
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5C
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB8
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Caption")]
	public string _VaEBso6OOri1y0w9IQvg5zajb6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC0
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA9
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9D
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Manufacturer")]
	public string _2LGcfWg9irJpfYK5B4taNm2rHsG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF4
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("SerialNumber")]
	public string _ozceJCod4VTkGRUZ6esDi7DJ2jjA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2B 0x98
		}
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x64
		}
	}

	private _iXTdsJyqcDrYkW2QBDcPAExE8dv()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}
}
