using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;

public static class _z4ln6GZBpn1EzvuEss4dEYkNnfLA
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _GiVcL9BlChVBmWJ5gg4KkFDghlt
	{
		public static readonly _GiVcL9BlChVBmWJ5gg4KkFDghlt _003C_003E9;

		public static Func<string, char> _003C_003E9__11_0;

		public static Func<string, char> _003C_003E9__12_0;

		public static Func<string, char> _003C_003E9__13_0;

		public static Func<string, char> _003C_003E9__14_0;

		public static Func<int, int, int> _003C_003E9__17_1;

		public static Func<int, int, int> _003C_003E9__17_2;

		public _GiVcL9BlChVBmWJ5gg4KkFDghlt()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal char _cRYu07LkULb3kMFcDUAphQG0ivK(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x18
		}

		internal char _swJg0ebfcU2Gb8D5hkxgr5F0UcX(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x18
		}

		internal char _g0P8L9LRC6AiuatBcVdNzYPAGiA(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x18
		}

		internal char _riQuIzesWsgAENDLgVZNcB2igYO(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x18
		}

		internal unsafe int _nr1lofg3nNNxNvigSfF4YFCCHBJ(int P_0, int P_1)
		{
			_ = *(int*)checked((sbyte)(ushort)unchecked((nuint)checked((nint)/*Error near IL_0001: Stack underflow*/)));
			/*Error near IL_0004: Unknown opcode: 0xBD*/;
		}

		internal int _NMbJzbp5wIbBzxl3VRJYoh5gLHi(int P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x97 0xC8
		}

		internal unsafe Random _tnCgjjyYapHL2C7UFcyfyehPVkQ()
		{
			throw *(IntPtr*)1;
		}

		static int _200E_200C_200B_200F_206B_202B_206C_206C_200B_206D_202C_200E_202C_202E_200E_200B_202C_200E_202D_206B_202C_202C_206D_200E_206F_200F_200D_200D_200D_202A_202E_200B_202C_200B_200C_200E_200D_206B_202E_200D_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x70
		}

		static char _206A_206A_200E_206D_206C_206F_206E_200B_202B_202D_206B_202E_200F_206E_200B_206F_202E_200D_206E_202E_200B_206F_202A_206C_206A_202E_206B_200B_202B_206C_202B_200E_200C_206C_202E_200B_206A_200C_200D_202E(string P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCD
		}

		static int _200C_202D_202D_202C_202C_200B_200C_206F_202C_202D_202D_202C_202B_202C_200E_206E_202A_202B_200B_206D_202B_202B_206C_202A_202B_206E_206E_202C_200E_200F_206E_206E_200C_206A_200F_200E_202C_206C_200B_202A_202E(ref int P_0)
		{
			checked
			{
				_ = (int)(ref P_0);
				/*Error near IL_0002: Unknown opcode: 0xA7*/;
			}
		}

		static Random _202C_202D_200D_206F_200E_200C_202D_206E_200C_202C_206C_200F_200B_200D_206D_202B_202D_206F_206C_200F_206C_202A_206E_206B_206C_202A_206E_206C_200C_200F_206F_200C_202A_200B_200E_206B_200B_206C_202E_202E_202E(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB9
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _Ixl3l7fcBMbDEzRz5GiTNrYh6jI<_0001>
	{
		public static readonly _Ixl3l7fcBMbDEzRz5GiTNrYh6jI<_0001> _003C_003E9;

		public static Func<_0001, Guid> _003C_003E9__10_0;

		static _Ixl3l7fcBMbDEzRz5GiTNrYh6jI()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB3 0x14
		}

		public _Ixl3l7fcBMbDEzRz5GiTNrYh6jI()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal Guid _gkJBDdrghdHVE5xkNesVT6t1X6X(_0001 P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}
	}

	private static int _HnhqnYfN7dlhrb0Pg3waAp2WTyF;

	private static readonly ThreadLocal<Random> _0cWE8DQceKW78e3X7FuXSwEgDLQ;

	public static int _s373TpCsQoVKXVtKxouQXnwUCUf(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x14
	}

	public static int _s373TpCsQoVKXVtKxouQXnwUCUf(int P_0, int P_1)
	{
		/*Error: Unknown opcode: 0xBF*/;
	}

	public static byte _woueCAVp7HgvcJMCLqW50tEVRFF()
	{
		_ = ((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
		/*Error near IL_0001: Invalid metadata token*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static void _ycqbmM8BURNbuL8DncDVdxbFeoEb(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x50
	}

	public static double _QMOwsxEi6PW9Ww1CKliztbidbnr()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4B 0xEC
	}

	public static double _QMOwsxEi6PW9Ww1CKliztbidbnr(double P_0, double P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x88
	}

	public static float _lKXR0EYMf8DlOt1FSfDo65G8V0e(float P_0, float P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x04
	}

	public static bool _xKoXqIErmAwwUh00szgISL9ba2M(int P_0 = 50)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEB 0x6F
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static _0001 _Yu17b7YsxglgZ8dDkhVAsTksC0j<_0001>(IEnumerable<_0001> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAC
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _DLJYRxw8ZzPPpEseZLDUjKTCLxI(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBF 0x70
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _Zku3UcyaVnzIWD8c5VG07F7gn1l(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x95
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _UF5SATgtbIfzzhV1UsXijGs5ij(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBC
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _KKxQF7L5kczSQAGWxsci8qYjM6g(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _DZDZz1MjAMj3tRmfNMlcaJ57syG()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x37 0x83
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static long _g1jr9oJQaLZ0YGMsBiXOA0Ts5PE(long P_0, long P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	public static string _jWDIEMeNKkgKf1oaBM5NuEG7WBp(string P_0)
	{
		/*Error: Unknown opcode: 0xE5*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _YAWarJod8ocDX87BQ8Bq9SUMlxg(bool P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x93 0x67
	}

	public static string _AFfKroX0hrChGAs1gFtdrqZA0LN(bool P_0)
	{
		/*Error: Unknown opcode: 0xBD*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _GbZCrSwHUvvuUCrMu9CYOLMwziD()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2B 0x8D
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _UUkxsipJoucOBU5286sJvGUMVqC()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0001: Stack underflow*/<< (int)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Read out of bounds.*/;
	}

	static _z4ln6GZBpn1EzvuEss4dEYkNnfLA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	[CompilerGenerated]
	internal static char _5EdblNZes1gmrAmbqI113dIQDNn(char P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}

	static int _200B_202B_206B_200B_206D_206D_206F_206B_206E_206E_202D_206E_200B_200D_202D_202B_206C_206E_200F_206E_200F_202D_206B_202E_206E_206E_206B_200E_200C_200D_202C_200D_202D_206E_206E_206C_202B_206D_206E_206B_202E(Random P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE5
	}

	static int _202C_202B_206C_206A_200C_202B_206A_206C_202E_206B_206B_206C_206B_200E_206B_200C_206B_200C_202E_206C_200F_200B_200B_202B_202C_202C_200B_200B_200E_200C_206D_202E_202A_206B_200C_206A_206A_200C_206E_202E(Random P_0, int P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB3 0x84
	}

	static ArgumentNullException _202A_200E_202B_206D_202D_206D_206A_200F_206D_200B_206A_206A_202D_200D_206D_200E_206F_200F_200E_202E_206A_202D_202D_202C_202C_202A_206C_206F_206F_202E_206A_206D_202B_202E_200B_206D_200C_206B_206A_200C_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xEF*/;
	}

	static void _202C_206C_200F_206F_206B_200E_206A_202E_200F_206C_202D_206A_202D_200E_202D_202B_206D_206C_202E_206E_206B_200C_206C_202E_200C_200C_202B_200F_202E_200F_206E_200C_202B_202D_206F_200F_206E_200F_200E_200F_202E(Random P_0, byte[] P_1)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0001: Stack underflow*/% /*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Unknown opcode: 0xA6*/;
	}

	static double _202C_202D_200D_200E_200D_200B_206B_202B_206A_200C_200C_206F_206B_202B_206F_202E_202B_202E_206B_202D_206E_206C_202B_202D_206B_206F_200D_200C_202C_206B_200E_200F_202E_200E_202D_202B_206E_206C_206C_202E_202E(Random P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}

	static string _206E_200B_206B_206F_206B_202B_200B_206D_202D_206A_202C_206D_200E_200F_206A_206D_202D_200F_200F_200D_202E_200C_202B_200B_206F_200C_206B_206A_200F_206A_206A_206B_200C_202B_202B_206E_200E_200E_206C_202D_202E(char[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDF 0x9C
	}

	static string _200B_200F_202A_202E_202A_202B_202B_206D_206B_206E_202C_202E_206D_206B_200B_206E_206C_206F_206E_202A_206F_206C_202E_206F_202B_202C_200B_206D_206E_202B_200E_206B_206B_206B_202E_200E_202E_202A_206B_206B_202E(string P_0, string P_1)
	{
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
		/*Error near IL_0002: Unknown opcode: 0xB1*/;
	}

	static Random _206B_206C_202E_200F_202E_202D_206E_200C_200F_200D_200E_202B_202E_206E_202B_206F_206F_202C_200D_202E_200B_202A_202D_202A_200C_200D_206B_202C_202C_206D_206D_206D_202E_202E_206B_202B_206C_202E_202D_206C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x77 0xED
	}

	static string _202B_200D_200B_206C_202E_200F_206F_200C_200E_200C_200C_206C_206C_200C_200E_206F_206B_200E_202A_200C_202E_206A_202A_200D_200C_200B_202C_202C_202A_206C_202D_206A_200C_206A_200F_206F_206F_206E_200B_206E_202E(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0x80
	}

	static string _202C_202C_202D_202A_200F_206E_206B_206E_206F_200E_206A_202B_200F_202B_202D_206D_200D_200B_202C_200B_206E_200B_202B_206F_200D_200E_202C_200C_206C_206F_202B_206D_206B_206B_202C_206E_200B_200C_202E_202E_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static string _202D_200C_200B_202C_200B_202C_202D_206F_202D_200C_206A_202B_202A_206F_202D_206A_202E_206F_200B_202B_206D_200D_202D_202A_200C_206D_202E_206C_202E_200D_206A_200D_206E_206B_200D_206F_202D_202D_202B_202D_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0x2F
	}

	static ArgumentOutOfRangeException _206F_200C_206A_200D_200E_202D_202E_202A_206F_200E_202A_200F_202A_202C_206D_202A_206F_200E_206F_206A_202A_206A_202B_206F_202D_200F_206F_202E_202E_206D_206E_206C_200F_206D_206D_200F_202B_202A_200C_206A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x83 0x25
	}

	static long _206D_200E_206C_200B_200C_202D_206A_206A_206E_202A_206F_206C_202B_202A_200D_206B_200F_206C_202D_200E_206A_200C_206C_206D_202B_206F_202B_202E_202E_200B_200B_202B_206A_202C_202D_200E_202D_206A_200B_200D_202E(byte[] P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x98
	}

	static string _202E_206A_200B_200F_200D_202E_206B_206B_202C_206F_206C_200F_206F_206C_200C_202B_206B_206A_202D_202A_200D_200C_206B_202B_202D_206C_202D_206E_202B_202E_206D_206C_206F_206D_206C_200F_206B_206F_206F_202E_202E(string P_0, object[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x97 0x67
	}

	unsafe static IPAddress _202C_206C_202A_200B_202D_202B_202A_200B_200D_202D_206F_202E_200D_200E_200C_206C_206A_206D_202A_206C_200C_206B_202E_200E_206B_200F_202A_206E_202A_206F_202B_202E_202E_200C_206D_200E_206D_206C_206D_202E(byte[] P_0)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		if (/*Error near IL_0003: Stack underflow*/ <= /*Error near IL_0003: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		((IntPtr[])/*Error near IL_0004: Stack underflow*/)[/*Error near IL_0004: Stack underflow*/] = (IntPtr)/*Error near IL_0004: Stack underflow*/;
		IntPtr intPtr = *(IntPtr*)(nint)/*Error near IL_0005: Stack underflow*/;
		checked
		{
			if (!float.IsFinite(/*Error near IL_0006: Stack underflow*/ - unchecked((nint)intPtr)))
			{
				throw new ArithmeticException();
			}
			/*Error near IL_0007: stloc 1 (out-of-bounds)*/;
			_ = /*Error near IL_000a: Stack underflow*/+ (/*Error near IL_0009: Stack underflow*/ + /*Error near IL_0009: Stack underflow*/);
			/*Error near IL_000a: Unknown opcode: 0xEF*/;
		}
	}

	static string _202A_206F_206B_202C_206F_206D_200F_206B_200B_202E_202D_206D_206E_202E_202B_200D_206D_206B_202D_202A_206C_200D_206C_206E_202D_206E_202B_200E_200F_200E_200D_200E_200C_206D_206E_200D_200F_206B_206F_206E_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static int _200E_200D_202D_200E_206A_202B_206D_200F_206A_206F_202D_206B_202A_206D_206C_200E_200C_202B_206F_202D_206A_202C_202A_206D_206A_206E_200F_202B_206F_202B_206A_202A_206C_200C_202B_206F_200B_202D_206A_206B_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}

	static void _202B_202E_206D_206F_206C_206F_206F_202B_206E_200F_202A_202B_202C_206D_200D_202A_200B_202A_206A_206E_202B_200D_206F_202B_206E_206B_200E_200C_202A_202D_206B_206D_206B_202B_202C_200D_202A_202A_202C_206F_202E(Array P_0, RuntimeFieldHandle P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		((object[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (object)/*Error near IL_0001: Stack underflow*/;
		_ = /*Error near IL_0002: Stack underflow*/% /*Error near IL_0002: Stack underflow*/;
		/*Error near IL_0002: Unknown opcode: 0xF9*/;
	}
}
