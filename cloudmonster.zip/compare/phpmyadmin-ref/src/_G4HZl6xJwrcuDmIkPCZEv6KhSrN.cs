using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

public class _G4HZl6xJwrcuDmIkPCZEv6KhSrN
{
	[CompilerGenerated]
	private sealed class _QsB9qZWHQDMLrWX3UUsqwEbeTQo : IEnumerable<_G4HZl6xJwrcuDmIkPCZEv6KhSrN>, IEnumerator<_G4HZl6xJwrcuDmIkPCZEv6KhSrN>, IEnumerator, IDisposable, IEnumerable
	{
		private int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		private _G4HZl6xJwrcuDmIkPCZEv6KhSrN _3tIG6UVQ4UPou107F3J4pJaBtrk;

		private int _bXU2D86OrOUxgQVBSC9GehimS1W;

		private string _hMidTonAra0P2CpcM0dJEDmi1seA;

		public string _VOkLx8G9YoxDQ8F3j6R0g2Z1xHJ;

		private string[] _uKpYifnB0xEYESgIi8iaIQ27xL5;

		private int _kS6x37UbCQaMzCWadfcp6RzDo6eb;

		_G4HZl6xJwrcuDmIkPCZEv6KhSrN IEnumerator<_G4HZl6xJwrcuDmIkPCZEv6KhSrN>._ZrZB8SZoSXVSkqkoNtwBOlqob2r
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xBB 0xEB
			}
		}

		object IEnumerator._Duoernm7b6cxarH5RFBwpDWHX9A
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xBB 0xEB
			}
		}

		[DebuggerHidden]
		public _QsB9qZWHQDMLrWX3UUsqwEbeTQo(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA0
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFD
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		private bool MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			/*Error: Unknown opcode: 0xFE1B*/;
		}

		[DebuggerHidden]
		IEnumerator<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> IEnumerable<_G4HZl6xJwrcuDmIkPCZEv6KhSrN>.GetEnumerator()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA3 0x60
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			if (/*Error near IL_0001: Stack underflow*/ < /*Error near IL_0001: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error: End of method reached without returning.*/;
		}

		unsafe static int _202D_200F_202B_200D_200C_206E_202B_202A_206A_206B_200D_202C_200D_206D_206C_200C_206A_206C_202B_200D_206A_200C_202B_200F_200F_202B_202D_206E_206A_200E_202E_206B_200B_206F_200B_206E_202E_200E_202E_202D_202E()
		{
			checked
			{
				_ = (nuint)unchecked((int)(*(byte*)(-5)));
				/*Error near IL_0004: Unknown opcode: 0xFEC4*/;
			}
		}

		static string[] _202E_206C_206C_202B_202A_206E_202A_202A_206C_206A_200E_200F_202D_206F_202B_202C_206C_202B_202E_206B_200B_202B_202E_206D_206E_202C_200D_202B_206D_200C_206E_200E_202B_202B_206A_206E_200D_206D_202A_206C_202E(string P_0, string[] P_1, StringSplitOptions P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x28
		}

		static NotSupportedException _202E_206A_206D_206D_200B_200B_200D_200D_200B_202E_200D_202E_200E_200E_206D_206D_200C_202D_202D_206C_206B_202E_206D_206B_206B_206F_206D_202C_206F_206A_200F_200D_206E_202E_206A_206B_200F_202B_202C_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}
	}

	private const string _7UawzOrAIV5GBYUfQf0ZPAruAEx = "^(\\d{1,3}\\.){3}\\d{1,3}:(\\d+)$";

	[CompilerGenerated]
	private readonly string _kcJaCLJpSOZ3ItmBgPNRCZca0dp;

	[CompilerGenerated]
	private int _O0k8od4sXMJjWgwBeyQGqBiKa1T;

	public string _VJya9c76w9MDYZX83fe7eoHFs8aA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFB 0x99
		}
	}

	public int _MWgaZxYKcqBeAlYsr226j7sbM0S
	{
		[CompilerGenerated]
		get
		{
			checked
			{
				_ = (ulong)((sbyte[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
				/*Error near IL_0002: Unknown opcode: 0xC0*/;
			}
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}
	}

	private unsafe _G4HZl6xJwrcuDmIkPCZEv6KhSrN(string P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Unknown opcode: 0xCF*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static _G4HZl6xJwrcuDmIkPCZEv6KhSrN _iUe4Q65CEiuUWa7iBhwsQKRNmaf(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x15
	}

	[IteratorStateMachine(typeof(_QsB9qZWHQDMLrWX3UUsqwEbeTQo))]
	public static IEnumerable<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> _yhhoTdxI3cba1wwjYFY8oIywPoj(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4B 0xF2
	}

	public int _0s7BnTa7QECXUctzgLGoxEqXm9X(int P_0 = 1)
	{
		if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0002: Unknown opcode: 0x24*/;
	}

	public int _KhT6m2eLN37yuswvDz2IGUsbBVC(int P_0 = 1)
	{
		/*Error: starg 10 (out-of-bounds)*/;
		/*Error near IL_0002: Unknown opcode: 0xF2*/;
	}

	public virtual string _5RU6m6RQWG9zt0PKA8ncfFUmRLC()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0001: Stack underflow*/- /*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Unknown opcode: 0xAB*/;
	}

	public virtual int _vU4UxKs8kzJleML5UufsADbk5il()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC7 0x88
	}

	public virtual bool _JLnVKxazDTsbncW5FaLxNDYw6AG(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF7 0x5A
	}

	static Match _206E_200B_202B_202A_206A_206A_206E_206B_202A_200C_200E_202D_202D_202C_202B_206D_200E_206D_200C_200B_200F_202A_206F_206F_206D_202A_206A_200C_202D_200D_206C_202A_200C_200F_206F_200F_200F_200C_200E_202C_202E(string P_0, string P_1)
	{
		/*Error: Unknown opcode: 0xE3*/;
	}

	static bool _200B_200D_206E_200E_202E_202C_200C_206E_200D_202E_206A_206B_202D_200E_200C_206E_202B_202E_206D_206F_200D_200F_206A_202B_206B_202A_206B_206B_202B_206C_200D_202A_200D_206F_200C_206E_200F_206D_206F_206C_202E(Group P_0)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static string _200F_200C_200D_206B_200C_202E_200E_202C_202A_200E_200B_206D_206C_202C_206D_202A_200B_206D_202C_200F_200F_200F_200E_206D_206F_200F_206E_202C_200E_206A_202E_202D_200D_206A_206C_200B_202E_202A_206D_200E_202E(Capture P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static int _200B_202E_206A_202A_200B_202B_200D_202B_206A_206E_206A_202E_206D_202D_206D_202D_206D_202C_200C_200E_200C_206B_206D_200B_202A_206F_202E_206D_206C_202C_200F_206B_206E_202A_202A_206F_200C_206D_202C_200F_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA3 0x6B
	}

	static string _206B_200C_202B_206C_206D_200F_200F_206C_206D_200F_202A_200D_200F_200C_202B_206F_202B_206F_202A_206A_206D_206B_200D_206E_206C_202D_202C_206F_200D_206D_200E_206F_206F_202B_202E_200B_206E_200F_200F_202D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x77
	}

	static int _200D_200C_202E_202E_200E_200D_202B_206F_200C_200F_206D_202E_202C_202A_202D_206E_202B_200F_202B_200D_206E_206A_206C_206A_206C_200E_202E_206E_202E_206F_206F_200B_206F_206E_200B_206D_206C_202A_202A_206E_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xCE*/;
	}

	static Type _200E_206A_206F_202E_206D_202D_200C_202B_206C_200D_202D_202E_202B_200C_200E_200D_206E_206A_202D_200B_206F_200E_202C_200D_200E_202E_202D_206A_206E_200E_202B_206E_206B_202C_202C_202B_206E_200B_202A_206A_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x98
	}

	static Type _202B_200E_206B_202D_200D_206F_200E_206B_206A_202B_206A_200F_206C_200D_206C_202C_206B_202D_206D_202A_202C_202C_200C_206D_206F_206E_200C_206D_200F_202E_202D_200F_206A_200D_206F_206E_206E_200D_200C_206F_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0x42
	}

	static bool _200F_202E_200E_206E_202E_206B_202D_202A_200E_202D_202D_206D_206F_200C_202A_202A_206B_202E_200B_206B_202B_206F_202C_206C_206E_202A_200B_206B_206C_206B_202E_202C_202C_206F_200F_200D_200D_206A_206E_202B_202E(Type P_0, Type P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x79
	}

	static bool _200F_206F_202E_200E_200B_200F_202E_202E_200C_202A_206E_202A_200B_206A_202C_206D_200B_202D_206D_200F_206E_202C_202A_202C_202B_200E_206B_206A_206C_202E_200D_202E_206E_206B_202E_202A_206A_200F_206E_206F_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	static bool _206F_206C_206E_206D_202A_202E_200E_206A_206E_200C_200D_202E_202E_200B_206F_200D_200C_206E_202B_200D_200E_202D_200B_206F_200E_200F_206B_200F_202B_206A_202B_202B_200D_202D_202D_206E_206B_206A_200E_206C_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}
}
