using System;
using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_VideoController")]
public sealed class _N8HN3DsxXrCBgkBJEcMaDNTubtp : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _2BiPiSFTMBS9wDqohxXLtXfHZ1c;

	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _RSen2ZwPqotFSflgOZEpUTa7cXb;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _CO7GHBAFKMlsJyBPogxaebuv0Yo;

	[CompilerGenerated]
	private string _nqvBvmL78WL3KTdxQ1zxtQUT0OF;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("PNPDeviceID", _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true)]
	public string _XQyaOXQZ5TUuzxjNDpcGpdH1d1v
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x40
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x60
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name", _z9iGSNwAHN9WJNl40wnjovc9b6g = true, _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true)]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Invalid comparison between Unknown and I4
			if ((int)/*Error near IL_0006: Stack underflow*/ < (int)checked((uint)/*Error near IL_0001: Stack underflow*/))
			{
				/*Error: Invalid branch target*/;
			}
			/*Error: End of method reached without returning.*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x24
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Caption")]
	public string _VaEBso6OOri1y0w9IQvg5zajb6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x93 0x7C
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Invalid comparison between Unknown and I
			if ((nint)/*Error near IL_0003: Stack underflow*/ < (nint)((Array)/*Error near IL_0001: Stack underflow*/).LongLength)
			{
				/*Error: Invalid branch target*/;
			}
			if (/*Error near IL_0008: Stack underflow*/ == /*Error near IL_0008: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			checked
			{
				_ = (long)/*Error near IL_0009: Stack underflow*/;
				/*Error near IL_0009: Invalid metadata token*/;
			}
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC5
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x98
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("VideoProcessor")]
	public unsafe string _C3PldzJWfUnmRl6JBkR32khQa9D
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}
		[CompilerGenerated]
		set
		{
			_ = *(float*)(-1);
			/*Error near IL_0002: Unknown opcode: 0xAB*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("AdapterCompatibility")]
	public string _qpzftm29eLlJyfqg2Yy5pCanApf
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE4
		}
	}

	protected override bool _7XSaEtGveaNphRXPJp1DwZ53W8u
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3D
		}
	}

	private _N8HN3DsxXrCBgkBJEcMaDNTubtp()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}

	static bool _200C_206D_202D_202E_202B_202C_206F_200C_202B_200F_200D_206E_206D_206B_200E_200F_200C_202B_206C_206D_202A_202C_206D_206E_206A_200B_200B_206D_200B_202D_200D_206E_202D_200E_200C_206F_200C_206D_206C_206C_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAC
	}
}
