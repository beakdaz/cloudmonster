using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

[DefaultMember("Item")]
public sealed class _HoDjNGQQWOu7flM3UN1QiGLYpcc : ICollection<_N1zFghe9GilBTRtLbiblz4JGYsM>, IEnumerable<_N1zFghe9GilBTRtLbiblz4JGYsM>, IEnumerable
{
	private readonly List<_N1zFghe9GilBTRtLbiblz4JGYsM> _bU7dgL3XtM6wx3amfCXa7QrwLoD;

	public bool IsReadOnly
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA1
		}
	}

	public int Count
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE3 0xE7
		}
	}

	// C# has no syntax for parameterized property '_iL3R5m8a5RgyADLJVYafgoHKEf3'.
	public _N1zFghe9GilBTRtLbiblz4JGYsM _eDO7eJdB1qoNcQKkPIn0MfYOZBP(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9B 0xCE
	}

	public _HoDjNGQQWOu7flM3UN1QiGLYpcc()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x04
	}

	public _HoDjNGQQWOu7flM3UN1QiGLYpcc(IEnumerable<_N1zFghe9GilBTRtLbiblz4JGYsM> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD0
	}

	public void Add(_N1zFghe9GilBTRtLbiblz4JGYsM item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5D
	}

	void ICollection<_N1zFghe9GilBTRtLbiblz4JGYsM>.Add(_N1zFghe9GilBTRtLbiblz4JGYsM item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Add
		this.Add(item);
	}

	public void _3bUY0p3zUFObETvZgyMcoYUmBTh(IEnumerable<_oh4yStHpxF3fEfcUptTuIXENCsi> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x23 0x48
	}

	public void Clear()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		((int[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (int)/*Error near IL_0001: Stack underflow*/;
		_ = (sbyte)(/*Error near IL_0002: Stack underflow*/ / /*Error near IL_0002: Stack underflow*/);
		/*Error near IL_0004: Not a type handle*/;
	}

	void ICollection<_N1zFghe9GilBTRtLbiblz4JGYsM>.Clear()
	{
		//ILSpy generated this explicit interface implementation from .override directive in Clear
		this.Clear();
	}

	public unsafe bool Contains(_N1zFghe9GilBTRtLbiblz4JGYsM item)
	{
		//IL_0002: Expected I, but got I8
		((IntPtr[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/] = (nint)(ulong)/*Error near IL_0001: Stack underflow*/;
		System.Runtime.CompilerServices.Unsafe.Write((void*)(nint)/*Error near IL_0003: Stack underflow*/, /*Error near IL_0003: Stack underflow*/);
		_ = *(ushort*)(nint)/*Error near IL_0004: Stack underflow*/;
		/*Error near IL_0004: starg 49 (out-of-bounds)*/;
		/*Error near IL_0006: Unknown opcode: 0xB2*/;
	}

	bool ICollection<_N1zFghe9GilBTRtLbiblz4JGYsM>.Contains(_N1zFghe9GilBTRtLbiblz4JGYsM item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Contains
		return this.Contains(item);
	}

	public void CopyTo(_N1zFghe9GilBTRtLbiblz4JGYsM[] array, int arrayIndex)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x79
	}

	void ICollection<_N1zFghe9GilBTRtLbiblz4JGYsM>.CopyTo(_N1zFghe9GilBTRtLbiblz4JGYsM[] array, int arrayIndex)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CopyTo
		this.CopyTo(array, arrayIndex);
	}

	public IEnumerator<_N1zFghe9GilBTRtLbiblz4JGYsM> GetEnumerator()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8C
	}

	IEnumerator<_N1zFghe9GilBTRtLbiblz4JGYsM> IEnumerable<_N1zFghe9GilBTRtLbiblz4JGYsM>.GetEnumerator()
	{
		//ILSpy generated this explicit interface implementation from .override directive in GetEnumerator
		return this.GetEnumerator();
	}

	public bool Remove(_N1zFghe9GilBTRtLbiblz4JGYsM item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFB 0x81
	}

	bool ICollection<_N1zFghe9GilBTRtLbiblz4JGYsM>.Remove(_N1zFghe9GilBTRtLbiblz4JGYsM item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Remove
		return this.Remove(item);
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8C
	}
}
