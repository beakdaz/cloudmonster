using System.Runtime.CompilerServices;
using xNet;

internal abstract class _xULUmRrI4p3f9lVXdlb81HoogZB : _Ua0fX2zuqNT58B5Lzv7fFD4JQH6
{
	internal class _dTRmokGBYGprQTuevxtuFT4S10C
	{
		[CompilerGenerated]
		private readonly int _hqp1cVdLjTj0lmwgL7eZFcGeeld;

		[CompilerGenerated]
		private readonly int _Vjudeq5ljOZZJ2rlcvi5sUZeGkT;

		[CompilerGenerated]
		private readonly int _ZFG7QbSijlJYv76UCB27XV4tfXb;

		[CompilerGenerated]
		private readonly int _4Bd2XBWl3pZbOoEjKWHs8tZodCA;

		public int _zioCkbCtKbGHJlUaPyVZaYGJcIA
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x6B 0x97
			}
		}

		public int _BrIlWYpC2Oee6zOqQidIy0GDVOB
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xF5
			}
		}

		public int _zG7rWrRHw2YOLuAbzGIrqPYJrCf
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xB3 0x08
			}
		}

		public int _MKjqD975CZWJcbFBMOXCLoA7R9n
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xA5
			}
		}

		public _dTRmokGBYGprQTuevxtuFT4S10C()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x83 0xE1
		}
	}

	internal class _qxkvlxjhONNUSzZ6SSMW5Pd0uze
	{
		[CompilerGenerated]
		private readonly int _S56acJcPOclaRgUqQwr61PsbDup;

		[CompilerGenerated]
		private readonly int _KftNFn0zMKnexjQ7Ia9T0PTd9XC;

		[CompilerGenerated]
		private readonly int _XTYvLLmq8acODTuS2Q69QQggg2H;

		[CompilerGenerated]
		private readonly int _i2Vxcf5nzpe1X8UVNfv6wrgfVKh;

		public int _2qOPKbbBKDS17lm8plAWIsbJlrL
		{
			[CompilerGenerated]
			get
			{
				/*Error: Unknown opcode: 0xE1*/;
			}
		}

		public int _PnUYYvvXEwjq7VcUXt3W4QtRyYB
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x71
			}
		}

		public int _FCh2Eqk439clVXG5tX82rbJXYiA
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x8B
			}
		}

		public int _trGJzSh0xIHboptpTBht5TFg9mh
		{
			[CompilerGenerated]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x95
			}
		}

		public _qxkvlxjhONNUSzZ6SSMW5Pd0uze()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3D
		}
	}

	private _qxkvlxjhONNUSzZ6SSMW5Pd0uze _EPZiYl8HelU11LG3dsAqAZ4eIBg;

	private _dTRmokGBYGprQTuevxtuFT4S10C _HLMbt3xJlFiaiKsWbRZ6RhpNa6x;

	public _qxkvlxjhONNUSzZ6SSMW5Pd0uze _T4Lb0TmlEjEOiAObPZzXW0CU7pn
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC8
		}
	}

	public _dTRmokGBYGprQTuevxtuFT4S10C _hFuLHY7WObbU32FfQ9SUFf1hWrH
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF7 0x02
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected _xULUmRrI4p3f9lVXdlb81HoogZB(ProxyClient P_0)
	{
		_ = ((short[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
		/*Error near IL_0001: Unknown opcode: 0xE4*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected static string _7twmgIL4YscpZRnv8tIaikgiVPn()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x57 0x88
	}

	static void _202E_202D_206B_206D_200F_202E_202D_202A_200E_202E_200E_202A_206D_202D_200F_202A_206B_200F_200E_202A_206F_202C_206B_200C_202B_200F_202B_200E_206E_200C_206B_206A_206F_200B_206F_202A_202E_202D_200E_202D_202E(HttpRequest P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static void _202D_200E_200C_206F_206B_202C_206A_200D_202D_206F_202A_200E_200F_206A_206B_200C_206A_206F_200E_200C_206E_206E_200B_202D_202D_200E_206A_206E_200D_202E_206D_206D_202B_200F_206B_200C_206F_200C_200C_202A_202E(HttpRequest P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x70
	}

	static void _206A_202E_200C_206A_206F_200C_206D_202C_202B_206B_206C_202C_202B_206E_206E_200E_200C_200D_200E_206F_200E_206B_202C_200F_206E_200E_206A_202A_206B_202B_202E_206E_202A_200D_206C_206A_202E_206B_206B_202E_202E(HttpRequest P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static string _200F_206A_202E_206A_206D_206D_206F_206E_200E_206C_206B_206B_206B_202B_206A_200B_206E_202E_200D_202A_200F_200B_200F_202C_200F_206F_202D_200E_202B_200D_202B_206C_206B_206E_202B_202A_206B_206D_206D_206B_202E(string[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC9
	}
}
