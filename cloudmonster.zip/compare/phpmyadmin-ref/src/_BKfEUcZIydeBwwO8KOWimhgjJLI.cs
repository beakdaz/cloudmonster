using System;
using System.Runtime.CompilerServices;

[AttributeUsage(AttributeTargets.Class)]
public sealed class _BKfEUcZIydeBwwO8KOWimhgjJLI : Attribute
{
	[CompilerGenerated]
	private readonly string _xaA6cTPLQfip2NO6ytA1fnvp1tD;

	public string _uJya2ErR45S53TCECbeFTl2xEIF
	{
		[CompilerGenerated]
		get
		{
			/*Error: Invalid branch target*/;
		}
	}

	public _BKfEUcZIydeBwwO8KOWimhgjJLI(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}
}
