using System;
using System.Security.Cryptography;

public sealed class _cqCEP37YAlup4oCa4xMSP5lpKZJ : HashAlgorithm
{
	public const uint _WzjCf6IFdZnmWabY2VeqjWo6Wt3A = 3988292384u;

	public const uint _UAY2RMoanlJJCiCdpL0JNQ6fIKX = uint.MaxValue;

	private static readonly uint[] _KwJMTsYAOl5NsTgDB1whMHB2OECA;

	private readonly uint _HnhqnYfN7dlhrb0Pg3waAp2WTyF;

	private readonly uint[] _B0ksW8MxvRlNnifLFaYPp8LeZi;

	private uint _TKweURtdSL8aZf0X2kITTqz27xP;

	public override int HashSize
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x80
		}
	}

	public _cqCEP37YAlup4oCa4xMSP5lpKZJ()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE9
	}

	public _cqCEP37YAlup4oCa4xMSP5lpKZJ(uint P_0, uint P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB1
	}

	public void _btGzZVH3Z96fu2lLwdyPruNRtBg()
	{
		checked
		{
			_ = (ushort)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Invalid field token*/;
		}
	}

	protected void _1fgLrEkFNP9qvRfb3kRmBYgcVzM(byte[] P_0, int P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA0
	}

	protected byte[] _Gv3Q3kU00a9pIbSCsJuBEkSk6Ke()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	public static uint _TssrSAqMjpYSPxpSuQLqIJroLKg(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x14
	}

	public static uint _TssrSAqMjpYSPxpSuQLqIJroLKg(uint P_0, byte[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0x7E
	}

	public static uint _TssrSAqMjpYSPxpSuQLqIJroLKg(uint P_0, uint P_1, byte[] P_2)
	{
		/*Error: Unknown opcode: 0xAA*/;
	}

	private static uint[] _Ub1VV2yub8KdldjXizUVclsMRMQ(uint P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x96
	}

	private static uint _JLMSdLTaN4OxRjBG9z2iLhMB0hN(uint[] P_0, uint P_1, byte[] P_2, int P_3, int P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	private static byte[] _L5vZJPlv39iOcLqJlLteEvhJZr0(uint P_0)
	{
		/*Error: Unknown opcode: 0xEE*/;
	}

	static _cqCEP37YAlup4oCa4xMSP5lpKZJ()
	{
		/*Error: stloc 233 (out-of-bounds)*/;
		_ = (ulong)/*Error near IL_0003: Stack underflow*/;
		/*Error near IL_0003: Unknown opcode: 0xCA*/;
	}

	static byte[] _200C_200E_202E_206A_202A_206D_206E_200D_200C_206A_202C_206D_206A_206D_206A_202A_200F_206A_206A_206E_200C_200F_202A_206B_200D_206F_200B_200D_206C_202E_200B_200E_206B_202D_206C_200F_200E_200C_206A_202A_202E(uint P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x38
	}

	static void _200F_200F_200B_200E_202E_206F_202A_200D_200C_200C_206D_202E_200E_202A_202A_206F_202B_206C_202C_206E_200E_200B_200C_200B_206C_202C_202E_200C_206D_202B_200E_206A_202B_206C_200D_206B_200D_202D_200D_202D_202E(Array P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x01
	}

	static void _200D_202B_206E_206C_200C_202D_206C_206D_206D_202D_200F_206C_202B_200C_206F_202D_202B_206D_202E_202A_202E_200F_206F_202B_206E_200B_206D_206E_200E_202E_206F_206A_206B_200E_200D_206C_200E_206D_206C_202B_202E(Array P_0, RuntimeFieldHandle P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		((object[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (object)/*Error near IL_0001: Stack underflow*/;
		_ = /*Error near IL_0002: Stack underflow*/% /*Error near IL_0002: Stack underflow*/;
		/*Error near IL_0002: Unknown opcode: 0xF9*/;
	}
}
