using System;
using System.Management;
using System.Runtime.CompilerServices;

public sealed class _oh4yStHpxF3fEfcUptTuIXENCsi
{
	private readonly PropertyData _G7zES0Yjxa1Gp5jXjARExEEcXGF;

	[CompilerGenerated]
	private readonly string _ns1lFRs9gE3KSYDqVpElFPvPTHe;

	[CompilerGenerated]
	private readonly string _KiQDwqqAbikC4OHjED90o8KqQUq;

	public string _uOcTyWZQhKr03LoVxwVHNeAWaEb
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA9
		}
	}

	public string _30Osqx1RJHqpD6nxwujM4LxpRo
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x71
		}
	}

	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x1A
		}
	}

	public object Value
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD1
		}
	}

	public string _fPTRJnNNhYVTQ5PBIOBVDFopM5I
	{
		get
		{
			_ = ((long[])/*Error near IL_0003: Stack underflow*/)[checked((sbyte)/*Error near IL_0001: Stack underflow*/)];
			/*Error near IL_0003: Unknown opcode: 0xC9*/;
		}
	}

	public Type _ayQ0OyljLfTgpCQfSdxidtiiimi
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEC
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _oh4yStHpxF3fEfcUptTuIXENCsi(string P_0, string P_1, PropertyData P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA5
	}

	private static Type _lQx4XQBNHdpxzuHdDxEVAeg758B(CimType P_0, bool P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1D
	}

	static string _202B_200E_200B_200D_200D_202E_206D_202D_202C_200B_206F_206A_206F_202A_202D_202B_200C_200E_202E_206C_200F_206D_200F_206B_206C_202D_200F_202B_202A_206B_202C_206F_202A_202D_206F_206B_200B_206A_202C_202C_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	static object _200C_200F_200C_202E_206E_200E_202B_202E_200E_206C_200C_202A_200F_200B_200E_200B_200C_202A_200F_200C_202D_202E_202A_206F_200E_200D_200B_202D_206D_200B_200C_206F_200C_200F_202D_200C_200D_206A_200F_206F_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB8
	}

	static string _200F_202C_202B_202A_206F_202B_202E_206C_202B_202B_206D_202A_206D_206E_206D_202A_202B_206C_200F_200C_202C_200D_200B_206B_200B_202D_206C_200B_206A_202B_202A_206F_200C_202D_206C_202A_200B_206A_202D_206F_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x00
	}

	static CimType _202B_200B_206F_202D_206E_202C_202D_206D_200F_200F_202C_202C_200C_200F_206B_202C_206D_206A_202A_206D_200D_200C_202A_206A_206A_202E_202D_200E_202C_200B_200F_202D_206D_200D_202C_206D_206F_206A_202B_206E_202E(PropertyData P_0)
	{
		/*Error: Invalid branch target*/;
	}

	static bool _200D_206D_206B_206A_206E_202E_200C_200B_200C_200D_202E_202B_202D_200D_202C_206E_202E_200B_206E_206E_202B_200D_202A_202C_206A_202B_200E_200E_206C_200F_206D_206B_202B_200C_200B_200B_200E_206F_202C_206B_202E(PropertyData P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	static Type _202B_206B_200E_206C_206C_200F_206D_200D_202D_206C_200D_202E_202E_202D_202E_200D_200B_202C_200F_206A_202A_206D_202D_200D_200C_202D_206A_206C_202D_202D_206B_206B_202D_206D_200C_202D_206C_206D_202B_202A_202E(RuntimeTypeHandle P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0x1F
	}

	static bool _206F_202B_202E_200B_206C_202A_202E_200E_202C_202B_200B_202C_200B_200D_200D_202B_200D_206D_202E_202B_202E_206F_202D_202E_206A_202E_206F_200F_202C_202C_206F_202B_206C_202A_202D_202E_202B_206C_206D_200E_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x07 0xCE
	}

	static ArgumentException _202D_206C_200C_206C_202C_200C_200F_200C_206A_200F_206B_202D_200D_200C_200D_206A_206F_206C_206A_206A_200C_202C_206C_202A_202C_206B_202D_202B_206D_206E_202C_206A_202A_206A_206E_200B_202A_206C_202B_200D_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x19
	}

	static ArgumentNullException _200B_206F_202A_206D_206E_206B_206F_206F_206D_200E_206E_202A_206A_206E_206C_206A_206B_206C_200B_202D_202C_202B_206C_206F_200E_206D_202C_202C_206C_200F_200F_202C_200B_206D_202D_202D_202E_202C_202C_200C_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xEF*/;
	}
}
