using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_Processor")]
public sealed class _YAAoKMgNXRuZegk2ZtB5gQy2igB : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _8Pz83HZyIy7vkOfoaLObaLKmEe1;

	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _z0Mc2acdAVfpSzRSgSbrZmZaIfU;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _IR4UikgDdp8PuDPgCYLoVBhsdaV;

	[CompilerGenerated]
	private string _8IJBgIvMysylbJ6UWCXWJ3JDjON;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("ProcessorId", _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true, _z9iGSNwAHN9WJNl40wnjovc9b6g = true)]
	public string _lmqqvzxKpv6X7958Pp1GORn5ebd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD1
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xAA*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name")]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC8
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("UniqueId")]
	public string _ufJZQbfy8U3JqSimUp9Am8mR5nD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x10
		}
		[CompilerGenerated]
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0002: Stack underflow*/- /*Error: ldarg 3 (out-of-bounds)*/;
				/*Error near IL_0002: stloc 21 (out-of-bounds)*/;
				/*Error near IL_0004: Unknown opcode: 0xCA*/;
			}
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x29
		}
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xF3*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Manufacturer")]
	public string _2LGcfWg9irJpfYK5B4taNm2rHsG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x18
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5C
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("SocketDesignation")]
	public string _vXAERTE0vm7L2oDKkg96OTXPv2e
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE4
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF9
		}
	}

	private _YAAoKMgNXRuZegk2ZtB5gQy2igB()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}
}
