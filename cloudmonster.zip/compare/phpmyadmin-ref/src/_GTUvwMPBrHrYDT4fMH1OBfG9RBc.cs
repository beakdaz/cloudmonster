using System;
using System.Collections.Generic;
using System.Management;
using System.Runtime.CompilerServices;

public static class _GTUvwMPBrHrYDT4fMH1OBfG9RBc
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _swm3UDechlpOE3KIJEwmNq6eHS2
	{
		public static readonly _swm3UDechlpOE3KIJEwmNq6eHS2 _003C_003E9;

		public static Func<_N1zFghe9GilBTRtLbiblz4JGYsM, IEnumerable<_oh4yStHpxF3fEfcUptTuIXENCsi>> _003C_003E9__3_0;

		static _swm3UDechlpOE3KIJEwmNq6eHS2()
		{
			/*Error: ldloc 0 (out-of-bounds)*/;
			/*Error near IL_0001: Unknown opcode: 0xBC*/;
		}

		public _swm3UDechlpOE3KIJEwmNq6eHS2()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal IEnumerable<_oh4yStHpxF3fEfcUptTuIXENCsi> _kQViMgOBV6qKcfEayrjJ4cbld6k(_N1zFghe9GilBTRtLbiblz4JGYsM P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF9
		}
	}

	[CompilerGenerated]
	private sealed class _UcBsiqmlmG8zOiTFjINLVxBtLkC
	{
		public ManagementBaseObject _R9oPWUwHxg3bBntnh0VtVddSYqI;

		public ManagementObject _Kr8zOCiYoqKdqisFKVBFfHEYVZb;

		public _UcBsiqmlmG8zOiTFjINLVxBtLkC()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal _oh4yStHpxF3fEfcUptTuIXENCsi _MRpsPOgfAdyeKboVoeHgaELQO7k(PropertyData P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0D
		}

		static ManagementPath _202C_202D_200F_200C_206F_206E_200B_206E_206D_202B_200B_206D_202A_206A_202C_202C_200D_206D_206B_200D_206E_200B_200F_206B_200F_206E_206E_206A_200D_200C_202A_202A_206E_200C_200D_206D_206C_200E_206C_202E_202E(ManagementBaseObject P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x20
		}

		static string _200C_206E_200D_206C_200E_200C_206F_206F_200F_200E_200C_202B_206D_200C_200E_206B_206F_202A_202E_206E_202A_202B_206F_202D_206C_202D_202B_206A_200E_202B_206F_200B_206D_202E_200C_202A_206B_202D_202A_202E(ManagementPath P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x39
		}

		static ManagementScope _206A_200B_202B_206C_202C_202C_200E_206B_202C_202B_202E_202B_206A_202D_206B_200D_206E_200B_200D_200D_200C_200E_206C_206B_200E_206C_200F_202B_200C_206E_202B_200F_206D_202D_200F_202E_202C_206E_200D_206E_202E(ManagementObject P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBB 0xFC
		}

		static ManagementPath _200E_202D_206C_200D_206C_200E_200C_206E_200F_206E_200D_206D_202A_206F_206F_200D_206B_206B_200B_206A_206B_202C_200B_202D_202D_206B_200F_206F_206E_202D_200B_202D_202B_206D_206F_206E_200E_200B_200C_206F_202E(ManagementScope P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}

		static string _200B_206D_200C_202C_202E_200B_206E_202E_206B_202D_200D_206D_200C_202D_200C_202E_206A_206E_202C_200D_206B_202E_200D_206A_202C_200F_206A_200E_200E_200B_202B_200B_200D_206A_200E_202E_202A_202E_200B_202B_202E(ManagementPath P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD3 0x52
		}
	}

	public static _HoDjNGQQWOu7flM3UN1QiGLYpcc _Xot50VxJi1gkgCcdZnwwEgknkn0(string P_0, string[] P_1 = null, string P_2 = null, ManagementScope P_3 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC8
	}

	public static _HoDjNGQQWOu7flM3UN1QiGLYpcc _x5Y5j3OOcc5RPJMlgS29lFONtmD(ObjectQuery P_0, ManagementScope P_1 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA5
	}

	public static _HoDjNGQQWOu7flM3UN1QiGLYpcc _x5Y5j3OOcc5RPJMlgS29lFONtmD(string P_0, ManagementScope P_1 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x28
	}

	public static _oh4yStHpxF3fEfcUptTuIXENCsi _1GB8lNWnUsM9zdZIPHgeRKE8mWD(string P_0, string P_1, string P_2 = null, ManagementScope P_3 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC0
	}

	public static _0001 _1GB8lNWnUsM9zdZIPHgeRKE8mWD<_0001>(string P_0, string P_1, string P_2 = null, ManagementScope P_3 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6F 0x8E
	}

	private static ManagementObjectCollection _Ctf7gGa09gbu75NxmLBkcKzvZTE(ObjectQuery P_0, ManagementScope P_1)
	{
		_ = (short)(-1);
		/*Error near IL_0002: Unknown opcode: 0xC8*/;
	}

	private static ManagementObjectCollection _Ctf7gGa09gbu75NxmLBkcKzvZTE(string P_0, ManagementScope P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x30
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static ManagementObjectCollection _Ctf7gGa09gbu75NxmLBkcKzvZTE(string P_0, string[] P_1, string P_2, ManagementScope P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	private static ManagementObjectCollection _Ctf7gGa09gbu75NxmLBkcKzvZTE(string P_0, string P_1, string P_2, ManagementScope P_3)
	{
		/*Error: Unknown opcode: 0xC5*/;
	}

	private static _HoDjNGQQWOu7flM3UN1QiGLYpcc _hGAeVRnJwSQ8f1kDboup1wntlnM(ManagementObjectCollection P_0)
	{
		/*Error: Unknown opcode: 0xAE*/;
	}

	static ObjectQuery _202C_200E_206D_206B_200C_200C_200C_202E_200D_200C_206D_206D_200F_200D_206A_206D_200B_200E_206E_202D_202D_200F_202E_202A_200D_202C_200F_202E_202E_200F_200B_200F_202D_200C_206A_202D_202D_206E_202E_206D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC3 0xC3
	}

	static ManagementObjectSearcher _202B_200E_206D_200D_200B_206E_206D_202B_200B_200D_202C_202A_202E_200F_206A_202C_202E_202E_200F_206C_202B_202C_206E_200B_206D_200F_206E_206F_200D_200B_202A_202D_206B_206C_202E_206F_206F_206D_206C_206B_202E(ManagementScope P_0, ObjectQuery P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC1
	}

	static ManagementObjectCollection _200C_202E_206F_200F_206A_206B_202E_202C_202D_202E_206A_206D_202D_206E_206B_202C_200E_202A_200B_206B_200D_200F_200C_202A_200D_200F_202E_202E_200C_206E_206C_200B_202C_206E_202C_200C_206C_206B_202A_206D_202E(ManagementObjectSearcher P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3D
	}

	static void _202A_200F_206B_202D_206C_206D_202A_200F_202E_202C_202B_202E_206D_202B_206B_202B_206C_200D_206A_202B_202E_200C_206A_206B_206B_200C_200F_200F_202E_200C_206C_200C_206C_202B_206A_200B_206F_206D_206D_202B_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	static string _202D_206E_206B_206E_206E_206F_202C_200F_206B_200E_202A_206B_200F_200C_206F_202A_200F_202C_202B_202A_206B_200D_206F_206F_202D_202C_200E_206E_206D_200B_202B_206C_200C_200D_206B_206D_200F_200C_206C_206D_202E(string P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	static bool _202C_206C_206C_206C_206F_200C_200B_202A_200D_202D_202C_200C_200C_202E_206C_206D_206A_202A_206A_202B_200E_202E_202B_202B_206B_202E_202B_202E_202E_202C_202D_206E_202E_200D_206C_206A_206C_206F_200C_206C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x07 0xCE
	}

	static string _206D_206B_200F_200C_200B_206E_206D_206D_206E_206F_206F_202C_206A_202A_200E_200C_206D_206B_206C_206D_200E_206F_202B_202E_200F_200D_200C_200E_200E_200F_206C_206B_202A_200E_200D_202E_202E_206F_206A_206A_202E(string P_0, string P_1, string P_2, string P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static string _202D_202B_200E_202E_200B_206D_202E_202C_206D_202B_206A_206D_206B_206E_202B_206E_206B_206A_202E_202B_202A_206E_200D_202A_206E_200B_202C_206D_206B_202D_202B_200E_200F_206E_206D_206F_206A_200D_202C_200F_202E(string[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC9
	}

	static int _200C_206F_200D_202A_200C_206C_202D_200D_202C_200C_202A_202D_200C_206D_202B_202A_200C_202E_206B_206C_200D_202E_202B_200F_202D_202E_206A_200B_200D_202A_200B_206D_200C_206B_200B_200F_206B_206E_200B_202A_202E(ManagementObjectCollection P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	static ManagementObjectCollection.ManagementObjectEnumerator _200F_202D_200E_202D_200F_202E_200D_200F_202D_200B_206F_206E_200F_202E_206E_206B_202B_200B_206A_202E_206D_202A_206D_200F_200D_206D_206F_206B_202E_206B_206B_202A_206A_206A_202D_206A_202E_206E_202D_200F_202E(ManagementObjectCollection P_0)
	{
		if (/*Error near IL_0005: Stack underflow*/ >= /*Error near IL_0005: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = ((short[])/*Error near IL_0006: Stack underflow*/)[/*Error near IL_0006: Stack underflow*/];
		/*Error near IL_0006: Metadata token must be either a methoddef, memberref or methodspec*/;
	}

	static ManagementBaseObject _200F_206D_206B_200C_202D_206A_202E_202B_206E_202B_206D_206D_206D_206C_206C_206E_200C_202A_200C_206F_202C_200D_206F_202E_202D_206E_202C_202B_202E_206B_206E_206B_200C_202D_200C_202C_200B_202B_202E_200E_202E(ManagementObjectCollection.ManagementObjectEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5D
	}

	static PropertyDataCollection _200F_200F_202B_200E_206D_200D_206D_202C_202D_200D_200D_202D_202C_206A_202C_200D_200D_206C_200E_206A_202A_206A_202E_202C_200C_202B_206C_206F_200E_200C_206D_200E_200B_206C_206B_206F_206B_206A_206F_202E(ManagementBaseObject P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	static bool _200D_206D_206C_200D_206D_200E_206D_200F_206B_200C_202E_200C_200F_202A_202A_200E_206B_206A_202E_206B_200F_206A_206B_200D_206E_202C_200C_200E_206A_206C_200C_206A_202A_200D_206A_202D_200B_206B_202D_202B_202E(ManagementObjectCollection.ManagementObjectEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD1
	}

	static void _206C_206A_200D_200F_206E_206D_200F_202D_202D_202A_200F_206B_202C_202B_206A_200C_200B_206C_202D_200F_202E_202A_206E_202C_200E_206B_200E_202A_206D_202B_200C_202E_200E_200E_206D_200B_200F_206B_202E_206E_202E(ManagementObjectCollection P_0)
	{
		/*Error: Unknown opcode: 0xA7*/;
	}
}
