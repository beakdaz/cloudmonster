using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using xNet;

internal abstract class _ssb9nw7YLUz7EsGj6hyMDcS0rLH : _Ua0fX2zuqNT58B5Lzv7fFD4JQH6
{
	internal class _D6U8c0vI5qXcGKOtBnKhHFlqTMV
	{
		private string _mlLq3OuDYfNi2MAXSCBWZTe2enR;

		private string _o74SjZ4R1ntnGIRDkI9TMHAM52f;

		private string _ujLBYA32w3usY9RhNHf6cghgGyO;

		private string _ZA2l4aTeOtl2iaatt7nFhpOSD6b;

		private string _6PBZDFW7G7QlZnz9UIPHcNLh7ih;

		private int _W1TRTBacMhUdsOEGQCZJqH0oPSe;

		private int _e2WDNsrQdYo1r6CCUXrt0uDrHWZ;

		private int _5jcNlErcykPxk95cNlpheoxXwmR;

		private int _m7ifS7UXGhTn2qLS0GhiN4pjP6A;

		private int _k3V1WcZhIyJTPBuQM4QUUSKgSnE;

		private static readonly string[] _0KLzwVilyfTxSVh0qTuHKWRAPEH;

		private static readonly Dictionary<string, string> _xgiGaaIcAsdeVTudyxSwUBULtQL;

		private static readonly Dictionary<string, (int width, int height)> _7lLbmBciNcpeDpSTMDJ6pQpjfudA;

		private static readonly Dictionary<string, (int width, int height)> _UBy31aAAqPP2vkzB48H7jGoTG1r;

		private static readonly Dictionary<string, int[]> _AopNOPCBbcEMb6vt1j3gWQL0XJs;

		public string _3RkdMt0F4tkVgRu6tUerms2J0Zc
		{
			get
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				//IL_0002: Unknown result type (might be due to invalid IL or missing references)
				//IL_0005: Expected F4, but got I4
				((float[])/*Error near IL_0005: Stack underflow*/)[/*Error near IL_0005: Stack underflow*/] = (int)checked((byte)unchecked(/*Error near IL_0003: Stack underflow*/ / (/*Error near IL_0002: Stack underflow*/ >> 6)));
				/*Error near IL_0005: Unknown opcode: 0xED*/;
			}
		}

		public string _Gej617gA1HU3HQbdLzhOryLClsR
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xBD
			}
		}

		public string _YJVs00sOaXGHlgtojDA3XgmEsXw
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x37 0x16
			}
		}

		public string _3vBDOFEwX2FmtDTOHtMj1T58DlL
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x43 0x0E
			}
		}

		public string _NP0mfera5Nd2qLHDs05gNUwtwuB
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x06
			}
		}

		public string _ykBaFdjYlybwzAs5CjPXSAHO7of
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x0D
			}
		}

		public int _4SFhkY2wRm4ma4FTS84CAW3N01h
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x37 0x61
			}
		}

		public int _dfex5KvbAOUryxUcRBuHiw7cVv4
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0xF9
			}
		}

		public unsafe int _1wqzZMROOmfl9Oiu4CADni5lC0h
		{
			get
			{
				_ = *(byte*)(nint)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: ldloc 0 (out-of-bounds)*/;
				/*Error near IL_0002: Invalid field token*/;
			}
		}

		public int _Bd6wIA5fpVetlR0Ao0ravgZNu6T
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x95
			}
		}

		public int _CN6kiuuas3vRXQKnmtevxyRM99B
		{
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x89
			}
		}

		public string _0AwfARaddnecOAN8SViw9woq1NG
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x18
			}
		}

		public _D6U8c0vI5qXcGKOtBnKhHFlqTMV()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		static _D6U8c0vI5qXcGKOtBnKhHFlqTMV()
		{
			/*Error: Unknown opcode: 0xFF*/;
		}

		static bool _206A_206F_202D_202B_206B_200C_202D_206D_200C_202C_206C_202D_202C_206B_202B_200D_206F_202C_206B_206C_200E_200F_200E_206B_206A_206F_206E_206E_200F_202A_202C_202A_202A_202E_206F_200C_202A_202C_206D_202E_202E(string P_0, string P_1)
		{
			/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
		}

		static string _202D_200E_206F_200E_200F_206B_202B_202C_202B_206B_202B_200D_202B_200F_200B_206A_202E_206E_206D_200B_206D_206F_206F_202B_200C_206F_206F_206D_202C_206E_202A_202B_202D_200D_200C_206C_200F_206A_202E_200F_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC5
		}

		static string _202C_200D_200E_206C_200D_206B_200B_202A_202D_200F_200F_202A_200B_206E_206F_206A_202C_206F_200B_202C_202A_200F_200D_202B_206B_200E_202A_202D_202C_202E_206E_202E_202A_200F_206E_206C_202A_200B_200B_200F_202E(string P_0, char P_1, char P_2)
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x7636ABB7
		}

		static string _206A_206E_206B_206C_206D_200B_202C_206F_206E_200C_202B_206F_202A_200C_202D_202A_202A_202B_206F_206F_202D_202B_206F_206A_202D_202A_202B_200B_202E_206E_206F_206D_202A_202D_200E_206C_202D_206C_202A_206C_202E(string P_0, string P_1, string P_2, string P_3)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}

		static void _206F_200F_202C_200D_206C_202E_202B_202A_200B_206D_206E_202D_202E_206D_200D_200D_200D_206B_206C_206A_200F_200D_200F_202D_202A_206E_200B_200F_206D_200D_206C_200F_206E_202B_200D_200D_202D_200B_206B_202A_202E(Array P_0, RuntimeFieldHandle P_1)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			((object[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (object)/*Error near IL_0001: Stack underflow*/;
			_ = /*Error near IL_0002: Stack underflow*/% /*Error near IL_0002: Stack underflow*/;
			/*Error near IL_0002: Unknown opcode: 0xF9*/;
		}
	}

	private _D6U8c0vI5qXcGKOtBnKhHFlqTMV _k3hdzrqGtUBu643xU4v4vvjM4TJ;

	public _D6U8c0vI5qXcGKOtBnKhHFlqTMV _NCZusUsYD5UVeyBsniGnNVfBQ5f
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x91
		}
		protected set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x95
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected _ssb9nw7YLUz7EsGj6hyMDcS0rLH(ProxyClient P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x33 0x05
	}

	static void _206C_200C_202B_200F_206E_202E_202B_202E_202B_206D_206F_202E_200B_206D_200B_202E_206B_200B_200C_206A_202E_206A_206D_206E_202D_200F_202C_202C_206B_200B_200E_206F_200E_206A_202C_206B_202A_200F_202B_206D_202E(HttpRequest P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x70
	}
}
