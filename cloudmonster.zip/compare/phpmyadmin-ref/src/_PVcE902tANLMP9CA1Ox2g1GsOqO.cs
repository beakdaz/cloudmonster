using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Input;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Definitions.Series;
using LiveCharts.Wpf;
using Microsoft.Win32;
using xNet;

internal abstract class _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> : _6r331qX72SngFdxF5rE3fjNTQIi where _0001 : _80FwX1vIzoG3pmTETaxQdVKVSED, new()
{
	public enum _3VEcGB4twz7bdUPRpfl7PnyfkobA
	{
		Idle,
		Working,
		Stopping
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _2hSgFT4zP9GdphFbiFyQFL3pdVd
	{
		public static readonly _2hSgFT4zP9GdphFbiFyQFL3pdVd _003C_003E9;

		public static Action<Thread> _003C_003E9__115_1;

		static _2hSgFT4zP9GdphFbiFyQFL3pdVd()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF8
		}

		public _2hSgFT4zP9GdphFbiFyQFL3pdVd()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _JGRVAKrlA3ITVijqtPvFIb7MIOdA(Thread P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}

		static void _202B_206A_206B_206F_206D_206E_206F_202A_206E_206E_200B_202A_206B_202D_200F_200B_200B_202D_200C_202B_200E_202D_200D_202C_202B_200D_200B_200B_202C_202D_202C_202D_206A_200E_206D_200E_200D_206A_200E_202C_202E(Thread P_0)
		{
			//IL_0000: Unsupported input type for neg.
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = 0 - /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xAB*/;
		}
	}

	[CompilerGenerated]
	private sealed class _X7Gmbgmfj5dRhqBZkv32igBl4VM
	{
		public List<_0001> _6cRACqJww1WtEG2hFt4A4iAyKzCA;

		public StreamReader _ToDhinFGSEzdWwvcgBgeKQINc09;

		public _X7Gmbgmfj5dRhqBZkv32igBl4VM()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _iPdVSGZ89NIRU4VCj5oaSdittzb()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9D
		}

		static string _202D_200C_202A_202A_206A_202E_200E_206B_200F_200C_206A_206B_202E_206B_206F_202B_200F_202A_200C_200B_206D_206A_202A_200F_202E_200B_202D_202D_202A_206E_202B_200B_206E_200B_206F_206D_206C_206A_200D_200E_202E(TextReader P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDD
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _ApIe0nA3diEJTWBUjOSbxgEth9A : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x50
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			/*Error: Unknown opcode: 0xC1*/;
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static OpenFileDialog _200D_200D_200E_200C_202C_202D_200E_200F_206A_200B_200C_200C_206B_206E_200C_202C_202C_206F_202D_202A_200E_200C_206B_206B_200D_202B_206A_206F_206D_202C_200E_202B_206A_200B_200F_202C_200F_200F_206F_206B_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x02
		}

		static void _206F_202E_202A_202E_200B_200D_202E_206C_206D_202B_206A_206E_206B_206D_200F_206F_200C_206F_200E_202B_206C_202E_206B_202B_206B_200B_202E_206E_206D_202E_202D_202A_200E_202B_202D_202D_200D_200B_202C_202D_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC3 0xEB
		}

		static void _202C_206B_200F_202C_200B_202D_202A_206D_200D_202B_202E_202C_200E_200D_200C_202B_206B_200E_202D_202E_206A_206E_202B_206B_206C_202A_200C_202A_206A_206B_202D_202A_206B_200C_202B_200D_206F_200B_200C_202E_202E(OpenFileDialog P_0, bool P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}

		static void _202E_202D_206A_200D_202A_206B_202B_200B_206A_202D_202E_206F_200C_200C_200B_206E_206E_200F_206A_202B_202C_202C_206C_206B_202B_206F_202D_202D_202C_206E_206B_200E_206B_200E_200C_202A_200C_200E_202E_206E_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0D
		}

		unsafe static bool? _202E_206A_206F_200E_202B_200C_206D_202B_206C_206F_206C_200C_200C_200C_200B_200B_200D_206C_200C_200B_206F_200F_200E_206B_202B_202C_206B_200B_206E_202D_200D_202A_200F_202A_202B_202D_202E_200F_202D_202E(CommonDialog P_0)
		{
			//IL_0008: Expected native int or pointer, but got F4
			double num = ((double[])/*Error near IL_0002: Stack underflow*/)[(nint)((Array)/*Error near IL_0001: Stack underflow*/).LongLength];
			*(_003F*)null = /*Error near IL_0007: ldloc 1 (out-of-bounds)*/;
			_ = ((sbyte[])/*Error near IL_000a: Stack underflow*/)[num];
			/*Error near IL_000a: Unknown opcode: 0xA9*/;
		}

		static string[] _200C_206E_202B_202C_200F_206C_200F_200C_200C_200F_200B_202B_206B_206B_202C_206A_206E_200D_206C_202A_206F_200F_202C_206E_200F_206D_206E_206A_200B_206F_206D_202B_206B_202D_206C_206A_206A_202B_206A_202E(FileDialog P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x41
		}

		static TaskAwaiter _206E_206A_202A_200F_200C_202A_200E_200F_206E_200D_206F_206E_200E_206E_206F_200C_200F_202C_206D_206A_206D_206D_200E_202C_200B_200D_206F_200B_202A_200C_200F_206C_200D_206A_206A_200F_206F_206F_206E_200F_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _sIh4Y0aUHolWqubwbpGzbo9W17h : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		public IEnumerable<string> _A09g2v92abaXoPFjVD2dbqfXerp;

		private _X7Gmbgmfj5dRhqBZkv32igBl4VM _UsuLem83vLyu2TtSUOnDVcs6EDb;

		private IEnumerator<string> _uKpYifnB0xEYESgIi8iaIQ27xL5;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			/*Error: Unknown opcode: 0xBD*/;
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_ = ((IntPtr[])((uint[])/*Error near IL_0002: Stack underflow*/)[(double)/*Error near IL_0001: Stack underflow*/])[0];
			/*Error near IL_0004: Invalid branch target*/;
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static MessageBoxResult _206C_200E_200C_206F_202C_202D_200D_202E_202D_206C_202D_202E_206B_206D_200E_202A_200B_206F_202A_200B_206B_206D_200B_206F_206D_200C_202D_206A_202B_202E_200E_206F_202B_200D_200F_200E_206F_200E_206C_202C_202E(string P_0, string P_1, MessageBoxButton P_2, MessageBoxImage P_3, MessageBoxResult P_4)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6C
		}

		static string _200E_200D_202D_200B_202B_206D_200B_200B_202E_202D_206F_200C_200E_202C_206A_206D_202D_202D_206D_200F_200E_206D_200D_200D_200E_202A_200F_206E_206E_206E_200F_206D_202C_206E_206B_200E_206E_202E_206C_202E_202E(string P_0, object P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}

		static string _206F_202D_200C_202D_206C_202D_202E_200E_202D_206F_200D_200D_200D_200B_202A_200F_206C_200E_206B_202A_206F_200B_202A_202E_202D_200F_202B_206E_206F_202C_200B_206C_206F_200D_206E_206D_200E_206D_202A_202E_202E(string P_0)
		{
			switch ((int)/*Error near IL_001c: Stack underflow*/)
			{
			default:
				/*Error: End of method reached without returning.*/;
			case 0:
				/*Error: Invalid branch target*/;
			case 1:
				/*Error: Invalid branch target*/;
			case 2:
				/*Error: Invalid branch target*/;
			case 3:
				/*Error: Invalid branch target*/;
			case 4:
				/*Error: Invalid branch target*/;
			}
		}

		unsafe static Cursor _202A_202C_206A_206B_202A_206F_206F_200F_200C_200D_206A_200C_202B_206C_206B_200F_202E_206C_202A_202D_200F_206D_202B_200F_202D_202E_202C_200C_200E_206A_202C_200E_200B_202B_206A_206B_206B_200C_206C_206B_202E()
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0003: Stack underflow*/+ *unchecked((int*)(nint)/*Error near IL_0001: Stack underflow*/);
				/*Error near IL_0003: Invalid metadata token*/;
			}
		}

		static void _202A_202D_206C_200D_206B_206D_206C_200C_206D_206E_206B_202E_202B_202A_202C_206F_200E_200B_206E_206D_202D_206C_200D_202D_200F_206A_206B_206D_206B_202C_202D_200D_200C_202D_206D_206D_206A_206B_206E_206E_202E(Cursor P_0)
		{
			_ = checked((long)/*Error near IL_0001: Stack underflow*/) + 6;
			/*Error near IL_0003: Unknown opcode: 0xFD*/;
		}

		static StreamReader _206D_202C_202A_202A_206F_202E_206D_200F_202D_206E_200E_202C_206C_202E_200F_206A_200E_206C_200E_206E_206A_202C_200D_202C_200C_206D_200B_206E_202E_206B_200B_206E_206C_206F_206E_200F_202D_206F_206D_206F_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		static Task _202D_202E_206B_206C_206A_200D_206F_206C_206C_206B_200C_202E_202A_200F_206F_202C_202A_200E_202A_200B_202C_200E_206D_200E_206C_202B_206E_206B_200E_206B_206E_206B_206C_206F_202B_202B_200F_202B_206E_206C_202E(Action P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0xFD
		}

		static TaskAwaiter _200F_202A_200B_200D_206B_200B_200C_200F_200D_200F_200D_206A_206B_202E_200E_202B_206A_206F_200E_200C_206D_202E_200E_206D_206A_202B_200C_200C_200E_206F_206E_202B_202B_200F_206B_206E_200C_206A_206C_206E_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}

		static void _202C_200C_202D_202E_202D_202A_200C_200B_206C_206D_206C_202D_202A_202D_202E_202A_202A_200F_206F_206C_206A_200B_202A_206C_202A_202A_206C_206A_202B_200F_200F_206B_200C_206F_202C_206B_200F_202C_206E_202E_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static bool _200E_206C_202C_200C_200C_206E_206A_202B_202B_202A_206D_200F_202C_200D_202D_202B_202E_206B_202E_202D_202D_206D_202D_200D_206A_206D_202E_200B_206E_200E_202B_202C_200C_200C_206D_202D_202A_206E_200F_202A_202E(IEnumerator P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _0xoxKZBAFj4aYAeP39fcbbYtLP7 : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA4
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE5
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static OpenFileDialog _202D_200F_200F_202C_200E_202D_202A_206E_206A_206D_202D_206B_200C_200D_206B_206F_202A_206E_202B_200C_206F_206E_202D_202C_206A_206F_202E_206C_206A_200C_202E_206F_206B_200C_206F_202E_200C_206F_200B_200F_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x02
		}

		static void _206B_200E_200F_200B_200D_202E_206E_206F_202B_200B_206D_202B_200B_206D_206F_200E_206C_200F_202D_206A_206A_200F_200E_200C_202C_202C_206C_202B_200C_200E_206E_206F_206C_200B_200D_200B_200B_202A_206D_200F_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC3 0xEB
		}

		static void _200D_206F_206C_202C_206C_200E_202E_206F_202D_202A_200B_206B_206A_202D_206D_200C_206B_206A_206E_206C_206F_200C_206E_200D_200B_202A_200F_206A_202C_206E_200F_200D_202D_206A_202E_200C_200E_200F_202A_206C_202E(OpenFileDialog P_0, bool P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}

		static void _200D_206C_202A_202E_206B_202A_202A_206B_200F_206F_202A_200F_202A_206E_206F_200D_206B_206D_200E_200F_200B_200D_206A_206E_202A_206F_202E_200D_202B_206A_200E_206F_200C_200B_200D_202A_206B_202C_206E_206E_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0D
		}

		unsafe static bool? _200C_202A_202C_200F_202B_206D_200C_202C_202C_206A_202E_200C_202E_200F_200D_202C_200D_200C_206F_206F_202D_200F_206C_206A_200F_202D_202D_200E_200B_200D_206F_200E_206B_200E_202B_206C_200C_200F_202E_206A_202E(CommonDialog P_0)
		{
			//IL_0008: Expected native int or pointer, but got F4
			double num = ((double[])/*Error near IL_0002: Stack underflow*/)[(nint)((Array)/*Error near IL_0001: Stack underflow*/).LongLength];
			*(_003F*)null = /*Error near IL_0007: ldloc 1 (out-of-bounds)*/;
			_ = ((sbyte[])/*Error near IL_000a: Stack underflow*/)[num];
			/*Error near IL_000a: Unknown opcode: 0xA9*/;
		}

		static string[] _200E_206A_206A_206C_202A_206F_200B_202E_206B_200E_200B_200B_206B_200D_200B_206A_200E_202D_202C_202A_202D_200F_206C_202B_200E_202C_202E_202B_206A_200C_206A_202B_202B_206C_200F_206A_202B_200F_200E_202E_202E(FileDialog P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x41
		}

		static TaskAwaiter _200E_200E_202C_200C_206D_202C_206B_206A_200F_206A_200F_200E_202C_202A_200B_202C_206D_202D_206C_206D_200F_202D_206E_206A_200F_206B_200B_206F_202B_200D_202A_206A_206D_202E_200F_202D_202E_206A_206B_206B_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _4hpynXE8unVRDNxBlZix5ccBL2c : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public IEnumerable<string> _A09g2v92abaXoPFjVD2dbqfXerp;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private List<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> _xhWleN0k5fS92Qf6ZnKFacoCUVJ;

		private string[] _kS6x37UbCQaMzCWadfcp6RzDo6eb;

		private int _y1LNZDL1uzdBaYlEzWqHm2Tzwm6;

		private StreamReader _O1s0hQnawM1mqGCDcfMODddgLEU;

		private TaskAwaiter<string> _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x63 0xBB
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x29
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static StreamReader _202C_202E_206D_200D_202B_202B_202E_202A_206C_202B_202A_206A_206C_202A_202B_200C_206E_200D_206B_206B_206D_200F_206F_206E_202B_206C_206F_200B_202D_200B_200D_202B_202C_202D_206D_202B_200E_202D_200C_206E_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		static Task<string> _202D_200E_206B_200D_200E_206B_200C_202A_202B_206C_206B_202B_206F_202A_206E_206D_202B_200D_202E_206B_200C_202B_202E_202B_206E_206C_202B_206F_200F_200B_206C_206A_200F_206B_206B_206A_200D_206D_200D_202D_202E(TextReader P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}

		static void _200E_206B_202A_202C_206F_200C_200B_200B_200B_206F_206D_206C_206D_206B_202A_202D_206E_202C_202C_202A_200F_200C_200B_202D_206B_206A_206A_206A_200D_202C_206B_200D_200B_200D_206C_206B_202C_206D_200D_202E_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static bool _206F_200C_206B_206A_202D_200D_200D_206F_206B_206A_200F_202C_200F_206C_206A_206C_200C_206B_202D_202A_206E_206A_206A_206C_200E_206C_202B_200F_200D_200C_206A_206E_206E_206D_206C_200F_206B_206B_200E_202D_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _SmQBOyAnkmBabJJ7dQSgSz9pbqY : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public IEnumerable<string> _A09g2v92abaXoPFjVD2dbqfXerp;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private List<string> _0KJFm7oAMbDk7S0qwB1E8TSvAyT;

		private List<string> _veNURliH5P5Jo8fCoUiB44WRCvI;

		private IEnumerator<string> _y1LNZDL1uzdBaYlEzWqHm2Tzwm6;

		private string _50Xji51SaSjjEBEZ6nprXQji64b;

		private StreamReader _JFxKjzUBwN4TYfmcLmQJvcQTfacA;

		private TaskAwaiter<string> _teSyrDiveRJ3xlAJarvFgQdzSFo;

		private TaskAwaiter _yJd6bQCyGWnWbEnF9S98nza3ciC;

		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB8
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB3 0xAF
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static StreamReader _206D_202B_202D_206D_202D_200F_206A_202E_200B_200E_206D_202D_206E_202B_206D_200D_202D_200E_202E_206F_200F_202B_202C_206F_206F_206E_206F_200B_206C_202E_206C_202D_200C_200D_206E_206E_206A_200B_200B_202E_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		static Task<string> _206B_202A_200E_202C_206D_202C_202C_206C_202E_206A_202E_206F_202B_206D_200B_206A_206F_206E_200E_206B_200D_202C_200E_200C_202B_200B_202B_200B_202E_200E_206D_206E_202D_202A_206D_202E_206F_206A_202C_200E_202E(TextReader P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}

		static bool _202B_200C_202A_202D_206C_202A_200C_206A_206E_202E_202E_206F_200C_202C_202B_206F_206D_200B_202A_206E_202B_206E_202A_206B_200E_206B_206A_206A_206C_202A_200B_206B_206B_202A_206C_202B_206F_202D_200B_202A_202E(string P_0)
		{
			/*Error: Invalid field token*/;
		}

		static bool _202A_206B_206B_202E_200E_200F_206F_200B_202E_206C_200C_200C_206C_202D_202E_200C_206D_200B_200E_202A_200B_200D_202E_200B_202E_206D_202C_202E_202A_202A_202B_202A_200C_202D_202A_200B_206D_206A_202B_206C_202E(StreamReader P_0)
		{
			if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0002: Metadata token must be either a methoddef, memberref or methodspec*/;
		}

		static void _206C_200E_202D_202E_206F_206C_206E_206D_206E_202B_200B_202A_202E_202B_206A_202E_206B_200B_200E_200C_200E_206A_202D_202A_206C_206E_202E_202E_206D_206F_200E_202A_202D_202D_200E_206B_200D_206E_202D_206A_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static bool _200C_202E_202E_206F_202D_202C_206F_200F_200B_202A_202A_202C_206E_206D_202C_200F_200B_206C_200F_206C_206F_202B_202E_206F_202E_206E_206E_202B_206C_200F_200E_206E_200C_202D_202B_200D_206C_206E_206F_202C_202E(IEnumerator P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}

		static TaskAwaiter _206B_202C_202C_206A_202D_200C_202C_200E_206F_206B_200B_202B_206B_206B_206A_200C_206E_206A_206D_200F_200B_202B_206F_202B_202C_200E_200F_200F_206C_202C_202E_200B_206B_206C_200E_202B_202E_206E_200C_206E_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _ZT7V9J1URzOLjRokOGGCwi7ue4E : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter<string> _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x63 0xC8
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//IL_0003: Invalid comparison between Unknown and I4
			if ((int)/*Error near IL_0008: Stack underflow*/ >= (int)checked((byte)unchecked((nuint)(nint)((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(uint)/*Error near IL_0001: Stack underflow*/])))
			{
				/*Error: Invalid branch target*/;
			}
			throw /*Error near IL_0009: Stack underflow*/;
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static bool _202E_206E_206E_206C_202D_200F_202B_200E_200F_202E_206C_206D_206D_206A_200F_200D_202B_202E_200C_200D_206B_200B_202E_200E_202E_206D_202C_206A_206D_200B_206D_202A_202C_206D_206C_202B_202E_206A_202C_200D_202E(string P_0)
		{
			/*Error: Invalid field token*/;
		}

		static string _202E_206D_206E_200F_202B_206A_200E_202D_202D_202E_202A_200F_202E_206D_200D_200F_202E_202A_202B_200D_200B_202B_206C_206D_206B_202B_206F_206E_202B_206C_206E_202B_200F_206F_202E_206D_206C_202E_206A_206E_202E(string P_0, string P_1)
		{
			_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
			/*Error near IL_0002: Unknown opcode: 0xB1*/;
		}

		unsafe static Exception _206F_206A_206F_202B_202C_206E_206D_206F_206E_206B_206B_206D_206E_202C_200B_200C_200B_206A_206C_202B_206B_200E_202D_202A_200C_200B_200D_200F_206B_206F_206C_202C_200D_202C_200E_202E_202E_206A_202E_202E_202E(string P_0)
		{
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			checked
			{
				_ = (byte)/*Error near IL_0002: Stack underflow*/;
				/*Error near IL_0002: ldloc 57 (out-of-bounds)*/;
				/*Error near IL_0004: Unknown opcode: 0xC5*/;
			}
		}

		static Exception _200E_206F_202E_202B_206A_202D_200B_202A_200E_202A_206A_206F_200D_206F_206A_202E_206B_200B_206E_200B_202C_202D_200D_206B_206C_206A_200B_206C_206D_202B_200D_202E_200E_206B_200D_202C_200E_206D_206A_206D_202E(Exception P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}

		static string _200C_200B_200E_200C_206B_206A_206A_206A_206A_206E_206C_206D_206F_206B_200E_206E_202A_206F_200C_206F_206E_202D_200D_206C_206B_200F_200F_202E_202C_202E_206E_206E_206C_206F_200B_206A_200D_206A_200B_200F_202E(Exception P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}

		static string _206A_206F_206D_206E_206D_206E_206F_202E_202B_206B_206A_200C_206E_200B_202E_200C_202C_200E_202E_202B_200D_206A_200B_200E_206F_206C_202E_206A_200C_206E_202E_200C_206B_206B_206C_206B_200E_206A_206C_206A_202E(string P_0, object P_1, object P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x61
		}

		static string _206B_202C_202A_206D_202E_200E_200C_200E_202B_200C_200D_200B_200F_202D_202C_200F_200E_200D_200C_200C_202E_206B_202C_206B_202A_202A_200B_202D_202C_206A_206E_202B_202D_200D_206D_202B_206C_206B_200C_206D_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7C
		}

		static string _200D_200D_206A_200C_206A_206D_206C_200E_200C_202C_200F_202C_200B_206F_202B_206B_206E_200D_202E_206F_200C_200C_206E_200B_206B_200D_202C_200B_206D_202E_200F_202B_206D_206C_206B_200F_200B_202B_206D_202E_202E(string P_0, string P_1, string P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD9
		}

		unsafe static DirectoryInfo _206D_206D_206E_202B_200B_206A_206A_206F_200C_206F_200B_200C_202E_206E_206B_200C_200E_206D_200E_202E_206B_202C_202C_206A_200D_206E_200E_200F_200D_200D_206F_200E_206B_206A_202D_200B_202A_206D_206D_200D_202E(string P_0)
		{
			_ = *(byte*)checked((int)uint.MaxValue);
			/*Error near IL_0003: Unknown opcode: 0xEF*/;
		}

		static string _202B_200B_206B_206E_200C_206E_200E_206D_200E_200B_206E_200B_206B_202C_206B_206C_206A_200C_202A_200D_202E_206E_202D_202B_200C_200E_206D_206F_200F_206E_206C_206D_202E_206F_202A_206B_206A_206F_200D_202B_202E(FileSystemInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCD
		}

		unsafe static SeriesCollection _202B_202D_200B_206F_206E_200D_206D_206C_206A_202D_200F_200F_206D_202E_206D_206E_200D_206E_206C_202C_202D_200D_200C_202C_202D_206D_206A_206C_202D_206C_206B_202D_206B_202E_206A_206C_206C_202B_200D_202A_202E()
		{
			//IL_0001: Invalid comparison between Unknown and I
			if ((nint)/*Error near IL_0006: Stack underflow*/ > (nint)/*Error near IL_0001: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			_ = ((int[])/*Error near IL_0009: Stack underflow*/)[(nint)(*(IntPtr*)(nint)/*Error near IL_0006: ldloc 0 (out-of-bounds)*/)];
			_ = -57756177668.81563;
			_ = 4;
			/*Error near IL_0013: Unknown opcode: 0xBE*/;
		}

		unsafe static LineSeries _200C_200F_200C_206C_202D_206E_200C_202B_200D_200C_206B_206B_200F_200D_202E_202A_200F_202E_200E_200B_206D_206F_202E_202E_202C_206F_202C_200F_202E_202E_200E_206B_200B_206F_206D_206F_206C_202E_206D_206D_202E()
		{
			if ((int)/*Error: ldarg 2 (out-of-bounds)*/ != 0)
			{
				/*Error: Invalid branch target*/;
			}
			*(_003F*)(nint)/*Error near IL_0004: Stack underflow*/ = /*Error near IL_0004: Stack underflow*/;
			checked
			{
				throw (nuint)unchecked((uint)checked((sbyte)/*Error near IL_0005: Stack underflow*/));
			}
		}

		static ObservableValue _202B_200B_206C_206C_200C_200B_200E_206D_200F_206D_202E_206D_200B_200B_206D_202A_206A_200C_206F_200F_206E_200E_206A_200C_202E_200E_206F_202E_206B_206F_202E_206C_200D_202A_200F_206C_202A_206C_206E_202E(double P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}

		static void _206D_200C_206E_200E_206A_206F_200F_206D_206C_206B_202A_202D_202D_200D_200F_200B_200F_202B_206B_206A_200E_206D_200D_206C_202B_206E_200D_200C_200B_206E_202C_200D_200F_206C_206E_206C_206B_202C_200C_206A_202E(Series P_0, IChartValues P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xC6
		}

		static Thread _206E_206B_202B_200F_202D_202D_200E_206C_202D_200F_206E_202A_206B_200B_200C_200D_200C_206C_206D_202C_206D_200F_200D_206F_200F_206E_202E_202E_202B_206E_206F_206E_206B_200B_206D_206F_200B_202A_206B_200F_202E(ThreadStart P_0)
		{
			/*Error: Invalid metadata token*/;
		}

		static void _202C_206F_202B_206E_202D_206C_200B_202B_206D_202B_206A_200C_206D_202E_206D_202A_206E_202A_202E_206D_206E_206D_200F_206F_200D_202A_206A_202A_202A_206A_202C_206B_202B_206C_206B_206B_200F_202E_202A_202B_202E(Thread P_0, bool P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE1
		}

		static string _206F_206F_200F_206D_200F_202E_200B_206A_202B_200E_200F_206C_206D_202B_206C_206B_200D_206E_202B_206E_206B_202B_206A_200C_206E_206D_206B_202D_206E_206A_206F_202C_200B_202A_206B_200B_200F_202E_200F_202B_202E(string P_0, object P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}

		static void _206E_202C_202B_206D_202B_202E_200E_206B_200E_206B_206D_206A_202D_202A_202E_202C_206C_206B_202D_202C_200F_200F_200E_200E_206E_200E_202A_202C_206B_206F_200C_200B_206F_202C_200E_202E_206F_206C_202A_202D_202E(Thread P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB8
		}

		static CultureInfo _200D_206B_200D_206E_206C_206D_200F_206D_202C_206C_200F_202C_200D_206B_202A_206E_206E_200C_200C_200D_206D_200C_206A_206C_202E_206A_200D_206A_200E_202E_200F_200E_206E_200E_200C_202E_200F_206F_202B_202D_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x58
		}

		static void _200B_200D_200B_206E_202A_200D_206C_206E_200E_206F_200B_206A_206F_206D_202B_206C_206C_200D_206C_202E_206F_206F_206E_202A_206C_202E_202D_206E_200C_200C_206D_200D_202E_202C_202E_200F_206C_200B_206D_202D_202E(Thread P_0, CultureInfo P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}

		static void _206F_206A_206A_202B_200F_202A_206F_206F_206C_206B_202B_200B_200F_200E_200E_206F_206B_202C_202D_200C_206B_202B_206B_206F_200C_200D_202E_206C_200E_202E_206E_200F_202A_202E_200F_206E_206E_200D_206B_206E_202E(Thread P_0, CultureInfo P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x64
		}

		unsafe static void _200F_200C_206A_200B_202C_200B_206D_206E_206F_200B_202C_202E_200D_202A_202D_200F_206E_202E_200C_206D_200C_202A_200C_206D_202A_206A_202E_206C_206B_200F_202A_206D_200E_206D_200F_200B_202B_206D_202E_206C_202E(Thread P_0, ThreadPriority P_1)
		{
			//IL_0003: Expected F8, but got I
			*(double*)(nint)/*Error near IL_0003: Stack underflow*/ = *(nint*)((Array)/*Error near IL_0001: Stack underflow*/).LongLength;
			/*Error near IL_0003: Invalid metadata token*/;
		}

		static void _200C_206E_202C_202B_200F_206F_200B_200C_206A_206B_206C_200D_206E_206F_202D_206E_200C_206A_202E_202A_206B_202A_200D_202E_202C_202E_200D_206F_200F_206C_206D_206B_206F_206A_206B_200D_202C_206C_206F_202A_202E(Thread P_0)
		{
			/*Error: Unknown opcode: 0xBC*/;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _xZQtYiAC0vYektaaizNvMY3aOgV : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _PVcE902tANLMP9CA1Ox2g1GsOqO<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x08
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static TaskAwaiter _206A_200D_206F_202E_200D_200C_200E_202D_206A_202E_202D_200C_206A_206E_200B_200C_200F_206C_200C_202B_200F_202E_200E_206C_206D_206F_202E_200E_202C_200E_200C_206D_206E_200E_206B_200E_206E_202C_200F_200E_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}

		static string _200F_202C_206C_202E_200B_206A_200E_202E_202E_200E_206A_200D_202D_200E_206B_200B_200F_202A_202D_202C_202D_200D_206D_206D_202B_200D_206B_200B_206A_206B_202B_206B_200F_202A_206D_200F_200D_202A_206C_202A_202E(Exception P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}

		static string _206C_206A_206B_206A_206F_200B_200E_200F_206A_202E_206C_202D_206A_206F_206D_206F_200C_202E_200B_200F_206D_206C_202E_206C_206D_206F_202B_200D_206F_200D_200C_206E_206F_206D_206C_200E_202C_200E_200E_200F_202E(string P_0, string P_1)
		{
			_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
			/*Error near IL_0002: Unknown opcode: 0xB1*/;
		}

		static MessageBoxResult _206F_200B_200E_206E_206D_200B_206C_202A_200B_206E_206B_200B_206F_206C_200C_206A_202C_200D_202E_200E_202B_202D_200D_206F_206A_200D_206C_206B_200B_206C_200F_206B_206D_200E_202A_206B_206B_206B_202D_202C_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0xAEEA4611
		}

		static Task _206D_202D_202C_200B_206E_202E_200B_206A_200D_206B_202B_202D_200C_202A_206C_206F_200D_200E_202D_206F_200C_202A_206E_200F_202D_202A_202C_200C_206C_206F_200C_200F_202C_202B_200F_202D_200E_202E_202D_206C_202E(Action P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0xFD
		}
	}

	private _3VEcGB4twz7bdUPRpfl7PnyfkobA _HEQaaJ4o34yuupItMK3sTCAZwfe;

	private string _eO4Jw4cDvL7Ojr7btewmZSTYnuN;

	private string _B8JNuxTWuc1lvD2sUMiL51AeGof;

	private bool _3VRvZFXDwI9k7f8FQEWtVBHUMpu;

	private System.Timers.Timer _4cs14RPqsRBH42BRm6aKJbWEKkd;

	private System.Timers.Timer _qRBb2tQfY1Vfcgre2Ew5MyLtphm;

	private readonly object _NWyKcVgjijMkMwp6RylPxCd0FMr;

	private readonly object _SusbMJKFTYoDRXVSVjC1mdIltYv;

	private ushort _SmKb3Q3jLgMutjL2TIKedGiC48D;

	private DateTime _RWb5iAaU3rZCoBWXGJSUvTTImoE;

	private List<Thread> _k07DNkLab5w7pYS7MfRvFRUewkAA;

	private int _pqSwdjJf9WjGqImAYgDde743c6J;

	[CompilerGenerated]
	private string _ipEcbLPaz4bmHRLfBnemoSPrdLd;

	[CompilerGenerated]
	private ConcurrentQueue<_0001> _iZqum5sb0b6LRwbwAFkSLgqgjvq;

	[CompilerGenerated]
	private _6kowxIyI5s2v3oeCKgG6VfVftqH _CtjH3bQYqdVdDAf2LI4HSw0CkDx;

	[CompilerGenerated]
	private ProxyType _BqjDIPAFPpq0jFiqviAuG0FP6Jw;

	[CompilerGenerated]
	private string _Yr2HnTBQ3gxL61ukeAFQSpFbWWg;

	[CompilerGenerated]
	private int _VzBf7Q6iXM5TbCPODdpIGT7S8aj;

	[CompilerGenerated]
	private string _2TuoPs9xWJGhQGu7ySkGRXhCi9b;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _UG75uz4tbNPLs4tw7F3s76BFVcm;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _vYzXLN1lHzABw3YsoSsTeB7gJ1s;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _qRFHbiG19mKwx63AyDefbDnSGbN;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _svbBDDumOIieFFCdYownaxnF89A;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _sg72IS7hAJNzAzhfETNWfCR8LPK;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _Fnbkqe7ISDFAEwFnWQO2HmJclHk;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _0pEX6aQnQZQMrYZpXbKlbbqWaSc;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _RmAwHxskhlDtbh4FWALW1qYPzqi;

	[CompilerGenerated]
	private int _v8nBPZEry3otPGusSEKnjwOYw6f;

	[CompilerGenerated]
	private int _QNOT6BU1EWviJU6FKAmhjE1MQvF;

	[CompilerGenerated]
	private TimeSpan _xPgmvu3IHqlLrNUOsIOyxQcYCKB;

	[CompilerGenerated]
	private TimeSpan _po6dPgRdj8RvF0LLsDqXwDjOsxe;

	[CompilerGenerated]
	private SeriesCollection _ACBAEOuJTudbgYqhSOMEPW4CIju;

	[CompilerGenerated]
	private _Wre1fZEd28y1dOTLmEZt1RQxd3I _S9UdJP8hUMTDuaQPJzyzYF7qgcE;

	public string Title
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC0
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEB 0x06
		}
	}

	public ConcurrentQueue<_0001> Sources
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x07 0xC9
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x29
		}
	}

	public _6kowxIyI5s2v3oeCKgG6VfVftqH Proxies
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x35
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x20
		}
	}

	public ProxyType ProxyType
	{
		[CompilerGenerated]
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0001: Stack underflow*/* /*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xBB*/;
			}
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}
	}

	public string ProxyAddress
	{
		[CompilerGenerated]
		get
		{
			//IL_0000: Unsupported input type for neg.
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = 0 - /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xA8*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x00
		}
	}

	public int AccsPerLink
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA0
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}
	}

	public virtual ushort ThreadsCount
	{
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = (ushort)(/*Error near IL_0001: Stack underflow*/ | /*Error near IL_0001: Stack underflow*/);
				/*Error near IL_0003: Unknown opcode: 0xBD*/;
			}
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE4
		}
	}

	public string StartStopContent
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x65
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			checked
			{
				_ = (ushort)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xEB*/;
			}
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk CurrentThreads
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE9
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4C
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Errors
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x839A0DA3
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Checked
	{
		[CompilerGenerated]
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = /*Error near IL_0001: Stack underflow*/& /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xCF*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk NotEmpty
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7D
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			/*Error: Invalid metadata token*/;
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Correct
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDC
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBF 0x14
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Banned
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFB 0xC6
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0F 0x49
		}
	}

	public unsafe _G15v8HWgo02bl3FVfr7aE6PyhXk Incorrect
	{
		[CompilerGenerated]
		get
		{
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			/*Error: End of method reached without returning.*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x13 0x2C
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Remaining
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFF 0xE3
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			((double[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (double)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Invalid branch target*/;
		}
	}

	public int AccsPerMin
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x45
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			/*Error: stloc 2 (out-of-bounds)*/;
			_ = 0;
			/*Error near IL_0003: Unknown opcode: 0xE8*/;
		}
	}

	public int Progress
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xEC*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x06
		}
	}

	public TimeSpan TimeFromStart
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x51
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9B 0xC6
		}
	}

	public TimeSpan TimeToEnd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x83 0x7D
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			((int[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (int)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xA7*/;
		}
	}

	public unsafe SeriesCollection Series
	{
		[CompilerGenerated]
		get
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			System.Runtime.CompilerServices.Unsafe.Write((void*)(nint)/*Error near IL_0001: Stack underflow*/, /*Error near IL_0001: Stack underflow*/);
			if (/*Error near IL_0007: Stack underflow*/ != /*Error near IL_0001: ldloc 1 (out-of-bounds)*/)
			{
				/*Error: Invalid branch target*/;
			}
			checked
			{
				if (/*Error near IL_000b: Stack underflow*/ >= /*Error near IL_0009: Stack underflow*/* unchecked(/*Error near IL_0008: Stack underflow*/ % /*Error near IL_0008: Stack underflow*/))
				{
					/*Error: Invalid branch target*/;
				}
				/*Error near IL_000b: Unknown opcode: 0xF1*/;
			}
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3F 0x78
		}
	}

	public _Wre1fZEd28y1dOTLmEZt1RQxd3I LoadAccountsCommand
	{
		get
		{
			/*Error: Unknown opcode: 0xF8*/;
		}
	}

	public _Wre1fZEd28y1dOTLmEZt1RQxd3I LoadProxiesCommand
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0xF7
		}
	}

	public _zDKxFKYm2SsAwcwMm1S8kCb29wN OpenDirectoryCommand
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x91
		}
	}

	public _Wre1fZEd28y1dOTLmEZt1RQxd3I StartStopCommand
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x31
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			if (/*Error near IL_0004: Stack underflow*/ != (/*Error near IL_0002: Stack underflow*/ & (nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]))
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0004: Unknown opcode: 0xC0*/;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected _PVcE902tANLMP9CA1Ox2g1GsOqO()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF3 0x84
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._ApIe0nA3diEJTWBUjOSbxgEth9A))]
	public Task _7YMd6sGY8xcQhqYq34A5ycSX2vD()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x68
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._0xoxKZBAFj4aYAeP39fcbbYtLP7))]
	public Task _1mw8caB5G5JkbOtST9waMaBaI3h()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2B 0x98
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._SmQBOyAnkmBabJJ7dQSgSz9pbqY))]
	public Task _haqzCzvi8WwewoUVagTTFJyVlJr(IEnumerable<string> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x17 0xCE
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected virtual void _v2BFP4p6Nz9FkTGr5IxcahGDbYZ()
	{
		/*Error: Unknown opcode: 0xBB*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected virtual void _saQIzBCdpg58qbjJ1JoEbNJvZYy()
	{
		/*Error: ldloca 163 (out-of-bounds)*/;
		/*Error near IL_0002: Invalid branch target*/;
	}

	protected virtual bool _Ymi5g6dAcGEZVTxT8wmmJPnevmF()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x18
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._sIh4Y0aUHolWqubwbpGzbo9W17h))]
	private Task _lZIXMsovtPQmhBP4cERmY8sR1GC(IEnumerable<string> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6F 0xEC
	}

	protected virtual void _zWBx3e1vRuyavm2fxYIpD18AYmK()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._4hpynXE8unVRDNxBlZix5ccBL2c))]
	private Task _IpvZIXRByUfS5RM0LCCEMTNikNz(IEnumerable<string> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA8
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._xZQtYiAC0vYektaaizNvMY3aOgV))]
	private Task _JMXUxQ5x2rCwoamVQEtOPhQj49e()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (IntPtr)/*Error near IL_0001: Stack underflow*/;
		_ = /*Error near IL_0002: Stack underflow*/% /*Error near IL_0002: Stack underflow*/;
		return (Task)/*OpCode not supported: Nop*/;
	}

	[AsyncStateMachine(typeof(_PVcE902tANLMP9CA1Ox2g1GsOqO<>._ZT7V9J1URzOLjRokOGGCwi7ue4E))]
	private Task _dSYAGq4PdudeOVyniXIfCgdr4Zz()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x05
	}

	private unsafe void _0c6lnBqjNcMQU4jsWZwDLEVrN6f()
	{
		_ = *(ushort*)(int)((uint[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
		/*Error near IL_0002: Invalid branch target*/;
	}

	private void _GD9dVF9BqPmMN6PiDZbtFioArqX()
	{
		((object[])/*Error near IL_0003: Stack underflow*/)[/*Error near IL_0003: Stack underflow*/] = (object)/*Error: ldarg 225 (out-of-bounds)*/;
		/*Error near IL_0003: Unknown opcode: 0xB1*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private void _1ULrp1TB5tEcGba3Gz4TsLTJwKW()
	{
		/*Error: Unknown opcode: 0xCE*/;
	}

	protected virtual void _xJT7CzY1KQvLwS3CVabfA8peREn()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	protected abstract void _GY3QokqGHn1ZtkFEvdoWdGi9wAC(_0001 P_0, _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_1 = null);

	protected virtual void _LoJ5r6QOsYP5hpS9OGQiRaGcRZd()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	protected void _CwpKbc9czEJmT1u0VgxuruHPSkH(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	protected void _CwpKbc9czEJmT1u0VgxuruHPSkH(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x69
	}

	[CompilerGenerated]
	private void _4modINrsOuwNq8aD0ggGIYhwIFP(object P_0, ExitEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x90
	}

	[CompilerGenerated]
	private bool _yiGlbMZeibfy6Lm0HHFfgUZlnVw()
	{
		/*Error: Unknown opcode: 0xFD*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[CompilerGenerated]
	private void _4YyfkpaxSI64BdsA4SPJDnW6MRe(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xB4
	}

	[CompilerGenerated]
	private bool _Y571TxrdzcsfSGDpBW3gM624kkh()
	{
		/*Error: Unknown opcode: 0xFD*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[CompilerGenerated]
	private void _g9zNj9VutO9Z1jQ5KquCHTAK98D(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0x51
	}

	[CompilerGenerated]
	private void _KyCZfaev8Gu5SESOB9xF8lkOuuG()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		_ = ((float[])/*Error near IL_0003: Stack underflow*/)[~/*Error: ldloc 1 (out-of-bounds)*/];
		/*Error near IL_0004: ldloc 1 (out-of-bounds)*/;
		/*Error near IL_0005: Unknown opcode: 0xE3*/;
	}

	[CompilerGenerated]
	private void _gLrAPspsRy2WLZ5Oz67aTcvdRdK()
	{
		/*Error: Unknown opcode: 0xAB*/;
	}

	[CompilerGenerated]
	private string _vtD5D5nv2nqFxJDxlUFRcn3PaKd()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBC
	}

	[CompilerGenerated]
	private bool _Qa3IjFbSI7bBb3p5rvJ56ZXJfPA()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		checked
		{
			_ = /*Error near IL_0001: Stack underflow*/- /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xCA*/;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[CompilerGenerated]
	private void _veO1zPTakqx1JGnMckDjQvvJesL(object P_0, ElapsedEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA9
	}

	[CompilerGenerated]
	private void _gIDfBgjHousA3Y84ROlCkOb5k9PA(object P_0, ElapsedEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x18
	}

	static object _200E_200D_202E_200D_200F_206F_202C_202C_200C_200F_202B_206D_202B_202B_202D_202C_202B_206B_206B_202B_202B_202D_206A_206D_202A_206A_206B_200B_206B_202C_202D_200D_200B_200C_206D_202B_202B_200B_206A_206A_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	unsafe static SeriesCollection _206D_202E_202E_202B_202B_200F_200E_200E_200F_206D_206A_200C_200F_200C_200D_202E_202E_202B_202C_202C_202A_206B_206F_202D_206A_202D_206F_206A_206A_206E_206B_200C_206A_202C_206A_202C_206B_202D_206D_202B_202E()
	{
		//IL_0001: Invalid comparison between Unknown and I
		if ((nint)/*Error near IL_0006: Stack underflow*/ > (nint)/*Error near IL_0001: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = ((int[])/*Error near IL_0009: Stack underflow*/)[(nint)(*(IntPtr*)(nint)/*Error near IL_0006: ldloc 0 (out-of-bounds)*/)];
		_ = -57756177668.81563;
		_ = 4;
		/*Error near IL_0013: Unknown opcode: 0xBE*/;
	}

	unsafe static LineSeries _200C_206D_200C_202B_206A_202C_206C_202C_200E_206D_200B_206E_202E_202B_202A_202E_200E_206B_206B_200F_206E_206A_206C_206A_206E_206B_200E_200B_206A_206F_206C_206F_206D_202C_200E_202B_202D_200D_200D_206D_202E()
	{
		if ((int)/*Error: ldarg 2 (out-of-bounds)*/ != 0)
		{
			/*Error: Invalid branch target*/;
		}
		*(_003F*)(nint)/*Error near IL_0004: Stack underflow*/ = /*Error near IL_0004: Stack underflow*/;
		checked
		{
			throw (nuint)unchecked((uint)checked((sbyte)/*Error near IL_0005: Stack underflow*/));
		}
	}

	static ObservableValue _206D_200E_206D_206F_200F_206B_202C_202A_206A_206C_202C_202E_206A_206F_202E_202B_200C_202D_206B_206B_200E_202A_206F_206C_206E_206C_206F_202E_202E_206C_202E_200F_200D_206A_206B_200F_200F_200C_200C_206B_202E(double P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x04
	}

	static void _200D_206F_206B_206F_206E_206B_200D_200D_202A_202C_200F_202C_200D_206D_206C_202E_206E_202C_202E_202E_206E_202C_200D_206B_200E_202A_202B_206D_200B_202D_200C_200F_202B_206A_200C_202B_202A_206A_200D_202E_202E(Series P_0, IChartValues P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xC6
	}

	static Assembly _200D_200E_206A_206D_206F_202C_202A_200B_200D_206F_202C_200B_206F_206D_206E_200D_202A_202B_200B_202C_200E_200D_202E_206B_206C_202E_202C_206B_200B_206B_200C_200F_206B_202B_200E_206C_202C_202C_206D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	static AssemblyName _206A_200B_200E_200C_206E_200B_206E_206B_202C_202C_206E_200F_206D_200F_200F_202B_200C_202A_206F_206B_202A_206A_202B_200E_200B_202E_202A_206C_200D_200C_200B_206C_206A_206A_206F_200F_206E_200D_206F_206C_202E(Assembly P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	unsafe static string _202C_200E_206C_202C_206C_206F_206E_202C_202D_202A_206A_200B_200D_206E_202C_202D_200C_206D_202A_202D_206B_200E_206D_202C_200C_206B_200E_206F_200F_206E_200E_206E_206D_202D_206A_200F_200D_206E_202C_202E_202E(AssemblyName P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/];
		/*Error near IL_0003: Unknown opcode: 0xEE*/;
	}

	static string _202A_200D_206E_200D_206C_206F_200B_206B_202E_206A_206B_200C_202C_200B_206D_200E_206B_202B_206D_206B_206D_206D_206C_200E_202B_202D_202A_200C_202C_206D_202E_200C_202A_200C_206D_202E_200C_202A_202E_206D_202E(string P_0, string P_1)
	{
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
		/*Error near IL_0002: Unknown opcode: 0xB1*/;
	}

	static Application _202E_200D_206F_206D_202A_200B_200E_200F_206E_200C_206C_202B_206E_200D_202D_202C_200B_202C_200E_202E_206A_202E_200D_200F_206A_200E_200E_200E_206A_200B_200E_200F_202A_200C_202B_200B_202A_206A_200D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}

	static void _202B_202B_202E_206D_200D_200B_206F_206F_200B_202B_200E_200D_200B_202E_202E_206F_200C_206D_202A_202E_206E_200C_200C_206F_202B_202B_200B_200E_206F_206C_200B_200B_202E_202D_200F_200C_202E_202E_202E(Application P_0, ExitEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}

	static bool _206A_200C_200E_200C_206E_202D_200D_202A_202D_200C_206A_202C_200E_206A_206E_200B_200F_200B_206B_200D_200C_200B_200C_202D_206B_206A_206A_206A_202D_200D_200D_200D_200D_202D_202A_206F_206B_200F_206F_202B_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	static bool _200F_202C_202B_200E_206A_206E_202D_202D_206B_200C_202A_202A_200D_200E_202B_206A_202A_202C_202A_206B_206D_200C_206F_206C_206F_202E_202C_206A_200C_202D_206E_200E_206D_202B_202B_206C_200D_200E_200D_200E_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	static object _200C_200E_200C_200F_202C_200B_202E_202A_206D_202E_206E_206D_206C_206A_202C_202D_202C_202E_206F_206A_206E_202A_202A_202E_200E_202C_206B_206F_200F_200C_206C_200D_200F_200E_200D_200E_200D_202A_206E_206A_202E(string P_0, string P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x15
	}

	static string _206A_200B_200B_206B_206C_206C_202D_202A_202B_200E_202D_206E_200F_206B_200D_202A_202B_200F_202E_202A_206D_206B_206C_206D_206F_200E_200E_202E_206E_200C_206C_202B_206F_202B_202A_206B_206D_202A_202B_202C_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static void _206D_200E_202A_206C_206F_202C_200B_206E_200F_200D_200E_200B_200C_202E_200D_202A_202D_202D_200C_202A_206B_206F_206F_200D_206D_200E_200D_200D_200F_200D_206A_206D_202A_206F_202C_206B_202A_202A_202A_206A_202E(string P_0, string P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3D
	}

	static bool _206A_202A_206F_200F_202E_202A_200E_206C_206A_202D_206C_202D_200E_202D_202D_200D_206C_206D_200F_200B_206B_202B_202D_200B_202E_206E_200F_206A_206D_200F_206D_200E_200E_206B_202B_206A_202A_202E_200C_200C_202E(string P_0)
	{
		/*Error: Invalid field token*/;
	}

	static System.Timers.Timer _200F_202B_202A_206B_206B_200B_206B_200C_200D_202E_200B_206F_202E_202C_206E_202C_202B_200C_200F_206E_202E_202B_202D_202E_202D_200D_200C_206F_206F_206D_200E_202D_202D_206F_206D_202B_206C_202B_202D_200D_202E(double P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEF 0x4C
	}

	static void _200D_200B_206A_200E_202B_206E_202D_206E_202D_206C_200C_200E_200F_200B_206A_202D_206F_206F_202C_206D_202A_202D_206A_200E_202C_200F_206E_200D_202E_200C_206C_200D_202B_206C_200C_200E_202A_206A_202A_206B_202E(System.Timers.Timer P_0, ElapsedEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	static void _206F_200C_200D_206F_202D_200D_200C_206A_200C_202B_206E_200D_206E_202B_200C_206D_200E_206A_200C_206C_200D_200E_200B_206C_200E_206D_202A_202B_200B_206B_202A_202D_202A_200E_206B_206A_200D_200F_200D_202E_202E(System.Timers.Timer P_0)
	{
		/*Error: ldarg 156 (out-of-bounds)*/;
		/*Error near IL_0002: Unknown opcode: 0xCC*/;
	}

	static void _202E_200C_206B_206E_206F_200D_200C_200D_206A_202E_202A_202D_200F_206D_202E_206A_200D_206D_200C_206F_206B_206D_206A_202A_206E_206B_206D_200C_202B_200F_200B_200D_202D_200F_200D_202C_202E_202C_206C_206B_202E(object P_0, ref bool P_1)
	{
		/*Error: Unknown opcode: 0xE1*/;
	}

	static void _206D_206C_202E_200D_206B_202E_206B_206B_200F_200B_202C_206F_200E_202E_206F_206A_202D_202C_200E_206F_202B_200E_206F_206C_206C_200D_206D_200C_202E_202D_202B_202A_200E_206B_202B_202A_200D_200D_202C_202E_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x01
	}

	static void _200B_202E_200C_202E_206A_202A_206F_200E_206A_202E_206B_202C_206A_200C_200D_202E_206C_202A_202D_206D_206E_200E_202A_206F_202B_206B_200F_206F_202A_200F_200C_200E_202D_200E_206A_202A_200E_206B_206C_202E(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x54
	}

	static string _202B_206E_202B_206C_206B_202E_202E_206D_206B_206D_200D_202A_202D_206F_200B_206E_206B_200F_202D_206C_206F_202E_206E_206A_200C_206D_206C_200E_200B_202C_202A_202D_202D_202B_206C_200B_200B_206A_200F_206F_202E()
	{
		/*Error: Unknown opcode: 0xCF*/;
	}

	static string _200E_202B_206F_200B_206A_206D_202A_202A_206B_200E_202E_200F_200D_206D_206D_206C_200E_202A_202B_206B_202B_206E_202A_200D_206C_202E_200E_200B_206E_206F_206B_202E_206D_200C_206C_206B_206C_206F_200F_200D_202E(string P_0, string P_1, string P_2, string P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static void _206F_206E_206B_202D_200E_202D_202C_200C_200D_202A_202D_200E_200E_206A_206F_200B_206D_202C_206F_206E_206C_200F_202C_202E_202E_206A_202C_202A_206A_206D_200D_200F_202A_206B_200B_202B_202E_206E_206D_200E_202E(System.Timers.Timer P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	static void _202E_206E_200B_200F_200D_202D_206F_206D_206F_200B_206E_206A_206D_206B_202D_202E_202B_202B_206E_200B_200E_206C_202C_202E_200D_200F_202B_202A_200C_200D_200C_206A_206A_200F_206E_202E_206F_200E_206E_200C_202E(System.Timers.Timer P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB7 0x80
	}

	static string _202B_206B_202C_202A_206A_206C_206D_202B_202D_200B_206D_206D_206C_200B_200D_202B_202E_200C_206E_200D_200F_202B_200F_200F_200B_206A_206F_206A_200E_200B_202E_206B_200C_206B_200B_206A_206E_202D_206D_202C_202E(string P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x34
	}

	static MessageBoxResult _200B_206D_202A_202D_200F_206C_206D_206E_202C_200C_206E_200C_200E_200E_202B_206B_206C_202E_206E_200E_202B_202C_200F_202C_202B_200B_200E_200D_200E_200B_200E_200E_206E_206D_202A_206E_200F_200F_206A_206D_202E(string P_0, string P_1, MessageBoxButton P_2, MessageBoxImage P_3, MessageBoxResult P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6C
	}

	static Process _200C_200D_206E_200E_206B_202C_202E_202D_200D_200B_206D_206A_206B_206E_206C_206E_206B_206D_200F_200C_202A_202A_200B_200B_202E_200E_200E_200E_200F_200F_206D_200D_200B_202C_200E_202D_206E_206E_202B_206B_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xF1*/;
	}

	static string _200E_202A_200B_200F_206A_200F_202B_202E_206C_200D_206D_206C_200D_206A_202E_202E_200F_202D_206A_206E_206A_202A_206D_206A_202D_206F_200F_206D_206A_202C_206F_200B_206D_206B_200C_206B_200C_202A_200E_206A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x97D39D2C
	}

	static StreamWriter _202D_202B_202D_206E_200D_200C_200E_206D_200B_202A_200B_200C_200F_202C_200F_200C_200B_206A_206A_200F_206C_200E_206B_202C_202A_202C_202D_206A_206E_206F_206F_206C_200C_206D_206F_206C_200E_200C_206A_200F_202E(string P_0, bool P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x75
	}

	static void _202C_202A_202D_206B_200E_206E_200F_206D_206A_202E_202A_200B_206A_206A_206B_200E_200D_200D_202B_206C_200E_206E_206C_202E_206A_202B_202C_200E_206B_200E_206F_200F_206E_202E_200E_202D_200F_200D_202C_202E(TextWriter P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x70
	}

	static void _200C_202C_200B_206D_206D_200F_202A_200D_202E_202E_202C_202D_202A_202B_206C_202B_200E_202C_206C_206E_200C_202D_200F_206B_200D_206E_206A_206B_202E_206D_200D_200E_202A_206C_202E_206A_200C_200B_206E_200C_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	unsafe static DirectoryInfo _202E_200E_200D_200C_200F_202D_206F_206D_200E_206A_202D_202E_202C_206A_206D_202C_206B_200C_200C_200F_206E_206C_202D_206D_202A_202C_200F_206E_206B_206C_200D_206E_206A_200B_200F_206D_200B_206C_200B_206F_202E(string P_0)
	{
		_ = *(byte*)checked((int)uint.MaxValue);
		/*Error near IL_0003: Unknown opcode: 0xEF*/;
	}

	static string _206D_206A_202D_202E_202A_206E_202B_202E_206B_200E_206D_200B_202C_200B_202A_200C_200C_200E_206A_200F_206C_200B_202E_200B_202E_202E_206C_206F_206C_200F_200D_206F_200E_200D_206B_202A_200D_200F_202A_202E_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD9
	}

	static string _202D_202B_202A_202A_202B_202B_200B_206A_202C_206A_200F_206E_200B_206F_202C_200B_206A_200E_200B_206E_206D_202C_206D_202C_206A_200E_206E_200F_200F_200C_206D_206C_206F_206B_202E_200D_200B_206F_202B_202A_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static MessageBoxResult _206C_202A_206B_200D_202C_202B_200B_202B_200C_200B_200E_200E_202E_206E_206B_202C_206A_206B_202B_202A_202C_202D_206C_202D_206D_202B_202D_206C_202B_202D_206F_206D_202E_206E_206D_200D_206E_202A_202D_200C_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xAEEA4611
	}

	static string _206F_200E_206A_202A_202A_206C_206C_200C_206B_202E_200B_202D_200C_202C_206D_206F_200D_206C_200E_202D_200E_202C_200F_206A_206F_206D_202A_200B_202C_200D_202D_200D_200D_206F_206C_202E_202B_202B_202E_206E_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0x5B
	}

	static ProcessStartInfo _206A_202A_206D_206D_202C_206A_206B_202B_200B_206A_200B_202A_202B_200C_202A_202B_202B_206E_200F_202D_202E_200B_200E_202A_200B_206D_200E_206C_206D_200B_200D_206C_202E_206E_200B_206D_206C_206C_202D_200D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x7C
	}

	static void _200B_202B_202C_202A_206F_200C_206D_200E_200D_202C_200D_202D_206D_200C_202D_206D_200B_206F_202B_202D_200D_206E_200E_206D_200B_200F_206B_206D_200D_200D_202C_202B_206C_202B_202D_206D_206D_200C_206A_206F_202E(ProcessStartInfo P_0, bool P_1)
	{
		if (/*Error near IL_0001: Stack underflow*/ >= /*Error near IL_0001: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0001: Unknown opcode: 0xAA*/;
	}

	static Process _206B_202C_200D_202D_202A_200E_206F_202C_200E_206A_202A_200E_200C_206F_206D_206F_200F_202B_200F_206A_202E_200F_202C_200B_200D_206F_200D_200D_200B_206C_206B_206B_206F_202D_206B_200C_206A_202E_202D_200F_202E(ProcessStartInfo P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0x0D
	}

	static HttpRequest _200F_202D_200D_202A_206C_200C_206C_200C_200F_206D_206A_200C_200D_202C_206B_206A_206D_202A_202D_202A_200C_206D_202B_202E_200C_200D_200B_202B_202D_200D_200C_202A_202D_202E_206F_200B_200F_200C_202E_200C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE5
	}

	static string _206C_200E_202C_200E_202D_200D_206A_200E_206D_206E_206D_200C_206F_202C_200C_202D_206C_206A_202B_202B_202B_206B_200D_206B_206D_202C_200F_206E_202D_206E_206B_202E_200F_206A_206D_200D_200E_200D_202D_200D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}

	static void _202E_202A_206D_200E_200B_200B_206E_206D_202A_202C_202E_206A_202E_202D_202A_206B_206B_202C_206E_200C_206E_206F_206D_202B_206A_200C_200E_206F_200E_206B_206A_206A_206C_202E_202B_202B_206E_202B_202D_206C_202E(HttpRequest P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static HttpResponse _206F_206C_200D_200D_206F_200C_206E_202A_200C_200B_202D_206D_206C_206F_206A_206F_206A_202C_202D_202B_202A_202D_200D_206E_200E_202A_202E_202C_200E_202A_206C_206C_206A_206E_206C_202A_200C_200D_200C_206D_202E(HttpRequest P_0, string P_1, RequestParams P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x09
	}

	static bool _206A_206F_206C_206C_202A_202D_200D_200B_202D_206E_202A_200E_206A_200C_202E_202D_200F_202C_206E_200D_202E_202B_206A_200D_202E_202E_206E_206E_202D_206A_200B_206F_202E_202D_206E_206F_206E_206A_206F_200D_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x39
	}

	static bool _200F_206B_206B_206C_202E_206B_200D_202A_206B_206E_206E_200D_200D_202B_206B_200C_206F_206A_202B_202E_202D_202C_200B_202A_206C_206F_206D_200B_202C_200F_206E_200D_202C_206F_200C_202D_202C_206F_202B_202A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1D
	}

	static int _202C_202A_200B_202C_206F_200E_206B_200D_206A_206C_200E_206F_206F_202B_206E_202D_206A_200F_206B_206F_206D_206F_202A_206B_206C_206E_200B_206E_200D_206B_200B_206A_202D_200E_202A_206B_202C_202A_200C_200F_202E(int P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x71
	}

	static IChartValues _200F_206B_202A_200B_200D_206A_200D_200E_202D_206F_202C_206D_200C_206B_202A_202E_200B_206B_206B_200F_200B_206B_200E_206B_202A_200B_206C_202A_200E_202C_202B_206C_202A_206D_200D_206A_206D_200E_200E_206A_202E(ISeriesView P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x48
	}

	static int _202E_206D_202B_200C_206C_202E_206B_200B_200D_206B_202C_206B_202E_206D_200C_206A_200E_200D_206B_200E_200C_206C_206A_202E_206D_202C_202C_206A_202C_206C_206F_200E_200C_200C_206C_202A_206F_200E_202D_202B_202E(ICollection P_0)
	{
		checked
		{
			_ = ((ushort[])/*Error near IL_0004: Stack underflow*/)[(byte)(sbyte)unchecked((ulong)(long)/*Error near IL_0001: Stack underflow*/)];
			/*Error near IL_0004: Invalid calli metadata token*/;
		}
	}

	static void _202E_206A_206C_206A_200D_206A_206C_202E_202A_206B_202A_202C_206B_200B_200F_200B_200E_206F_206A_202C_200D_202E_202A_202C_202B_200B_202B_202D_200F_202D_202C_206A_200C_200C_202A_206C_200C_200C_206F_202C_202E(IList P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3F 0x68
	}

	static int _206A_200B_202D_206C_200C_206B_206C_206A_202C_202B_202C_200B_200F_200F_200F_202B_202E_206F_202A_200E_202C_202E_200D_202A_206A_206C_206D_206F_200B_200F_206A_206B_202D_202D_206E_202A_200F_200C_202E_202C_202E(IList P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}
}
