using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Input;

public class _Wre1fZEd28y1dOTLmEZt1RQxd3I : ICommand
{
	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _QxO6hNopEVJK7U2FaDACgDL8VQF : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _Wre1fZEd28y1dOTLmEZt1RQxd3I _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6F 0xA3
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF3 0x7B
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static TaskAwaiter _206A_202A_200D_206D_202D_202B_206F_202A_206F_206E_200D_200F_200D_206F_206F_206A_202C_202D_200C_202B_200D_202B_206E_200C_202D_202E_202E_206D_202C_202A_206E_206C_202E_200C_206B_200F_206B_200D_202E_206D_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _SKLcqyFxkNa7fH9Ya7WjL0Cs6Iq : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncVoidMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _Wre1fZEd28y1dOTLmEZt1RQxd3I _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB5
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC0
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static TaskAwaiter _202B_206A_202E_200D_200F_206A_206D_206A_202A_200C_206F_202E_202D_206C_202D_206C_202E_200C_206A_202C_200D_202E_202E_206E_200C_202B_206A_202C_200B_202B_206F_202E_206D_202B_200B_202E_200F_206F_202A_202A_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	private bool _89vGIZFirjpnsQbbahd5ib0bKfS;

	private readonly Func<Task> _Bi2o7B0aB3Seu67lRjBQlwtm0gf;

	private readonly Func<bool> _LeeEC1BpvqkKqPuhkIYnKZGjWwd;

	private readonly Action<Exception> _S0HT6QmuaiV64FyDzWeFj1Ai1Sz;

	public event EventHandler CanExecuteChanged
	{
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC4
		}
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB5
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public _Wre1fZEd28y1dOTLmEZt1RQxd3I(Func<Task> P_0, Func<bool> P_1 = null, Action<Exception> P_2 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x17 0xB6
	}

	public bool _839cKmdkDgx2DHXIZu5Ox290xKI()
	{
		if (/*Error near IL_0007: Stack underflow*/ < /*Error: ldloca 146 (out-of-bounds)*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0007: Unknown opcode: 0xF5*/;
	}

	[AsyncStateMachine(typeof(_QxO6hNopEVJK7U2FaDACgDL8VQF))]
	public Task _9bqjA8h2PS1xQyCeXG4nkXRKYrC()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	public void _VxRS7HzE5jzgsySUT4YYiBE0uDg()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2C
	}

	bool ICommand.CanExecute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x03 0xB5
	}

	[AsyncStateMachine(typeof(_SKLcqyFxkNa7fH9Ya7WjL0Cs6Iq))]
	void ICommand.Execute(object parameter)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	static ArgumentNullException _202E_202D_206C_202B_200E_202A_200F_200E_206E_202C_206A_200C_200B_202B_202B_206A_200E_200E_206D_200F_200D_202B_202A_202C_206E_200E_206B_202B_206B_206B_200D_200B_206C_200E_202B_200C_206E_202E_200C_200D_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9D
	}

	static void _206B_200E_202A_200D_206B_206B_200D_202D_206A_206C_206E_200C_200E_206D_200C_206E_202E_206A_200E_206D_200B_200C_206B_200C_202E_206B_202D_206D_202B_202C_206D_206B_206D_202A_200C_200B_200D_206B_206A_202C_202E(EventHandler P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9D
	}

	static void _206A_206C_202B_200C_202D_200F_206A_200C_202D_206C_200C_200C_202E_206B_206F_200F_200E_200C_206B_200D_202A_202C_206A_200D_202A_202D_206B_206A_202B_200B_200B_200C_206C_202D_200B_206B_202B_206F_200D_202A_202E(EventHandler P_0)
	{
		/*Error: Invalid metadata token*/;
	}

	static void _200C_206F_200B_206A_200C_200B_202A_202B_200F_202C_206C_206C_206F_206E_200B_200D_206A_206E_202A_200D_202E_202B_202C_202D_200F_206B_206C_206B_206C_202D_206A_200E_200F_206B_202C_202C_202C_206E_200E_200F_202E()
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x780D9673
	}
}
