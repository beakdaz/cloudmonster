using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _TDb99D9uW2lbidNMnIlPwJGYfHj<_0001> : INotifyPropertyChanged
{
	protected _0001 _QslvWppHAbjT86FW2mO1U6Ek7bh;

	[CompilerGenerated]
	private PropertyChangedEventHandler _arY7kwXO7ug04fWaROU2eJhjkKx;

	public unsafe _0001 Value
	{
		get
		{
			_ = *(int*)(nint)/*Error near IL_0001: Stack underflow*/;
			_ = (uint)null;
			_ = 2;
			/*Error near IL_0006: Unknown opcode: 0xF8*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x28
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDC
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}
	}

	protected void _1Yzk6bRp8xHCvc5v3jeg0buSEQb(string P_0)
	{
		/*Error: Unknown opcode: 0xFA*/;
	}

	public _TDb99D9uW2lbidNMnIlPwJGYfHj()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static bool _200C_200F_206E_200D_200D_202A_200C_206A_206B_202B_200B_206B_206E_202A_206F_200C_200B_206A_202D_200E_206F_202E_200B_200C_202A_206F_206E_206A_200B_206F_206E_206D_202C_206B_200F_202B_202B_200E_202D_202E_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	static Delegate _206C_206B_202E_202E_202B_206F_202D_202E_206F_206B_200F_206B_200B_206D_206E_202A_206B_202B_206C_200B_206D_202D_206D_206F_206F_200E_202D_202C_202B_202E_200E_206E_206B_206C_202C_200D_200B_202A_206A_200D_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static Delegate _202B_206D_206B_206D_206B_206B_200F_202C_200C_200D_206A_206C_206F_206A_200E_206A_202D_200D_202E_206C_206D_206C_206A_206E_206B_202C_206C_202E_200C_202E_202C_200E_206E_200E_200E_206D_200E_206A_202E_200C_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static PropertyChangedEventArgs _206E_202E_200B_202C_202A_202C_206D_206B_202B_206B_200C_202C_200B_202E_206C_206D_200E_202B_200C_200C_206E_206C_200C_206E_206B_202B_200B_202A_206B_206F_202D_202D_206F_206D_202B_200B_202E_206B_200E_202C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}
}
