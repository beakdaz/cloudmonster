using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Windows;

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyCompany("PhpMyAdmin")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("PhpMyAdmin")]
[assembly: AssemblyTitle("PhpMyAdmin")]
[assembly: AssemblyVersion("1.0.0.0")]
[module: _Vv3qdsqDb9OTA3ajdw7fC3CpZVA(11)]
