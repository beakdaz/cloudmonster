using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_ComputerSystemProduct")]
public sealed class _Z3dLQl3mrsNYEs8MfwN56QwVL9E : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _SAIpsOZA6hIbim1oPSBHcAIgOE4b;

	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _ebTu9crNgEhTQozsGigJWOkudV;

	[CompilerGenerated]
	private string _OoFKkHoW42hf63ZSRPqYhC2iCyf;

	[CompilerGenerated]
	private string _RSen2ZwPqotFSflgOZEpUTa7cXb;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _4x9TVnEQeG1kaPF4nssab67FE1W;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("UUID", _z9iGSNwAHN9WJNl40wnjovc9b6g = true, _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true)]
	public string _gx3mZGpXKtiF69Quy3i2WOkIqHe
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAC
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB7 0xDD
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name")]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x00
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Vendor")]
	public string _zcABsoO0zyEdjCzufFAZDBL8com
	{
		[CompilerGenerated]
		get
		{
			checked
			{
				_ = (sbyte)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xFC*/;
			}
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC8
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Version")]
	public string _NP0mfera5Nd2qLHDs05gNUwtwuB
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x70CEF3E2
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8F 0xD5
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Caption")]
	public string _VaEBso6OOri1y0w9IQvg5zajb6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x53 0xA0
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x27 0x2F
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA8
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("IdentifyingNumber")]
	public string _6qV08Z6heIxb8V8T1IFYToZVkCG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x67 0x6A
		}
		[CompilerGenerated]
		set
		{
			checked
			{
				_ = (nuint)/*Error near IL_0001: Stack underflow*/;
				/*OpCode not supported: DebugBreak*/;
				/*Error near IL_0002: Not a type handle*/;
			}
		}
	}

	private _Z3dLQl3mrsNYEs8MfwN56QwVL9E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}
}
