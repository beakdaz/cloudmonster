using System;
using System.Runtime.CompilerServices;

public class _qp3HOl7AATfXj9hxFJ0bhTYaaRy : Exception
{
	[CompilerGenerated]
	private readonly string _mWdAOs3tzksEfaDFJ7exKTcezkyA;

	public string _tvdtQU69qNsPHFtGqUuwoMIx5Ae
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6C
		}
	}

	public _qp3HOl7AATfXj9hxFJ0bhTYaaRy(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x12
	}

	public _qp3HOl7AATfXj9hxFJ0bhTYaaRy(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x25
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public virtual string _5RU6m6RQWG9zt0PKA8ncfFUmRLC()
	{
		throw /*Error near IL_0001: Stack underflow*/;
	}

	static bool _206B_200F_206E_200D_206D_202C_206A_206B_202D_202A_202D_202A_206A_200D_206E_206C_200D_206A_206D_206C_206F_206C_202C_206B_206C_202D_202B_206A_206B_200F_200C_200E_206E_206A_206C_206D_202E_206B_202C_202E_202E(string P_0)
	{
		/*Error: Invalid field token*/;
	}

	static string _206E_200F_202A_206F_202B_202A_202B_202A_206F_206F_206C_202E_202C_202A_200C_200D_206E_206A_200F_206A_206D_202D_206B_200E_206A_202E_202C_200F_206C_206F_206A_206E_206D_200C_202D_202B_200C_202A_206C_206D_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static string _200F_206D_206A_202D_200C_206A_200C_200B_202D_200E_200B_200F_200E_206F_200C_200E_202A_206C_202C_202A_200B_206F_200D_202D_206D_206F_206E_206E_206D_206F_202A_206D_206F_206F_206E_200D_202D_206E_200F_200F_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}
}
