using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_SystemEnclosure")]
public sealed class _ZZGo2mEFd1PtkYprWFQAegl92Ve : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _RduTl3L1YDrve5QLAzSP1vC80Gf;

	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _RSen2ZwPqotFSflgOZEpUTa7cXb;

	[CompilerGenerated]
	private string _OoFKkHoW42hf63ZSRPqYhC2iCyf;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _tIzOxqAveP3uc4ROcd6D3llDGiD;

	[CompilerGenerated]
	private string _IR4UikgDdp8PuDPgCYLoVBhsdaV;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("SMBIOSAssetTag")]
	public string _QwzBhP9bDb3e0j5uzm8hp70VCMX
	{
		[CompilerGenerated]
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			if (/*Error near IL_0004: Stack underflow*/ > /*Error near IL_0002: Stack underflow*/>> (int)checked((uint)/*Error near IL_0001: Stack underflow*/))
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0004: Invalid field token*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name")]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFD
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3F 0x9D
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Caption")]
	public string _VaEBso6OOri1y0w9IQvg5zajb6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5F 0x49
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Version")]
	public string _NP0mfera5Nd2qLHDs05gNUwtwuB
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x60
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x333AC9EE
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x94
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7D
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("SerialNumber")]
	public string _ozceJCod4VTkGRUZ6esDi7DJ2jjA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA7 0xD1
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Manufacturer")]
	public string _2LGcfWg9irJpfYK5B4taNm2rHsG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8C
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0xCBA08688
		}
	}

	private _ZZGo2mEFd1PtkYprWFQAegl92Ve()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}
}
