using System;
using System.Runtime.CompilerServices;

internal class _G15v8HWgo02bl3FVfr7aE6PyhXk : _TDb99D9uW2lbidNMnIlPwJGYfHj<int>
{
	[MethodImpl(MethodImplOptions.NoInlining)]
	public int _0s7BnTa7QECXUctzgLGoxEqXm9X()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x39
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public int _KhT6m2eLN37yuswvDz2IGUsbBVC()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	[SpecialName]
	public static _G15v8HWgo02bl3FVfr7aE6PyhXk _9apHzhs5aY5HXiBtJkzUNBznfbk(_G15v8HWgo02bl3FVfr7aE6PyhXk P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x71
	}

	[SpecialName]
	public static _G15v8HWgo02bl3FVfr7aE6PyhXk _714Bh0tidU5cFYGXq5JNELMzq0x(_G15v8HWgo02bl3FVfr7aE6PyhXk P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8F 0x43
	}

	[SpecialName]
	public static bool _ESSZuNWL3tFRWo2BIjseeUxkxIt(_G15v8HWgo02bl3FVfr7aE6PyhXk P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD1
	}

	[SpecialName]
	public static bool _ltcDLK9Xb6yipP3m5Vpztb4uT2c(_G15v8HWgo02bl3FVfr7aE6PyhXk P_0, int P_1)
	{
		checked
		{
			_ = (nint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xF1*/;
		}
	}

	protected bool _JLnVKxazDTsbncW5FaLxNDYw6AG(_G15v8HWgo02bl3FVfr7aE6PyhXk P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF3 0x60
	}

	public virtual bool _JLnVKxazDTsbncW5FaLxNDYw6AG(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x23 0x9A
	}

	public virtual int _vU4UxKs8kzJleML5UufsADbk5il()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFB 0xC1
	}

	static int _206B_200E_202D_200C_206D_200C_206C_200D_206B_202D_200C_206E_200E_202B_206A_200B_200B_202B_202A_200B_200B_202A_202C_206F_200D_202E_206D_206F_200D_202E_200C_206A_206F_200B_206A_200F_206C_206C_202C_202C_202E(ref int P_0)
	{
		checked
		{
			_ = (int)(ref P_0);
			/*Error near IL_0002: Unknown opcode: 0xA7*/;
		}
	}

	static int _206A_202D_202A_206A_200B_200C_206D_202D_202A_206F_206B_206B_200E_206D_206A_200E_206B_200D_206F_200B_200C_202B_206E_202C_206F_200C_202D_200E_200E_206C_200B_206F_202C_206C_206A_200B_200B_200E_202D_206E_202E(ref int P_0)
	{
		/*Error: Unknown opcode: 0xFD*/;
	}

	static Type _206D_200E_206A_202D_200F_202B_206F_206A_200E_200F_202E_200B_206C_202C_202A_202C_202E_206B_202C_206C_206C_200D_206D_206D_202A_200D_200D_202D_200F_200C_202B_206A_206B_206A_206C_206D_202A_202D_202D_202C_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x98
	}

	static Type _200D_206D_202A_200D_206E_202C_202C_202E_202B_200D_206D_200F_206F_202D_206C_200B_206F_202B_202C_206B_202D_206E_202A_200D_200F_202E_200B_202C_206D_202C_200F_200C_206F_206A_200D_202A_200B_206A_206F_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0x42
	}

	static bool _206B_206B_206A_206F_206F_202A_202B_206F_200B_206D_200D_202A_200E_202C_206F_206A_200C_206E_200B_200F_200E_202B_202B_200E_202B_202D_200B_200E_202A_200D_202C_200C_206F_200E_202D_206E_202B_200C_200F_202A_202E(Type P_0, Type P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x79
	}
}
