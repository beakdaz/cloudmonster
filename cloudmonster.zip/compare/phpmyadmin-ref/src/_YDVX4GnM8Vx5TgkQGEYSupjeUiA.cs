using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_BaseBoard")]
public sealed class _YDVX4GnM8Vx5TgkQGEYSupjeUiA : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _tIzOxqAveP3uc4ROcd6D3llDGiD;

	[CompilerGenerated]
	private string _BvbhPXRrCFxHCQzsmNhImM8IRuj;

	[CompilerGenerated]
	private string _HijGTDlOQiAvsHqaGS6tATpqD6j;

	[CompilerGenerated]
	private string _rzmCE1XW2OFRRFDZKsPJliDsjxG;

	[CompilerGenerated]
	private string _RSen2ZwPqotFSflgOZEpUTa7cXb;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _IR4UikgDdp8PuDPgCYLoVBhsdaV;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("SerialNumber", _z9iGSNwAHN9WJNl40wnjovc9b6g = true)]
	public string _ozceJCod4VTkGRUZ6esDi7DJ2jjA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB5
		}
		[CompilerGenerated]
		set
		{
			/*Error: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xB0*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Name")]
	public string _GbZCrSwHUvvuUCrMu9CYOLMwziD
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1F 0x83
		}
		[CompilerGenerated]
		set
		{
			/*Error: Invalid branch target*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Model")]
	public string _3RkdMt0F4tkVgRu6tUerms2J0Zc
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x05
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAD
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Product")]
	public string _ukpAc1XaMJPy7GHcjla6h784jYfb
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9B 0xFC
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Caption")]
	public string _VaEBso6OOri1y0w9IQvg5zajb6A
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x20
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1F 0x58
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD5
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC3 0x64
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Manufacturer")]
	public string _2LGcfWg9irJpfYK5B4taNm2rHsG
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5B 0xE1
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9C
		}
	}

	private _YDVX4GnM8Vx5TgkQGEYSupjeUiA()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}
}
