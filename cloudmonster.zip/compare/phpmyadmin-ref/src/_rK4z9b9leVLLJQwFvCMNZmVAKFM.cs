public interface _rK4z9b9leVLLJQwFvCMNZmVAKFM
{
	string _eaoBAdVCPFyZIM8mDx28SCXwEw1 { get; }

	int _iO0Mz10j4WWZ1vG7LBOz7sWUSSd { get; set; }

	int _XmYAk4f8tC1yaxh0zKqIBa6hwxW { get; set; }

	bool _peIMkkUB49hMDmauPUhLROcraYA(string P_0);

	string _5RU6m6RQWG9zt0PKA8ncfFUmRLC();
}
