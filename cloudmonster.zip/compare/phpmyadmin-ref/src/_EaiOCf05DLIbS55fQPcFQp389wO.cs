using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

public class _EaiOCf05DLIbS55fQPcFQp389wO : INotifyPropertyChanged
{
	private string _KA0fGdjb8hmkI04VFy4sgRpKXNY;

	private string _gUEBzPfBSFLBRtcKTFa4dVGpCgdA;

	private long _UfVizrsc6NSogy3oZr9fm6qusVH;

	[CompilerGenerated]
	private PropertyChangedEventHandler _arY7kwXO7ug04fWaROU2eJhjkKx;

	public unsafe string Status
	{
		get
		{
			_ = (sbyte)(*(nint*)(nint)/*Error near IL_0001: Stack underflow*/);
			/*Error near IL_0002: Unknown opcode: 0xB1*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x48
		}
	}

	public string Text
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x9A
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x73
		}
	}

	public long Received
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF9
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xED
		}
	}

	public string FormattedReceived
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7C
		}
	}

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5F 0x7D
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8D
		}
	}

	protected virtual void _sl4k5NzeijBrxuHECAXWFnCh2qd([CallerMemberName] string P_0 = null)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0001: Stack underflow*/>> (int)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: stloc 0 (out-of-bounds)*/;
		/*Error near IL_0002: ldarg 3 (out-of-bounds)*/;
		/*Error near IL_0003: Unknown opcode: 0xBE*/;
	}

	protected bool _2EhktIeCgoRX5kHQwyV7vdZVrDl<_0001>(ref _0001 P_0, _0001 P_1, [CallerMemberName] string P_2 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static string _xomlG39cDVrKHlnRd94gZyIz8Pf(long P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8C
	}

	public _EaiOCf05DLIbS55fQPcFQp389wO()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static bool _200B_202C_206F_202C_200F_202A_200D_200B_200B_206B_206A_200B_200D_200E_200B_206D_202B_200E_206A_200B_206D_200B_206A_200D_200B_206E_206D_202D_200D_206B_202E_206B_200D_200E_200F_200E_202B_200E_200E_206B_202E(string P_0, string P_1)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static Delegate _202A_200C_202D_202E_202C_202D_206B_202C_202C_206A_206A_202B_202E_206F_202D_202E_206C_200D_206D_200E_202C_206E_202D_202E_202C_202C_200C_202C_206F_206E_206F_200D_202E_202B_206C_206A_200C_200D_206B_200E_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static Delegate _200D_200C_206E_206C_200F_206E_206D_202E_202D_206E_206B_200F_206C_200C_202C_200B_202A_202A_200C_200F_206B_206E_202E_200C_200D_202D_206F_206A_202D_202B_206A_202B_206E_206C_202B_206C_206E_206F_206D_206D_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static PropertyChangedEventArgs _206C_206D_206A_202B_206A_206A_200C_206E_202C_206C_206D_202E_206C_206B_206C_206E_202A_202C_200F_206A_206E_206F_202E_202B_206B_202B_206B_206E_206E_202A_202A_206F_206B_202D_206A_200E_206D_206B_206C_202D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}

	static string _206B_206A_206F_202B_200E_200B_202D_206F_200E_206A_206B_202A_206D_206A_202C_202D_206E_202E_202E_206B_202E_200E_202C_200C_202C_200C_206E_202A_206B_202C_206B_206A_202E_206A_202B_202C_202E_202D_202C_200C_202E(string P_0, object P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x61
	}
}
