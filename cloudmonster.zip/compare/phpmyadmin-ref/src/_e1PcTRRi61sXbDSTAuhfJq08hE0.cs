using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

public abstract class _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _d1mCZmwds1DiHRcPxaCim5iNBe5C
	{
		public static readonly _d1mCZmwds1DiHRcPxaCim5iNBe5C _003C_003E9;

		public static Func<PropertyInfo, bool> _003C_003E9__4_0;

		static _d1mCZmwds1DiHRcPxaCim5iNBe5C()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}

		public _d1mCZmwds1DiHRcPxaCim5iNBe5C()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal bool _AR3HvB9UsQLU8dkan3WJGiUn3VG(PropertyInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}

		static bool _206A_202D_206E_200B_200F_202E_202B_202D_206B_206A_202B_206B_200E_206D_202D_200B_200C_202A_202B_206A_206D_200F_206D_206C_200B_206F_200E_200F_200B_206D_200E_200D_202B_206A_200C_202A_200C_202A_200C_200E_202E(PropertyInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x33 0xC6
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _zw8bSRAVo1z7ClpLtQbezsPfptW<_0001> where _0001 : _e1PcTRRi61sXbDSTAuhfJq08hE0
	{
		public static readonly _zw8bSRAVo1z7ClpLtQbezsPfptW<_0001> _003C_003E9;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute), string> _003C_003E9__3_0;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute), bool> _003C_003E9__3_2;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute), bool> _003C_003E9__3_1;

		public static Func<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute), bool> _003C_003E9__3_3;

		static _zw8bSRAVo1z7ClpLtQbezsPfptW()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}

		public _zw8bSRAVo1z7ClpLtQbezsPfptW()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal string _V7f7w7YwVBhqEQ6XUbIMtIkfoId((string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}

		internal bool _PqSU4EwnFxGwYPY7moYdNao6u4b((string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5F 0xDE
		}

		internal bool _vwqawgCl92casIcZpMy8koXCp0AA((string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}

		internal bool _uhX7InmsEY5bYQv9zZ5FiDo4CqT((string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) P_0)
		{
			checked
			{
				_ = (ulong)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Read out of bounds.*/;
			}
		}
	}

	[CompilerGenerated]
	private sealed class _O97my4U1rIiefEUGDFXEk4YaAUE<_0001> where _0001 : _e1PcTRRi61sXbDSTAuhfJq08hE0
	{
		public (string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) _umHdU1uqOiX8fnjKH7tlpNnXhij;

		public _O97my4U1rIiefEUGDFXEk4YaAUE()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal object _6Ogtd5wfRG4Aia0SwOQmTE10i6A(_0001 P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}

		static object _200B_202A_202E_206B_200F_202B_202B_202B_206F_202A_200F_200D_206E_202D_206F_200D_202B_202B_202B_200D_206C_206F_206C_202A_202A_206A_206E_202A_206D_202B_206A_202E_202C_202C_206B_206C_206D_206C_202A_206A_202E(PropertyInfo P_0, object P_1, object[] P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCB 0x02
		}
	}

	[CompilerGenerated]
	private sealed class _VnPkEmZVhu6x2vhggrtkjQ8dAAJ : IEnumerable<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute)>, IEnumerator<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute)>, IEnumerator, IDisposable, IEnumerable
	{
		private int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		private (string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) _3tIG6UVQ4UPou107F3J4pJaBtrk;

		private int _bXU2D86OrOUxgQVBSC9GehimS1W;

		private Type _8v7NdythDGV7a2P9W9xtUtG2wDJ;

		public Type _dhO047YtXBRAohNT0Z5s60WNilD;

		private IEnumerator<PropertyInfo> _uKpYifnB0xEYESgIi8iaIQ27xL5;

		(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute) IEnumerator<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute)>._GfOHkJpsltTvVgiqlFqEP57KY3c
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x15
			}
		}

		object IEnumerator._Duoernm7b6cxarH5RFBwpDWHX9A
		{
			[DebuggerHidden]
			get
			{
				//Invalid MethodBodyBlock: Invalid method header: 0x3B 0xE1
			}
		}

		[DebuggerHidden]
		public _VnPkEmZVhu6x2vhggrtkjQ8dAAJ(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x85
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFF 0x1A
		}

		private bool MoveNext()
		{
			checked
			{
				_ = (uint)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xF7*/;
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		private void _ervxcZHNZEp1YIoLWqKnuSSjWY()
		{
			if (/*Error near IL_0005: Stack underflow*/ >= /*Error near IL_0005: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0005: Invalid field token*/;
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			/*Error: Unknown opcode: 0xE8*/;
		}

		[DebuggerHidden]
		IEnumerator<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute)> IEnumerable<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute)>.GetEnumerator()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3D
		}

		[DebuggerHidden]
		IEnumerator IEnumerable.GetEnumerator()
		{
			/*Error: Unknown opcode: 0xC1*/;
		}

		unsafe static int _206E_206C_206A_200D_206E_200F_200F_202C_202D_200E_200B_206A_200D_206E_206A_200E_206E_206A_200B_206B_206C_200B_200F_206A_206D_202D_206F_200B_200C_200E_202D_200C_206F_206C_202D_206D_200F_202E_206A_202A_202E()
		{
			checked
			{
				_ = (nuint)unchecked((int)(*(byte*)(-5)));
				/*Error near IL_0004: Unknown opcode: 0xFEC4*/;
			}
		}

		static PropertyInfo[] _200D_206A_200E_206C_202D_200F_206B_200B_202B_202A_206D_202B_206A_200C_206C_200C_202E_206D_200F_200B_206D_200B_202B_202C_200F_206C_206C_206C_200D_206D_206D_206A_206B_206A_200B_200F_206D_206C_206E_200E_202E(Type P_0, BindingFlags P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE1
		}

		static string _200F_202B_202E_200C_206F_206E_206E_200D_200E_202C_202D_206E_200E_200C_202E_202A_200E_200C_206F_206A_200D_206F_200E_200F_202C_200C_202D_200B_202C_200F_206C_200B_202A_200E_200D_206B_202A_202E_200C_200E_202E(MemberInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFF 0x1F
		}

		static bool _206D_202D_206D_202B_200D_206F_206F_202B_206A_200F_202A_206F_202A_206E_202D_200B_200E_202A_206D_202D_206B_200F_200D_206D_200E_206D_206E_206C_206A_206D_200C_206F_200B_206D_200B_206D_206D_200D_206C_202E(IEnumerator P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}

		static void _200B_206D_206B_202D_206A_202B_206E_202C_202D_206B_206C_202E_206E_202E_200E_202E_206B_202C_206B_206B_206A_202C_200D_206E_206B_206B_206A_202C_200C_206B_202A_206D_200C_200F_206F_200C_202D_202A_200F_200F_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static NotSupportedException _206F_206F_200D_206D_206F_206E_206F_206A_202B_206C_206A_200C_202A_206D_200C_200B_206E_200C_202D_200E_202B_202D_206B_200D_206E_202E_206E_200B_200F_206B_202C_206B_202A_202D_206D_206F_206B_200F_206E_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}
	}

	protected virtual bool _7XSaEtGveaNphRXPJp1DwZ53W8u
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF9
		}
	}

	public static _0001 _EKkzNOa2jSjdoRrjtZepL00EQhG<_0001>() where _0001 : _e1PcTRRi61sXbDSTAuhfJq08hE0
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x95
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static IEnumerable<_0001> _gAGXPI13GjuysSpk91jInKrF2YC<_0001>() where _0001 : _e1PcTRRi61sXbDSTAuhfJq08hE0
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}

	[IteratorStateMachine(typeof(_VnPkEmZVhu6x2vhggrtkjQ8dAAJ))]
	private static IEnumerable<(string PropertyName, PropertyInfo PropertyInfo, _2TZHKOVBqCRTojsrTXGYzWqT05c PropertyAttribute)> _7ooxD0HkEtJTA4ZjEGfjMiS2M0X(Type P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCF 0x8F
	}

	protected _e1PcTRRi61sXbDSTAuhfJq08hE0()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static Type _202C_206E_200B_200F_202D_202A_206E_200F_200F_206E_206C_200B_200F_206E_206E_206D_200D_200C_200E_206E_200B_200C_202B_206F_200B_200B_200D_206C_202D_200D_206B_200B_200E_206F_202A_206A_202D_202B_206F_200E_202E(RuntimeTypeHandle P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0x1F
	}

	static object _206B_202D_200B_206E_200D_200C_206B_202A_202D_206F_200D_206B_200B_202A_206E_200D_200B_202E_202E_202C_202C_202C_206C_206B_200E_202D_202E_200F_206B_202C_206C_202A_200D_200B_202E_200D_206F_200B_200B_200C_202E(Type P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	static string _202B_202C_200D_200C_202A_200D_200B_200D_206C_200C_206C_202A_200F_200B_202A_202A_202B_206E_206E_202A_202B_200E_202D_206A_200E_200E_206B_200D_202C_206B_202D_202D_206F_202D_200E_202E_206F_206F_200D_202A_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB8
	}

	static string _200F_202A_202E_200E_202A_200F_206D_206F_206B_202C_200E_200B_206E_202A_206B_202A_206C_206F_202B_206A_200C_206C_202D_206A_206B_200F_202C_202B_206A_206D_206A_206C_202D_200C_206B_202C_200D_206F_202B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x77
	}

	static void _202D_202C_200E_202B_206E_206E_206C_202C_202E_200B_206F_206B_206E_200E_202A_202B_202C_206D_200C_206F_206A_202D_206F_202C_206E_200C_206D_200E_206B_206C_200F_202E_206B_206E_200B_200F_202B_206A_200E_206F_202E(PropertyInfo P_0, object P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC5
	}

	static bool _202E_202D_202B_202E_200B_200C_200D_206C_202B_202A_202B_200D_200F_206A_200D_206A_200D_200E_202D_202E_200F_206D_202A_206D_202C_200F_200E_206D_200D_206F_206C_200F_200B_202A_206C_206A_202E_200B_206C_206A_202E(IEnumerator P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static void _200D_202A_206E_206B_202D_206D_202D_202D_202E_206D_206B_200D_202A_206B_202D_200F_202C_200C_206D_202D_206B_202B_202B_200E_200C_200B_206B_206F_200C_202B_206C_200E_200F_206C_206B_202B_206D_200D_200D_202B_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	static object _206A_202C_200B_200E_200E_206E_202D_206D_206D_200E_202B_202E_202E_202B_202D_200E_202C_206C_202B_206F_202D_200F_200F_206E_200C_202A_206B_200D_202E_200B_206D_200F_206E_206F_206E_206E_206E_202A_200F_200C_202E(PropertyInfo P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}

	static bool _200F_202A_202D_200C_206E_202D_200E_206E_200C_206F_206E_200F_206E_206E_206F_202A_202C_202A_202C_206F_200B_200B_206B_202D_202A_202D_200E_202C_202D_200D_200B_200F_206F_200E_200D_206F_202C_202A_202E_206E_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x07 0xCE
	}
}
