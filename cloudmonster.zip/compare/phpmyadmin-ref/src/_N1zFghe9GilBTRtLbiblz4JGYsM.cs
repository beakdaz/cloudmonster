using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

[DefaultMember("Item")]
public sealed class _N1zFghe9GilBTRtLbiblz4JGYsM : ICollection<_oh4yStHpxF3fEfcUptTuIXENCsi>, IEnumerable<_oh4yStHpxF3fEfcUptTuIXENCsi>, IEnumerable
{
	[CompilerGenerated]
	private sealed class _aFsAQ1zgHEyouyaonQKh5vbb9Oz
	{
		public string _IjjAenUKu0DisLzDnXOFS4kXnUDA;

		public _aFsAQ1zgHEyouyaonQKh5vbb9Oz()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal bool _IN3Phm3BDoCdoPylbxOBmPuYIlk(_oh4yStHpxF3fEfcUptTuIXENCsi P_0)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			if (/*Error near IL_0003: Stack underflow*/ != (/*Error near IL_0001: Stack underflow*/ ^ /*Error near IL_0001: Stack underflow*/))
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0003: Unknown opcode: 0xFF*/;
		}

		static bool _200B_206F_200C_206F_206F_200B_206F_202C_202D_200C_202D_206A_206E_200C_200B_206B_200D_206D_206E_206F_200B_206A_206C_200B_200F_206D_200C_202D_202B_200D_200D_206A_206E_206B_202C_206F_200E_200D_200E_206E_202E(string P_0, string P_1)
		{
			/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
		}
	}

	[CompilerGenerated]
	private sealed class _6gtcYStl1ccDKkdjB3QkSgAKkCkA
	{
		public string _IjjAenUKu0DisLzDnXOFS4kXnUDA;

		public _6gtcYStl1ccDKkdjB3QkSgAKkCkA()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal bool _sqqvdBtnR8zfN7RCRA7mVb8PADE(_oh4yStHpxF3fEfcUptTuIXENCsi P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD7 0xAF
		}

		static bool _200C_206D_200B_202A_206C_206A_202A_206D_200F_200C_202D_206D_202A_202B_202D_206E_200D_206A_206F_202C_202D_202B_202E_206F_202C_202D_206C_200D_202C_202B_200D_206A_202D_200B_206D_200F_202E_200F_206B_200C_202E(string P_0, string P_1)
		{
			/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
		}
	}

	[CompilerGenerated]
	private sealed class _9M0R1tStIU29xXp8fGrACA4IAjH
	{
		public string _IjjAenUKu0DisLzDnXOFS4kXnUDA;

		public _9M0R1tStIU29xXp8fGrACA4IAjH()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal bool _jmt7qbXDbcb20kz76v8s2Dannvi(_oh4yStHpxF3fEfcUptTuIXENCsi P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x50
		}

		static bool _200E_202C_200B_200D_206A_206E_206F_202E_206D_202A_202D_206C_206E_200B_202A_206F_206F_206D_202A_206A_206F_202B_206C_206E_206A_206D_202C_202E_200E_200C_200C_202D_200C_200D_202D_202B_206F_202E_206D_206E_202E(string P_0, string P_1)
		{
			/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
		}
	}

	private readonly List<_oh4yStHpxF3fEfcUptTuIXENCsi> _fEJAuIDF02CGCCbFvw4NAcQzxnUA;

	public bool IsReadOnly
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA1
		}
	}

	public int Count
	{
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = (sbyte)(/*Error near IL_0001: Stack underflow*/ >> unchecked((int)/*Error near IL_0001: Stack underflow*/));
				/*Error near IL_0002: Unknown opcode: 0xBB*/;
			}
		}
	}

	// C# has no syntax for parameterized property '_iL3R5m8a5RgyADLJVYafgoHKEf3'.
	[MethodImpl(MethodImplOptions.NoInlining)]
	public _oh4yStHpxF3fEfcUptTuIXENCsi _eDO7eJdB1qoNcQKkPIn0MfYOZBP(string P_0, bool P_1 = true)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5F 0xED
	}

	public _N1zFghe9GilBTRtLbiblz4JGYsM(IEnumerable<_oh4yStHpxF3fEfcUptTuIXENCsi> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x30
	}

	public unsafe IEnumerator<_oh4yStHpxF3fEfcUptTuIXENCsi> GetEnumerator()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Expected native int or pointer, but got F8
		if (/*Error near IL_0008: Stack underflow*/ < checked(4 + /*Error near IL_0001: ldloc 3 (out-of-bounds)*/))
		{
			/*Error: Invalid branch target*/;
		}
		*(_003F*)(nint)(double)/*Error near IL_0009: Stack underflow*/ = /*Error near IL_0009: ldarg 2 (out-of-bounds)*/;
		_ = *(ushort*)(nint)/*Error near IL_000c: Stack underflow*/;
		/*Error near IL_000c: Unknown opcode: 0xF8*/;
	}

	IEnumerator<_oh4yStHpxF3fEfcUptTuIXENCsi> IEnumerable<_oh4yStHpxF3fEfcUptTuIXENCsi>.GetEnumerator()
	{
		//ILSpy generated this explicit interface implementation from .override directive in GetEnumerator
		return this.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		/*Error: Invalid metadata token*/;
	}

	public void Add(_oh4yStHpxF3fEfcUptTuIXENCsi item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB5
	}

	void ICollection<_oh4yStHpxF3fEfcUptTuIXENCsi>.Add(_oh4yStHpxF3fEfcUptTuIXENCsi item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Add
		this.Add(item);
	}

	public void Clear()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x95
	}

	void ICollection<_oh4yStHpxF3fEfcUptTuIXENCsi>.Clear()
	{
		//ILSpy generated this explicit interface implementation from .override directive in Clear
		this.Clear();
	}

	public unsafe bool Contains(_oh4yStHpxF3fEfcUptTuIXENCsi item)
	{
		//IL_0003: Expected O, but got I4
		//IL_0008: Expected O, but got I8
		((int[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (int)/*Error near IL_0001: Stack underflow*/;
		checked
		{
			((object[])/*Error near IL_0008: Stack underflow*/)[/*Error near IL_0008: Stack underflow*/] = (long)unchecked((int)checked(unchecked((uint)(*(byte*)((Array)checked((int)/*Error near IL_0002: Stack underflow*/)).LongLength)) * 6u));
			/*Error near IL_0008: ldloc 1 (out-of-bounds)*/;
			/*Error near IL_0009: Invalid metadata token*/;
		}
	}

	bool ICollection<_oh4yStHpxF3fEfcUptTuIXENCsi>.Contains(_oh4yStHpxF3fEfcUptTuIXENCsi item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Contains
		return this.Contains(item);
	}

	public bool _xUN5S5OZJmoBSIeajK2RbTZbq8(string P_0)
	{
		checked
		{
			_ = (ulong)/*Error near IL_0001: Stack underflow*/;
			_ = (ulong)(object)this;
			/*Error near IL_0003: Unknown opcode: 0xFEC6*/;
		}
	}

	public void CopyTo(_oh4yStHpxF3fEfcUptTuIXENCsi[] array, int arrayIndex)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x77 0x1D
	}

	void ICollection<_oh4yStHpxF3fEfcUptTuIXENCsi>.CopyTo(_oh4yStHpxF3fEfcUptTuIXENCsi[] array, int arrayIndex)
	{
		//ILSpy generated this explicit interface implementation from .override directive in CopyTo
		this.CopyTo(array, arrayIndex);
	}

	public bool Remove(_oh4yStHpxF3fEfcUptTuIXENCsi item)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	bool ICollection<_oh4yStHpxF3fEfcUptTuIXENCsi>.Remove(_oh4yStHpxF3fEfcUptTuIXENCsi item)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Remove
		return this.Remove(item);
	}

	public bool _wawb6k2WukyLZjSC9PJdtyv0yXl(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAF 0xD8
	}

	static string _200F_202B_202B_200D_206A_200F_202C_200F_206C_206E_202C_206F_206F_206D_202D_206F_202C_202E_202E_200D_206C_206C_206C_206A_206E_202D_206E_200C_200F_206D_206A_206B_202B_206C_202C_200D_202C_202C_200E_200E_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static IndexOutOfRangeException _202D_202B_200C_206F_200C_206D_200C_202B_202E_202B_200F_206C_200F_200B_206D_206A_206C_206C_200C_206F_200B_206D_206F_200C_200C_202E_206F_202E_202C_206F_206F_202C_200C_200D_202C_200B_206D_206A_206E_200F_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	static NotImplementedException _206A_202C_206D_206A_206F_206F_200E_206C_202E_202E_206A_206C_202A_200C_206D_202B_200B_200B_200B_206A_200D_200C_206D_200C_206F_206D_206C_206A_202E_200C_206C_206A_206E_202B_202C_200B_202D_202A_202C_202A_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}
}
