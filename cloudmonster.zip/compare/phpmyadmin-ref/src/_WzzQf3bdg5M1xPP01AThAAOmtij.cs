public enum _WzzQf3bdg5M1xPP01AThAAOmtij
{
	Invalid,
	Bad,
	Captcha,
	Good
}
