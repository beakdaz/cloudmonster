using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal static class _R4toOBkGwfshGjofWh6gsDWxLyG
{
	private static object _41DeUMw7xDfyeXO0f3szxA9icyi;

	private static Dictionary<string, bool> _yjW74NgKZShG65IwDjMw6GsBsac;

	private static Dictionary<string, string> _4nmj811TuH3QwOXi6hzJgwGd71d;

	private static Dictionary<string, string> _VfaMCKd9KzC4xvSDEjrv7nk0vgb;

	private static int _MYxl38DjQVqErBeVBTCb1fbhyvN;

	private static string _ahNT5aEPLWEw9oG6IdPAmm66TLE(CultureInfo P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0xD2
	}

	private static Assembly _32XDadvleXZHRBD0CvkNe1cItcyA(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE5
	}

	private static void _PFKAUmO8Lzqhnq7X80z0qlYGAXg(Stream P_0, Stream P_1)
	{
		/*Error: Invalid metadata token*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static Stream _IGz4B8WFGSeLmzH1KgN3K4gsxNj(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB7 0x98
	}

	private static Stream _IGz4B8WFGSeLmzH1KgN3K4gsxNj(Dictionary<string, string> P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x95
	}

	private static byte[] _vqxgG9QbJ2Fl8ZNOZSxWWCMBdto(Stream P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x53
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static Assembly _G8x9fyFTcO7SOdjE225kWLOfRHC(Dictionary<string, string> P_0, Dictionary<string, string> P_1, AssemblyName P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x00
	}

	public static Assembly _MGbEMYbr14xRtKkCltOTKNFVZhk(object P_0, ResolveEventArgs P_1)
	{
		// ILSpy could not decompile this. Please report the exception below,
		// along with the assembly it came from, at https://github.com/icsharpcode/ILSpy/issues/new
		// System.ArgumentException: Invalid token. (Parameter 'token')
		//    at System.Reflection.Throw.InvalidToken()
		//    at System.Reflection.Metadata.Ecma335.MetadataTokens.EntityHandle(Int32 token)
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeMetadataToken() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 225
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeTypeReference() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 237
		//    at ICSharpCode.Decompiler.IL.ILReader.DecodeInstruction() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 1196
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadBlock(ImportedBlock block, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 537
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadInstructions(CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 504
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadIL(MethodDefinitionHandle method, MethodBodyBlock body, GenericContext genericContext, ILFunctionKind kind, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 724
		//    at ICSharpCode.Decompiler.CSharp.CSharpDecompiler.DecompileBody(IMethod method, EntityDeclaration entityDecl, DecompileRun decompileRun, ITypeResolveContext decompilationContext, ExtensionInfo extensionInfo) in /_/ICSharpCode.Decompiler/CSharp/CSharpDecompiler.cs:line 2282
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	static _R4toOBkGwfshGjofWh6gsDWxLyG()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0xB1
	}

	public static void _iit2fkGbbo7jPMUQeaoulIn9fqf()
	{
		_ = ((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
		/*Error near IL_0001: Invalid metadata token*/;
	}

	static string _200B_202E_202A_202C_200C_206F_200E_202D_200E_206D_200D_202C_202C_202C_202E_206C_202A_202D_206D_200D_200B_206E_206C_202D_202D_206B_202B_206E_200E_200C_206E_202D_206E_206A_202C_200D_200F_206A_206C_200F_202E(CultureInfo P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x88
	}

	static AppDomain _200B_206C_200F_206D_206F_206D_202B_202E_202D_202A_202B_200B_206B_200B_200F_202E_200E_206C_202B_200B_202A_202D_206E_206F_202A_202D_206F_200F_200D_202C_200D_206E_206F_206A_200D_202E_206D_200D_206E_202E_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static Assembly[] _206F_206B_202B_206D_200F_200B_206F_202B_202A_200C_200E_202B_202B_206A_202B_206D_202C_202D_200E_202D_206C_202A_206C_200F_206D_206E_206A_206B_206C_202D_206D_200B_202D_202A_202C_200D_202D_206F_206C_200D_202E(AppDomain P_0)
	{
		// ILSpy could not decompile this. Please report the exception below,
		// along with the assembly it came from, at https://github.com/icsharpcode/ILSpy/issues/new
		// System.ArgumentException: Invalid token. (Parameter 'token')
		//    at System.Reflection.Throw.InvalidToken()
		//    at System.Reflection.Metadata.Ecma335.MetadataTokens.EntityHandle(Int32 token)
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeMetadataToken() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 225
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadAndDecodeFieldReference() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 249
		//    at ICSharpCode.Decompiler.IL.ILReader.DecodeInstruction() in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 1204
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadBlock(ImportedBlock block, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 537
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadInstructions(CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 504
		//    at ICSharpCode.Decompiler.IL.ILReader.ReadIL(MethodDefinitionHandle method, MethodBodyBlock body, GenericContext genericContext, ILFunctionKind kind, CancellationToken cancellationToken) in /_/ICSharpCode.Decompiler/IL/ILReader.cs:line 724
		//    at ICSharpCode.Decompiler.CSharp.CSharpDecompiler.DecompileBody(IMethod method, EntityDeclaration entityDecl, DecompileRun decompileRun, ITypeResolveContext decompilationContext, ExtensionInfo extensionInfo) in /_/ICSharpCode.Decompiler/CSharp/CSharpDecompiler.cs:line 2282
	}

	static AssemblyName _202C_202E_200C_206E_206C_202B_202A_200B_200E_202C_200D_206B_202A_206A_202C_206C_206D_200B_202C_202E_202B_200B_200C_202B_206D_202C_202E_206B_200C_202D_206F_202A_202A_206B_202E_202A_206A_202E_206A_200E_202E(Assembly P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	unsafe static string _202B_202A_206D_200E_200D_202D_206C_200D_202C_200E_206E_206D_200C_202B_206E_200B_202A_206D_200D_200D_202B_200C_200B_200B_206B_200D_200E_206D_202A_202A_202C_200C_200C_200E_200C_202C_206F_202B_202C_206F_202E(AssemblyName P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/];
		/*Error near IL_0003: Unknown opcode: 0xEE*/;
	}

	static bool _206B_202E_202B_200D_200C_206A_200E_200C_200B_206B_206A_206D_200B_206E_202B_206A_206B_206A_200B_202C_206E_200F_206F_206C_202C_206B_202C_202E_206B_206F_202D_206B_206E_206D_206B_206B_200E_200B_202A_200E_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	static CultureInfo _202A_206A_202E_206E_200D_206E_202A_206F_206B_202C_202B_200F_206D_200E_206D_200C_200E_200E_206B_200B_202B_202E_206A_206D_202C_200B_200B_202D_202E_200B_206B_202C_200F_200B_202B_202D_202B_206C_200B_202A_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x07 0x93
	}

	static void _202D_206B_206C_200E_206B_202A_200C_202B_200B_206A_202E_202E_202D_200E_202D_200D_202D_202D_200C_200C_200D_202E_202B_200C_202A_206F_200C_206A_206F_206A_200F_200B_202B_200D_206D_202E_206E_202D_206F_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
	{
		switch ((int)/*Error near IL_0002: Stack underflow*/)
		{
		default:
			/*Error: End of method reached without returning.*/;
		}
	}

	static int _206B_202A_200C_206A_202A_206D_202E_202D_200D_200D_206F_200E_206A_202C_202B_200F_200E_200E_202E_202C_202E_200F_202A_200C_202C_202E_200D_200D_200E_200C_202E_202A_206A_200F_206D_202B_200B_202A_200F_202C_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC1
	}

	static Assembly _206B_200F_202B_206F_200D_200F_206F_200C_202D_206A_202D_206D_200E_200C_206B_206E_200D_206E_202A_200B_200F_206C_206C_200C_202D_200D_202E_202D_206E_200E_206C_200D_202A_206C_200C_206C_200B_200F_200C_202A_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	static bool _200E_200E_206D_202A_200B_202E_200B_200D_200C_206A_206E_202A_200C_200D_202D_202B_206F_206E_202D_200B_202C_202B_206E_206A_200F_200D_206F_206B_202B_200F_200F_206C_200E_202E_202A_206E_202A_206A_200E_202A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static Stream _200F_202C_206A_206C_202E_206F_206F_200F_206C_202C_206B_200F_206F_202B_200C_202D_200C_200D_206C_206C_206E_200E_202A_202A_202B_200E_200E_200B_200B_206C_206E_206A_206C_202D_200F_206A_202A_206B_200F_206B_202E(Assembly P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD3 0x08
	}

	static DeflateStream _200B_200D_200E_200B_200C_206F_200E_206D_202B_200B_206F_200F_200E_206E_202C_206C_206F_206E_200D_206E_200B_200F_206B_206D_206A_206E_202E_202A_200C_200B_202E_202E_202A_202B_200E_202D_200C_206C_202B_200C_202E(Stream P_0, CompressionMode P_1)
	{
		/*Error: stloc 0 (out-of-bounds)*/;
		_ = -1;
		/*Error near IL_0002: Unknown opcode: 0xA9*/;
	}

	static MemoryStream _202C_200C_202A_200C_206D_202A_200C_202C_206C_206E_202C_200B_206D_202B_200E_202A_206B_202D_200B_206D_206C_200C_202B_202D_206A_200F_206C_200C_206D_200E_200E_206A_200B_200B_206C_206C_202C_206B_206E_200E_202E()
	{
		if (/*Error near IL_0001: Stack underflow*/ <= /*Error near IL_0001: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		if (!float.IsFinite(/*Error near IL_0002: Stack underflow*/))
		{
			throw new ArithmeticException();
		}
		checked
		{
			_ = (sbyte)/*Error near IL_0003: Stack underflow*/;
			/*Error: End of method reached without returning.*/;
		}
	}

	static void _200B_206B_206C_202C_202E_200C_206D_200D_202B_202A_202E_202A_202B_200F_206E_202C_206B_200E_202A_206F_200E_202D_202E_206C_202E_200E_200C_206A_206A_206A_200C_202A_200C_200F_206D_206A_200E_200F_206C_206B_202E(Stream P_0, long P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBB 0x28
	}

	static void _206E_202B_202A_206E_200D_202D_200E_202C_202B_200C_206E_206B_206C_202C_206B_202B_200B_200D_202C_206E_206A_206A_206F_200C_206A_200E_200F_202B_202A_202A_200B_202D_200B_206C_202D_202B_202D_206D_200C_202A_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	static long _202B_200F_206D_202A_200E_200C_202D_200D_206A_202C_200C_200C_206A_202B_206D_206B_206F_206A_200B_202C_206B_206F_206F_200D_200B_206B_202D_202B_202C_200F_206C_200E_200B_200D_200F_200B_200C_206F_202C_202A_202E(Stream P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9C
	}

	static string _206A_202E_200D_202E_206A_200B_206A_206C_200F_200D_206D_202B_202E_206C_202D_206A_200C_202D_200F_202A_200F_200E_206D_206C_202E_206D_206F_200B_200B_202C_202D_200D_202E_206F_200E_206E_200D_200F_206A_200F_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBD
	}

	static bool _200D_206F_206B_200F_206A_206E_206C_206D_206F_206C_202E_206B_200B_202E_206F_202A_202E_200E_202B_206F_202E_206C_202E_200B_200B_206C_202A_200D_202C_202E_200C_200B_200F_202C_206D_206A_200C_202C_202B_200E_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x07 0xCE
	}

	static string _202E_206B_200B_206F_206D_206A_200F_202C_206F_202A_206B_202B_202D_202E_206D_202D_206F_200F_206D_206E_202D_206C_206E_200B_206E_206C_206A_206F_206E_202D_206A_202C_206A_206D_200C_202C_200F_200B_202A_206A_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static Assembly _206A_202B_206D_206D_206E_206A_202C_202C_206A_206C_206F_206A_202E_206F_206C_206B_206D_206E_206C_206A_206C_200C_202C_200D_202C_202C_202A_200E_202B_200C_200F_202E_206D_200B_202A_200C_206A_202E_202A_206E_202E(byte[] P_0, byte[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDF 0x5E
	}

	static Assembly _206B_202A_200F_200E_206D_200C_206A_202B_202A_202C_200C_206C_206E_206C_202B_202A_206D_200F_200C_202D_206F_206F_200D_206D_206F_202D_206A_200D_202D_200B_202B_202C_202E_200D_206C_200F_206C_206F_202E_202E(byte[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB4
	}

	static void _200D_202E_200F_200C_202B_206A_202C_206D_200B_206E_206B_202B_206A_206B_206B_206F_202D_206D_206B_206F_202C_206A_200E_206D_202A_202A_200D_206D_206E_200D_200E_206F_200F_206B_200B_200D_200C_206A_200D_202C_202E(object P_0, ref bool P_1)
	{
		/*Error: Unknown opcode: 0xE1*/;
	}

	static string _206E_200B_200B_206B_206E_200D_200D_206E_200D_202B_202C_200F_202E_206C_206F_202A_206D_206A_200E_202B_200B_206D_200E_206D_206A_206E_200D_202A_202A_200B_202C_202B_202E_202E_206C_202A_206D_200D_206C_206B_202E(ResolveEventArgs P_0)
	{
		/*Error: Unknown opcode: 0xFD*/;
	}

	static void _200E_202A_206E_200E_206C_200B_202B_200B_202B_206F_202E_202E_202C_200E_202E_200F_200B_206F_200E_200F_200C_202B_200C_206C_206D_200F_202D_200E_200F_200F_202C_206D_200F_200C_202B_206A_206B_202B_202D_206A_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x01
	}

	static AssemblyName _200C_206A_202A_200D_206D_202D_206D_206F_202B_202A_202E_202C_202C_206C_206F_200C_200B_202E_202E_200B_200D_200F_200D_200E_202A_202E_206E_206B_200B_206B_202D_202D_206A_200C_202A_206F_206C_202A_206B_202D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD8
	}

	static AssemblyNameFlags _200D_200D_206C_202D_206D_206B_200F_202B_206F_200D_206E_202B_200B_206E_202E_206F_206B_206B_200E_202D_200C_206B_206A_202D_206D_200B_206D_206A_206A_206A_202C_206B_200C_202A_202D_200C_206B_202E_202C_202C_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x57 0xA1
	}

	static Assembly _206C_206B_200D_206D_206E_202E_200D_202D_200E_200E_206D_202D_200E_200C_200F_206E_206D_202E_202C_206E_202A_200C_202D_200B_202D_200B_206D_200D_200C_202E_200C_200F_206E_200B_200E_200B_206E_200D_206B_200F_202E(AssemblyName P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static object _200E_206A_202D_202D_206F_202A_202A_200C_206D_200B_202A_206E_200D_206B_206B_202B_206C_202A_206E_206C_202A_206E_206D_206D_202E_206C_206B_200C_202A_206E_202B_200D_200B_206B_206B_206B_202B_202E_206F_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	static int _200B_206B_200C_202C_202D_206D_202C_202B_206A_200E_206B_202D_206D_202D_202C_202C_206E_206F_206F_202D_206E_202E_200D_200D_206E_200F_202B_206C_202B_200F_202E_200B_200F_202A_206B_202D_200E_206E_202C_200D_202E(ref int P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x27 0x65
	}

	static void _206D_200D_206D_200B_202E_202B_200F_200E_200B_202E_206E_206C_206A_200F_206E_206D_206E_206A_200B_202E_200E_206C_206E_202B_200E_206B_206A_206F_206E_200F_200C_200E_200D_206A_206B_206E_202B_202B_206F_202E_202E(AppDomain P_0, ResolveEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1B 0xB9
	}
}
