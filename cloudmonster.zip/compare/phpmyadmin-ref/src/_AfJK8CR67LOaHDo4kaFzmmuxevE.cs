using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Markup;

[DebuggerNonUserCode]
[GeneratedCode("PresentationBuildTasks", "7.0.1.0")]
[EditorBrowsable(EditorBrowsableState.Never)]
public sealed class _AfJK8CR67LOaHDo4kaFzmmuxevE : InternalTypeHelper
{
	protected object _AHpLPH4l0DcsTRnvJFDnaJLkF0B(Type P_0, CultureInfo P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6D
	}

	protected object _kg0Wcb581PDpNGU6LYqUHXPCWQG(PropertyInfo P_0, object P_1, CultureInfo P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x85
	}

	protected void _C2y7PW7V7bxAbrCTGFmHLzmmig4(PropertyInfo P_0, object P_1, object P_2, CultureInfo P_3)
	{
		/*Error: Unknown opcode: 0xCC*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected Delegate _XQ5lLIJFwU3UWYg5g0Ngrs6vNki(Type P_0, object P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDF 0x22
	}

	protected void _IcomYaRox9ySdj8GJl64Qnj0Bk(EventInfo P_0, object P_1, Delegate P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEB 0x7A
	}

	public _AfJK8CR67LOaHDo4kaFzmmuxevE()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		_ = (sbyte)(/*Error near IL_0003: Stack underflow*/ ^ (/*Error near IL_0002: Stack underflow*/ >> (int)/*Error: ldloc 0 (out-of-bounds)*/));
		/*Error near IL_0004: Invalid metadata token*/;
	}

	static object _202E_202E_206A_200E_206F_202D_200D_206F_206C_200C_202B_200C_206D_206A_200E_200E_206E_200B_206A_202E_200D_200C_200B_200E_206E_206B_200C_206B_202C_202E_200C_202B_202B_202C_200F_200D_200C_200E_202C_202E(Type P_0, BindingFlags P_1, Binder P_2, object[] P_3, CultureInfo P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7C
	}

	static object _200F_202C_200D_202B_200C_202E_200F_200D_200C_200E_206A_200E_202C_206F_200B_202E_206D_206B_202A_200D_202E_206A_206C_200F_200C_206A_206E_202B_200C_206E_200B_200E_206A_206D_206A_202B_206C_206D_202E(PropertyInfo P_0, object P_1, BindingFlags P_2, Binder P_3, object[] P_4, CultureInfo P_5)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCC
	}

	static void _206C_202D_202D_206C_202D_206C_200F_206E_200E_206B_200D_200D_206B_200C_206E_202D_206B_202D_200D_206E_206F_206B_206F_200C_206A_206C_200E_200D_206A_202C_202D_206C_202A_206C_206F_202A_206E_200C_202E_206D_202E(PropertyInfo P_0, object P_1, object P_2, BindingFlags P_3, Binder P_4, object[] P_5, CultureInfo P_6)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		checked
		{
			_ = /*Error near IL_0006: Stack underflow*/- 1688166447;
			/*Error near IL_0006: Unknown opcode: 0xC0*/;
		}
	}

	static Type _200B_206C_206E_200B_200D_202E_202E_202B_206A_200D_202A_206C_206C_206D_200C_202B_206B_206D_206B_206F_206D_206D_206E_200B_202B_202E_206B_202D_202B_202B_206E_202B_202E_200F_202E_206E_202A_206F_200E_202D_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x98
	}

	static object _200C_202A_202D_200C_202D_202A_206E_206F_206B_200D_202D_202E_200C_202B_202E_206A_202D_206D_206C_206D_200B_206D_202E_206A_202E_202B_202A_200D_200F_202B_206A_202D_202E_200C_206F_206B_206E_206E_206F_200E_202E(Type P_0, string P_1, BindingFlags P_2, Binder P_3, object P_4, object[] P_5, CultureInfo P_6)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}

	static void _206E_200B_206A_202D_206B_200E_200B_206E_202B_200B_200B_206C_200F_200C_202E_202C_202C_200F_206A_206A_200B_200D_202E_206E_202C_202D_202A_206F_206A_206C_202D_206C_202D_206F_200D_202C_200C_206F_200B_200F_202E(EventInfo P_0, object P_1, Delegate P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA3 0xC4
	}
}
