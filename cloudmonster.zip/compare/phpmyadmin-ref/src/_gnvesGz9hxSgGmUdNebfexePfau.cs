using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

internal class _gnvesGz9hxSgGmUdNebfexePfau : INotifyPropertyChanged
{
	[CompilerGenerated]
	private PropertyChangedEventHandler _arY7kwXO7ug04fWaROU2eJhjkKx;

	public event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x31
		}
		[CompilerGenerated]
		remove
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA4
		}
	}

	protected virtual void _1Yzk6bRp8xHCvc5v3jeg0buSEQb([CallerMemberName] string P_0 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x14
	}

	public _gnvesGz9hxSgGmUdNebfexePfau()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static Delegate _200E_202A_206B_206F_206A_202E_206C_202B_206F_202A_206A_206B_202D_202B_200F_206E_202B_206B_200F_206F_202C_200B_206E_202D_206C_206E_202D_202B_200E_202E_202B_202A_202E_200C_202B_200D_206F_202A_200B_202E_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x51
	}

	static Delegate _206B_206A_202A_206D_202D_202E_202E_206D_206E_200B_200B_202E_200B_202C_202C_202E_202B_206D_200F_202B_200D_206C_200D_202A_202D_206B_202B_202A_202B_202C_200D_200F_206E_202D_206C_200B_206A_202B_200C_206B_202E(Delegate P_0, Delegate P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static PropertyChangedEventArgs _202E_206E_202B_200D_206C_202B_206B_202B_200F_206A_206C_202A_206C_206E_200C_202D_200F_206C_202A_206B_202D_206A_202D_200B_200F_202D_206C_206C_202A_206E_202E_200F_202B_202C_200B_202D_200F_200D_202E_200E_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}
}
