using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;

public class _T8BgTz8OsE1ElMZp7uxHu2CxJ0g
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _Vlw5psheKzOAhkEL52V33P6DVYB
	{
		public static readonly _Vlw5psheKzOAhkEL52V33P6DVYB _003C_003E9;

		public static Func<_bFiUbOYDxS9uF9HdSGLDw204NYX, string> _003C_003E9__28_0;

		public static Func<_YAAoKMgNXRuZegk2ZtB5gQy2igB, string> _003C_003E9__28_1;

		public static Func<_YDVX4GnM8Vx5TgkQGEYSupjeUiA, string> _003C_003E9__28_2;

		public static Func<_z090FNu6yQeKE0jrbAZw480qMBG, string> _003C_003E9__28_3;

		public static Func<_N8HN3DsxXrCBgkBJEcMaDNTubtp, string> _003C_003E9__28_4;

		public static Func<_Z3dLQl3mrsNYEs8MfwN56QwVL9E, string> _003C_003E9__28_5;

		public static Func<_iXTdsJyqcDrYkW2QBDcPAExE8dv, string> _003C_003E9__28_6;

		public static Func<byte, string> _003C_003E9__29_0;

		static _Vlw5psheKzOAhkEL52V33P6DVYB()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB3 0x02
		}

		public _Vlw5psheKzOAhkEL52V33P6DVYB()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _1dVweypuFVNYidQrZoLwAjRKEQl(_bFiUbOYDxS9uF9HdSGLDw204NYX P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _VKxrIuogoijuECEu6XnP6RjRDBf(_YAAoKMgNXRuZegk2ZtB5gQy2igB P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x95
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _M7VBybJEpVmRTZHaKSgA2tHmaC0A(_YDVX4GnM8Vx5TgkQGEYSupjeUiA P_0)
		{
			//Invalid MethodBodyBlock: Read out of bounds.
		}

		internal string _Zr2Rqxxz21W9SbUopRsd8vxhuvB(_z090FNu6yQeKE0jrbAZw480qMBG P_0)
		{
			checked
			{
				_ = (ulong)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Invalid calli metadata token*/;
			}
		}

		internal string _N6KdXbLy6wByLK7Cvzpik5QQ0It(_N8HN3DsxXrCBgkBJEcMaDNTubtp P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x57
		}

		internal string _MholSFUksoM6tgMzRaPFGKYr7OG(_Z3dLQl3mrsNYEs8MfwN56QwVL9E P_0)
		{
			_ = ((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
			/*Error near IL_0001: Unknown opcode: 0xE9*/;
		}

		internal string _RpqO12QOEIG8EORrDGMdW3hBibj(_iXTdsJyqcDrYkW2QBDcPAExE8dv P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x90
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal string _kU8DwMirOq1nwBGKEVhhMkzHsGM(byte P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x67 0x2E
		}

		internal _bFiUbOYDxS9uF9HdSGLDw204NYX[] _xBwLjkDShpaLcWkMvyEAxhD645D()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x59
		}

		internal _YAAoKMgNXRuZegk2ZtB5gQy2igB[] _m8qzGU2IwMG310UsKZsAecKg45e()
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x9ECA5684
		}

		internal _YDVX4GnM8Vx5TgkQGEYSupjeUiA[] _ul3H2hLbjP81OUqAOXlTgIhMJdT()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x89
		}

		internal _z090FNu6yQeKE0jrbAZw480qMBG[] _YdjQO2lVB6UnAH20Y7lyPpYFtgi()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE5
		}

		internal unsafe _N8HN3DsxXrCBgkBJEcMaDNTubtp[] _QF36aOShVFWaOQVQM9aBQiTamj6()
		{
			checked
			{
				_ = (byte)(*unchecked((float*)(nint)/*Error near IL_0001: Stack underflow*/));
				return (_N8HN3DsxXrCBgkBJEcMaDNTubtp[])/*OpCode not supported: Nop*/;
			}
		}

		internal _ZZGo2mEFd1PtkYprWFQAegl92Ve[] _rObkzeN3TO0GGqcesM7nYGub8zh()
		{
			nint num = checked((nint)/*Error near IL_0001: Stack underflow*/);
			/*OpCode not supported: DebugBreak*/;
			_ = num;
			_ = 8;
			return (_ZZGo2mEFd1PtkYprWFQAegl92Ve[])/*OpCode not supported: Nop*/;
		}

		internal _Z3dLQl3mrsNYEs8MfwN56QwVL9E[] _56WiYTni9n6fBrxRSRK9gycLHmd()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x72
		}

		internal _iXTdsJyqcDrYkW2QBDcPAExE8dv[] _TZD4jaSAYMCg9bATtNR5WQJAsjn()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x27 0x2A
		}

		internal string _E74f8LEM1KebaamjN4BgnOs2EMBA()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9C
		}

		static string _200F_202B_206B_206C_206E_202C_200D_206E_200C_202D_206E_206B_202C_200F_206C_200D_206A_206F_200E_200D_202E_200D_200C_200F_202B_200D_206B_206D_206B_206E_200D_200C_200B_206A_202B_202C_206D_202C_202C_206E_202E(string P_0, string P_1, string P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDC
		}

		static WindowsIdentity _206C_206B_206E_206A_202E_206C_202B_202C_200F_206D_200B_206F_200F_206F_206B_206B_200E_200C_200F_202C_202C_200B_206B_202C_202E_206A_202D_202C_206A_206D_206A_202D_200D_200F_202D_206B_200D_202B_202C_202B_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}

		static SecurityIdentifier _202A_206E_200C_200F_206E_206A_202C_202D_206B_202E_206F_200C_206E_202E_206D_202B_206C_200F_206D_200B_200C_200E_206D_202E_206C_206E_202A_202D_200F_200F_202D_206B_206D_202E_206C_202D_202A_200C_202A_202E_202E(WindowsIdentity P_0)
		{
			/*Error: Unknown opcode: 0xCD*/;
		}

		static string _202A_200E_202A_202C_206E_206A_202E_202A_206A_200C_200B_202E_202B_202E_200E_202A_206E_206F_200F_206E_202A_206D_206F_202D_206C_202B_202A_200F_200D_206C_206D_206E_202C_202E_200B_206B_200F_206F_206D_202E(IdentityReference P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x17 0x72
		}
	}

	[CompilerGenerated]
	private sealed class _uojFW9gNEB8mpkp8jv6fUFgd9fm
	{
		public int _nUJMf2l1NaySyf4dxws59xnmrpp;

		public _uojFW9gNEB8mpkp8jv6fUFgd9fm()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal string _wJLt9oNCVMfCTdMf5EgGltrUsqI(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAF 0xE4
		}

		static bool _202D_200E_202C_202E_206D_200D_202B_206B_202E_200E_202E_200B_206A_206F_202C_202D_206B_200E_206B_206A_200D_202E_206C_206E_200D_206F_200F_200D_202D_206E_200C_200C_206A_206F_202D_206E_200B_206B_206D_202D_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x07 0xCE
		}

		static string _206E_200F_200E_202D_202D_206A_206E_206B_206C_200D_206D_202B_200D_206B_206A_200F_200B_206D_202D_202A_200B_206B_206D_206A_200F_200E_202D_206B_206F_206B_200C_202A_202B_206A_202A_202A_202A_206E_200E_206E_202E(char P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x58
		}
	}

	private const string _LR7asYB6LljsCZdByiVe2dl2zoY = "-";

	private static readonly Lazy<_bFiUbOYDxS9uF9HdSGLDw204NYX[]> _KTBBjlvfLs4IKaWN4wkDx5dtXXl;

	private static readonly Lazy<_YAAoKMgNXRuZegk2ZtB5gQy2igB[]> _1IseHm1jgYGnfWFjBBdqq9kBYsd;

	private static readonly Lazy<_YDVX4GnM8Vx5TgkQGEYSupjeUiA[]> _1Lc8B4CamtnLzfxz3ZAPbYvlqUh;

	private static readonly Lazy<_z090FNu6yQeKE0jrbAZw480qMBG[]> _x3RBGHQ1xOTp1X4xJVwXBoza3wF;

	private static readonly Lazy<_N8HN3DsxXrCBgkBJEcMaDNTubtp[]> _zxVynMb3BJvIOO50v4mdYjNJglBA;

	private static readonly Lazy<_ZZGo2mEFd1PtkYprWFQAegl92Ve[]> _goRLb8AWjXjNMIv8LpJJKVX3CVf;

	private static readonly Lazy<_Z3dLQl3mrsNYEs8MfwN56QwVL9E[]> _WnLv66QqVButc9wcYHksbMoZyFg;

	private static readonly Lazy<_iXTdsJyqcDrYkW2QBDcPAExE8dv[]> _1z32UjVrb0OhdD3hdygoMoLyBkA;

	private static readonly Lazy<string> _adlrfDbHel1RM3czPYnuFByAnJE;

	public static _bFiUbOYDxS9uF9HdSGLDw204NYX[] _Ye88Jebm3rjJZL7duLAxAIkSxVF
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x55
		}
	}

	public static _YAAoKMgNXRuZegk2ZtB5gQy2igB[] _7FGclqTo1YIShPVjIZLWcQq3nFB
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0B 0x78
		}
	}

	public static _YDVX4GnM8Vx5TgkQGEYSupjeUiA[] _sW5XfUc18YSRYVuzykclofyTa2D
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}
	}

	public static _z090FNu6yQeKE0jrbAZw480qMBG[] _L1JLRjwMOayvq8HzBM0C2Ln5SDg
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}
	}

	public static _N8HN3DsxXrCBgkBJEcMaDNTubtp[] _B5G0V9qT7DrqHBnPYgnDQrmi23b
	{
		get
		{
			checked
			{
				_ = (int)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: ldarg 2 (out-of-bounds)*/;
				/*Error near IL_0002: Unknown opcode: 0xAF*/;
			}
		}
	}

	public static _ZZGo2mEFd1PtkYprWFQAegl92Ve[] _ZqJbC3BbQn6D8Tro2FO2r1gSnFh
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF5
		}
	}

	public static _Z3dLQl3mrsNYEs8MfwN56QwVL9E[] _MtmZkwRCn3bbPTc2A8VbRmRc1Zr
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x45
		}
	}

	public static _iXTdsJyqcDrYkW2QBDcPAExE8dv[] _nSjewjvcgEB9SCGmN8gE44mfaxZ
	{
		get
		{
			if (/*Error near IL_0005: Stack underflow*/ != /*Error near IL_0005: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0005: Unknown opcode: 0xF0*/;
		}
	}

	public static string _rrxCscpaFsIgBaw2bZdqsBvjWCDA
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB3 0xEB
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static string _azyugn0Q3IEvtZu6R5haUlgIHpo()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	private static string _KFZa2fYYFtV6jhMCqkm2j8YxVWu(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAD
	}

	public _T8BgTz8OsE1ElMZp7uxHu2CxJ0g()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static _T8BgTz8OsE1ElMZp7uxHu2CxJ0g()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9F 0xB2
	}

	static string _200D_202B_202B_202B_202E_200E_200E_202B_202A_200B_202D_200E_202C_206F_202B_206C_200E_202B_202D_200C_206B_206B_202C_206E_200E_206A_206B_206B_200D_206B_200D_202A_200C_202E_202B_202A_206D_200B_200C_202D_202E(string P_0, IEnumerable<string> P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	static string _206B_206F_206E_202B_206B_206C_206C_206D_206F_206E_206F_200B_202B_200F_206E_202E_206A_202E_202D_200C_206D_200C_202A_202D_206B_206A_206B_202E_206A_200F_202C_206F_200D_206E_206F_206C_202D_206D_200E_200E_202E(string P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	static string _200F_206B_206C_206E_202B_200C_206E_206A_200B_200E_200D_206B_206E_202B_200F_206D_202D_200D_206B_200B_202E_202B_200B_202C_200E_202B_200D_206E_200E_202B_200F_202C_200B_200F_200B_202C_202E_206B_202E_202B_202E(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	static Encoding _200D_202D_200F_206A_200E_202C_200F_206F_206F_206B_202C_206E_206B_206A_202B_206F_202A_202D_200F_200E_200E_206B_206E_200C_200C_206B_206D_202E_202C_200B_200C_206A_206B_206B_206A_206A_206C_200B_200F_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4D
	}

	static byte[] _200C_206C_202A_206A_200E_206C_202E_202D_200C_202D_200F_206E_200F_200E_200F_206F_206D_200B_206D_200F_202D_206D_202E_200F_206C_202A_202A_200B_202D_202C_200F_200D_200F_202B_200E_200E_200D_200C_206F_200C_202E(Encoding P_0, string P_1)
	{
		if (/*Error near IL_0002: Stack underflow*/ > /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0002: Unknown opcode: 0xF7*/;
	}

	static byte[] _202E_202B_200E_202C_206C_200F_202D_202E_206F_206A_202B_206C_206A_202A_200F_200F_206A_200C_202E_206F_202C_202B_200D_206D_206A_202D_206B_206D_200F_206F_206F_200D_202D_206F_200C_202D_200E_206D_200C_206E_202E(HashAlgorithm P_0, byte[] P_1)
	{
		_ = ((short[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
		_ = 7uL;
		/*Error near IL_0004: Unknown opcode: 0xA6*/;
	}
}
