using System.ComponentModel;

internal interface _6kowxIyI5s2v3oeCKgG6VfVftqH : INotifyPropertyChanged
{
	int Current { get; }

	bool IsEmpty { get; }

	int Count { get; }

	void _m6DAZ1ofdlOESdCeekTkQDtVNc4(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0);

	void _FjJJ9ndeYmontKzxcRaA7MzWXTd(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0);

	void _3bUY0p3zUFObETvZgyMcoYUmBTh(_G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0);

	void _gZt8iGTZTXOBzcLskqjIlwoAqsW(_G4HZl6xJwrcuDmIkPCZEv6KhSrN[] P_0);

	bool _b1ZRGWNavyIHO2DWwOmklrT0kCE(out _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_0);

	void _gnCc21dXnVllE4PFosTLplU4rHE();

	void _jzojlHFawgR2a37stEoWW9tukDJ();
}
