using System;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

internal class _6r331qX72SngFdxF5rE3fjNTQIi : _gnvesGz9hxSgGmUdNebfexePfau
{
	private class _2o75F5b4wtqKGZ3BeEjfeQre4Lr : JObject
	{
		public _2o75F5b4wtqKGZ3BeEjfeQre4Lr()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD8
		}

		private unsafe _2o75F5b4wtqKGZ3BeEjfeQre4Lr(JObject P_0)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0003: Not a type handle*/;
		}

		public void _IPzRWskwm1j5q12i6kIFfdsXqqG(Stream P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAF 0xA3
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		public static _2o75F5b4wtqKGZ3BeEjfeQre4Lr _g49jHHPO3XDbhdIT4bfaWRwuLyQ(Stream P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x55
		}

		static Encoding _206E_206F_200F_200D_200E_202D_200F_202C_200B_202C_202B_200D_200C_206A_206E_202A_200C_200C_200F_200D_202C_202B_200E_202E_206F_202C_206F_202C_206E_202B_206D_202E_206F_200F_206D_200F_202E_202B_200D_202E_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4D
		}

		static string _206F_200D_206C_202E_200F_206B_202E_206B_200E_206D_206F_200C_206D_202E_200E_200D_206D_202E_200D_206A_202A_200E_206B_200B_200B_206E_202C_206D_206D_200F_202C_200E_200F_202A_206B_206F_200F_202A_206F_206A_202E(JToken P_0, Formatting P_1, JsonConverter[] P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA0
		}

		static byte[] _202C_200F_202C_202E_202D_202D_202E_202C_206F_200E_200C_202C_206C_206F_200B_206D_206E_206F_202B_200E_202C_202D_200C_200F_206E_200C_200D_200E_206A_206A_206C_202B_202E_206A_202B_206F_200F_202B_206C_202D_202E(Encoding P_0, string P_1)
		{
			if (/*Error near IL_0002: Stack underflow*/ > /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0002: Unknown opcode: 0xF7*/;
		}

		static byte[] _200E_200C_200C_206D_206F_202C_202C_206F_206D_206A_206A_200C_202D_200F_206F_206F_200B_200E_202A_200F_202C_206B_202A_206D_200E_206C_206C_200B_206A_200D_206B_206C_206C_200D_200C_202E_202B_206E_200F_202A_202E(int P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x77 0xA7
		}

		static void _200B_200C_202A_206E_202C_200E_200D_200C_206C_206E_202C_206F_202D_202B_202B_206C_202E_206A_200F_200C_206C_202D_200E_202C_206C_206D_200C_206C_202E_200D_200E_202B_206A_202B_206C_200B_200D_206C_202B_200E_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
		{
			switch ((int)/*Error near IL_0002: Stack underflow*/)
			{
			default:
				/*Error: End of method reached without returning.*/;
			}
		}

		static int _200D_206F_202A_200B_202A_202C_206A_202A_202C_206D_206B_202E_202D_206C_206E_200D_202C_202A_200C_206B_202A_202B_202B_200D_202A_206E_202C_200E_200C_206F_202D_206E_202B_200F_202E_202E_200C_202E_202E_206E_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC1
		}

		static int _200C_202A_200D_202D_206A_200C_200C_200E_206E_200C_202D_206D_200B_200B_202C_206B_206E_206F_202A_200F_206F_206B_202B_206A_202C_206A_206F_202C_200E_200C_202E_200B_200C_200E_202C_200F_202D_206D_200E_206D_202E(byte[] P_0, int P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFB 0x2B
		}

		unsafe static Exception _200B_200F_206F_200B_202A_200D_206A_206B_206A_200B_200F_200C_200D_200F_200B_206D_206D_206E_206A_202D_206C_206B_206B_206E_200E_202A_202D_202E_206F_202E_206D_206B_206B_202B_200D_202E_202E_200F_206E_206E_202E(string P_0)
		{
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			checked
			{
				_ = (byte)/*Error near IL_0002: Stack underflow*/;
				/*Error near IL_0002: ldloc 57 (out-of-bounds)*/;
				/*Error near IL_0004: Unknown opcode: 0xC5*/;
			}
		}

		static string _200F_206D_206B_200C_202C_206B_200D_202B_206D_202A_206B_206F_202B_200D_202D_200C_202A_202B_200E_202D_206D_200F_202D_206A_206D_206E_206F_202B_200F_206D_206E_202B_202D_200D_206B_206E_200D_202D_202D_206C_202E(Encoding P_0, byte[] P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x59
		}

		static JObject _202C_200B_200C_202C_200B_202A_206A_206A_202E_200C_200E_206D_206F_200E_206A_200C_202B_206B_200E_202C_206E_202C_200E_202C_202B_200B_206C_200F_206F_200B_202B_202E_200D_202C_206F_202B_206A_206C_202E_202C_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC9
		}
	}

	[CompilerGenerated]
	private static class _4xxbxMZIsPYt0fZew4Rb2FQe8RF
	{
		public static RemoteCertificateValidationCallback _ubY4eAB5A7oeXmF6YDYFujyxOGM;
	}

	[CompilerGenerated]
	private sealed class _GLclj2gV8ZZJpM5TUIw1W0pBGnO
	{
		public string _v5TqMH7HONBZKcq5SwQefsvCXuc;

		public _GLclj2gV8ZZJpM5TUIw1W0pBGnO()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _eYpUU3WrJ1YgZ3t60ZC1GcRJhEh()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA0
		}

		static void _200E_206B_206E_202E_206D_202A_200F_202C_200B_200B_200E_206B_202E_202B_206A_206B_202E_206B_202A_200E_202B_206A_200F_200C_202B_202B_202A_206D_206B_206A_200D_202D_206A_200C_202A_206B_202B_200C_202B_206F_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}
	}

	private TcpClient _jIuLc3mfOVAUPdoc9yONYtQhvp2;

	private Stream _I5cD1efz944dNuhYqu543UCR0Fk;

	[CompilerGenerated]
	private bool _WX4xvICk8Grby8pFz1j2nGJJuY8;

	[CompilerGenerated]
	private object _vxcdcztfGHH9PXq4jZDf3dIrjSy;

	[CompilerGenerated]
	private Visibility _yAaceDv9AR2D01tHwVVQzXamR9j;

	protected bool IsAuthentificated
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1B 0xE1
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			((short[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] = (short)/*Error near IL_0001: Stack underflow*/;
			_ = (float)((short[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/];
			/*Error near IL_0003: Not a type handle*/;
		}
	}

	public object BusyAnimation
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x54
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}
	}

	public Visibility IsBusy
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x54
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}
	}

	protected _6r331qX72SngFdxF5rE3fjNTQIi()
	{
		/*Error: Invalid metadata token*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private void _sWn3v69sCvGspiIQPatA9ZRV9aI()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Expected I8, but got O
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		((long[])/*Error near IL_0005: Stack underflow*/)[checked(/*Error near IL_0003: Stack underflow*/ * unchecked((byte)(/*Error near IL_0001: Stack underflow*/ % /*Error near IL_0001: Stack underflow*/)))] = (long)this;
		if ((nuint)(nint)(/*Error near IL_0007: Stack underflow*/ + checked((nint)/*Error near IL_0006: Stack underflow*/)) > (nuint)8u)
		{
			/*Error: Invalid branch target*/;
		}
		_ = (uint)/*Error near IL_000f: Stack underflow*/;
		/*Error near IL_000f: Invalid branch target*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private unsafe _2o75F5b4wtqKGZ3BeEjfeQre4Lr _bCeAFZWGSaY9HBFuJzetX6lTpSX(string P_0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Expected I4, but got Unknown
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		*(sbyte*)(nint)/*Error near IL_0003: Stack underflow*/ = (sbyte)checked(/*Error near IL_0002: Stack underflow*/ - /*Error near IL_0002: Stack underflow*/);
		checked
		{
			if (/*Error near IL_0008: Stack underflow*/ == /*Error near IL_0006: Stack underflow*/- unchecked(/*Error near IL_0005: Stack underflow*/ + /*Error near IL_0004: Stack underflow*// /*Error near IL_0004: Stack underflow*/))
			{
				/*Error: Invalid branch target*/;
			}
			((int[])3)[-1] = 68;
			if (/*Error near IL_0012: Stack underflow*/ >= /*Error near IL_0012: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
		}
		if ((int)/*Error near IL_0017: Stack underflow*/ == 0)
		{
			/*Error: Invalid branch target*/;
		}
		_ = /*Error near IL_0018: Stack underflow*/% /*Error near IL_0018: Stack underflow*/;
		/*Error near IL_0018: stloc 3 (out-of-bounds)*/;
		/*Error near IL_0019: Not a type handle*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static bool _32y0X2nf67qUanBb1bDdCogrQui(object P_0, X509Certificate P_1, X509Chain P_2, SslPolicyErrors P_3)
	{
		return (byte)(int)/*OpCode not supported: Nop*/ != 0;
	}

	static bool _206D_202B_206E_206C_200E_202B_206F_202A_200B_202C_206E_200B_202B_202D_202C_202A_200C_200D_206B_206D_202E_206D_200C_200C_202E_200E_206A_206E_200B_202E_206B_202D_206C_206E_202D_206E_206C_206C_206D_202C_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	static TcpClient _200F_202B_206D_202A_206C_202A_200D_206E_200F_200C_206E_206A_202C_206F_200D_206E_206D_200F_202D_202C_202A_206E_206A_200C_200E_202C_206A_200D_206C_206F_202C_200D_206D_200D_200F_202B_206E_200D_206E_202A_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1B 0x91
	}

	static void _200F_206B_200C_200F_206C_200C_200F_206E_206F_202C_202B_202B_200C_202D_206E_206B_202D_200D_206C_202D_206E_200F_206F_202B_202C_202A_206C_206D_202A_202D_200E_200E_200E_200C_202D_206E_206B_202C_200F_206D_202E(TcpClient P_0, string P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x10
	}

	static NetworkStream _200E_200B_206D_206F_202E_206F_206A_206B_200D_200D_206C_200B_200F_202D_202C_206B_206D_202C_206B_200C_202B_200F_206E_206A_206F_206B_202B_206C_206B_206C_202A_206A_200B_206B_200C_202D_202D_202B_206A_202C_202E(TcpClient P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC5
	}

	static SslStream _206C_206A_202A_206A_200D_206A_200E_200C_206F_200C_202A_200E_202B_200E_206B_202B_206C_206F_202B_202C_202A_206D_206F_202C_202D_202B_202D_206A_200F_200F_206D_206D_206C_202B_206B_202D_200B_200E_206A_206F_202E(Stream P_0, bool P_1, RemoteCertificateValidationCallback P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x27 0x89
	}

	static void _200D_206A_206C_206C_202D_200C_206C_200F_202E_206D_206A_200D_200B_206D_206C_206A_202C_200F_200E_200C_206F_206E_206E_206A_206E_200F_200E_200C_202D_206E_202A_202B_206B_206E_206F_202C_206D_206B_202E_202C_202E(Stream P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x0F 0xDF
	}

	static void _202E_202A_206C_206E_200D_206D_206E_200F_202D_206F_206B_202B_200B_202C_206F_206C_200C_206B_206A_202C_200D_206D_200B_200E_202A_202C_206C_200F_202D_200F_200C_200C_200B_202E_206A_202B_200D_200B_206D_200D_202E(Stream P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}

	static void _200F_200E_200E_206B_202E_202A_202C_202A_206A_200F_200F_206C_206D_206A_200D_202D_206B_206C_200D_200D_202D_200B_200D_206F_202E_206E_202E_206A_206B_200E_202A_202D_200E_200F_200D_206E_202E_200C_200F_206C_202E(SslStream P_0, string P_1, X509CertificateCollection P_2, SslProtocols P_3, bool P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0x81
	}

	static MessageBoxResult _200E_206E_206C_206B_202C_200C_206E_206C_200C_200C_200F_206B_200E_206A_200C_206D_206D_200D_202C_200B_202A_200C_202A_206C_202B_206A_202E_206C_206B_200E_200F_206B_206D_200E_200C_206D_200C_200F_200F_206A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xAEEA4611
	}

	static void _206F_200D_206B_202B_200E_206D_202B_206D_206E_206B_206A_202E_200B_202D_202B_206A_202A_206D_202B_202A_206D_200B_202A_202C_202D_206A_202C_206A_206E_206F_202C_200D_202E_200E_200D_202A_206E_202A_206D_202B_202E(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static bool _206B_206D_200F_206B_206F_200C_206E_206F_202C_200C_200F_200C_206B_200E_206D_200B_202A_202D_202B_206A_202C_206B_202C_202B_202E_206A_200D_206B_200B_202D_200C_202A_200C_206D_206C_206E_200F_206D_206F_202D_202E(string P_0, string P_1)
	{
		/*Error: Empty body found. Decompiled assembly might be a reference assembly.*/;
	}

	static void _206C_206E_206F_202C_206E_202C_202C_200C_206D_206A_206A_200D_200E_206A_206C_206D_202D_202E_202A_200E_202D_206C_202D_202B_200F_206D_206D_206B_200F_202E_200C_202C_202A_200E_200B_202E_206F_202E_206C_206D_202E(Action P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x99
	}

	static MessageBoxResult _202E_206C_200E_200E_200D_200B_200B_202C_206E_206F_202A_200D_202A_200C_206B_206F_206F_206E_202D_200F_202A_206D_206A_206B_202B_202B_206B_200E_206B_206D_202E_206F_206E_206F_206C_206F_200F_206B_202E_206E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x25
	}

	static MessageBoxResult _200F_206B_200E_200E_206D_206B_202E_206E_202D_206A_206A_206A_206F_200C_206B_200D_200F_200B_206E_200B_206D_206A_200E_200D_200E_202C_200E_200E_206C_202B_202E_200B_202B_200C_206D_200E_202E_202D_202C_206F_202E(string P_0, string P_1)
	{
		checked
		{
			_ = (nuint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xEC*/;
		}
	}

	static string _206E_206B_202A_202A_202B_206E_200C_202A_200C_202D_202D_202D_200C_202C_202A_206C_200B_206E_200D_200D_206D_200F_206B_206B_200C_206E_200F_206F_202A_200F_202B_200C_206F_200C_200E_200C_202A_200B_202A_206B_202E(string P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x34
	}

	unsafe static Exception _200C_206C_206E_202A_200B_200E_202C_206A_200F_200B_206B_202C_202A_206F_202B_200B_206A_206D_202D_202B_200B_206A_202A_206C_202E_200C_206A_206E_200D_206C_200F_206A_206E_200B_202D_200B_200D_202A_206A_200C_202E(string P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		checked
		{
			_ = (byte)/*Error near IL_0002: Stack underflow*/;
			/*Error near IL_0002: ldloc 57 (out-of-bounds)*/;
			/*Error near IL_0004: Unknown opcode: 0xC5*/;
		}
	}

	static string _202E_200C_202C_206F_200D_206D_206F_202D_206C_200C_202C_206D_200C_206F_206A_202C_202D_202D_206F_200D_206E_202E_206F_202C_200F_200D_206A_200D_200C_206E_200B_200B_206D_206A_200E_206D_202E_206F_200D_202C_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static string _200F_206A_206D_200D_206F_202B_206E_202B_200F_206C_200C_206D_202E_200B_202A_206C_200B_202A_206A_206C_200F_206F_200E_206F_206F_206D_206E_202B_206D_200E_200B_200E_206B_206E_202B_200B_206C_202E_200F_200F_202E(string P_0, string P_1)
	{
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
		/*Error near IL_0002: Unknown opcode: 0xB1*/;
	}

	static void _206A_202A_200E_202B_206D_202C_202C_202C_202B_206F_202C_206E_202B_202E_202B_206F_200B_202B_202A_202E_202E_206C_202E_200D_202A_202A_202B_206B_206B_200C_206A_202D_200B_200C_202D_200F_200F_202D_206F_206B_202E(TcpClient P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xD4
	}

	static Assembly _206E_206C_206F_200F_202A_206D_200E_202D_202B_206E_202E_200B_200E_206A_206A_202D_200E_200B_200C_206E_202B_206A_200E_202A_206C_200B_206A_202A_206F_206D_206B_202C_202E_202B_206A_202E_200B_202C_200E_200C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	static AssemblyName _206A_200F_202D_200D_202A_206A_200B_206B_206C_200B_202C_202A_200C_200D_202A_202C_200C_206B_200D_200D_200F_200D_200C_206B_200E_206B_200E_206C_200E_206D_202B_200B_200C_200B_200F_200D_206D_206B_206B_200D_202E(Assembly P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	static JToken _206D_202A_200B_200F_200F_200D_202C_202E_200D_206D_202D_206E_200D_202E_200F_206B_202D_202D_200D_206C_202B_200F_206E_202D_202E_200E_202B_206E_206A_200E_202B_200E_202A_200F_206D_202E_200D_202D_206F_202B_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2C
	}

	static void _202E_200F_206B_206D_200D_200B_202E_206F_202A_206E_206E_202C_206B_202C_206C_200E_200D_202C_202B_202E_202E_206C_202C_200D_206A_206A_206A_202D_206F_206F_202B_206D_206A_202B_206E_200F_202B_200B_206B_202C_202E(JObject P_0, string P_1, JToken P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x88
	}

	unsafe static string _200E_202C_206A_206B_206B_202E_200C_206C_206C_202E_200D_202D_200F_202E_200E_200D_206B_206F_206D_206C_200C_200E_202C_200E_202A_200E_200C_200B_202E_206B_206A_206D_202C_200B_202B_202B_200F_202E_206C_202D_202E(AssemblyName P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/];
		/*Error near IL_0003: Unknown opcode: 0xEE*/;
	}

	static Version _206C_206F_202A_206D_206B_206A_200E_202A_206E_206D_200E_200B_206D_206D_200D_202C_206B_202D_206D_206B_202B_202E_206F_206F_202A_206F_206F_200D_202D_200E_200C_200D_202C_202B_202D_206A_206B_200F_206F_202C_202E(AssemblyName P_0)
	{
		_ = 5;
		_ = (byte)15;
		/*Error near IL_0008: Unknown opcode: 0xCE*/;
	}

	static string _200C_200E_206C_202A_200C_206E_206C_200C_206F_200B_206F_202B_200E_206C_206D_206E_206C_202A_202D_202E_206B_202D_202C_202D_200F_206C_206C_206E_202C_200B_202B_206F_200D_200E_206E_200C_202D_200D_206F_206F_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static string _202C_202B_206C_206D_202D_200E_206B_202E_206C_202E_206F_202B_206B_200D_202D_202A_202E_200D_202A_202A_206E_200E_202E_202A_200B_202A_206D_200C_202B_200C_206C_206A_206F_206F_202B_200C_202B_206E_206A_206A_202E(X509Certificate P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}

	static int _200E_206C_200F_202A_202C_206B_200B_206E_200C_206A_200C_206F_206D_206B_200E_200D_200B_206E_206B_202C_206E_200F_206E_202B_200E_202C_202B_200C_200C_200B_202B_200B_200E_206D_200B_202B_202B_200E_200C_206A_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA3 0x6B
	}
}
