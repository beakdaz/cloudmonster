using System;
using System.Runtime.CompilerServices;

[_BKfEUcZIydeBwwO8KOWimhgjJLI("Win32_DiskDrive")]
public sealed class _bFiUbOYDxS9uF9HdSGLDw204NYX : _e1PcTRRi61sXbDSTAuhfJq08hE0
{
	[CompilerGenerated]
	private string _2BiPiSFTMBS9wDqohxXLtXfHZ1c;

	[CompilerGenerated]
	private string _HijGTDlOQiAvsHqaGS6tATpqD6j;

	[CompilerGenerated]
	private string _KsyTg1v5pMxw10gnTNV1V87uOUE;

	[CompilerGenerated]
	private string _IR4UikgDdp8PuDPgCYLoVBhsdaV;

	[CompilerGenerated]
	private string _OFud9t3DCxPWieCntj9fdHrIJol;

	[CompilerGenerated]
	private string _tIzOxqAveP3uc4ROcd6D3llDGiD;

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("PNPDeviceID", _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true)]
	public string _XQyaOXQZ5TUuzxjNDpcGpdH1d1v
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC0
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x54
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Model", _tFy3PAFwXh22Af9Rd6EaVyvRwuA = true, _z9iGSNwAHN9WJNl40wnjovc9b6g = true)]
	public unsafe string _3RkdMt0F4tkVgRu6tUerms2J0Zc
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x38
		}
		[CompilerGenerated]
		set
		{
			_ = *(IntPtr*)(nint)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xA6*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Description")]
	public string _JmDR8PuI3WhdzgUwT6qV1rseQZd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB3 0x12
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x93 0x7B
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("Manufacturer")]
	public unsafe string _2LGcfWg9irJpfYK5B4taNm2rHsG
	{
		[CompilerGenerated]
		get
		{
			_ = *(long*)(nint)/*Error near IL_0001: Stack underflow*/;
			return (string)/*OpCode not supported: Nop*/;
		}
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5B 0xAE
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("InterfaceType")]
	public string _rrwJFAlt9V1MU9fH8rGhPfWqudE
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB9
		}
		[CompilerGenerated]
		set
		{
			/*Error near IL_0001: Read out of bounds.*/;
		}
	}

	[_2TZHKOVBqCRTojsrTXGYzWqT05c("SerialNumber")]
	public string _ozceJCod4VTkGRUZ6esDi7DJ2jjA
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD1
		}
		[CompilerGenerated]
		set
		{
			_ = 6;
			/*Error near IL_0001: Unknown opcode: 0xC4*/;
		}
	}

	protected override bool _7XSaEtGveaNphRXPJp1DwZ53W8u
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x60
		}
	}

	private _bFiUbOYDxS9uF9HdSGLDw204NYX()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCD
	}

	static bool _206A_206E_206E_202B_202B_200D_202B_206A_202B_206C_206A_202A_206D_200D_206F_206B_200F_206C_202B_206B_202E_202A_202E_200B_206F_202C_200B_206A_202A_206C_200F_200C_202E_202C_206D_202E_206A_200C_202E_202A_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA8
	}
}
