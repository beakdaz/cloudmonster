using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Input;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Definitions.Series;
using LiveCharts.Wpf;
using Microsoft.Win32;
using xNet;

internal abstract class _TYt5UiueQJPld0Vj3scfuVKB51s : _TYt5UiueQJPld0Vj3scfuVKB51s<_HGlz1vBAP3ZbPHwPjEO1RgBwQdt>
{
	protected _TYt5UiueQJPld0Vj3scfuVKB51s()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF1
	}
}
internal abstract class _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> : _6r331qX72SngFdxF5rE3fjNTQIi where _0001 : _rK4z9b9leVLLJQwFvCMNZmVAKFM, new()
{
	public enum _6jR3LzK3cpBaUvSBgX6pnlYKDMG
	{
		Idle,
		Working,
		Stopping
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _mU91z2DMPY4ZgYhMLr1zK22ToqF
	{
		public static readonly _mU91z2DMPY4ZgYhMLr1zK22ToqF _003C_003E9;

		public static Action<Thread> _003C_003E9__111_1;

		static _mU91z2DMPY4ZgYhMLr1zK22ToqF()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x48
		}

		public _mU91z2DMPY4ZgYhMLr1zK22ToqF()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _2tMoZ6mn6yG806LrPzQ5M3xCDTB(Thread P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4B 0xA0
		}

		static void _200B_206F_200B_200F_200C_202B_206D_202E_202B_206E_206B_200C_200B_202E_206F_200C_202E_200B_200B_206C_200F_200E_202E_200D_200D_206E_200E_202D_200E_206E_206D_202A_202A_200C_202D_206A_200B_206A_202D_200F_202E(Thread P_0)
		{
			//IL_0000: Unsupported input type for neg.
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			_ = 0 - /*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xAB*/;
		}
	}

	[CompilerGenerated]
	private sealed class _icklY21vi4sW2skAhoZbKCLjQxo
	{
		public List<_0001> _6cRACqJww1WtEG2hFt4A4iAyKzCA;

		public StreamReader _ToDhinFGSEzdWwvcgBgeKQINc09;

		public _icklY21vi4sW2skAhoZbKCLjQxo()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _iPdVSGZ89NIRU4VCj5oaSdittzb()
		{
			if ((int)/*Error near IL_0002: Stack underflow*/ != 0)
			{
				((int[])/*Error near IL_0003: Stack underflow*/)[/*Error near IL_0003: Stack underflow*/] = (int)/*Error near IL_0003: Stack underflow*/;
				/*Error near IL_0003: Invalid metadata token*/;
			}
			/*Error near IL_001a: Read out of bounds.*/;
		}

		static string _200E_200C_202D_202A_206A_206D_202E_202E_202E_206C_202B_200B_200B_206E_200D_200B_202E_200B_202C_202A_206D_202A_200B_202C_202D_206B_200E_206F_202D_200B_202C_200F_206A_200B_202A_202A_200F_202D_200D_206A_202E(TextReader P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDD
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _XPm8O4SFcJHoRsuqWBgwBL3l3Xh : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			checked
			{
				_ = (nint)/*Error near IL_0001: Stack underflow*/;
				/*Error near IL_0001: Unknown opcode: 0xB0*/;
			}
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			/*Error near IL_0001: Not a type handle*/;
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static OpenFileDialog _202B_202E_206F_200C_206F_200D_200D_202A_206F_206F_200B_202B_200D_200F_206F_200D_202A_202D_206C_202C_206C_200F_206D_206C_206D_202B_202C_200F_206D_206A_200E_202C_202C_200E_202A_206E_206E_200B_200E_202B_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x02
		}

		static void _206D_206F_206F_206D_202B_206C_206A_206F_206C_200E_206B_200D_206A_200F_200B_202A_206F_206E_202C_200C_200F_202B_202B_200E_206D_202D_206E_200D_202B_200C_206B_206B_206B_200D_206D_200E_200F_206F_202D_206E_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC3 0xEB
		}

		static void _206D_206E_202B_202E_206E_202C_202E_202C_206C_200B_202C_202A_202E_202A_200F_200C_202E_202B_202D_202C_202A_206E_200B_206B_202B_200B_200F_202C_200C_206C_200E_200F_206A_206C_200C_206D_206B_200B_202D_200F_202E(OpenFileDialog P_0, bool P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}

		static void _206A_206D_200D_200C_206F_206F_202B_200D_200B_206E_202B_206F_206A_206A_200C_200D_206E_202B_206E_200E_200C_200D_206D_200E_200C_202D_202D_200D_202B_200D_202E_200D_202D_206B_206D_202E_206E_200D_202D_206F_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0D
		}

		unsafe static bool? _206A_202B_206F_200B_206F_200C_206A_200D_202B_206B_200B_206B_206B_206D_206C_206D_206E_202A_202E_206F_202A_200C_206A_202D_200B_206A_206C_206D_200D_200F_206F_202B_206C_202E_200B_200D_200B_202B_206F_200D_202E(CommonDialog P_0)
		{
			//IL_0008: Expected native int or pointer, but got F4
			double num = ((double[])/*Error near IL_0002: Stack underflow*/)[(nint)((Array)/*Error near IL_0001: Stack underflow*/).LongLength];
			*(_003F*)null = /*Error near IL_0007: ldloc 1 (out-of-bounds)*/;
			_ = ((sbyte[])/*Error near IL_000a: Stack underflow*/)[num];
			/*Error near IL_000a: Unknown opcode: 0xA9*/;
		}

		static string[] _200F_200D_200D_206B_206A_206C_202E_202E_202C_206C_206F_202E_200F_206E_200B_206E_202D_200B_206E_206F_202A_202B_206A_202B_206E_202A_200B_206F_202D_200F_200B_206B_206A_206C_202D_206A_206D_202A_200F_206E_202E(FileDialog P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x41
		}

		static TaskAwaiter _200D_206F_202B_200B_202A_200B_200F_206B_206F_206E_200B_200D_206E_200C_202B_206C_206C_200F_206B_206C_206A_202B_202A_200D_206B_202B_206C_200C_202B_206B_206C_200F_202A_206C_206C_206C_206E_200C_200D_200D_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _Qg0dgvRCr6W2jPNHDdF1lPCfIQL : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		public IEnumerable<string> _A09g2v92abaXoPFjVD2dbqfXerp;

		private _icklY21vi4sW2skAhoZbKCLjQxo _UsuLem83vLyu2TtSUOnDVcs6EDb;

		private IEnumerator<string> _uKpYifnB0xEYESgIi8iaIQ27xL5;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x6D
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			checked
			{
				_ = (ushort)/*Error near IL_0002: Stack underflow*/;
			}
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static MessageBoxResult _200C_202A_200F_206B_200F_206C_202E_202D_202D_200F_206F_206D_202C_200D_202C_200F_206C_200D_206E_206D_200B_200B_206A_206A_202B_206C_200B_202E_200B_206D_200F_206A_206C_206A_206C_200F_206B_206C_200C_200E_202E(string P_0, string P_1, MessageBoxButton P_2, MessageBoxImage P_3, MessageBoxResult P_4)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6C
		}

		static string _206E_200F_200E_200D_200D_206C_202B_202D_202E_206D_206B_206E_200C_206D_202A_200D_206C_202D_200C_202B_206C_206F_200E_202B_202B_206D_202C_206E_206B_200B_206B_206C_200B_200F_206A_200C_206B_202B_206E_202E(string P_0, object P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}

		static string _206C_202C_200F_206A_206E_206C_206A_206B_200E_202B_200F_202E_206C_202C_200C_202A_202A_206C_200F_200E_202E_202E_206F_202E_206B_206A_202E_200D_202B_202C_202B_206D_202B_206B_202C_206D_200E_200E_206D_200E_202E(string P_0)
		{
			switch ((int)/*Error near IL_001c: Stack underflow*/)
			{
			default:
				/*Error: End of method reached without returning.*/;
			case 0:
				/*Error: Invalid branch target*/;
			case 1:
				/*Error: Invalid branch target*/;
			case 2:
				/*Error: Invalid branch target*/;
			case 3:
				/*Error: Invalid branch target*/;
			case 4:
				/*Error: Invalid branch target*/;
			}
		}

		unsafe static Cursor _200F_202D_206E_202C_206C_200B_200E_202C_206B_200C_206A_206A_200C_202E_200D_202B_200D_202A_202B_202A_202C_200F_202C_202C_206D_200D_206E_202B_202B_200C_200B_206E_206D_202E_202D_206C_206E_202E_200F_206F_202E()
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0003: Stack underflow*/+ *unchecked((int*)(nint)/*Error near IL_0001: Stack underflow*/);
				/*Error near IL_0003: Invalid metadata token*/;
			}
		}

		static void _206C_206B_200D_206D_200C_206B_200B_202B_206F_206E_200F_200E_200C_206D_200F_202A_200B_200F_200D_202B_206B_200B_206F_200B_202E_200C_200B_202C_206C_202A_200C_200C_202C_206F_202C_206A_206F_200B_202C_202D_202E(Cursor P_0)
		{
			_ = checked((long)/*Error near IL_0001: Stack underflow*/) + 6;
			/*Error near IL_0003: Unknown opcode: 0xFD*/;
		}

		static StreamReader _200F_202E_200B_200D_206F_202C_206B_202E_202A_200B_206D_202A_206B_202E_206D_202B_200C_206A_202B_200B_206D_206C_200B_206D_202E_206B_202B_206F_206F_202B_200E_202B_202E_206F_200B_202B_202C_206A_206B_206B_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		static Task _202E_202D_200E_200F_202B_200F_202E_202E_200C_206E_200E_206E_202B_200D_206B_202C_200C_206F_202B_200E_200E_206C_206B_206C_200E_202B_200E_200C_202A_200D_202E_200E_200E_202A_206F_200C_200B_202A_206E_200D_202E(Action P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0xFD
		}

		static TaskAwaiter _206E_200C_206F_202C_200E_206D_206B_202A_200E_206B_200D_200F_202B_200F_200F_200E_202D_206D_206B_206F_202D_200E_206A_206F_200F_206E_206A_206D_206F_200E_206B_200C_200B_206A_202B_206F_206A_200B_202A_202E_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}

		static void _206E_206D_202A_206A_200F_206B_202D_206D_200F_202A_206C_202E_206B_206A_206D_200D_202A_200B_200E_202A_202A_202A_200D_202D_202C_206A_202B_206C_202E_202D_200D_200C_206A_202E_202C_200B_206E_206B_206B_202B_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static bool _202B_202D_206C_202E_202C_206E_200C_202E_202A_202D_202B_206A_200C_206C_206B_206D_200F_206A_206B_202A_206D_202B_200B_200D_202C_202C_202E_202A_206D_206A_200F_202A_206A_200C_200C_202D_200E_206E_202B_202E_202E(IEnumerator P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _VkWUg3CsqJrCWUjwIrnnlyhOlNc : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC7 0xEF
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static OpenFileDialog _202A_206D_200E_202C_200D_200E_202E_202B_202E_202B_206F_200B_200E_202A_200C_206F_202A_200F_206E_206D_200B_206F_206E_206D_202B_200E_202D_200C_200E_200C_200E_206F_206F_206C_206C_202D_202C_200C_206E_206E_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x02
		}

		static void _206E_200B_206B_206B_202A_206A_206D_206A_200C_202E_206E_200D_200F_202A_200C_206F_206B_202C_200F_200F_200E_200C_206C_200D_206F_206E_200D_202E_206E_200B_200C_202E_202A_206B_200B_202B_202B_202E_200B_206A_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC3 0xEB
		}

		static void _200F_206C_200C_206A_206D_200F_206E_200F_200F_202D_200B_200C_200C_200B_206A_206E_200E_200C_200C_202A_206F_200D_202B_206A_200D_206E_206D_206B_200B_200B_202A_202D_202D_206D_202C_202D_202B_206F_206D_202A_202E(OpenFileDialog P_0, bool P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x61
		}

		static void _202B_206A_202C_206B_206C_200E_206D_200C_202A_202A_206E_200E_202E_206C_206D_206E_202B_206F_202C_200B_206C_206A_200F_206A_206A_206A_206A_200B_206E_202E_206C_206D_200E_200D_202B_206F_200B_206B_200C_206D_202E(FileDialog P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x0D
		}

		unsafe static bool? _202E_206E_206F_206B_200E_206E_200E_202D_206B_206A_202D_206C_202C_206B_200F_200D_206C_206A_206E_206B_200B_202A_206D_202B_200E_206B_202C_206B_200D_206F_200F_206B_206B_202B_202B_202B_206B_200E_206C_206F_202E(CommonDialog P_0)
		{
			//IL_0008: Expected native int or pointer, but got F4
			double num = ((double[])/*Error near IL_0002: Stack underflow*/)[(nint)((Array)/*Error near IL_0001: Stack underflow*/).LongLength];
			*(_003F*)null = /*Error near IL_0007: ldloc 1 (out-of-bounds)*/;
			_ = ((sbyte[])/*Error near IL_000a: Stack underflow*/)[num];
			/*Error near IL_000a: Unknown opcode: 0xA9*/;
		}

		static string[] _202D_200E_206F_200F_202B_206F_200D_202A_206F_202E_202C_206E_202E_202D_206A_202B_200C_206F_206C_200F_200D_206E_202C_202B_206D_206A_200B_206C_206F_206D_206F_206A_202E_206E_202B_202D_200C_200E_200B_200E_202E(FileDialog P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x41
		}

		static TaskAwaiter _206C_206D_206C_200F_200C_202B_202B_206D_202B_200F_202A_202E_202D_200D_206A_206A_206F_206D_200D_202E_206C_202C_202B_206B_202E_200B_202D_206C_202B_200D_202C_200C_200D_202D_200D_206A_202A_206E_206E_206C_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _0XB84jjQ8G92e2g9ehzszaM8TMi : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public IEnumerable<string> _A09g2v92abaXoPFjVD2dbqfXerp;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private List<_G4HZl6xJwrcuDmIkPCZEv6KhSrN> _xhWleN0k5fS92Qf6ZnKFacoCUVJ;

		private string[] _kS6x37UbCQaMzCWadfcp6RzDo6eb;

		private int _y1LNZDL1uzdBaYlEzWqHm2Tzwm6;

		private StreamReader _O1s0hQnawM1mqGCDcfMODddgLEU;

		private TaskAwaiter<string> _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			_ = 870101241;
			/*Error near IL_0005: Unknown opcode: 0xC0*/;
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static StreamReader _200C_202A_202B_202B_200B_200F_202A_202B_202B_202B_206B_206E_200E_202D_206A_202C_202E_200B_206F_200D_202A_202A_202A_206D_202B_206C_206F_202C_202D_200D_200C_200D_200C_206F_202A_200C_206A_200F_202E_202E_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		static Task<string> _206F_206B_200D_200B_202E_200C_206E_206C_206F_206F_200B_200C_206F_206A_200E_202A_202A_200D_206D_200F_206B_202D_202B_200B_202E_200D_206D_202A_206F_200B_202E_202E_206D_206E_202B_206E_200C_200D_202D_202C_202E(TextReader P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}

		static void _202B_202E_206B_202A_202E_202E_200D_206D_202B_200F_206A_206A_206A_200D_206A_200E_206F_202A_202D_200B_200D_206F_206A_206E_200D_200F_202E_206F_206E_202E_206C_206A_206A_202D_200F_200B_202A_202E_200C_200E_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static bool _200B_206A_200D_200F_202E_206B_202A_202E_206F_202D_202B_200D_202E_202E_200C_206E_206E_200C_200B_200B_206C_200C_206E_202A_206D_206E_206D_206A_202E_206E_200C_200C_202E_206C_200E_200F_206E_206C_202C_202B_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x1D
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _q9c1CkD25dViDRcrfydyxHabcmH : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public IEnumerable<string> _A09g2v92abaXoPFjVD2dbqfXerp;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private List<string> _0KJFm7oAMbDk7S0qwB1E8TSvAyT;

		private List<string> _veNURliH5P5Jo8fCoUiB44WRCvI;

		private IEnumerator<string> _y1LNZDL1uzdBaYlEzWqHm2Tzwm6;

		private string _50Xji51SaSjjEBEZ6nprXQji64b;

		private StreamReader _JFxKjzUBwN4TYfmcLmQJvcQTfacA;

		private TaskAwaiter<string> _teSyrDiveRJ3xlAJarvFgQdzSFo;

		private TaskAwaiter _yJd6bQCyGWnWbEnF9S98nza3ciC;

		private void MoveNext()
		{
			if (!float.IsFinite(checked((ulong)/*Error near IL_0001: Stack underflow*/)))
			{
				throw new ArithmeticException();
			}
			/*Error near IL_0002: Unknown opcode: 0xFE38*/;
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private unsafe void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			if (/*Error near IL_000d: Stack underflow*/ >= checked(/*Error near IL_000b: Stack underflow*/ + (ushort)(-5.3690572936511076E+172)))
			{
				/*Error: Invalid branch target*/;
			}
			if (/*Error near IL_0013: Stack underflow*/ <= /*Error near IL_000e: Stack underflow*/>> (int)/*Error near IL_000e: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			*(_003F*)(nint)/*Error near IL_0015: Stack underflow*/ = /*Error near IL_0015: Stack underflow*/;
			if (/*Error near IL_0017: Stack underflow*/ != /*Error near IL_0017: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0017: Unknown opcode: 0xE7*/;
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static StreamReader _200D_200C_206E_200F_202D_200D_200E_202B_206D_200F_206E_206D_200C_202E_206D_206D_200E_206C_202C_200E_202D_200C_206F_202D_206B_200D_200C_206E_200C_202D_200E_206F_202B_200E_200C_206E_200D_206B_202D_202B_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x11
		}

		static Task<string> _202A_200F_202D_202D_202C_202A_200C_202A_200E_206A_206E_202A_200D_202C_202C_202A_206D_206E_206D_206C_202A_202A_202E_206C_202B_200D_206C_202D_202B_202E_206E_202E_206F_202C_202D_200B_202C_200E_206A_206F_202E(TextReader P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xBD
		}

		static bool _206A_202A_202E_202C_200C_200C_200F_200E_200E_202C_200D_206A_202E_200C_206A_206F_206C_200D_200D_202D_202A_200D_202D_200F_200B_202D_202E_200B_206C_200D_206C_200C_206D_200E_200D_200E_200E_206C_200F_202D_202E(string P_0)
		{
			/*Error: Invalid field token*/;
		}

		static bool _202C_202D_200D_206D_202D_200F_202D_200D_202A_206C_202E_200B_200D_206D_200E_206A_202B_200F_200B_200B_202C_202E_200F_206D_202E_206D_202B_202C_206E_200D_202C_200F_206B_200C_206D_206D_202C_202C_202A_206E_202E(StreamReader P_0)
		{
			if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0002: Metadata token must be either a methoddef, memberref or methodspec*/;
		}

		static void _200B_200E_202A_206E_202A_202C_202B_200E_200D_202C_200E_206C_202B_202D_202E_206A_200B_200F_206A_206E_206A_202E_200F_200E_200E_202E_200B_200E_206D_200B_202E_202E_202B_206D_206A_202E_202C_202C_202A_202C_202E(IDisposable P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
		}

		static bool _200D_206E_202A_200D_202D_202B_200C_206D_202D_200B_200F_206C_206F_206C_206E_206E_202A_200E_202C_206C_206C_202E_202E_202B_200F_206E_206F_202E_202B_200B_206C_202D_206A_206D_202B_200E_206C_200F_200B_200F_202E(IEnumerator P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}

		static TaskAwaiter _206E_200E_206D_206C_200B_202C_202B_202D_206D_206F_200B_206E_200E_202A_206E_206D_200F_200E_202E_202E_200D_206B_200B_200E_206A_206F_202D_206F_206D_202A_200B_202D_202A_202A_206F_200C_206B_200D_206E_202D_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _EVa6l6VW15EVOnRKJC4tuQN4yFb : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter<string> _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0002: Stack underflow*/- unchecked(/*Error near IL_0001: Stack underflow*/ % /*Error near IL_0001: Stack underflow*/);
				/*Error near IL_0002: stloc 3 (out-of-bounds)*/;
				/*Error near IL_0003: Unknown opcode: 0xE7*/;
			}
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE5
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static bool _202E_200C_202E_202D_206D_206B_200B_200F_206D_200B_206F_200F_206A_206A_202C_206E_206C_206E_206D_202A_206B_202E_206A_200E_202C_202C_202A_202A_206C_202E_206E_206B_202A_200C_206A_200E_200B_206B_202A_206E_202E(string P_0)
		{
			/*Error: Invalid field token*/;
		}

		static string _200D_206B_206F_202C_206C_206D_202D_200D_206E_206D_206E_202E_206D_206B_206F_206B_202A_200C_200E_202E_202A_206C_202B_202A_206D_206C_202E_200C_206B_200B_206E_206D_206A_202E_200D_202B_202E_200E_206D_200E_202E(string P_0, string P_1)
		{
			_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
			/*Error near IL_0002: Unknown opcode: 0xB1*/;
		}

		unsafe static Exception _200B_206C_200B_202D_202A_200B_200F_200C_206B_202C_206B_200E_200C_200D_206E_200E_206E_202D_200C_200D_206C_206E_206C_202C_200C_202A_202D_206B_200B_200D_200E_206A_206A_202B_200B_202E_200B_200E_206E_202A_202E(string P_0)
		{
			*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
			checked
			{
				_ = (byte)/*Error near IL_0002: Stack underflow*/;
				/*Error near IL_0002: ldloc 57 (out-of-bounds)*/;
				/*Error near IL_0004: Unknown opcode: 0xC5*/;
			}
		}

		static Exception _202D_202A_206F_200B_206D_200B_200D_206D_200D_202A_202D_206E_206F_200B_202C_206D_200D_202A_206F_202B_202C_200E_206C_206C_200D_200C_202A_206F_206B_206C_200C_206D_200E_206F_202B_202B_200F_206F_202E_200D_202E(Exception P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB1
		}

		static string _206D_200B_202B_200B_202B_200B_206C_206C_206C_202D_206B_206F_206F_202C_206E_206A_206C_200F_200F_200D_206F_206A_206E_206D_206D_200B_202D_206E_202D_206A_202B_206D_200F_206C_200B_200F_202E_200C_200C_206D_202E(Exception P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}

		static string _206B_202D_206F_202C_202A_202C_202C_202B_202D_202B_202D_202E_206D_202B_200D_202E_206B_200C_200D_206A_202B_202C_200D_200B_206F_202C_206A_200C_202A_200C_202C_206C_200F_206C_202D_202D_206A_200D_200B_206F_202E(string P_0, object P_1, object P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x61
		}

		static string _202B_206A_206E_206F_202A_206B_200E_202A_202A_200B_202C_206A_200E_206F_200E_200E_200B_200C_206E_206B_202E_200D_202C_202A_200F_206D_206E_202C_200B_206C_206E_202C_200E_206F_200B_200D_202A_206E_206F_206E_202E()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7C
		}

		static string _202D_202D_200F_206F_206A_200D_202A_202A_206A_206D_206D_206E_206A_202A_206A_206A_200C_206A_206A_206B_206F_206A_200B_206D_200C_206C_202D_206A_202A_200C_206D_200D_200F_202B_202D_206B_202E_202E_202D_202B_202E(string P_0, string P_1, string P_2)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xD9
		}

		unsafe static DirectoryInfo _202C_202E_202A_206E_200B_202D_202C_200B_206B_200E_206E_200E_206D_200C_200B_202A_206F_200E_202B_200B_200E_200D_202A_202D_200F_202D_200F_206B_200F_200B_202A_202C_200D_202B_206D_206C_202B_202B_206C_202A_202E(string P_0)
		{
			_ = *(byte*)checked((int)uint.MaxValue);
			/*Error near IL_0003: Unknown opcode: 0xEF*/;
		}

		static string _200C_206F_202B_200B_206F_202A_206A_206A_202E_202A_202A_202B_206D_200C_202D_200D_206C_206F_202A_200D_206F_202C_206A_206B_206E_202A_200D_206A_206A_200F_206F_202D_200F_200E_202C_202C_206A_206D_206F_206C_202E(FileSystemInfo P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xCD
		}

		unsafe static SeriesCollection _206A_206E_200D_200E_206A_200B_202B_206C_202B_206B_206D_206F_206C_202E_206A_206B_202B_202D_206D_206B_206E_206E_206C_202D_200B_200F_200D_200C_200F_206D_200B_206B_200D_202A_206D_202C_202E_200F_206E_206B_202E()
		{
			//IL_0001: Invalid comparison between Unknown and I
			if ((nint)/*Error near IL_0006: Stack underflow*/ > (nint)/*Error near IL_0001: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			_ = ((int[])/*Error near IL_0009: Stack underflow*/)[(nint)(*(IntPtr*)(nint)/*Error near IL_0006: ldloc 0 (out-of-bounds)*/)];
			_ = -57756177668.81563;
			_ = 4;
			/*Error near IL_0013: Unknown opcode: 0xBE*/;
		}

		unsafe static LineSeries _200C_206C_200C_206C_200E_202D_206E_200F_202E_206A_202C_206A_202C_202B_206C_202C_206C_202B_202E_200E_206B_206C_202E_202C_200B_200C_206D_200B_202E_206B_200C_202C_206A_202B_206F_200C_206E_200C_200E_206D_202E()
		{
			if ((int)/*Error: ldarg 2 (out-of-bounds)*/ != 0)
			{
				/*Error: Invalid branch target*/;
			}
			*(_003F*)(nint)/*Error near IL_0004: Stack underflow*/ = /*Error near IL_0004: Stack underflow*/;
			checked
			{
				throw (nuint)unchecked((uint)checked((sbyte)/*Error near IL_0005: Stack underflow*/));
			}
		}

		static ObservableValue _206B_206A_206A_206D_206D_206F_202E_206D_202A_200C_206F_202E_206B_206C_206E_200E_200F_202B_206D_202E_202A_200E_206C_200D_200F_202D_206F_202E_206B_202A_202A_206F_200F_206F_200C_202D_202B_200F_202D_202C_202E(double P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x04
		}

		static void _206B_206E_202B_202E_206E_202C_200D_206A_200F_206C_200C_202B_202E_206D_200E_202A_202A_206F_202D_202B_200B_206D_202B_202B_200C_202B_202D_202C_202D_200F_202E_206B_202C_206F_200F_200E_202A_202D_200B_206F_202E(Series P_0, IChartValues P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xC6
		}

		static Thread _200D_206E_200B_202A_200B_206C_206F_202C_202A_206D_202A_202B_202A_206E_200B_206A_200E_202D_202D_206B_202D_206A_200B_206E_206E_206D_200C_202B_200B_202C_206D_206E_202A_202D_202A_202A_200E_202C_206F_206C_202E(ThreadStart P_0)
		{
			/*Error: Invalid metadata token*/;
		}

		static void _206B_206A_202E_202D_206E_200F_206E_202A_202C_206A_200D_200B_200C_206A_200F_202E_200B_206C_206F_206A_206D_206E_200C_200C_200B_200D_200F_200B_202E_206C_206E_202C_206E_202C_202B_206A_206E_202A_200B_200E_202E(Thread P_0, bool P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE1
		}

		static string _206A_202A_206B_200E_206A_206A_206A_206E_200B_206C_202E_202A_206B_206A_206F_200B_206E_200D_202C_206F_206E_206C_202C_202D_200F_206B_200C_202B_200F_206D_200B_200B_206D_202C_200C_206E_206F_206D_206C_202D_202E(string P_0, object P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x34
		}

		static void _206B_200F_202E_202B_206F_202A_206F_200D_206A_206A_202E_206C_200B_200C_200B_202B_206B_206E_200C_206F_200B_200B_206E_206A_200D_200B_200D_200D_206B_206F_202A_202C_206E_206D_202B_202E_200D_202B_206E_202C_202E(Thread P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB8
		}

		static CultureInfo _206C_200B_200C_206B_202C_206A_200F_202B_200F_202D_202B_200D_206B_206F_202A_202E_200B_206F_202B_200B_200F_200F_202B_202D_206E_202C_206E_206E_200F_206C_206A_206B_200D_202C_200C_202B_200B_200D_206D_202A_202E(string P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x58
		}

		static void _206D_202D_206B_202A_206A_206B_206D_200B_202C_200D_206E_202A_202B_200C_200B_200D_202E_202C_206A_200F_200E_200B_200C_206D_206A_206B_202A_206F_200E_202A_206B_206B_200D_202D_206F_202E_206A_200C_200B_206A_202E(Thread P_0, CultureInfo P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x78
		}

		static void _200F_202C_200E_200F_206B_200D_206D_202A_206E_202B_206D_202E_200D_206C_200F_202A_206A_202C_200B_200F_206C_200C_202E_206F_202A_200C_202B_202B_206F_200B_202A_202B_206C_206D_206C_200E_200B_202A_206C_206E_202E(Thread P_0, CultureInfo P_1)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x64
		}

		unsafe static void _202B_206D_206D_200D_200D_206A_202E_200C_200D_206F_200C_206A_202D_200C_202B_202E_200C_206C_202C_200B_200F_200F_206A_206B_200C_200B_202D_200C_206C_202D_206E_200E_200D_206C_202B_202A_200E_202D_206D_206A_202E(Thread P_0, ThreadPriority P_1)
		{
			//IL_0003: Expected F8, but got I
			*(double*)(nint)/*Error near IL_0003: Stack underflow*/ = *(nint*)((Array)/*Error near IL_0001: Stack underflow*/).LongLength;
			/*Error near IL_0003: Invalid metadata token*/;
		}

		static void _202E_200F_202E_202C_200E_202C_202A_202A_200C_206A_206F_200D_200E_206D_200D_206D_206D_206E_202A_200B_200D_200C_206F_200E_202C_206F_206F_202C_206E_200F_206B_206E_202A_206C_200D_200E_200E_200D_206C_202A_202E(Thread P_0)
		{
			/*Error: Unknown opcode: 0xBC*/;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _kF7BNk8tXPx2CMQTAn3mdAtuOcE : IAsyncStateMachine
	{
		public int _YGQsHw1oydDDHSuBcHrGpiaPO4db;

		public AsyncTaskMethodBuilder _xgr06n2FSHAhExGNcEXekMIzA5I;

		public _TYt5UiueQJPld0Vj3scfuVKB51s<_0001> _JrnjrISK3KOFV2H3As7v8D2XpLd;

		private TaskAwaiter _teSyrDiveRJ3xlAJarvFgQdzSFo;

		[MethodImpl(MethodImplOptions.NoInlining)]
		private void MoveNext()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x3C
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x59
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		static TaskAwaiter _202B_202E_206D_200C_206C_202B_206E_200D_206A_202A_200D_202D_202B_200E_206A_206B_206F_200F_206E_200D_206F_206C_200B_200E_206F_200E_200F_206B_202C_200B_200C_202B_202C_206E_202E_200D_202A_206E_200E_200D_202E(Task P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x30
		}

		static string _200D_202C_200C_200E_206E_206E_206D_206F_202C_200B_202C_202C_206F_202E_202C_206B_206B_200F_206E_202E_206B_200B_202A_206C_202E_200E_206D_200F_202B_206D_202C_200C_202B_202A_202D_200B_200E_206F_200D_202E_202E(Exception P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB0
		}

		static string _202E_202D_200B_200E_200E_202A_200C_206F_200B_202A_202B_200F_206B_200F_202E_202C_200C_202E_206A_202E_200F_202D_200C_200F_206A_200E_202C_202A_202B_200C_206B_206D_206A_202A_206A_202B_206E_200C_206E_202E_202E(string P_0, string P_1)
		{
			_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
			/*Error near IL_0002: Unknown opcode: 0xB1*/;
		}

		static MessageBoxResult _200C_202C_206D_206E_206F_202A_202E_202E_206C_202E_200D_206F_206E_206F_200E_206F_200E_206E_202A_202C_202E_200D_200C_202C_206A_202E_206C_202C_200D_202C_200F_206D_202A_200F_200C_202B_202A_200D_202B_200C_202E(string P_0, string P_1)
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0xAEEA4611
		}

		static Task _206D_206A_206D_200F_202C_202C_200C_202D_206A_202E_202D_206E_202E_202C_200D_206F_206E_206B_200B_202A_206D_200C_202B_202E_206D_202B_206D_200C_202C_200D_202B_206D_202D_200B_206A_206B_206C_200D_206C_202D_202E(Action P_0)
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x2F 0xFD
		}
	}

	private _6jR3LzK3cpBaUvSBgX6pnlYKDMG _HEQaaJ4o34yuupItMK3sTCAZwfe;

	private string _B8JNuxTWuc1lvD2sUMiL51AeGof;

	private bool _3VRvZFXDwI9k7f8FQEWtVBHUMpu;

	private System.Timers.Timer _4cs14RPqsRBH42BRm6aKJbWEKkd;

	private System.Timers.Timer _qRBb2tQfY1Vfcgre2Ew5MyLtphm;

	private readonly object _NWyKcVgjijMkMwp6RylPxCd0FMr;

	private readonly ReaderWriterLockSlim _SusbMJKFTYoDRXVSVjC1mdIltYv;

	private ushort _SmKb3Q3jLgMutjL2TIKedGiC48D;

	private DateTime _RWb5iAaU3rZCoBWXGJSUvTTImoE;

	private List<Thread> _k07DNkLab5w7pYS7MfRvFRUewkAA;

	private int _pqSwdjJf9WjGqImAYgDde743c6J;

	protected string _AgR9Kqzu7K9sg4klRLDDy5XC90Q;

	[CompilerGenerated]
	private string _ipEcbLPaz4bmHRLfBnemoSPrdLd;

	[CompilerGenerated]
	private ConcurrentStack<_0001> _iZqum5sb0b6LRwbwAFkSLgqgjvq;

	[CompilerGenerated]
	private _6kowxIyI5s2v3oeCKgG6VfVftqH _CtjH3bQYqdVdDAf2LI4HSw0CkDx;

	[CompilerGenerated]
	private ProxyType _BqjDIPAFPpq0jFiqviAuG0FP6Jw;

	[CompilerGenerated]
	private string _Yr2HnTBQ3gxL61ukeAFQSpFbWWg;

	[CompilerGenerated]
	private string _2TuoPs9xWJGhQGu7ySkGRXhCi9b;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _UG75uz4tbNPLs4tw7F3s76BFVcm;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _RmAwHxskhlDtbh4FWALW1qYPzqi;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _qRFHbiG19mKwx63AyDefbDnSGbN;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _vYzXLN1lHzABw3YsoSsTeB7gJ1s;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _svbBDDumOIieFFCdYownaxnF89A;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _sg72IS7hAJNzAzhfETNWfCR8LPK;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _Fnbkqe7ISDFAEwFnWQO2HmJclHk;

	[CompilerGenerated]
	private _G15v8HWgo02bl3FVfr7aE6PyhXk _0pEX6aQnQZQMrYZpXbKlbbqWaSc;

	[CompilerGenerated]
	private int _v8nBPZEry3otPGusSEKnjwOYw6f;

	[CompilerGenerated]
	private int _QNOT6BU1EWviJU6FKAmhjE1MQvF;

	[CompilerGenerated]
	private TimeSpan _xPgmvu3IHqlLrNUOsIOyxQcYCKB;

	[CompilerGenerated]
	private TimeSpan _po6dPgRdj8RvF0LLsDqXwDjOsxe;

	[CompilerGenerated]
	private SeriesCollection _ACBAEOuJTudbgYqhSOMEPW4CIju;

	[CompilerGenerated]
	private _Wre1fZEd28y1dOTLmEZt1RQxd3I _S9UdJP8hUMTDuaQPJzyzYF7qgcE;

	public string Title
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xC0*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xDC
		}
	}

	public ConcurrentStack<_0001> Sources
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x20
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid local signature token: 0x2F875EEF
		}
	}

	public _6kowxIyI5s2v3oeCKgG6VfVftqH Proxies
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x75
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA9
		}
	}

	public ProxyType ProxyType
	{
		[CompilerGenerated]
		get
		{
			_ = ((long[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/];
			_ = 6;
			/*Error near IL_0002: Unknown opcode: 0xED*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x43 0xD5
		}
	}

	public string ProxyAddress
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xF0*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x4F 0xA7
		}
	}

	public virtual ushort ThreadsCount
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xF9
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE9
		}
	}

	public string StartStopContent
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x20
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x89
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk CurrentThreads
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x65
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xB5
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Remaining
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x54
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7D
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Checked
	{
		[CompilerGenerated]
		get
		{
			/*Error: Invalid metadata token*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x77 0xE7
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Errors
	{
		[CompilerGenerated]
		get
		{
			/*Error: ldloc 1 (out-of-bounds)*/;
			if (7u >= 3887910587u)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0009: ldarg 226 (out-of-bounds)*/;
			/*Error near IL_000b: Unknown opcode: 0xFF*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		protected set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x0E
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk NotEmpty
	{
		[CompilerGenerated]
		get
		{
			_ = (ulong)/*Error near IL_0001: Stack underflow*/;
			/*Error near IL_0001: Unknown opcode: 0xF2*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		protected set
		{
			/*Error: Unknown opcode: 0xE1*/;
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Correct
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x37 0xFA
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		protected set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE1
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Banned
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xC5
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		protected set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x5C
		}
	}

	public _G15v8HWgo02bl3FVfr7aE6PyhXk Incorrect
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9D
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		protected set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xEF 0xAA
		}
	}

	public int AccsPerMin
	{
		[CompilerGenerated]
		get
		{
			/*Error: Unknown opcode: 0xCB*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x07 0x1D
		}
	}

	public int Progress
	{
		[CompilerGenerated]
		get
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			_ = ((float[])/*Error near IL_0004: Stack underflow*/)[((int[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/] * /*Error near IL_0001: ldloc 3 (out-of-bounds)*/];
			/*Error near IL_0004: Unknown opcode: 0xC7*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xFC
		}
	}

	public TimeSpan TimeFromStart
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x44
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//IL_0005: Expected native int or pointer, but got F4
			System.Runtime.CompilerServices.Unsafe.Read<object>(null);
			_ = -114;
			/*Error: End of method reached without returning.*/;
		}
	}

	public TimeSpan TimeToEnd
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x47 0x42
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x9F 0x05
		}
	}

	public SeriesCollection Series
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x21
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xE8
		}
	}

	public _Wre1fZEd28y1dOTLmEZt1RQxd3I LoadAccountsCommand
	{
		get
		{
			/*Error: Invalid metadata token for ldtoken instruction.*/;
		}
	}

	public _Wre1fZEd28y1dOTLmEZt1RQxd3I LoadProxiesCommand
	{
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x7F 0x0B
		}
	}

	public unsafe _zDKxFKYm2SsAwcwMm1S8kCb29wN OpenDirectoryCommand
	{
		get
		{
			_ = *(long*)(-1477604683);
			/*Error near IL_0006: Unknown opcode: 0xF4*/;
		}
	}

	public _Wre1fZEd28y1dOTLmEZt1RQxd3I StartStopCommand
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x55
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		private set
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xA4
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected unsafe _TYt5UiueQJPld0Vj3scfuVKB51s()
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Unknown opcode: 0xF4*/;
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._XPm8O4SFcJHoRsuqWBgwBL3l3Xh))]
	public Task _7YMd6sGY8xcQhqYq34A5ycSX2vD()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDD
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._VkWUg3CsqJrCWUjwIrnnlyhOlNc))]
	public Task _1mw8caB5G5JkbOtST9waMaBaI3h()
	{
		/*Error: stloc 2 (out-of-bounds)*/;
		_ = (double)/*Error near IL_0002: Stack underflow*/;
		/*Error near IL_0002: ldloca 129 (out-of-bounds)*/;
		/*Error near IL_0004: Unknown opcode: 0xCC*/;
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._q9c1CkD25dViDRcrfydyxHabcmH))]
	public Task _haqzCzvi8WwewoUVagTTFJyVlJr(IEnumerable<string> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected virtual void _v2BFP4p6Nz9FkTGr5IxcahGDbYZ()
	{
		/*OpCode not supported: DebugBreak*/;
		/*Error near IL_0002: Not a type handle*/;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected virtual void _saQIzBCdpg58qbjJ1JoEbNJvZYy()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x17 0x64
	}

	protected virtual bool _Ymi5g6dAcGEZVTxT8wmmJPnevmF()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._Qg0dgvRCr6W2jPNHDdF1lPCfIQL))]
	private Task _lZIXMsovtPQmhBP4cERmY8sR1GC(IEnumerable<string> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBF 0x60
	}

	protected virtual void _zWBx3e1vRuyavm2fxYIpD18AYmK()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._0XB84jjQ8G92e2g9ehzszaM8TMi))]
	private Task _IpvZIXRByUfS5RM0LCCEMTNikNz(IEnumerable<string> P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3D
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._kF7BNk8tXPx2CMQTAn3mdAtuOcE))]
	private Task _JMXUxQ5x2rCwoamVQEtOPhQj49e()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x20
	}

	[AsyncStateMachine(typeof(_TYt5UiueQJPld0Vj3scfuVKB51s<>._EVa6l6VW15EVOnRKJC4tuQN4yFb))]
	private Task _dSYAGq4PdudeOVyniXIfCgdr4Zz()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	private void _0c6lnBqjNcMQU4jsWZwDLEVrN6f()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x84
	}

	private void _GD9dVF9BqPmMN6PiDZbtFioArqX()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x28
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private void _1ULrp1TB5tEcGba3Gz4TsLTJwKW()
	{
		/*Error: Not a type handle*/;
	}

	protected virtual void _xJT7CzY1KQvLwS3CVabfA8peREn()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	protected abstract void _GY3QokqGHn1ZtkFEvdoWdGi9wAC(_0001 P_0, _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_1 = null);

	protected virtual void _LoJ5r6QOsYP5hpS9OGQiRaGcRZd()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xFD
	}

	protected string _LXF8qGxm4IfDb14VUNnSI9Gt2RH(string P_0, string P_1 = "")
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	protected void _zKFyCfI6fzgrYvKZ6cTJBuZzmCA(object P_0, params string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}

	protected void _zKFyCfI6fzgrYvKZ6cTJBuZzmCA(string P_0, params string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA7 0xEB
	}

	protected void _zKFyCfI6fzgrYvKZ6cTJBuZzmCA(byte[] P_0, params string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xA9
	}

	protected void _CwpKbc9czEJmT1u0VgxuruHPSkH(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}

	protected void _CwpKbc9czEJmT1u0VgxuruHPSkH(string P_0, string P_1, string P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private void _4YBspMlPODd3MWai43iLTfJ1Agj(byte[] P_0, params string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x2B 0x6F
	}

	[CompilerGenerated]
	private void _4modINrsOuwNq8aD0ggGIYhwIFP(object P_0, ExitEventArgs P_1)
	{
		/*Error: ldloc 2 (out-of-bounds)*/;
		/*Error near IL_0001: Unknown opcode: 0xFA*/;
	}

	[CompilerGenerated]
	private bool _PlgLZHo1QuZp2k18zbtCcXgBXbs()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x08
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[CompilerGenerated]
	private void _knm4aM69ow5CalnwNvfL2Y6Ejgc(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB5
	}

	[CompilerGenerated]
	private bool _Yxx8UEzdpyNlhTdtB6FSTi3E6eV()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x08
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[CompilerGenerated]
	private unsafe void _jEMdwzVxqKVvZmbe93tAHjaHdJf(Exception P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		checked
		{
			_ = (int)/*Error near IL_0002: Stack underflow*/;
			/*Error near IL_0002: Unknown opcode: 0xFF*/;
		}
	}

	[CompilerGenerated]
	private void _2xUtJMtSaZCH41f1q2FKmEyOeVs()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDC
	}

	[CompilerGenerated]
	private void _FUINOiEMRFws7hAiC1fFLHkReRP()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x53 0xAE
	}

	[CompilerGenerated]
	private string _LgDJZ6R6fYfBeDB8Grj99JbE0ux()
	{
		/*Error: Unknown opcode: 0xF0*/;
	}

	[CompilerGenerated]
	private bool _gxOCKxijScxGBqlNIXtLFgnonLF()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x64
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[CompilerGenerated]
	private void _GkhZ8m6IppiLq4uwaCZ3LN3FESB(object P_0, ElapsedEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x64
	}

	[CompilerGenerated]
	private void _Rcjb4gJVYtRGqJcD6t03sm8WFrG(object P_0, ElapsedEventArgs P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x81
	}

	static object _202C_202A_206A_206D_206D_206C_206E_202B_202D_206D_200E_202D_202D_206F_202C_200C_202B_200B_206C_206C_200D_200B_206E_206A_200D_206F_202B_202D_200C_206A_202B_202C_202A_206B_206C_206B_200F_200F_202C_206F_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	static ReaderWriterLockSlim _202E_206C_206F_200E_202A_200C_200E_200C_206C_202B_206B_200B_206C_200F_200D_202E_200D_206F_202B_202E_200E_200C_200D_202C_202E_206B_206C_200F_200D_206E_206C_202A_202E_202D_200F_202C_202B_200B_206F_202A_202E()
	{
		_ = -45;
		_ = 7;
		/*Error near IL_0003: Unknown opcode: 0xEA*/;
	}

	unsafe static SeriesCollection _202D_202B_202A_206A_206F_202E_202E_206C_206E_200D_206E_206F_206F_200F_202A_200D_200C_202A_206E_200F_206B_206A_202C_202D_206B_200E_202E_202A_206A_202D_202E_202E_202B_200B_202A_206C_200F_206F_202E_202B_202E()
	{
		//IL_0001: Invalid comparison between Unknown and I
		if ((nint)/*Error near IL_0006: Stack underflow*/ > (nint)/*Error near IL_0001: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = ((int[])/*Error near IL_0009: Stack underflow*/)[(nint)(*(IntPtr*)(nint)/*Error near IL_0006: ldloc 0 (out-of-bounds)*/)];
		_ = -57756177668.81563;
		_ = 4;
		/*Error near IL_0013: Unknown opcode: 0xBE*/;
	}

	unsafe static LineSeries _200E_200B_206C_206D_202C_206A_202B_200F_200D_200F_200E_200D_206C_202A_206B_202D_206E_206A_200F_206C_200C_202B_206F_200C_206D_206C_200F_202C_200D_206E_202C_206D_206F_202B_202C_206F_202D_206D_202D_202E()
	{
		if ((int)/*Error: ldarg 2 (out-of-bounds)*/ != 0)
		{
			/*Error: Invalid branch target*/;
		}
		*(_003F*)(nint)/*Error near IL_0004: Stack underflow*/ = /*Error near IL_0004: Stack underflow*/;
		checked
		{
			throw (nuint)unchecked((uint)checked((sbyte)/*Error near IL_0005: Stack underflow*/));
		}
	}

	static ObservableValue _202A_200E_200B_200C_202E_206B_202A_200D_200E_206B_202A_206C_206A_206B_206B_206E_206C_200E_200D_200E_202C_206A_206A_200B_200C_206C_202A_206A_206E_200C_206B_206D_206C_206F_200C_200E_200D_206F_202D_200E_202E(double P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x04
	}

	static void _200C_200E_200D_202A_206D_200C_200E_200D_202B_200F_200F_206D_202C_206D_202A_200C_206F_200F_206A_206F_200E_200C_206E_206B_206B_202D_202B_202E_202D_202E_200B_200E_206F_202D_202B_202A_206F_206A_200D_202D_202E(Series P_0, IChartValues P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0xC6
	}

	static Assembly _202D_206A_200C_206A_200F_200F_206F_200F_200F_206A_206E_206F_200C_200B_200E_206F_202D_202C_206C_200E_202D_202D_202B_202B_206F_206F_206C_206B_206D_200D_206F_202C_200D_200C_200D_200C_202C_200F_206D_206F_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x49
	}

	static AssemblyName _206B_200C_202A_202D_202C_200C_206F_200B_206C_206F_202E_200F_200B_202C_200F_206E_202E_200E_206C_206D_202C_200C_200F_206F_202A_200F_206E_202B_202D_202C_206B_200B_206A_206F_206B_202A_206B_202B_200C_206A_202E(Assembly P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	unsafe static string _206C_206F_206F_200F_200B_206F_206F_206B_200B_202A_200C_200C_202E_202A_200D_206D_200C_200D_206C_206B_206D_206B_206D_206F_206F_200E_206A_202E_200E_202D_200C_200C_200F_200D_200F_202E_206B_206D_206B_206F_202E(AssemblyName P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[/*Error near IL_0002: Stack underflow*/];
		/*Error near IL_0003: Unknown opcode: 0xEE*/;
	}

	static string _202B_200C_206B_206D_200B_202B_206D_200C_202D_202E_206E_202A_202B_202B_200C_202E_200E_200C_200B_200D_200E_200E_200C_200D_202C_206C_206F_202C_202C_206C_206C_206C_200F_200D_206A_200E_200E_200B_200D_202D_202E(string P_0, string P_1)
	{
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
		/*Error near IL_0002: Unknown opcode: 0xB1*/;
	}

	static Application _202C_206E_206E_206B_202C_202D_202C_202D_202A_200F_200D_200F_206C_206D_200B_202C_206C_202A_202D_206A_206B_200D_200B_202E_206B_200C_206E_200E_200E_206F_206F_202B_206D_200D_206F_206E_202A_206C_202E_202D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}

	static void _200E_200F_202D_202A_206F_202D_202A_206C_206C_206B_206B_200C_202E_206B_206F_206B_200E_202A_206D_206B_202A_200B_202C_202C_202A_202C_202E_206D_200D_206A_202D_206B_200B_200D_202A_200C_206B_202B_202D_202D_202E(Application P_0, ExitEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x74
	}

	static bool _202E_202E_200D_200B_206C_202E_206E_200E_206D_206B_206E_200E_200D_200B_202D_200B_202E_202B_206E_202A_206F_202C_206D_200D_200B_202C_206C_202A_206B_202B_202B_200B_206C_202C_200E_206F_206F_202B_200C_206C_202E(string P_0, string P_1, StringComparison P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x99
	}

	static bool _200D_200D_202C_202A_206D_200B_200D_206A_200C_202D_206A_200D_206F_200E_206B_202D_200F_206E_200F_202E_206F_206D_200D_200B_202E_206C_206B_202E_202E_202A_206A_200C_202A_206C_202D_206C_206F_200C_206D_202D_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	static object _206E_200D_200C_200B_202D_202C_206D_200B_200E_202C_206E_202C_206A_200D_200B_206F_200E_206C_202A_206C_202A_202B_200C_202D_202A_202A_206E_206D_206E_206F_202D_202D_206C_202B_206D_200F_202C_200D_200D_206E_202E(string P_0, string P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x15
	}

	static string _206B_202D_200B_206A_202C_206A_202C_206A_202B_206F_202D_200E_200C_200C_206A_206E_206D_202D_206C_206B_200B_202E_202A_206F_200D_200E_206E_206D_206B_200C_202C_206A_206F_200B_202D_206B_200C_206B_202A_206F_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static void _202A_206A_206F_202E_200C_200D_206D_200F_202D_202C_206D_202D_206E_200D_200E_200E_202E_202E_202D_206A_200C_206C_202C_200C_202B_200B_206F_206E_202D_206C_200E_200C_202D_206C_206F_202A_200D_202B_200C_206F_202E(string P_0, string P_1, object P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3D
	}

	static bool _200C_206C_206E_200E_206A_206D_200F_202A_200F_206E_200B_200F_200E_200C_206B_202C_200F_200C_202D_200D_206E_200D_200F_200B_202A_200F_200E_202B_206C_200C_202D_206B_206E_206E_206D_206D_202E_200F_202B_200F_202E(string P_0)
	{
		/*Error: Invalid field token*/;
	}

	static System.Timers.Timer _206A_200B_206A_200D_202D_200D_200F_206E_200C_202D_206E_200C_206F_202B_206C_202B_206D_206C_206C_200D_202B_202C_206E_202C_202A_206A_200D_202D_200E_206C_206F_202B_206D_206E_202E_200C_202A_200E_206E_202C_202E(double P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEF 0x4C
	}

	static void _206D_206E_206A_200E_200C_202A_202A_206A_202A_206E_206A_206F_206E_206F_206D_200D_200F_200F_206B_202B_202E_202B_206A_200D_200F_206C_202B_202A_206E_202C_206E_206E_206C_206D_200F_200B_206E_202C_200D_206F_202E(System.Timers.Timer P_0, ElapsedEventHandler P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x45
	}

	static void _206C_202E_200C_206F_202A_202E_200F_202B_206A_202E_202E_202D_200F_202E_200E_202C_200D_206E_200C_206B_200B_200F_200C_206E_200E_206D_200C_206A_206C_206E_206A_206E_200F_202C_206E_206E_202E_202E_206A_200C_202E(System.Timers.Timer P_0)
	{
		/*Error: ldarg 156 (out-of-bounds)*/;
		/*Error near IL_0002: Unknown opcode: 0xCC*/;
	}

	static void _206B_202A_206A_200D_206D_200E_200C_200C_202D_200B_200D_200D_206B_206F_200F_206F_200C_206F_200B_200D_202A_206C_206E_200F_200E_200F_206F_206E_200E_202E_202B_206B_206E_202A_200B_200E_202C_200D_206E_202D_202E(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x54
	}

	static string _202E_206E_202D_206F_202A_200E_202A_206D_202C_206C_206C_206A_202C_200B_206E_202D_202E_206F_206B_206E_200B_200E_206A_200E_206A_202B_206F_206E_202C_206A_202E_206B_206D_200C_206A_206F_202E_200C_200E_202E()
	{
		/*Error: Unknown opcode: 0xCF*/;
	}

	static string _202E_200F_206C_200C_202B_202D_202A_206F_200C_206A_200D_206B_202D_202A_200F_202B_200F_206C_206D_206F_206C_200C_200C_202B_200B_200C_202E_202C_206B_200E_200F_200C_200B_202A_206C_202A_200E_200C_200E_200C_202E(string P_0, string P_1, string P_2, string P_3)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	static void _202E_206B_206A_202D_202E_202C_202A_202A_200D_202A_202C_206F_206E_202A_206F_200B_202A_200B_202E_200E_200B_206C_202D_202C_206C_206A_206A_200C_206D_200E_206E_202B_206B_200B_200D_206A_206D_200D_200B_202A_202E(System.Timers.Timer P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3C
	}

	static string _206F_200B_202E_202A_206B_206E_202D_202C_206B_202B_202B_206C_206C_200F_202C_206B_206D_206D_200F_200F_202C_202D_202A_206E_202D_202D_200D_200F_200C_200F_206F_200C_202E_200D_200B_200D_206F_202B_200D_200C_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x97D39D2C
	}

	static StreamWriter _206A_200B_206C_202B_202C_202C_200E_200C_206C_200E_200B_206E_202D_206E_206B_200D_206D_200D_206B_202B_202B_206E_202A_200D_200C_202B_200E_206F_200B_200B_202D_200E_202D_200E_202C_206E_206B_200F_206F_206C_202E(string P_0)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		if (/*Error near IL_0002: Stack underflow*/ > /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = /*Error near IL_0003: Stack underflow*/* /*Error near IL_0003: Stack underflow*/;
		/*Error near IL_0003: Unknown opcode: 0xE4*/;
	}

	static void _206F_206F_206E_206A_206D_200D_202B_200B_206D_206A_202A_206E_200C_200B_206A_202A_206C_202E_202B_206F_202B_206F_200C_206D_200C_206D_202A_200C_202D_200E_202C_202C_200B_200E_202E_200D_200F_206C_200C_202C_202E(TextWriter P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x70
	}

	static void _200B_200E_206B_206D_202B_200F_200F_200C_206E_206C_200E_206F_206E_206F_200D_200C_206C_202D_202B_206C_200C_200C_206E_206A_200B_200C_206B_200F_202A_206A_202E_200D_202D_200B_206F_202A_206E_200F_202E_206C_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}

	static void _202C_202E_200D_202D_200B_206D_206F_206B_200D_206A_200F_206E_200E_200F_206B_200C_202E_200C_206B_202C_200F_206E_200D_202B_206C_200F_202C_202E_200D_202D_206C_200B_200D_202D_202B_200E_206C_200F_206E_206D_202E(System.Timers.Timer P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB7 0x80
	}

	static string _200F_200D_200D_202B_200F_202C_200B_200B_202D_206A_206F_206B_206B_206C_200E_206B_206A_200E_200B_206A_200E_202E_200E_202A_202B_202C_202E_200F_202E_200E_200F_206D_200F_202C_206B_206F_206C_200C_202D_202E(string P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x34
	}

	static MessageBoxResult _206A_200D_202A_206F_206B_202E_202D_206F_202D_206E_206A_200E_202A_200E_206E_206F_202A_206B_202E_200F_200B_200C_202B_202A_200D_202A_206C_206D_206E_206D_200F_206F_202A_202A_202A_202B_206A_200D_206D_202D_202E(string P_0, string P_1, MessageBoxButton P_2, MessageBoxImage P_3, MessageBoxResult P_4)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6C
	}

	static Process _200D_200D_200C_206F_202E_200F_202E_200E_206C_200F_202E_206C_202A_206A_202E_200D_206F_200B_200B_202C_206C_206F_206E_206C_202E_202A_202E_206E_200F_206C_200D_206B_200E_206E_200B_206D_200E_200E_206A_202A_202E(string P_0)
	{
		/*Error: Unknown opcode: 0xF1*/;
	}

	static char[] _206F_202E_206A_206C_202C_206A_206A_202D_206F_206D_206A_200D_200E_200D_200E_200E_200D_206B_202A_200D_206E_200F_206E_202D_202C_200F_206C_206B_202B_206F_202E_200E_206E_206A_200C_202E_200D_200D_202A_202B_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC3 0x98
	}

	static string[] _206D_206B_200E_206F_200F_202A_206D_200D_206D_200C_200C_200B_202E_200C_202B_206B_202C_206A_206D_202D_202E_200D_206E_200D_200C_202C_206D_206B_202E_200C_206A_206C_200C_206B_200B_206F_206F_200C_202E_202A_202E(string P_0, char[] P_1)
	{
		/*Error: Unknown opcode: 0xE5*/;
	}

	static string _202D_202A_206D_200B_200E_206C_200F_200F_202E_206C_206D_206E_206A_202D_202C_206A_206A_206D_206F_202E_206F_200E_200B_200D_202C_200F_200B_202C_206B_206F_206D_206F_202B_202D_200B_200B_202E_206B_200C_202E(string P_0, string[] P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	static Encoding _200F_202E_202C_206A_206E_206F_200C_202E_206D_206C_200D_200F_206A_200E_206E_206D_206F_200E_200F_202C_206F_202B_206F_200D_206E_202E_200B_206F_200B_200F_202A_202B_202B_206A_206B_202A_202D_202E_200F_206E_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4D
	}

	static byte[] _200F_202B_202C_202C_206F_200E_202D_202B_202A_200E_202A_200E_202C_200E_206C_206B_206F_206A_202D_206A_202C_200E_202A_206F_200E_202C_200C_206B_206D_200E_206B_202E_200D_200D_200E_206E_200C_206B_206E_206D_202E(Encoding P_0, string P_1)
	{
		if (/*Error near IL_0002: Stack underflow*/ > /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0002: Unknown opcode: 0xF7*/;
	}

	static void _202E_200E_200C_202E_200C_202E_202A_206A_206E_206F_206B_202B_206C_206E_200F_202C_206F_202E_200F_206F_206E_202C_202A_202E_202E_200F_200D_202E_200D_202D_202D_202B_202C_202A_200B_206A_206C_202D_206F_202A_202E(Array P_0, Array P_1, int P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB5
	}

	static string _206B_202C_202C_200F_206F_206A_202D_202C_200E_206A_202E_200B_200B_206B_206C_206C_202A_200D_202C_200D_206F_202D_206D_206D_202B_206B_200C_200C_206F_200E_202A_200D_202E_206F_200B_206C_206A_202E_200C_200F_202E(string[] P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xCF 0xF0
	}

	static string _202E_200E_202B_202A_202D_202B_200F_206F_206E_206F_206A_206D_200D_206C_206B_206F_206B_200D_206B_202C_200F_200B_200B_206B_206B_206A_200D_206E_206C_206C_202C_200E_206F_200C_202B_202D_200B_206D_202D_202D_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xBC
	}

	unsafe static Exception _202B_200D_206C_200D_200B_206B_200B_206D_202B_202B_202A_202B_200C_200E_206D_206B_200C_200D_202D_206A_200D_200B_202B_200C_206C_206F_206A_202D_206B_202A_202D_202E_206C_206E_202C_200E_202B_202B_202D_200D_202E(string P_0)
	{
		*(_003F*)(nint)/*Error near IL_0001: Stack underflow*/ = /*Error near IL_0001: Stack underflow*/;
		checked
		{
			_ = (byte)/*Error near IL_0002: Stack underflow*/;
			/*Error near IL_0002: ldloc 57 (out-of-bounds)*/;
			/*Error near IL_0004: Unknown opcode: 0xC5*/;
		}
	}

	static bool _200C_202B_200C_206D_206E_206D_200D_202A_202B_202B_202E_202C_202A_206C_200B_206D_202A_202A_202B_200D_202C_202C_202D_206B_206E_206E_200E_206D_206D_206C_202B_202E_206E_202C_206D_200E_200D_202B_206D_206C_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xDD
	}

	unsafe static DirectoryInfo _200D_206C_200E_200C_206B_202B_200C_200B_202B_206D_206F_202C_202A_206E_202E_200D_200F_200D_200F_206D_206A_202E_202E_200C_206E_206A_200D_202D_206A_200D_206E_200B_200F_200D_202A_202A_200F_206D_206E_202E_202E(string P_0)
	{
		_ = *(byte*)checked((int)uint.MaxValue);
		/*Error near IL_0003: Unknown opcode: 0xEF*/;
	}

	static void _206D_202C_206D_200C_200F_206F_200D_206E_200C_202E_200E_200E_206C_206F_206F_206B_206D_200E_206A_206E_200D_202D_206D_206B_206D_202D_202A_202A_206E_202D_206C_200C_206D_206D_200F_202D_206D_202E_200D_200D_202E(ReaderWriterLockSlim P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x34
	}

	static FileStream _202B_202A_200C_202B_206F_206E_206C_200C_206A_200C_200E_206D_206B_206D_206F_200B_202E_206A_202A_206B_202A_200C_206F_200B_202E_200C_200F_200E_200F_206A_202E_202A_206F_200E_206F_200F_206B_202A_200C_200F_202E(string P_0, FileMode P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC3 0xCD
	}

	static void _202E_200F_206B_206B_206D_206F_200F_202E_202C_202C_202E_200D_202E_200B_206C_200F_202A_202E_206F_206A_202D_200E_200C_200C_202D_206C_206A_206B_206C_200C_206C_200F_206A_206C_206E_200B_206A_202D_202D_202E(Stream P_0, byte[] P_1, int P_2, int P_3)
	{
		switch ((int)/*Error near IL_0002: Stack underflow*/)
		{
		default:
			/*Error: End of method reached without returning.*/;
		}
	}

	static void _206B_200B_206B_206E_200C_200E_202A_202E_206E_206E_200D_206B_206E_202C_206C_202E_200C_200F_200E_206D_200E_200C_206F_202D_202B_200D_206A_206F_200C_200E_200C_200C_206B_200E_200B_200E_206D_200E_202D_206E_202E(Stream P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xAD
	}

	static void _206A_200D_206D_206D_206A_206D_200D_206C_206E_206F_200F_200B_200D_206F_200C_200F_200C_200C_202B_200E_206A_200E_202C_206F_200F_206E_202C_200D_202B_202C_200E_202E_206C_206A_202D_206B_202C_200B_200F_202E(ReaderWriterLockSlim P_0)
	{
		/*Error: Unknown opcode: 0xFE98*/;
	}

	static string _206E_206E_206B_206B_202C_206D_202A_206B_200C_206F_206B_200E_202C_200C_206E_200D_206F_200E_206D_206B_202B_202E_206C_200B_206F_200B_206B_206D_206C_200F_206F_200C_206B_200C_206D_206B_200F_202C_202D_206B_202E(Exception P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xB0
	}

	static MessageBoxResult _202B_202B_200F_200F_200E_206E_202E_206D_200D_206A_200B_206B_206B_206D_200E_206B_202B_206B_206D_200F_200D_206A_202B_202B_202C_202D_206A_206B_206A_200D_200C_200B_202B_202C_202B_200C_202D_206F_202E_200C_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0xAEEA4611
	}

	static string _202B_200E_200E_200E_206C_202A_206C_202E_206A_200C_200B_200F_202C_200C_202E_200E_200B_206E_200B_206C_206D_206E_200C_206E_206B_200C_202D_202A_206F_200E_206C_206F_206D_202C_200F_202C_200D_200E_200E_206F_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE7 0x5B
	}

	static ProcessStartInfo _202D_206B_206F_202E_200B_206A_200E_206A_202B_202D_200B_200C_206F_200D_200F_202B_206C_206B_202A_206F_206E_200D_200F_202A_200F_200C_202D_206A_200F_202A_206E_200B_206A_200F_200E_200E_206F_202B_202E_202A_202E(string P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x7C
	}

	static void _202D_202C_206C_200D_206B_202E_206B_202D_200C_206E_206E_200B_200F_206B_200E_206E_202A_202D_206C_202D_206A_206B_202A_200F_206A_206E_206B_206F_202D_202B_200D_206E_206E_200C_206A_206C_206F_202C_202E_200C_202E(ProcessStartInfo P_0, bool P_1)
	{
		if (/*Error near IL_0001: Stack underflow*/ >= /*Error near IL_0001: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		/*Error near IL_0001: Unknown opcode: 0xAA*/;
	}

	static Process _202A_200C_200D_200C_200C_206D_206A_206A_206E_206D_202B_202A_200C_202D_202A_202A_206D_200F_206C_200F_206A_202D_202A_202C_206E_202E_200D_200C_206C_202C_200B_200D_200C_200B_202A_200C_202E_206B_202C_200C_202E(ProcessStartInfo P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x6B 0x0D
	}

	static HttpRequest _202E_206D_202D_200B_200C_200D_200F_206A_200F_200B_202C_206A_202B_206C_206A_202C_202A_200C_200D_206C_206D_206B_200C_200F_200C_202D_206B_202A_206F_206B_202B_206C_206F_202A_206A_200C_202B_200B_200C_200C_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE5
	}

	static string _200E_202A_206C_202D_202D_202A_202B_200C_200D_206B_202D_206E_206C_202C_202D_200B_202C_202E_206B_202C_200F_202A_202B_206F_202A_202D_200F_206A_206B_200F_200F_202D_206A_206E_202D_206D_206F_202E_202E_200F_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x11
	}

	static void _202D_200E_202C_206B_200E_200D_206F_206E_202A_206B_200C_202E_202A_200E_202E_206E_206A_202C_202C_206B_206B_200B_206A_200D_200B_206A_202A_200E_200E_206D_200C_206A_206A_200C_202E_200F_200E_206D_200E_202C_202E(HttpRequest P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xF5
	}

	static HttpResponse _202B_200E_206A_202D_206C_202A_206E_206A_206B_202C_200B_202D_206A_206E_202A_200D_202A_206F_206B_200F_206C_200D_202B_202A_206C_206A_200D_206A_202E_206A_206A_200B_200B_202D_206C_202D_200C_202B_200D_206A_202E(HttpRequest P_0, string P_1, RequestParams P_2)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x4F 0x09
	}

	static bool _206D_206F_200F_200B_206C_206C_202D_202A_202E_202E_202D_206D_202B_200C_206F_206D_206E_202A_202B_200D_206A_202E_200D_202D_206F_206D_206B_200F_200E_202B_202B_202C_200B_206E_206A_206F_202E_200C_200D_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x39
	}

	static bool _200E_202D_206E_200E_206F_200E_206A_202A_202D_200F_206B_200D_200E_206D_200E_200F_206A_206E_200C_200B_206A_202A_206C_202D_200C_202C_200E_206F_206B_206E_206E_206E_206A_200B_200D_206F_202A_206D_202B_200F_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x1D
	}

	static void _200E_200D_202E_206E_202B_202A_206F_206B_200E_202C_202A_200F_206F_200E_206B_200D_202D_202E_202E_206D_202B_206F_202D_200F_200E_200C_206A_200D_202D_200B_202E_206F_200B_206F_200F_202C_206D_200F_200F_206F_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x7B 0x01
	}

	static int _200F_202D_200D_200C_202E_206B_206E_200F_206D_202D_200C_200B_200F_206D_200E_200B_206C_202D_200D_200C_200C_202D_206A_202E_202E_200F_206C_202C_200D_202A_202A_200B_200B_200F_200B_206F_206A_202B_206F_200E_202E(int P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x71
	}

	static IChartValues _206D_200B_206D_202B_200B_200D_202A_206E_202B_206D_206F_202E_200D_202A_202E_206B_200E_206D_200F_206B_202C_206F_202E_200D_202C_200B_200C_206A_202A_202C_206B_200E_206B_200D_200C_206D_206D_206A_202D_200E_202E(ISeriesView P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x48
	}

	static int _202D_200C_206D_206B_200C_202E_202D_206A_202E_206D_200E_206A_206B_206A_206D_206F_200B_200D_200E_200E_206D_202C_200C_206D_200D_206E_200B_202C_200D_200B_206E_202D_202B_200D_206C_200D_202D_206A_200D_202C_202E(ICollection P_0)
	{
		checked
		{
			_ = ((ushort[])/*Error near IL_0004: Stack underflow*/)[(byte)(sbyte)unchecked((ulong)(long)/*Error near IL_0001: Stack underflow*/)];
			/*Error near IL_0004: Invalid calli metadata token*/;
		}
	}

	static void _206C_200D_200C_206B_202E_200F_206F_202C_206B_206B_206E_202C_202E_202D_206A_200E_202E_200B_202E_200D_206A_206F_200F_206F_200D_206E_200E_200B_200E_206E_200C_206C_206F_202D_200E_206E_202C_206A_202A_200C_202E(IList P_0, int P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x3F 0x68
	}

	static int _202D_206C_206D_200C_202B_202A_206F_202D_206F_206C_206F_206D_200C_206A_202C_202A_200F_206F_202C_206E_200D_206B_202B_206F_206B_200F_200F_206A_200C_206D_200F_200C_200E_200E_202A_200E_202D_206D_206B_202E_202E(IList P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE4
	}
}
