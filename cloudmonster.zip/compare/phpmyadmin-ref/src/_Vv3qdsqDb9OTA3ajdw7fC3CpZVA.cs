using System;
using System.Runtime.CompilerServices;

[CompilerGenerated]
[_1deL5VKElKMneJuWCVicQneaaWP]
[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
internal sealed class _Vv3qdsqDb9OTA3ajdw7fC3CpZVA : Attribute
{
	public readonly int _NP0mfera5Nd2qLHDs05gNUwtwuB;

	public _Vv3qdsqDb9OTA3ajdw7fC3CpZVA(int P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x9C
	}
}
