using System;
using System.Globalization;
using System.Windows.Data;

public class _pRWpL6cM9P4cECeyR03gW6tr6HH : IValueConverter
{
	public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	object IValueConverter.Convert(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//ILSpy generated this explicit interface implementation from .override directive in Convert
		return this.Convert(value, targetType, parameter, culture);
	}

	public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x90
	}

	object IValueConverter.ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
	{
		//ILSpy generated this explicit interface implementation from .override directive in ConvertBack
		return this.ConvertBack(value, targetType, parameter, culture);
	}

	public _pRWpL6cM9P4cECeyR03gW6tr6HH()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x09
	}

	static Type _202C_200B_200F_200E_206C_202B_206F_206A_202B_200E_200F_200E_202E_202B_202B_200E_200B_200B_200C_206A_200C_206F_200E_206C_200C_200E_200C_200F_202C_206C_202A_202D_206D_200B_200F_202A_200F_206B_202C_200F_202E(object P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x98
	}

	static bool _206C_202E_206E_206F_206C_202E_206B_206D_200E_202B_202D_202E_200F_200C_200E_206F_206C_202C_202C_202C_202B_202B_200E_202B_206D_206A_206E_206C_206E_206F_206E_206B_200C_200F_206C_206A_202B_206F_200D_202D_202E(Type P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC3 0x54
	}

	static object _202C_200B_202E_206D_206E_202C_202B_200D_200F_206C_200D_206C_202A_200C_200E_206F_206F_206B_200C_206F_206A_202A_206C_202E_202B_206C_206A_200C_200C_202B_202E_200B_202C_202C_202B_206E_206D_206D_200E_202B_202E(Type P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x43 0x97
	}

	static bool _200D_206B_206A_206F_206E_206A_206D_202B_202E_200C_206A_202B_206D_200D_200C_202C_206A_206F_200E_206C_206D_200E_200D_202E_200B_202C_200C_200F_206E_200C_206E_200F_202D_202E_200C_200C_206D_206E_202B_202D_202E(object P_0, object P_1)
	{
		_ = (uint)/*Error near IL_0001: Stack underflow*/;
		/*Error near IL_0001: Invalid metadata token*/;
	}
}
