using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;

public class _HlavQgi1bVrhzWrbCuMwTpQNKZu : Application
{
	private bool _4HzZsGhVvtYrYG2qOrXTnyCtnTb;

	[MethodImpl(MethodImplOptions.NoInlining)]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.1.0")]
	public void _INcbSej5qVY4amGf0dKAqDQoIT7()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x5C
	}

	[STAThread]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "7.0.1.0")]
	public static void _P83FKDs7FFplEE475F7RZVV3DOk()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x18
	}

	public _HlavQgi1bVrhzWrbCuMwTpQNKZu()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x44
	}

	unsafe static Uri _202C_206B_202E_200C_200E_200C_202D_206F_200D_202D_200E_200B_206E_202C_200C_202A_200C_200B_202D_202D_200E_206E_200C_206C_206F_206E_200E_200D_206E_200D_202E_206A_206D_206E_200E_200B_200C_206B_200F_206E_202E(string P_0, UriKind P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		_ = /*Error near IL_0002: Stack underflow*/>> (int)(*(float*)(nint)/*Error near IL_0001: Stack underflow*/);
		/*Error near IL_0002: Unknown opcode: 0xF5*/;
	}

	static void _206F_200F_202C_202B_206C_206F_200B_206B_206F_206C_206E_206D_206C_200B_206B_206F_202E_200E_202B_206F_206D_200C_200C_202E_206E_206C_202A_206D_202C_206D_202B_206C_200E_202A_202C_206D_206D_206C_200F_206F_202E(Application P_0, Uri P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x57 0xBD
	}

	static void _200F_202B_206D_200B_200B_202E_200F_202B_206A_200B_202D_206D_200E_202C_206F_200B_206B_206D_200C_206F_202E_200C_200D_200F_200C_202D_200E_202E_206E_206C_200F_206E_206D_206B_206F_200F_202C_200E_206D_206E_202E(object P_0, Uri P_1)
	{
		/*Error: Unknown opcode: 0xBC*/;
	}

	static int _202B_200B_206B_200D_206D_202D_206F_206D_200C_206A_206B_206F_206E_206A_202C_200D_206D_206A_200B_202B_202A_202E_206A_202C_206F_200E_202B_206D_200B_200E_202A_200F_202B_202D_206D_200D_206B_206F_200C_200E_202E(Application P_0)
	{
		//IL_0007: Invalid comparison between F8 and I4
		if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
		{
			if (/*Error near IL_0004: Stack underflow*/ != /*Error near IL_0004: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			if ((double)/*Error near IL_0005: Stack underflow*/ == 51.0)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0009: Unknown opcode: 0xC7*/;
		}
		/*Error near IL_0011: Invalid metadata token*/;
	}
}
