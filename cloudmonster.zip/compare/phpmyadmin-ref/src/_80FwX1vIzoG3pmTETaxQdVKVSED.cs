public interface _80FwX1vIzoG3pmTETaxQdVKVSED
{
	string _eaoBAdVCPFyZIM8mDx28SCXwEw1 { get; }

	int _ZoI6ciSJQwlQHGWEVHfaudZ96bM { get; set; }

	bool _peIMkkUB49hMDmauPUhLROcraYA(string P_0);

	string _5RU6m6RQWG9zt0PKA8ncfFUmRLC();
}
