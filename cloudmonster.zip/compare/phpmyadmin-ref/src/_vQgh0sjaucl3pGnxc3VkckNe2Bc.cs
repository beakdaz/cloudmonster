using System;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Threading;

internal class _vQgh0sjaucl3pGnxc3VkckNe2Bc : _TYt5UiueQJPld0Vj3scfuVKB51s<_PnNZuayyjAZTWlDfE5rUmZjqyYg>
{
	[CompilerGenerated]
	private sealed class _xBHd84g7gpLVv2JawM8BapZEEIb
	{
		public _vQgh0sjaucl3pGnxc3VkckNe2Bc _JrnjrISK3KOFV2H3As7v8D2XpLd;

		public _EaiOCf05DLIbS55fQPcFQp389wO _N62l6aDFtBFmQ4tlAwI7K2OJY7B;

		public _xBHd84g7gpLVv2JawM8BapZEEIb()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x09
		}

		internal void _XmNd7p7wK8hRUYx9fkcOk8Np4Be()
		{
			//IL_0003: Invalid comparison between Unknown and O
			object obj = ((object[])0)[/*Error near IL_0001: ldloc 1 (out-of-bounds)*/];
			if (System.Runtime.CompilerServices.Unsafe.As<_003F, UIntPtr>(ref /*Error near IL_0005: Stack underflow*/) > System.Runtime.CompilerServices.Unsafe.As<object, UIntPtr>(ref obj))
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0005: Unknown opcode: 0xFF*/;
		}

		internal bool _IEU8n1dMFNHVlva2jfYxG5mhxTH()
		{
			//Invalid MethodBodyBlock: Invalid method header: 0xAB 0x09
		}
	}

	private ushort _SmKb3Q3jLgMutjL2TIKedGiC48D;

	[CompilerGenerated]
	private ObservableCollection<_EaiOCf05DLIbS55fQPcFQp389wO> _WWMPmNN5tpqk8Zzg0alpuTAtEaf;

	public ObservableCollection<_EaiOCf05DLIbS55fQPcFQp389wO> Log
	{
		[CompilerGenerated]
		get
		{
			//Invalid MethodBodyBlock: Invalid method header: 0x8B 0x7C
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		set
		{
			/*Error: Unknown opcode: 0xC0*/;
		}
	}

	public override ushort ThreadsCount
	{
		get
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			if (/*Error near IL_0006: Stack underflow*/ <= checked(/*Error near IL_0004: Stack underflow*/ + (ulong)/*Error near IL_0003: Stack underflow*/))
			{
				/*Error: Invalid branch target*/;
			}
			if (/*Error near IL_0008: Stack underflow*/ <= /*Error near IL_0008: Stack underflow*/)
			{
				/*Error: Invalid branch target*/;
			}
			/*Error near IL_0009: Invalid metadata token*/;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			checked
			{
				_ = /*Error near IL_0002: Stack underflow*/* this;
				/*Error near IL_0002: Unknown opcode: 0xCA*/;
			}
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public unsafe _vQgh0sjaucl3pGnxc3VkckNe2Bc()
	{
		if (/*Error near IL_0002: Stack underflow*/ < /*Error near IL_0002: Stack underflow*/)
		{
			/*Error: Invalid branch target*/;
		}
		_ = *(sbyte*)(nint)/*Error near IL_0003: Stack underflow*/;
		checked
		{
			_ = (sbyte)/*Error near IL_0003: ldloc 1 (out-of-bounds)*/;
			/*Error near IL_0005: Unknown opcode: 0xF5*/;
		}
	}

	protected override bool _Ymi5g6dAcGEZVTxT8wmmJPnevmF()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xEC
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	protected override void _GY3QokqGHn1ZtkFEvdoWdGi9wAC(_PnNZuayyjAZTWlDfE5rUmZjqyYg P_0, _G4HZl6xJwrcuDmIkPCZEv6KhSrN P_1 = null)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x80
	}

	static bool _200B_202E_200B_202A_202E_206B_206D_206C_202E_206F_202A_206E_200E_206C_202B_200C_206C_200D_202D_202C_200F_206A_206D_206D_200B_202A_200B_206B_206B_206B_206A_200D_206C_202C_200E_206C_200B_202E_202D_200F_202E(object P_0, object P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x59
	}

	static string _200D_202A_206F_206D_206C_202A_202C_202D_202E_202A_206F_200E_206F_206F_206E_202D_202A_206E_206A_206F_202D_206A_206C_206E_200D_202C_200F_202D_206F_200E_206E_206E_202E_206E_206E_200D_202C_200B_200E_200F_202E(Uri P_0)
	{
		/*Error: Invalid branch target*/;
	}

	static string _202A_200E_200C_202B_206B_200D_206C_200B_200D_200F_202B_202C_206A_206E_206F_206E_206F_206D_206B_202D_206F_206A_202B_206D_206A_200F_206E_206E_200C_200F_202B_200D_200E_206E_206C_200E_200D_200E_202A_202D_202E(object P_0)
	{
		/*Error: Unknown opcode: 0xE8*/;
	}

	static Application _202B_202E_206B_206F_200C_200C_206A_200C_200C_200F_200F_206D_202C_200E_202A_202C_206D_206E_202A_206A_202A_200F_206C_202E_202E_206E_200B_202D_200C_202E_200B_202D_206A_206C_200D_206F_206D_202B_206E_206D_202E()
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xED
	}

	static Dispatcher _202A_206E_202D_202A_206C_202B_206C_206A_206A_200C_206E_200D_206B_202A_202C_202C_202E_206A_202C_200F_206B_200D_206B_202C_200B_200B_206B_202A_202A_206E_202C_206B_200D_200B_200F_206D_202B_206A_202A_202E(DispatcherObject P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xC4
	}

	static void _202A_202B_200F_206B_202D_202B_206E_200E_206A_206A_206D_206F_200B_202A_202D_206B_200D_202D_200D_206C_200D_206E_202D_206A_200D_200F_206F_206C_206D_202E_200B_206C_206B_202B_206D_200F_202C_206A_202D_206E_202E(Dispatcher P_0, Action P_1)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0xE8
	}

	static string _206F_200E_200E_206A_202E_202A_206F_206B_200B_200B_200C_206C_206A_200C_200E_206F_200D_206D_202C_200E_206D_202A_202D_206E_200D_206A_202A_206F_206E_206D_206D_200D_202D_200F_206D_202D_206B_200B_200F_200E_202E(string P_0, string P_1)
	{
		_ = ((IntPtr[])/*Error near IL_0002: Stack underflow*/)[(nint)((IntPtr[])/*Error near IL_0001: Stack underflow*/)[/*Error near IL_0001: Stack underflow*/]];
		/*Error near IL_0002: Unknown opcode: 0xB1*/;
	}

	static string _206A_200B_206A_202C_202D_206C_206D_202B_200F_200C_206D_200B_202B_202B_202C_206C_206B_206F_206D_202E_206F_200C_206D_202C_202C_202E_202B_200F_202B_206C_202D_200D_200D_206B_200F_200F_200F_206F_202E_206E_202E(string P_0, string P_1)
	{
		//Invalid MethodBodyBlock: Invalid local signature token: 0x97D39D2C
	}

	static void _206B_206B_202D_202E_206A_202A_200E_206C_206E_200D_202B_206B_206A_200B_206D_206F_202D_200E_202A_202B_206F_206F_206A_202E_206B_206E_206D_206A_202A_206A_200D_200D_202D_200B_200E_202D_200F_206B_200F_202E_202E(IDisposable P_0)
	{
		//Invalid MethodBodyBlock: Invalid method header: 0x8B 0xAF
	}
}
