//! Theme: shadcn/ui dark neutral (https://ui.shadcn.com/docs/theming) mapped to egui.
//! RecehTok chart glow helpers kept for optional use.

#![allow(dead_code)]

use eframe::egui::{self, Color32, CursorIcon, FontId, Pos2, Rect, Rounding, Stroke, Ui, Visuals};
use egui::Align2;

// shadcn `.dark` + zinc/neutral (≈ oklch defaults)
pub const BG: Color32 = Color32::from_rgb(9, 9, 11);
pub const BG_DEEP: Color32 = BG;
pub const PANEL: Color32 = Color32::from_rgb(24, 24, 27);
pub const CARD: Color32 = Color32::from_rgb(24, 24, 27);
pub const ELEVATED: Color32 = Color32::from_rgb(39, 39, 42);
pub const INPUT: Color32 = Color32::from_rgb(39, 39, 42);
pub const BORDER: Color32 = Color32::from_rgb(39, 39, 42);
pub const BORDER_STRONG: Color32 = Color32::from_rgb(63, 63, 70);
pub const TEXT: Color32 = Color32::from_rgb(250, 250, 250);
pub const SECONDARY: Color32 = Color32::from_rgb(228, 228, 231);
pub const MUTED: Color32 = Color32::from_rgb(161, 161, 170);
pub const PRIMARY: Color32 = Color32::from_rgb(250, 250, 250);
pub const PRIMARY_FG: Color32 = Color32::from_rgb(9, 9, 11);
pub const PRIMARY_LIGHT: Color32 = Color32::from_rgb(244, 244, 245);
pub const ACCENT: Color32 = ELEVATED;
pub const RING: Color32 = Color32::from_rgb(113, 113, 122);
pub const SUCCESS: Color32 = Color32::from_rgb(34, 197, 94);
pub const SUCCESS_LIGHT: Color32 = Color32::from_rgb(74, 222, 128);
pub const WARNING: Color32 = Color32::from_rgb(234, 179, 8);
pub const WARNING_LIGHT: Color32 = Color32::from_rgb(250, 204, 21);
pub const DANGER: Color32 = Color32::from_rgb(248, 113, 113);
pub const DANGER_LIGHT: Color32 = Color32::from_rgb(252, 165, 165);

pub const SKY: Color32 = Color32::from_rgb(56, 189, 248);
pub const VIOLET: Color32 = Color32::from_rgb(129, 140, 248);
pub const SLATE: Color32 = MUTED;
pub const LOG_BG: Color32 = Color32::from_rgb(9, 9, 11);
pub const LOG_TEXT: Color32 = MUTED;

pub const TOOLBAR_START_FILL: Color32 = Color32::from_rgb(250, 250, 250);
pub const TOOLBAR_START_STROKE: Color32 = Color32::from_rgb(63, 63, 70);
pub const TOOLBAR_START_HOVER: Color32 = Color32::from_rgb(228, 228, 231);
pub const TOOLBAR_PAUSE_FILL: Color32 = Color32::from_rgb(48, 36, 16);
pub const TOOLBAR_PAUSE_STROKE: Color32 = Color32::from_rgb(200, 140, 24);
pub const TOOLBAR_PAUSE_HOVER: Color32 = Color32::from_rgb(64, 48, 20);
pub const TOOLBAR_RESULTS_FILL: Color32 = Color32::from_rgb(36, 24, 56);
pub const TOOLBAR_RESULTS_STROKE: Color32 = Color32::from_rgb(100, 72, 180);
pub const TOOLBAR_RESULTS_HOVER: Color32 = Color32::from_rgb(48, 32, 72);
pub const TOOLBAR_DELETE_FILL: Color32 = Color32::from_rgb(69, 10, 10);
pub const TOOLBAR_DELETE_STROKE: Color32 = Color32::from_rgb(127, 29, 29);
pub const TOOLBAR_DELETE_HOVER: Color32 = Color32::from_rgb(88, 28, 28);
pub const TOOLBAR_ARCHIVE_FILL: Color32 = Color32::from_rgb(40, 32, 16);
pub const TOOLBAR_ARCHIVE_STROKE: Color32 = Color32::from_rgb(180, 130, 40);
pub const TOOLBAR_ARCHIVE_HOVER: Color32 = Color32::from_rgb(56, 44, 20);
pub const TOOLBAR_NEUTRAL_FILL: Color32 = INPUT;
pub const TOOLBAR_NEUTRAL_STROKE: Color32 = BORDER;
pub const TOOLBAR_NEUTRAL_HOVER: Color32 = ELEVATED;

pub const BTN_ROUND: f32 = 10.0;
pub const CARD_ROUND: f32 = 10.0;
pub const CARD_ROUND_LG: f32 = 10.0;
pub const SHELL_ROUND: f32 = 10.0;
pub const RADIUS: f32 = 10.0;
pub const SHELL_PAD: f32 = 6.0;
pub const CHROME_H: f32 = 36.0;
pub const ROUND: f32 = BTN_ROUND;
pub const GAP: f32 = 8.0;
pub const GRID_GAP: f32 = 16.0;
pub const FONT: f32 = 13.0;
pub const FONT_SMALL: f32 = 12.0;
pub const FONT_TINY: f32 = 11.0;
pub const FONT_LABEL: f32 = 9.0;
pub const FONT_PAGE: f32 = 22.0;
pub const BROWSE_W: f32 = 88.0;
pub const ACTION_W: f32 = 96.0;
pub const TOOLBAR_W: f32 = 74.0;
pub const CTRL_H: f32 = 32.0;
pub const CONTENT_HEADER_H: f32 = 72.0;
/// Inner settings width target (mode grid, proxy fields).
pub const SIDEBAR_W: f32 = 448.0;
/// Total `SidePanel::left` width including shell margins.
pub const SIDEBAR_PANEL_W: f32 = SIDEBAR_W + SHELL_PAD + 4.0 + 20.0;
pub const MODE_COLS: usize = 3;
pub const MODE_BTN_W: f32 = 132.0;
pub const NAV_ITEM_H: f32 = 44.0;
pub const LOG_CARD_H: f32 = 108.0;
pub const STAT_TILE_H: f32 = 72.0;
pub const STAT_COMPACT_H: f32 = 28.0;

fn stroke_border() -> Stroke {
    Stroke::new(1.0_f32, BORDER)
}

fn lerp_color(a: Color32, b: Color32, t: f32) -> Color32 {
    let t = t.clamp(0.0, 1.0);
    Color32::from_rgba_unmultiplied(
        (a.r() as f32 + (b.r() as f32 - a.r() as f32) * t) as u8,
        (a.g() as f32 + (b.g() as f32 - a.g() as f32) * t) as u8,
        (a.b() as f32 + (b.b() as f32 - a.b() as f32) * t) as u8,
        (a.a() as f32 + (b.a() as f32 - a.a() as f32) * t) as u8,
    )
}

fn soft_radial_glow(
    painter: &egui::Painter,
    center: Pos2,
    radius: f32,
    rgb: Color32,
    alpha: u8,
    layers: u8,
) {
    for i in 0..layers {
        let t = i as f32 / layers as f32;
        let r = radius * (1.0 - t * 0.88);
        let a = ((alpha as f32) * (1.0 - t).powf(1.5) * 0.4).max(1.0) as u8;
        painter.circle_filled(
            center,
            r,
            Color32::from_rgba_unmultiplied(rgb.r(), rgb.g(), rgb.b(), a),
        );
    }
}

fn paint_vertical_gradient(painter: &egui::Painter, rect: Rect, top: Color32, bottom: Color32) {
    let mut mesh = egui::Mesh::default();
    mesh.colored_vertex(rect.left_top(), top);
    mesh.colored_vertex(rect.right_top(), top);
    mesh.colored_vertex(rect.right_bottom(), bottom);
    mesh.colored_vertex(rect.left_bottom(), bottom);
    mesh.add_triangle(0, 1, 2);
    mesh.add_triangle(0, 2, 3);
    painter.add(egui::Shape::mesh(mesh));
}

fn paint_chart_grid(painter: &egui::Painter, rect: Rect) {
    let line = Color32::from_rgba_unmultiplied(72, 68, 110, 14);
    let cell = 52.0_f32;
    let mut x = rect.left();
    while x <= rect.right() {
        painter.line_segment(
            [Pos2::new(x, rect.top()), Pos2::new(x, rect.bottom())],
            Stroke::new(1.0_f32, line),
        );
        x += cell;
    }
    let mut y = rect.top() + cell * 2.0;
    while y <= rect.bottom() {
        painter.line_segment(
            [Pos2::new(rect.left(), y), Pos2::new(rect.right(), y)],
            Stroke::new(1.0_f32, line),
        );
        y += cell;
    }
}

fn paint_frost_column(painter: &egui::Painter, rect: Rect, center_x: f32, width: f32) {
    let cy = rect.center().y;
    let h = rect.height() * 0.94;
    for i in 0..12 {
        let spread = 1.0 + i as f32 * 0.14;
        let w = width * spread;
        let a = (26.0_f32 * (1.0 - i as f32 / 12.0) * 0.55) as u8;
        let band = Rect::from_center_size(Pos2::new(center_x, cy), egui::vec2(w, h));
        painter.rect(
            band,
            0.0,
            Color32::from_rgba_unmultiplied(160, 110, 255, a),
            Stroke::NONE,
        );
    }
    painter.line_segment(
        [
            Pos2::new(center_x, rect.top() + 4.0),
            Pos2::new(center_x, rect.bottom() - 4.0),
        ],
        Stroke::new(1.0_f32, RING),
    );
}

pub fn paint_recehtok_chart_backdrop(painter: &egui::Painter, rect: Rect, rounding: f32) {
    painter.rect(
        rect,
        Rounding::same(rounding),
        LOG_BG,
        Stroke::new(1.0_f32, BORDER),
    );
}

pub fn paint_chart_well_backdrop(ui: &Ui) {
    let rect = ui.max_rect();
    paint_recehtok_chart_backdrop(ui.painter(), rect, CARD_ROUND_LG);
}

pub fn paint_shell_backdrop(painter: &egui::Painter, rect: Rect) {
    painter.rect(
        rect,
        Rounding::same(SHELL_ROUND),
        BG,
        Stroke::new(1.0_f32, BORDER),
    );
}

pub fn apply(ctx: &egui::Context) {
    let mut visuals = Visuals::dark();
    visuals.panel_fill = PANEL;
    visuals.window_fill = BG;
    visuals.extreme_bg_color = BG;
    visuals.faint_bg_color = PANEL;
    visuals.code_bg_color = LOG_BG;
    visuals.window_stroke = Stroke::NONE;
    visuals.widgets.noninteractive.bg_fill = CARD;
    visuals.widgets.noninteractive.fg_stroke = Stroke::new(1.0_f32, TEXT);
    visuals.widgets.inactive.bg_fill = INPUT;
    visuals.widgets.inactive.fg_stroke = Stroke::new(1.0_f32, TEXT);
    visuals.widgets.inactive.bg_stroke = stroke_border();
    visuals.widgets.hovered.bg_fill = ELEVATED;
    visuals.widgets.hovered.fg_stroke = Stroke::new(1.0_f32, TEXT);
    visuals.widgets.hovered.bg_stroke = Stroke::new(1.0_f32, BORDER_STRONG);
    visuals.widgets.active.bg_fill = ELEVATED;
    visuals.widgets.active.fg_stroke = Stroke::new(1.0_f32, TEXT);
    visuals.widgets.open.bg_fill = ELEVATED;
    visuals.selection.bg_fill = ELEVATED.gamma_multiply(0.85);
    visuals.selection.stroke = Stroke::new(1.0_f32, BORDER_STRONG);
    visuals.hyperlink_color = SECONDARY;
    visuals.warn_fg_color = WARNING;
    visuals.error_fg_color = DANGER;
    visuals.window_rounding = Rounding::same(SHELL_ROUND);
    let widget_round = Rounding::same(BTN_ROUND);
    visuals.widgets.noninteractive.rounding = Rounding::same(CARD_ROUND);
    visuals.widgets.inactive.rounding = widget_round;
    visuals.widgets.hovered.rounding = widget_round;
    visuals.widgets.active.rounding = widget_round;
    visuals.widgets.open.rounding = widget_round;
    ctx.set_visuals(visuals);
    let mut style = (*ctx.style()).clone();
    style.spacing.item_spacing = egui::vec2(GAP, GAP);
    style.spacing.button_padding = egui::vec2(10.0, 4.0);
    style.spacing.interact_size = egui::vec2(36.0, CTRL_H);
    style.interaction.selectable_labels = true;
    ctx.set_style(style);
}

pub fn section_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(CARD)
        .stroke(stroke_border())
        .rounding(Rounding::same(CARD_ROUND))
        .inner_margin(egui::vec2(14.0, 10.0))
}

pub fn sidebar_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(PANEL)
        .inner_margin(egui::vec2(16.0, 20.0))
}

fn shell_margin() -> egui::Margin {
    egui::Margin {
        left: SHELL_PAD,
        right: SHELL_PAD,
        top: 0.0,
        bottom: SHELL_PAD,
    }
}

pub fn draw_window_background(ctx: &egui::Context) {
    let rect = ctx.input(|i| i.screen_rect());
    if rect.width() <= 0.0 || rect.height() <= 0.0 {
        return;
    }
    paint_shell_backdrop(&ctx.layer_painter(egui::LayerId::background()), rect);
}

pub fn title_bar(ctx: &egui::Context, title: &str) {
    egui::TopBottomPanel::top("window_chrome")
        .exact_height(CHROME_H)
        .frame(
            egui::Frame::none()
                .fill(Color32::TRANSPARENT)
                .inner_margin(egui::Margin::symmetric(14.0, 6.0)),
        )
        .show(ctx, |ui| {
            let bar_h = CHROME_H - 12.0;
            let close_w = 32.0;
            ui.set_min_height(bar_h);
            ui.horizontal(|ui| {
                let drag_w = (ui.available_width() - close_w - 4.0).max(1.0);
                let (drag_rect, drag) = ui.allocate_exact_size(
                    egui::vec2(drag_w, bar_h),
                    egui::Sense::click_and_drag(),
                );
                ui.painter().text(
                    drag_rect.left_center(),
                    Align2::LEFT_CENTER,
                    title,
                    FontId::proportional(FONT_SMALL),
                    MUTED,
                );
                if drag.hovered() || drag.dragged() {
                    ui.ctx()
                        .output_mut(|o| o.cursor_icon = CursorIcon::Grab);
                }
                if drag.dragged() {
                    ui.ctx()
                        .output_mut(|o| o.cursor_icon = CursorIcon::Grabbing);
                }
                if drag.drag_started() {
                    ctx.send_viewport_cmd(egui::ViewportCommand::StartDrag);
                }

                if ui
                    .add(
                        egui::Button::new(
                            egui::RichText::new("✕").size(FONT_SMALL).color(SECONDARY),
                        )
                        .fill(ELEVATED)
                        .stroke(stroke_border())
                        .rounding(Rounding::same(BTN_ROUND))
                        .min_size(egui::vec2(close_w, bar_h)),
                    )
                    .on_hover_text("Close")
                    .clicked()
                {
                    ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                }
            });
        });
}

pub fn sidebar_panel_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(PANEL)
        .rounding(Rounding::same(CARD_ROUND_LG))
        .stroke(Stroke::new(1.0_f32, BORDER))
        .outer_margin(egui::Margin {
            left: SHELL_PAD,
            right: 4.0,
            top: 0.0,
            bottom: SHELL_PAD,
        })
        .inner_margin(egui::Margin::same(10.0))
}

pub fn main_panel_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(BG)
        .rounding(Rounding::same(CARD_ROUND_LG))
        .stroke(stroke_border())
        .outer_margin(shell_margin())
        .inner_margin(egui::Margin::same(12.0))
}

pub fn log_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(Color32::TRANSPARENT)
        .stroke(Stroke::NONE)
        .rounding(Rounding::same(CARD_ROUND_LG))
        .inner_margin(egui::vec2(12.0, 10.0))
}

pub fn section_title(ui: &mut Ui, text: &str) {
    ui.label(
        egui::RichText::new(text.to_uppercase())
            .size(FONT_LABEL)
            .strong()
            .color(MUTED),
    );
}

pub fn page_title(ui: &mut Ui, title: &str, subtitle: &str) {
    ui.vertical(|ui| {
        ui.spacing_mut().item_spacing.y = 2.0;
        ui.label(
            egui::RichText::new(title)
                .size(FONT_PAGE)
                .strong()
                .color(TEXT),
        );
        ui.label(
            egui::RichText::new(subtitle)
                .size(FONT_SMALL)
                .color(MUTED),
        );
    });
}

pub fn stat_tile(ui: &mut Ui, label: &str, value: &str, value_color: Color32) {
    stat_chip(ui, label, value, value_color);
}

/// Minimal inline stat (no card frame).
pub fn stat_chip(ui: &mut Ui, label: &str, value: &str, value_color: Color32) {
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 4.0;
        ui.label(
            egui::RichText::new(label.to_uppercase())
                .size(FONT_LABEL)
                .color(MUTED),
        );
        ui.label(
            egui::RichText::new(value)
                .size(FONT_SMALL)
                .strong()
                .monospace()
                .color(value_color),
        );
    });
}

pub fn stat_row_compact(ui: &mut Ui, valid: &str, invalid: &str, errors: &str) {
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 16.0;
        stat_chip(ui, "Valid", valid, SUCCESS);
        stat_chip(ui, "Bad", invalid, DANGER);
        stat_chip(ui, "Err", errors, WARNING);
    });
}

pub fn outline_button(label: &str) -> egui::Button<'static> {
    egui::Button::new(egui::RichText::new(label).color(TEXT))
        .fill(CARD)
        .stroke(stroke_border())
        .rounding(Rounding::same(BTN_ROUND))
}

pub fn primary_button(label: &str) -> egui::Button<'static> {
    egui::Button::new(egui::RichText::new(label).strong().color(PRIMARY_FG))
        .fill(PRIMARY)
        .stroke(Stroke::new(1.0_f32, BORDER_STRONG))
        .rounding(Rounding::same(BTN_ROUND))
}
pub fn action_button(label: &str, fill: Color32, stroke: Color32) -> egui::Button<'static> {
    if fill == TOOLBAR_START_FILL {
        return primary_button(label);
    }
    let fg = if fill == TOOLBAR_DELETE_FILL {
        TEXT
    } else {
        TEXT
    };
    egui::Button::new(egui::RichText::new(label).strong().color(fg))
        .fill(fill)
        .stroke(Stroke::new(1.0_f32, stroke))
        .rounding(Rounding::same(BTN_ROUND))
}

pub fn mode_chip(
    ui: &mut Ui,
    selected: bool,
    label: &str,
    _accent: Color32,
) -> egui::Response {
    let id = ui.id().with(label);
    let t_sel = ui.ctx().animate_bool_responsive(id.with("sel"), selected);
    let size = egui::vec2(MODE_BTN_W, CTRL_H - 2.0);
    let (rect, response) = ui.allocate_exact_size(size, egui::Sense::click());
    let t_hover = ui
        .ctx()
        .animate_bool_responsive(id.with("hov"), response.hovered());

    let fill = lerp_color(CARD, ELEVATED, t_sel.max(t_hover * 0.4));
    let stroke_a = lerp_color(BORDER, RING, t_sel.max(t_hover * 0.35));
    let stroke_w = if t_sel > 0.01 { 1.25_f32 } else { 1.0_f32 };
    let text = lerp_color(MUTED, TEXT, t_sel.max(t_hover * 0.35));

    ui.painter().rect(
        rect,
        Rounding::same(BTN_ROUND),
        fill,
        Stroke::new(stroke_w, stroke_a),
    );
    ui.painter().text(
        rect.center(),
        Align2::CENTER_CENTER,
        label,
        FontId::proportional(FONT_SMALL),
        text,
    );
    response
}
