//! Thin wrapper — prefer per-mode exes under `apps/export-*`.

fn main() -> eframe::Result<()> {
    pma_gui::run(pma_gui::LaunchConfig::default())
}
