//! Snowflake target list: `https://acct.snowflake.com user:pass`,
//! `app.snowflake.com|ACCOUNT|user|pass`, pipe-separated.
use crate::credential_line::{parse_host_colon_user_pass, with_default_scheme};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use regex::Regex;
use std::sync::LazyLock;
use url::Url;

/// Python parity: `SNOWFLAKE_URL_RE` — `*.snowflake.com` with optional scheme, port, path.
static SNOWFLAKE_URL_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"(?i)^(?:https?://)?(?:[a-zA-Z0-9-]+\.)+snowflake\.com(?::\d{1,5})?(?:/.*)?$",
    )
    .expect("SNOWFLAKE_URL_RE")
});

/// Legacy account URLs (`*.snowflakecomputing.com`), same shape as above.
static SNOWFLAKE_COMPUTING_URL_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"(?i)^(?:https?://)?(?:[a-zA-Z0-9-]+\.)+snowflakecomputing\.com(?::\d{1,5})?(?:/.*)?$",
    )
    .expect("SNOWFLAKE_COMPUTING_URL_RE")
});

pub fn snowflake_url_re_matches(raw: &str) -> bool {
    let t = raw.trim();
    if t.is_empty() {
        return false;
    }
    let base = t.split(['?', '#']).next().unwrap_or(t).trim();
    if SNOWFLAKE_URL_RE.is_match(t)
        || SNOWFLAKE_COMPUTING_URL_RE.is_match(t)
        || SNOWFLAKE_URL_RE.is_match(base)
        || SNOWFLAKE_COMPUTING_URL_RE.is_match(base)
    {
        return true;
    }
    let with_https = with_default_scheme(base, "https");
    SNOWFLAKE_URL_RE.is_match(&with_https) || SNOWFLAKE_COMPUTING_URL_RE.is_match(&with_https)
}

fn validate_snowflake_target_url(raw: &str) -> Result<()> {
    if snowflake_url_re_matches(raw) {
        return Ok(());
    }
    let base = raw.split('?').next().unwrap_or(raw).trim();
    if snowflake_url_re_matches(base) {
        return Ok(());
    }
    if raw.contains("snowflake_account=")
        && (base.contains("app.snowflake.com") || snowflake_url_re_matches(base))
    {
        return Ok(());
    }
    bail!(
        "URL `{raw}` is not a valid Snowflake URL (expected `*.snowflake.com` or `*.snowflakecomputing.com`)"
    )
}

/// Explicit account locator from `url?snowflake_account=…` (pipe format with 4 fields).
pub fn snowflake_account_from_url(url: &Url) -> Option<String> {
    url.query_pairs()
        .find(|(k, _)| k == "snowflake_account")
        .map(|(_, v)| v.into_owned())
        .filter(|s| !s.is_empty())
}

#[derive(Debug, Clone, Default)]
pub struct SnowflakeParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_snowflake: usize,
    pub total_lines: usize,
}

pub fn is_snowflake_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("");
    if host.is_empty() {
        return false;
    }
    let mut target = format!("https://{host}");
    if let Some(port) = url.port() {
        target = format!("https://{host}:{port}");
    }
    if let Some(path) = url.path().strip_prefix('/') {
        if !path.is_empty() && path != "/" {
            target.push('/');
            target.push_str(path.trim_end_matches('/'));
        }
    }
    snowflake_url_re_matches(&target) || snowflake_url_re_matches(host)
}

pub fn parse_snowflake_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_snowflake_host(&cred.url) {
        bail!(
            "host `{}` does not look like Snowflake (*.snowflakecomputing.com or *.snowflake.com)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn preprocess_line(line: &str) -> String {
    let trimmed = line.trim();
    if trimmed.contains('|') {
        let parts: Vec<&str> = trimmed.split('|').map(str::trim).collect();
        // `url|account|user|pass` or `url|account|user:pass`
        if parts.len() >= 4 && !parts[0].is_empty() && !parts[1].is_empty() {
            let pass = parts[3..].join("|");
            return format!(
                "{}?snowflake_account={} {}:{}",
                parts[0], parts[1], parts[2], pass
            );
        }
        if parts.len() == 3
            && !parts[0].is_empty()
            && !parts[1].is_empty()
            && !parts[1].contains('@')
            && parts[1].len() <= 128
        {
            if let Some((user, pass)) = parts[2].split_once(':') {
                if !user.is_empty() && !pass.is_empty() {
                    return format!(
                        "{}?snowflake_account={} {}:{}",
                        parts[0], parts[1], user, pass
                    );
                }
            }
        }
        if parts.len() >= 3 && !parts[0].is_empty() {
            let pass = parts[2..].join("|");
            return format!("{} {}:{}", parts[0], parts[1], pass);
        }
    }
    trimmed.to_string()
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = preprocess_line(line);
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    reject_garbage_line(&trimmed)?;

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        validate_credentials(&username, &password)?;
        validate_snowflake_target_url(url_part)?;
        let url = normalize_snowflake_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(&trimmed)
    } else {
        parse_host_colon_user_pass(&trimmed, &normalize_snowflake_url, false)
    }
}

fn reject_garbage_line(line: &str) -> Result<()> {
    let lower = line.to_ascii_lowercase();
    if lower.starts_with("android://")
        || lower.starts_with("intent://")
        || lower.starts_with("ftp://")
    {
        bail!("garbage line");
    }
    Ok(())
}

fn validate_credentials(username: &str, password: &str) -> Result<()> {
    if username.is_empty() {
        bail!("missing username");
    }
    if password.is_empty() {
        bail!("missing password");
    }
    Ok(())
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    validate_credentials(username, password)?;
    validate_snowflake_target_url(&format!("{scheme}{url_part}"))?;

    let url = normalize_snowflake_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let (user, pass) = cred_part
        .split_once(':')
        .context("expected user:password")?;
    if user.is_empty() {
        bail!("missing username");
    }
    Ok((user.to_string(), pass.to_string()))
}

/// Force HTTPS; keep host only (Snowflake REST is at account root).
pub fn normalize_snowflake_url(raw: &str) -> Result<Url> {
    validate_snowflake_target_url(raw)?;
    let with_scheme = with_default_scheme(raw.trim(), "https");
    let mut url = Url::parse(&with_scheme).with_context(|| format!("invalid url: {raw}"))?;
    let account = snowflake_account_from_url(&url);
    if url.scheme() != "https" {
        url.set_scheme("https").ok();
    }
    url.set_fragment(None);
    url.set_path("/");
    if let Some(acct) = account {
        url.set_query(Some(&format!(
            "snowflake_account={}",
            urlencoding_encode(&acct)
        )));
    } else {
        url.set_query(None);
    }
    Ok(url)
}

fn urlencoding_encode(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}

pub fn parse_snowflake_list_summary(content: &str) -> Result<SnowflakeParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_snowflake = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        total_lines += 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            skipped += 1;
            continue;
        }
        match parse_snowflake_line(trimmed) {
            Ok(cred) if is_snowflake_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_snowflake += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(SnowflakeParseSummary {
        credentials,
        skipped,
        filtered_non_snowflake,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_snowflakecomputing_host() {
        let cred = parse_snowflake_line(
            "https://xy12345.us-east-1.aws.snowflakecomputing.com analyst:Secret1",
        )
        .unwrap();
        assert_eq!(
            cred.url.host_str(),
            Some("xy12345.us-east-1.aws.snowflakecomputing.com")
        );
        assert_eq!(cred.username, "analyst");
    }

    #[test]
    fn parses_snowflake_com_host() {
        let cred =
            parse_snowflake_line("https://myorg-myacct.snowflake.com user:pass").unwrap();
        assert_eq!(cred.url.host_str(), Some("myorg-myacct.snowflake.com"));
    }

    #[test]
    fn rejects_bare_snowflake_com_without_subdomain() {
        assert!(!snowflake_url_re_matches("https://snowflake.com"));
        assert!(parse_snowflake_line("https://snowflake.com u:p").is_err());
    }

    #[test]
    fn accepts_port_and_path_on_snowflake_com() {
        assert!(snowflake_url_re_matches("http://myorg-myacct.snowflake.com:443/login"));
        let cred = parse_snowflake_line("myorg-myacct.snowflake.com:8443 user:pass").unwrap();
        assert_eq!(cred.url.host_str(), Some("myorg-myacct.snowflake.com"));
        assert_eq!(cred.url.port(), Some(8443));
    }

    #[test]
    fn parses_app_url_with_pipe_account() {
        let cred = parse_snowflake_line(
            "https://app.snowflake.com|ffb99554|david_jokotoye:Paste20$",
        )
        .unwrap();
        assert_eq!(cred.url.host_str(), Some("app.snowflake.com"));
        assert_eq!(
            snowflake_account_from_url(&cred.url).as_deref(),
            Some("ffb99554")
        );
        assert_eq!(cred.username, "david_jokotoye");
    }

    #[test]
    fn rejects_non_snowflake() {
        assert!(parse_snowflake_line("https://redmine.example.com u:p").is_err());
    }
}
