//! Adminer list lines — generic credential parsing with optional URL filter.

use crate::parser::parse_credential_line;
use crate::types::Credential;
use anyhow::{bail, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct AdminerParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_adminer: usize,
    pub total_lines: usize,
}

pub fn is_adminer_url(url: &Url) -> bool {
    let path = url.path().to_ascii_lowercase();
    path.contains("adminer")
        || path.ends_with(".php")
        || path == "/"
        || path.is_empty()
}

pub fn parse_adminer_line(line: &str) -> Result<Credential> {
    let cred = parse_credential_line(line)?;
    if !is_adminer_url(&cred.url) {
        bail!("url `{}` does not look like Adminer", cred.url.as_str());
    }
    Ok(cred)
}

pub fn parse_adminer_list_summary(content: &str) -> Result<AdminerParseSummary> {
    let mut summary = AdminerParseSummary::default();
    for line in content.lines() {
        summary.total_lines += 1;
        match parse_adminer_line(line) {
            Ok(cred) => summary.credentials.push(cred),
            Err(err) => {
                let msg = err.to_string();
                if msg.contains("does not look like Adminer") {
                    summary.filtered_non_adminer += 1;
                } else {
                    summary.skipped += 1;
                }
            }
        }
    }
    Ok(summary)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn adminer_line_space_separated() {
        let cred =
            parse_adminer_line("http://db.example.com/adminer.php:root:secret").unwrap();
        assert_eq!(cred.username, "root");
        assert!(cred.url.path().contains("adminer"));
    }
}
