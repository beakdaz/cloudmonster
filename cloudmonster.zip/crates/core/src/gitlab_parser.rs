//! GitLab target list format: `https://host user@email:password` or `url:user:pass`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct GitLabParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_gitlab: usize,
    pub total_lines: usize,
}

pub fn is_gitlab_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    if host.is_empty() {
        return false;
    }
    if host.contains("atlassian.net")
        || host.contains("github.com")
        || host.contains("bitbucket.")
        || host.contains("amazonaws.com")
    {
        return false;
    }
    host.contains("gitlab")
}

pub fn parse_gitlab_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_gitlab_host(&cred.url) {
        bail!(
            "host `{}` does not look like GitLab (hostname must contain `gitlab`)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    reject_garbage_line(trimmed)?;

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        validate_credentials(&username, &password)?;
        let url = normalize_gitlab_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_gitlab_colon_line(trimmed)
    } else {
        let cred = parse_host_colon_user_pass(trimmed, &normalize_gitlab_url, true)?;
        validate_credentials(&cred.username, &cred.password)?;
        Ok(cred)
    }
}

fn reject_garbage_line(line: &str) -> Result<()> {
    let lower = line.to_ascii_lowercase();
    if lower.starts_with("android://")
        || lower.starts_with("intent://")
        || lower.starts_with("ftp://")
        || line.contains('(')
        || line.contains(')')
    {
        bail!("garbage line");
    }
    Ok(())
}

fn validate_credentials(username: &str, password: &str) -> Result<()> {
    if username.is_empty() {
        bail!("missing username");
    }
    if password.is_empty() {
        bail!("missing password");
    }
    // Mis-parsed port left as username: `host:8443:pass`
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }
    if username.contains('/') || username.contains('\\') {
        bail!("username contains invalid characters");
    }
    // Port glued to username: `8443user@x`
    if username
        .chars()
        .take_while(|c| c.is_ascii_digit())
        .count()
        >= 4
        && username.chars().any(|c| c.is_ascii_alphabetic())
    {
        bail!("username looks like port glued to login");
    }
    Ok(())
}

fn parse_gitlab_colon_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    // password = after last ':'; username = before that; remainder is host[:port][/path]
    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    validate_credentials(username, password)?;

    let url = normalize_gitlab_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_gitlab_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    // Strip accidental login/path junk after host:port, keep port.
    if let Some(scheme_idx) = candidate.find("://") {
        let after = &candidate[scheme_idx + 3..];
        if let Some(slash) = after.find('/') {
            let keep = &candidate[..scheme_idx + 3 + slash];
            candidate = keep.to_string();
        }
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    if url.host_str().is_none() {
        bail!("url missing host");
    }
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_gitlab_list_summary(content: &str) -> Result<GitLabParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_gitlab = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_gitlab_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_gitlab += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(GitLabParseSummary {
        credentials,
        skipped,
        filtered_non_gitlab,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_space_separated_gitlab_line() {
        let cred = parse_gitlab_line(
            "https://gitlab.nic.cz majad37003@carpetd.com:Creative#_123",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://gitlab.nic.cz/");
        assert_eq!(cred.username, "majad37003@carpetd.com");
        assert_eq!(cred.password, "Creative#_123");
    }

    #[test]
    fn parses_colon_separated_https_url() {
        let cred =
            parse_gitlab_line("https://gitlab.example.com:alice@corp.com:secretpass").unwrap();
        assert_eq!(cred.url.as_str(), "https://gitlab.example.com/");
        assert_eq!(cred.username, "alice@corp.com");
        assert_eq!(cred.password, "secretpass");
    }

    #[test]
    fn parses_host_with_port() {
        let cred = parse_gitlab_line(
            "https://gitlab.saigontechnology.vn:6969:phuong.pham:P@ssw0rdSTSgit",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://gitlab.saigontechnology.vn:6969/");
        assert_eq!(cred.url.port(), Some(6969));
        assert_eq!(cred.username, "phuong.pham");
        assert_eq!(cred.password, "P@ssw0rdSTSgit");
    }

    #[test]
    fn parses_host_port_email_user() {
        let cred = parse_gitlab_line(
            "https://gitlab.elearnmooc.com:10080:tengma@iflytek.com:12345678",
        )
        .unwrap();
        assert_eq!(cred.url.port(), Some(10080));
        assert_eq!(cred.username, "tengma@iflytek.com");
        assert_eq!(cred.password, "12345678");
    }

    #[test]
    fn rejects_host_port_without_password() {
        assert!(parse_gitlab_line("https://gitlab.themo-on.com:30000:only104").is_err());
    }

    #[test]
    fn rejects_garbage_parenthesis_line() {
        assert!(parse_gitlab_line(
            "https://gitlab.sgalinski.de(gitlab.sgalinski.de:Pom1355:145436020"
        )
        .is_err());
    }

    #[test]
    fn rejects_android_scheme() {
        assert!(parse_gitlab_line(
            "android://token@za.co.digitlab/:0760415150:007kiss"
        )
        .is_err());
    }

    #[test]
    fn rejects_atlassian() {
        assert!(parse_gitlab_line(
            "https://gpsmonster.atlassian.net:user:pass"
        )
        .is_err());
    }

    #[test]
    fn rejects_port_glued_username() {
        assert!(parse_gitlab_line(
            "https://gitlab.kootoro.com:8443thanhnt@nodo.vn:NodoKootoro"
        )
        .is_err());
    }

    #[test]
    fn adds_https_when_scheme_missing() {
        let cred = parse_gitlab_line("gitlab.example.com bob:pass").unwrap();
        assert_eq!(cred.url.scheme(), "https");
    }

    #[test]
    fn parses_password_with_question_mark() {
        let cred = parse_gitlab_line("https://gitlab.cctin.com:helu:345678a?").unwrap();
        assert_eq!(cred.url.as_str(), "https://gitlab.cctin.com/");
        assert_eq!(cred.username, "helu");
        assert_eq!(cred.password, "345678a?");
    }

    #[test]
    fn filters_non_gitlab_from_list() {
        let list = "\
https://gpsmonster.atlassian.net:user:pass
https://gitlab.example.com:alice:secret
android://x:y:z
";
        let summary = parse_gitlab_list_summary(list).unwrap();
        assert_eq!(summary.credentials.len(), 1);
        assert!(summary.skipped + summary.filtered_non_gitlab >= 2);
    }
}
