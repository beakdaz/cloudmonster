//! Shared credential list helpers (default scheme, colon lines without `://`).

use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

/// If `raw` has no `://`, prefix `{default_scheme}://`.
pub fn with_default_scheme(raw: &str, default_scheme: &str) -> String {
    let t = raw.trim();
    if t.is_empty() {
        return String::new();
    }
    if t.contains("://") {
        t.to_string()
    } else {
        format!("{default_scheme}://{t}")
    }
}

/// `host[:port][/path]:user:pass` when the line does not contain `://`.
pub fn parse_host_colon_user_pass(
    line: &str,
    normalize_url: &dyn Fn(&str) -> Result<Url>,
    reject_digit_only_username: bool,
) -> Result<Credential> {
    if line.contains("://") {
        bail!("line already has an explicit scheme");
    }
    let parts: Vec<&str> = line.split(':').collect();
    if parts.len() < 3 {
        bail!("expected host:username:password");
    }
    let password = parts[parts.len() - 1].to_string();
    let username = parts[parts.len() - 2].to_string();
    if username.is_empty() {
        bail!("missing username");
    }
    if reject_digit_only_username && username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }
    let url_part = parts[..parts.len() - 2].join(":");
    let url = normalize_url(&url_part).with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username,
        password,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn norm_http(raw: &str) -> Result<Url> {
        Url::parse(&with_default_scheme(raw, "http")).map_err(Into::into)
    }

    #[test]
    fn parses_host_port_user_pass() {
        let cred = parse_host_colon_user_pass("195.110.34.145:8081:root:astroast", &norm_http, true).unwrap();
        assert_eq!(cred.username, "root");
        assert_eq!(cred.password, "astroast");
        assert_eq!(cred.url.host_str(), Some("195.110.34.145"));
        assert_eq!(cred.url.port(), Some(8081));
    }
}
