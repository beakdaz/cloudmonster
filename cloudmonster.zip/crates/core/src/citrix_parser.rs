//! Citrix NetScaler / Gateway VPN list: `https://host/vpn/index.html:user:pass`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct CitrixParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_vpn: usize,
    pub total_lines: usize,
}

pub fn is_citrix_vpn_url(url: &Url) -> bool {
    let path = url.path().to_ascii_lowercase();
    path.contains("/vpn/")
        || path.contains("/logon/")
        || path.ends_with("/vpn")
        || path.contains("/citrix/")
}

pub fn citrix_portal_origin(url: &Url) -> Result<Url> {
    let mut origin = url.clone();
    origin.set_path("/");
    origin.set_query(None);
    origin.set_fragment(None);
    Ok(origin)
}

pub fn parse_citrix_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_citrix_vpn_url(&cred.url) {
        bail!(
            "url `{}` does not look like Citrix VPN (path should contain `/vpn/`)",
            cred.url.as_str()
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    let lower = trimmed.to_ascii_lowercase();
    if lower.contains(".html:") || lower.contains(".htm:") {
        if trimmed.contains("://") {
            return parse_colon_service_line(trimmed);
        }
        return parse_host_colon_user_pass(trimmed, &normalize_citrix_url, true);
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_citrix_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_citrix_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];
    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    // Split credentials after `.html:` / `.htm:` so passwords may contain `:`.
    let lower_rest = rest.to_ascii_lowercase();
    if let Some(marker) = [".html:", ".htm:"].into_iter().find(|m| lower_rest.contains(m)) {
        let html_idx = lower_rest
            .find(marker)
            .context("expected url:username:password")?;
        let colon = html_idx + marker.len() - 1;
        let url_part = &rest[..colon];
        let cred_part = &rest[colon + 1..];
        let (username, password) = split_user_password(cred_part)?;
        if username.is_empty() {
            bail!("missing username");
        }
        let url = normalize_citrix_url(&format!("{scheme}{url_part}"))
            .with_context(|| format!("invalid url: {url_part}"))?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }

    let url = normalize_citrix_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_citrix_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }
    Url::parse(&candidate).context("url parse failed")
}

pub fn parse_citrix_list_summary(content: &str) -> Result<CitrixParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_vpn = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_citrix_vpn_url(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_vpn += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(CitrixParseSummary {
        credentials,
        skipped,
        filtered_non_vpn,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_vpn_index_line() {
        let line = "https://aaa2.coviran.es/vpn/tmindex.html:sc3146:Naranjos*1";
        let cred = parse_citrix_line(line).unwrap();
        assert_eq!(cred.username, "sc3146");
        assert!(cred.url.path().contains("/vpn/"));
    }

    #[test]
    fn parses_password_with_colons_after_html() {
        let line = "https://storefront.iuanyware.iu.edu/vpn/index.html:tmjames:My:degree is: Master Social Work";
        let cred = parse_citrix_line(line).unwrap();
        assert_eq!(cred.username, "tmjames");
        assert_eq!(cred.password, "My:degree is: Master Social Work");
    }
}
