//! XWiki list format: `https://xwiki.domain.com user:pass` (same line shapes as Jira lists).

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct XWikiParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_xwiki: usize,
    pub total_lines: usize,
}

/// Host looks like a real XWiki wiki instance (`xwiki.customer.com`, `*.cloud.xwiki.com`), not `rxwiki` / `loxwiki` / Jira forum.
pub fn is_xwiki_host(url: &Url) -> bool {
    let host = normalized_host(url);
    !host.is_empty() && has_xwiki_service_label(&host) && !is_excluded_xwiki_host(&host)
}

/// Line shape is usable (not `Wiki:(XWiki.org)` doc titles, jsessionid junk, etc.).
pub fn is_plausible_xwiki_credential(cred: &Credential) -> bool {
    plausible_username(&cred.username) && plausible_password(&cred.password)
}

pub fn is_xwiki_wiki_target(cred: &Credential) -> bool {
    is_xwiki_host(&cred.url) && is_plausible_xwiki_credential(cred)
}

pub fn parse_xwiki_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_xwiki_wiki_target(&cred) {
        bail!(
            "host `{}` is not a private XWiki wiki target (need `xwiki.` subdomain or `*.cloud.xwiki.com`; public/community sites excluded)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn normalized_host(url: &Url) -> String {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    host.strip_prefix("www.").unwrap_or(&host).to_string()
}

fn has_xwiki_service_label(host: &str) -> bool {
    if host.starts_with("xwiki.") {
        return true;
    }
    if host.ends_with(".cloud.xwiki.com") || host.ends_with(".demo.xwiki.com") {
        return true;
    }
    host.split('.').any(|label| {
        label == "xwiki" || label.starts_with("xwiki-") || label.ends_with("-xwiki")
    })
}

fn is_excluded_xwiki_host(host: &str) -> bool {
    static EXACT: &[&str] = &[
        "xwiki.org",
        "www.xwiki.org",
        "xwiki.com",
        "www.xwiki.com",
        "network.xwiki.com",
        "jira.xwiki.org",
        "forum.xwiki.org",
        "lists.xwiki.org",
        "l10n.xwiki.org",
        "extensions.xwiki.org",
        "playground.xwiki.org",
        "xclams.xwiki.org",
        "platform.xwiki.org",
        "und.xwiki.org",
        "ams.xwiki.org",
        "snipit.xwiki.org",
        "peertube.xwiki.com",
        "myxwiki.org",
        "www.myxwiki.org",
        "westexwiki.com",
        "www.westexwiki.com",
        "loxwiki.eu",
        "www.loxwiki.eu",
        "gfxwiki.com",
        "www.gfxwiki.com",
        "forexwiki.com",
        "buxwiki.com",
        "pvxwiki.com",
        "www.pvxwiki.com",
        "gxwiki.com",
        "www.gxwiki.com",
        "inxwiki.net",
        "www.inxwiki.net",
        "orangeboxwiki.com",
        "rpxwiki.com",
        "rxwiki.com",
        "refill-web.rxwiki.com",
        "api-web.rxwiki.com",
        "accounts.rxwiki.com",
        "my.rxwiki.com",
    ];
    if EXACT.contains(&host) {
        return true;
    }
    if host.ends_with(".atlassian.net") {
        return true;
    }
    if host.contains("rxwiki") {
        return true;
    }
    if host.ends_with(".myxwiki.org") || host.ends_with(".orthodoxwiki.org") {
        return true;
    }
    let false_wiki_suffixes = [
        "exwiki.com",
        "loxwiki.eu",
        "gfxwiki.com",
        "forexwiki.com",
        "orthodoxwiki.org",
        "felixwiki.",
        "lexwiki.",
        "hxwiki.",
        "vexwiki.",
    ];
    false_wiki_suffixes
        .iter()
        .any(|s| host.contains(s) && !host.contains(".xwiki."))
}

fn plausible_username(username: &str) -> bool {
    let u = username.trim();
    if u.is_empty() || u.len() > 120 {
        return false;
    }
    if u.contains('(') || u.contains(')') {
        return false;
    }
    if u.contains("://") || u.contains('/') {
        return false;
    }
    let lower = u.to_ascii_lowercase();
    if lower.starts_with("jsessionid=") {
        return false;
    }
    if lower == "wiki" || lower == "xwiki" || lower == "guide" || lower == "installation" {
        return false;
    }
    if lower.contains("xwiki.org") {
        return false;
    }
    if u.contains(':') && !u.contains('@') {
        return false;
    }
    true
}

fn plausible_password(password: &str) -> bool {
    let p = password.trim();
    if p.is_empty() || p.len() > 512 {
        return false;
    }
    if p.starts_with('(') && p.ends_with(')') && p.to_ascii_lowercase().contains("xwiki.org") {
        return false;
    }
    true
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_xwiki_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_xwiki_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_xwiki_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_xwiki_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    if let Some(scheme_idx) = candidate.find("://") {
        let after = &candidate[scheme_idx + 3..];
        if let Some(slash) = after.find('/') {
            candidate = candidate[..scheme_idx + 3 + slash].to_string();
        }
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_xwiki_list_summary(content: &str) -> Result<XWikiParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_xwiki = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_xwiki_wiki_target(&cred) => credentials.push(cred),
            Ok(_) => filtered_non_xwiki += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(XWikiParseSummary {
        credentials,
        skipped,
        filtered_non_xwiki,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_tenant_xwiki_subdomain() {
        let cred = parse_xwiki_line("https://xwiki.example.com admin:secret").unwrap();
        assert_eq!(cred.url.as_str(), "https://xwiki.example.com/");
    }

    #[test]
    fn accepts_cloud_tenant() {
        let cred =
            parse_xwiki_line("https://team.cloud.xwiki.com user:pass").unwrap();
        assert_eq!(cred.url.host_str(), Some("team.cloud.xwiki.com"));
    }

    #[test]
    fn rejects_westexwiki_false_positive() {
        assert!(parse_xwiki_line("https://westexwiki.com user:pass").is_err());
    }

    #[test]
    fn rejects_jira_xwiki_org() {
        assert!(parse_xwiki_line("https://jira.xwiki.org user:pass").is_err());
    }

    #[test]
    fn rejects_doc_title_credentials() {
        assert!(parse_xwiki_line("https://xwiki.example.com Wiki:(XWiki.org)").is_err());
    }

    #[test]
    fn strips_bin_view_path() {
        let cred = parse_xwiki_line(
            "https://xwiki.domain.com/bin/view/Main/WebHome user:pass",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://xwiki.domain.com/");
    }
}
