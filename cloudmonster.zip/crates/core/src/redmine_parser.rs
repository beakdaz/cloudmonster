//! Redmine target list: `https://redmine.host/redmine/login user:pass`, `host/login:user:pass`, pipe-separated.

use crate::credential_line::{parse_host_colon_user_pass, with_default_scheme};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct RedmineParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_redmine: usize,
    pub total_lines: usize,
}

pub fn is_redmine_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    if host.is_empty() {
        return false;
    }
    host.contains("redmine")
        || host.ends_with("easyredmine.com")
        || host.ends_with("hostedredmine.com")
        || host == "hostedredmine.com"
}

pub fn parse_redmine_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_redmine_host(&cred.url) {
        bail!(
            "host `{}` does not look like Redmine (hostname should contain `redmine`, easyredmine.com, or hostedredmine.com)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn preprocess_line(line: &str) -> String {
    let trimmed = line.trim();
    if trimmed.contains('|') {
        let parts: Vec<&str> = trimmed.split('|').map(str::trim).collect();
        if parts.len() >= 3 && !parts[0].is_empty() {
            let pass = parts[2..].join("|");
            return format!("{} {}:{}", parts[0], parts[1], pass);
        }
    }
    trimmed.to_string()
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = preprocess_line(line);
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    reject_garbage_line(&trimmed)?;

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        validate_credentials(&username, &password)?;
        let url = normalize_redmine_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_redmine_colon_line(&trimmed)
    } else {
        let cred = parse_host_colon_user_pass(&trimmed, &normalize_redmine_url, false)?;
        validate_credentials(&cred.username, &cred.password)?;
        Ok(cred)
    }
}

fn reject_garbage_line(line: &str) -> Result<()> {
    let lower = line.to_ascii_lowercase();
    if lower.starts_with("android://")
        || lower.starts_with("intent://")
        || lower.starts_with("ftp://")
    {
        bail!("garbage line");
    }
    Ok(())
}

fn validate_credentials(username: &str, password: &str) -> Result<()> {
    if username.is_empty() {
        bail!("missing username");
    }
    if password.is_empty() {
        bail!("missing password");
    }
    Ok(())
}

fn parse_redmine_colon_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    validate_credentials(username, password)?;

    let url = normalize_redmine_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

/// Keeps subpath such as `/redmine/`; strips login/register suffixes from combo URLs.
pub fn normalize_redmine_url(raw: &str) -> Result<Url> {
    let candidate = with_default_scheme(raw.trim(), "http");
    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }

    let mut path = url.path().to_string();
    if path.is_empty() {
        path = "/".to_string();
    }
    path = path.trim_end_matches('/').to_string();
    for suffix in ["/login", "/account/register", "/account/login"] {
        if path.ends_with(suffix) {
            path = path[..path.len() - suffix.len()].to_string();
            break;
        }
    }
    if path.is_empty() {
        path = "/".to_string();
    } else if !path.ends_with('/') {
        path.push('/');
    }
    url.set_path(&path);
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_redmine_list_summary(content: &str) -> Result<RedmineParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_redmine = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_redmine_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_redmine += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(RedmineParseSummary {
        credentials,
        skipped,
        filtered_non_redmine,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_subpath_login_colon_format() {
        let cred = parse_redmine_line(
            "https://redmine.telefonicalearningservices.com/redmine/login:3523802:123456789",
        )
        .unwrap();
        assert_eq!(
            cred.url.as_str(),
            "https://redmine.telefonicalearningservices.com/redmine/"
        );
        assert_eq!(cred.username, "3523802");
    }

    #[test]
    fn parses_host_login_without_scheme() {
        let cred = parse_redmine_line("redmine.vinsoftware.vn/login:nguyennh3:Bryan@19021975").unwrap();
        assert_eq!(cred.url.as_str(), "http://redmine.vinsoftware.vn/");
        assert_eq!(cred.username, "nguyennh3");
    }

    #[test]
    fn parses_port_and_redmine_path() {
        let cred =
            parse_redmine_line("redmine.bns.co.kr:3000/redmine/login:9CPDST:somaro95").unwrap();
        assert_eq!(cred.url.port(), Some(3000));
        assert!(cred.url.path().starts_with("/redmine"));
    }

    #[test]
    fn parses_pipe_separator() {
        let cred = parse_redmine_line("http://redmine.thebeastapps.com|bbaldaniya|Passw0rd@B").unwrap();
        assert_eq!(cred.username, "bbaldaniya");
        assert_eq!(cred.password, "Passw0rd@B");
    }

    #[test]
    fn parses_space_credentials() {
        let cred = parse_redmine_line("demo.redmine.org:facundo021913:10a3lrsy").unwrap();
        assert_eq!(cred.url.host_str(), Some("demo.redmine.org"));
        assert_eq!(cred.url.scheme(), "http");
    }

    #[test]
    fn parses_belcash_space_format() {
        let cred = parse_redmine_line("http://redmine.belcash.com admin:admin").unwrap();
        assert_eq!(cred.url.as_str(), "http://redmine.belcash.com/");
        assert_eq!(cred.username, "admin");
        assert_eq!(cred.password, "admin");
    }

    #[test]
    fn keeps_explicit_http_scheme() {
        let cred = parse_redmine_line("http://redmine.work:rahmat:versa12").unwrap();
        assert_eq!(cred.url.scheme(), "http");
        assert_eq!(cred.url.host_str(), Some("redmine.work"));
    }

    /// Manual: `cargo test -p pma-core parse_user_good_txt -- --nocapture`
    #[test]
    fn parse_user_good_txt() {
        let path = std::path::Path::new(r"D:\git\Good.txt");
        if !path.exists() {
            eprintln!("skip: {} not found", path.display());
            return;
        }
        let content = std::fs::read_to_string(path).unwrap();
        let summary = parse_redmine_list_summary(&content).unwrap();
        eprintln!(
            "summary: total_lines={} credentials={} skipped={} filtered_non_redmine={}",
            summary.total_lines,
            summary.credentials.len(),
            summary.skipped,
            summary.filtered_non_redmine
        );
        for line in content.lines() {
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }
            match parse_redmine_line(trimmed) {
                Ok(c) => eprintln!(
                    "OK  line={trimmed}\n    -> url={} user={} pass={}",
                    c.url, c.username, c.password
                ),
                Err(e) => eprintln!("ERR line={trimmed}\n    -> {e}"),
            }
        }
        assert_eq!(summary.credentials.len(), 11);
        assert_eq!(summary.skipped, 0);
        assert_eq!(summary.filtered_non_redmine, 0);
    }
}
