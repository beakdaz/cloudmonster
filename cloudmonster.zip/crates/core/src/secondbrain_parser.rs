//! The Second Brain: `https://thesecondbrain.io email:password`.

use crate::credential_line::{parse_host_colon_user_pass, with_default_scheme};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct SecondbrainParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_secondbrain: usize,
    pub total_lines: usize,
}

pub fn is_secondbrain_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    host.contains("thesecondbrain.io") || host.contains("secondbrain.io")
}

pub fn parse_secondbrain_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_secondbrain_host(&cred.url) {
        bail!(
            "host `{}` does not look like The Second Brain (expected thesecondbrain.io)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let (username, password) = split_user_password(cred_part.trim())?;
        validate_credentials(&username, &password)?;
        let url = normalize_secondbrain_url(url_part.trim())?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }
    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_secondbrain_url, true)
    }
}

fn validate_credentials(username: &str, password: &str) -> Result<()> {
    if username.is_empty() || password.is_empty() {
        bail!("missing username or password");
    }
    Ok(())
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line.find("://").map(|idx| idx + 3).context("expected url")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];
    let (url_and_user, password) = rest.rsplit_once(':').context("expected url:user:pass")?;
    let (url_part, username) = url_and_user.rsplit_once(':').context("expected url:user:pass")?;
    validate_credentials(username, password)?;
    let url = normalize_secondbrain_url(&format!("{scheme}{url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part.find(':').context("expected user:password")?;
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

pub fn normalize_secondbrain_url(raw: &str) -> Result<Url> {
    let candidate = with_default_scheme(raw.trim(), "https");
    let mut url = Url::parse(&candidate).context("url parse failed")?;
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_secondbrain_list_summary(content: &str) -> Result<SecondbrainParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_secondbrain = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_secondbrain_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_secondbrain += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(SecondbrainParseSummary {
        credentials,
        skipped,
        filtered_non_secondbrain,
        total_lines,
    })
}
