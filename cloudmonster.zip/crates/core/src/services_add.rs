//! OWA, Kibana, Zabbix, Zimbra, Drupal, Grafana, SonarQube, Mattermost combo lists.

use crate::service_combo::{
    host_path_lower, normalize_web_url, parse_combo_line, parse_list_summary, ServiceParseSummary,
};
use crate::types::Credential;
use anyhow::{bail, Result};
use url::Url;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AddServiceKind {
    Owa,
    Kibana,
    Zabbix,
    Zimbra,
    Drupal,
    Grafana,
    SonarQube,
    Mattermost,
}

impl AddServiceKind {
    pub const ALL: [AddServiceKind; 8] = [
        AddServiceKind::Owa,
        AddServiceKind::Kibana,
        AddServiceKind::Zabbix,
        AddServiceKind::Zimbra,
        AddServiceKind::Drupal,
        AddServiceKind::Grafana,
        AddServiceKind::SonarQube,
        AddServiceKind::Mattermost,
    ];

    pub fn label(self) -> &'static str {
        match self {
            AddServiceKind::Owa => "OWA",
            AddServiceKind::Kibana => "Kibana",
            AddServiceKind::Zabbix => "Zabbix",
            AddServiceKind::Zimbra => "Zimbra",
            AddServiceKind::Drupal => "Drupal",
            AddServiceKind::Grafana => "Grafana",
            AddServiceKind::SonarQube => "SonarQube",
            AddServiceKind::Mattermost => "Mattermost",
        }
    }

    pub fn output_tag(self) -> &'static str {
        match self {
            AddServiceKind::Owa => "owa",
            AddServiceKind::Kibana => "kibana",
            AddServiceKind::Zabbix => "zabbix",
            AddServiceKind::Zimbra => "zimbra",
            AddServiceKind::Drupal => "drupal",
            AddServiceKind::Grafana => "grafana",
            AddServiceKind::SonarQube => "sonarqube",
            AddServiceKind::Mattermost => "mattermost",
        }
    }
}

pub type OwaParseSummary = ServiceParseSummary;
pub type KibanaParseSummary = ServiceParseSummary;
pub type ZabbixParseSummary = ServiceParseSummary;
pub type ZimbraParseSummary = ServiceParseSummary;
pub type DrupalParseSummary = ServiceParseSummary;
pub type GrafanaParseSummary = ServiceParseSummary;
pub type SonarQubeParseSummary = ServiceParseSummary;
pub type MattermostParseSummary = ServiceParseSummary;

macro_rules! impl_service_parser {
    ($kind:expr, $parse_fn:ident, $is_fn:ident, $norm_fn:ident, $reject_fn:ident, $summary_fn:ident, $strip:expr, $digit_user:expr) => {
        pub fn $is_fn(url: &Url) -> bool {
            service_matches($kind, url)
        }

        pub fn $norm_fn(raw: &str) -> Result<Url> {
            normalize_web_url(raw, "http", $strip)
        }

        fn $reject_fn(line: &str) -> Result<()> {
            reject_for_service($kind, line)
        }

        pub fn $parse_fn(line: &str) -> Result<Credential> {
            let cred = parse_combo_line(line, &$norm_fn, &$reject_fn, $digit_user)?;
            if !$is_fn(&cred.url) {
                bail!(
                    "host `{}` does not look like {}",
                    cred.url.host_str().unwrap_or("?"),
                    $kind.label()
                );
            }
            Ok(cred)
        }

        pub fn $summary_fn(content: &str) -> Result<ServiceParseSummary> {
            parse_list_summary(content, &$parse_fn, &$is_fn)
        }
    };
}

fn normalize_owa_url(raw: &str) -> Result<Url> {
    let lower = raw.to_ascii_lowercase();
    let mut url = normalize_web_url(
        raw,
        "http",
        &[
            "/owa/auth/logon.aspx",
            "/owa/auth/expiredpassword.aspx",
            "/owa/auth.owa",
        ],
    )?;
    if lower.contains("/owa") && !url.path().to_ascii_lowercase().contains("owa") {
        url.set_path("/owa/");
    }
    Ok(url)
}

pub fn is_owa_url(url: &Url) -> bool {
    service_matches(AddServiceKind::Owa, url)
}

fn reject_owa_line(line: &str) -> Result<()> {
    reject_for_service(AddServiceKind::Owa, line)?;
    let lower = line.to_ascii_lowercase();
    if lower.contains("errorfe.aspx")
        || lower.contains("peoplebank.com")
        || lower.contains("/candidate.")
        || lower.contains("google.com:")
    {
        bail!("not exchange OWA endpoint");
    }
    Ok(())
}

pub fn parse_owa_line(line: &str) -> Result<Credential> {
    let cred = parse_combo_line(line, &normalize_owa_url, &reject_owa_line, false)?;
    if !is_owa_url(&cred.url) {
        bail!(
            "host `{}` does not look like OWA",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

pub fn parse_owa_list_summary(content: &str) -> Result<ServiceParseSummary> {
    parse_list_summary(content, &parse_owa_line, &is_owa_url)
}

impl_service_parser!(
    AddServiceKind::Kibana,
    parse_kibana_line,
    is_kibana_url,
    normalize_kibana_url,
    reject_kibana_line,
    parse_kibana_list_summary,
    &["/login", "/app/login"],
    false
);

impl_service_parser!(
    AddServiceKind::Zabbix,
    parse_zabbix_line,
    is_zabbix_url,
    normalize_zabbix_url,
    reject_zabbix_line,
    parse_zabbix_list_summary,
    &[
        "/index.php",
        "/zabbix.php",
        "/setup.php",
        "/zabbix/index.php",
        "/zabbix/zabbix.php",
        "/zabbix/setup.php",
    ],
    true
);

impl_service_parser!(
    AddServiceKind::Zimbra,
    parse_zimbra_line,
    is_zimbra_url,
    normalize_zimbra_url,
    reject_zimbra_line,
    parse_zimbra_list_summary,
    &[
        "/zimbra",
        "/zimbraAdmin",
        "/zimbraadmin",
        "/zimbra.html",
    ],
    false
);

impl_service_parser!(
    AddServiceKind::Drupal,
    parse_drupal_line,
    is_drupal_url,
    normalize_drupal_url,
    reject_drupal_line,
    parse_drupal_list_summary,
    &[
        "/user/login",
        "/core/install.php",
        "/install.php",
        "/user",
    ],
    false
);

impl_service_parser!(
    AddServiceKind::Grafana,
    parse_grafana_line,
    is_grafana_url,
    normalize_grafana_url,
    reject_grafana_line,
    parse_grafana_list_summary,
    &["/login", "/auth/sign-in", "/auth/sign-up/create-user"],
    false
);

impl_service_parser!(
    AddServiceKind::SonarQube,
    parse_sonarqube_line,
    is_sonarqube_url,
    normalize_sonarqube_url,
    reject_sonarqube_line,
    parse_sonarqube_list_summary,
    &[
        "/sessions/new",
        "/admin/users",
        "/login",
    ],
    false
);

impl_service_parser!(
    AddServiceKind::Mattermost,
    parse_mattermost_line,
    is_mattermost_url,
    normalize_mattermost_url,
    reject_mattermost_line,
    parse_mattermost_list_summary,
    &["/login", "/signup_email"],
    false
);

pub fn parse_service_line(kind: AddServiceKind, line: &str) -> Result<Credential> {
    match kind {
        AddServiceKind::Owa => parse_owa_line(line),
        AddServiceKind::Kibana => parse_kibana_line(line),
        AddServiceKind::Zabbix => parse_zabbix_line(line),
        AddServiceKind::Zimbra => parse_zimbra_line(line),
        AddServiceKind::Drupal => parse_drupal_line(line),
        AddServiceKind::Grafana => parse_grafana_line(line),
        AddServiceKind::SonarQube => parse_sonarqube_line(line),
        AddServiceKind::Mattermost => parse_mattermost_line(line),
    }
}

pub fn parse_service_list_summary(kind: AddServiceKind, content: &str) -> Result<ServiceParseSummary> {
    match kind {
        AddServiceKind::Owa => parse_owa_list_summary(content),
        AddServiceKind::Kibana => parse_kibana_list_summary(content),
        AddServiceKind::Zabbix => parse_zabbix_list_summary(content),
        AddServiceKind::Zimbra => parse_zimbra_list_summary(content),
        AddServiceKind::Drupal => parse_drupal_list_summary(content),
        AddServiceKind::Grafana => parse_grafana_list_summary(content),
        AddServiceKind::SonarQube => parse_sonarqube_list_summary(content),
        AddServiceKind::Mattermost => parse_mattermost_list_summary(content),
    }
}

fn service_matches(kind: AddServiceKind, url: &Url) -> bool {
    let (host, path) = host_path_lower(url);
    if host.is_empty() {
        return false;
    }
    match kind {
        AddServiceKind::Owa => {
            path.contains("/owa")
                || host == "outlook.live.com"
                || host == "outlook.office365.com"
                || host.starts_with("outlook.")
        }
        AddServiceKind::Kibana => {
            host.contains("kibana")
                || host.contains("akibana")
                || path.contains("/app/")
                || path.contains("/kibana")
        }
        AddServiceKind::Zabbix => {
            host.contains("zabbix")
                || path.contains("zabbix")
                || path == "/"
                || path.ends_with("/index.php")
        }
        AddServiceKind::Zimbra => {
            host.contains("zimbra") || path.contains("zimbra") || url.port() == Some(7071)
        }
        AddServiceKind::Drupal => path.contains("drupal"),
        AddServiceKind::Grafana => {
            (host.contains("grafana") || path.contains("grafana"))
                && !host.ends_with("grafana.com")
        }
        AddServiceKind::SonarQube => host.contains("sonarqube") || path.contains("sessions/new"),
        AddServiceKind::Mattermost => {
            host.contains("mattermost") && !host.contains("customers.mattermost.com")
        }
    }
}

fn reject_for_service(kind: AddServiceKind, line: &str) -> Result<()> {
    let lower = line.to_ascii_lowercase();
    match kind {
        AddServiceKind::Kibana => {
            if lower.contains("amazon.fr") || lower.contains("www.zoho.com") {
                bail!("off-target host");
            }
        }
        AddServiceKind::Grafana => {
            if lower.contains("grafana.com/auth") {
                bail!("grafana.com cloud signup, not instance");
            }
        }
        AddServiceKind::Mattermost => {
            if lower.contains("customers.mattermost.com") {
                bail!("mattermost portal, not server");
            }
        }
        _ => {}
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn owa_logon_colon() {
        let c = parse_owa_line(
            "https://mail.bip.gov.sa/owa/auth/logon.aspx:f.hummadi@bip.gov.sa:N643m725",
        )
        .unwrap();
        assert!(c.url.as_str().contains("mail.bip.gov.sa"));
    }

    #[test]
    fn owa_colon_uwaterloo() {
        let c = parse_owa_line("https://connect.uwaterloo.ca/owa/auth/logon.aspx:jwconly@uwaterloo.ca:pass")
            .unwrap();
        assert!(is_owa_url(&c.url));
    }

    #[test]
    fn zabbix_ip_colon() {
        let c = parse_zabbix_line("http://10.1.0.70/zabbix/zabbix.php:Admin:secret").unwrap();
        assert_eq!(c.username, "Admin");
    }

    #[test]
    fn sonarqube_host_port() {
        let c = parse_sonarqube_line("sonarqube.scarfallbr.com:9000/sessions/new:admin:pass").unwrap();
        assert!(is_sonarqube_url(&c.url));
    }

    #[test]
    fn mattermost_rejects_mobile() {
        assert!(parse_mattermost_line("com.mattermost.rn:user:pass").is_err());
    }
}
