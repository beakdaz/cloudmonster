//! Cloud account lists: `email:password` or `login:password` (note suite); classic clouds keep their formats.

use crate::cloud::CloudProvider;
use crate::mega_parser::{parse_mega_line, parse_mega_list_summary, MegaParseSummary};
use crate::note_export_service::{parse_note_account_line, split_login_or_email_password, NoteExportService};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct CloudParseSummary {
    pub provider: CloudProvider,
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub total_lines: usize,
}

pub fn parse_cloud_line(provider: CloudProvider, line: &str) -> Result<Credential> {
    if provider == CloudProvider::Mega {
        return parse_mega_line(line);
    }
    if provider == CloudProvider::Riseup {
        return parse_riseup_line(line);
    }
    if provider == CloudProvider::NimbusNotes {
        return parse_nimbus_line(line);
    }
    if let Some(service) = NoteExportService::from_cloud_provider(provider) {
        return parse_note_account_line(service, line);
    }
    parse_email_password_line(provider, line)
}

pub fn parse_cloud_list_summary(provider: CloudProvider, content: &str) -> Result<CloudParseSummary> {
    if provider == CloudProvider::Mega {
        let MegaParseSummary {
            credentials,
            skipped,
            total_lines,
        } = parse_mega_list_summary(content)?;
        return Ok(CloudParseSummary {
            provider,
            credentials,
            skipped,
            total_lines,
        });
    }

    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut total_lines = 0usize;
    for line in content.lines() {
        total_lines += 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            skipped += 1;
            continue;
        }
        let parsed = if provider == CloudProvider::Riseup {
            parse_riseup_line(trimmed)
        } else if provider == CloudProvider::NimbusNotes {
            parse_nimbus_line(trimmed)
        } else if let Some(service) = NoteExportService::from_cloud_provider(provider) {
            parse_note_account_line(service, trimmed)
        } else {
            parse_email_password_line(provider, trimmed)
        };
        match parsed {
            Ok(c) => credentials.push(c),
            Err(_) => skipped += 1,
        }
    }
    Ok(CloudParseSummary {
        provider,
        credentials,
        skipped,
        total_lines,
    })
}

/// Riseup account name or `user@riseup.net`, then `:password`.
fn parse_riseup_line(line: &str) -> Result<Credential> {
    let line = line.trim();
    if line.is_empty() {
        bail!("empty line");
    }
    if line.contains('@') {
        return parse_email_password_line(CloudProvider::Riseup, line);
    }
    let colon = line.find(':').context("expected user:password")?;
    let user = line[..colon].trim();
    let password = line[colon + 1..].trim();
    if user.is_empty() || password.is_empty() {
        bail!("missing user or password");
    }
    Ok(Credential {
        url: Url::parse(CloudProvider::Riseup.base_url()).expect("cloud base url"),
        username: user.to_string(),
        password: password.to_string(),
    })
}

fn parse_nimbus_line(line: &str) -> Result<Credential> {
    let (username, password) = split_login_or_email_password(line)?;
    Ok(Credential {
        url: Url::parse(CloudProvider::NimbusNotes.base_url()).expect("cloud base url"),
        username,
        password,
    })
}

fn parse_email_password_line(provider: CloudProvider, line: &str) -> Result<Credential> {
    let at = line.find('@').context("missing @ in email")?;
    let after_at = &line[at..];
    let colon = after_at
        .find(':')
        .context("expected email:password (colon after domain)")?;
    let split_at = at + colon;
    let email = line[..split_at].trim();
    if email.is_empty() || !email.contains('@') {
        bail!("invalid email");
    }
    let password = line[split_at + 1..].trim();
    if password.is_empty() {
        bail!("missing password");
    }
    Ok(Credential {
        url: Url::parse(provider.base_url()).expect("cloud base url"),
        username: email.to_string(),
        password: password.to_string(),
    })
}
