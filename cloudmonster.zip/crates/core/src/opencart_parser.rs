//! OpenCart admin: `https://shop.example.com/admin user:pass`.

use crate::credential_line::{parse_host_colon_user_pass, with_default_scheme};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct OpencartParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_opencart: usize,
    pub total_lines: usize,
}

pub fn is_opencart_admin_url(url: &Url) -> bool {
    let path = url.path().to_ascii_lowercase();
    path.contains("/admin") || path.contains("route=common/login")
}

pub fn parse_opencart_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_opencart_admin_url(&cred.url) {
        bail!(
            "url `{}` does not look like OpenCart admin (path should contain `/admin`)",
            cred.url
        );
    }
    Ok(cred)
}

fn preprocess_line(line: &str) -> String {
    let trimmed = line.trim();
    if trimmed.contains('|') {
        let parts: Vec<&str> = trimmed.split('|').map(str::trim).collect();
        if parts.len() >= 3 && !parts[0].is_empty() {
            let pass = parts[2..].join("|");
            return format!("{} {}:{}", parts[0], parts[1], pass);
        }
    }
    trimmed.to_string()
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = preprocess_line(line);
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        validate_credentials(&username, &password)?;
        let url = normalize_opencart_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(&trimmed)
    } else {
        let cred = parse_host_colon_user_pass(&trimmed, &normalize_opencart_url, true)?;
        validate_credentials(&cred.username, &cred.password)?;
        Ok(cred)
    }
}

fn validate_credentials(username: &str, password: &str) -> Result<()> {
    if username.is_empty() || password.is_empty() {
        bail!("missing username or password");
    }
    Ok(())
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];
    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }
    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    validate_credentials(username, password)?;
    let url = normalize_opencart_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part.find(':').context("expected user:password")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

pub fn normalize_opencart_url(raw: &str) -> Result<Url> {
    let candidate = with_default_scheme(raw.trim(), "https");
    let mut url = Url::parse(&candidate).context("url parse failed")?;
    let mut path = url.path().to_string();
    if !path.to_ascii_lowercase().contains("/admin") {
        let base = path.trim_end_matches('/');
        path = if base.is_empty() || base == "/" {
            "/admin/".to_string()
        } else {
            format!("{base}/admin/")
        };
    } else if !path.ends_with('/') {
        path.push('/');
    }
    url.set_path(&path);
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_opencart_list_summary(content: &str) -> Result<OpencartParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_opencart = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_opencart_admin_url(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_opencart += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(OpencartParseSummary {
        credentials,
        skipped,
        filtered_non_opencart,
        total_lines,
    })
}
