//! CRM SaaS — combo lists: **`email:password`**, **`login:password`**, or URL prefix (same as note suite).

use crate::types::Credential;
use anyhow::{bail, Result};

use crate::note_export_service::parse_account_line_with_optional_url;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum CrmExportService {
    Trello,
    Hubspot,
    Pipedrive,
    Freshworks,
    Insightly,
    Sugarcrm,
    Sap,
    Keap,
    Nimble,
    Creatio,
    Monday,
    Clickup,
    Salesforce,
}

impl CrmExportService {
    pub const ALL: [Self; 13] = [
        Self::Trello,
        Self::Hubspot,
        Self::Pipedrive,
        Self::Freshworks,
        Self::Insightly,
        Self::Sugarcrm,
        Self::Sap,
        Self::Keap,
        Self::Nimble,
        Self::Creatio,
        Self::Monday,
        Self::Clickup,
        Self::Salesforce,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Self::Trello => "Trello",
            Self::Hubspot => "HubSpot",
            Self::Pipedrive => "Pipedrive",
            Self::Freshworks => "Freshworks",
            Self::Insightly => "Insightly",
            Self::Sugarcrm => "SugarCRM",
            Self::Sap => "SAP",
            Self::Keap => "Keap",
            Self::Nimble => "Nimble",
            Self::Creatio => "Creatio",
            Self::Monday => "monday.com",
            Self::Clickup => "ClickUp",
            Self::Salesforce => "Salesforce",
        }
    }

    pub fn output_slug(self) -> &'static str {
        match self {
            Self::Trello => "trello",
            Self::Hubspot => "hubspot",
            Self::Pipedrive => "pipedrive",
            Self::Freshworks => "freshworks",
            Self::Insightly => "insightly",
            Self::Sugarcrm => "sugarcrm",
            Self::Sap => "sap",
            Self::Keap => "keap",
            Self::Nimble => "nimble",
            Self::Creatio => "creatio",
            Self::Monday => "monday",
            Self::Clickup => "clickup",
            Self::Salesforce => "salesforce",
        }
    }

    pub fn default_origin(self) -> &'static str {
        match self {
            Self::Trello => "https://trello.com/",
            Self::Hubspot => "https://app.hubspot.com/",
            Self::Pipedrive => "https://app.pipedrive.com/",
            Self::Freshworks => "https://login.freshworks.com/",
            Self::Insightly => "https://app.insightly.com/",
            Self::Sugarcrm => "https://login.sugarcrm.com/",
            Self::Sap => "https://accounts.sap.com/",
            Self::Keap => "https://app.keap.com/",
            Self::Nimble => "https://app.nimble.com/",
            Self::Creatio => "https://login.creatio.com/",
            Self::Monday => "https://auth.monday.com/",
            Self::Clickup => "https://app.clickup.com/",
            Self::Salesforce => "https://login.salesforce.com/",
        }
    }
}

#[derive(Debug, Clone)]
pub struct CrmExportParseSummary {
    pub service: CrmExportService,
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_wrong_host: usize,
    pub total_lines: usize,
}

pub fn parse_crm_account_line(service: CrmExportService, line: &str) -> Result<Credential> {
    parse_account_line_with_optional_url(line, service.default_origin())
}

pub fn parse_crm_export_list_summary(
    service: CrmExportService,
    content: &str,
) -> Result<CrmExportParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_crm_account_line(service, trimmed) {
            Ok(cred) => credentials.push(cred),
            Err(_) => skipped += 1,
        }
    }

    Ok(CrmExportParseSummary {
        service,
        credentials,
        skipped,
        filtered_wrong_host: 0,
        total_lines,
    })
}
