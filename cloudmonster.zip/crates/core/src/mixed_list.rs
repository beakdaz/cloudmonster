//! One combo file → auto-detect service (AdminPanel-style).

use crate::service_combo::preprocess_combo_line;
use crate::types::Credential;
use crate::AddServiceKind;
use crate::{
    parse_adminer_line, parse_bamboo_line, parse_bitrix_line, parse_drupal_line,
    parse_fortinet_line, parse_gitlab_line, parse_grafana_line, parse_jenkins_line,
    parse_jira_line, parse_kibana_line, parse_mattermost_line, parse_owa_line,
    parse_phppgadmin_line, parse_redmine_line, parse_sonarqube_line, parse_xwiki_line,
    parse_zabbix_line, parse_zimbra_line,
};
use anyhow::Result;
use url::Url;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum MixedService {
    PhpMyAdmin,
    Adminer,
    PhpPgAdmin,
    GitLab,
    Jenkins,
    Bitrix,
    Jira,
    Redmine,
    XWiki,
    Bamboo,
    Owa,
    RdWeb,
    Kibana,
    Zabbix,
    Zimbra,
    Drupal,
    Grafana,
    SonarQube,
    Mattermost,
}

impl MixedService {
    /// Services shown in AdminPanel mixed list (email:pass / url:user:pass combos).
    pub const ALL: [MixedService; 19] = [
        MixedService::RdWeb,
        MixedService::Owa,
        MixedService::Kibana,
        MixedService::Grafana,
        MixedService::SonarQube,
        MixedService::Mattermost,
        MixedService::Zabbix,
        MixedService::Zimbra,
        MixedService::Drupal,
        MixedService::Redmine,
        MixedService::Jira,
        MixedService::GitLab,
        MixedService::Jenkins,
        MixedService::Bitrix,
        MixedService::XWiki,
        MixedService::Bamboo,
        MixedService::PhpPgAdmin,
        MixedService::Adminer,
        MixedService::PhpMyAdmin,
    ];

    pub fn good_bucket_name(self) -> &'static str {
        match self {
            MixedService::PhpMyAdmin => "Good_phpMyAdmin.txt",
            MixedService::Adminer => "Good_Adminer.txt",
            MixedService::PhpPgAdmin => "Good_phpPgAdmin.txt",
            MixedService::GitLab => "Good_GitLab.txt",
            MixedService::Jenkins => "Good_Jenkins.txt",
            MixedService::Bitrix => "Good_Bitrix.txt",
            MixedService::Jira => "Good_Jira.txt",
            MixedService::Redmine => "Good_Redmine.txt",
            MixedService::XWiki => "Good_XWiki.txt",
            MixedService::Bamboo => "Good_Bamboo.txt",
            MixedService::Owa => "Good_OWA.txt",
            MixedService::RdWeb => "Good_RDWeb.txt",
            MixedService::Kibana => "Good_Kibana.txt",
            MixedService::Zabbix => "Good_Zabbix.txt",
            MixedService::Zimbra => "Good_Zimbra.txt",
            MixedService::Drupal => "Good_Drupal.txt",
            MixedService::Grafana => "Good_Grafana.txt",
            MixedService::SonarQube => "Good_SonarQube.txt",
            MixedService::Mattermost => "Good_Mattermost.txt",
        }
    }

    pub fn add_service_kind(self) -> Option<AddServiceKind> {
        match self {
            MixedService::Owa => Some(AddServiceKind::Owa),
            MixedService::RdWeb => None,
            MixedService::Kibana => Some(AddServiceKind::Kibana),
            MixedService::Zabbix => Some(AddServiceKind::Zabbix),
            MixedService::Zimbra => Some(AddServiceKind::Zimbra),
            MixedService::Drupal => Some(AddServiceKind::Drupal),
            MixedService::Grafana => Some(AddServiceKind::Grafana),
            MixedService::SonarQube => Some(AddServiceKind::SonarQube),
            MixedService::Mattermost => Some(AddServiceKind::Mattermost),
            _ => None,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            MixedService::PhpMyAdmin => "phpMyAdmin",
            MixedService::Adminer => "Adminer",
            MixedService::PhpPgAdmin => "phpPgAdmin",
            MixedService::GitLab => "GitLab",
            MixedService::Jenkins => "Jenkins",
            MixedService::Bitrix => "Bitrix",
            MixedService::Jira => "Jira",
            MixedService::Redmine => "Redmine",
            MixedService::XWiki => "XWiki",
            MixedService::Bamboo => "Bamboo",
            MixedService::Owa => "OWA",
            MixedService::RdWeb => "RDWeb",
            MixedService::Kibana => "Kibana",
            MixedService::Zabbix => "Zabbix",
            MixedService::Zimbra => "Zimbra",
            MixedService::Drupal => "Drupal",
            MixedService::Grafana => "Grafana",
            MixedService::SonarQube => "SonarQube",
            MixedService::Mattermost => "Mattermost",
        }
    }

    /// How this line is recognized in a mixed file.
    pub fn detect_hint(self) -> &'static str {
        match self {
            MixedService::RdWeb => "Microsoft RD Web: `/RDWeb/Pages/.../login.aspx` in URL",
            MixedService::Owa => "Outlook Web App: /owa/ in URL or OWA-style host",
            MixedService::PhpMyAdmin => "«phpmyadmin» in URL path or hostname",
            MixedService::Kibana => "Kibana / app kibana in URL",
            MixedService::Grafana => "Grafana login URL",
            MixedService::SonarQube => "SonarQube / sonar in URL",
            MixedService::Mattermost => "Mattermost team/login URL",
            MixedService::Zabbix => "Zabbix frontend URL",
            MixedService::Zimbra => "Zimbra webmail URL",
            MixedService::Drupal => "Drupal user login URL",
            _ => "Service-specific parser (GitLab, Jira, …)",
        }
    }

    /// RGB fill for UI chips (AdminPanel).
    pub fn chip_rgb(self) -> (u8, u8, u8) {
        match self {
            Self::RdWeb => (220, 38, 38),
            Self::Owa => (37, 99, 235),
            Self::Kibana => (16, 185, 129),
            Self::Grafana => (245, 158, 11),
            Self::SonarQube => (124, 58, 237),
            Self::Mattermost => (59, 130, 246),
            Self::Zabbix => (220, 38, 127),
            Self::Zimbra => (234, 88, 12),
            Self::Drupal => (13, 148, 136),
            Self::Redmine => (185, 28, 28),
            Self::Jira => (14, 165, 233),
            Self::GitLab => (249, 115, 22),
            Self::Jenkins => (107, 114, 128),
            Self::Bitrix => (99, 102, 241),
            Self::XWiki => (34, 197, 94),
            Self::Bamboo => (22, 163, 74),
            Self::PhpPgAdmin => (168, 85, 247),
            Self::Adminer => (6, 182, 212),
            Self::PhpMyAdmin => (236, 72, 153),
        }
    }

    /// Example combo shapes (one line = one target).
    pub fn line_format_help(self) -> &'static str {
        match self {
            MixedService::RdWeb => {
                "https://host/RDWeb/Pages/en-US/login.aspx:user:pass\nhttps://host/rdweb|user|pass"
            }
            MixedService::Owa => {
                "https://mail.contoso.com/owa/:email@domain.com:password\nhttps://host/owa|user|pass"
            }
            MixedService::PhpMyAdmin | MixedService::Adminer | MixedService::PhpPgAdmin => {
                "https://host/phpmyadmin/:user:pass\nhttps://host:8080/adminer.php|root|secret"
            }
            MixedService::Redmine | MixedService::Jira => {
                "https://redmine.example.com/login:user:pass\nhttps://jira.atlassian.net|user|pass"
            }
            MixedService::GitLab => {
                "https://gitlab.com/user:token_or_pass\nhttps://gitlab.example.com|user|pass"
            }
            MixedService::Kibana
            | MixedService::Grafana
            | MixedService::Zabbix
            | MixedService::Zimbra
            | MixedService::Drupal
            | MixedService::SonarQube
            | MixedService::Mattermost => {
                "https://host/app/:user:pass\nhttps://host/path|user|pass"
            }
            _ => {
                "https://host[:port]/path:user:password\nhttps://host|user|pass\nhttp://host login:user pass"
            }
        }
    }
}

#[derive(Debug, Clone)]
pub struct MixedTarget {
    pub service: MixedService,
    pub credential: Credential,
    pub source_line: String,
}

#[derive(Debug, Clone, Default)]
pub struct MixedParseSummary {
    pub targets: Vec<MixedTarget>,
    pub skipped: usize,
    pub unclassified: usize,
    pub unclassified_lines: Vec<String>,
    pub total_lines: usize,
}

pub fn is_rdweb_url(url: &Url) -> bool {
    url.path().to_ascii_lowercase().contains("/rdweb")
}

fn try_rdweb(line: &str) -> Result<Credential> {
    if !line.to_ascii_lowercase().contains("rdweb") {
        anyhow::bail!("not rdweb");
    }
    let cred = parse_fortinet_line(line)?;
    if is_rdweb_url(&cred.url) {
        Ok(cred)
    } else {
        anyhow::bail!("not rdweb url");
    }
}

fn try_phpmyadmin(line: &str) -> Result<Credential> {
    use crate::parse_credential_line;
    let cred = parse_credential_line(line)?;
    let path = cred.url.path().to_ascii_lowercase();
    let host = cred.url.host_str().unwrap_or("").to_ascii_lowercase();
    if path.contains("phpmyadmin") || host.contains("phpmyadmin") {
        Ok(cred)
    } else {
        anyhow::bail!("not phpmyadmin");
    }
}

type ParseFn = fn(&str) -> Result<Credential>;

fn classify_parsed(service: MixedService, cred: Credential, source: &str) -> MixedTarget {
    MixedTarget {
        service,
        credential: cred,
        source_line: source.to_string(),
    }
}

pub fn classify_mixed_line(line: &str) -> Result<MixedTarget> {
    let source = preprocess_combo_line(line);
    if source.is_empty() || source.starts_with('#') {
        anyhow::bail!("empty line");
    }

    let attempts: &[(MixedService, ParseFn)] = &[
        (MixedService::RdWeb, try_rdweb as ParseFn),
        (MixedService::Owa, parse_owa_line as ParseFn),
        (MixedService::Kibana, parse_kibana_line as ParseFn),
        (MixedService::Grafana, parse_grafana_line as ParseFn),
        (MixedService::SonarQube, parse_sonarqube_line as ParseFn),
        (MixedService::Mattermost, parse_mattermost_line as ParseFn),
        (MixedService::Zabbix, parse_zabbix_line as ParseFn),
        (MixedService::Zimbra, parse_zimbra_line as ParseFn),
        (MixedService::Drupal, parse_drupal_line as ParseFn),
        (MixedService::Redmine, parse_redmine_line as ParseFn),
        (MixedService::Jira, parse_jira_line as ParseFn),
        (MixedService::GitLab, parse_gitlab_line as ParseFn),
        (MixedService::Jenkins, parse_jenkins_line as ParseFn),
        (MixedService::Bitrix, parse_bitrix_line as ParseFn),
        (MixedService::XWiki, parse_xwiki_line as ParseFn),
        (MixedService::Bamboo, parse_bamboo_line as ParseFn),
        (MixedService::PhpPgAdmin, parse_phppgadmin_line as ParseFn),
        (MixedService::Adminer, parse_adminer_line as ParseFn),
        (MixedService::PhpMyAdmin, try_phpmyadmin as ParseFn),
    ];

    for (service, parse) in attempts {
        if let Ok(cred) = parse(&source) {
            return Ok(classify_parsed(*service, cred, &source));
        }
    }
    anyhow::bail!("could not classify service")
}

pub fn parse_mixed_list_summary(content: &str) -> MixedParseSummary {
    let mut targets = Vec::new();
    let mut skipped = 0usize;
    let mut unclassified = 0usize;
    let mut unclassified_lines = Vec::new();
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match classify_mixed_line(trimmed) {
            Ok(t) => targets.push(t),
            Err(_) => {
                unclassified += 1;
                skipped += 1;
                unclassified_lines.push(trimmed.to_string());
            }
        }
    }

    MixedParseSummary {
        targets,
        skipped,
        unclassified,
        unclassified_lines,
        total_lines,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use url::Url;

    #[test]
    fn is_rdweb_url_detects_path() {
        let u = Url::parse("https://host/RDWeb/Pages/en-US/login.aspx").unwrap();
        assert!(is_rdweb_url(&u));
        let other = Url::parse("https://host/fortinet/login").unwrap();
        assert!(!is_rdweb_url(&other));
    }

    #[test]
    fn rdweb_fixture_lines_classify_as_rdweb() {
        let content = include_str!("../../../tests/fixtures/rdweb.txt");
        let summary = parse_mixed_list_summary(content);
        assert_eq!(
            summary.targets.len(),
            10,
            "expected 10 RDWeb targets, got {} unclassified={}",
            summary.targets.len(),
            summary.unclassified
        );
        assert!(summary.unclassified_lines.is_empty());
        for t in &summary.targets {
            assert_eq!(t.service, MixedService::RdWeb);
            assert!(is_rdweb_url(&t.credential.url));
        }
    }
}
