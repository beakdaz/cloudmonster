//! Core types and list parsing for phpMyAdmin tooling.
//!
//! Source inspiration: phpMyAdmin Exploiter list format and sqldump-tool input handling.

mod adminer_parser;
mod bamboo_parser;
mod bitbucket_parser;
mod bitrix_parser;
mod citrix_parser;
mod cloud;
mod cloud_download;
mod cloud_parser;
mod credential_line;
mod fortinet_parser;
mod gitlab_parser;
mod jenkins_parser;
mod jira_parser;
mod appflowy_parser;
mod confluence_parser;
mod opencart_parser;
mod redmine_parser;
mod roamresearch_parser;
mod secondbrain_parser;
mod snowflake_parser;
mod note_export_service;
mod crm_export_service;
mod workflowy_parser;
mod service_combo;
mod services_add;
mod mega_parser;
mod mixed_list;
mod xwiki_parser;
mod media;
mod output;
mod parser;
mod phppgadmin_parser;
mod slack_parser;
mod types;

pub use adminer_parser::{
    is_adminer_url, parse_adminer_line, parse_adminer_list_summary, AdminerParseSummary,
};
pub use bitbucket_parser::{
    parse_bitbucket_line, parse_bitbucket_list_summary, BitbucketParseSummary,
};
pub use bamboo_parser::{parse_bamboo_line, parse_bamboo_list_summary, BambooParseSummary};
pub use bitrix_parser::{parse_bitrix_line, parse_bitrix_list_summary, BitrixParseSummary};
pub use citrix_parser::{
    citrix_portal_origin, is_citrix_vpn_url, parse_citrix_line, parse_citrix_list_summary,
    CitrixParseSummary,
};
pub use cloud::{CloudIpStack, CloudProvider, CloudProviderSpec, CloudTransport};
pub use cloud_download::CloudDownloadFilter;
pub use cloud_parser::{
    parse_cloud_line, parse_cloud_list_summary, CloudParseSummary,
};
pub use fortinet_parser::{
    fortinet_appliance_base, parse_fortinet_line, parse_fortinet_list_summary, FortinetParseSummary,
};
pub use gitlab_parser::{parse_gitlab_line, parse_gitlab_list_summary, GitLabParseSummary};
pub use jenkins_parser::{parse_jenkins_line, parse_jenkins_list_summary, JenkinsParseSummary};
pub use jira_parser::{parse_jira_line, parse_jira_list_summary, JiraParseSummary};
pub use appflowy_parser::{parse_appflowy_line, parse_appflowy_list_summary, AppflowyParseSummary};
pub use confluence_parser::{
    parse_confluence_line, parse_confluence_list_summary, ConfluenceParseSummary,
};
pub use opencart_parser::{parse_opencart_line, parse_opencart_list_summary, OpencartParseSummary};
pub use redmine_parser::{parse_redmine_line, parse_redmine_list_summary, RedmineParseSummary};
pub use roamresearch_parser::{
    parse_roamresearch_line, parse_roamresearch_list_summary, RoamresearchParseSummary,
};
pub use secondbrain_parser::{
    parse_secondbrain_line, parse_secondbrain_list_summary, SecondbrainParseSummary,
};
pub use workflowy_parser::{
    parse_workflowy_line, parse_workflowy_list_summary, WorkflowyParseSummary,
};
pub use note_export_service::{
    parse_note_account_line, parse_note_export_line, parse_note_export_list_summary,
    parse_account_line_with_optional_url, split_login_or_email_password, NoteExportParseSummary,
    NoteExportService,
};
pub use crm_export_service::{
    parse_crm_account_line, parse_crm_export_list_summary, CrmExportParseSummary, CrmExportService,
};
pub use snowflake_parser::{
    parse_snowflake_line, parse_snowflake_list_summary, snowflake_account_from_url,
    snowflake_url_re_matches, SnowflakeParseSummary,
};
pub use service_combo::ServiceParseSummary;
pub use services_add::{
    parse_drupal_line, parse_drupal_list_summary, parse_grafana_line, parse_grafana_list_summary,
    parse_kibana_line, parse_kibana_list_summary, parse_mattermost_line, parse_mattermost_list_summary,
    parse_owa_line, parse_owa_list_summary, parse_service_line, parse_service_list_summary,
    parse_sonarqube_line, parse_sonarqube_list_summary, parse_zabbix_line, parse_zabbix_list_summary,
    parse_zimbra_line, parse_zimbra_list_summary, AddServiceKind,
};
pub use mega_parser::{
    is_mega_email_account, parse_mega_line, parse_mega_list_summary, MegaParseSummary,
};
pub use xwiki_parser::{
    is_plausible_xwiki_credential, is_xwiki_host, is_xwiki_wiki_target, parse_xwiki_line,
    parse_xwiki_list_summary, XWikiParseSummary,
};
pub use slack_parser::{
    is_app_slack_host, is_named_workspace_slack_host, is_slack_host, looks_like_slack_api_token,
    parse_slack_line, parse_slack_list_summary, SlackParseSummary,
};
pub use phppgadmin_parser::{
    is_pgadmin_url, parse_phppgadmin_line, parse_phppgadmin_list_summary, PhpPgAdminParseSummary,
};
pub use media::is_excluded_media_filename;
pub use output::{extension_bucket, output_file_path, output_file_path_in_bucket, output_relative_href};
pub use mixed_list::{
    classify_mixed_line, is_rdweb_url, parse_mixed_list_summary, MixedParseSummary, MixedService,
    MixedTarget,
};
pub use parser::{parse_credential_line, parse_credential_list, parse_credential_list_summary, ParseSummary};
pub use credential_line::{parse_host_colon_user_pass, with_default_scheme};
pub use types::{Credential, ScanResult, ScanStatus};
