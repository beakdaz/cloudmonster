//! Bamboo list format: `https://bamboo.example.com user:pass` — hostname must contain `bamboo`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct BambooParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_bamboo: usize,
    pub total_lines: usize,
}

pub fn repair_glued_port_in_host(host: &str) -> String {
    let lower = host.to_ascii_lowercase();
    for suffix_len in [5usize, 4] {
        if host.len() <= suffix_len + 2 {
            continue;
        }
        let split = host.len() - suffix_len;
        let port_part = &host[split..];
        if !port_part.chars().all(|c| c.is_ascii_digit()) {
            continue;
        }
        let before = &host[..split];
        if before.ends_with('.') || lower.contains(".co.") || lower.contains(".com") {
            return format!("{before}:{port_part}");
        }
    }
    host.to_string()
}

fn host_has_glued_port(host: &str) -> bool {
    repair_glued_port_in_host(host) != host
}

pub fn is_bamboo_host(url: &Url) -> bool {
    url.host_str()
        .unwrap_or("")
        .to_ascii_lowercase()
        .contains("bamboo")
}

pub fn parse_bamboo_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_bamboo_host(&cred.url) {
        bail!(
            "host `{}` does not look like Bamboo (hostname must contain `bamboo`)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_bamboo_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_bamboo_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_bamboo_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_bamboo_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    if let Some(after_scheme) = candidate.split("://").nth(1) {
        let host_part = after_scheme.split('/').next().unwrap_or(after_scheme);
        if !host_part.contains(':') && host_has_glued_port(host_part) {
            let fixed_host = repair_glued_port_in_host(host_part);
            candidate = candidate.replacen(host_part, &fixed_host, 1);
        }
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_bamboo_list_summary(content: &str) -> Result<BambooParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_bamboo = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_bamboo_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_bamboo += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(BambooParseSummary {
        credentials,
        skipped,
        filtered_non_bamboo,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_storage_bamboo_s3_style() {
        let cred = parse_bamboo_line(
            "https://storage-bamboo.dev.masoffer.tech:akiait6estsky55qnzrq:SecretKeyValue",
        )
        .unwrap();
        assert_eq!(
            cred.url.host_str(),
            Some("storage-bamboo.dev.masoffer.tech")
        );
        assert_eq!(cred.username, "akiait6estsky55qnzrq");
    }

    #[test]
    fn parses_storage_bamboo_http_colon_and_space_forms() {
        let colon = parse_bamboo_line(
            "http://storage-bamboo.dev.masoffer.tech:AKIAIT6ESTSKY55QNZRQ:V29FcyJLPzhZijWwjiaHaa5D",
        )
        .unwrap();
        assert_eq!(colon.url.scheme(), "http");
        assert_eq!(colon.username, "AKIAIT6ESTSKY55QNZRQ");
        assert_eq!(colon.password, "V29FcyJLPzhZijWwjiaHaa5D");

        let spaced = parse_bamboo_line(
            "http://storage-bamboo.dev.masoffer.tech AKIAIT6ESTSKY55QNZRQ:V29FcyJLPzhZijWwjiaHaa5D",
        )
        .unwrap();
        assert_eq!(spaced.url.host_str(), colon.url.host_str());
        assert_eq!(spaced.username, colon.username);
        assert_eq!(spaced.password, colon.password);
    }

    #[test]
    fn parses_big_bamboo_org() {
        let cred =
            parse_bamboo_line("https://big-bamboo.org:oldclan9@gmail.com:jPy28P5Syncmima").unwrap();
        assert_eq!(cred.url.host_str(), Some("big-bamboo.org"));
    }

    #[test]
    fn repairs_glued_cpanel_port() {
        let cred =
            parse_bamboo_line("https://rambamboo.aserv.co.za2083:sanjeev:S@int0072796").unwrap();
        assert_eq!(cred.url.host_str(), Some("rambamboo.aserv.co.za"));
        assert_eq!(cred.url.port(), Some(2083));
    }

    #[test]
    fn parses_cloudapp_bamboo() {
        let cred = parse_bamboo_line(
            "https://agl-bamboo.cloudapp.net:agl-bamboo-admin:Welcome1",
        )
        .unwrap();
        assert_eq!(cred.url.host_str(), Some("agl-bamboo.cloudapp.net"));
    }
}
