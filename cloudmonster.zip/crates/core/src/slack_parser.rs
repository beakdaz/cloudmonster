//! Slack list format: `https://team.slack.com user@email.com:password`, `https://team.slack.com:username:password`, or `team.slack.com:xoxp-token:`

use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct SlackParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_slack: usize,
    pub total_lines: usize,
}

pub fn is_slack_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    if host.is_empty() {
        return false;
    }
    if host == "slack.com" || host.ends_with(".slack.com") {
        return host != "api.slack.com";
    }
    host == "app.slack.com"
}

/// `https://acme.slack.com/` — preferred for email/password (not `app.slack.com`).
pub fn is_named_workspace_slack_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    host.ends_with(".slack.com")
        && host != "app.slack.com"
        && host != "api.slack.com"
        && host != "slack.com"
}

/// Slack user/bot/session token (incl. `xoxe.xoxp-1-…` rotation format).
pub fn looks_like_slack_api_token(s: &str) -> bool {
    let t = s.trim();
    if t.starts_with("xoxp-")
        || t.starts_with("xoxb-")
        || t.starts_with("xoxc-")
        || t.starts_with("xoxe-")
        || t.starts_with("xoxa-")
        || t.starts_with("xoxs-")
    {
        return true;
    }
    // Enterprise / rotated: `xoxe.xoxp-1-…`
    t.starts_with("xoxe.") && t.contains("xoxp-")
}

pub fn is_app_slack_host(url: &Url) -> bool {
    url.host_str()
        .is_some_and(|h| h.eq_ignore_ascii_case("app.slack.com"))
}

pub fn parse_slack_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_slack_host(&cred.url) {
        bail!(
            "host `{}` does not look like Slack (use https://workspace.slack.com or app.slack.com)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_slack_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if !trimmed.contains("://") && trimmed.matches(':').count() >= 2 {
        if let Ok(cred) = parse_bare_colon_slack_line(trimmed) {
            return Ok(cred);
        }
    }

    parse_colon_service_line(trimmed)
}

/// `host:email:xoxe.xoxp-…` or `host:email:pass` without `https://` (combo lists).
fn parse_bare_colon_slack_line(line: &str) -> Result<Credential> {
    let (url_and_user, password) = line
        .rsplit_once(':')
        .context("expected host:username:secret")?;
    let (host_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected host:username:secret")?;
    if username.is_empty() {
        bail!("missing username");
    }

    let url = if host_part.contains("slack.com") {
        normalize_slack_url(host_part)?
    } else if looks_like_slack_api_token(password) {
        // Site in combo is not Slack; token still goes to auth.test via app.slack.com.
        normalize_slack_url("https://app.slack.com")?
    } else {
        bail!("host `{host_part}` is not Slack and secret is not a Slack token");
    };

    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_slack_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_slack_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }

    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    if host.ends_with(".slack.com") && host != "app.slack.com" {
        url.set_path("/");
    } else if host == "app.slack.com" {
        // keep client path for deep links if present
    } else if host == "slack.com" {
        url.set_path("/");
    }

    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_slack_list_summary(content: &str) -> Result<SlackParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_slack = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred)
                if is_slack_host(&cred.url)
                    || looks_like_slack_api_token(&cred.password)
                    || looks_like_slack_api_token(&cred.username) =>
            {
                credentials.push(cred)
            }
            Ok(_) => filtered_non_slack += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(SlackParseSummary {
        credentials,
        skipped,
        filtered_non_slack,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_combo_host_with_xoxe_token() {
        let cred = parse_slack_line(
            "gnews.io:wangsachiel@gmail.com:xoxe.xoxp-1-Mi0yLTg2NjQ4MjkzODI2NDctTEST",
        )
        .unwrap();
        assert_eq!(cred.url.host_str(), Some("app.slack.com"));
        assert_eq!(cred.username, "wangsachiel@gmail.com");
        assert!(looks_like_slack_api_token(&cred.password));
    }

    #[test]
    fn parses_colon_username_password() {
        let cred =
            parse_slack_line("https://acme.slack.com:grace:Secret123").unwrap();
        assert_eq!(cred.url.as_str(), "https://acme.slack.com/");
        assert_eq!(cred.username, "grace");
        assert_eq!(cred.password, "Secret123");
    }

    #[test]
    fn parses_workspace_url() {
        let cred =
            parse_slack_line("https://acme.slack.com user@acme.com:Secret123").unwrap();
        assert_eq!(cred.url.as_str(), "https://acme.slack.com/");
        assert_eq!(cred.username, "user@acme.com");
    }

    #[test]
    fn parses_token_colon_line() {
        let cred = parse_slack_line(
            "https://acme.slack.com:xoxp-1234567890-abcdef:",
        )
        .unwrap();
        assert_eq!(cred.username, "xoxp-1234567890-abcdef");
    }

    #[test]
    fn strips_signin_path() {
        let cred = parse_slack_line(
            "https://acme.slack.com/signin#/signin user@acme.com:pass",
        )
        .unwrap();
        assert_eq!(cred.url.path(), "/");
    }
}
