//! Run output layout: `{run_output_dir}/{kind}_{host}/{extension}/{leaf_filename}`.

use std::path::{Path, PathBuf};

pub fn extension_bucket(leaf_filename: &str) -> String {
    Path::new(leaf_filename)
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_ascii_lowercase())
        .filter(|e| !e.is_empty())
        .unwrap_or_else(|| "other".to_string())
}

pub fn output_file_path(site_root: &Path, leaf_filename: &str) -> PathBuf {
    site_root
        .join(extension_bucket(leaf_filename))
        .join(leaf_filename)
}

pub fn output_file_path_in_bucket(
    site_root: &Path,
    leaf_filename: &str,
    bucket: &str,
) -> PathBuf {
    site_root.join(bucket).join(leaf_filename)
}

/// Relative URL from one exported leaf file to another (extension subfolders).
pub fn output_relative_href(from_leaf: &str, to_leaf: &str) -> String {
    let from_bucket = extension_bucket(from_leaf);
    let to_bucket = extension_bucket(to_leaf);
    if from_bucket == to_bucket {
        to_leaf.to_string()
    } else {
        format!("../{to_bucket}/{to_leaf}")
    }
}
