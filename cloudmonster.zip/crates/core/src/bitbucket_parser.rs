//! Bitbucket Server list format: `https://bitbucket.host user:pass` — self-hosted host must contain `bitbucket` or `stash`.
//! `bitbucket.org` (Cloud) and glued hosts like `bitbucket.orguser` are filtered with a clear reason.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

const BITBUCKET_ORG: &str = "bitbucket.org";

pub const BITBUCKET_CLOUD_SKIP_MSG: &str =
    "bitbucket.org is Bitbucket Cloud (not supported — use self-hosted bitbucket.company.com; glued org hosts like bitbucket.orguser are fixed at parse time)";

#[derive(Debug, Clone, Default)]
pub struct BitbucketParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_bitbucket: usize,
    pub filtered_cloud: usize,
    pub total_lines: usize,
}

/// Self-hosted Bitbucket Server / Stash only (not Cloud).
pub fn is_bitbucket_server_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    if host.is_empty() || host == BITBUCKET_ORG {
        return false;
    }
    if is_glued_bitbucket_org_host(&host).is_some() {
        return false;
    }
    host.contains("bitbucket") || host.contains("stash")
}

pub fn repair_bitbucket_org_glued_host(cred: &mut Credential) -> bool {
    let Some(host) = cred.url.host_str() else {
        return false;
    };
    let lower = host.to_ascii_lowercase();
    let Some(suffix) = is_glued_bitbucket_org_host(&lower) else {
        return false;
    };
    cred.url.set_host(Some(BITBUCKET_ORG)).ok();
    cred.username = suffix;
    true
}

fn is_glued_bitbucket_org_host(host_lower: &str) -> Option<String> {
    if host_lower == BITBUCKET_ORG {
        return None;
    }
    if !host_lower.starts_with(BITBUCKET_ORG) {
        return None;
    }
    let suffix = &host_lower[BITBUCKET_ORG.len()..];
    if suffix.is_empty() {
        return None;
    }
    if !suffix
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-' || c == '.')
    {
        return None;
    }
    let suffix = suffix.trim_end_matches('.').to_string();
    if suffix.is_empty() {
        return None;
    }
    Some(suffix)
}

fn finalize_bitbucket_credential(cred: &mut Credential) -> CredentialKind {
    repair_bitbucket_org_glued_host(cred);
    let host = cred.url.host_str().unwrap_or("").to_ascii_lowercase();
    if host == BITBUCKET_ORG {
        return CredentialKind::Cloud;
    }
    if is_bitbucket_server_host(&cred.url) {
        CredentialKind::Server
    } else {
        CredentialKind::Other
    }
}

#[derive(Copy, Clone, Eq, PartialEq, Debug)]
enum CredentialKind {
    Server,
    Cloud,
    Other,
}

pub fn parse_bitbucket_line(line: &str) -> Result<Credential> {
    let mut cred = parse_service_line(line)?;
    match finalize_bitbucket_credential(&mut cred) {
        CredentialKind::Server => Ok(cred),
        CredentialKind::Cloud => bail!("{BITBUCKET_CLOUD_SKIP_MSG}"),
        CredentialKind::Other => bail!(
            "host `{}` does not look like Bitbucket Server (hostname must contain `bitbucket` or `stash`)",
            cred.url.host_str().unwrap_or("?")
        ),
    }
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_bitbucket_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_bitbucket_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_bitbucket_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_bitbucket_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    if let Some(scheme_idx) = candidate.find("://") {
        let after = &candidate[scheme_idx + 3..];
        if let Some(slash) = after.find('/') {
            let keep = &candidate[..scheme_idx + 3 + slash];
            candidate = keep.to_string();
        }
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_bitbucket_list_summary(content: &str) -> Result<BitbucketParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_bitbucket = 0usize;
    let mut filtered_cloud = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(mut cred) => match finalize_bitbucket_credential(&mut cred) {
                CredentialKind::Server => credentials.push(cred),
                CredentialKind::Cloud => filtered_cloud += 1,
                CredentialKind::Other => filtered_non_bitbucket += 1,
            },
            Err(_) => skipped += 1,
        }
    }

    Ok(BitbucketParseSummary {
        credentials,
        skipped,
        filtered_non_bitbucket,
        filtered_cloud,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_geniusmindzone_host() {
        let cred = parse_bitbucket_line("https://bitbucket.geniusmindzone.com admin:secret").unwrap();
        assert_eq!(
            cred.url.as_str(),
            "https://bitbucket.geniusmindzone.com/"
        );
        assert_eq!(cred.username, "admin");
        assert_eq!(cred.password, "secret");
    }

    #[test]
    fn rejects_gitlab_host() {
        assert!(parse_bitbucket_line("https://gitlab.example.com:user:pass").is_err());
    }

    #[test]
    fn filters_mixed_list() {
        let list = "\
https://gitlab.example.com:alice:secret
https://bitbucket.geniusmindzone.com:bob:pass2
";
        let summary = parse_bitbucket_list_summary(list).unwrap();
        assert_eq!(summary.credentials.len(), 1);
        assert_eq!(summary.filtered_non_bitbucket, 1);
    }

    #[test]
    fn filters_bitbucket_cloud_colon_line() {
        let summary = parse_bitbucket_list_summary(
            "https://bitbucket.org:alice:secret\n",
        )
        .unwrap();
        assert_eq!(summary.credentials.len(), 0);
        assert_eq!(summary.filtered_cloud, 1);
    }

    #[test]
    fn filters_glued_org_username_without_network() {
        let summary = parse_bitbucket_list_summary(
            "https://bitbucket.orglalit:kumar:Lalit@4960\n",
        )
        .unwrap();
        assert_eq!(summary.credentials.len(), 0);
        assert_eq!(summary.filtered_cloud, 1);
    }

    #[test]
    fn repairs_glued_org_username_field() {
        let mut cred = parse_service_line("https://bitbucket.orgjarrod:davis:shardboy3").unwrap();
        assert!(repair_bitbucket_org_glued_host(&mut cred));
        assert_eq!(cred.url.host_str(), Some(BITBUCKET_ORG));
        assert_eq!(cred.username, "jarrod");
        assert_eq!(cred.password, "shardboy3");
    }

    #[test]
    fn filters_glued_org_with_trailing_dot_in_username() {
        let summary = parse_bitbucket_list_summary(
            "https://bitbucket.orgleod.:stampede:Leo1991{}\n",
        )
        .unwrap();
        assert_eq!(summary.credentials.len(), 0);
        assert_eq!(summary.filtered_cloud, 1);
    }
}
