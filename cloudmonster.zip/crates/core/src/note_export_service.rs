//! Note / task SaaS — combo lists: **`email:password`**, **`login:password`**, or **`url` + cred** / **`url:cred`**.

use crate::cloud::CloudProvider;
use crate::credential_line::with_default_scheme;
use crate::service_combo::{parse_colon_url_line, preprocess_combo_line, reject_common_garbage};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

fn normalize_saas_url(raw: &str) -> Result<Url> {
    let candidate = with_default_scheme(raw.trim(), "https");
    Url::parse(&candidate).context("invalid url")
}

/// Optional URL prefix, then `email:password` or `login:password` (password may contain `:`).
pub fn parse_account_line_with_optional_url(line: &str, default_origin: &str) -> Result<Credential> {
    let trimmed = preprocess_combo_line(line);
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    reject_common_garbage(&trimmed).ok();

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let url_part = trimmed[..idx].trim();
        let cred_part = trimmed[idx..].trim();
        if !url_part.is_empty()
            && !cred_part.is_empty()
            && (url_part.contains("://") || url_part.contains('.'))
        {
            let (username, password) = split_login_or_email_password(cred_part)?;
            let url = normalize_saas_url(url_part)?;
            return Ok(Credential {
                url,
                username,
                password,
            });
        }
    }

    if trimmed.contains("://") {
        if trimmed.contains('@') {
            if let Ok(cred) = parse_url_colon_email_password_line(&trimmed) {
                return Ok(cred);
            }
        }
        if let Ok(cred) = parse_colon_url_line(&trimmed, &normalize_saas_url) {
            return Ok(cred);
        }
    }

    let (username, password) = split_login_or_email_password(&trimmed)?;
    let url = Url::parse(default_origin).context("service base url")?;
    Ok(Credential {
        url,
        username,
        password,
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NoteExportService {
    Obsidian,
    Dynalist,
    Capacities,
    Gnotes,
    Joplin,
    Kortex,
    Mindlog,
    Notejoy,
    Notesnook,
    StandardNotes,
    Todoist,
    Turtl,
    Zotero,
}

impl NoteExportService {
    pub const ALL: [Self; 13] = [
        Self::Obsidian,
        Self::Dynalist,
        Self::Capacities,
        Self::Gnotes,
        Self::Joplin,
        Self::Kortex,
        Self::Mindlog,
        Self::Notejoy,
        Self::Notesnook,
        Self::StandardNotes,
        Self::Todoist,
        Self::Turtl,
        Self::Zotero,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Self::Obsidian => "Obsidian",
            Self::Dynalist => "Dynalist",
            Self::Capacities => "Capacities",
            Self::Gnotes => "GNotes",
            Self::Joplin => "Joplin",
            Self::Kortex => "Kortex",
            Self::Mindlog => "Mindlog",
            Self::Notejoy => "Notejoy",
            Self::Notesnook => "Notesnook",
            Self::StandardNotes => "Standard Notes",
            Self::Todoist => "Todoist",
            Self::Turtl => "Turtl",
            Self::Zotero => "Zotero",
        }
    }

    pub fn output_slug(self) -> &'static str {
        match self {
            Self::Obsidian => "obsidian",
            Self::Dynalist => "dynalist",
            Self::Capacities => "capacities",
            Self::Gnotes => "gnotes",
            Self::Joplin => "joplin",
            Self::Kortex => "kortex",
            Self::Mindlog => "mindlog",
            Self::Notejoy => "notejoy",
            Self::Notesnook => "notesnook",
            Self::StandardNotes => "standardnotes",
            Self::Todoist => "todoist",
            Self::Turtl => "turtl",
            Self::Zotero => "zotero",
        }
    }

    pub fn default_origin(self) -> &'static str {
        match self {
            Self::Obsidian => "https://obsidian.md/",
            Self::Dynalist => "https://dynalist.io/",
            Self::Capacities => "https://app.capacities.io/",
            Self::Gnotes => "https://www.gnotes.me/",
            Self::Joplin => "https://joplincloud.com/",
            Self::Kortex => "https://app.kortex.co/",
            Self::Mindlog => "https://mindlog.app/",
            Self::Notejoy => "https://notejoy.com/",
            Self::Notesnook => "https://app.notesnook.com/",
            Self::StandardNotes => "https://app.standardnotes.com/",
            Self::Todoist => "https://todoist.com/",
            Self::Turtl => "https://api.turtlapp.com/",
            Self::Zotero => "https://www.zotero.org/",
        }
    }

    pub fn cloud_provider(self) -> CloudProvider {
        match self {
            Self::Obsidian => CloudProvider::Obsidian,
            Self::Dynalist => CloudProvider::Dynalist,
            Self::Capacities => CloudProvider::Capacities,
            Self::Gnotes => CloudProvider::Gnotes,
            Self::Joplin => CloudProvider::Joplin,
            Self::Kortex => CloudProvider::Kortex,
            Self::Mindlog => CloudProvider::Mindlog,
            Self::Notejoy => CloudProvider::Notejoy,
            Self::Notesnook => CloudProvider::Notesnook,
            Self::StandardNotes => CloudProvider::StandardNotes,
            Self::Todoist => CloudProvider::Todoist,
            Self::Turtl => CloudProvider::Turtl,
            Self::Zotero => CloudProvider::Zotero,
        }
    }

    pub fn from_cloud_provider(p: CloudProvider) -> Option<Self> {
        Some(match p {
            CloudProvider::Obsidian => Self::Obsidian,
            CloudProvider::Dynalist => Self::Dynalist,
            CloudProvider::Capacities => Self::Capacities,
            CloudProvider::Gnotes => Self::Gnotes,
            CloudProvider::Joplin => Self::Joplin,
            CloudProvider::Kortex => Self::Kortex,
            CloudProvider::Mindlog => Self::Mindlog,
            CloudProvider::Notejoy => Self::Notejoy,
            CloudProvider::Notesnook => Self::Notesnook,
            CloudProvider::StandardNotes => Self::StandardNotes,
            CloudProvider::Todoist => Self::Todoist,
            CloudProvider::Turtl => Self::Turtl,
            CloudProvider::Zotero => Self::Zotero,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone)]
pub struct NoteExportParseSummary {
    pub service: NoteExportService,
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    /// Legacy field (always 0 — lists are not URL-filtered).
    pub filtered_wrong_host: usize,
    pub total_lines: usize,
}

/// `https://host[:port][/path]:email@domain:password` (password may contain `:`).
fn parse_url_colon_email_password_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url with scheme")?;
    let scheme = &line[..scheme_end];
    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }
    let rest = &line[scheme_end..];
    let at = rest.find('@').context("expected email in credential part")?;
    let before_at = &rest[..at];
    let colon = before_at
        .rfind(':')
        .context("expected url:email:password")?;
    let url_part = &rest[..colon];
    let cred_part = &rest[colon + 1..];
    let (username, password) = split_login_or_email_password(cred_part)?;
    let url = normalize_saas_url(&format!("{scheme}{url_part}"))?;
    Ok(Credential {
        url,
        username,
        password,
    })
}

/// Split `login:password` or `email@domain:password` (password may contain `:`).
pub fn split_login_or_email_password(line: &str) -> Result<(String, String)> {
    let trimmed = line.trim();
    if trimmed.is_empty() {
        bail!("empty line");
    }
    if trimmed.contains('@') {
        let at = trimmed.find('@').context("missing @")?;
        let after_at = &trimmed[at..];
        let colon = after_at
            .find(':')
            .context("expected email:password (colon after domain)")?;
        let split_at = at + colon;
        let login = trimmed[..split_at].trim().to_string();
        let password = trimmed[split_at + 1..].trim().to_string();
        if login.is_empty() || !login.contains('@') || password.is_empty() {
            bail!("invalid email:password");
        }
        return Ok((login, password));
    }
    let colon = trimmed.find(':').context("expected login:password")?;
    let login = trimmed[..colon].trim().to_string();
    let password = trimmed[colon + 1..].trim().to_string();
    if login.is_empty() || password.is_empty() {
        bail!("missing login or password");
    }
    Ok((login, password))
}

pub fn parse_note_account_line(service: NoteExportService, line: &str) -> Result<Credential> {
    parse_account_line_with_optional_url(line, service.default_origin())
}

pub fn parse_note_export_line(service: NoteExportService, line: &str) -> Result<Credential> {
    parse_note_account_line(service, line)
}

pub fn parse_note_export_list_summary(
    service: NoteExportService,
    content: &str,
) -> Result<NoteExportParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_note_account_line(service, trimmed) {
            Ok(cred) => credentials.push(cred),
            Err(_) => skipped += 1,
        }
    }

    Ok(NoteExportParseSummary {
        service,
        credentials,
        skipped,
        filtered_wrong_host: 0,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn email_password_with_colon_in_pass() {
        let (u, p) = split_login_or_email_password("a@b.com:pass:word").unwrap();
        assert_eq!(u, "a@b.com");
        assert_eq!(p, "pass:word");
    }

    #[test]
    fn login_password() {
        let cred =
            parse_note_account_line(NoteExportService::Todoist, "myuser:secret").unwrap();
        assert_eq!(cred.username, "myuser");
        assert_eq!(cred.password, "secret");
        assert!(cred.url.as_str().contains("todoist"));
    }

    #[test]
    fn url_space_email_password() {
        let cred = parse_note_account_line(
            NoteExportService::Todoist,
            "https://todoist.com user@mail.com:secret",
        )
        .unwrap();
        assert_eq!(cred.username, "user@mail.com");
        assert_eq!(cred.password, "secret");
        assert!(cred.url.as_str().contains("todoist"));
    }

    #[test]
    fn url_colon_email_password() {
        let cred = parse_note_account_line(
            NoteExportService::Todoist,
            "https://todoist.com:user@mail.com:pass:word",
        )
        .unwrap();
        assert_eq!(cred.username, "user@mail.com");
        assert_eq!(cred.password, "pass:word");
    }
}
