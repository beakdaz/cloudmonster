//! Jenkins list format: `https://jenkins.host user:pass` — host must contain `jenkins`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct JenkinsParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_jenkins: usize,
    pub total_lines: usize,
}

pub fn is_jenkins_host(url: &Url) -> bool {
    url.host_str()
        .unwrap_or("")
        .to_ascii_lowercase()
        .contains("jenkins")
}

pub fn parse_jenkins_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_jenkins_host(&cred.url) {
        bail!(
            "host `{}` does not look like Jenkins (hostname must contain `jenkins`)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_jenkins_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_jenkins_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_jenkins_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    // First colon separates username and password (password may contain ':').
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_jenkins_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_jenkins_list_summary(content: &str) -> Result<JenkinsParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_jenkins = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_jenkins_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_jenkins += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(JenkinsParseSummary {
        credentials,
        skipped,
        filtered_non_jenkins,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_space_separated_jenkins_line() {
        let cred =
            parse_jenkins_line("https://jenkins.cosium.dev vducheler:007Caca666").unwrap();
        assert_eq!(cred.url.as_str(), "https://jenkins.cosium.dev/");
        assert_eq!(cred.username, "vducheler");
    }

    #[test]
    fn parses_url_with_port_and_login_path() {
        let cred =
            parse_jenkins_line("https://jenkins.ostaapp.com:8080/login:Brontoo:Brontoo").unwrap();
        assert_eq!(cred.url.as_str(), "https://jenkins.ostaapp.com:8080/");
        assert_eq!(cred.username, "Brontoo");
    }

    #[test]
    fn rejects_non_jenkins_host() {
        assert!(parse_jenkins_line(
            "https://tfsbillpay.com:jenkins.c98188@gmail.com:Businessonly41$"
        )
        .is_err());
    }

    #[test]
    fn parses_user_colon_lines() {
        let cases = [
            (
                "https://jenkins.cova.africa:cova:Cova@2024",
                "https://jenkins.cova.africa/",
                "cova",
                "Cova@2024",
            ),
            (
                "https://jenkins.rigil.net:jenkins-prateek:Rigil.1234",
                "https://jenkins.rigil.net/",
                "jenkins-prateek",
                "Rigil.1234",
            ),
            (
                "https://jenkins.komatsupartsu.com:trueapex-dev:Nid2NenImyooHerc^",
                "https://jenkins.komatsupartsu.com/",
                "trueapex-dev",
                "Nid2NenImyooHerc^",
            ),
        ];
        for (line, url, user, pass) in cases {
            let cred = parse_jenkins_line(line).unwrap();
            assert_eq!(cred.url.as_str(), url, "url for {line}");
            assert_eq!(cred.username, user, "user for {line}");
            assert_eq!(cred.password, pass, "pass for {line}");
        }
    }

    #[test]
    fn strips_setup_wizard_path() {
        let cred = parse_jenkins_line(
            "https://jenkins.starcam.com:8080/setupWizard/setupWizardFirstUser jenkins_admin::4slZjx~-6$:5>x7kdQ&",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://jenkins.starcam.com:8080/");
        assert_eq!(cred.username, "jenkins_admin");
        assert_eq!(cred.password, ":4slZjx~-6$:5>x7kdQ&");
    }

    #[test]
    fn parses_phone_username_with_port() {
        let cred =
            parse_jenkins_line("https://jenkins.europolitan.se:8090:+37061204554:Gt9S5pk3QPkfqtb").unwrap();
        assert_eq!(cred.url.as_str(), "https://jenkins.europolitan.se:8090/");
        assert_eq!(cred.username, "+37061204554");
        assert_eq!(cred.password, "Gt9S5pk3QPkfqtb");
    }

    #[test]
    fn parses_host_with_numeric_port() {
        let cred =
            parse_jenkins_line("https://jenkins.example.com:8443:admin:secret").unwrap();
        assert_eq!(cred.url.port(), Some(8443));
        assert_eq!(cred.username, "admin");
        assert_eq!(cred.password, "secret");
    }

    #[test]
    fn rejects_port_as_username() {
        assert!(parse_jenkins_line("https://jenkins.example.com:8080:onlyuser").is_err());
    }

    #[test]
    fn filters_mixed_list() {
        let list = "\
https://tfsbillpay.com:jenkins.c98188@gmail.com:pass1
https://jenkins.cosium.dev:user:pass2
";
        let summary = parse_jenkins_list_summary(list).unwrap();
        assert_eq!(summary.credentials.len(), 1);
        assert_eq!(summary.filtered_non_jenkins, 1);
        assert_eq!(summary.credentials[0].url.host_str(), Some("jenkins.cosium.dev"));
    }
}
