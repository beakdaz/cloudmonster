// Source: phpMyAdmin Exploiter list format — `url:user:pass` / `url:login:password`.

use crate::types::Credential;
use anyhow::{Context, Result, bail};
use url::Url;

/// Parse one non-empty line in `url:username:password` format.
///
/// The URL may contain colons (scheme, port). Username and password are always
/// the last two colon-separated fields.
pub fn parse_credential_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    let parts: Vec<&str> = trimmed.split(':').collect();
    if parts.len() < 3 {
        bail!("expected url:username:password, got {parts:?}");
    }

    let password = parts[parts.len() - 1].to_string();
    let username = parts[parts.len() - 2].to_string();
    let url_part = parts[..parts.len() - 2].join(":");

    let url = normalize_url(&url_part).with_context(|| format!("invalid url: {url_part}"))?;

    Ok(Credential {
        url,
        username,
        password,
    })
}

/// Result of parsing a target list file.
#[derive(Debug, Clone, Default)]
pub struct ParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub total_lines: usize,
}

impl ParseSummary {
    pub fn is_empty(&self) -> bool {
        self.credentials.is_empty()
    }
}

/// Parse a full list file, skipping blanks, comments, and invalid lines (C# behavior).
pub fn parse_credential_list(content: &str) -> Result<Vec<Credential>> {
    Ok(parse_credential_list_summary(content)?.credentials)
}

/// Like [`parse_credential_list`] but also reports how many lines were skipped.
pub fn parse_credential_list_summary(content: &str) -> Result<ParseSummary> {
    let mut out = Vec::new();
    let mut skipped = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_credential_line(trimmed) {
            Ok(cred) => out.push(cred),
            Err(_) => skipped += 1,
        }
    }

    Ok(ParseSummary {
        credentials: out,
        skipped,
        total_lines,
    })
}

fn normalize_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if !candidate.contains("://") {
        candidate = format!("http://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    let path = url.path();
    if path.is_empty() || path == "/" {
        url.set_path("/");
    } else if !path.ends_with('/') {
        url.set_path(&format!("{path}/"));
    }
    Ok(url)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_simple_http_target() {
        let cred = parse_credential_line("http://10.0.0.1/phpmyadmin:root:secret").unwrap();
        assert_eq!(cred.username, "root");
        assert_eq!(cred.password, "secret");
        assert_eq!(cred.url.as_str(), "http://10.0.0.1/phpmyadmin/");
    }

    #[test]
    fn parses_url_with_port() {
        let cred = parse_credential_line("http://example.com:8080/pma:admin:secret").unwrap();
        assert_eq!(cred.username, "admin");
        assert_eq!(cred.password, "secret");
        assert_eq!(cred.url.as_str(), "http://example.com:8080/pma/");
    }

    #[test]
    fn adds_scheme_when_missing() {
        let cred = parse_credential_line("db.example.com/phpmyadmin:user:pass").unwrap();
        assert_eq!(cred.url.scheme(), "http");
        assert!(cred.url.as_str().contains("db.example.com/phpmyadmin"));
    }

    #[test]
    fn skips_comments_in_list() {
        let list = "# comment\nhttp://a/b:u:p\n\n";
        let creds = parse_credential_list(list).unwrap();
        assert_eq!(creds.len(), 1);
        assert_eq!(creds[0].username, "u");
    }

    #[test]
    fn skips_invalid_lines_like_csharp() {
        let list = "host/pma:user:pass\nnot-enough-colons\n:::remote::garbage\nother/db:u2:p2\n";
        let summary = parse_credential_list_summary(list).unwrap();
        assert_eq!(summary.credentials.len(), 2);
        assert_eq!(summary.skipped, 2);
    }

    #[test]
    fn parses_host_port_user_pass() {
        let cred = parse_credential_line("195.110.34.145:8081:root:astroast").unwrap();
        assert_eq!(cred.username, "root");
        assert_eq!(cred.url.as_str(), "http://195.110.34.145:8081/");
    }

    #[test]
    fn scan_status_labels() {
        use crate::ScanStatus;
        assert_eq!(ScanStatus::Valid.label(), "OK");
        assert_eq!(ScanStatus::Error.label(), "ERROR");
        assert_eq!(ScanStatus::Captcha.label(), "CAPTCHA");
        assert_eq!(ScanStatus::Valid.bucket_filename(), Some("Good.txt"));
    }
}
