//! FortiGate / Fortinet list format: `https://host:443:admin:password` or `https://host admin:pass`.
//! Hostname filter is loose (IPs and firewalls without "forti" in the name are accepted).

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct FortinetParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub total_lines: usize,
}

pub fn fortinet_appliance_base(url: &Url) -> Result<Url> {
    let mut base = url.clone();
    base.set_path("/");
    base.set_query(None);
    base.set_fragment(None);
    Ok(base)
}

pub fn parse_fortinet_line(line: &str) -> Result<Credential> {
    parse_service_line(line)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    if trimmed.contains('(') || trimmed.contains(')') {
        bail!("url contains invalid characters");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_fortinet_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_fortinet_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];
    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_fortinet_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_fortinet_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }
    let url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    Ok(url)
}

pub fn parse_fortinet_list_summary(content: &str) -> Result<FortinetParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) => credentials.push(cred),
            Err(_) => skipped += 1,
        }
    }

    Ok(FortinetParseSummary {
        credentials,
        skipped,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_ip_colon_line() {
        let cred = parse_fortinet_line("https://203.0.113.10:443:admin:Secret1!").unwrap();
        assert_eq!(cred.username, "admin");
        assert!(cred.url.host_str() == Some("203.0.113.10"));
    }

    #[test]
    fn parses_fortigate_host() {
        let cred =
            parse_fortinet_line("https://fgt.example.com/logincheck:admin:pass").unwrap();
        assert!(cred.url.path().contains("logincheck"));
    }
}
