//! Skip video/audio downloads (attachments, artifacts).

use std::path::Path;

const EXCLUDED_MEDIA_EXTENSIONS: &[&str] = &[
    // video
    "3gp", "3g2", "avi", "flv", "m4v", "mkv", "mov", "mp4", "mpeg", "mpg", "ogv", "webm", "wmv",
    // audio
    "aac", "aiff", "ape", "flac", "m4a", "mp3", "ogg", "opus", "wav", "wma",
];

pub fn is_excluded_media_filename(filename: &str) -> bool {
    Path::new(filename)
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| {
            let lower = e.to_ascii_lowercase();
            EXCLUDED_MEDIA_EXTENSIONS.iter().any(|&x| x == lower)
        })
        .unwrap_or(false)
}
