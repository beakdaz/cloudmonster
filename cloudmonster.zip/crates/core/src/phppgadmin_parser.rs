//! phpPgAdmin / pgAdmin list lines — mixed separators between URL and credentials.
//! Examples: `URL user:pass`, `URL:user:pass`, `URL|user:pass`, `URL;user:pass`, `URL user|pass`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct PhpPgAdminParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_pgadmin: usize,
    pub total_lines: usize,
}

pub fn is_pgadmin_url(url: &Url) -> bool {
    let path = url.path().to_ascii_lowercase();
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    path.contains("phppgadmin")
        || path.contains("pgadmin")
        || path.ends_with("redirect.php")
        || path.ends_with("servers.php")
        || path.ends_with("/gc/login.html")
        || host.contains("pgadmin")
        || path == "/"
}

pub fn parse_phppgadmin_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_pgadmin_url(&cred.url) {
        bail!(
            "url `{}` does not look like phpPgAdmin/pgAdmin",
            cred.url.as_str()
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    if trimmed.contains('(') || trimmed.contains(')') {
        bail!("url contains invalid characters");
    }

    if let Some((url_part, cred_part)) = split_url_and_credentials(trimmed) {
        let (username, password) = split_user_password_mixed(cred_part)?;
        let url = normalize_pgadmin_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let url_part = trimmed[..idx].trim();
        let cred_part = trimmed[idx..].trim();
        if !url_part.is_empty() && !cred_part.is_empty() {
            let (username, password) = split_user_password_mixed(cred_part)?;
            let url = normalize_pgadmin_url(url_part)?;
            return Ok(Credential {
                url,
                username,
                password,
            });
        }
    }

    if trimmed.contains("://") {
        return parse_colon_service_line(trimmed);
    }

    parse_host_colon_user_pass(trimmed, &normalize_pgadmin_url, true)
}

/// Split after a full URL using whitespace, `|`, `;`, or tab (not `:` — use colon-line parser).
fn split_url_and_credentials(line: &str) -> Option<(&str, &str)> {
    let scheme_end = line.find("://").map(|idx| idx + 3).unwrap_or(0);
    let mut best: Option<(usize, usize)> = None;

    for (i, ch) in line.char_indices() {
        if i < scheme_end {
            continue;
        }
        let cred_start = match ch {
            ' ' | '\t' | '\r' | '\n' => {
                let mut j = i;
                while j < line.len() && line.as_bytes()[j].is_ascii_whitespace() {
                    j += 1;
                }
                if j >= line.len() {
                    continue;
                }
                j
            }
            '|' | ';' => i + ch.len_utf8(),
            _ => continue,
        };
        let url_part = line[..i].trim_end();
        if url_part.is_empty() {
            continue;
        }
        if scheme_end > 0 && url_part.len() <= scheme_end.saturating_sub(3) {
            continue;
        }
        let cred_part = line[cred_start..].trim();
        if cred_part.is_empty() {
            continue;
        }
        match best {
            None => best = Some((i, cred_start)),
            Some((prev_i, _)) if i < prev_i => best = Some((i, cred_start)),
            _ => {}
        }
    }

    let (split_at, cred_start) = best?;
    Some((line[..split_at].trim_end(), line[cred_start..].trim()))
}

fn split_user_password_mixed(cred_part: &str) -> Result<(String, String)> {
    if let Ok(pair) = split_user_password(cred_part) {
        return Ok(pair);
    }
    for sep in ['|', ';', '\t'] {
        if let Some(idx) = cred_part.find(sep) {
            if idx > 0 && idx + 1 < cred_part.len() {
                return Ok((
                    cred_part[..idx].trim().to_string(),
                    cred_part[idx + 1..].trim().to_string(),
                ));
            }
        }
    }
    split_user_password(cred_part)
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_pgadmin_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_pgadmin_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }

    url.set_fragment(None);
    url.set_query(None);

    let path = url.path().to_string();
    let lower = path.to_ascii_lowercase();

    if lower.contains("/pgadmin4/") {
        url.set_path("/pgadmin4/browser/");
    } else if lower.ends_with("/pgadmin/user/signup.php") {
        let p = path.replace("signup.php", "login.php");
        url.set_path(&p);
    } else if lower.contains("/pgadmin/user/login.php") {
        // legacy pgAdmin PHP login — keep path
    } else if lower.contains("/pgadmin/login") && !lower.contains("pgadmin4") {
        url.set_path("/pgadmin4/login");
        url.set_query(Some("next=/pgadmin4/browser/"));
    } else if lower.ends_with("/pgadmin4/browser") {
        url.set_path("/pgadmin4/browser/");
    } else if lower.ends_with("redirect.php") || lower.ends_with("servers.php") {
        // keep full entry script path
    } else if lower.contains("phppgadmin") {
        if lower.ends_with("/phppgadmin") || lower.ends_with("/phppgadmin/") {
            url.set_path("/phppgadmin/redirect.php");
        }
    } else if lower.contains("/gc/login.html") {
        // custom login wrapper — keep path
    } else if path == "/" || path.is_empty() {
        url.set_path("/phppgadmin/redirect.php");
    }

    Ok(url)
}

pub fn parse_phppgadmin_list_summary(content: &str) -> Result<PhpPgAdminParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_pgadmin = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_pgadmin_url(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_pgadmin += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(PhpPgAdminParseSummary {
        credentials,
        skipped,
        filtered_non_pgadmin,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_redirect_colon_format() {
        let cred = parse_phppgadmin_line(
            "http://www.example.com/redirect.php:user:secret",
        )
        .unwrap();
        assert!(cred.url.as_str().contains("redirect.php"));
        assert_eq!(cred.username, "user");
    }

    #[test]
    fn parse_servers_php_colon_format() {
        let cred = parse_phppgadmin_line(
            "https://info.example.edu/phppgadmin/servers.php:dbuser:secret",
        )
        .unwrap();
        assert!(cred.url.path().ends_with("servers.php"));
        assert_eq!(cred.username, "dbuser");
    }

    #[test]
    fn parse_ip_postgres_colon_format() {
        let cred = parse_phppgadmin_line("http://172.28.0.19:postgres:Zhan@yang123").unwrap();
        assert_eq!(cred.username, "postgres");
        assert_eq!(cred.url.host_str(), Some("172.28.0.19"));
    }

    /// Colon-separated cred after full phpPgAdmin redirect URL (IP host, no port in URL).
    #[test]
    fn parse_ip_phppgadmin_redirect_colon_format() {
        let cred = parse_phppgadmin_line(
            "https://185.30.142.26/phppgadmin/redirect.php:dialapplet:example_secret",
        )
        .unwrap();
        assert_eq!(cred.url.scheme(), "https");
        assert_eq!(cred.url.host_str(), Some("185.30.142.26"));
        assert_eq!(cred.url.path(), "/phppgadmin/redirect.php");
        assert_eq!(cred.username, "dialapplet");
        assert_eq!(cred.password, "example_secret");
        assert!(is_pgadmin_url(&cred.url));
    }

    #[test]
    fn normalize_pgadmin4_login_url_to_browser() {
        let cred = parse_phppgadmin_line(
            "https://inside.thatsend.app/pgadmin4/login?next=/pgadmin4/browser/ admin:secret",
        )
        .unwrap();
        assert_eq!(cred.url.path(), "/pgadmin4/browser/");
        assert_eq!(cred.username, "admin");
        assert_eq!(cred.password, "secret");
        assert!(is_pgadmin_url(&cred.url));
    }

    #[test]
    fn parse_pgadmin4_space_separated_credentials() {
        let cred = parse_phppgadmin_line(
            "https://host.example/pgadmin4/browser/ dbadmin:P@ssw0rd!",
        )
        .unwrap();
        assert_eq!(cred.url.path(), "/pgadmin4/browser/");
        assert_eq!(cred.username, "dbadmin");
    }

    #[test]
    fn parse_mixed_separators_url_cred() {
        let pipe = parse_phppgadmin_line(
            "https://host.example/phppgadmin/redirect.php|postgres:secret",
        )
        .unwrap();
        assert_eq!(pipe.username, "postgres");
        assert_eq!(pipe.password, "secret");

        let semi = parse_phppgadmin_line(
            "http://host.example/pgadmin4/browser;admin@x.com:pass;word",
        )
        .unwrap();
        assert_eq!(semi.username, "admin@x.com");
        assert_eq!(semi.password, "pass;word");

        let tab = parse_phppgadmin_line(
            "https://host.example/phppgadmin/redirect.php\tuser:pass",
        )
        .unwrap();
        assert_eq!(tab.username, "user");
    }

    #[test]
    fn parse_mixed_separators_user_pass() {
        let cred =
            parse_phppgadmin_line("https://host.example/pgadmin4/browser/ user|p@ss|w0rd").unwrap();
        assert_eq!(cred.username, "user");
        assert_eq!(cred.password, "p@ss|w0rd");
    }

    #[test]
    fn parse_host_without_scheme_space_separated() {
        let cred = parse_phppgadmin_line("185.30.142.26/phppgadmin/redirect.php dialapplet:secret").unwrap();
        assert_eq!(cred.url.host_str(), Some("185.30.142.26"));
        assert_eq!(cred.username, "dialapplet");
    }

    #[test]
    fn parse_host_without_scheme_colon_format() {
        let cred =
            parse_phppgadmin_line("185.30.142.26/phppgadmin/redirect.php:dialapplet:secret").unwrap();
        assert_eq!(cred.username, "dialapplet");
        assert_eq!(cred.password, "secret");
    }
}
