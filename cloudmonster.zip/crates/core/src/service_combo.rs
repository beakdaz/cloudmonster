//! Shared combo parsing for web-app export modules (OWA, Kibana, Zabbix, …).

use crate::credential_line::{parse_host_colon_user_pass, with_default_scheme};
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

pub fn preprocess_combo_line(line: &str) -> String {
    let mut trimmed = line.trim().to_string();
    if let Some(open) = trimmed.find('(') {
        if let Some(close) = trimmed[open..].find(')') {
            let inner = trimmed[open + 1..open + close].trim();
            if inner.contains("://") || inner.starts_with("http") {
                trimmed = inner.to_string();
            }
        }
    }
    if trimmed.contains('|') {
        let parts: Vec<&str> = trimmed.split('|').map(str::trim).collect();
        if parts.len() >= 3 && !parts[0].is_empty() {
            let pass = parts[2..].join("|");
            return format!("{} {}:{}", parts[0], parts[1], pass);
        }
    }
    trimmed
}

pub fn reject_common_garbage(line: &str) -> Result<()> {
    let lower = line.to_ascii_lowercase();
    if lower.starts_with("android://")
        || lower.starts_with("intent://")
        || lower.starts_with("ftp://")
        || lower.contains("com.mattermost.rn")
        || lower.contains("mattermost.rn.com")
    {
        bail!("garbage line");
    }
    if lower.contains("accounts.google.com") || lower.contains("google.com/signin") {
        bail!("not a target url");
    }
    Ok(())
}

pub fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

pub fn validate_credentials(username: &str, password: &str) -> Result<()> {
    if username.is_empty() || username.eq_ignore_ascii_case("n/a") {
        bail!("missing username");
    }
    if password.is_empty() {
        bail!("missing password");
    }
    Ok(())
}

pub fn parse_colon_url_line(
    line: &str,
    normalize: &dyn Fn(&str) -> Result<Url>,
) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];
    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }
    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    validate_credentials(username, password)?;
    let url = normalize(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

pub fn parse_combo_line(
    line: &str,
    normalize: &dyn Fn(&str) -> Result<Url>,
    reject_extra: &dyn Fn(&str) -> Result<()>,
    reject_digit_username: bool,
) -> Result<Credential> {
    let trimmed = preprocess_combo_line(line);
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    reject_common_garbage(&trimmed)?;
    reject_extra(&trimmed)?;

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        validate_credentials(&username, &password)?;
        let url = normalize(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_url_line(&trimmed, normalize)
    } else {
        let cred = parse_host_colon_user_pass(&trimmed, normalize, reject_digit_username)?;
        validate_credentials(&cred.username, &cred.password)?;
        Ok(cred)
    }
}

pub fn normalize_web_url(raw: &str, default_scheme: &str, strip_suffixes: &[&str]) -> Result<Url> {
    let candidate = with_default_scheme(raw.trim(), default_scheme);
    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    let mut path = url.path().to_string();
    if path.is_empty() {
        path = "/".to_string();
    }
    path = path.trim_end_matches('/').to_string();
    for suffix in strip_suffixes {
        if path.ends_with(suffix) {
            path = path[..path.len() - suffix.len()].to_string();
            break;
        }
    }
    if path.is_empty() {
        path = "/".to_string();
    } else if !path.ends_with('/') {
        path.push('/');
    }
    url.set_path(&path);
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn host_path_lower(url: &Url) -> (String, String) {
    (
        url.host_str().unwrap_or("").to_ascii_lowercase(),
        url.path().to_ascii_lowercase(),
    )
}

pub fn parse_list_summary(
    content: &str,
    parse_line: &dyn Fn(&str) -> Result<Credential>,
    matches_target: &dyn Fn(&Url) -> bool,
) -> Result<ServiceParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered = 0usize;
    let mut total_lines = 0usize;
    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_line(trimmed) {
            Ok(cred) if matches_target(&cred.url) => credentials.push(cred),
            Ok(_) => filtered += 1,
            Err(_) => skipped += 1,
        }
    }
    Ok(ServiceParseSummary {
        credentials,
        skipped,
        filtered_non_target: filtered,
        total_lines,
    })
}

#[derive(Debug, Clone, Default)]
pub struct ServiceParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_target: usize,
    pub total_lines: usize,
}
