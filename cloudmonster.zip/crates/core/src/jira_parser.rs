//! Jira list format: `https://jira.host user:pass` or `https://company.atlassian.net email:api_token`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct JiraParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_jira: usize,
    pub total_lines: usize,
}

pub fn is_jira_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    if host.is_empty() {
        return false;
    }
    if host.ends_with(".atlassian.net") || host == "atlassian.net" {
        return true;
    }
    host.contains("jira")
}

pub fn parse_jira_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_jira_host(&cred.url) {
        bail!(
            "host `{}` does not look like Jira (hostname must contain `jira` or be *.atlassian.net)",
            cred.url.host_str().unwrap_or("?")
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_jira_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_jira_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_jira_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_jira_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if candidate.contains('(') || candidate.contains(')') {
        bail!("url contains invalid characters");
    }
    if let Some(scheme_idx) = candidate.find("://") {
        let after = &candidate[scheme_idx + 3..];
        if let Some(slash) = after.find('/') {
            candidate = candidate[..scheme_idx + 3 + slash].to_string();
        }
    }
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }
    url.set_path("/");
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

pub fn parse_jira_list_summary(content: &str) -> Result<JiraParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_jira = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_jira_host(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_jira += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(JiraParseSummary {
        credentials,
        skipped,
        filtered_non_jira,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_self_hosted_jira() {
        let cred = parse_jira_line("https://jira.example.com admin:secret").unwrap();
        assert_eq!(cred.url.as_str(), "https://jira.example.com/");
        assert_eq!(cred.username, "admin");
    }

    #[test]
    fn parses_atlassian_cloud() {
        let cred =
            parse_jira_line("https://myteam.atlassian.net user@corp.com:api_token_here").unwrap();
        assert_eq!(cred.url.host_str(), Some("myteam.atlassian.net"));
    }

    #[test]
    fn parses_login_jsp_url_with_space_credentials() {
        let cred =
            parse_jira_line("https://jira.gns-it.com/login.jsp Sami:Sami@123").unwrap();
        assert_eq!(cred.url.as_str(), "https://jira.gns-it.com/");
        assert_eq!(cred.username, "Sami");
        assert_eq!(cred.password, "Sami@123");
    }

    #[test]
    fn parses_http_host_without_tls() {
        let cred = parse_jira_line("http://jira.protonema.co.id yuantikaw:Yuantika03").unwrap();
        assert_eq!(cred.url.as_str(), "http://jira.protonema.co.id/");
        assert_eq!(cred.url.scheme(), "http");
        assert_eq!(cred.username, "yuantikaw");
    }

    #[test]
    fn parses_servicedesk_customer_login_path() {
        let cred = parse_jira_line(
            "https://jira.furfest.org/servicedesk/customer/user/login user@example.com:secret",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://jira.furfest.org/");
    }
}
