// Source: C# LoginResult enum + result bucket files from project_final.

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use url::Url;

/// A single phpMyAdmin target: panel URL plus credentials.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Credential {
    pub url: Url,
    pub username: String,
    pub password: String,
}

impl Credential {
    pub fn display_line(&self) -> String {
        format!(
            "{}:{}:{}",
            self.url.as_str().trim_end_matches('/'),
            self.username,
            self.password
        )
    }

    /// Mega v4.6 bucket / GUI log line: `email:password`.
    pub fn combo_line(&self) -> String {
        format!("{}:{}", self.username, self.password)
    }

    /// Host segment for folder names (`jtalks_org`, port appended when non-default).
    pub fn site_dir_name(&self) -> String {
        let mut host = self
            .url
            .host_str()
            .unwrap_or("unknown")
            .replace('.', "_");
        if let Some(port) = self.url.port() {
            host = format!("{host}_{port}");
        }
        host
    }

    /// Top-level site folder under the run output dir, e.g. `jira_jtalks_org`.
    pub fn site_folder_name(&self, kind: &str) -> String {
        format!("{kind}_{}", self.site_dir_name())
    }

    /// File name prefix for this account inside a site folder (sanitized username).
    pub fn account_file_prefix(&self) -> String {
        Self::safe_path_component(&self.username)
    }

    pub fn site_output_dir(&self, run_output_dir: &Path, kind: &str) -> PathBuf {
        run_output_dir.join(self.site_folder_name(kind))
    }

    /// Per-account export root (avoids parallel workers on the same host deleting each other's dumps).
    pub fn account_site_output_dir(&self, run_output_dir: &Path, kind: &str) -> PathBuf {
        self.site_output_dir(run_output_dir, kind)
            .join(self.account_file_prefix())
    }

    /// Username prefix for exported files inside [`Self::site_output_dir`].
    pub fn storage_prefix(&self) -> String {
        self.account_file_prefix()
    }

    pub fn safe_path_component(input: &str) -> String {
        input
            .chars()
            .map(|c| {
                if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                    c
                } else {
                    '_'
                }
            })
            .collect()
    }

    /// C# skips targets with user/pass shorter than 3 chars unless host is local.
    pub fn should_skip_short_credentials(&self) -> bool {
        let host = self.url.host_str().unwrap_or("");
        let is_local =
            host == "localhost" || host == "127.0.0.1" || host.starts_with("192.168.");
        !is_local && (self.username.len() < 3 || self.password.len() < 3)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ScanStatus {
    Valid,
    InvalidCredentials,
    Unreachable,
    NotPhpMyAdmin,
    Captcha,
    Error,
}

impl ScanStatus {
    pub fn label(&self) -> &'static str {
        match self {
            Self::Valid => "OK",
            Self::InvalidCredentials => "INVALID",
            Self::Unreachable => "DOWN",
            Self::NotPhpMyAdmin => "NO_PMA",
            Self::Captcha => "CAPTCHA",
            Self::Error => "ERROR",
        }
    }

    /// Result bucket filename:
    /// AUTH → Bad, NETWORK → Error, ERROR/other → CantCheck, captcha/2FA → 2FA.
    pub fn bucket_filename(&self) -> Option<&'static str> {
        match self {
            Self::Valid => Some("Good.txt"),
            Self::InvalidCredentials => Some("Bad.txt"),
            Self::Unreachable => Some("Error.txt"),
            Self::Error | Self::NotPhpMyAdmin => Some("CantCheck.txt"),
            Self::Captcha => Some("2FA.txt"),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ScanResult {
    pub credential: Credential,
    pub status: ScanStatus,
    pub message: Option<String>,
    pub databases: Vec<String>,
}

impl ScanResult {
    pub fn is_valid(&self) -> bool {
        self.status == ScanStatus::Valid
    }
}
