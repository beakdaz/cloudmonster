//! Cloud file download filters (extensions, size, keywords) — Mega v4.x style.

use std::path::Path;

/// Filter cloud files before download. Empty lists = no restriction on that axis.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct CloudDownloadFilter {
    /// Lowercase extensions without dot, e.g. `pdf`, `docx`.
    pub extensions: Vec<String>,
    /// Minimum file size in bytes (0 = no minimum).
    pub min_bytes: u64,
    /// Maximum file size in bytes (0 = no maximum).
    pub max_bytes: u64,
    /// Filename/path must contain at least one keyword (case-insensitive).
    pub keywords: Vec<String>,
}

impl CloudDownloadFilter {
    pub fn parse_extensions(raw: &str) -> Vec<String> {
        split_tokens(raw)
            .into_iter()
            .map(|mut e| {
                e = e.trim_start_matches('.').to_string();
                e
            })
            .filter(|e| !e.is_empty())
            .collect()
    }

    pub fn parse_keywords(raw: &str) -> Vec<String> {
        split_tokens(raw)
    }

    /// `min_kb` / `max_mb` from GUI: 0 means unset.
    pub fn from_gui(min_kb: u64, max_mb: u64, extensions_raw: &str, keywords_raw: &str) -> Self {
        let min_bytes = min_kb.saturating_mul(1024);
        let max_bytes = if max_mb == 0 {
            0
        } else {
            max_mb.saturating_mul(1024 * 1024)
        };
        Self {
            extensions: Self::parse_extensions(extensions_raw),
            min_bytes,
            max_bytes,
            keywords: Self::parse_keywords(keywords_raw),
        }
    }

    pub fn is_active(&self) -> bool {
        !self.extensions.is_empty()
            || self.min_bytes > 0
            || self.max_bytes > 0
            || !self.keywords.is_empty()
    }

    /// Match on display path (may include folders) + size.
    pub fn matches(&self, path_or_name: &str, size: u64) -> bool {
        self.matches_parts(path_or_name, "", "", size)
    }

    /// Match on path, leaf name, optional extra text (e.g. note body preview) + size.
    pub fn matches_parts(
        &self,
        path: &str,
        name: &str,
        keyword_extra: &str,
        size: u64,
    ) -> bool {
        if self.min_bytes > 0 && size < self.min_bytes {
            return false;
        }
        if self.max_bytes > 0 && size > self.max_bytes {
            return false;
        }
        let ext_source = if !name.is_empty() { name } else { path };
        if !self.extensions.is_empty() {
            let ext = Path::new(ext_source)
                .extension()
                .and_then(|e| e.to_str())
                .unwrap_or("")
                .to_lowercase();
            if ext.is_empty() || !self.extensions.iter().any(|e| e == &ext) {
                return false;
            }
        }
        if !self.keywords.is_empty() {
            let hay = format!(
                "{} {} {}",
                path.to_lowercase(),
                name.to_lowercase(),
                keyword_extra.to_lowercase()
            );
            if !self
                .keywords
                .iter()
                .any(|kw| !kw.is_empty() && hay.contains(kw))
            {
                return false;
            }
        }
        true
    }
}

fn split_tokens(raw: &str) -> Vec<String> {
    raw.split(|c: char| c == ',' || c == ';' || c == '|' || c == '\n' || c == ' ')
        .map(|s| s.trim().to_lowercase())
        .filter(|s| !s.is_empty())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn keyword_in_extra_text() {
        let f = CloudDownloadFilter {
            extensions: vec![],
            min_bytes: 0,
            max_bytes: 0,
            keywords: vec!["secret".into()],
        };
        assert!(f.matches_parts("notes/memo", "memo", "contains secret phrase", 0));
        assert!(!f.matches_parts("notes/memo", "memo", "plain text", 0));
    }

    #[test]
    fn keyword_and_ext() {
        let f = CloudDownloadFilter {
            extensions: vec!["pdf".into()],
            min_bytes: 100,
            max_bytes: 0,
            keywords: vec!["wallet".into()],
        };
        assert!(f.matches("backup/wallet.pdf", 200));
        assert!(!f.matches("backup/wallet.pdf", 50));
        assert!(!f.matches("backup/seed.txt", 200));
    }
}
