//! MEGA.nz account list: `email@domain.com:password` (Mega v4.6 accounts file).

use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

const MEGA_ACCOUNT_URL: &str = "https://mega.nz/";

#[derive(Debug, Clone, Default)]
pub struct MegaParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub total_lines: usize,
}

pub fn is_mega_email_account(cred: &Credential) -> bool {
    cred.url.host_str() == Some("mega.nz") && cred.username.contains('@')
}

pub fn parse_mega_line(line: &str) -> Result<Credential> {
    let cred = parse_line_inner(line)?;
    if !is_mega_email_account(&cred) {
        bail!("expected MEGA account line `email:password`");
    }
    Ok(cred)
}

fn parse_line_inner(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (email, rest) = trimmed.split_at(idx);
        let email = normalize_mega_email(email);
        let rest = rest.trim();
        if !email.contains('@') {
            bail!("missing @ in email");
        }
        let password = parse_password_field(rest)?;
        return Ok(mega_credential(&email, &password));
    }

    let (email, password) = split_mega_email_password(trimmed)?;
    Ok(mega_credential(&email, &password))
}

/// Split `email@host.tld:password` with passwords that may contain `:`.
fn split_mega_email_password(line: &str) -> Result<(String, String)> {
    let at = line.find('@').context("missing @ in email")?;
    let after_at = &line[at..];
    let colon = after_at
        .find(':')
        .context("expected email:password (colon after domain)")?;
    let split_at = at + colon;
    let email = normalize_mega_email(&line[..split_at]);
    if email.is_empty() || !email.contains('@') {
        bail!("invalid email");
    }
    let password = line[split_at + 1..].trim();
    if password.is_empty() {
        bail!("missing password");
    }
    Ok((email, password.to_string()))
}

fn normalize_mega_email(raw: &str) -> String {
    let mut s = raw.trim();
    for prefix in [
        "https://mega.nz:",
        "http://mega.nz:",
        "https://mega.co.nz:",
        "http://mega.co.nz:",
        "mega.nz:",
        "mega.co.nz:",
    ] {
        if let Some(rest) = s.strip_prefix(prefix) {
            s = rest;
            break;
        }
    }
    if let Some(rest) = s.strip_prefix("https://mega.nz/") {
        s = rest;
    } else if let Some(rest) = s.strip_prefix("http://mega.nz/") {
        s = rest;
    }
    s.trim().to_string()
}

fn parse_password_field(rest: &str) -> Result<String> {
    if rest.contains(':') {
        let (_, password) = split_user_password(rest)?;
        return Ok(password);
    }
    Ok(rest.to_string())
}

fn mega_credential(email: &str, password: &str) -> Credential {
    Credential {
        url: Url::parse(MEGA_ACCOUNT_URL).expect("mega url"),
        username: email.to_string(),
        password: password.to_string(),
    }
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after email")?;
    if idx == 0 {
        bail!("missing password");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

pub fn parse_mega_list_summary(content: &str) -> Result<MegaParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_mega_line(trimmed) {
            Ok(c) => credentials.push(c),
            Err(_) => skipped += 1,
        }
    }

    Ok(MegaParseSummary {
        credentials,
        skipped,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_colon_form() {
        let c = parse_mega_line("user@example.com:Secret1").unwrap();
        assert_eq!(c.username, "user@example.com");
        assert_eq!(c.password, "Secret1");
    }

    #[test]
    fn parses_space_form() {
        let c = parse_mega_line("user@example.com login:Secret1").unwrap();
        assert_eq!(c.username, "user@example.com");
        assert_eq!(c.password, "Secret1");
    }

    #[test]
    fn parses_password_with_colons() {
        let c = parse_mega_line("user@example.com:pass:word:2").unwrap();
        assert_eq!(c.username, "user@example.com");
        assert_eq!(c.password, "pass:word:2");
    }

    #[test]
    fn parses_url_triple_form() {
        let c = parse_mega_line("https://mega.nz:ortega@mail.com:laberinto").unwrap();
        assert_eq!(c.username, "ortega@mail.com");
        assert_eq!(c.password, "laberinto");
    }
}
