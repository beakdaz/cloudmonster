//! Bitrix admin list format: `https://host/bitrix/admin user:pass`.

use crate::credential_line::parse_host_colon_user_pass;
use crate::types::Credential;
use anyhow::{bail, Context, Result};
use url::Url;

#[derive(Debug, Clone, Default)]
pub struct BitrixParseSummary {
    pub credentials: Vec<Credential>,
    pub skipped: usize,
    pub filtered_non_bitrix: usize,
    pub total_lines: usize,
}

pub fn is_bitrix_url(url: &Url) -> bool {
    url.path().to_ascii_lowercase().contains("bitrix")
}

pub fn parse_bitrix_line(line: &str) -> Result<Credential> {
    let cred = parse_service_line(line)?;
    if !is_bitrix_url(&cred.url) {
        bail!(
            "url `{}` does not look like Bitrix admin (path must contain `bitrix`)",
            cred.url.as_str()
        );
    }
    Ok(cred)
}

fn parse_service_line(line: &str) -> Result<Credential> {
    let trimmed = line.trim();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        bail!("empty or comment line");
    }
    if trimmed.contains('(') || trimmed.contains(')') {
        bail!("url contains invalid characters");
    }

    if let Some(idx) = trimmed.find(char::is_whitespace) {
        let (url_part, cred_part) = trimmed.split_at(idx);
        let url_part = url_part.trim();
        let cred_part = cred_part.trim();
        if url_part.is_empty() || cred_part.is_empty() {
            bail!("expected `url user:password`");
        }
        let (username, password) = split_user_password(cred_part)?;
        let url = normalize_bitrix_url(url_part)?;
        return Ok(Credential {
            url,
            username,
            password,
        });
    }

    if trimmed.contains("://") {
        parse_colon_service_line(trimmed)
    } else {
        parse_host_colon_user_pass(trimmed, &normalize_bitrix_url, true)
    }
}

fn parse_colon_service_line(line: &str) -> Result<Credential> {
    let scheme_end = line
        .find("://")
        .map(|idx| idx + 3)
        .context("expected url:username:password")?;
    let scheme = &line[..scheme_end];
    let rest = &line[scheme_end..];

    if scheme != "http://" && scheme != "https://" {
        bail!("unsupported url scheme");
    }

    let (url_and_user, password) = rest
        .rsplit_once(':')
        .context("expected url:username:password")?;
    let (url_part, username) = url_and_user
        .rsplit_once(':')
        .context("expected url:username:password")?;
    if username.is_empty() {
        bail!("missing username");
    }
    if username.chars().all(|c| c.is_ascii_digit()) {
        bail!("username looks like a port number (bad line format)");
    }

    let url = normalize_bitrix_url(&format!("{scheme}{url_part}"))
        .with_context(|| format!("invalid url: {url_part}"))?;
    Ok(Credential {
        url,
        username: username.to_string(),
        password: password.to_string(),
    })
}

fn split_user_password(cred_part: &str) -> Result<(String, String)> {
    let idx = cred_part
        .find(':')
        .context("expected user:password after url")?;
    if idx == 0 {
        bail!("missing username");
    }
    Ok((
        cred_part[..idx].to_string(),
        cred_part[idx + 1..].to_string(),
    ))
}

fn normalize_bitrix_url(raw: &str) -> Result<Url> {
    let mut candidate = raw.trim().to_string();
    if !candidate.contains("://") {
        candidate = format!("https://{candidate}");
    }

    let mut url = Url::parse(&candidate).context("url parse failed")?;
    match url.scheme() {
        "http" | "https" => {}
        other => bail!("unsupported scheme `{other}`"),
    }

    let path = url.path().to_ascii_lowercase();
    url.set_fragment(None);
    url.set_query(None);
    if path.contains("/bitrix/admin/index.php") {
        url.set_path("/bitrix/admin/index.php");
    } else if path.contains("/bitrix/admin") || path.contains("bitrix") {
        url.set_path("/bitrix/admin/");
    }
    Ok(url)
}

pub fn parse_bitrix_list_summary(content: &str) -> Result<BitrixParseSummary> {
    let mut credentials = Vec::new();
    let mut skipped = 0usize;
    let mut filtered_non_bitrix = 0usize;
    let mut total_lines = 0usize;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        total_lines += 1;
        match parse_service_line(trimmed) {
            Ok(cred) if is_bitrix_url(&cred.url) => credentials.push(cred),
            Ok(_) => filtered_non_bitrix += 1,
            Err(_) => skipped += 1,
        }
    }

    Ok(BitrixParseSummary {
        credentials,
        skipped,
        filtered_non_bitrix,
        total_lines,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_space_separated_bitrix_line() {
        let cred = parse_bitrix_line(
            "https://peugeot.yug-avto.ru/bitrix/admin andreev_a:bp7ed3z2",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://peugeot.yug-avto.ru/bitrix/admin/");
        assert_eq!(cred.username, "andreev_a");
        assert_eq!(cred.password, "bp7ed3z2");
    }

    #[test]
    fn parses_second_example() {
        let cred = parse_bitrix_line(
            "https://vps.vitranet24.asia/bitrix/admin cuongnh1.vn:cuongnh1.vn",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://vps.vitranet24.asia/bitrix/admin/");
        assert_eq!(cred.username, "cuongnh1.vn");
    }

    #[test]
    fn parses_colon_line() {
        let cred =
            parse_bitrix_line("https://example.com/bitrix/admin:admin:secret").unwrap();
        assert_eq!(cred.username, "admin");
        assert_eq!(cred.password, "secret");
    }

    #[test]
    fn preserves_index_php_entry_url() {
        let cred = parse_bitrix_line(
            "https://gkunicom.ru/bitrix/admin/index.php#authorize admin:secret",
        )
        .unwrap();
        assert_eq!(cred.url.as_str(), "https://gkunicom.ru/bitrix/admin/index.php");
        assert_eq!(cred.username, "admin");
    }

    #[test]
    fn rejects_non_bitrix_url() {
        assert!(parse_bitrix_line("https://example.com/admin user:pass").is_err());
    }
}
