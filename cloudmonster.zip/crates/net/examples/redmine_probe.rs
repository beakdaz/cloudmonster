//! Live Redmine probe: `cargo run -p pma-net --example redmine_probe -- "http://host user:pass" [--export]`
use anyhow::Result;
use pma_core::parse_redmine_line;
use pma_net::{download_redmine_projects, RedmineClientConfig, RedmineExportOptions};
use std::env;
use std::path::PathBuf;

#[tokio::main]
async fn main() -> Result<()> {
    let mut args = env::args().skip(1);
    let mut export = false;
    let mut line = String::from("http://redmine.belcash.com admin:admin");
    for a in args.by_ref() {
        if a == "--export" {
            export = true;
        } else {
            line = a;
        }
    }
    let cred = parse_redmine_line(&line)?;
    println!("parsed url={} user={}", cred.url, cred.username);
    let out = env::temp_dir().join("redmine_probe_out");
    tokio::fs::create_dir_all(&out).await?;
    let config = RedmineClientConfig::default();
    let (stats, files) = match download_redmine_projects(
        &cred,
        &config,
        PathBuf::from(&out).as_path(),
        export,
        RedmineExportOptions::default(),
    )
    .await
    {
        Ok(v) => v,
        Err(e) => {
            eprintln!("{e:#}");
            return Err(e);
        }
    };
    println!("{}", stats.detail_line());
    if export {
        println!("json_exports={} out={}", files.len(), out.display());
    }
    Ok(())
}
