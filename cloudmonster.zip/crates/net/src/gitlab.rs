//! GitLab API client: authenticate, list owned projects, download repository archives.

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, Credential};
use regex::Regex;
use reqwest::{Client, Response, Url};
use serde::Deserialize;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

// #region agent log
fn agent_log(hypothesis_id: &str, location: &str, message: &str, data: serde_json::Value) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let line = serde_json::json!({
        "sessionId": "be3b27",
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0),
        "runId": "post-fix"
    });
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

static CSRF_META_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)name="csrf-token"\s+content="([^"]+)""#).unwrap()
});

static AUTH_TOKEN_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"name="authenticity_token"\s+value="([^"]+)""#).unwrap()
});

#[derive(Debug, Clone)]
pub struct GitLabClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for GitLabClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct GitLabUser {
    #[allow(dead_code)]
    pub id: u64,
    pub username: Option<String>,
    #[allow(dead_code)]
    pub name: Option<String>,
    #[serde(default)]
    pub is_admin: bool,
}

#[derive(Debug, Deserialize)]
struct GitLabVersion {
    version: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct GitLabProject {
    pub id: u64,
    pub name: String,
    pub path: String,
    pub path_with_namespace: String,
    pub web_url: String,
    pub default_branch: Option<String>,
    pub visibility: Option<String>,
}

/// Summary shown for successful GitLab downloads (Good log lines).
#[derive(Debug, Clone)]
pub struct GitLabAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub owned_projects: usize,
    pub membership_projects: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl GitLabAccountStats {
    pub fn detail_line(&self) -> String {
        let check_metric = self
            .owned_projects
            .saturating_add(self.membership_projects);
        let downloaded = crate::stats_display::file_count(self.downloaded, check_metric);
        format!(
            "user={} admin={} owned={} membership={} downloaded={downloaded} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.owned_projects,
            self.membership_projects,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

enum GitLabAuth {
    Basic {
        username: String,
        password: String,
    },
    PrivateToken(String),
}

pub struct GitLabClient {
    http: Client,
    detect_http: Client,
    base: Url,
    auth: Option<GitLabAuth>,
}

impl GitLabClient {
    pub fn new(base: Url, config: &GitLabClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-gitlab/0.1");

        let mut detect_builder = Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-gitlab/0.1");

        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
            detect_builder = detect_builder.danger_accept_invalid_certs(true);
        }

        Ok(Self {
            http: builder.build().context("failed to build HTTP client")?,
            detect_http: detect_builder.build().context("failed to build detect HTTP client")?,
            base,
            auth: None,
        })
    }

    fn apply_auth(&self, builder: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        match &self.auth {
            Some(GitLabAuth::Basic { username, password }) => {
                builder.basic_auth(username, Some(password.as_str()))
            }
            Some(GitLabAuth::PrivateToken(token)) => builder.header("PRIVATE-TOKEN", token.as_str()),
            None => builder,
        }
    }

    fn api_url(&self, path: &str) -> Result<Url> {
        self.base
            .join(&format!("api/v4/{path}"))
            .context("failed to build api url")
    }

    pub async fn detect(&self) -> Result<bool> {
        let url = self.api_url("version")?;
        let resp = match self.detect_http.get(url.clone()).send().await {
            Ok(resp) => resp,
            Err(err) => {
                // #region agent log
                agent_log(
                    "G2",
                    "gitlab.rs:detect",
                    "connect failed",
                    serde_json::json!({
                        "url": url.to_string(),
                        "base": self.base.to_string(),
                        "error": err.to_string(),
                    }),
                );
                // #endregion
                return Err(err).with_context(|| {
                    format!(
                        "cannot reach GitLab at {} (check VPN/network; enable Allow invalid TLS for bad certificates)",
                        self.base
                    )
                });
            }
        };
        let status = resp.status();
        if status.is_redirection() {
            let location = resp
                .headers()
                .get(reqwest::header::LOCATION)
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            let redirect_gitlab = is_gitlab_login_redirect(location)
                || looks_like_gitlab_response_headers(resp.headers());
            // #region agent log
            agent_log(
                "G3",
                "gitlab.rs:detect",
                "redirect on version probe",
                serde_json::json!({
                    "status": status.as_u16(),
                    "location": location,
                    "is_gitlab": redirect_gitlab,
                }),
            );
            // #endregion
            if redirect_gitlab {
                return Ok(true);
            }
        } else if looks_like_gitlab_response_headers(resp.headers()) && !status.is_success() {
            // Empty-body GitLab/Rails responses (e.g. edcast 302 with X-Runtime only).
            // #region agent log
            agent_log(
                "G3",
                "gitlab.rs:detect",
                "gitlab headers without json body",
                serde_json::json!({ "status": status.as_u16(), "is_gitlab": true }),
            );
            // #endregion
            return Ok(true);
        }

        let body = resp.text().await?;
        let trimmed = body.trim_start();
        if trimmed.starts_with("<!DOCTYPE")
            || trimmed.starts_with("<!doctype")
            || trimmed.starts_with("<html")
        {
            // #region agent log
            agent_log(
                "D",
                "gitlab.rs:detect",
                "not gitlab",
                serde_json::json!({
                    "status": status.as_u16(),
                    "body_prefix": body.chars().take(120).collect::<String>(),
                }),
            );
            // #endregion
            return Ok(false);
        }

        if status.is_success() {
            let ok = serde_json::from_str::<GitLabVersion>(&body)
                .map(|v| v.version.is_some())
                .unwrap_or(false);
            // #region agent log
            agent_log(
                "D",
                "gitlab.rs:detect",
                "version probe",
                serde_json::json!({ "is_gitlab": ok, "status": status.as_u16(), "body_prefix": body.chars().take(80).collect::<String>() }),
            );
            // #endregion
            return Ok(ok);
        }

        // GitLab API error JSON (401/403/404) — still GitLab, auth happens later.
        let is_gitlab_api = looks_like_gitlab_api_json(trimmed);
        // #region agent log
        agent_log(
            "G1",
            "gitlab.rs:detect",
            if is_gitlab_api { "gitlab api error json" } else { "not gitlab" },
            serde_json::json!({
                "is_gitlab": is_gitlab_api,
                "status": status.as_u16(),
                "body_prefix": body.chars().take(120).collect::<String>(),
            }),
        );
        // #endregion
        Ok(is_gitlab_api)
    }

    pub async fn authenticate(&mut self, username: &str, password: &str) -> Result<()> {
        if self.verify_session().await? {
            return Ok(());
        }

        if self.try_basic_auth(username, password).await? {
            self.auth = Some(GitLabAuth::Basic {
                username: username.to_string(),
                password: password.to_string(),
            });
            return Ok(());
        }

        if self.try_private_token_header(password).await? {
            self.auth = Some(GitLabAuth::PrivateToken(password.to_string()));
            return Ok(());
        }

        self.session_login(username, password).await
    }

    async fn verify_session(&self) -> Result<bool> {
        Ok(self.fetch_current_user().await?.is_some())
    }

    async fn fetch_current_user(&self) -> Result<Option<GitLabUser>> {
        let url = self.api_url("user")?;
        let resp = self.apply_auth(self.http.get(url)).send().await?;
        parse_user_response(resp, "fetch_current_user").await
    }

    async fn try_basic_auth(&self, username: &str, password: &str) -> Result<bool> {
        let url = self.api_url("user")?;
        let resp = self
            .http
            .get(url)
            .basic_auth(username, Some(password))
            .send()
            .await?;
        Ok(parse_user_response(resp, "try_basic_auth").await?.is_some())
    }

    async fn try_private_token_header(&self, token: &str) -> Result<bool> {
        let url = self.api_url("user")?;
        let resp = self
            .http
            .get(url)
            .header("PRIVATE-TOKEN", token)
            .send()
            .await?;
        Ok(parse_user_response(resp, "try_private_token_header")
            .await?
            .is_some())
    }

    async fn session_login(&mut self, username: &str, password: &str) -> Result<()> {
        let sign_in = self
            .base
            .join("users/sign_in")
            .context("failed to build sign-in url")?;
        let html = self
            .http
            .get(sign_in.clone())
            .send()
            .await?
            .error_for_status()?
            .text()
            .await?;

        let authenticity_token = CSRF_META_RE
            .captures(&html)
            .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
            .or_else(|| {
                AUTH_TOKEN_RE
                    .captures(&html)
                    .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
            })
            .context("missing GitLab CSRF token on sign-in page")?;

        let resp = self
            .http
            .post(sign_in)
            .form(&[
                ("utf8", "✓"),
                ("authenticity_token", authenticity_token.as_str()),
                ("user[login]", username),
                ("user[password]", password),
                ("user[remember_me]", "0"),
                ("commit", "Sign in"),
            ])
            .send()
            .await?;

        if !resp.status().is_redirection() && !resp.status().is_success() {
            bail!("GitLab sign-in failed with HTTP {}", resp.status());
        }

        if self.verify_session().await? {
            return Ok(());
        }

        bail!(
            "GitLab authentication failed for {username} (check email/password, 2FA, or use a personal access token as password)"
        );
    }

    pub async fn list_owned_projects(&self) -> Result<Vec<GitLabProject>> {
        let mut page = 1u32;
        let mut all = Vec::new();

        loop {
            let url = self.api_url(&format!(
                "projects?owned=true&simple=false&per_page=100&page={page}"
            ))?;
            let resp = self.apply_auth(self.http.get(url)).send().await?;
            let batch: Vec<GitLabProject> =
                parse_json_response(resp, "projects?owned=true").await?;
            if batch.is_empty() {
                break;
            }
            all.extend(batch);
            page += 1;
        }

        Ok(all)
    }

    pub async fn current_user(&self) -> Result<GitLabUser> {
        self.fetch_current_user()
            .await?
            .context("GitLab /user returned no user object")
    }

    /// Count projects matching a filter using `X-Total` when available.
    pub async fn count_projects(&self, filter: &str) -> Result<usize> {
        let url = self.api_url(&format!("projects?{filter}&simple=true&per_page=1&page=1"))?;
        let resp = self.apply_auth(self.http.get(url)).send().await?;
        let status = resp.status();
        if let Some(total) = resp
            .headers()
            .get("x-total")
            .and_then(|v| v.to_str().ok())
            .and_then(|s| s.parse::<usize>().ok())
        {
            let _ = resp.bytes().await;
            return Ok(total);
        }
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            bail!("GitLab projects count failed {status}: {}", preview_body(&body));
        }
        // Fallback: page through simple lists.
        let _ = resp.bytes().await;
        let mut page = 1u32;
        let mut total = 0usize;
        loop {
            let url = self.api_url(&format!(
                "projects?{filter}&simple=true&per_page=100&page={page}"
            ))?;
            let resp = self.apply_auth(self.http.get(url)).send().await?;
            let batch: Vec<serde_json::Value> =
                parse_json_response(resp, "projects count").await?;
            if batch.is_empty() {
                break;
            }
            total += batch.len();
            if batch.len() < 100 {
                break;
            }
            page += 1;
        }
        Ok(total)
    }

    pub async fn download_project_archive(
        &self,
        project: &GitLabProject,
        output_path: &Path,
    ) -> Result<u64> {
        let encoded = urlencoding::encode(&project.path_with_namespace);
        let mut url = self.api_url(&format!("projects/{encoded}/repository/archive.zip"))?;
        if let Some(branch) = &project.default_branch {
            url.query_pairs_mut()
                .append_pair("sha", branch.as_str());
        }

        let resp = self.apply_auth(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!(
                "archive download failed for {}: HTTP {}",
                project.path_with_namespace,
                resp.status()
            );
        }

        let bytes = resp.bytes().await?;
        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut file = fs::File::create(output_path).await?;
        file.write_all(&bytes).await?;
        Ok(bytes.len() as u64)
    }
}

async fn parse_user_response(resp: Response, stage: &str) -> Result<Option<GitLabUser>> {
    let status = resp.status();
    let content_type = resp
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    let body = resp.text().await?;
    let trimmed = body.trim_start();
    let looks_html = trimmed.starts_with("<!DOCTYPE")
        || trimmed.starts_with("<html")
        || trimmed.starts_with("<HTML");
    // #region agent log
    agent_log(
        "A",
        "gitlab.rs:parse_user_response",
        stage,
        serde_json::json!({
            "status": status.as_u16(),
            "content_type": content_type,
            "looks_html": looks_html,
            "body_prefix": body.chars().take(160).collect::<String>(),
        }),
    );
    // #endregion
    if !status.is_success() || looks_html {
        return Ok(None);
    }
    match serde_json::from_str::<GitLabUser>(&body) {
        Ok(user) => Ok(Some(user)),
        Err(err) => {
            // #region agent log
            agent_log(
                "B",
                "gitlab.rs:parse_user_response",
                "user json decode failed",
                serde_json::json!({
                    "stage": stage,
                    "error": err.to_string(),
                    "body_prefix": body.chars().take(160).collect::<String>(),
                }),
            );
            // #endregion
            Ok(None)
        }
    }
}

async fn parse_json_response<T: serde::de::DeserializeOwned>(
    resp: Response,
    endpoint: &str,
) -> Result<T> {
    let status = resp.status();
    let content_type = resp
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    let body = resp.text().await?;
    let trimmed = body.trim_start();
    let looks_html = trimmed.starts_with("<!DOCTYPE")
        || trimmed.starts_with("<html")
        || trimmed.starts_with("<HTML");
    // #region agent log
    agent_log(
        "C",
        "gitlab.rs:parse_json_response",
        endpoint,
        serde_json::json!({
            "status": status.as_u16(),
            "content_type": content_type,
            "looks_html": looks_html,
            "body_prefix": body.chars().take(160).collect::<String>(),
        }),
    );
    // #endregion
    if !status.is_success() {
        bail!("GitLab API error {status} on {endpoint}: {}", preview_body(&body));
    }
    if looks_html {
        bail!(
            "GitLab API returned HTML instead of JSON on {endpoint} (session not authenticated?)"
        );
    }
    serde_json::from_str(&body).with_context(|| {
        format!(
            "failed to decode GitLab API JSON from {endpoint}: {}",
            preview_body(&body)
        )
    })
}

fn preview_body(body: &str) -> String {
    body.chars().take(200).collect::<String>().replace('\n', " ")
}

fn looks_like_gitlab_api_json(body: &str) -> bool {
    let value: serde_json::Value = match serde_json::from_str(body) {
        Ok(v) => v,
        Err(_) => return false,
    };
    value.is_object()
        && (value.get("version").is_some() || value.get("message").is_some())
}

fn is_gitlab_login_redirect(location: &str) -> bool {
    let loc = location.to_ascii_lowercase();
    loc.contains("log_in")
        || loc.contains("/login")
        || loc.contains("/users/sign_in")
        || loc.contains("/users/sign_in/")
}

fn looks_like_gitlab_response_headers(headers: &reqwest::header::HeaderMap) -> bool {
    headers.contains_key("x-gitlab-meta")
        || headers.contains_key("x-gitlab-feature-category")
        || (headers.contains_key("x-request-id") && headers.contains_key("x-runtime"))
}

pub fn safe_path_component(input: &str) -> String {
    input
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

pub async fn download_personal_projects(
    cred: &Credential,
    config: &GitLabClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(GitLabAccountStats, Vec<(GitLabProject, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_personal_projects_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_personal_projects_once(
    cred: Credential,
    config: &GitLabClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(GitLabAccountStats, Vec<(GitLabProject, PathBuf, u64)>)> {
    // #region agent log
    agent_log(
        "G1",
        "gitlab.rs:download_personal_projects",
        "parsed credential",
        serde_json::json!({
            "url": cred.url.to_string(),
            "username": cred.username,
            "password_len": cred.password.len(),
            "insecure": config.insecure,
        }),
    );
    // #endregion
    let mut client = GitLabClient::new(cred.url.clone(), config)?;
    if !client.detect().await? {
        bail!(
            "{} is not a GitLab server (no /api/v4/version JSON response)",
            cred.url.host_str().unwrap_or("host")
        );
    }
    client
        .authenticate(&cred.username, &cred.password)
        .await
        .with_context(|| format!("login failed for {}", cred.display_line()))?;

    let user = client.current_user().await.unwrap_or(GitLabUser {
        id: 0,
        username: Some(cred.username.clone()),
        name: None,
        is_admin: false,
    });
    let username = user
        .username
        .clone()
        .unwrap_or_else(|| cred.username.clone());

    let projects = client.list_owned_projects().await?;
    let owned_projects = projects.len();
    let membership_projects = client
        .count_projects("membership=true")
        .await
        .unwrap_or(owned_projects);

    if projects.is_empty() {
        warn!("no owned projects for {}", cred.display_line());
        return Ok((
            GitLabAccountStats {
                username,
                is_admin: user.is_admin,
                owned_projects: 0,
                membership_projects,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    if !download_files {
        return Ok((
            GitLabAccountStats {
                username,
                is_admin: user.is_admin,
                owned_projects,
                membership_projects,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "gitlab");
    let prefix = cred.account_file_prefix();

    let mut written = Vec::new();
    for project in projects {
        let leaf = format!(
            "{}__{}.zip",
            prefix,
            safe_path_component(&project.path_with_namespace)
        );
        let path = output_file_path(&site_dir, &leaf);
        match client.download_project_archive(&project, &path).await {
            Ok(bytes) => {
                debug!(
                    "downloaded {} ({} bytes) for {}",
                    project.path_with_namespace,
                    bytes,
                    cred.display_line()
                );
                written.push((project, path, bytes));
            }
            Err(err) => warn!(
                "failed to download {} for {}: {err}",
                project.path_with_namespace,
                cred.display_line()
            ),
        }
    }

    let bytes: u64 = written.iter().map(|(_, _, b)| *b).sum();
    let downloaded = written.len();
    Ok((
        GitLabAccountStats {
            username,
            is_admin: user.is_admin,
            owned_projects,
            membership_projects,
            downloaded,
            bytes,
        },
        written,
    ))
}

#[cfg(test)]
mod detect_tests {
    use super::{is_gitlab_login_redirect, looks_like_gitlab_response_headers};
    use reqwest::header::{HeaderMap, HeaderValue};

    #[test]
    fn edcast_login_redirect_is_gitlab() {
        assert!(is_gitlab_login_redirect("https://gitlab.edcast.com/log_in"));
    }

    #[test]
    fn gitlab_rails_headers() {
        let mut headers = HeaderMap::new();
        headers.insert("x-request-id", HeaderValue::from_static("abc"));
        headers.insert("x-runtime", HeaderValue::from_static("0.01"));
        assert!(looks_like_gitlab_response_headers(&headers));
    }
}

mod urlencoding {
    pub fn encode(input: &str) -> String {
        input.bytes().fold(String::new(), |mut acc, b| {
            match b {
                b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                    acc.push(b as char);
                }
                _ => {
                    use std::fmt::Write;
                    let _ = write!(acc, "%{b:02X}");
                }
            }
            acc
        })
    }
}
