use crate::note_app_common::{download_note_app_account, NoteAppAccountStats, NoteAppSpec};
use anyhow::Result;
use pma_core::Credential;
use std::path::{Path, PathBuf};

pub use crate::note_app_common::NoteAppClientConfig as RoamresearchClientConfig;

const SPEC: NoteAppSpec = NoteAppSpec {
    service_label: "Roam Research",
    output_slug: "roamresearch",
    user_agent: "phpmyadmin-rs-roam/0.1",
    login_paths: &["app", "login", ""],
    post_paths: &["api/login", "login"],
    json_login_paths: &["api/login", "auth/login"],
    success_probe_paths: &["api/graph", "app", ""],
    inventory_api_paths: &["api/graph/overview", "api/graph"],
};

pub async fn download_roamresearch_account(
    cred: &Credential,
    config: &RoamresearchClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    download_note_app_account(cred, config, output_dir, download_files, &SPEC).await
}
