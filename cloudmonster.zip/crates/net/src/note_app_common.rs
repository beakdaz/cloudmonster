//! Shared types for note-style web apps (logic lives in `crate::note`).

use anyhow::Result;
use pma_core::Credential;
use std::path::{Path, PathBuf};
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct NoteAppClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for NoteAppClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct NoteAppAccountStats {
    pub service: String,
    pub username: String,
    pub auth_method: String,
    pub inventory_items: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl NoteAppAccountStats {
    pub fn detail_line(&self) -> String {
        let files = crate::stats_display::file_count(self.downloaded, self.inventory_items);
        format!(
            "{} user={} auth={} items={} files={files} ({})",
            self.service,
            self.username,
            self.auth_method,
            self.inventory_items,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

pub struct NoteAppSpec {
    pub service_label: &'static str,
    pub output_slug: &'static str,
    pub user_agent: &'static str,
    pub login_paths: &'static [&'static str],
    pub post_paths: &'static [&'static str],
    pub json_login_paths: &'static [&'static str],
    pub success_probe_paths: &'static [&'static str],
    pub inventory_api_paths: &'static [&'static str],
}

pub async fn download_note_app_account(
    cred: &Credential,
    config: &NoteAppClientConfig,
    output_dir: &Path,
    download_files: bool,
    spec: &NoteAppSpec,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let runtime = std::sync::Arc::new(crate::note::NoteRuntime::new(
        crate::note::NoteRuntimeConfig::from_legacy(config.timeout, config.insecure),
        spec.user_agent,
        None,
    )?);
    crate::note::download_with_runtime(cred, runtime, output_dir, download_files, spec).await
}
