//! Jenkins API client: authenticate, list personal jobs, download configs and artifacts.

use anyhow::{bail, Context, Result};
use pma_core::{is_excluded_media_filename, output_file_path, Credential};
use reqwest::{Client, Url};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

#[derive(Debug, Clone)]
pub struct JenkinsClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for JenkinsClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct JenkinsJob {
    pub name: String,
    pub full_name: String,
    pub url: String,
}

#[derive(Debug, Deserialize)]
struct JenkinsRoot {
    #[serde(rename = "_class")]
    class: Option<String>,
    jobs: Option<Vec<JenkinsJobNode>>,
}

#[derive(Debug, Deserialize)]
struct JenkinsJobNode {
    name: String,
    url: String,
    #[serde(rename = "_class")]
    class: Option<String>,
    jobs: Option<Vec<JenkinsJobNode>>,
}

#[derive(Debug, Deserialize)]
struct JenkinsMe {
    id: String,
    full_name: Option<String>,
    #[serde(default)]
    authorities: Vec<String>,
}

/// Summary shown for successful Jenkins downloads (Good log lines).
#[derive(Debug, Clone)]
pub struct JenkinsAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub jobs: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl JenkinsAccountStats {
    pub fn detail_line(&self) -> String {
        let downloaded = crate::stats_display::file_count(self.downloaded, self.jobs);
        format!(
            "user={} admin={} jobs={} downloaded={downloaded} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.jobs,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

#[derive(Debug, Deserialize, Serialize)]
struct JenkinsBuildRef {
    number: u64,
    result: Option<String>,
    artifacts: Option<Vec<JenkinsArtifact>>,
}

#[derive(Debug, Deserialize)]
struct JenkinsJobBuilds {
    builds: Option<Vec<JenkinsBuildRef>>,
}

const WORKSPACE_CANDIDATES: &[&str] = &[
    "Jenkinsfile",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "package.json",
    "requirements.txt",
    "Dockerfile",
    "docker-compose.yml",
    "README.md",
    ".env",
];

#[derive(Debug, Deserialize, Serialize)]
struct JenkinsArtifact {
    #[serde(rename = "fileName")]
    #[allow(dead_code)]
    file_name: String,
    relative_path: String,
}

pub struct JenkinsClient {
    http: Client,
    base: Url,
    username: String,
    password: String,
}

impl JenkinsClient {
    pub fn new(base: Url, username: &str, password: &str, config: &JenkinsClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-jenkins/0.1");

        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }

        Ok(Self {
            http: builder.build().context("failed to build HTTP client")?,
            base,
            username: username.to_string(),
            password: password.to_string(),
        })
    }

    fn authed(&self, builder: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        builder.basic_auth(&self.username, Some(self.password.as_str()))
    }

    pub async fn detect(&self) -> Result<bool> {
        let url = self
            .base
            .join("api/json")
            .context("failed to build Jenkins api url")?;
        let resp = match self.authed(self.http.get(url.clone())).send().await {
            Ok(resp) => resp,
            Err(err) => {
                // #region agent log
                agent_log(
                    "J2",
                    "jenkins.rs:detect",
                    "connect failed",
                    &format!(
                        r#"{{"base":"{}","api_url":"{}","error":{}}}"#,
                        self.base,
                        url,
                        json_string(&err.to_string())
                    ),
                );
                // #endregion
                return Err(err).with_context(|| {
                    format!(
                        "cannot reach Jenkins at {} (check VPN/network; enable Allow invalid TLS if certificate is bad)",
                        self.base
                    )
                });
            }
        };
        if resp.headers().contains_key("x-jenkins") {
            return Ok(true);
        }
        let status = resp.status();
        let body = resp.text().await?;
        if !status.is_success() {
            return Ok(false);
        }
        let trimmed = body.trim_start();
        if trimmed.starts_with("<!DOCTYPE") || trimmed.starts_with("<html") {
            return Ok(false);
        }
        Ok(serde_json::from_str::<JenkinsRoot>(&body)
            .map(|root| {
                root.class
                    .is_some_and(|c| c.contains("Hudson") || c.contains("Jenkins"))
            })
            .unwrap_or(false))
    }

    pub async fn authenticate(&self) -> Result<(String, bool)> {
        let url = self
            .base
            .join("me/api/json?tree=id,fullName,authorities")
            .context("failed to build Jenkins me url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        let status = resp.status();
        let body = resp.text().await?;
        if !status.is_success() {
            bail!("Jenkins authentication failed (HTTP {status})");
        }
        if body.trim_start().starts_with('<') {
            bail!("Jenkins authentication returned HTML instead of JSON");
        }
        let me: JenkinsMe =
            serde_json::from_str(&body).context("failed to decode Jenkins /me JSON")?;
        let display = me.id.clone();
        let is_admin = me
            .authorities
            .iter()
            .any(|a| a.eq_ignore_ascii_case("admin") || a.eq_ignore_ascii_case("administrator"))
            || me.id.eq_ignore_ascii_case("admin");
        let _ = me.full_name;
        Ok((display, is_admin))
    }

    pub async fn list_personal_jobs(&self, jenkins_user: &str, login: &str) -> Result<Vec<JenkinsJob>> {
        let mut jobs = self
            .list_jobs_at_folder(&format!("user/{jenkins_user}"))
            .await?;
        if jobs.is_empty() && login != jenkins_user {
            jobs = self.list_jobs_at_folder(&format!("user/{login}")).await?;
        }
        if jobs.is_empty() {
            let all = self.list_all_jobs().await?;
            jobs = all
                .into_iter()
                .filter(|job| {
                    job.full_name.starts_with(&format!("{jenkins_user}/"))
                        || job.url.contains(&format!("/user/{jenkins_user}/"))
                        || job.full_name == jenkins_user
                        || (login != jenkins_user
                            && (job.full_name.starts_with(&format!("{login}/"))
                                || job.url.contains(&format!("/user/{login}/"))))
                })
                .collect();
        }
        if jobs.is_empty() {
            jobs = self.list_all_jobs().await?;
        }
        jobs.sort_by(|a, b| a.full_name.cmp(&b.full_name));
        jobs.dedup_by(|a, b| a.url == b.url);
        Ok(jobs)
    }

    async fn list_all_jobs(&self) -> Result<Vec<JenkinsJob>> {
        match self.fetch_job_nodes("").await {
            Ok(nodes) => Ok(flatten_job_nodes(nodes, String::new())),
            Err(err) => {
                warn!("fast Jenkins job listing failed, falling back to folder scan: {err}");
                self.collect_jobs_bfs("", String::new()).await
            }
        }
    }

    async fn list_jobs_at_folder(&self, folder: &str) -> Result<Vec<JenkinsJob>> {
        match self.fetch_job_nodes(folder).await {
            Ok(nodes) => Ok(flatten_job_nodes(
                nodes,
                folder.trim_end_matches('/').to_string(),
            )),
            Err(err) => {
                warn!("fast folder listing failed for {folder}: {err}");
                self.collect_jobs_bfs(folder, folder.trim_end_matches('/').to_string())
                    .await
            }
        }
    }

    async fn collect_jobs_bfs(&self, start_folder: &str, prefix: String) -> Result<Vec<JenkinsJob>> {
        let mut jobs = Vec::new();
        let mut folders = vec![(start_folder.to_string(), prefix)];

        while let Some((folder, folder_prefix)) = folders.pop() {
            let nodes = self.fetch_job_nodes_shallow(&folder).await?;
            for node in nodes {
                let full_name = if folder_prefix.is_empty() {
                    node.name.clone()
                } else {
                    format!("{}/{}", folder_prefix, node.name)
                };
                if is_folder(&node) {
                    folders.push((full_name.clone(), full_name));
                } else {
                    jobs.push(JenkinsJob {
                        name: node.name,
                        full_name,
                        url: node.url,
                    });
                }
            }
        }

        Ok(jobs)
    }

    async fn fetch_job_nodes_shallow(&self, folder: &str) -> Result<Vec<JenkinsJobNode>> {
        let tree = "jobs[name,url,_class,jobs[name,url,_class]]";
        let path = if folder.is_empty() {
            format!("api/json?tree={tree}")
        } else {
            format!(
                "job/{}/api/json?tree={tree}",
                encode_jenkins_path(folder.trim_end_matches('/'))
            )
        };
        let url = self.base.join(&path).context("failed to build jobs url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        let status = resp.status();
        let body = resp.text().await?;
        if status.as_u16() == 404 {
            return Ok(Vec::new());
        }
        if !status.is_success() {
            bail!("Jenkins jobs API error {status}: {}", preview(&body));
        }
        if body.trim_start().starts_with('<') {
            bail!("Jenkins jobs API returned HTML instead of JSON");
        }
        let root: JenkinsRoot =
            serde_json::from_str(&body).context("failed to decode Jenkins jobs JSON")?;
        Ok(root.jobs.unwrap_or_default())
    }

    async fn fetch_job_nodes(&self, folder: &str) -> Result<Vec<JenkinsJobNode>> {
        let tree = "jobs[name,url,_class,jobs[name,url,_class,jobs[name,url,_class,jobs[name,url,_class,jobs[name,url,_class]]]]";
        let path = if folder.is_empty() {
            format!("api/json?depth=10&tree={tree}")
        } else {
            format!(
                "job/{}/api/json?depth=10&tree={tree}",
                encode_jenkins_path(folder.trim_end_matches('/'))
            )
        };
        let url = self.base.join(&path).context("failed to build jobs url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        let status = resp.status();
        let body = resp.text().await?;
        if status.as_u16() == 404 {
            return Ok(Vec::new());
        }
        if !status.is_success() {
            bail!("Jenkins jobs API error {status}: {}", preview(&body));
        }
        if body.trim_start().starts_with('<') {
            bail!("Jenkins jobs API returned HTML instead of JSON");
        }
        let root: JenkinsRoot =
            serde_json::from_str(&body).context("failed to decode Jenkins jobs JSON")?;
        Ok(root.jobs.unwrap_or_default())
    }

    pub async fn download_job(&self, job: &JenkinsJob, run_output_dir: &Path, file_prefix: &str) -> Result<u64> {
        let safe_name = safe_path_component(&job.full_name);
        let p = |suffix: &str| {
            let leaf = format!("{file_prefix}__{safe_name}__{suffix}");
            output_file_path(run_output_dir, &leaf)
        };

        let mut total = 0u64;
        let mut files = 0u64;

        if self
            .download_bytes_to(
                self.job_api_url(job, "config.xml")?,
                &p("config.xml"),
            )
            .await
            .is_ok()
        {
            total += fs::metadata(&p("config.xml"))
                .await
                .map(|m| m.len())
                .unwrap_or(0);
            files += 1;
        }

        if self
            .download_bytes_to(
                self.job_api_url(job, "api/json")?,
                &p("job.json"),
            )
            .await
            .is_ok()
        {
            files += 1;
            total += fs::metadata(&p("job.json"))
                .await
                .map(|m| m.len())
                .unwrap_or(0);
        }

        let (build_bytes, build_files) = self
            .download_recent_builds(job, run_output_dir, file_prefix, &safe_name)
            .await
            .unwrap_or((0, 0));
        total += build_bytes;
        files += build_files;

        let (ws_bytes, ws_files) = self
            .download_workspace_files(job, run_output_dir, file_prefix, &safe_name)
            .await
            .unwrap_or((0, 0));
        total += ws_bytes;
        files += ws_files;

        if files == 0 {
            bail!("no files downloaded for {}", job.full_name);
        }

        Ok(total)
    }

    async fn download_recent_builds(
        &self,
        job: &JenkinsJob,
        output_dir: &Path,
        file_prefix: &str,
        safe_name: &str,
    ) -> Result<(u64, u64)> {
        let url = self.job_api_url(
            job,
            "api/json?tree=builds[number,result,artifacts[fileName,relativePath]]",
        )?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            return Ok((0, 0));
        }
        let body = resp.text().await?;
        let info: JenkinsJobBuilds = match serde_json::from_str(&body) {
            Ok(v) => v,
            Err(_) => return Ok((0, 0)),
        };
        let Some(builds) = info.builds else {
            return Ok((0, 0));
        };

        let mut total = 0u64;
        let mut files = 0u64;
        for build in builds.into_iter().take(5) {
            let build_tag = format!("build-{}", build.number);
            let p = |suffix: &str| {
                let leaf = format!("{file_prefix}__{safe_name}__{build_tag}__{suffix}");
                output_file_path(output_dir, &leaf)
            };

            if let Ok(meta) = serde_json::to_string_pretty(&build) {
                let meta_path = p("build.json");
                fs::write(&meta_path, meta).await?;
                files += 1;
                total += fs::metadata(&meta_path).await.map(|m| m.len()).unwrap_or(0);
            }

            let console_path = p("console.log");
            if self
                .download_bytes_to(
                    self.job_api_url(job, &format!("{}/consoleText", build.number))?,
                    &console_path,
                )
                .await
                .is_ok()
            {
                files += 1;
                total += fs::metadata(&console_path).await.map(|m| m.len()).unwrap_or(0);
            }

            if let Some(artifacts) = build.artifacts {
                for artifact in artifacts {
                    let art_path = &artifact.relative_path;
                    if is_excluded_media_filename(art_path) {
                        continue;
                    }
                    let art_name = safe_path_component(&art_path.replace('/', "__"));
                    let leaf = format!("{file_prefix}__{safe_name}__{build_tag}__artifact__{art_name}");
                    let path = output_file_path(output_dir, &leaf);
                    if self
                        .download_bytes_to(
                            self.job_api_url(
                                job,
                                &format!("{}/artifact/{}", build.number, artifact.relative_path),
                            )?,
                            &path,
                        )
                        .await
                        .is_ok()
                    {
                        files += 1;
                        total += fs::metadata(&path).await.map(|m| m.len()).unwrap_or(0);
                    }
                }
            }
        }

        Ok((total, files))
    }

    async fn download_workspace_files(
        &self,
        job: &JenkinsJob,
        output_dir: &Path,
        file_prefix: &str,
        safe_name: &str,
    ) -> Result<(u64, u64)> {
        let mut total = 0u64;
        let mut files = 0u64;
        for rel in WORKSPACE_CANDIDATES {
            if is_excluded_media_filename(rel) {
                continue;
            }
            let leaf = format!(
                "{file_prefix}__{safe_name}__ws__{}",
                safe_path_component(rel)
            );
            let path = output_file_path(output_dir, &leaf);
            if self
                .download_bytes_to(self.job_api_url(job, &format!("ws/{rel}"))?, &path)
                .await
                .is_ok()
            {
                files += 1;
                total += fs::metadata(&path).await.map(|m| m.len()).unwrap_or(0);
            }
        }
        Ok((total, files))
    }

    async fn download_bytes_to(&self, url: Url, output_path: &Path) -> Result<u64> {
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("HTTP {}", resp.status());
        }
        let bytes = resp.bytes().await?;
        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut file = fs::File::create(output_path).await?;
        file.write_all(&bytes).await?;
        Ok(bytes.len() as u64)
    }

    fn job_api_url(&self, job: &JenkinsJob, suffix: &str) -> Result<Url> {
        let path = format!("{}/{}", jenkins_job_api_path(&job.full_name), suffix.trim_start_matches('/'));
        self.base.join(&path).context("invalid jenkins job url")
    }

}

fn flatten_job_nodes(nodes: Vec<JenkinsJobNode>, prefix: String) -> Vec<JenkinsJob> {
    let mut jobs = Vec::new();
    for node in nodes {
        let full_name = if prefix.is_empty() {
            node.name.clone()
        } else {
            format!("{}/{}", prefix, node.name)
        };
        if is_folder(&node) {
            if let Some(children) = node.jobs {
                jobs.extend(flatten_job_nodes(children, full_name));
            }
        } else {
            jobs.push(JenkinsJob {
                name: node.name,
                full_name,
                url: node.url,
            });
        }
    }
    jobs
}

fn is_folder(node: &JenkinsJobNode) -> bool {
    node.class.as_deref().is_some_and(|c| {
        c.contains("folder.Folder")
            || c.contains("OrganizationFolder")
            || c.ends_with(".Folder")
    })
}

fn jenkins_job_api_path(full_name: &str) -> String {
    full_name
        .split('/')
        .map(|segment| format!("job/{}", encode_jenkins_path(segment)))
        .collect::<Vec<_>>()
        .join("/")
}

fn encode_jenkins_path(path: &str) -> String {
    path.split('/')
        .map(|segment| {
            segment
                .bytes()
                .fold(String::new(), |mut acc, b| {
                    match b {
                        b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                            acc.push(b as char);
                        }
                        _ => {
                            use std::fmt::Write;
                            let _ = write!(acc, "%{b:02X}");
                        }
                    }
                    acc
                })
        })
        .collect::<Vec<_>>()
        .join("/")
}

fn preview(body: &str) -> String {
    body.chars().take(160).collect::<String>().replace('\n', " ")
}

pub fn safe_path_component(input: &str) -> String {
    input
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

// #region agent log
fn agent_log(hypothesis_id: &str, location: &str, message: &str, data: &str) {
    use std::io::Write;
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let line = format!(
        r#"{{"sessionId":"be3b27","hypothesisId":"{hypothesis_id}","location":"{location}","message":"{message}","data":{data},"timestamp":{ts}}}"#
    );
    if let Ok(mut f) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}

fn json_string(value: &str) -> String {
    serde_json::Value::String(value.to_string()).to_string()
}
// #endregion

pub async fn download_personal_jobs(
    cred: &Credential,
    config: &JenkinsClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(JenkinsAccountStats, Vec<(JenkinsJob, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_personal_jobs_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_personal_jobs_once(
    cred: Credential,
    config: &JenkinsClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(JenkinsAccountStats, Vec<(JenkinsJob, PathBuf, u64)>)> {
    // #region agent log
    agent_log(
        "J1",
        "jenkins.rs:download_personal_jobs",
        "parsed credential",
        &format!(
            r#"{{"url":"{}","username":"{}","password_len":{},"insecure":{}}}"#,
            cred.url,
            cred.username,
            cred.password.len(),
            config.insecure
        ),
    );
    // #endregion
    let client = JenkinsClient::new(
        cred.url.clone(),
        &cred.username,
        &cred.password,
        config,
    )?;
    if !client.detect().await? {
        bail!(
            "{} is not a Jenkins server (no /api/json Jenkins response)",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let (jenkins_user, is_admin) = client.authenticate().await.with_context(|| {
        format!("login failed for {}", cred.display_line())
    })?;

    let jobs = client
        .list_personal_jobs(&jenkins_user, &cred.username)
        .await
        .with_context(|| format!("failed to list jobs for {}", cred.display_line()))?;

    if jobs.is_empty() {
        bail!(
            "no Jenkins jobs visible for {} (logged in as {jenkins_user})",
            cred.display_line()
        );
    }

    let job_count = jobs.len();
    if !download_files {
        return Ok((
            JenkinsAccountStats {
                username: jenkins_user,
                is_admin,
                jobs: job_count,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "jenkins");
    let prefix = cred.account_file_prefix();

    let mut written = Vec::new();
    for job in jobs {
        match client.download_job(&job, &site_dir, &prefix).await {
            Ok(bytes) => {
                let leaf = format!(
                    "{}__{}__config.xml",
                    prefix,
                    safe_path_component(&job.full_name)
                );
                let path = output_file_path(&site_dir, &leaf);
                debug!(
                    "downloaded Jenkins job {} ({} bytes) for {}",
                    job.full_name,
                    bytes,
                    cred.display_line()
                );
                written.push((job, path, bytes));
            }
            Err(err) => warn!(
                "failed to download Jenkins job {} for {}: {err}",
                job.full_name,
                cred.display_line()
            ),
        }
    }

    if written.is_empty() {
        bail!(
            "found {job_count} Jenkins jobs for {} but failed to download any config/artifacts",
            cred.display_line()
        );
    }

    let bytes: u64 = written.iter().map(|(_, _, b)| *b).sum();
    Ok((
        JenkinsAccountStats {
            username: jenkins_user,
            is_admin,
            jobs: job_count,
            downloaded: written.len(),
            bytes,
        },
        written,
    ))
}
