use crate::note_app_common::{download_note_app_account, NoteAppAccountStats, NoteAppSpec};
use anyhow::Result;
use pma_core::Credential;
use std::path::{Path, PathBuf};

pub use crate::note_app_common::NoteAppClientConfig as WorkflowyClientConfig;

const SPEC: NoteAppSpec = NoteAppSpec {
    service_label: "Workflowy",
    output_slug: "workflowy",
    user_agent: "phpmyadmin-rs-workflowy/0.1",
    login_paths: &["login", "app", ""],
    post_paths: &["api/login", "login", "auth/login"],
    json_login_paths: &["api/auth", "api/login", "login"],
    success_probe_paths: &["api/data", "app", "api/me", ""],
    inventory_api_paths: &["api/data", "api/v1/files"],
};

pub async fn download_workflowy_account(
    cred: &Credential,
    config: &WorkflowyClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    download_note_app_account(cred, config, output_dir, download_files, &SPEC).await
}
