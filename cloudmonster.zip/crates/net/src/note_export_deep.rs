//! Deeper REST exports for Todoist, Joplin Cloud, and Zotero.

use anyhow::{Context, Result};
use cached::proc_macro::cached;
use pma_core::{output_file_path, Credential, NoteExportService};
use reqwest::Client;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use tokio::fs;

async fn write_json(
    site_dir: &Path,
    prefix: &str,
    name: &str,
    value: &Value,
) -> Result<(PathBuf, u64)> {
    let leaf = format!("{prefix}__deep_{name}.json");
    let path = output_file_path(site_dir, &leaf);
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await.ok();
    }
    let text = serde_json::to_string_pretty(value)?;
    let bytes = text.len() as u64;
    fs::write(&path, &text).await?;
    Ok((path, bytes))
}

fn todoist_api_token(cred: &Credential) -> Option<String> {
    let pass = cred.password.trim();
    let pass = pass
        .strip_prefix("token:")
        .or_else(|| pass.strip_prefix("api:"))
        .unwrap_or(pass)
        .trim();
    if pass.len() >= 32 && !pass.contains(' ') {
        return Some(pass.to_string());
    }
    None
}

#[cached(
    time = 3600,
    size = 5000,
    key = "String",
    convert = r#"{ format!("todoist-api:{}", cred.username) }"#
)]
fn todoist_api_token_cached(cred: &Credential) -> Option<String> {
    todoist_api_token(cred)
}

async fn todoist_login_token(http: &Client, cred: &Credential) -> Result<Option<String>> {
    if let Some(t) = todoist_api_token_cached(cred) {
        return Ok(Some(t));
    }
    let resp = http
        .post("https://api.todoist.com/user/login")
        .form(&[
            ("email", cred.username.as_str()),
            ("password", cred.password.as_str()),
        ])
        .send()
        .await
        .context("todoist user/login")?;
    if !resp.status().is_success() {
        return Ok(None);
    }
    let v: Value = resp.json().await.unwrap_or(Value::Null);
    Ok(v.get("token")
        .or_else(|| v.get("access_token"))
        .and_then(|x| x.as_str())
        .map(str::to_string))
}

async fn todoist_deep(
    http: &Client,
    cred: &Credential,
    site_dir: &Path,
    prefix: &str,
) -> Result<Vec<(PathBuf, u64)>> {
    let Some(token) = todoist_login_token(http, cred).await? else {
        return Ok(Vec::new());
    };
    let mut out = Vec::new();

    let projects = http
        .get("https://api.todoist.com/rest/v2/projects")
        .header("Authorization", format!("Bearer {token}"))
        .send()
        .await
        .context("todoist projects")?;
    if projects.status().is_success() {
        let v: Value = projects.json().await.unwrap_or(Value::Null);
        out.push(write_json(site_dir, prefix, "todoist_projects", &v).await?);
    }

    let sync = http
        .post("https://api.todoist.com/sync/v9/sync")
        .header("Authorization", format!("Bearer {token}"))
        .json(&json!({
            "sync_token": "*",
            "resource_types": ["projects", "items", "notes", "sections", "labels"],
        }))
        .send()
        .await
        .context("todoist sync")?;
    if sync.status().is_success() {
        let v: Value = sync.json().await.unwrap_or(Value::Null);
        out.push(write_json(site_dir, prefix, "todoist_sync", &v).await?);
    }

    Ok(out)
}

async fn joplin_session_token(http: &Client, cred: &Credential) -> Result<Option<String>> {
    let mut bases: Vec<String> = vec![
        "https://joplincloud.com".into(),
        "https://api.joplincloud.com".into(),
    ];
    let origin = cred.url.origin().ascii_serialization();
    if !origin.is_empty() {
        bases.push(origin.trim_end_matches('/').to_string());
    }
    for base in bases {
        let url = format!("{base}/api/sessions");
        let resp = http
            .post(&url)
            .json(&json!({
                "email": cred.username,
                "password": cred.password,
            }))
            .send()
            .await;
        let Ok(resp) = resp else { continue };
        if !resp.status().is_success() {
            continue;
        }
        let v: Value = resp.json().await.unwrap_or(Value::Null);
        if let Some(t) = v
            .get("token")
            .or_else(|| v.get("api_token"))
            .and_then(|x| x.as_str())
        {
            return Ok(Some(t.to_string()));
        }
    }
    Ok(None)
}

async fn joplin_deep(
    http: &Client,
    cred: &Credential,
    site_dir: &Path,
    prefix: &str,
) -> Result<Vec<(PathBuf, u64)>> {
    let Some(token) = joplin_session_token(http, cred).await? else {
        return Ok(Vec::new());
    };
    let mut all_items = Vec::new();
    let mut page = 1u32;
    loop {
        let url = format!(
            "https://joplincloud.com/api/items?token={}&page={}&limit=100",
            urlencoding_encode(&token),
            page
        );
        let resp = http.get(&url).send().await.context("joplin items")?;
        if !resp.status().is_success() {
            break;
        }
        let v: Value = resp.json().await.unwrap_or(Value::Null);
        let batch = v
            .get("items")
            .and_then(|x| x.as_array())
            .cloned()
            .unwrap_or_default();
        if batch.is_empty() {
            if page == 1 {
                if let Some(arr) = v.as_array() {
                    all_items.extend(arr.clone());
                }
            }
            break;
        }
        let batch_len = batch.len();
        all_items.extend(batch);
        let has_more = v.get("has_more").and_then(|x| x.as_bool()).unwrap_or(false);
        if !has_more && batch_len < 100 {
            break;
        }
        page += 1;
        if page > 500 {
            break;
        }
    }
    let mut out = Vec::new();
    out.push(
        write_json(
            site_dir,
            prefix,
            "joplin_items",
            &json!({
                "count": all_items.len(),
                "items": all_items,
            }),
        )
        .await?,
    );
    Ok(out)
}

fn urlencoding_encode(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}

fn zotero_api_key(cred: &Credential) -> Option<String> {
    let pass = cred.password.trim();
    let pass = pass
        .strip_prefix("token:")
        .or_else(|| pass.strip_prefix("api:"))
        .unwrap_or(pass)
        .trim();
    if pass.len() >= 8 && pass.len() <= 64 && pass.chars().all(|c| c.is_ascii_alphanumeric()) {
        return Some(pass.to_string());
    }
    None
}

async fn zotero_deep(
    http: &Client,
    cred: &Credential,
    site_dir: &Path,
    prefix: &str,
) -> Result<Vec<(PathBuf, u64)>> {
    let Some(key) = zotero_api_key(cred) else {
        return Ok(Vec::new());
    };
    let key_info = http
        .get(format!("https://api.zotero.org/keys/{key}"))
        .header("Zotero-API-Key", &key)
        .send()
        .await
        .context("zotero keys")?;
    if !key_info.status().is_success() {
        return Ok(Vec::new());
    }
    let key_v: Value = key_info.json().await.unwrap_or(Value::Null);
    let user_id = key_v
        .get("userID")
        .and_then(|x| x.as_u64())
        .or_else(|| {
            key_v
                .get("userID")
                .and_then(|x| x.as_str())
                .and_then(|s| s.parse().ok())
        });
    let Some(user_id) = user_id else {
        return Ok(vec![write_json(site_dir, prefix, "zotero_key", &key_v).await?]);
    };

    let mut out = vec![write_json(site_dir, prefix, "zotero_key", &key_v).await?];
    let mut all = Vec::new();
    let mut start = 0u32;
    loop {
        let url = format!("https://api.zotero.org/users/{user_id}/items?limit=100&start={start}");
        let resp = http
            .get(&url)
            .header("Zotero-API-Key", &key)
            .send()
            .await
            .context("zotero items")?;
        if !resp.status().is_success() {
            break;
        }
        let v: Value = resp.json().await.unwrap_or(Value::Null);
        let batch = v.as_array().cloned().unwrap_or_default();
        let n = batch.len();
        all.extend(batch);
        if n < 100 {
            break;
        }
        start += 100;
        if start > 50_000 {
            break;
        }
    }
    out.push(
        write_json(
            site_dir,
            prefix,
            "zotero_library",
            &json!({ "user_id": user_id, "count": all.len(), "items": all }),
        )
        .await?,
    );
    Ok(out)
}

pub async fn deep_note_exports(
    service: NoteExportService,
    http: &Client,
    cred: &Credential,
    site_dir: &Path,
    prefix: &str,
) -> Result<Vec<(PathBuf, u64)>> {
    match service {
        NoteExportService::Todoist => todoist_deep(http, cred, site_dir, prefix).await,
        NoteExportService::Joplin => joplin_deep(http, cred, site_dir, prefix).await,
        NoteExportService::Zotero => zotero_deep(http, cred, site_dir, prefix).await,
        _ => Ok(Vec::new()),
    }
}
