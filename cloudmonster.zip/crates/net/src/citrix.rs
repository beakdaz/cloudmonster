//! Citrix NetScaler Gateway / AAA VPN: `/cgi/login`, session cookies `NSC_*`.

use anyhow::{bail, Context, Result};
use crate::http_client::apply_proxy;
use pma_core::{citrix_portal_origin, Credential};
use reqwest::{Client, StatusCode, Url};
use std::time::Duration;

fn response_has_nsc_cookie(headers: &reqwest::header::HeaderMap) -> bool {
    headers.iter().any(|(name, _)| name.as_str().eq_ignore_ascii_case("set-cookie"))
        && headers
            .get_all("set-cookie")
            .iter()
            .any(|v| v.to_str().unwrap_or("").to_ascii_lowercase().contains("nsc_"))
}

#[derive(Debug, Clone)]
pub struct CitrixClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
    /// HTTP(S) or SOCKS5 proxy URL, e.g. `http://127.0.0.1:8080` or `socks5://127.0.0.1:1080`.
    pub proxy: Option<String>,
}

impl Default for CitrixClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
            proxy: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct CitrixAccountStats {
    pub username: String,
    pub auth_method: String,
    pub portal_path: String,
    pub downloaded: usize,
    pub bytes: u64,
}

impl CitrixAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "auth={} user={} portal={} files={}",
            self.auth_method, self.username, self.portal_path, self.downloaded,
        )
    }
}

pub struct CitrixClient {
    http: Client,
    origin: Url,
    portal_url: Url,
    username: String,
    password: String,
}

impl CitrixClient {
    pub fn new(
        portal: Url,
        username: &str,
        password: &str,
        config: &CitrixClientConfig,
    ) -> Result<Self> {
        let origin = citrix_portal_origin(&portal)?;
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::none())
            .timeout(config.timeout)
            .user_agent(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
            );
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        builder = apply_proxy(builder, config.proxy.as_deref())?;
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            origin,
            portal_url: portal,
            username: username.to_string(),
            password: password.to_string(),
        })
    }

    pub async fn detect(&self) -> Result<bool> {
        let portal_body = self.fetch(self.portal_url.clone()).await?;
        let portal_hit = self.page_looks_like_citrix(&portal_body).await?;
        if portal_hit {
            return Ok(true);
        }
        if portal_body.is_empty() && self.portal_url.path().contains("/vpn/") {
            return Ok(true);
        }
        if self.portal_url.path().contains("/vpn/") && !portal_body.is_empty() {
            let lower = portal_body.to_ascii_lowercase();
            if lower.contains("passwd")
                || lower.contains("/cgi/login")
                || lower.contains("storefront")
                || lower.contains("wfica")
                || lower.contains("cvpn")
                || lower.contains("samlrequest")
                || lower.contains("/cgi/samlauth")
                || (lower.contains("visibility: hidden") && lower.contains("document.forms[0].submit"))
            {
                return Ok(true);
            }
        }
        let index = self.origin.join("vpn/index.html")?;
        if self.page_looks_like_citrix(&self.fetch(index).await?).await? {
            return Ok(true);
        }
        Ok(false)
    }

    async fn fetch(&self, url: Url) -> Result<String> {
        let mut current = url;
        for _ in 0..8 {
            let resp = match self.http.get(current.clone()).send().await {
                Ok(r) => r,
                Err(e) => {
                    let msg = format!("{e:#}");
                    if msg.contains("too many redirects") {
                        return Ok(String::new());
                    }
                    return Err(e.into());
                }
            };
            if resp.status().is_redirection() {
                let Some(loc) = resp
                    .headers()
                    .get(reqwest::header::LOCATION)
                    .and_then(|v| v.to_str().ok())
                else {
                    return Ok(resp.text().await.unwrap_or_default());
                };
                current = resolve_redirect_url(&current, loc)?;
                continue;
            }
            return Ok(resp.text().await.unwrap_or_default());
        }
        Ok(String::new())
    }

    async fn page_looks_like_citrix(&self, body: &str) -> Result<bool> {
        Ok(citrix_gateway_page(body))
    }

    pub async fn authenticate(&self) -> Result<String> {
        let mut notes: Vec<String> = Vec::new();
        match self.try_cgi_login().await {
            Ok(true) => return Ok("cgi_login".into()),
            Ok(false) => notes.push("cgi/login: rejected".into()),
            Err(e) => notes.push(format!("cgi/login: {e:#}")),
        }
        match self.try_logon_do_auth().await {
            Ok(true) => return Ok("doAuthentication".into()),
            Ok(false) => notes.push("doAuthentication: rejected".into()),
            Err(e) => notes.push(format!("doAuthentication: {e:#}")),
        }
        let detail = notes.join("; ");
        bail!("Citrix VPN login failed ({detail})")
    }

    async fn try_cgi_login(&self) -> Result<bool> {
        let _ = self.fetch(self.portal_url.clone()).await?;
        let domains = self.portal_user_domains().await?;
        let tries = if domains.is_empty() { 1 } else { domains.len() };
        let url = self.origin.join("cgi/login").context("cgi/login url")?;

        for i in 0..tries {
            let mut form: Vec<(&str, &str)> = vec![
                ("dummy_username", ""),
                ("dummy_pass1", ""),
                ("login", self.username.as_str()),
                ("passwd", self.password.as_str()),
            ];
            let domain_owned;
            if !domains.is_empty() {
                domain_owned = domains[i].clone();
                form.push(("domainvalue", domain_owned.as_str()));
            }
            let resp = match self
                .http
                .post(url.clone())
                .header(reqwest::header::REFERER, self.portal_url.as_str())
                .header(reqwest::header::CONTENT_TYPE, "application/x-www-form-urlencoded")
                .form(&form)
                .send()
                .await
            {
                Ok(r) => r,
                Err(e) => return Err(e.into()),
            };
            let headers = resp.headers().clone();
            let location = headers
                .get(reqwest::header::LOCATION)
                .and_then(|v| v.to_str().ok())
                .unwrap_or("")
                .to_string();
            let body = resp.text().await.unwrap_or_default();
            let tmcr = citrix_tmcr_cgi_login_result(&location, &body);
            match tmcr {
                CitrixTmcrResult::Good => return Ok(true),
                CitrixTmcrResult::Bad => continue,
                CitrixTmcrResult::Indeterminate => {
                    if citrix_login_post_failed(&body) {
                        continue;
                    }
                    if self.session_verified(&body, &headers).await? {
                        return Ok(true);
                    }
                }
            }
        }
        Ok(false)
    }

    async fn portal_user_domains(&self) -> Result<Vec<String>> {
        let resp = self.http.get(self.portal_url.clone()).send().await?;
        let mut out = Vec::new();
        for cookie in resp.headers().get_all(reqwest::header::SET_COOKIE) {
            let s = cookie.to_str().unwrap_or("");
            if !s.contains("userDomains=") {
                continue;
            }
            let Some(start) = s.find("userDomains=") else {
                continue;
            };
            let rest = &s[start + "userDomains=".len()..];
            let end = rest.find(';').unwrap_or(rest.len());
            for part in rest[..end].split(',') {
                let d = part.trim();
                if !d.is_empty() && !d.eq_ignore_ascii_case("unspecified") {
                    out.push(d.to_string());
                }
            }
        }
        Ok(out)
    }

    async fn try_logon_do_auth(&self) -> Result<bool> {
        let url = self
            .origin
            .join("p/u/doAuthentication.do")
            .context("doAuthentication url")?;
        let form = [
            ("login", self.username.as_str()),
            ("passwd", self.password.as_str()),
            ("Login", "Log On"),
        ];
        let resp = self.http.post(url.clone()).form(&form).send().await?;
        let status = resp.status();
        let headers = resp.headers().clone();
        let nsc = response_has_nsc_cookie(&headers);
        let body = resp.text().await.unwrap_or_default();
        let post_failed = citrix_login_post_failed(&body);
        self.follow_login_refresh(&body).await?;
        let session_ok = if post_failed {
            false
        } else if status.is_redirection() || nsc || status.is_success() {
            self.session_verified(&body, &headers).await?
        } else {
            false
        };
        Ok(session_ok)
    }

    async fn session_verified(
        &self,
        post_body: &str,
        post_headers: &reqwest::header::HeaderMap,
    ) -> Result<bool> {
        let post_signals = citrix_post_login_signals(post_body);
        let page = self.fetch_portal_page(self.portal_url.path()).await?;
        let resources = self.citrix_resources_state().await?;
        let setclient = self.fetch_setclient_state().await?;
        let homepage_authed = citrix_authenticated_portal(&page.body);
        let resources_unauthorized = resources.unauthorized;
        let post_succeeded = citrix_login_post_succeeded(post_body, post_headers);

        let post_failed = citrix_login_post_failed(post_body);
        let gateway_rule = citrix_gateway_login_accept(
            post_body,
            post_headers,
            &post_signals,
            &page.body,
            page.login_form,
        );

        let ok = if citrix_post_explicit_failure(&post_signals) {
            false
        } else if setclient.authenticated {
            true
        } else if !resources_unauthorized && (resources.published_count > 0 || homepage_authed) {
            true
        } else if post_succeeded && homepage_authed && !page.login_form {
            true
        } else if gateway_rule.is_some() && !citrix_saml_sso_page(post_body) {
            true
        } else if resources_unauthorized {
            false
        } else if response_has_nsc_cookie(post_headers)
            && !post_failed
            && !page.login_form
            && homepage_authed
        {
            true
        } else {
            false
        };

        Ok(ok)
    }

    async fn fetch_setclient_state(&self) -> Result<SetclientState> {
        let url = self.origin.join("cgi/setclient")?;
        let resp = self.http.get(url).send().await?;
        let status = resp.status().as_u16();
        if !resp.status().is_success() {
            return Ok(SetclientState {
                status,
                authenticated: false,
                body_len: 0,
            });
        }
        let body = resp.text().await.unwrap_or_default();
        let authenticated = citrix_setclient_session(&body);
        Ok(SetclientState {
            status,
            authenticated,
            body_len: body.len(),
        })
    }

    async fn fetch_portal_page(&self, path: &str) -> Result<PortalPageState> {
        let path = if path.is_empty() { "/" } else { path };
        let url = if path.starts_with("http") {
            Url::parse(path).context("portal url")?
        } else {
            self.origin.join(path.trim_start_matches('/'))?
        };
        let resp = match self.http.get(url).send().await {
            Ok(r) => r,
            Err(e) if format!("{e:#}").contains("too many redirects") => {
                return Ok(PortalPageState {
                    status: 0,
                    login_form: false,
                    body: String::new(),
                });
            }
            Err(e) => return Err(e.into()),
        };
        let status = resp.status().as_u16();
        let body = resp.text().await.unwrap_or_default();
        let lower = body.to_ascii_lowercase();
        let login_form = lower.contains("name=\"passwd\"")
            || lower.contains("name='passwd'")
            || lower.contains("id=\"passwd\"")
            || lower.contains("please log on")
            || lower.contains("please enter your user name");
        Ok(PortalPageState {
            status,
            login_form,
            body,
        })
    }

    async fn citrix_resources_state(&self) -> Result<ResourcesState> {
        let url = self
            .origin
            .join("cgi/resources/list")
            .context("resources list url")?;
        let resp = self.http.get(url).send().await?;
        let status = resp.status().as_u16();
        if !resp.status().is_success() {
            return Ok(ResourcesState {
                status,
                published_count: 0,
                unauthorized: false,
            });
        }
        let body = resp.text().await.unwrap_or_default();
        let published_count = count_citrix_published_resources(&body);
        let unauthorized = resources_json_unauthorized(&body);
        Ok(ResourcesState {
            status,
            published_count,
            unauthorized,
        })
    }

    async fn follow_login_refresh(&self, body: &str) -> Result<()> {
        let Some(target) = meta_refresh_target(body) else {
            return Ok(());
        };
        let url = if target.starts_with("http") {
            Url::parse(&target)?
        } else {
            self.origin.join(target.trim_start_matches('/'))?
        };
        let _ = self.http.get(url).send().await?;
        Ok(())
    }
}

struct PortalPageState {
    status: u16,
    login_form: bool,
    body: String,
}

struct ResourcesState {
    status: u16,
    published_count: usize,
    unauthorized: bool,
}

struct SetclientState {
    status: u16,
    authenticated: bool,
    body_len: usize,
}

fn count_citrix_published_resources(body: &str) -> usize {
    let trimmed = body.trim();
    if trimmed.is_empty() {
        return 0;
    }
    if let Ok(v) = serde_json::from_str::<serde_json::Value>(trimmed) {
        if v.get("unauthorized").and_then(|u| u.as_bool()) == Some(true) {
            return 0;
        }
        if let Some(arr) = v.get("resources").and_then(|r| r.as_array()) {
            return arr.len();
        }
        if let Some(arr) = v.get("Resources").and_then(|r| r.as_array()) {
            return arr.len();
        }
        if v.is_array() {
            return v.as_array().map(|a| a.len()).unwrap_or(0);
        }
    }
    0
}

fn resources_json_unauthorized(body: &str) -> bool {
    let trimmed = body.trim();
    if trimmed.is_empty() {
        return false;
    }
    serde_json::from_str::<serde_json::Value>(trimmed)
        .ok()
        .and_then(|v| v.get("unauthorized").and_then(|u| u.as_bool()))
        == Some(true)
}

fn meta_refresh_target(body: &str) -> Option<String> {
    let lower = body.to_ascii_lowercase();
    let needle = "url=";
    let idx = lower.find(needle)?;
    let rest = &body[idx + needle.len()..];
    let end = rest
        .find(['"', '\'', '>', ' ', '\r', '\n'])
        .unwrap_or(rest.len());
    let target = rest[..end].trim();
    if target.is_empty() {
        None
    } else {
        Some(target.to_string())
    }
}

fn citrix_setclient_session(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    if lower.contains("visibility:hidden") || lower.contains("visibility: hidden") {
        return false;
    }
    if lower.contains("please log on")
        || lower.contains("name=\"passwd\"")
        || lower.contains("authentication failed")
    {
        return false;
    }
    lower.contains("wfica")
        || lower.contains("launch/applications")
        || lower.contains("icafile")
        || lower.contains("ngsc.launch")
        || lower.contains("clientconfiguration")
        || lower.contains("nscode=")
}

fn resolve_redirect_url(base: &Url, location: &str) -> Result<Url> {
    if location.starts_with("http://") || location.starts_with("https://") {
        Ok(Url::parse(location)?)
    } else {
        Ok(base.join(location)?)
    }
}

fn citrix_tmcr_cgi_login_result(location: &str, body: &str) -> CitrixTmcrResult {
    let loc = location.to_ascii_lowercase();
    if loc.contains("/cgi/setclient") && loc.contains("wica") {
        return CitrixTmcrResult::Good;
    }
    if loc.contains("/vpn/index.html") {
        return CitrixTmcrResult::Bad;
    }
    let lower = body.to_ascii_lowercase();
    if lower.contains("login.microsoftonline.com") || lower.contains("launcher.myapps.microsoft.com") {
        return CitrixTmcrResult::Bad;
    }
    CitrixTmcrResult::Indeterminate
}

#[derive(Debug, Clone, Copy, serde::Serialize)]
#[serde(rename_all = "lowercase")]
enum CitrixTmcrResult {
    Good,
    Bad,
    Indeterminate,
}

fn citrix_post_login_signals(body: &str) -> serde_json::Value {
    let lower = body.to_ascii_lowercase();
    serde_json::json!({
        "meta_refresh": lower.contains("http-equiv=\"refresh\""),
        "initial_login_failed": lower.contains("initialvalue") && lower.contains("login failed"),
        "login_failed_token": lower.contains("loginfailed") || lower.contains("login_failed"),
        "has_setclient": lower.contains("/cgi/setclient"),
        "has_launch": lower.contains("launch/applications"),
        "visibility_page": lower.contains("visibility:hidden") || lower.contains("visibility: hidden"),
        "has_passwd_field": lower.contains("name=\"passwd\"") || lower.contains("name='passwd'"),
    })
}

fn citrix_post_explicit_failure(signals: &serde_json::Value) -> bool {
    signals
        .get("initial_login_failed")
        .and_then(|v| v.as_bool())
        .unwrap_or(false)
        || signals
            .get("login_failed_token")
            .and_then(|v| v.as_bool())
            .unwrap_or(false)
}

/// NSC cookie + POST shape heuristics for common NetScaler / Receiver gateways.
/// UPC wrong-pass band (~6500–7000) is intentionally excluded.
const CITRIX_FULL_PORTAL_POST_MIN: usize = 35_000;
const CITRIX_MID_POST_MIN: usize = 7000;

fn citrix_gateway_login_accept(
    post_body: &str,
    post_headers: &reqwest::header::HeaderMap,
    post_signals: &serde_json::Value,
    _portal_body: &str,
    portal_login_form: bool,
) -> Option<&'static str> {
    if citrix_login_post_failed(post_body) || citrix_post_explicit_failure(post_signals) {
        return None;
    }
    if portal_login_form || !response_has_nsc_cookie(post_headers) {
        return None;
    }
    let len = post_body.len();
    let visibility = post_signals
        .get("visibility_page")
        .and_then(|v| v.as_bool())
        .unwrap_or(false);

    if len >= CITRIX_FULL_PORTAL_POST_MIN && citrix_gateway_page(post_body) {
        return Some("nsc_full_portal_post");
    }
    if visibility && len >= CITRIX_MID_POST_MIN && len < CITRIX_FULL_PORTAL_POST_MIN {
        return Some("nsc_visibility_midpost");
    }
    if visibility && (1500..6500).contains(&len) {
        return Some("nsc_visibility_shortpost");
    }
    // Receiver / LMIG-style POST (full HTML, not always visibility:hidden).
    if len >= CITRIX_MID_POST_MIN
        && len < CITRIX_FULL_PORTAL_POST_MIN
        && post_body.to_ascii_lowercase().contains("receiver.appcache")
    {
        return Some("nsc_receiver_midpost");
    }
    None
}

fn citrix_login_post_succeeded(body: &str, _headers: &reqwest::header::HeaderMap) -> bool {
    if citrix_login_post_failed(body) || citrix_post_explicit_failure(&citrix_post_login_signals(body)) {
        return false;
    }
    let signals = citrix_post_login_signals(body);
    if signals
        .get("meta_refresh")
        .and_then(|v| v.as_bool())
        .unwrap_or(false)
    {
        return true;
    }
    if signals.get("has_launch").and_then(|v| v.as_bool()).unwrap_or(false) {
        return true;
    }
    let lower = body.to_ascii_lowercase();
    if lower.contains("window.location") && (lower.contains("/vpn/") || lower.contains("citrix/")) {
        return true;
    }
    false
}

fn citrix_login_post_failed(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    lower.contains("login failed")
        || lower.contains("logon failure")
        || lower.contains("authentication failed")
        || lower.contains("invalid credentials")
        || lower.contains("incorrect user")
        || lower.contains("incorrect password")
        || lower.contains("bad password")
        || lower.contains("failed login")
        || (lower.contains("errormessage") && lower.contains("login failed"))
}

fn citrix_saml_sso_page(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    lower.contains("samlrequest") || lower.contains("saml2/post/sso")
}

fn citrix_gateway_page(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    lower.contains("netscaler")
        || lower.contains("citrix")
        || lower.contains("cvpn")
        || lower.contains("wfica")
        || lower.contains("nsg_x")
        || (lower.contains("passwd") && lower.contains("vpn"))
}

fn citrix_authenticated_portal(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    let login_form = lower.contains("name=\"passwd\"")
        || lower.contains("name='passwd'")
        || lower.contains("id=\"passwd\"")
        || lower.contains("please log on")
        || lower.contains("please enter your user name");
    if login_form {
        return false;
    }
    lower.contains("launch/applications")
        || lower.contains("/logoff")
        || lower.contains("home.do")
        || lower.contains("receiver.splash")
}

#[allow(dead_code)]
fn citrix_session_portal(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    let has_marker = lower.contains("netscaler")
        || lower.contains("citrix workspace")
        || lower.contains("citrix receiver")
        || lower.contains("cvpn")
        || lower.contains("wfica")
        || lower.contains("/cgi/setclient")
        || lower.contains("storefront")
        || lower.contains("nsc_aaac")
        || lower.contains("launch/applications");
    let still_login = lower.contains("name=\"passwd\"")
        || lower.contains("name='passwd'")
        || lower.contains("please log on")
        || lower.contains("log on</title>")
        || lower.contains("authentication failed")
        || lower.contains("login failed")
        || lower.contains("page cannot be displayed")
        || lower.contains("404 not found");
    has_marker && !still_login
}

#[allow(dead_code)]
fn login_response_ok(status: StatusCode, body: &str) -> bool {
    if status.is_redirection() {
        return true;
    }
    let lower = body.to_ascii_lowercase();
    if lower.contains("login failed")
        || lower.contains("authentication failed")
        || lower.contains("invalid credentials")
        || lower.contains("access denied")
    {
        return false;
    }
    status.is_success() && !lower.contains("please enter your credentials")
}

pub async fn download_citrix_account(
    cred: &Credential,
    config: &CitrixClientConfig,
    _output_dir: &std::path::Path,
    download_files: bool,
) -> Result<(CitrixAccountStats, Vec<std::path::PathBuf>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_citrix_account_once(attempt, config, _output_dir, download_files)
    })
    .await
}

async fn download_citrix_account_once(
    cred: Credential,
    config: &CitrixClientConfig,
    _output_dir: &std::path::Path,
    download_files: bool,
) -> Result<(CitrixAccountStats, Vec<std::path::PathBuf>)> {
    let client = CitrixClient::new(cred.url.clone(), &cred.username, &cred.password, config)?;
    if !client.detect().await? {
        bail!(
            "{} is not a Citrix NetScaler/Gateway VPN portal",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let username = client
        .authenticate()
        .await
        .with_context(|| format!("Citrix login failed for {}", cred.display_line()))?;
    let portal_path = cred.url.path().to_string();
    let auth_method = "vpn".to_string();

    if !download_files {
        return Ok((
            CitrixAccountStats {
                username,
                auth_method,
                portal_path,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    Ok((
        CitrixAccountStats {
            username,
            auth_method,
            portal_path,
            downloaded: 0,
            bytes: 0,
        },
        Vec::new(),
    ))
}
