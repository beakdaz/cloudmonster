//! XWiki REST client: detect, authenticate, list spaces/pages, export JSON and attachments.

use anyhow::{bail, Context, Result};
use pma_core::{is_excluded_media_filename, output_file_path, Credential};
use reqwest::{Client, Response, StatusCode, Url};
use serde::Deserialize;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

static XWIKI_SPACE_NAME_RE: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| {
    regex::Regex::new(r#"(?i)(?:<space[^>]*\sname=["']([^"']+)["']|"name"\s*:\s*"([^"]+)")"#).unwrap()
});

#[derive(Clone, Copy)]
enum RestAuth {
    None,
    Basic,
    Cookie,
    BasicAndCookie,
}

const MAX_SPACES: usize = 50;
const MAX_PAGES_PER_SPACE: usize = 100;
const MAX_ATTACHMENTS_PER_PAGE: usize = 40;
const MAX_ATTACHMENT_FILE_BYTES: u64 = 100 * 1024 * 1024;
const MAX_ATTACHMENTS_TOTAL_BYTES: u64 = 1024 * 1024 * 1024;
const WIKI_ID: &str = "xwiki";

#[derive(Debug, Clone)]
pub struct XWikiClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for XWikiClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct XWikiSpace {
    pub name: String,
}

#[derive(Debug, Clone)]
pub struct XWikiPage {
    pub space: String,
    pub name: String,
}

#[derive(Debug, Clone)]
pub struct XWikiAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub authenticated: bool,
    pub spaces: usize,
    pub pages_exported: usize,
    pub attachments: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl XWikiAccountStats {
    pub fn detail_line(&self) -> String {
        let check_metric = self
            .pages_exported
            .max(self.spaces)
            .max(self.attachments);
        let files = crate::stats_display::file_count(self.downloaded, check_metric);
        format!(
            "user={} admin={} spaces={} pages={} attachments={} files={files} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.spaces,
            self.pages_exported,
            self.attachments,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

struct XWikiClient {
    http: Client,
    site_base: Url,
    rest_base: Url,
    wiki_id: String,
    username: String,
    password: String,
}

impl XWikiClient {
    fn new(cred: &Credential, config: &XWikiClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-xwiki/0.1");

        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }

        Ok(Self {
            http: builder.build().context("failed to build HTTP client")?,
            site_base: cred.url.clone(),
            rest_base: cred.url.clone(),
            wiki_id: WIKI_ID.to_string(),
            username: cred.username.clone(),
            password: cred.password.clone(),
        })
    }

    fn rest_url(&self, path: &str) -> Result<Url> {
        let path = path.trim_start_matches('/');
        self.rest_base
            .join(path)
            .context("failed to build XWiki REST url")
    }

    fn apply_auth(&self, builder: reqwest::RequestBuilder, mode: RestAuth) -> reqwest::RequestBuilder {
        let builder = builder.header(reqwest::header::ACCEPT, "application/json");
        match mode {
            RestAuth::None => builder,
            RestAuth::Basic => builder.basic_auth(&self.username, Some(self.password.as_str())),
            RestAuth::Cookie => builder,
            RestAuth::BasicAndCookie => {
                builder.basic_auth(&self.username, Some(self.password.as_str()))
            }
        }
    }

    async fn rest_get(&self, path: &str, mode: RestAuth) -> Result<Response> {
        let url = self.rest_url(path)?;
        self.apply_auth(self.http.get(url), mode).send().await.map_err(Into::into)
    }

    pub async fn detect(&mut self) -> Result<bool> {
        let mut last_transport: Option<anyhow::Error> = None;
        for (site, rest) in candidate_xwiki_rest_roots(&self.site_base) {
            if let Ok(html_hit) = self.probe_html_xwiki(&site).await {
                if html_hit {
                    self.site_base = site.clone();
                }
            }
            match self.probe_rest_root(&site, &rest).await {
                Ok(Some(wiki_id)) => {
                    self.site_base = site;
                    self.rest_base = rest;
                    self.wiki_id = wiki_id;
                    return Ok(true);
                }
                Ok(None) => {}
                Err(err) => last_transport = Some(err),
            }
        }
        if let Some(err) = last_transport {
            return Err(err).with_context(|| {
                format!(
                    "cannot reach XWiki at {} (check network; enable Allow invalid TLS for bad certificates)",
                    self.site_base
                )
            });
        }
        Ok(false)
    }

    async fn probe_html_xwiki(&self, site: &Url) -> Result<bool> {
        for path in ["xwiki/bin/view/Main/", "bin/view/Main/", "xwiki/"] {
            let url = site.join(path).context("view url")?;
            let resp = match self.http.get(url).send().await {
                Ok(r) => r,
                Err(_) => continue,
            };
            let body = resp.text().await.unwrap_or_default();
            let lower = body.to_ascii_lowercase();
            if lower.contains("data-xwiki-reference")
                || lower.contains("xwikienterprise")
                || lower.contains("href=\"/xwiki/bin/")
                || lower.contains("xwiki.webapp")
            {
                return Ok(true);
            }
        }
        Ok(false)
    }

    async fn probe_rest_root(&self, site: &Url, rest: &Url) -> Result<Option<String>> {
        let wiki_id = self.discover_wiki_id(rest).await?;
        let wiki_id = wiki_id.unwrap_or_else(|| WIKI_ID.to_string());
        let path = format!("wikis/{wiki_id}/spaces");
        for mode in [RestAuth::None, RestAuth::Basic] {
            let resp = self.rest_get_at(rest, &path, mode).await?;
            let status = resp.status();
            let body = resp.text().await?;
            if looks_like_xwiki_rest_payload(&body, status) {
                let _ = site;
                return Ok(Some(wiki_id));
            }
        }
        Ok(None)
    }

    async fn discover_wiki_id(&self, rest: &Url) -> Result<Option<String>> {
        let url = rest.join("wikis").context("wikis root")?;
        let resp = self
            .http
            .get(url)
            .header(reqwest::header::ACCEPT, "application/json")
            .send()
            .await?;
        if !resp.status().is_success() {
            return Ok(None);
        }
        let body = resp.text().await?;
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(&body) {
            if let Some(arr) = v.as_array() {
                if let Some(id) = arr
                    .first()
                    .and_then(|w| w.get("id"))
                    .and_then(|x| x.as_str())
                {
                    return Ok(Some(id.to_string()));
                }
            }
            if let Some(id) = v.get("id").and_then(|x| x.as_str()) {
                return Ok(Some(id.to_string()));
            }
        }
        Ok(None)
    }

    async fn rest_get_at(&self, rest: &Url, path: &str, mode: RestAuth) -> Result<Response> {
        let url = rest
            .join(path.trim_start_matches('/'))
            .context("rest path")?;
        self.apply_auth(self.http.get(url), mode)
            .send()
            .await
            .map_err(Into::into)
    }

    async fn establish_web_session(&self) -> Result<()> {
        for login_path in ["xwiki/bin/login/XWiki/XWiki", "bin/login/XWiki/XWiki"] {
            let login_page = self.site_base.join(login_path).context("login page")?;
            let page = self.http.get(login_page.clone()).send().await?;
            let html = page.text().await.unwrap_or_default();
            let token = extract_form_field(&html, "form_token")
                .or_else(|| extract_form_field(&html, "xsrfToken"));
            for submit_path in [
                "xwiki/bin/loginsubmit/XWiki/XWiki",
                "bin/loginsubmit/XWiki/XWiki",
            ] {
                let submit_url = self.site_base.join(submit_path).context("loginsubmit")?;
                let mut form: Vec<(&str, &str)> = vec![
                    ("j_username", &self.username),
                    ("j_password", &self.password),
                    ("j_logintext", &self.username),
                    ("rememberme", "1"),
                    ("xredirect", "/"),
                ];
                if let Some(ref t) = token {
                    form.push(("form_token", t));
                }
                let resp = self.http.post(submit_url).form(&form).send().await?;
                if resp.status().is_success() || resp.status().is_redirection() {
                    debug!("XWiki form login for {}", self.username);
                    return Ok(());
                }
            }
        }
        Ok(())
    }

    async fn verify_authenticated(&self) -> Result<bool> {
        let path = format!("wikis/{}/spaces", self.wiki_id);
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.rest_get(&path, mode).await?;
            if resp.status().is_success() {
                let body = resp.text().await?;
                if !parse_spaces_body(&body).is_empty() || body.contains("space") {
                    return Ok(true);
                }
            }
        }
        Ok(false)
    }

    pub async fn authenticate(&mut self) -> Result<(String, bool)> {
        if !self.verify_authenticated().await? {
            self.establish_web_session().await?;
            if !self.verify_authenticated().await? {
                bail!(
                    "XWiki authentication failed for {} (check username/password; REST may require web login)",
                    self.username
                );
            }
        }
        let is_admin = self.check_admin().await.unwrap_or(false);
        Ok((self.username.clone(), is_admin))
    }

    async fn check_admin(&self) -> Result<bool> {
        let user = rest_path_segment(&self.username);
        let path = format!("wikis/{}/users/{user}/groups", self.wiki_id);
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.rest_get(&path, mode).await?;
            if !resp.status().is_success() {
                continue;
            }
            let body = resp.text().await?;
            let lower = body.to_ascii_lowercase();
            if lower.contains("xwiki.admin") || lower.contains("administrator") {
                return Ok(true);
            }
        }
        Ok(false)
    }

    pub async fn list_spaces(&self) -> Result<Vec<XWikiSpace>> {
        let path = format!("wikis/{}/spaces", self.wiki_id);
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.rest_get(&path, mode).await?;
            if !resp.status().is_success() {
                continue;
            }
            let body = resp.text().await?;
            let mut spaces = parse_spaces_body(&body);
            if spaces.is_empty() {
                spaces.push(XWikiSpace {
                    name: "Main".into(),
                });
            }
            return Ok(spaces.into_iter().take(MAX_SPACES).collect());
        }
        bail!("XWiki list spaces failed (not authenticated for REST?)");
    }

    pub async fn list_pages(&self, space: &str) -> Result<Vec<XWikiPage>> {
        let encoded = rest_path_segment(space);
        let path = format!("wikis/{}/spaces/{encoded}/pages", self.wiki_id);
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.rest_get(&path, mode).await?;
            if !resp.status().is_success() {
                continue;
            }
            let body = resp.text().await?;
            let pages = parse_pages_json(&body, space);
            if !pages.is_empty() {
                return Ok(pages.into_iter().take(MAX_PAGES_PER_SPACE).collect());
            }
        }
        self.list_pages_search(space).await
    }

    async fn list_pages_search(&self, space: &str) -> Result<Vec<XWikiPage>> {
        let mut url = self.rest_url(&format!("wikis/{}/search", self.wiki_id))?;
        url.query_pairs_mut()
            .append_pair("scope", "wiki")
            .append_pair("type", "page")
            .append_pair("number", &MAX_PAGES_PER_SPACE.to_string())
            .append_pair("q", "**");
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.apply_auth(self.http.get(url.clone()), mode).send().await?;
            if !resp.status().is_success() {
                continue;
            }
            let body = resp.text().await?;
            let pages: Vec<XWikiPage> = parse_pages_json(&body, space)
                .into_iter()
                .filter(|p| p.space.eq_ignore_ascii_case(space) || space == "Main")
                .take(MAX_PAGES_PER_SPACE)
                .collect();
            if !pages.is_empty() {
                return Ok(pages);
            }
        }
        Ok(vec![XWikiPage {
            space: space.to_string(),
            name: "WebHome".into(),
        }])
    }

    pub async fn export_page_json(&self, page: &XWikiPage) -> Result<Vec<u8>> {
        let space = rest_path_segment(&page.space);
        let name = rest_path_segment(&page.name);
        let path = format!(
            "wikis/{}/spaces/{space}/pages/{name}",
            self.wiki_id
        );
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.rest_get(&path, mode).await?;
            if !resp.status().is_success() {
                continue;
            }
            let bytes = resp.bytes().await?;
            if bytes.starts_with(b"<") {
                continue;
            }
            return Ok(bytes.to_vec());
        }
        bail!(
            "XWiki page export failed for {}/{}",
            page.space,
            page.name
        );
    }

    pub async fn download_page_attachments(
        &self,
        page: &XWikiPage,
        output_dir: &Path,
        file_prefix: &str,
        account_attachment_bytes: &mut u64,
    ) -> Result<(usize, u64)> {
        let space = rest_path_segment(&page.space);
        let name = rest_path_segment(&page.name);
        let path = format!(
            "wikis/{}/spaces/{space}/pages/{name}/attachments",
            self.wiki_id
        );
        let body = {
            let mut found = None;
            for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
                let resp = self.rest_get(&path, mode).await?;
                if resp.status().is_success() {
                    found = Some(resp.text().await?);
                    break;
                }
            }
            match found {
                Some(b) => b,
                None => return Ok((0, 0)),
            }
        };
        let names = parse_attachment_names(&body);
        let mut saved = 0usize;
        let mut total_bytes = 0u64;
        let mut budget = MAX_ATTACHMENTS_PER_PAGE;

        for att_name in names {
            if budget == 0 || *account_attachment_bytes >= MAX_ATTACHMENTS_TOTAL_BYTES {
                break;
            }
            if is_excluded_media_filename(&att_name) {
                continue;
            }
            let att_enc = rest_path_segment(&att_name);
            let dl_path = format!(
                "wikis/{}/spaces/{space}/pages/{name}/attachments/{att_enc}",
                self.wiki_id
            );
            let leaf = format!(
                "{}__{}__{}__{}",
                safe_path_component(file_prefix),
                safe_path_component(&page.space),
                safe_path_component(&page.name),
                safe_path_component(&att_name),
            );
            let path = output_file_path(output_dir, &leaf);
            let remaining =
                MAX_ATTACHMENTS_TOTAL_BYTES.saturating_sub(*account_attachment_bytes);
            match self.download_attachment_to(&dl_path, &path, remaining).await {
                Ok(n) => {
                    saved += 1;
                    total_bytes += n;
                    *account_attachment_bytes += n;
                    budget -= 1;
                }
                Err(err) => warn!(
                    "XWiki attachment {} on {}/{}: {err}",
                    att_name, page.space, page.name
                ),
            }
        }
        Ok((saved, total_bytes))
    }

    async fn download_attachment_to(
        &self,
        rest_path: &str,
        output_path: &Path,
        max_bytes: u64,
    ) -> Result<u64> {
        let mut last_status = StatusCode::BAD_REQUEST;
        for mode in [RestAuth::Basic, RestAuth::Cookie, RestAuth::BasicAndCookie] {
            let resp = self.rest_get(rest_path, mode).await?;
            last_status = resp.status();
            if !resp.status().is_success() {
                continue;
            }
            if let Some(len) = resp.content_length() {
                if len > max_bytes || len > MAX_ATTACHMENT_FILE_BYTES {
                    bail!("attachment exceeds size limit");
                }
            }
            let bytes = resp.bytes().await?;
            let n = bytes.len() as u64;
            if n > max_bytes || n > MAX_ATTACHMENT_FILE_BYTES {
                bail!("attachment exceeds size limit");
            }
            if let Some(parent) = output_path.parent() {
                fs::create_dir_all(parent).await?;
            }
            let mut file = fs::File::create(output_path).await?;
            file.write_all(&bytes).await?;
            return Ok(n);
        }
        bail!("attachment HTTP {last_status}");
    }
}

#[derive(Debug, Deserialize)]
struct SpaceNode {
    #[serde(default)]
    name: Option<String>,
}

fn looks_like_xwiki_rest_payload(body: &str, status: StatusCode) -> bool {
    let lower = body.to_ascii_lowercase();
    if lower.contains("xwiki") || lower.contains("spaceSummaries") || lower.contains("\"spaces\"") {
        return status.is_success()
            || status == StatusCode::UNAUTHORIZED
            || status == StatusCode::FORBIDDEN;
    }
    if body.trim_start().starts_with("<spaces") || body.contains("xmlns=\"http://www.xwiki.org") {
        return true;
    }
    false
}

fn parse_spaces_body(body: &str) -> Vec<XWikiSpace> {
    if let Ok(v) = serde_json::from_str::<serde_json::Value>(body) {
        for key in ["spaces", "spaceSummaries"] {
            if let Some(arr) = v.get(key).and_then(|x| x.as_array()) {
                let names: Vec<XWikiSpace> = arr
                    .iter()
                    .filter_map(|item| {
                        item.get("name")
                            .and_then(|x| x.as_str())
                            .map(|n| XWikiSpace {
                                name: n.to_string(),
                            })
                    })
                    .collect();
                if !names.is_empty() {
                    return names;
                }
            }
        }
    }
    let mut out = Vec::new();
    for cap in XWIKI_SPACE_NAME_RE.captures_iter(body) {
        let name = cap
            .get(1)
            .or_else(|| cap.get(2))
            .map(|m| m.as_str().to_string())
            .unwrap_or_default();
        if !name.is_empty() && !out.iter().any(|s: &XWikiSpace| s.name == name) {
            out.push(XWikiSpace { name });
        }
    }
    out
}

fn extract_form_field(html: &str, field: &str) -> Option<String> {
    let pattern = format!(
        r#"(?i)name="{field}"[^>]*value="([^"]*)"|name='{field}'[^>]*value='([^']*)'"#
    );
    let re = regex::Regex::new(&pattern).ok()?;
    re.captures(html).and_then(|c| {
        c.get(1)
            .or_else(|| c.get(2))
            .map(|m| m.as_str().to_string())
    })
}

#[derive(Debug, Deserialize)]
struct SpacesResponse {
    #[serde(default)]
    spaces: Vec<SpaceNode>,
}

fn parse_pages_json(body: &str, space: &str) -> Vec<XWikiPage> {
    if let Ok(v) = serde_json::from_str::<serde_json::Value>(body) {
        for key in ["pageSummaries", "pages", "page"] {
            if let Some(arr) = v.get(key).and_then(|x| x.as_array()) {
                return arr
                    .iter()
                    .filter_map(|item| {
                        let name = item
                            .get("name")
                            .or_else(|| item.get("page"))
                            .and_then(|x| x.as_str())
                            .map(str::to_string)?;
                        Some(XWikiPage {
                            space: space.to_string(),
                            name,
                        })
                    })
                    .collect();
            }
        }
        if let Some(name) = v.get("name").and_then(|x| x.as_str()) {
            return vec![XWikiPage {
                space: space.to_string(),
                name: name.to_string(),
            }];
        }
    }
    vec![XWikiPage {
        space: space.to_string(),
        name: "WebHome".into(),
    }]
}

fn parse_attachment_names(body: &str) -> Vec<String> {
    let mut out = Vec::new();
    if let Ok(v) = serde_json::from_str::<serde_json::Value>(body) {
        for key in ["attachments", "attachment"] {
            if let Some(arr) = v.get(key).and_then(|x| x.as_array()) {
                for item in arr {
                    if let Some(name) = item
                        .get("name")
                        .or_else(|| item.get("filename"))
                        .and_then(|x| x.as_str())
                    {
                        out.push(name.to_string());
                    }
                }
                return out;
            }
        }
    }
    out
}

fn candidate_xwiki_rest_roots(site: &Url) -> Vec<(Url, Url)> {
    let mut out = Vec::new();
    let mut push = |site: Url, rest_path: &str| {
        if let Ok(rest) = site.join(rest_path) {
            if !out.iter().any(|(_, r): &(Url, Url)| r.as_str() == rest.as_str()) {
                out.push((site.clone(), rest));
            }
        }
    };
    for variant in crate::http_client::base_url_variants(site) {
        push(variant.clone(), "rest/");
        push(variant.clone(), "xwiki/rest/");
        if let Ok(xwiki_root) = variant.join("xwiki/") {
            push(xwiki_root, "rest/");
        }
    }
    out
}

async fn parse_json_response<T: serde::de::DeserializeOwned>(
    resp: Response,
    endpoint: &str,
) -> Result<T> {
    let status = resp.status();
    let body = resp.text().await?;
    let trimmed = body.trim_start();
    let looks_html = trimmed.starts_with("<!DOCTYPE")
        || trimmed.starts_with("<html")
        || trimmed.starts_with("<HTML");
    if !status.is_success() {
        bail!(
            "XWiki API error {status} on {endpoint}: {}",
            preview_body(&body)
        );
    }
    if looks_html {
        bail!("XWiki API returned HTML instead of JSON on {endpoint}");
    }
    serde_json::from_str(&body).with_context(|| {
        format!(
            "failed to decode XWiki JSON from {endpoint}: {}",
            preview_body(&body)
        )
    })
}

fn preview_body(body: &str) -> String {
    body.chars().take(200).collect::<String>().replace('\n', " ")
}

fn rest_path_segment(s: &str) -> String {
    s.chars()
        .map(|c| match c {
            'A'..='Z' | 'a'..='z' | '0'..='9' | '-' | '_' | '.' | '~' => c.to_string(),
            _ => format!("%{:02X}", c as u32),
        })
        .collect()
}

pub fn safe_path_component(input: &str) -> String {
    input
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

pub async fn download_xwiki_content(
    cred: &Credential,
    config: &XWikiClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(XWikiAccountStats, Vec<(XWikiPage, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_xwiki_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_xwiki_once(
    cred: Credential,
    config: &XWikiClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(XWikiAccountStats, Vec<(XWikiPage, PathBuf, u64)>)> {
    let mut client = XWikiClient::new(&cred, config)?;
    if !client.detect().await? {
        bail!(
            "{} is not an XWiki server (no REST API under /rest/ or /xwiki/rest/)",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let (session_user, is_admin) = client
        .authenticate()
        .await
        .with_context(|| format!("XWiki login failed for {}", cred.display_line()))?;

    let spaces = client.list_spaces().await?;
    let space_count = spaces.len();

    if !download_files {
        return Ok((
            XWikiAccountStats {
                username: session_user,
                is_admin,
                authenticated: true,
                spaces: space_count,
                pages_exported: 0,
                attachments: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "xwiki");
    let prefix = cred.account_file_prefix();
    let mut written = Vec::new();
    let mut pages_total = 0usize;
    let mut attachment_total = 0usize;
    let mut total_bytes = 0u64;
    let mut attachment_bytes_account = 0u64;

    for space in spaces {
        let pages = match client.list_pages(&space.name).await {
            Ok(p) => p,
            Err(err) => {
                warn!("XWiki pages in space {}: {err}", space.name);
                continue;
            }
        };
        for page in pages {
            match client.export_page_json(&page).await {
                Ok(bytes) => {
                    pages_total += 1;
                    let leaf = format!(
                        "{}__{}__{}.json",
                        prefix,
                        safe_path_component(&page.space),
                        safe_path_component(&page.name),
                    );
                    let path = output_file_path(&site_dir, &leaf);
                    if let Some(parent) = path.parent() {
                        fs::create_dir_all(parent).await?;
                    }
                    fs::write(&path, &bytes).await?;
                    let n = bytes.len() as u64;
                    total_bytes += n;
                    written.push((page.clone(), path, n));

                    match client
                        .download_page_attachments(
                            &page,
                            &site_dir,
                            &prefix,
                            &mut attachment_bytes_account,
                        )
                        .await
                    {
                        Ok((count, att_bytes)) => {
                            attachment_total += count;
                            total_bytes += att_bytes;
                        }
                        Err(err) => warn!(
                            "XWiki attachments {}/{}: {err}",
                            page.space, page.name
                        ),
                    }
                }
                Err(err) => warn!(
                    "XWiki page export {}/{} for {}: {err}",
                    page.space,
                    page.name,
                    cred.display_line()
                ),
            }
        }
    }

    Ok((
        XWikiAccountStats {
            username: session_user,
            is_admin,
            authenticated: true,
            spaces: space_count,
            pages_exported: pages_total,
            attachments: attachment_total,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}
