//! Minimal S3 SigV4 (ListBuckets / ListObjectsV2) for storage endpoints.

use anyhow::{bail, Context, Result};
use hmac::{Hmac, Mac};
use reqwest::{Client, Url};
use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};

type HmacSha256 = Hmac<Sha256>;

pub fn looks_like_s3_access_key(key: &str) -> bool {
    key.len() >= 16
        && key.len() <= 128
        && key
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-' || c == '.')
        && !key.contains('@')
}

pub async fn list_buckets(
    http: &Client,
    base: &Url,
    access_key: &str,
    secret_key: &str,
) -> Result<(Vec<String>, String)> {
    let host = signing_host(base)?;
    let regions = s3_regions_to_try(&host);
    let try_all_regions = regions.len() > 1;
    let mut last_err: Option<anyhow::Error> = None;
    for region in regions {
        match list_buckets_in_region(http, base, access_key, secret_key, &region).await {
            Ok(buckets) => return Ok((buckets, region)),
            Err(err) => {
                let msg = err.to_string().to_ascii_lowercase();
                if msg.contains("invalidaccesskeyid")
                    || msg.contains("signaturedoesnotmatch")
                    || msg.contains("authentication failed")
                {
                    if msg.contains("signaturedoesnotmatch") {
                        last_err = Some(err);
                        continue;
                    }
                    if !try_all_regions {
                        return Err(err);
                    }
                    last_err = Some(err);
                    continue;
                }
                return Err(err);
            }
        }
    }
    Err(last_err.unwrap_or_else(|| anyhow::anyhow!("S3 list buckets failed")))
}

async fn list_buckets_in_region(
    http: &Client,
    base: &Url,
    access_key: &str,
    secret_key: &str,
    region: &str,
) -> Result<Vec<String>> {
    let body =
        signed_get(http, base, access_key, secret_key, "/", "s3", None, region).await?;
    let mut buckets = Vec::new();
    for cap in regex::Regex::new(r"(?i)<Name>([^<]+)</Name>")
        .unwrap()
        .captures_iter(&body)
    {
        buckets.push(cap[1].to_string());
    }
    if buckets.is_empty() && body.contains("ListAllMyBucketsResult") {
        return Ok(buckets);
    }
    if buckets.is_empty() && !body.trim().is_empty() {
        bail!("S3 list buckets: unexpected response");
    }
    Ok(buckets)
}

pub async fn list_object_keys(
    http: &Client,
    base: &Url,
    access_key: &str,
    secret_key: &str,
    bucket: &str,
    max_keys: u32,
    region: &str,
) -> Result<Vec<(String, u64)>> {
    let query = format!("list-type=2&max-keys={max_keys}");
    let path = format!("/{bucket}");
    let body = signed_get(http, base, access_key, secret_key, &path, "s3", Some(&query), region).await?;
    let key_re = regex::Regex::new(r"(?i)<Key>([^<]+)</Key>").unwrap();
    let size_re = regex::Regex::new(r"(?i)<Size>(\d+)</Size>").unwrap();
    let keys: Vec<String> = key_re
        .captures_iter(&body)
        .map(|c| c[1].to_string())
        .collect();
    let sizes: Vec<u64> = size_re
        .captures_iter(&body)
        .filter_map(|c| c[1].parse().ok())
        .collect();
    Ok(keys
        .into_iter()
        .zip(sizes.into_iter().chain(std::iter::repeat(0)))
        .collect())
}

pub async fn get_object(
    http: &Client,
    base: &Url,
    access_key: &str,
    secret_key: &str,
    bucket: &str,
    key: &str,
    region: &str,
) -> Result<Vec<u8>> {
    let path = format!("/{bucket}/{key}");
    let bytes = signed_get_bytes(http, base, access_key, secret_key, &path, "s3", None, region).await?;
    Ok(bytes)
}

async fn signed_get(
    http: &Client,
    base: &Url,
    access_key: &str,
    secret_key: &str,
    path: &str,
    service: &str,
    query: Option<&str>,
    region: &str,
) -> Result<String> {
    let bytes = signed_get_bytes(
        http, base, access_key, secret_key, path, service, query, region,
    )
    .await?;
    String::from_utf8(bytes).context("S3 response not UTF-8")
}

async fn signed_get_bytes(
    http: &Client,
    base: &Url,
    access_key: &str,
    secret_key: &str,
    path: &str,
    service: &str,
    query: Option<&str>,
    region: &str,
) -> Result<Vec<u8>> {
    let host = signing_host(base)?;
    let uri = if let Some(q) = query {
        format!("{path}?{q}")
    } else {
        path.to_string()
    };
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
    let amz_date = format_amz_date(now.as_secs());
    let date_stamp = &amz_date[..8];
    let payload_hash = hex_sha256(b"");
    let canonical_headers = format!("host:{host}\nx-amz-content-sha256:{payload_hash}\nx-amz-date:{amz_date}\n");
    let signed_headers = "host;x-amz-content-sha256;x-amz-date";
    let canonical_request = format!(
        "GET\n{canonical_uri}\n{canonical_query}\n{canonical_headers}\n{signed_headers}\n{payload_hash}",
        canonical_uri = canonical_uri_path(path),
        canonical_query = query.unwrap_or(""),
    );
    let scope = format!("{date_stamp}/{region}/{service}/aws4_request");
    let string_to_sign = format!(
        "AWS4-HMAC-SHA256\n{amz_date}\n{scope}\n{}",
        hex_sha256(canonical_request.as_bytes())
    );
    let signing_key = signing_key(secret_key, date_stamp, &region, service);
    let signature = hex_hmac(signing_key, string_to_sign.as_bytes());
    let auth = format!(
        "AWS4-HMAC-SHA256 Credential={access_key}/{scope}, SignedHeaders={signed_headers}, Signature={signature}"
    );
    let url = format!("{}://{}{}", base.scheme(), host, uri);
    let resp = http
        .get(&url)
        .header("Authorization", auth)
        .header("x-amz-date", amz_date)
        .header("x-amz-content-sha256", payload_hash)
        .send()
        .await?;
    if resp.status().is_success() {
        return Ok(resp.bytes().await?.to_vec());
    }
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    let snippet: String = body.chars().take(200).collect();
    if status.as_u16() == 401 || status.as_u16() == 403 {
        bail!(
            "S3 authentication failed (HTTP {status}) at {path}{}",
            if snippet.is_empty() {
                String::new()
            } else {
                format!(": {snippet}")
            }
        );
    }
    if status.is_redirection() {
        bail!(
            "S3 GET {path} HTTP {status} (try https:// for this host if you used http://)"
        );
    }
    bail!(
        "S3 GET {path} HTTP {status}{}",
        if snippet.is_empty() {
            String::new()
        } else {
            format!(": {snippet}")
        }
    );
}

fn guess_region(host: &str) -> String {
    if host.contains(".amazonaws.com") {
        host.split('.')
            .nth(1)
            .unwrap_or("us-east-1")
            .to_string()
    } else {
        "us-east-1".to_string()
    }
}

fn s3_regions_to_try(host: &str) -> Vec<String> {
    if host.contains(".amazonaws.com") {
        return vec![guess_region(host)];
    }
    vec![
        "us-east-1".to_string(),
        "ap-southeast-1".to_string(),
        "ap-southeast-2".to_string(),
        "eu-west-1".to_string(),
        "eu-central-1".to_string(),
    ]
}

fn signing_host(base: &Url) -> Result<String> {
    let host = base.host_str().context("S3 url host")?;
    match base.port() {
        Some(port) if needs_port_in_host(base.scheme(), port) => Ok(format!("{host}:{port}")),
        _ => Ok(host.to_string()),
    }
}

fn needs_port_in_host(scheme: &str, port: u16) -> bool {
    match scheme {
        "http" => port != 80,
        "https" => port != 443,
        _ => true,
    }
}

fn canonical_uri_path(path: &str) -> String {
    if path.is_empty() || path == "/" {
        return "/".to_string();
    }
    path.split('/')
        .map(|seg| urlencoding(seg))
        .collect::<Vec<_>>()
        .join("/")
}

fn urlencoding(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

fn format_amz_date(epoch: u64) -> String {
    let secs = epoch;
    let days = secs / 86400;
    let rem = secs % 86400;
    let h = rem / 3600;
    let m = (rem % 3600) / 60;
    let s = rem % 60;
    let (y, mo, d) = civil_from_days(days as i64);
    format!("{y:04}{mo:02}{d:02}T{h:02}{m:02}{s:02}Z")
}

fn civil_from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = (if z >= 0 { z } else { z - 146096 }) / 146097;
    let doe = (z - era * 146097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let mo = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = if mo <= 2 { y + 1 } else { y };
    (y, mo as i64, d as i64)
}

fn hex_sha256(data: &[u8]) -> String {
    hex::encode(Sha256::digest(data))
}

fn hex_hmac(key: Vec<u8>, data: &[u8]) -> String {
    let mut mac = HmacSha256::new_from_slice(&key).expect("hmac key");
    mac.update(data);
    hex::encode(mac.finalize().into_bytes())
}

fn signing_key(secret: &str, date_stamp: &str, region: &str, service: &str) -> Vec<u8> {
    let k_date = hmac_raw(format!("AWS4{secret}").as_bytes(), date_stamp.as_bytes());
    let k_region = hmac_raw(&k_date, region.as_bytes());
    let k_service = hmac_raw(&k_region, service.as_bytes());
    hmac_raw(&k_service, b"aws4_request")
}

fn hmac_raw(key: &[u8], data: &[u8]) -> Vec<u8> {
    let mut mac = HmacSha256::new_from_slice(key).expect("hmac key");
    mac.update(data);
    mac.finalize().into_bytes().to_vec()
}
