//! Shared check-only vs export counts for `detail_line()` output.

/// When nothing was downloaded, show an inventory metric instead of `0`.
pub(crate) fn file_count(downloaded: usize, check_metric: usize) -> usize {
    if downloaded > 0 {
        downloaded
    } else {
        check_metric
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn prefers_downloaded_count() {
        assert_eq!(file_count(5, 100), 5);
    }

    #[test]
    fn falls_back_to_inventory_in_check_only() {
        assert_eq!(file_count(0, 42), 42);
    }
}
