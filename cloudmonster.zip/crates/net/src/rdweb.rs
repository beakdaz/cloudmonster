//! Microsoft Remote Desktop Web Access (`/RDWeb/Pages/.../login.aspx`).

use anyhow::{bail, Context, Result};
use crate::http_client::apply_proxy;
use pma_core::{is_rdweb_url, Credential};
use regex::Regex;
use reqwest::{Client, Url};
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::Duration;
use tracing::debug;

#[derive(Debug, Clone)]
pub struct RdWebClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
    pub proxy: Option<String>,
}

impl Default for RdWebClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
            proxy: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct RdWebAccountStats {
    pub username: String,
    pub hostname: String,
    pub login_page: String,
}

impl RdWebAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "RDWeb user={} host={} page={} export_files=1 (0 B)",
            self.username, self.hostname, self.login_page
        )
    }
}

struct RdWebClient {
    http: Client,
    login_url: Url,
    username: String,
    password: String,
}

impl RdWebClient {
    fn new(login_url: Url, username: &str, password: &str, config: &RdWebClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        builder = apply_proxy(builder, config.proxy.as_deref())?;
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            login_url,
            username: username.to_string(),
            password: password.to_string(),
        })
    }

    async fn authenticate(&self) -> Result<()> {
        let page = self
            .http
            .get(self.login_url.clone())
            .send()
            .await
            .context("GET login.aspx")?;
        if !page.status().is_success() && !page.status().is_redirection() {
            bail!("login page HTTP {}", page.status());
        }
        let html = page.text().await.unwrap_or_default();
        if !page_looks_like_rdweb(&html) {
            bail!("not an RD Web login page");
        }

        let mut form: Vec<(String, String)> = extract_hidden_inputs(&html);
        set_field(&mut form, "DomainUserName", &self.username);
        set_field(&mut form, "UserPass", &self.password);
        set_field(&mut form, "Password", &self.password);
        set_field(&mut form, "WorkSpaceID", "");
        set_field(&mut form, "RedirectorTimeZone", "000");

        let post_refs: Vec<(&str, &str)> = form
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();

        let resp = self
            .http
            .post(self.login_url.clone())
            .form(&post_refs)
            .send()
            .await
            .context("POST login.aspx")?;
        let status = resp.status();
        let landed = resp.url().clone();
        let body = resp.text().await.unwrap_or_default();

        if rdweb_login_failed(&landed, &body) {
            bail!("RD Web rejected credentials");
        }
        if rdweb_login_ok(&landed, &body) {
            return Ok(());
        }
        if status.is_success() || status.is_redirection() {
            if self.verify_session().await? {
                return Ok(());
            }
        }
        debug!(
            url = %landed,
            snippet = %body.chars().take(120).collect::<String>(),
            "RD Web ambiguous response"
        );
        bail!("RD Web login inconclusive (no session)");
    }

    async fn verify_session(&self) -> Result<bool> {
        let base = rdweb_portal_base(&self.login_url)?;
        let probes = [
            "Default.aspx",
            "Feed/webfeed.aspx",
            "Pages/en-US/Default.aspx",
        ];
        for probe in probes {
            let url = base.join(probe).context("probe url")?;
            let resp = match self.http.get(url).send().await {
                Ok(r) => r,
                Err(_) => continue,
            };
            if !resp.status().is_success() && !resp.status().is_redirection() {
                continue;
            }
            let landed = resp.url().clone();
            let body = resp.text().await.unwrap_or_default();
            if rdweb_login_failed(&landed, &body) {
                return Ok(false);
            }
            if rdweb_login_ok(&landed, &body) {
                return Ok(true);
            }
        }
        Ok(false)
    }
}

fn set_field(form: &mut Vec<(String, String)>, name: &str, value: &str) {
    if let Some(slot) = form
        .iter_mut()
        .find(|(k, _)| k.eq_ignore_ascii_case(name))
    {
        slot.1 = value.to_string();
    } else {
        form.push((name.to_string(), value.to_string()));
    }
}

fn page_looks_like_rdweb(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("rdweb")
        && (lower.contains("domainusername")
            || lower.contains("userpass")
            || lower.contains("login.aspx"))
}

fn rdweb_login_failed(url: &Url, body: &str) -> bool {
    let path = url.path().to_ascii_lowercase();
    let lower = body.to_ascii_lowercase();
    path.contains("login.aspx") && path.contains("/rdweb/")
        && (lower.contains("incorrect")
            || lower.contains("invalid")
            || lower.contains("failed")
            || lower.contains("error")
            || lower.contains("unauthorized")
            || lower.contains("denied")
            || lower.contains("password")
            && lower.contains("try again"))
        || lower.contains("loginfailed")
        || lower.contains("access is denied")
}

fn rdweb_login_ok(url: &Url, body: &str) -> bool {
    if rdweb_login_failed(url, body) {
        return false;
    }
    let path = url.path().to_ascii_lowercase();
    let lower = body.to_ascii_lowercase();
    if path.contains("/rdweb/") && !path.contains("login.aspx") {
        return true;
    }
    lower.contains("webfeed.aspx")
        || lower.contains("default.aspx")
        || lower.contains("rdwebfeed")
        || lower.contains("workspacename")
        || lower.contains("remote desktop")
}

pub fn rdweb_login_url(cred_url: &Url) -> Result<Url> {
    if is_rdweb_url(cred_url) {
        let path = cred_url.path().to_ascii_lowercase();
        if path.contains("login.aspx") {
            return Ok(cred_url.clone());
        }
        let base = rdweb_portal_base(cred_url)?;
        for locale in ["en-US", "es-ES", "zh-TW", "mk-MK", "it-IT", "de-DE", "fr-FR"] {
            let candidate = base
                .join(&format!("Pages/{locale}/login.aspx"))
                .context("login url")?;
            return Ok(candidate);
        }
    }
    bail!("URL is not RD Web")
}

fn rdweb_portal_base(url: &Url) -> Result<Url> {
    let path = url.path();
    let lower = path.to_ascii_lowercase();
    let idx = lower
        .find("/rdweb/")
        .context("missing /RDWeb/ in path")?;
    let prefix = &path[..idx + "/RDWeb/".len()];
    let mut base = url.clone();
    base.set_path(prefix);
    base.set_query(None);
    base.set_fragment(None);
    Ok(base)
}

static HIDDEN_INPUT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)<input[^>]+type=["']hidden["'][^>]*>"#).unwrap()
});
static INPUT_NAME_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)name=["']([^"']+)["']"#).unwrap()
});
static INPUT_VALUE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)value=["']([^"']*)["']"#).unwrap()
});

fn extract_hidden_inputs(html: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    for cap in HIDDEN_INPUT_RE.captures_iter(html) {
        let tag = cap.get(0).map(|m| m.as_str()).unwrap_or("");
        let name = INPUT_NAME_RE
            .captures(tag)
            .and_then(|c| c.get(1))
            .map(|m| m.as_str().to_string());
        let Some(name) = name else { continue };
        let value = INPUT_VALUE_RE
            .captures(tag)
            .and_then(|c| c.get(1))
            .map(|m| m.as_str().to_string())
            .unwrap_or_default();
        out.push((name, value));
    }
    out
}

pub async fn download_rdweb_account(
    cred: &Credential,
    config: &RdWebClientConfig,
    _output_dir: &Path,
    download_files: bool,
) -> Result<(RdWebAccountStats, Vec<PathBuf>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_rdweb_once(attempt, config, download_files)
    })
    .await
}

async fn download_rdweb_once(
    cred: Credential,
    config: &RdWebClientConfig,
    download_files: bool,
) -> Result<(RdWebAccountStats, Vec<PathBuf>)> {
    let login_url = rdweb_login_url(&cred.url)?;
    let client = RdWebClient::new(login_url.clone(), &cred.username, &cred.password, config)?;
    client.authenticate().await.with_context(|| {
        format!(
            "RD Web login failed for {}",
            cred.display_line()
        )
    })?;

    let stats = RdWebAccountStats {
        username: cred.username.clone(),
        hostname: cred.url.host_str().unwrap_or("-").to_string(),
        login_page: login_url.path().to_string(),
    };
    if download_files {
        // Check-only AdminPanel path; no feed export yet.
    }
    Ok((stats, Vec::new()))
}

#[cfg(test)]
mod tests {
    use super::*;
    use url::Url;

    #[test]
    fn login_url_keeps_full_login_aspx() {
        let u = Url::parse("https://host/RDWeb/Pages/en-US/login.aspx").unwrap();
        let l = rdweb_login_url(&u).unwrap();
        assert!(l.path().contains("login.aspx"));
    }
}
