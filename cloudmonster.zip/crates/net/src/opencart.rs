//! OpenCart admin session login + store info HTML export.

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, Credential};
use reqwest::{Client, Url};
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;

#[derive(Debug, Clone)]
pub struct OpencartClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for OpencartClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct OpencartAccountStats {
    pub username: String,
    pub store_name: String,
    pub downloaded: usize,
    pub bytes: u64,
}

impl OpencartAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "user={} store={} files={} ({})",
            self.username,
            self.store_name,
            self.downloaded,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

async fn admin_login(
    http: &Client,
    admin_base: &Url,
    username: &str,
    password: &str,
) -> Result<()> {
    let login_routes = [
        "index.php?route=common/login",
        "index.php?route=common/login/login",
    ];
    for route in login_routes {
        let Ok(login_url) = admin_base.join(route) else {
            continue;
        };
        let page = http.get(login_url.clone()).send().await?;
        if !page.status().is_success() {
            continue;
        }
        let form = [
            ("username", username),
            ("password", password),
            ("redirect", ""),
        ];
        let resp = http.post(login_url).form(&form).send().await?;
        if !resp.status().is_success() && !resp.status().is_redirection() {
            continue;
        }
        let dash = admin_base.join("index.php?route=common/dashboard")?;
        let check = http.get(dash).send().await?;
        let ok_status = check.status().is_success();
        let body = check.text().await.unwrap_or_default();
        let lower = body.to_ascii_lowercase();
        if ok_status
            && !lower.contains("route=common/login")
            && (lower.contains("dashboard") || lower.contains("logout"))
        {
            return Ok(());
        }
    }
    bail!("OpenCart admin login failed");
}

fn extract_title(html: &str) -> String {
    if let Some(start) = html.find("<title>") {
        let rest = &html[start + 7..];
        if let Some(end) = rest.find("</title>") {
            return rest[..end].trim().to_string();
        }
    }
    "OpenCart".into()
}

pub async fn download_opencart_account(
    cred: &Credential,
    config: &OpencartClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(OpencartAccountStats, Vec<(PathBuf, u64)>)> {
    let mut builder = Client::builder()
        .cookie_store(true)
        .redirect(reqwest::redirect::Policy::limited(10))
        .timeout(config.timeout)
        .user_agent("phpmyadmin-rs-opencart/0.1");
    if config.insecure {
        builder = builder.danger_accept_invalid_certs(true);
    }
    let http = builder.build().context("HTTP client")?;
    let admin_base = cred.url.clone();

    admin_login(&http, &admin_base, &cred.username, &cred.password)
        .await
        .with_context(|| format!("OpenCart login failed for {}", cred.display_line()))?;

    let dash = admin_base.join("index.php?route=common/dashboard")?;
    let dash_resp = http.get(dash).send().await?;
    let dash_html = dash_resp.text().await.unwrap_or_default();
    let store_name = extract_title(&dash_html);

    if !download_files {
        return Ok((
            OpencartAccountStats {
                username: cred.username.clone(),
                store_name,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "opencart");
    let prefix = cred.account_file_prefix();
    let html = format!(
        r#"<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>OpenCart store</title></head>
<body>
<h1>OpenCart admin export</h1>
<p>Admin URL: {url}</p>
<p>User: {user}</p>
<p>Store / title: {store}</p>
</body></html>"#,
        url = html_escape(admin_base.as_str()),
        user = html_escape(&cred.username),
        store = html_escape(&store_name),
    );
    let leaf = format!("{prefix}__store.html");
    let path = output_file_path(&site_dir, &leaf);
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(&path, &html).await?;
    let bytes = html.len() as u64;
    Ok((
        OpencartAccountStats {
            username: cred.username.clone(),
            store_name,
            downloaded: 1,
            bytes,
        },
        vec![(path, bytes)],
    ))
}
