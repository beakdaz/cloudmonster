//! Redmine REST: detect, authenticate, list projects, export issues HTML + attachments.

use anyhow::{bail, Context, Result};
use pma_core::{is_excluded_media_filename, output_file_path, output_relative_href, Credential};
use regex::Regex;
use reqwest::{Client, Url};
use serde::Deserialize;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

static AUTH_TOKEN_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)name=["']authenticity_token["'][^>]*value=["']([^"']+)["']"#).unwrap()
});
static AUTH_TOKEN_RE2: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)value=["']([^"']+)["'][^>]*name=["']authenticity_token["']"#).unwrap()
});

const MAX_PROJECTS: usize = 100;
const MAX_ISSUES_PER_PROJECT: u32 = 500;
const MAX_WIKI_PAGES_PER_PROJECT: usize = 200;
const MAX_ATTACHMENTS_PER_PROJECT: usize = 400;
const MAX_ATTACHMENT_FILE_BYTES: u64 = 100 * 1024 * 1024;
const MAX_ATTACHMENTS_TOTAL_BYTES: u64 = 1024 * 1024 * 1024;
const PAGE_SIZE: u32 = 100;

#[derive(Debug, Clone)]
pub struct RedmineClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

/// What to download when export is enabled (GUI checkboxes).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RedmineExportOptions {
    /// Issue list HTML (`*__issues.html`).
    pub issues: bool,
    /// Issue + project file attachments on disk.
    pub attachments: bool,
    /// Wiki pages (`*__wiki__*.html`, wiki index).
    pub wiki: bool,
}

impl RedmineExportOptions {
    pub fn all_enabled() -> Self {
        Self {
            issues: true,
            attachments: true,
            wiki: true,
        }
    }

    pub fn any_selected(self) -> bool {
        self.issues || self.attachments || self.wiki
    }
}

impl Default for RedmineExportOptions {
    fn default() -> Self {
        Self::all_enabled()
    }
}

impl Default for RedmineClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct RedmineProject {
    pub id: u64,
    pub identifier: String,
    pub name: String,
}

#[derive(Debug, Clone)]
pub struct RedmineAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub projects: usize,
    pub issues_exported: usize,
    pub notes_exported: usize,
    pub wiki_pages: usize,
    pub attachments: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl RedmineAccountStats {
    pub fn detail_line(&self) -> String {
        let check_metric = self
            .projects
            .max(self.issues_exported)
            .max(self.wiki_pages)
            .max(self.attachments);
        let files = crate::stats_display::file_count(self.downloaded, check_metric);
        format!(
            "user={} admin={} projects={} issues={} notes={} wiki={} attachments={} files={files} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.projects,
            self.issues_exported,
            self.notes_exported,
            self.wiki_pages,
            self.attachments,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

#[derive(Debug, Deserialize)]
struct RedmineUser {
    #[serde(default)]
    login: Option<String>,
    #[serde(default, rename = "firstname")]
    first_name: Option<String>,
    #[serde(default, rename = "lastname")]
    last_name: Option<String>,
    #[serde(default)]
    admin: Option<bool>,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum RedmineAuth {
    Session,
    Basic,
    ApiKey,
}

struct RedmineClient {
    http: Client,
    base: Url,
    username: String,
    password: String,
    auth: RedmineAuth,
}

impl RedmineClient {
    fn new(base: Url, username: &str, password: &str, config: &RedmineClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-redmine/0.1");
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            base,
            username: username.to_string(),
            password: password.to_string(),
            auth: RedmineAuth::Basic,
        })
    }

    fn join_api(&self, path: &str) -> Result<Url> {
        self.base
            .join(path.trim_start_matches('/'))
            .context("redmine url join")
    }

    fn authed(&self, builder: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        match self.auth {
            RedmineAuth::Session => builder,
            RedmineAuth::ApiKey => builder.header("X-Redmine-API-Key", self.password.as_str()),
            RedmineAuth::Basic => {
                builder.basic_auth(&self.username, Some(self.password.as_str()))
            }
        }
    }

    async fn apply_http_to_https_redirect(&mut self) -> Result<()> {
        if self.base.scheme() != "http" {
            return Ok(());
        }
        let probe = self.join_api("users/current.json")?;
        let probe_client = Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .timeout(Duration::from_secs(30))
            .build()?;
        let resp = probe_client.get(probe.clone()).send().await?;
        if !resp.status().is_redirection() {
            return Ok(());
        }
        let Some(loc) = resp.headers().get(reqwest::header::LOCATION) else {
            return Ok(());
        };
        let loc_str = loc.to_str().unwrap_or_default();
        let target = match Url::parse(loc_str) {
            Ok(u) => u,
            Err(_) => match self.base.join(loc_str) {
                Ok(u) => u,
                Err(_) => return Ok(()),
            },
        };
        if target.scheme() == "https" && target.host() == self.base.host() {
            self.base
                .set_scheme("https")
                .map_err(|_| anyhow::anyhow!("https scheme"))?;
            tracing::info!("Redmine base upgraded to {}", self.base);
        }
        Ok(())
    }

    async fn connect(&mut self) -> Result<(String, bool)> {
        let bases = candidate_redmine_bases(&self.base);
        let mut last: Option<anyhow::Error> = None;
        for base in bases {
            self.base = base;
            if let Err(e) = self.apply_http_to_https_redirect().await {
                last = Some(e);
            }
            for mode in [RedmineAuth::Basic, RedmineAuth::ApiKey] {
                self.auth = mode;
                match self.fetch_current_user().await {
                    Ok(u) => return Ok(u),
                    Err(e) => {
                        last = Some(e.context(format!(
                            "{:?} auth at {}",
                            mode,
                            self.base
                        )));
                    }
                }
            }
            self.auth = RedmineAuth::Session;
            match self.session_login().await {
                Ok(()) => match self.fetch_current_user().await {
                    Ok(u) => return Ok(u),
                    Err(e) => last = Some(e.context(format!("session user at {}", self.base))),
                },
                Err(e) => last = Some(e.context(format!("session login at {}", self.base))),
            }
        }
        Err(last.unwrap_or_else(|| {
            anyhow::anyhow!("not a Redmine server or login failed for {}", self.base)
        }))
    }

    async fn fetch_current_user(&self) -> Result<(String, bool)> {
        let url = self.join_api("users/current.json")?;
        let url_str = url.to_string();
        let resp = self
            .authed(self.http.get(url))
            .send()
            .await
            .context("users/current")?;
        if !resp.status().is_success() {
            bail!("HTTP {} for {}", resp.status(), url_str);
        }
        let v: serde_json::Value = resp.json().await.context("current user json")?;
        let user = v.get("user").context("user object")?;
        let parsed: RedmineUser = serde_json::from_value(user.clone()).context("user parse")?;
        let display = parsed
            .login
            .or_else(|| {
                Some(format!(
                    "{} {}",
                    parsed.first_name.unwrap_or_default(),
                    parsed.last_name.unwrap_or_default()
                ))
            })
            .unwrap_or_else(|| self.username.clone());
        let name = display.trim().to_string();
        let is_admin = parsed.admin.unwrap_or(false);
        Ok((
            if name.is_empty() {
                self.username.clone()
            } else {
                name
            },
            is_admin,
        ))
    }

    async fn session_login(&mut self) -> Result<()> {
        for login_path in ["login", "account/login"] {
            let page_url = self.join_api(login_path)?;
            let page = self
                .http
                .get(page_url.clone())
                .send()
                .await
                .context("redmine login page")?;
            if !page.status().is_success() {
                continue;
            }
            let html = page.text().await.unwrap_or_default();
            let Some(token) = extract_authenticity_token(&html) else {
                continue;
            };
            let form = [
                ("utf8", "✓"),
                ("authenticity_token", token.as_str()),
                ("username", self.username.as_str()),
                ("password", self.password.as_str()),
                ("login", "Login"),
            ];
            let resp = self
                .http
                .post(page_url)
                .form(&form)
                .send()
                .await
                .context("redmine login post")?;
            if resp.status().is_success() || resp.status().is_redirection() {
                let probe = self.join_api("users/current.json")?;
                let check = self.http.get(probe).send().await?;
                if check.status().is_success() {
                    self.auth = RedmineAuth::Session;
                    return Ok(());
                }
            }
        }
        bail!("Redmine web login failed");
    }

    async fn list_projects(&self) -> Result<Vec<RedmineProject>> {
        let mut out = Vec::new();
        let mut offset = 0u32;
        loop {
            let url = self.join_api(&format!(
                "projects.json?limit={PAGE_SIZE}&offset={offset}"
            ))?;
            let resp = self.authed(self.http.get(url)).send().await?;
            if !resp.status().is_success() {
                bail!("projects list HTTP {}", resp.status());
            }
            let v: serde_json::Value = resp.json().await?;
            let Some(arr) = v.get("projects").and_then(|p| p.as_array()) else {
                break;
            };
            if arr.is_empty() {
                break;
            }
            for p in arr {
                let id = p.get("id").and_then(|x| x.as_u64()).unwrap_or(0);
                let identifier = p
                    .get("identifier")
                    .and_then(|x| x.as_str())
                    .unwrap_or("")
                    .to_string();
                let name = p
                    .get("name")
                    .and_then(|x| x.as_str())
                    .unwrap_or(&identifier)
                    .to_string();
                if id > 0 {
                    out.push(RedmineProject {
                        id,
                        identifier,
                        name,
                    });
                }
            }
            if out.len() >= MAX_PROJECTS || arr.len() < PAGE_SIZE as usize {
                break;
            }
            offset += PAGE_SIZE;
        }
        Ok(out)
    }

    async fn export_project_issues(
        &self,
        project: &RedmineProject,
        include_journals: bool,
    ) -> Result<(u32, u32, Vec<serde_json::Value>)> {
        let include = if include_journals {
            "attachments,journals"
        } else {
            "attachments"
        };
        let mut all_issues = Vec::new();
        let mut offset = 0u32;
        let mut total = 0u32;
        loop {
            let url = self.join_api(&format!(
                "issues.json?project_id={}&limit={PAGE_SIZE}&offset={offset}&status_id=*&include={include}",
                project.id
            ))?;
            let resp = self.authed(self.http.get(url)).send().await?;
            if !resp.status().is_success() {
                bail!("issues HTTP {} for {}", resp.status(), project.identifier);
            }
            let v: serde_json::Value = resp.json().await?;
            if offset == 0 {
                total = v.get("total_count").and_then(|x| x.as_u64()).unwrap_or(0) as u32;
            }
            let issues = v
                .get("issues")
                .and_then(|x| x.as_array())
                .cloned()
                .unwrap_or_default();
            if issues.is_empty() {
                break;
            }
            all_issues.extend(issues);
            if all_issues.len() as u32 >= MAX_ISSUES_PER_PROJECT.min(total.max(1)) {
                break;
            }
            if (offset + PAGE_SIZE) >= total {
                break;
            }
            offset += PAGE_SIZE;
        }
        let exported = all_issues.len() as u32;
        Ok((exported, total, all_issues))
    }

    /// List wiki page titles for a project (`GET …/wiki/index.json`).
    async fn list_wiki_page_titles(&self, project: &RedmineProject) -> Result<Vec<String>> {
        let url = self.join_api(&format!("projects/{}/wiki/index.json", project.id))?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if resp.status().as_u16() == 404 {
            return Ok(Vec::new());
        }
        if !resp.status().is_success() {
            bail!(
                "wiki index HTTP {} for {}",
                resp.status(),
                project.identifier
            );
        }
        let v: serde_json::Value = resp.json().await?;
        let mut titles = Vec::new();
        if let Some(arr) = v.get("wiki_pages").and_then(|x| x.as_array()) {
            for page in arr {
                if let Some(title) = page.get("title").and_then(|t| t.as_str()) {
                    if !title.is_empty() {
                        titles.push(title.to_string());
                    }
                }
            }
        }
        titles.truncate(MAX_WIKI_PAGES_PER_PROJECT);
        Ok(titles)
    }

    async fn fetch_wiki_page(
        &self,
        project: &RedmineProject,
        title: &str,
    ) -> Result<(String, String)> {
        let encoded = urlencoding_simple(title);
        let url = self.join_api(&format!(
            "projects/{}/wiki/{encoded}.json",
            project.id
        ))?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!(
                "wiki page HTTP {} for {} / {title}",
                resp.status(),
                project.identifier
            );
        }
        let v: serde_json::Value = resp.json().await?;
        let page = v
            .get("wiki_page")
            .cloned()
            .unwrap_or(serde_json::Value::Null);
        let title_out = page
            .get("title")
            .and_then(|t| t.as_str())
            .unwrap_or(title)
            .to_string();
        let text = page
            .get("text")
            .and_then(|t| t.as_str())
            .unwrap_or("")
            .to_string();
        Ok((title_out, text))
    }

    /// Export wiki index + per-page HTML under `html/`.
    async fn export_project_wiki(
        &self,
        project: &RedmineProject,
        site_dir: &Path,
        file_prefix: &str,
        base: &Url,
        session_user: &str,
    ) -> Result<(usize, u64, Vec<(RedmineProject, PathBuf, u64)>)> {
        let titles = match self.list_wiki_page_titles(project).await {
            Ok(t) => t,
            Err(err) => {
                debug!("Redmine wiki index {}: {err}", project.identifier);
                return Ok((0, 0, Vec::new()));
            }
        };
        if titles.is_empty() {
            return Ok((0, 0, Vec::new()));
        }

        let mut pages: Vec<(String, String, String)> = Vec::new();
        for title in &titles {
            match self.fetch_wiki_page(project, title).await {
                Ok((t, text)) => {
                    let leaf = format!(
                        "{file_prefix}__{}__wiki__{}.html",
                        project.identifier,
                        sanitize_wiki_leaf(&t)
                    );
                    pages.push((t, text, leaf));
                }
                Err(err) => debug!(
                    "Redmine wiki page {} / {title}: {err}",
                    project.identifier
                ),
            }
        }
        if pages.is_empty() {
            return Ok((0, 0, Vec::new()));
        }

        let index_leaf = format!("{file_prefix}__{}__wiki_index.html", project.identifier);
        let mut written = Vec::new();
        let mut bytes_total = 0u64;

        let index_html = render_wiki_index_html(base, session_user, project, &pages);
        let index_path = output_file_path(site_dir, &index_leaf);
        let n = write_issues_html(&index_path, &index_html).await?;
        bytes_total += n;
        written.push((project.clone(), index_path, n));

        for (title, text, leaf) in &pages {
            let page_html = render_wiki_page_html(
                base,
                session_user,
                project,
                title,
                text,
                &index_leaf,
            );
            let path = output_file_path(site_dir, leaf);
            match write_issues_html(&path, &page_html).await {
                Ok(n) => {
                    bytes_total += n;
                    written.push((project.clone(), path, n));
                }
                Err(err) => warn!(
                    "Redmine wiki write {} / {title}: {err}",
                    project.identifier
                ),
            }
        }

        Ok((pages.len(), bytes_total, written))
    }

    async fn enrich_issues_attachments(&self, issues: &mut [serde_json::Value]) {
        for issue in issues.iter_mut() {
            if issue_has_attachments_list(issue) {
                continue;
            }
            let Some(id) = issue.get("id").and_then(|x| x.as_u64()) else {
                continue;
            };
            match self.fetch_issue_with_attachments(id).await {
                Ok(detail) => {
                    if let Some(atts) = detail.get("attachments") {
                        issue["attachments"] = atts.clone();
                    }
                }
                Err(err) => debug!("Redmine issue {id} attachment detail: {err}"),
            }
        }
    }

    async fn enrich_issues_journals(&self, issues: &mut [serde_json::Value]) {
        for issue in issues.iter_mut() {
            if issue
                .get("journals")
                .and_then(|j| j.as_array())
                .is_some_and(|a| !a.is_empty())
            {
                continue;
            }
            let Some(id) = issue.get("id").and_then(|x| x.as_u64()) else {
                continue;
            };
            match self.fetch_issue_with_journals(id).await {
                Ok(detail) => {
                    if let Some(journals) = detail.get("journals") {
                        issue["journals"] = journals.clone();
                    }
                }
                Err(err) => debug!("Redmine issue {id} journals: {err}"),
            }
        }
    }

    async fn fetch_issue_with_journals(&self, issue_id: u64) -> Result<serde_json::Value> {
        let url = self.join_api(&format!("issues/{issue_id}.json?include=journals"))?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("issue {issue_id} journals HTTP {}", resp.status());
        }
        let v: serde_json::Value = resp.json().await?;
        Ok(v.get("issue").cloned().unwrap_or(v))
    }

    async fn fetch_issue_with_attachments(&self, issue_id: u64) -> Result<serde_json::Value> {
        let url = self.join_api(&format!("issues/{issue_id}.json?include=attachments"))?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("issue {issue_id} HTTP {}", resp.status());
        }
        let v: serde_json::Value = resp.json().await?;
        Ok(v.get("issue").cloned().unwrap_or(v))
    }

    async fn list_project_files(&self, project: &RedmineProject) -> Result<Vec<serde_json::Value>> {
        let url = self.join_api(&format!("projects/{}/files.json", project.id))?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if resp.status().as_u16() == 404 {
            return Ok(Vec::new());
        }
        if !resp.status().is_success() {
            bail!("project files HTTP {}", resp.status());
        }
        let v: serde_json::Value = resp.json().await?;
        Ok(v.get("files")
            .and_then(|x| x.as_array())
            .cloned()
            .unwrap_or_default())
    }

    async fn download_issue_attachments(
        &self,
        project: &RedmineProject,
        issues: &[serde_json::Value],
        _issues_html_leaf: &str,
        output_dir: &Path,
        file_prefix: &str,
        account_attachment_bytes: &mut u64,
    ) -> Result<(usize, u64)> {
        let mut saved = 0usize;
        let mut total_bytes = 0u64;
        let mut budget = MAX_ATTACHMENTS_PER_PROJECT;

        for issue in issues {
            if budget == 0 || *account_attachment_bytes >= MAX_ATTACHMENTS_TOTAL_BYTES {
                break;
            }
            let issue_id = issue
                .get("id")
                .and_then(|v| v.as_u64())
                .map(|id| id.to_string())
                .unwrap_or_else(|| "issue".into());
            let Some(attachments) = issue.get("attachments").and_then(|a| a.as_array()) else {
                continue;
            };
            let mut used_names = HashSet::new();

            for att in attachments {
                if budget == 0 || *account_attachment_bytes >= MAX_ATTACHMENTS_TOTAL_BYTES {
                    break;
                }
                let Some(filename) = att.get("filename").and_then(|v| v.as_str()) else {
                    continue;
                };
                if is_excluded_media_filename(filename) {
                    continue;
                }
                let size = att.get("filesize").and_then(|v| v.as_u64()).unwrap_or(0);
                if size > MAX_ATTACHMENT_FILE_BYTES {
                    warn!(
                        "skip oversized Redmine attachment {} ({} bytes) on #{}",
                        filename, size, issue_id
                    );
                    continue;
                }
                let remaining_total =
                    MAX_ATTACHMENTS_TOTAL_BYTES.saturating_sub(*account_attachment_bytes);
                if size > remaining_total && size > 0 {
                    warn!(
                        "skip Redmine attachment {} — account attachment cap reached",
                        filename
                    );
                    continue;
                }

                let download_url = redmine_attachment_url(&self.base, att)?;
                let safe_name = unique_filename(filename, &mut used_names);
                let leaf = flat_attachment_name(
                    file_prefix,
                    &project.identifier,
                    &issue_id,
                    &safe_name,
                );
                let path = output_file_path(output_dir, &leaf);

                match self
                    .download_binary_to(&download_url, &path, remaining_total)
                    .await
                {
                    Ok(bytes) => {
                        saved += 1;
                        total_bytes += bytes;
                        *account_attachment_bytes += bytes;
                        budget -= 1;
                    }
                    Err(err) => warn!(
                        "failed Redmine attachment {} on #{}: {err}",
                        filename, issue_id
                    ),
                }
            }
        }

        Ok((saved, total_bytes))
    }

    async fn download_project_files(
        &self,
        project: &RedmineProject,
        output_dir: &Path,
        file_prefix: &str,
        account_attachment_bytes: &mut u64,
    ) -> Result<(usize, u64)> {
        let files = match self.list_project_files(project).await {
            Ok(f) => f,
            Err(err) => {
                debug!("Redmine project files {}: {err}", project.identifier);
                return Ok((0, 0));
            }
        };
        let mut saved = 0usize;
        let mut total_bytes = 0u64;
        let mut used_names = HashSet::new();

        for file in files {
            if *account_attachment_bytes >= MAX_ATTACHMENTS_TOTAL_BYTES {
                break;
            }
            let Some(filename) = file.get("filename").and_then(|v| v.as_str()) else {
                continue;
            };
            if is_excluded_media_filename(filename) {
                continue;
            }
            let size = file.get("filesize").and_then(|v| v.as_u64()).unwrap_or(0);
            if size > MAX_ATTACHMENT_FILE_BYTES {
                continue;
            }
            let remaining_total =
                MAX_ATTACHMENTS_TOTAL_BYTES.saturating_sub(*account_attachment_bytes);
            if size > remaining_total && size > 0 {
                break;
            }
            let download_url = redmine_attachment_url(&self.base, &file)?;
            let safe_name = unique_filename(filename, &mut used_names);
            let leaf = format!(
                "{}__{}__projectfile__{}",
                safe_path_component(file_prefix),
                safe_path_component(&project.identifier),
                safe_name,
            );
            let path = output_file_path(output_dir, &leaf);
            match self
                .download_binary_to(&download_url, &path, remaining_total)
                .await
            {
                Ok(bytes) => {
                    saved += 1;
                    total_bytes += bytes;
                    *account_attachment_bytes += bytes;
                }
                Err(err) => warn!(
                    "failed Redmine project file {} on {}: {err}",
                    filename, project.identifier
                ),
            }
        }

        Ok((saved, total_bytes))
    }

    async fn download_binary_to(
        &self,
        url: &Url,
        output_path: &Path,
        max_bytes: u64,
    ) -> Result<u64> {
        let resp = self.authed(self.http.get(url.clone())).send().await?;
        if !resp.status().is_success() {
            bail!("download HTTP {}", resp.status());
        }
        if let Some(len) = resp.content_length() {
            if len > max_bytes.max(MAX_ATTACHMENT_FILE_BYTES) {
                bail!("download exceeds size limit");
            }
        }
        let bytes = resp.bytes().await?;
        let n = bytes.len() as u64;
        if n > max_bytes.max(MAX_ATTACHMENT_FILE_BYTES) {
            bail!("download exceeds size limit");
        }
        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut file = fs::File::create(output_path).await?;
        file.write_all(&bytes).await?;
        Ok(n)
    }
}

fn issue_has_attachments_list(issue: &serde_json::Value) -> bool {
    issue.get("attachments").map(|a| a.is_array()).unwrap_or(false)
}

fn redmine_attachment_url(base: &Url, att: &serde_json::Value) -> Result<Url> {
    if let Some(content) = att.get("content_url").and_then(|v| v.as_str()) {
        if let Ok(url) = Url::parse(content) {
            return Ok(url);
        }
        return base
            .join(content.trim_start_matches('/'))
            .context("attachment content_url join");
    }
    let id = att
        .get("id")
        .and_then(|v| v.as_u64())
        .context("attachment missing id")?;
    let filename = att
        .get("filename")
        .and_then(|v| v.as_str())
        .unwrap_or("file");
    base.join(&format!("attachments/download/{id}/{}", urlencoding_simple(filename)))
        .context("attachment download url")
}

fn urlencoding_simple(s: &str) -> String {
    s.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' || c == '~' {
                c.to_string()
            } else {
                format!("%{:02X}", c as u32)
            }
        })
        .collect()
}

pub fn safe_path_component(input: &str) -> String {
    input
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

fn unique_filename(name: &str, used: &mut HashSet<String>) -> String {
    let base = safe_path_component(name);
    if used.insert(base.clone()) {
        return base;
    }
    let ext = Path::new(&base)
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| format!(".{e}"))
        .unwrap_or_default();
    let stem = Path::new(&base)
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("file");
    let mut n = 2u32;
    loop {
        let candidate = format!("{stem}_{n}{ext}");
        if used.insert(candidate.clone()) {
            return candidate;
        }
        n += 1;
    }
}

fn flat_attachment_name(
    prefix: &str,
    project_identifier: &str,
    issue_id: &str,
    filename: &str,
) -> String {
    format!(
        "{}__{}__{}__{}",
        safe_path_component(prefix),
        safe_path_component(project_identifier),
        safe_path_component(issue_id),
        safe_path_component(filename),
    )
}

fn escape_html(input: &str) -> String {
    input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn redmine_named_field(value: &serde_json::Value) -> String {
    match value {
        serde_json::Value::String(s) => s.clone(),
        serde_json::Value::Object(obj) => obj
            .get("name")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string(),
        _ => String::new(),
    }
}

fn issue_attachments_html(
    issues_html_leaf: &str,
    file_prefix: &str,
    project_identifier: &str,
    issue: &serde_json::Value,
) -> String {
    let issue_id = issue
        .get("id")
        .and_then(|v| v.as_u64())
        .map(|id| id.to_string())
        .unwrap_or_else(|| "issue".into());
    let Some(list) = issue.get("attachments").and_then(|a| a.as_array()) else {
        return String::new();
    };
    if list.is_empty() {
        return String::new();
    }
    let mut out = String::from("<ul class=\"att\">");
    for att in list {
        let name = att
            .get("filename")
            .and_then(|v| v.as_str())
            .unwrap_or("file");
        if is_excluded_media_filename(name) {
            continue;
        }
        let safe_name = safe_path_component(name);
        let att_leaf = flat_attachment_name(
            file_prefix,
            project_identifier,
            &issue_id,
            &safe_name,
        );
        let href = output_relative_href(issues_html_leaf, &att_leaf);
        out.push_str(&format!(
            "<li><a href=\"{href}\">{}</a></li>",
            escape_html(name)
        ));
    }
    out.push_str("</ul>");
    out
}

fn render_project_issues_html(
    base: &Url,
    session_user: &str,
    file_prefix: &str,
    project: &RedmineProject,
    exported: u32,
    total: u32,
    issues: &[serde_json::Value],
) -> String {
    let issues_html_leaf = format!("{file_prefix}__{}__issues.html", project.identifier);
    let site = base.to_string();
    let mut rows = String::new();
    for issue in issues {
        let id = issue
            .get("id")
            .and_then(|v| v.as_u64())
            .map(|n| n.to_string())
            .unwrap_or_default();
        let subject = issue
            .get("subject")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let tracker = issue
            .get("tracker")
            .map(redmine_named_field)
            .unwrap_or_default();
        let status = issue
            .get("status")
            .map(redmine_named_field)
            .unwrap_or_default();
        let priority = issue
            .get("priority")
            .map(redmine_named_field)
            .unwrap_or_default();
        let assignee = issue
            .get("assigned_to")
            .map(redmine_named_field)
            .unwrap_or_default();
        let author = issue
            .get("author")
            .map(redmine_named_field)
            .unwrap_or_default();
        let created = issue
            .get("created_on")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let updated = issue
            .get("updated_on")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let description = issue
            .get("description")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let desc_html = if description.is_empty() {
            String::new()
        } else {
            format!("<div class=\"desc\">{}</div>", escape_html(description))
        };
        let attachments = issue_attachments_html(
            &issues_html_leaf,
            file_prefix,
            &project.identifier,
            issue,
        );
        rows.push_str(&format!(
            "<tr><td>#{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>\
            <td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>",
            escape_html(&id),
            escape_html(&tracker),
            escape_html(&status),
            escape_html(&priority),
            escape_html(subject),
            escape_html(&assignee),
            escape_html(&author),
            escape_html(created),
            escape_html(updated),
            attachments,
            desc_html,
        ));
    }

    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Redmine — {project_name}</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f6f7f9;color:#333}}
h1{{font-size:1.35rem;margin-bottom:4px}}
.meta{{color:#666;font-size:0.9rem}}
.wrap{{background:#fff;border:1px solid #ddd;border-radius:8px;padding:16px;margin:16px 0}}
table{{width:100%;border-collapse:collapse;font-size:0.85rem}}
th,td{{border:1px solid #ddd;padding:6px 8px;vertical-align:top;text-align:left}}
th{{background:#f0f0f0}}
ul.att{{margin:0;padding-left:18px}}
.desc{{margin-top:6px;color:#444;white-space:pre-wrap;font-size:0.8rem}}
a{{color:#169}}
</style>
</head>
<body>
<h1>{project_name}</h1>
<p class="meta">Site: {site}<br/>User: {user}<br/>Project: {project_id} — exported {exported} / {total} issues</p>
<div class="wrap">
<table>
<thead><tr>
<th>ID</th><th>Tracker</th><th>Status</th><th>Priority</th><th>Subject</th>
<th>Assignee</th><th>Author</th><th>Created</th><th>Updated</th><th>Attachments</th><th>Description</th>
</tr></thead>
<tbody>
{rows}
</tbody>
</table>
</div>
</body>
</html>"#,
        project_name = escape_html(&project.name),
        site = escape_html(&site),
        user = escape_html(session_user),
        project_id = escape_html(&project.identifier),
        exported = exported,
        total = total,
        rows = rows,
    )
}

fn journal_notes_text(journal: &serde_json::Value) -> String {
    journal
        .get("notes")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .trim()
        .to_string()
}

fn render_project_notes_html(
    base: &Url,
    session_user: &str,
    project: &RedmineProject,
    issues: &[serde_json::Value],
) -> String {
    let site = base.to_string();
    let mut rows = String::new();
    let mut note_count = 0usize;
    for issue in issues {
        let issue_id = issue
            .get("id")
            .and_then(|v| v.as_u64())
            .map(|n| n.to_string())
            .unwrap_or_default();
        let subject = issue
            .get("subject")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let Some(journals) = issue.get("journals").and_then(|j| j.as_array()) else {
            continue;
        };
        for journal in journals {
            let text = journal_notes_text(journal);
            if text.is_empty() {
                continue;
            }
            note_count += 1;
            let author = journal
                .get("user")
                .map(redmine_named_field)
                .unwrap_or_default();
            let created = journal
                .get("created_on")
                .and_then(|v| v.as_str())
                .unwrap_or("");
            let jid = journal
                .get("id")
                .and_then(|v| v.as_u64())
                .map(|n| n.to_string())
                .unwrap_or_default();
            rows.push_str(&format!(
                "<tr><td>#{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td><pre class=\"note\">{}</pre></td></tr>",
                escape_html(&issue_id),
                escape_html(subject),
                escape_html(&jid),
                escape_html(&author),
                escape_html(created),
                escape_html(&text),
            ));
        }
    }

    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Redmine notes — {project_name}</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f6f7f9;color:#333}}
h1{{font-size:1.35rem;margin-bottom:4px}}
.meta{{color:#666;font-size:0.9rem}}
.wrap{{background:#fff;border:1px solid #ddd;border-radius:8px;padding:16px;margin:16px 0}}
table{{width:100%;border-collapse:collapse;font-size:0.85rem}}
th,td{{border:1px solid #ddd;padding:6px 8px;vertical-align:top;text-align:left}}
th{{background:#f0f0f0}}
pre.note{{white-space:pre-wrap;margin:0;font-family:inherit;font-size:0.85rem}}
</style>
</head>
<body>
<h1>Notes — {project_name}</h1>
<p class="meta">Site: {site}<br/>User: {user}<br/>Project: {project_id} — {note_count} journal entries</p>
<div class="wrap">
<table>
<thead><tr>
<th>Issue</th><th>Subject</th><th>Journal</th><th>Author</th><th>Created</th><th>Notes</th>
</tr></thead>
<tbody>
{rows}
</tbody>
</table>
</div>
</body>
</html>"#,
        project_name = escape_html(&project.name),
        site = escape_html(&site),
        user = escape_html(session_user),
        project_id = escape_html(&project.identifier),
        note_count = note_count,
        rows = rows,
    )
}

async fn write_issues_html(path: &Path, html: &str) -> Result<u64> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(path, html.as_bytes()).await?;
    Ok(html.len() as u64)
}

fn sanitize_wiki_leaf(title: &str) -> String {
    let s = safe_path_component(title);
    if s.is_empty() {
        "page".into()
    } else {
        s.chars().take(80).collect()
    }
}

fn wiki_textile_to_html_pre(text: &str) -> String {
    // Preserve Textile/Markdown as readable preformatted HTML (no full wiki parser).
    format!(
        "<pre class=\"wiki-body\">{}</pre>",
        escape_html(text)
    )
}

fn render_wiki_index_html(
    base: &Url,
    session_user: &str,
    project: &RedmineProject,
    pages: &[(String, String, String)],
) -> String {
    let site = base.to_string();
    let mut items = String::new();
    for (title, _text, leaf) in pages {
        let href = escape_html(leaf);
        items.push_str(&format!(
            "<li><a href=\"{href}\">{}</a></li>",
            escape_html(title)
        ));
    }
    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Wiki — {project_name}</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f6f7f9;color:#333}}
h1{{font-size:1.35rem;margin-bottom:4px}}
.meta{{color:#666;font-size:0.9rem}}
.wrap{{background:#fff;border:1px solid #ddd;border-radius:8px;padding:16px;margin:16px 0}}
ul{{line-height:1.6}}
a{{color:#169}}
</style>
</head>
<body>
<h1>Wiki — {project_name}</h1>
<p class="meta">Site: {site}<br/>User: {user}<br/>Project: {project_id} — {count} pages</p>
<div class="wrap">
<ul>
{items}
</ul>
</div>
</body>
</html>"#,
        project_name = escape_html(&project.name),
        site = escape_html(&site),
        user = escape_html(session_user),
        project_id = escape_html(&project.identifier),
        count = pages.len(),
        items = items,
    )
}

fn render_wiki_page_html(
    base: &Url,
    session_user: &str,
    project: &RedmineProject,
    title: &str,
    text: &str,
    index_leaf: &str,
) -> String {
    let site = base.to_string();
    let body = wiki_textile_to_html_pre(text);
    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>{title_esc} — Wiki — {project_name}</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f6f7f9;color:#333}}
h1{{font-size:1.35rem;margin-bottom:4px}}
.meta{{color:#666;font-size:0.9rem}}
.wrap{{background:#fff;border:1px solid #ddd;border-radius:8px;padding:16px;margin:16px 0}}
pre.wiki-body{{white-space:pre-wrap;word-break:break-word;font-family:Consolas,monospace;font-size:0.85rem;margin:0}}
a{{color:#169}}
</style>
</head>
<body>
<p class="meta"><a href="{index_href}">← Wiki index</a></p>
<h1>{title_esc}</h1>
<p class="meta">Site: {site}<br/>User: {user}<br/>Project: {project_id}</p>
<div class="wrap">
{body}
</div>
</body>
</html>"#,
        title_esc = escape_html(title),
        project_name = escape_html(&project.name),
        site = escape_html(&site),
        user = escape_html(session_user),
        project_id = escape_html(&project.identifier),
        index_href = escape_html(index_leaf),
        body = body,
    )
}

fn extract_authenticity_token(html: &str) -> Option<String> {
    AUTH_TOKEN_RE
        .captures(html)
        .or_else(|| AUTH_TOKEN_RE2.captures(html))
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn hostedredmine_tenant_url(scheme: &str, username: &str) -> Option<Url> {
    let local = username.split('@').next()?.trim();
    if local.is_empty() {
        return None;
    }
    let safe: String = local
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' {
                c.to_ascii_lowercase()
            } else {
                '-'
            }
        })
        .collect();
    Url::parse(&format!("{scheme}://{safe}.hostedredmine.com/")).ok()
}

pub fn effective_redmine_base(cred: &Credential) -> Url {
    let host = cred.url.host_str().unwrap_or("").to_ascii_lowercase();
    if host == "hostedredmine.com" || host == "www.hostedredmine.com" {
        let scheme = cred.url.scheme();
        let scheme = if scheme == "http" || scheme == "https" {
            scheme
        } else {
            "https"
        };
        if let Some(u) = hostedredmine_tenant_url(scheme, &cred.username) {
            return u;
        }
    }
    cred.url.clone()
}

/// Same scheme/port/path as in the combo — no http↔https flip.
fn candidate_redmine_bases(base: &Url) -> Vec<Url> {
    let mut bases = Vec::new();
    let mut push = |u: Url| {
        if !bases.iter().any(|x: &Url| x.as_str() == u.as_str()) {
            bases.push(u);
        }
    };
    push(base.clone());
    let path = base.path();
    if (path.is_empty() || path == "/")
        && !base.host_str().unwrap_or("").to_ascii_lowercase().contains("redmine")
    {
        if let Ok(sub) = base.join("redmine/") {
            push(sub);
        }
    }
    bases
}

pub async fn download_redmine_projects(
    cred: &Credential,
    config: &RedmineClientConfig,
    output_dir: &Path,
    download_files: bool,
    export_options: RedmineExportOptions,
) -> Result<(RedmineAccountStats, Vec<(RedmineProject, PathBuf, u64)>)> {
    download_redmine_once(cred.clone(), config, output_dir, download_files, export_options).await
}

async fn download_redmine_once(
    cred: Credential,
    config: &RedmineClientConfig,
    output_dir: &Path,
    download_files: bool,
    options: RedmineExportOptions,
) -> Result<(RedmineAccountStats, Vec<(RedmineProject, PathBuf, u64)>)> {
    let base = effective_redmine_base(&cred);
    let export_base = base.clone();
    let mut client = RedmineClient::new(base, &cred.username, &cred.password, config)?;
    let (session_user, is_admin) = client
        .connect()
        .await
        .with_context(|| format!("Redmine login failed for {}", cred.display_line()))?;

    let projects = client.list_projects().await?;
    let project_count = projects.len();

    if projects.is_empty() {
        return Ok((
            RedmineAccountStats {
                username: session_user,
                is_admin,
                projects: 0,
                issues_exported: 0,
                notes_exported: 0,
                wiki_pages: 0,
                attachments: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    if !download_files {
        return Ok((
            RedmineAccountStats {
                username: session_user,
                is_admin,
                projects: project_count,
                issues_exported: 0,
                notes_exported: 0,
                wiki_pages: 0,
                attachments: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    if !options.any_selected() {
        return Ok((
            RedmineAccountStats {
                username: session_user,
                is_admin,
                projects: project_count,
                issues_exported: 0,
                notes_exported: 0,
                wiki_pages: 0,
                attachments: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "redmine");
    let prefix = cred.account_file_prefix();
    let mut written = Vec::new();
    let mut issues_total = 0u32;
    let mut wiki_total = 0usize;
    let mut attachment_total = 0usize;
    let mut total_bytes = 0u64;
    let mut attachment_bytes_account = 0u64;

    for project in projects {
        let need_issue_list = options.issues || options.attachments;
        if need_issue_list {
            match client
                .export_project_issues(&project, false)
                .await
            {
                Ok((exported, total_matching, mut issues)) => {
                    if options.issues {
                        issues_total += exported;
                    }

                    if options.attachments {
                        client.enrich_issues_attachments(&mut issues).await;
                    }

                    let html_leaf = format!("{prefix}__{}__issues.html", project.identifier);

                    if options.issues {
                        let html_path = output_file_path(&site_dir, &html_leaf);
                        let html = render_project_issues_html(
                            &export_base,
                            &session_user,
                            &prefix,
                            &project,
                            exported,
                            total_matching,
                            &issues,
                        );

                        match write_issues_html(&html_path, &html).await {
                            Ok(bytes) => {
                                total_bytes += bytes;
                                written.push((project.clone(), html_path.clone(), bytes));
                            }
                            Err(err) => {
                                warn!(
                                    "Redmine HTML write {} for {}: {err}",
                                    project.identifier,
                                    cred.display_line()
                                );
                            }
                        }
                    }

                    if options.attachments {
                        match client
                            .download_issue_attachments(
                                &project,
                                &issues,
                                &html_leaf,
                                &site_dir,
                                &prefix,
                                &mut attachment_bytes_account,
                            )
                            .await
                        {
                            Ok((count, att_bytes)) => {
                                attachment_total += count;
                                total_bytes += att_bytes;
                            }
                            Err(err) => warn!(
                                "Redmine issue attachments {} for {}: {err}",
                                project.identifier,
                                cred.display_line()
                            ),
                        }

                        match client
                            .download_project_files(
                                &project,
                                &site_dir,
                                &prefix,
                                &mut attachment_bytes_account,
                            )
                            .await
                        {
                            Ok((count, att_bytes)) => {
                                attachment_total += count;
                                total_bytes += att_bytes;
                            }
                            Err(err) => warn!(
                                "Redmine project files {} for {}: {err}",
                                project.identifier,
                                cred.display_line()
                            ),
                        }
                    }
                }
                Err(err) => warn!(
                    "Redmine export {} for {}: {err}",
                    project.identifier,
                    cred.display_line()
                ),
            }
        }

        if options.wiki {
            match client
                .export_project_wiki(
                    &project,
                    &site_dir,
                    &prefix,
                    &export_base,
                    &session_user,
                )
                .await
            {
                Ok((pages, wiki_bytes, wiki_files)) => {
                    wiki_total += pages;
                    total_bytes += wiki_bytes;
                    written.extend(wiki_files);
                }
                Err(err) => warn!(
                    "Redmine wiki {} for {}: {err}",
                    project.identifier,
                    cred.display_line()
                ),
            }
        }
    }

    Ok((
        RedmineAccountStats {
            username: session_user,
            is_admin,
            projects: project_count,
            issues_exported: issues_total as usize,
            notes_exported: 0,
            wiki_pages: wiki_total,
            attachments: attachment_total,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    use pma_core::parse_redmine_line;
    use std::env;

    /// `cargo test -p pma-net redmine_belcash_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "network: live Redmine belcash.com"]
    async fn redmine_belcash_smoke() {
        let cred =
            parse_redmine_line("http://redmine.belcash.com admin:admin").expect("parse combo");
        assert_eq!(cred.url.scheme(), "http");
        let out = env::temp_dir().join("redmine_belcash_smoke");
        let _ = fs::remove_dir_all(&out).await;
        fs::create_dir_all(&out).await.unwrap();
        let config = RedmineClientConfig::default();
        let (check, _) = download_redmine_projects(
            &cred,
            &config,
            &out,
            false,
            RedmineExportOptions::default(),
        )
            .await
            .expect("login / list projects");
        eprintln!("check-only: {}", check.detail_line());
        assert!(check.projects > 0, "expected visible projects");
        let (stats, files) = download_redmine_projects(
            &cred,
            &config,
            &out,
            true,
            RedmineExportOptions::default(),
        )
            .await
            .expect("export");
        eprintln!("export: {}", stats.detail_line());
        eprintln!("html files written: {}", files.len());
        assert!(stats.issues_exported > 0 || !files.is_empty());
    }
}
