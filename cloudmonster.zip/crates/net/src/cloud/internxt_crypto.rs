//! Internxt Drive crypto (ported from internxt/rclone-adapter).

use aes::cipher::{block_padding::Pkcs7, BlockDecryptMut, BlockEncryptMut, KeyIvInit};
use aes::Aes256;
use anyhow::{anyhow, Context, Result};
use md5::Digest;
use pbkdf2::pbkdf2_hmac;
use rand::RngCore;
use sha1::Sha1;

const APP_CRYPTO_SECRET: &str = "6KYQBP847D4ATSFA";
const SALTED_PREFIX: &[u8] = b"Salted__";

type Aes256CbcEnc = cbc::Encryptor<Aes256>;
type Aes256CbcDec = cbc::Decryptor<Aes256>;

pub fn encrypt_password_hash(password: &str, encrypted_salt: &str) -> Result<String> {
    let salt = decrypt_text(encrypted_salt, APP_CRYPTO_SECRET)?;
    let hash = pass_to_hash(password, &salt)?;
    encrypt_text(&hash, APP_CRYPTO_SECRET)
}

fn pass_to_hash(password: &str, salt_hex: &str) -> Result<String> {
    let salt = hex::decode(salt_hex).context("internxt salt hex")?;
    let mut out = [0u8; 32];
    pbkdf2_hmac::<Sha1>(password.as_bytes(), &salt, 10_000, &mut out);
    Ok(hex::encode(out))
}

fn get_key_iv_from(secret: &str, salt: &[u8]) -> ([u8; 32], [u8; 16]) {
    let password = [secret.as_bytes(), salt].concat();
    let mut digest = password.clone();
    let mut md5_hashes: Vec<Vec<u8>> = Vec::with_capacity(3);
    for _ in 0..3 {
        let mut hasher = md5::Md5::new();
        hasher.update(&digest);
        let h = hasher.finalize().to_vec();
        md5_hashes.push(h.clone());
        digest = [h, password.clone()].concat();
    }
    let mut key = [0u8; 32];
    key[..16].copy_from_slice(&md5_hashes[0]);
    key[16..].copy_from_slice(&md5_hashes[1]);
    let mut iv = [0u8; 16];
    iv.copy_from_slice(&md5_hashes[2]);
    (key, iv)
}

pub fn decrypt_text(encrypted_hex: &str, secret: &str) -> Result<String> {
    let cipher_text = hex::decode(encrypted_hex).context("internxt cipher hex")?;
    if cipher_text.len() < 16 || &cipher_text[..8] != SALTED_PREFIX {
        return Err(anyhow!("internxt: invalid OpenSSL blob"));
    }
    let salt = &cipher_text[8..16];
    let encrypted_content = &cipher_text[16..];
    let (key, iv) = get_key_iv_from(secret, salt);
    let dec = Aes256CbcDec::new_from_slices(&key, &iv).context("internxt aes dec")?;
    let mut buf = encrypted_content.to_vec();
    let plain = dec
        .decrypt_padded_mut::<Pkcs7>(&mut buf)
        .map_err(|e| anyhow!("internxt aes unpad: {e:?}"))?;
    String::from_utf8(plain.to_vec()).context("internxt plain utf8")
}

fn encrypt_text(plain_text: &str, secret: &str) -> Result<String> {
    let mut salt = [0u8; 8];
    rand::thread_rng().fill_bytes(&mut salt);
    let (key, iv) = get_key_iv_from(secret, &salt);
    let enc = Aes256CbcEnc::new_from_slices(&key, &iv).context("internxt aes enc")?;
    let mut buf = plain_text.as_bytes().to_vec();
    let pos = buf.len();
    buf.resize(pos + 16, 0);
    let cipher = enc
        .encrypt_padded_mut::<Pkcs7>(&mut buf, pos)
        .map_err(|e| anyhow!("internxt aes pad: {e:?}"))?;
    let mut out = Vec::with_capacity(8 + 8 + cipher.len());
    out.extend_from_slice(SALTED_PREFIX);
    out.extend_from_slice(&salt);
    out.extend_from_slice(cipher);
    Ok(hex::encode(out))
}
