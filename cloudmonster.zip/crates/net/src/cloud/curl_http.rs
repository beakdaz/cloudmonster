//! Общая HTTP-сессия для облачных чекеров (reqwest + ручной cookie-jar).

use super::common::{cloud_network_error, cloud_rate_limit_error};
use super::config::{cloud_browser_headers, CloudClientConfig};
use anyhow::{Context, Result};
use pma_core::CloudProvider;
use reqwest::header::{HeaderName, LOCATION, SET_COOKIE};
use reqwest::header::HeaderMap;
use reqwest::{Client, Method};
use serde_json::Value;
use std::str::FromStr;
use std::time::Duration;
use url::Url;

// #region agent log
fn cloud_curl_debug(provider: CloudProvider, hypothesis_id: &str, ctx: &str, data_json: &str) {
    use std::fs::OpenOptions;
    use std::io::Write;
    use std::sync::Mutex;
    static LOCK: Mutex<()> = Mutex::new(());
    let _g = LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let line = format!(
        r#"{{"sessionId":"be3b27","hypothesisId":"{hypothesis_id}","location":"curl_http.rs","message":"{ctx}","data":{{"provider":"{}","detail":{data_json}}},"timestamp":{ts},"runId":"cloud-curl"}}"#,
        provider.label()
    );
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

pub struct CloudCurlSession {
    cookies: Vec<(String, String)>,
    /// Provider-specific browser mimicry (User-Agent, sec-ch-ua, …) applied on every request.
    browser_profile: Vec<(String, String)>,
}

impl CloudCurlSession {
    pub fn new() -> Result<Self> {
        Ok(Self {
            cookies: Vec::new(),
            browser_profile: Vec::new(),
        })
    }

    pub fn set_browser_profile(&mut self, headers: Vec<(String, String)>) {
        self.browser_profile = headers;
    }

    pub async fn get_text(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        url: &str,
        extra: &[(&str, &str)],
        follow_redirects: bool,
    ) -> Result<(u16, String)> {
        let (status, text, _) = self
            .exchange(cfg, ctx, Method::GET, url, None, extra, follow_redirects)
            .await?;
        Ok((status, text))
    }

    pub async fn get_json(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        url: &str,
        extra: &[(&str, &str)],
    ) -> Result<Value> {
        let (status, text) = self.get_text(cfg, ctx, url, extra, false).await?;
        parse_json_text(cfg.provider, status, &text, ctx)
    }

    pub async fn post_form(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        url: &str,
        form: &[(&str, &str)],
        extra: &[(&str, &str)],
        follow_redirects: bool,
    ) -> Result<(u16, String)> {
        let body = form_urlencoded_body(form);
        let mut headers: Vec<(&str, &str)> = extra.to_vec();
        headers.push(("Content-Type", "application/x-www-form-urlencoded"));
        let (status, text, _) = self
            .exchange(
                cfg,
                ctx,
                Method::POST,
                url,
                Some(body.into_bytes()),
                &headers,
                follow_redirects,
            )
            .await?;
        Ok((status, text))
    }

    pub async fn post_body(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        url: &str,
        body: Vec<u8>,
        content_type: &str,
        extra: &[(&str, &str)],
        follow_redirects: bool,
    ) -> Result<(u16, String)> {
        let mut headers: Vec<(&str, &str)> = extra.to_vec();
        headers.push(("Content-Type", content_type));
        let (status, text, _) = self
            .exchange(
                cfg,
                ctx,
                Method::POST,
                url,
                Some(body),
                &headers,
                follow_redirects,
            )
            .await?;
        Ok((status, text))
    }

    pub async fn post_json(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        url: &str,
        json: &Value,
        extra: &[(&str, &str)],
    ) -> Result<(u16, Value)> {
        let body = serde_json::to_vec(json).context("cloud json encode")?;
        let mut headers: Vec<(&str, &str)> = extra.to_vec();
        headers.push(("Content-Type", "application/json"));
        headers.push(("Accept", "application/json"));
        let (status, text, _) = self
            .exchange(
                cfg,
                ctx,
                Method::POST,
                url,
                Some(body),
                &headers,
                false,
            )
            .await?;
        let v = parse_json_text(cfg.provider, status, &text, ctx)?;
        Ok((status, v))
    }

    pub async fn exchange(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        method: Method,
        url: &str,
        body: Option<Vec<u8>>,
        extra: &[(&str, &str)],
        follow_redirects: bool,
    ) -> Result<(u16, String, Vec<String>)> {
        let timeout = cfg.timeout;
        let client = &cfg.http_no_redirect;
        let max_hops = if follow_redirects { 10u32 } else { 0 };
        let mut current_url = url.to_string();
        let mut hop_method = method;
        let mut hop_body = body;
        let mut last_status = 0u16;
        let mut last_preview = String::new();

        for hop in 0..=max_hops {
            for attempt in 0..4u32 {
                let mut headers = header_pairs(cfg, extra);
                for (k, v) in &self.browser_profile {
                    headers.retain(|(n, _)| !n.eq_ignore_ascii_case(k));
                    headers.push((k.clone(), v.clone()));
                }
                if hop_body.is_some()
                    && !headers
                        .iter()
                        .any(|(k, _)| k.eq_ignore_ascii_case("content-type"))
                {
                    headers.push((
                        "Content-Type".to_string(),
                        "application/x-www-form-urlencoded".to_string(),
                    ));
                }
                let cookie_line = self.cookie_header();
                if !cookie_line.is_empty() {
                    headers.push(("Cookie".to_string(), cookie_line));
                }

                let exchange_result = reqwest_exchange(
                    client,
                    hop_method.clone(),
                    &current_url,
                    hop_body.clone(),
                    &headers,
                    timeout,
                )
                .await;

                let (status, text, set_cookies, location) = match exchange_result {
                    Ok(v) => v,
                    Err(e) if is_cloud_transport_error(&e) && attempt < 3 => {
                        let wait_ms = 750u64 * (attempt as u64 + 1);
                        tokio::time::sleep(Duration::from_millis(wait_ms)).await;
                        continue;
                    }
                    Err(e) => {
                        return Err(e).with_context(|| format!("{ctx} http"));
                    }
                };

                merge_set_cookies(&mut self.cookies, &set_cookies);
                last_status = status;
                last_preview = preview_body(&text, 120);
                let block = is_edge_block(status, &text);
                cloud_curl_debug(
                    cfg.provider,
                    if block { "H2" } else { "H3" },
                    ctx,
                    &format!(
                        r#"{{"attempt":{attempt},"hop":{hop},"status":{status},"blocked":{block},"preview":{}}}"#,
                        serde_json::to_string(&last_preview).unwrap_or_else(|_| "\"\"".into())
                    ),
                );
                if block {
                    if attempt < 3 {
                        let wait_ms = 500u64 * (attempt as u64 + 1);
                        tokio::time::sleep(Duration::from_millis(wait_ms)).await;
                        continue;
                    }
                    return Err(cloud_rate_limit_error(format!(
                        "{ctx}: http {status} (cloudflare/rate limit)"
                    )));
                }

                if follow_redirects
                    && hop < max_hops
                    && is_redirect_status(status)
                    && location.as_deref().is_some_and(|l| !l.is_empty())
                {
                    current_url =
                        resolve_redirect_url(&current_url, location.as_deref().unwrap())?;
                    hop_method = Method::GET;
                    hop_body = None;
                    break;
                }

                return Ok((status, text, set_cookies));
            }
            if hop < max_hops {
                continue;
            }
        }
        Err(cloud_rate_limit_error(format!(
            "{ctx}: http {last_status} {last_preview}"
        )))
    }
}

async fn reqwest_exchange(
    client: &Client,
    method: Method,
    url: &str,
    body: Option<Vec<u8>>,
    headers: &[(String, String)],
    timeout: Duration,
) -> Result<(u16, String, Vec<String>, Option<String>)> {
    let mut req = client.request(method, url).timeout(timeout);
    for (k, v) in headers {
        let name = HeaderName::from_str(k).with_context(|| format!("invalid header name: {k}"))?;
        req = req.header(name, v.as_str());
    }
    if let Some(b) = body {
        req = req.body(b);
    }
    let resp = req
        .send()
        .await
        .map_err(map_reqwest_transport_error)
        .context("cloud http send")?;
    let status = resp.status().as_u16();
    let location = resp
        .headers()
        .get(LOCATION)
        .and_then(|v| v.to_str().ok())
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(str::to_string);
    let set_cookies: Vec<String> = resp
        .headers()
        .get_all(SET_COOKIE)
        .iter()
        .filter_map(|v| v.to_str().ok().map(String::from))
        .collect();
    let text = resp
        .text()
        .await
        .map_err(map_reqwest_transport_error)
        .context("cloud http body")?;
    Ok((status, text, set_cookies, location))
}

fn is_redirect_status(status: u16) -> bool {
    matches!(status, 301 | 302 | 303 | 307 | 308)
}

fn resolve_redirect_url(base: &str, location: &str) -> Result<String> {
    if let Ok(abs) = Url::parse(location) {
        return Ok(abs.into());
    }
    let base_url = Url::parse(base).with_context(|| format!("redirect base url: {base}"))?;
    base_url
        .join(location)
        .with_context(|| format!("redirect join: {base} + {location}"))
        .map(|u| u.into())
}

fn is_cloud_transport_error(err: &anyhow::Error) -> bool {
    err.chain()
        .any(|c| c.downcast_ref::<CloudNetworkMarker>().is_some())
        || format!("{err:#}").contains("cloud network:")
}

/// Tag applied by [`map_reqwest_transport_error`] for retry detection.
#[derive(Debug)]
struct CloudNetworkMarker;

impl std::fmt::Display for CloudNetworkMarker {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("cloud network transport")
    }
}

impl std::error::Error for CloudNetworkMarker {}

fn map_reqwest_transport_error(err: reqwest::Error) -> anyhow::Error {
    if err.is_connect() || err.is_timeout() || err.is_request() {
        let detail = err.to_string();
        return cloud_network_error(if detail.is_empty() {
            "connection failed".to_string()
        } else {
            detail
        })
        .context(CloudNetworkMarker);
    }
    err.into()
}

pub fn header_pairs(cfg: &CloudClientConfig, extra: &[(&str, &str)]) -> Vec<(String, String)> {
    let map = cloud_browser_headers(cfg.provider, None);
    let mut out = header_map_to_pairs(&map);
    for (k, v) in extra {
        out.retain(|(n, _)| !n.eq_ignore_ascii_case(k));
        out.push(((*k).to_string(), (*v).to_string()));
    }
    out
}

pub fn json_api_header_pairs(cfg: &CloudClientConfig, referer: Option<&str>) -> Vec<(String, String)> {
    let map = super::common::json_api_headers(cfg, referer);
    header_map_to_pairs(&map)
}

fn header_map_to_pairs(map: &HeaderMap) -> Vec<(String, String)> {
    map.iter()
        .filter_map(|(k, v)| v.to_str().ok().map(|s| (k.to_string(), s.to_string())))
        .collect()
}

fn form_urlencoded_body(pairs: &[(&str, &str)]) -> String {
    let mut out = String::new();
    {
        let mut ser = url::form_urlencoded::Serializer::new(&mut out);
        for (k, v) in pairs {
            ser.append_pair(k, v);
        }
    }
    out
}

pub fn build_url(base: &str, params: &[(&str, &str)]) -> Result<String> {
    let mut url = Url::parse(base).context("cloud url")?;
    {
        let mut q = url.query_pairs_mut();
        for (k, v) in params {
            q.append_pair(k, v);
        }
    }
    Ok(url.into())
}

/// HTTP 200/403 HTML / debug dumps from captive portals, WAF, or poisoned proxies — not API JSON.
pub fn body_is_non_api_response(body: &str) -> bool {
    is_proxy_polluted_body(body)
}

/// HTTP 200 HTML / debug dumps from captive portals or poisoned proxies — not API JSON.
fn is_proxy_polluted_body(body: &str) -> bool {
    let trimmed = body.trim();
    if trimmed.is_empty() {
        return false;
    }
    let lower = trimmed.to_lowercase();
    if lower.starts_with("<!doctype html") || lower.starts_with("<html") {
        return true;
    }
    if trimmed.starts_with("REMOTE_ADDR =") || trimmed.contains("\nREQUEST_URI = ") {
        return true;
    }
    false
}

pub fn parse_json_text(
    _provider: CloudProvider,
    status: u16,
    text: &str,
    ctx: &str,
) -> Result<Value> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Err(cloud_network_error(format!(
            "{ctx}: empty body (http {status})"
        )));
    }
    if is_proxy_polluted_body(trimmed) {
        return Err(cloud_network_error(format!(
            "{ctx}: proxy or gateway returned non-API body (http {status}): {}",
            preview_body(trimmed, 120)
        )));
    }
    match serde_json::from_str(trimmed) {
        Ok(v) => Ok(v),
        Err(e) => {
            if is_proxy_polluted_body(trimmed) {
                return Err(cloud_network_error(format!(
                    "{ctx}: proxy or gateway returned non-API body (http {status}): {}",
                    preview_body(trimmed, 120)
                )));
            }
            Err(e).with_context(|| {
                format!(
                    "{ctx}: invalid json (http {status}): {}",
                    preview_body(trimmed, 240)
                )
            })
        }
    }
}

fn preview_body(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

fn is_waf_challenge_body(body: &str) -> bool {
    let lower = body.to_lowercase();
    if lower.contains("just a moment") {
        return true;
    }
    if lower.contains("cf-browser-verification")
        || lower.contains("challenge-platform")
        || lower.contains("/cdn-cgi/challenge")
    {
        return true;
    }
    if lower.contains("checking your browser") && lower.contains("cloudflare") {
        return true;
    }
    body.contains("MediaFire.com - Error")
}

fn is_edge_block(status: u16, body: &str) -> bool {
    if status == 404 && body.trim_start().starts_with('{') {
        return false;
    }
    match status {
        429 => true,
        403 | 503 => is_waf_challenge_body(body),
        200..=299 => is_waf_challenge_body(body),
        _ => false,
    }
}

fn merge_set_cookies(jar: &mut Vec<(String, String)>, lines: &[String]) {
    for line in lines {
        let Some((name, rest)) = line.split_once('=') else {
            continue;
        };
        let value = rest.split(';').next().unwrap_or("").trim();
        jar.retain(|(k, _)| k != name);
        jar.push((name.to_string(), value.to_string()));
    }
}

impl CloudCurlSession {
    fn cookie_header(&self) -> String {
        self.cookies
            .iter()
            .map(|(k, v)| format!("{k}={v}"))
            .collect::<Vec<_>>()
            .join("; ")
    }

    pub fn cookie_value(&self, name: &str) -> Option<&str> {
        self.cookies
            .iter()
            .find(|(k, _)| k.eq_ignore_ascii_case(name))
            .map(|(_, v)| v.as_str())
    }

    pub fn any_cookie_name_starts_with(&self, prefix: &str) -> bool {
        self.cookies
            .iter()
            .any(|(k, _)| k.starts_with(prefix))
    }

    pub fn seed_cookie(&mut self, name: &str, value: &str) {
        merge_set_cookies(
            &mut self.cookies,
            &[format!("{name}={value}; Path=/")],
        );
    }

    /// Duplicate cookie jar (and browser profile) for parallel API walks sharing one login.
    pub fn fork_session(&self) -> Result<Self> {
        Ok(Self {
            cookies: self.cookies.clone(),
            browser_profile: self.browser_profile.clone(),
        })
    }

    /// WebDAV `PROPFIND` with HTTP Basic auth (ADrive, 4shared fallback).
    pub async fn webdav_propfind_basic(
        &mut self,
        cfg: &CloudClientConfig,
        ctx: &str,
        url: &str,
        user: &str,
        password: &str,
        depth: &str,
        body: &str,
        extra: &[(&str, &str)],
    ) -> Result<(u16, String)> {
        use base64::Engine;
        let token = base64::engine::general_purpose::STANDARD.encode(format!("{user}:{password}"));
        let mut owned: Vec<(String, String)> = header_pairs(cfg, extra);
        owned.retain(|(k, _)| !k.eq_ignore_ascii_case("authorization"));
        owned.push(("Authorization".to_string(), format!("Basic {token}")));
        owned.push(("Depth".to_string(), depth.to_string()));
        owned.push((
            "Content-Type".to_string(),
            "application/xml; charset=utf-8".to_string(),
        ));
        let cookie_line = self.cookie_header();
        if !cookie_line.is_empty() {
            owned.push(("Cookie".to_string(), cookie_line));
        }
        let propfind = Method::from_bytes(b"PROPFIND").context("PROPFIND method")?;
        let (status, text, set_cookies, _) = reqwest_exchange(
            &cfg.http_no_redirect,
            propfind,
            url,
            Some(body.as_bytes().to_vec()),
            &owned,
            cfg.timeout,
        )
        .await
        .with_context(|| format!("{ctx} PROPFIND"))?;
        merge_set_cookies(&mut self.cookies, &set_cookies);
        Ok((status, text))
    }
}
