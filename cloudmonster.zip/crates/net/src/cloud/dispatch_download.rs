//! Provider-specific filtered downloads after inventory.

use super::common::CloudInventory;
use super::config::CloudClientConfig;
use super::download::{download_http_file, matching_files};
use super::fex;
use super::filesfm;
use super::icedrive;
use super::mediafire;
use super::onedrive;
use super::pcloud;
use super::pixeldrain;
use anyhow::Result;
use pma_core::{output_file_path, Credential};
use reqwest::Client;
use std::path::{Path, PathBuf};

pub async fn download_filtered(
    cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let filter = &cfg.download_filter;
    let picks = matching_files(&inv.files, filter);
    if picks.is_empty() {
        return Ok((0, 0, Vec::new()));
    }
    match cfg.provider {
        pma_core::CloudProvider::Mediafire => {
            mediafire::download_filtered_files(cfg, client, cred, run_output_dir, inv, &picks).await
        }
        pma_core::CloudProvider::PixelDrain => {
            pixeldrain::download_filtered_files(client, cred, run_output_dir, &picks).await
        }
        pma_core::CloudProvider::Filesfm => {
            filesfm::download_filtered_files(cfg, client, cred, run_output_dir, inv, &picks).await
        }
        pma_core::CloudProvider::OneDrive => {
            onedrive::download_filtered_files(cfg, client, cred, run_output_dir, inv, &picks).await
        }
        pma_core::CloudProvider::Pcloud => {
            pcloud::download_filtered_files(cfg, client, cred, run_output_dir, inv, &picks).await
        }
        pma_core::CloudProvider::Fex => {
            fex::download_filtered_files(cfg, client, cred, run_output_dir, inv, &picks).await
        }
        pma_core::CloudProvider::Icedrive => {
            icedrive::download_filtered_files(cfg, client, cred, run_output_dir, inv, &picks).await
        }
        _ => Ok((0, 0, Vec::new())),
    }
}

/// Shared helper: write leaf under `{run}/{site_dir}/{ext}/`.
pub async fn write_leaf(
    cred: &Credential,
    run_output_dir: &Path,
    leaf: &str,
    client: &Client,
    url: &str,
) -> Result<(PathBuf, u64)> {
    let site_root = run_output_dir.join(cred.site_dir_name());
    let dest = output_file_path(&site_root, leaf);
    let n = download_http_file(client, url, &dest).await?;
    Ok((dest, n))
}

pub async fn write_bytes(
    cred: &Credential,
    run_output_dir: &Path,
    leaf: &str,
    bytes: &[u8],
) -> Result<(PathBuf, u64)> {
    use tokio::fs;
    let site_root = run_output_dir.join(cred.site_dir_name());
    let dest = output_file_path(&site_root, leaf);
    if let Some(parent) = dest.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(&dest, bytes).await?;
    Ok((dest, bytes.len() as u64))
}
