//! HTTP download helpers + filter application for cloud checkers.

use super::common::CloudFileMeta;
use anyhow::{Context, Result};
use pma_core::{output_file_path, CloudDownloadFilter, Credential};
use reqwest::Client;
use std::path::{Path, PathBuf};
use tokio::fs;
use tokio::io::AsyncWriteExt;

pub async fn download_http_file(client: &Client, url: &str, dest: &Path) -> Result<u64> {
    if let Some(parent) = dest.parent() {
        fs::create_dir_all(parent).await?;
    }
    let resp = client
        .get(url)
        .send()
        .await
        .with_context(|| format!("GET {url}"))?;
    if !resp.status().is_success() {
        anyhow::bail!("download http {}", resp.status());
    }
    let bytes = resp.bytes().await.context("download body")?;
    let mut f = fs::File::create(dest).await?;
    f.write_all(&bytes).await?;
    Ok(bytes.len() as u64)
}

pub fn matching_files<'a>(
    files: &'a [CloudFileMeta],
    filter: &CloudDownloadFilter,
) -> Vec<&'a CloudFileMeta> {
    files
        .iter()
        .filter(|f| filter.matches_parts(&f.path, &f.name, &f.keyword_extra, f.size))
        .collect()
}

pub async fn save_to_export_tree(
    cred: &Credential,
    run_output_dir: &Path,
    leaf_name: &str,
    bytes: &[u8],
) -> Result<PathBuf> {
    let site_root = run_output_dir.join(cred.site_dir_name());
    let dest = output_file_path(&site_root, leaf_name);
    if let Some(parent) = dest.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(&dest, bytes).await?;
    Ok(dest)
}
