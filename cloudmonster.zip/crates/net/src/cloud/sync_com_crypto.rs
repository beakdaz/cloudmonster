//! Sync.com filename / user-key crypto (SyncAPI.js / sjcl legacy layout).

use aes_gcm::aead::{Aead, KeyInit};
use aes_gcm::{Aes256Gcm, Nonce};
use anyhow::{anyhow, Context, Result};
use base64::Engine;
use pbkdf2::pbkdf2_hmac;
use sha1::Sha1;

const PBKDF2_ITERS: u32 = 10_000;

/// Decrypt `enc_meta_key` / `enc_priv_key` (`30:` + base64 sjcl blob).
pub fn sync_password_decrypt(b64_crypted: &str, password: &str) -> Result<String> {
    let trimmed = b64_crypted.trim();
    if !trimmed.starts_with("30:") {
        return Err(anyhow!("sync: unsupported key blob prefix"));
    }
    let raw = base64::engine::general_purpose::STANDARD
        .decode(trimmed.get(3..).unwrap_or(""))
        .context("sync key b64")?;
    if raw.len() < 24 {
        return Err(anyhow!("sync key blob too short"));
    }
    let salt = &raw[0..12];
    let iv = &raw[12..24];
    let cipher = &raw[24..];
    let mut key = [0u8; 32];
    pbkdf2_hmac::<Sha1>(password.as_bytes(), salt, PBKDF2_ITERS, &mut key);
    let plain = aes_gcm_decrypt(&key, iv, cipher)?;
    String::from_utf8(plain).context("sync key plain utf8")
}

/// Decrypt path item `enc_name` using decrypted meta key string (Sync web client).
pub fn sync_filename_decrypt(enc_name: &str, meta_key: &str) -> Result<String> {
    let payload = enc_name
        .split_once(':')
        .map(|(_, p)| p)
        .unwrap_or(enc_name);
    let raw = base64::engine::general_purpose::STANDARD
        .decode(payload)
        .context("sync enc_name b64")?;
    if raw.len() < 13 {
        return Err(anyhow!("sync enc_name too short"));
    }
    let meta_bytes = base64::engine::general_purpose::STANDARD
        .decode(meta_key.trim())
        .unwrap_or_else(|_| meta_key.as_bytes().to_vec());
    let mut key = [0u8; 32];
    let copy_len = meta_bytes.len().min(32);
    key[..copy_len].copy_from_slice(&meta_bytes[..copy_len]);
    let iv = &raw[0..12];
    let cipher = &raw[12..];
    let plain = aes_gcm_decrypt(&key, iv, cipher)?;
    String::from_utf8(plain).context("sync filename utf8")
}

fn aes_gcm_decrypt(key: &[u8; 32], iv: &[u8], cipher: &[u8]) -> Result<Vec<u8>> {
    if iv.len() != 12 {
        return Err(anyhow!("sync gcm iv len {}", iv.len()));
    }
    if cipher.len() < 16 {
        return Err(anyhow!("sync gcm cipher too short"));
    }
    let aes = Aes256Gcm::new_from_slice(key).context("sync aes key")?;
    let nonce = Nonce::from_slice(iv);
    aes.decrypt(nonce, cipher)
        .map_err(|e| anyhow!("sync gcm decrypt: {e}"))
}
