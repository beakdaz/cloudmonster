//! Per-provider HTTP client settings (non-MEGA cloud checkers).

use crate::concurrency::megax_cloud_login_parallel;
use crate::http_client::apply_proxy;
use anyhow::{Context, Result};
use pma_core::{CloudDownloadFilter, CloudIpStack, CloudProvider};
use std::net::{IpAddr, Ipv4Addr};
use reqwest::header::{HeaderMap, HeaderValue, ACCEPT, ACCEPT_LANGUAGE, ORIGIN, REFERER, USER_AGENT};
use reqwest::Client;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Semaphore;

const CHROME_UA: &str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

#[derive(Debug, Clone)]
pub struct CloudClientConfig {
    pub provider: CloudProvider,
    pub timeout: Duration,
    pub insecure: bool,
    pub proxy: Option<String>,
    pub http: Client,
    /// Same settings as `http`, but redirects are not followed (login flows).
    pub http_no_redirect: Client,
    pub login_semaphore: Arc<Semaphore>,
    pub download_from_cloud: bool,
    pub download_filter: CloudDownloadFilter,
}

impl CloudClientConfig {
    pub fn clone_with_proxy(&self, proxy: Option<String>) -> Result<Self> {
        if self.proxy == proxy {
            return Ok(self.clone());
        }
        let (http, http_no_redirect) = build_cloud_http_clients(
            self.provider,
            self.timeout,
            self.insecure,
            proxy.as_deref(),
        )?;
        Ok(Self {
            proxy,
            http,
            http_no_redirect,
            ..self.clone()
        })
    }

    pub fn build(
        provider: CloudProvider,
        timeout: Duration,
        insecure: bool,
        proxy: Option<String>,
        checker_threads: usize,
        download_from_cloud: bool,
        download_filter: CloudDownloadFilter,
    ) -> Result<Self> {
        let spec = provider.spec();
        let slots = megax_cloud_login_parallel(spec.login_concurrency, checker_threads);
        // Cloud checkers use CloudCurlSession (reqwest + manual cookies); MEGA uses curl-impersonate separately.
        let (http, http_no_redirect) =
            build_cloud_http_clients(provider, timeout, insecure, proxy.as_deref())?;
        Ok(Self {
            provider,
            timeout,
            insecure,
            proxy,
            http,
            http_no_redirect,
            login_semaphore: Arc::new(Semaphore::new(slots)),
            download_from_cloud,
            download_filter,
        })
    }
}

pub fn build_cloud_http_clients(
    provider: CloudProvider,
    timeout: Duration,
    insecure: bool,
    proxy: Option<&str>,
) -> Result<(Client, Client)> {
    let http = build_reqwest_browser_client_with_redirect(
        provider,
        timeout,
        insecure,
        proxy,
        reqwest::redirect::Policy::limited(10),
    )?;
    let http_no_redirect = build_reqwest_browser_client_with_redirect(
        provider,
        timeout,
        insecure,
        proxy,
        reqwest::redirect::Policy::none(),
    )?;
    Ok((http, http_no_redirect))
}

pub fn build_reqwest_browser_client(
    provider: CloudProvider,
    timeout: Duration,
    insecure: bool,
    proxy: Option<&str>,
) -> Result<Client> {
    build_reqwest_browser_client_with_redirect(
        provider,
        timeout,
        insecure,
        proxy,
        reqwest::redirect::Policy::limited(10),
    )
}

fn build_reqwest_browser_client_with_redirect(
    provider: CloudProvider,
    timeout: Duration,
    insecure: bool,
    proxy: Option<&str>,
    redirect: reqwest::redirect::Policy,
) -> Result<Client> {
    let spec = provider.spec();
    let mut builder = Client::builder()
        // CloudCurlSession sends cookies manually; reqwest jar duplicates Set-Cookie values.
        .cookie_store(false)
        .redirect(redirect)
        .connect_timeout(timeout.min(Duration::from_secs(45)))
        .timeout(timeout)
        .user_agent(CHROME_UA);
    if spec.ip_stack == CloudIpStack::Ipv4Only {
        builder = builder.local_address(IpAddr::V4(Ipv4Addr::UNSPECIFIED));
    }
    if provider == CloudProvider::ZohoNotes {
        // Zoho IAM is more reliable over HTTP/1.1 from some networks/proxies than h2.
        builder = builder.http1_only();
    }
    if proxy.is_some() {
        // Fresh TCP per request reduces stale SOCKS handshakes under high thread count.
        builder = builder.pool_max_idle_per_host(0);
    } else if provider == CloudProvider::ZohoNotes {
        // Reuse connections for sign-in pipeline (HTTP/2 / keep-alive via reqwest pool).
        builder = builder.pool_max_idle_per_host(4);
    }
    if insecure {
        builder = builder.danger_accept_invalid_certs(true);
    }
    builder = apply_proxy(builder, proxy)?;
    let client = builder.build().context("cloud reqwest client")?;
    Ok(client)
}

pub fn cloud_browser_headers(provider: CloudProvider, referer: Option<&str>) -> HeaderMap {
    let spec = provider.spec();
    let mut headers = HeaderMap::new();
    headers.insert(
        ACCEPT,
        HeaderValue::from_static(
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        ),
    );
    headers.insert(
        ACCEPT_LANGUAGE,
        HeaderValue::from_static("en-US,en;q=0.9"),
    );
    // Zoho sets Origin/Referer/UA per DC in `zoho_notes` browser profile + request extras.
    if provider != CloudProvider::ZohoNotes {
        if let Ok(origin) = HeaderValue::from_str(spec.origin) {
            headers.insert(ORIGIN, origin);
        }
        if let Ok(ua) = HeaderValue::from_str(CHROME_UA) {
            headers.insert(USER_AGENT, ua);
        }
    }
    let referer_url = referer.unwrap_or(spec.origin);
    if let Ok(v) = HeaderValue::from_str(referer_url) {
        headers.insert(REFERER, v);
    }
    headers
}
