//! Multi-service cloud checkers (MEGA + Filen, MediaFire, …).

mod common;
mod config;
mod curl_http;
mod dispatch_download;
mod download;
mod providers;
mod sync_com_crypto;
mod filen_crypto;
mod internxt_crypto;

pub use common::{cloud_retryable_with_other_proxy, scan_status_for_cloud_anyhow};
pub use common::CONTENTS_DIR;

pub use config::{build_reqwest_browser_client, cloud_browser_headers, CloudClientConfig};

pub use crate::mega::{
    build_mega_http, download_mega_account, mega_is_banned_anyhow, scan_status_for_mega_anyhow,
    scan_status_for_mega_error, MegaAccountStats, MegaClientConfig, MEGA_LOGIN_CONCURRENCY,
};

pub type CloudAccountStats = MegaAccountStats;

pub(crate) type CheckStartedHook = std::sync::Arc<dyn Fn() + Send + Sync>;

pub use providers::{
    acronis, adrive, blomp, box_com, degoo, fex, file_io, filen, filesfm, four_shared, icedrive,
    internxt, koofr, mediafire, mobidrive, nimbus_notes, note_export_cloud, obsidian, onedrive, pcloud, pixeldrain,
    proton_drive, raindrop, remnote, riseup, secureshare, sync_com, terabox, toffeeshare, upnote,
    workupload, wps, zoho_notes,
};

use anyhow::{bail, Context, Result};
use pma_core::CloudProvider;
use pma_core::Credential;
use std::path::{Path, PathBuf};
use std::sync::Arc;

pub fn cloud_client_config_for_index(
    base: &CloudClientConfig,
    proxy_list: Option<&Arc<Vec<String>>>,
    index: usize,
) -> Result<Arc<CloudClientConfig>> {
    let mut proxy = base.proxy.clone();
    if let Some(list) = proxy_list {
        if !list.is_empty() {
            proxy = Some(list[index % list.len()].clone());
        }
    }
    Ok(Arc::new(base.clone_with_proxy(proxy)?))
}

pub async fn download_cloud_account(
    provider: CloudProvider,
    cred: &Credential,
    mega_config: Option<&MegaClientConfig>,
    cloud_config: Option<&CloudClientConfig>,
    output_dir: &Path,
    upload_files: bool,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    if upload_files && !provider.supports_upload() {
        bail!("upload mode is only supported for MEGA.nz");
    }
    match provider {
        CloudProvider::Mega => {
            let cfg = mega_config.context("MEGA client config")?;
            download_mega_account(cred, cfg, output_dir, upload_files, on_check_started).await
        }
        CloudProvider::Filen => {
            let cfg = cloud_config.context("cloud client config")?;
            filen::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Degoo => {
            let cfg = cloud_config.context("cloud client config")?;
            degoo::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Mediafire => {
            let cfg = cloud_config.context("cloud client config")?;
            mediafire::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::FourShared => {
            let cfg = cloud_config.context("cloud client config")?;
            four_shared::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Blomp => {
            let cfg = cloud_config.context("cloud client config")?;
            blomp::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Filesfm => {
            let cfg = cloud_config.context("cloud client config")?;
            filesfm::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Adrive => {
            let cfg = cloud_config.context("cloud client config")?;
            adrive::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Terabox => {
            let cfg = cloud_config.context("cloud client config")?;
            terabox::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::PixelDrain => {
            let cfg = cloud_config.context("cloud client config")?;
            pixeldrain::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Raindrop => {
            let cfg = cloud_config.context("cloud client config")?;
            raindrop::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::InternXt => {
            let cfg = cloud_config.context("cloud client config")?;
            internxt::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Remnote => {
            let cfg = cloud_config.context("cloud client config")?;
            remnote::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::OneDrive => {
            let cfg = cloud_config.context("cloud client config")?;
            onedrive::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Wps => {
            let cfg = cloud_config.context("cloud client config")?;
            wps::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::SyncCom => {
            let cfg = cloud_config.context("cloud client config")?;
            sync_com::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Acronis => {
            let cfg = cloud_config.context("cloud client config")?;
            acronis::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::ZohoNotes => {
            let cfg = cloud_config.context("cloud client config")?;
            zoho_notes::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Obsidian => {
            let cfg = cloud_config.context("cloud client config")?;
            obsidian::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::NimbusNotes => {
            let cfg = cloud_config.context("cloud client config")?;
            nimbus_notes::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Dynalist => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Dynalist,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Capacities => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Capacities,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Gnotes => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Gnotes,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Joplin => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Joplin,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Kortex => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Kortex,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Mindlog => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Mindlog,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Notejoy => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Notejoy,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Notesnook => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Notesnook,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::StandardNotes => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::StandardNotes,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Todoist => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Todoist,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Turtl => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Turtl,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::Zotero => {
            let cfg = cloud_config.context("cloud client config")?;
            note_export_cloud::check_account(
                pma_core::NoteExportService::Zotero,
                cfg,
                cred,
                output_dir,
                on_check_started,
            )
            .await
        }
        CloudProvider::ProtonDrive => {
            let cfg = cloud_config.context("cloud client config")?;
            proton_drive::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Koofr => {
            let cfg = cloud_config.context("cloud client config")?;
            koofr::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Upnote => {
            let cfg = cloud_config.context("cloud client config")?;
            upnote::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::BoxCom => {
            let cfg = cloud_config.context("cloud client config")?;
            box_com::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Fex => {
            let cfg = cloud_config.context("cloud client config")?;
            fex::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::FileIo => {
            let cfg = cloud_config.context("cloud client config")?;
            file_io::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Icedrive => {
            let cfg = cloud_config.context("cloud client config")?;
            icedrive::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Mobidrive => {
            let cfg = cloud_config.context("cloud client config")?;
            mobidrive::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::SecureShare => {
            let cfg = cloud_config.context("cloud client config")?;
            secureshare::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::ToffeeShare => {
            let cfg = cloud_config.context("cloud client config")?;
            toffeeshare::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Workupload => {
            let cfg = cloud_config.context("cloud client config")?;
            workupload::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Pcloud => {
            let cfg = cloud_config.context("cloud client config")?;
            pcloud::check_account(cfg, cred, output_dir, on_check_started).await
        }
        CloudProvider::Riseup => {
            let cfg = cloud_config.context("cloud client config")?;
            riseup::check_account(cfg, cred, output_dir, on_check_started).await
        }
    }
}
