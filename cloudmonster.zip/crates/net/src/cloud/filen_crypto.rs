//! Filen auth v2 password derivation (matches app / OpenBullet Node script).

use pbkdf2::pbkdf2_hmac;
use sha2::{Digest, Sha512};

const PBKDF2_ITERS: u32 = 200_000;
const DK_LEN: usize = 64;

/// Returns `(master_key_hex_64_chars, send_pwd_hex)` for `/v3/login`.
pub fn filen_derive_login_password(password: &str, salt: &str) -> (String, String) {
    let mut dk = [0u8; DK_LEN];
    pbkdf2_hmac::<Sha512>(password.as_bytes(), salt.as_bytes(), PBKDF2_ITERS, &mut dk);
    let dk_hex = hex::encode(dk);
    let master_key = dk_hex[..64].to_string();
    let second_half_hex = &dk_hex[64..];
    let send_pwd = hex::encode(Sha512::digest(second_half_hex.as_bytes()));
    (master_key, send_pwd)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn filen_derive_matches_node_pbkdf2_sha512() {
        let (_, send_pwd) = filen_derive_login_password("test", "testsalt");
        assert_eq!(
            send_pwd,
            "7e11407bf5fe57bf03d5e114ed33548c9187f11592d1befabd2f50a365c028884c17f5e4b25b1489f094dc80256881fa3236407a71bb2fa4401b21f4874c5ecf"
        );
        let (master_key, _) = filen_derive_login_password("test", "testsalt");
        assert_eq!(
            master_key,
            "ebda7fc192b821def0e96b48ec0f70bb489775ba5c89266c3b5212891c744331"
        );
    }
}
