﻿//! RemNote — Firebase email/password login (Identity Toolkit).
//! RemNote has no public server API to list all notes; on success we record login + uid.

use crate::cloud::common::{cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use regex::Regex;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

const REMNOTE_ORIGIN: &str = "https://www.remnote.com/";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        remnote_inventory(cfg, client, cred)
    })
    .await
}

async fn remnote_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let session = remnote_firebase_login(cfg, &mut curl, &email, &password).await?;
    let uid = session
        .get("localId")
        .and_then(|x| x.as_str())
        .unwrap_or("unknown");

    let marker = format!("RemNote account ({email})");
    let files = vec![CloudFileMeta::new(
        marker.clone(),
        0,
        format!("/{marker}"),
    )
    .with_remote_id(uid.to_string())];

    let mut inv = inventory_from_account(&email, files, 0, 0, "RemNote");
    inv.list_note = Some(
        "# RemNote: проверка через Firebase login. Публичного REST API для полного списка заметок нет — аккаунт Good при успешном входе.\n".to_string(),
    );
    Ok(inv)
}

async fn remnote_firebase_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<Value> {
    let key = firebase_api_key(cfg, curl).await?;
    let url = format!(
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
    );
    let body = serde_json::json!({
        "email": email,
        "password": password,
        "returnSecureToken": true,
    });
    let (status, v) = curl
        .post_json(cfg, "remnote firebase login", &url, &body, &[])
        .await
        .context("remnote firebase")?;

    if status == 200 && v.get("idToken").is_some() {
        return Ok(v);
    }

    if let Some(err) = v.get("error").and_then(|e| e.get("message")).and_then(|m| m.as_str()) {
        return Err(map_firebase_error(err));
    }
    Err(cloud_auth_error(format!(
        "remnote login failed (http {status})"
    )))
}

async fn firebase_api_key(cfg: &CloudClientConfig, curl: &mut CloudCurlSession) -> Result<String> {
    if let Ok(k) = std::env::var("REMNOTE_FIREBASE_API_KEY") {
        let k = k.trim();
        if !k.is_empty() {
            return Ok(k.to_string());
        }
    }

    static CACHED: OnceLock<String> = OnceLock::new();
    if let Some(cached) = CACHED.get() {
        return Ok(cached.clone());
    }

    let resolved = discover_firebase_api_key(cfg, curl).await?;
    let _ = CACHED.set(resolved.clone());
    Ok(resolved)
}

async fn discover_firebase_api_key(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
) -> Result<String> {
    let re = Regex::new(r"AIzaSy[A-Za-z0-9_-]{33}").context("remnote firebase key regex")?;
    let api_key_field =
        Regex::new(r#""apiKey"\s*:\s*"(AIzaSy[A-Za-z0-9_-]{33})""#).ok();
    let mut queue = vec![
        REMNOTE_ORIGIN.to_string(),
        "https://www.remnote.com/sign_in".to_string(),
        "https://auth.remnote.com/".to_string(),
    ];
    let mut seen = std::collections::HashSet::new();

    while let Some(url) = queue.pop() {
        if !seen.insert(url.clone()) {
            continue;
        }
        let Ok((status, body)) = curl
            .get_text(cfg, "remnote fetch firebase config", &url, &[], true)
            .await
        else {
            continue;
        };
        if status >= 400 {
            continue;
        }
        if let Some(k) = parse_firebase_api_key_json(&body) {
            return Ok(k);
        }
        if let Some(re_field) = &api_key_field {
            if let Some(c) = re_field.captures(&body) {
                if let Some(m) = c.get(1) {
                    return Ok(m.as_str().to_string());
                }
            }
        }
        if let Some(m) = re.find(&body) {
            return Ok(m.as_str().to_string());
        }
        for js in extract_builtin_js_paths(&body) {
            queue.push(js);
        }
        if queue.len() >= 24 {
            break;
        }
        for script in extract_script_srcs(&body) {
            let abs = absolutize_remnote_url(&url, &script);
            if abs.contains("remnote.com") && (abs.ends_with(".js") || abs.contains("/js/")) {
                queue.push(abs);
            }
        }
    }

    Err(anyhow!(
        "remnote: не удалось автоматически найти Firebase apiKey. \
         https://www.remnote.com/sign_in → F12 → Sources → Ctrl+Shift+F → apiKey (AIzaSy…), \
         либо REMNOTE_FIREBASE_API_KEY (tools/REMNOTE-FIREBASE.md)"
    ))
}

fn extract_builtin_js_paths(html: &str) -> Vec<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        Regex::new(r#"(?i)(?:href|src)\s*=\s*["'](/js/[^"']+\.js)["']"#).unwrap()
    });
    let mut out = Vec::new();
    for cap in re.captures_iter(html) {
        if let Some(m) = cap.get(1) {
            out.push(format!("https://www.remnote.com{}", m.as_str()));
        }
    }
    if let Some(start) = html.find("__builtinWebRelease") {
        let slice = &html[start..html.len().min(start + 4000)];
        static JS_RE: OnceLock<Regex> = OnceLock::new();
        let js_re = JS_RE.get_or_init(|| Regex::new(r#""(/js/[^"]+\.js)""#).unwrap());
        for cap in js_re.captures_iter(slice) {
            if let Some(m) = cap.get(1) {
                out.push(format!("https://www.remnote.com{}", m.as_str()));
            }
        }
    }
    out.sort_unstable();
    out.dedup();
    out.truncate(6);
    out
}

fn parse_firebase_api_key_json(body: &str) -> Option<String> {
    let trimmed = body.trim();
    if !trimmed.starts_with('{') {
        return None;
    }
    let v: Value = serde_json::from_str(trimmed).ok()?;
    let key = v.get("apiKey")?.as_str()?.trim();
    if key.starts_with("AIzaSy") && key.len() >= 39 {
        Some(key.to_string())
    } else {
        None
    }
}

fn extract_script_srcs(html: &str) -> Vec<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| Regex::new(r#"(?i)src\s*=\s*["']([^"']+)["']"#).unwrap());
    re.captures_iter(html)
        .filter_map(|c| c.get(1).map(|m| m.as_str().to_string()))
        .collect()
}

fn absolutize_remnote_url(page: &str, src: &str) -> String {
    if src.starts_with("http://") || src.starts_with("https://") {
        return src.to_string();
    }
    if src.starts_with("//") {
        return format!("https:{src}");
    }
    let base = page.trim_end_matches('/');
    if src.starts_with('/') {
        format!("https://www.remnote.com{src}")
    } else {
        format!("{base}/{src}")
    }
}

fn map_firebase_error(msg: &str) -> anyhow::Error {
    match msg {
        "EMAIL_NOT_FOUND" | "INVALID_PASSWORD" | "INVALID_LOGIN_CREDENTIALS" => {
            cloud_auth_error("remnote: invalid email or password")
        }
        "USER_DISABLED" => cloud_auth_error("remnote: account disabled"),
        "TOO_MANY_ATTEMPTS_TRY_LATER" => {
            crate::cloud::common::cloud_rate_limit_error("remnote: too many attempts")
        }
        other => cloud_auth_error(format!("remnote firebase: {other}")),
    }
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use crate::cloud::config::CloudClientConfig;
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use std::time::Duration;
    use url::Url;

    #[tokio::test]
    #[ignore = "local smoke: set REMNOTE_TEST_COMBO; optional REMNOTE_FIREBASE_API_KEY"]
    async fn remnote_local_smoke() {
        let path = std::env::var("REMNOTE_TEST_COMBO").expect("REMNOTE_TEST_COMBO");
        let line = std::fs::read_to_string(&path).unwrap();
        let line = line
            .lines()
            .find(|l| !l.trim().is_empty())
            .unwrap()
            .trim();
        let (user, pass) = line.split_once(':').unwrap();
        let cred = Credential {
            url: Url::parse("https://www.remnote.com/").unwrap(),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::Remnote,
            Duration::from_secs(60),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .unwrap();
        let out = std::env::temp_dir().join("remnote-smoke-out");
        check_account(&cfg, &cred, &out, None)
            .await
            .expect("check_account");
    }
}
