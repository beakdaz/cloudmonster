﻿//! Acronis Cyber Cloud — password grant on resolved data center.

use crate::cloud::common::{
    cloud_auth_error, cloud_network_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudInventory,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{body_is_non_api_response, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const ACCOUNT_LOOKUP: &str = "https://account.acronis.com/api/1/accounts";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        acronis_inventory(cfg, client, cred)
    })
    .await
}

async fn acronis_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let lookup = format!(
        "{}?login={}",
        ACCOUNT_LOOKUP,
        urlencoding_path(&email)
    );
    let (status, text) = curl
        .get_text(cfg, "acronis account lookup", &lookup, &[], true)
        .await
        .context("acronis lookup")?;
    if status >= 400 || body_is_non_api_response(&text) {
        return Err(acronis_lookup_http_error(status, &text));
    }
    let lookup_v: Value = match serde_json::from_str(text.trim()) {
        Ok(v) => v,
        Err(e) => {
            if body_is_non_api_response(&text) {
                return Err(acronis_lookup_http_error(status, &text));
            }
            return Err(e).context("acronis lookup json");
        }
    };
    let server_url = lookup_v
        .get("server_url")
        .or_else(|| lookup_v.get("serverUrl"))
        .and_then(|x| x.as_str())
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .ok_or_else(|| anyhow!("acronis: no server_url for login"))?;

    let token_url = format!("{}/api/2/idp/token", server_url.trim_end_matches('/'));
    let form = [
        ("grant_type", "password"),
        ("username", email.as_str()),
        ("password", password.as_str()),
        ("scope", "offline_access"),
    ];
    let (t_status, t_text) = curl
        .post_form(cfg, "acronis token", &token_url, &form, &[], false)
        .await
        .context("acronis token")?;

    if t_status == 401 || t_status == 403 {
        return Err(cloud_auth_error("acronis: invalid email or password"));
    }
    if t_status == 429 {
        return Err(cloud_rate_limit_error(format!("acronis token http {t_status}")));
    }
    if t_status >= 400 {
        return Err(anyhow!("acronis token http {t_status}: {}", preview(&t_text, 200)));
    }

    let token_v: Value = serde_json::from_str(&t_text).context("acronis token json")?;
    if token_v.get("access_token").and_then(|x| x.as_str()).is_none() {
        let err = token_v
            .get("error")
            .and_then(|x| x.as_str())
            .unwrap_or("token_error");
        let desc = token_v
            .get("error_description")
            .and_then(|x| x.as_str())
            .unwrap_or("");
        if err == "access_denied" || desc.contains("Invalid") || desc.contains("invalid") {
            return Err(cloud_auth_error(format!("acronis: {desc} ({err})")));
        }
        if err.contains("totp") {
            return Err(cloud_rate_limit_error(format!("acronis: 2FA required ({err})")));
        }
        return Err(cloud_auth_error(format!("acronis: {desc} ({err})")));
    }

    let mut inv = inventory_from_account(&email, Vec::new(), 0, 0, "Acronis");
    inv.list_note = Some(
        "# Acronis: вход по password grant OK. Список файлов зависит от продукта (Backup/Notary) — в combo-чекере только валидность учётки.\n".into(),
    );
    Ok(inv)
}

fn urlencoding_path(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}

fn acronis_lookup_http_error(status: u16, text: &str) -> anyhow::Error {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return cloud_network_error(format!("acronis lookup: empty body (http {status})"));
    }
    if body_is_non_api_response(trimmed) || status == 403 || status == 502 || status == 503 {
        return cloud_network_error(format!(
            "acronis lookup: blocked or non-API response (http {status}): {}",
            preview(trimmed, 120)
        ));
    }
    cloud_network_error(format!(
        "acronis lookup: http {status}: {}",
        preview(trimmed, 160)
    ))
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}
