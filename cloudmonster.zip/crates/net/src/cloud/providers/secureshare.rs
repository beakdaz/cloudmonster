﻿//! SecureShare (secureshare.co) — session cookie (`secureshare:…`); listing shares/files API.

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::Result;
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const ORIGIN: &str = "https://secureshare.co";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        secureshare_inventory(cfg, client, cred)
    })
    .await
}

async fn secureshare_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let secret = cred.password.trim();
    if !(secret.starts_with("secureshare:") || secret.starts_with("Cookie ")) {
        return Err(cloud_auth_error(
            "secureshare: пароль = `secureshare:COOKIE` из браузера после входа (2FA на сайте)",
        ));
    }

    let cookie_blob = secret
        .strip_prefix("secureshare:")
        .or_else(|| secret.strip_prefix("Cookie "))
        .unwrap_or(secret)
        .trim();
    if cookie_blob.is_empty() {
        return Err(cloud_auth_error("secureshare: пустой cookie"));
    }

    let mut curl = CloudCurlSession::new()?;
    secureshare_seed_cookies(&mut curl, cookie_blob);

    let mut files = Vec::new();
    let list_urls = [
        format!("{ORIGIN}/api/files"),
        format!("{ORIGIN}/api/v1/files"),
        format!("{ORIGIN}/api/shares"),
        format!("{ORIGIN}/api/user/files"),
        format!("{ORIGIN}/api/user/shares"),
        format!("{ORIGIN}/dashboard/api/files"),
    ];
    let refs = [("Referer", ORIGIN), ("Origin", ORIGIN)];
    for url in &list_urls {
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let Ok((status, body)) = curl
            .get_text(cfg, "secureshare list", url, &refs, true)
            .await
        else {
            continue;
        };
        if status == 401 || status == 403 {
            return Err(cloud_auth_error("secureshare: cookie недействителен или истёк"));
        }
        if status >= 400 {
            continue;
        }
        secureshare_collect_json_files(&body, &mut files);
    }

    if files.is_empty() {
        let (me_st, me_body) = curl
            .get_text(
                cfg,
                "secureshare me",
                &format!("{ORIGIN}/api/user"),
                &refs,
                true,
            )
            .await
            .unwrap_or((0, String::new()));
        if me_st == 401 || me_st == 403 {
            return Err(cloud_auth_error("secureshare: cookie недействителен"));
        }
        if me_st >= 200 && me_st < 300 && !me_body.trim().is_empty() {
            secureshare_collect_json_files(&me_body, &mut files);
        }
    }

    let mut inv = inventory_from_account(&email, files, 0, 0, "SecureShare");
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# SecureShare: cookie принят; API листинга пуст или другой формат — проверьте shares в браузере\n"
                .into(),
        );
    }
    Ok(inv)
}

fn secureshare_seed_cookies(curl: &mut CloudCurlSession, raw: &str) {
    for part in raw.split(';') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        let Some((name, value)) = part.split_once('=') else {
            continue;
        };
        let name = name.trim();
        let value = value.trim();
        if !name.is_empty() {
            curl.seed_cookie(name, value);
        }
    }
}

fn secureshare_collect_json_files(body: &str, out: &mut Vec<CloudFileMeta>) {
    let trimmed = body.trim();
    if trimmed.is_empty() || !trimmed.starts_with('{') && !trimmed.starts_with('[') {
        return;
    }
    let Ok(v) = serde_json::from_str::<Value>(trimmed) else {
        return;
    };
    if let Some(arr) = v.as_array() {
        for item in arr {
            secureshare_push_file_item(item, out);
        }
        return;
    }
    for key in ["files", "shares", "data", "items", "results"] {
        let Some(arr) = v.get(key).and_then(|x| x.as_array()) else {
            continue;
        };
        for item in arr {
            secureshare_push_file_item(item, out);
        }
    }
}

fn secureshare_push_file_item(item: &Value, out: &mut Vec<CloudFileMeta>) {
    if out.len() >= MAX_CLOUD_LIST_LINES {
        return;
    }
    let name = item
        .get("name")
        .or_else(|| item.get("filename"))
        .or_else(|| item.get("title"))
        .or_else(|| item.get("label"))
        .and_then(|x| x.as_str())
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .unwrap_or("share");
    let size = item
        .get("size")
        .or_else(|| item.get("bytes"))
        .and_then(|x| x.as_u64().or_else(|| x.as_str()?.parse().ok()))
        .unwrap_or(0);
    let id = item
        .get("id")
        .or_else(|| item.get("shareId"))
        .and_then(|x| x.as_str())
        .unwrap_or("");
    let path = if id.is_empty() {
        name.to_string()
    } else {
        format!("{id}/{name}")
    };
    let mut meta = CloudFileMeta::new(name, size, path);
    if !id.is_empty() {
        meta = meta.with_remote_id(id);
    }
    out.push(meta);
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn secureshare_parses_files_array() {
        let body = r#"{"files":[{"id":"1","name":"report.pdf","size":1024}]}"#;
        let mut v = Vec::new();
        secureshare_collect_json_files(body, &mut v);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "report.pdf");
    }
}
