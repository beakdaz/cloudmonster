//! Riseup — account portal (account.riseup.net) + Roundcube webmail (mail.riseup.net/rc/).

use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use regex::Regex;
use reqwest::Client;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;

const ACCOUNT_LOGIN_PAGE: &str = "https://account.riseup.net/session/new";
const ACCOUNT_POST: &str = "https://account.riseup.net/session";
const MAIL_LOGIN_PAGE: &str = "https://mail.riseup.net/rc/?_task=login";
const MAIL_POST: &str = "https://mail.riseup.net/rc/";

static CSRF_META_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)name="csrf-token"\s+content="([^"]+)""#).expect("csrf meta re")
});

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        riseup_inventory(cfg, client, cred)
    })
    .await
}

async fn riseup_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let (account_user, mail_user) = riseup_users(&cred.username);
    let password = cred.password.clone();
    if account_user.is_empty() || password.is_empty() {
        return Err(cloud_auth_error("missing username or password"));
    }

    let mut curl = CloudCurlSession::new()?;

    if riseup_account_login(cfg, &mut curl, &account_user, &password)
        .await
        .is_ok()
    {
        return Ok(riseup_inventory_ok(&mail_user));
    }

    riseup_roundcube_login(cfg, &mut curl, &mail_user, &password).await?;
    Ok(riseup_inventory_ok(&mail_user))
}

fn riseup_users(raw: &str) -> (String, String) {
    let raw = raw.trim();
    if raw.is_empty() {
        return (String::new(), String::new());
    }
    if let Some((local, _)) = raw.split_once('@') {
        return (local.to_string(), raw.to_string());
    }
    (raw.to_string(), format!("{raw}@riseup.net"))
}

fn riseup_inventory_ok(mail_user: &str) -> CloudInventory {
    let files = vec![CloudFileMeta::new("INBOX", 0, "webmail")];
    inventory_from_account(mail_user, files, 0, 0, "Riseup")
}

async fn riseup_account_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    username: &str,
    password: &str,
) -> Result<()> {
    let (status, html) = curl
        .get_text(cfg, "riseup account login page", ACCOUNT_LOGIN_PAGE, &[], false)
        .await
        .context("riseup account GET")?;
    if status >= 500 {
        return Err(anyhow!("riseup account page HTTP {status}"));
    }
    if status == 429 {
        return Err(cloud_rate_limit_error("riseup account HTTP 429"));
    }

    let token = extract_input_value(&html, "authenticity_token")
        .or_else(|| extract_csrf_meta(&html))
        .ok_or_else(|| cloud_auth_error("riseup account: missing CSRF token"))?;

    let form = [
        ("utf8", "✓"),
        ("authenticity_token", token.as_str()),
        ("username", username),
        ("password", password),
    ];
    let referer = [("Referer", ACCOUNT_LOGIN_PAGE)];
    let (post_status, body) = curl
        .post_form(cfg, "riseup account POST", ACCOUNT_POST, &form, &referer, true)
        .await
        .context("riseup account POST")?;

    if post_status == 429 {
        return Err(cloud_rate_limit_error("riseup account HTTP 429"));
    }

    let blob = body.to_lowercase();
    if contains_any(&blob, &[
        "invalid login",
        "invalid username",
        "invalid password",
        "incorrect",
        "doesn't match",
        "does not match",
        "wrong password",
        "login failed",
    ]) {
        return Err(cloud_auth_error("invalid username or password"));
    }
    if contains_any(&blob, &["two_factor", "2fa", "otp", "verification_code"]) {
        return Err(cloud_auth_error("riseup: 2FA required"));
    }

    if riseup_account_success(&blob, post_status) {
        return Ok(());
    }

    // Session cookie may be set even when body is minimal — probe account home.
    let (probe_status, probe_body) = curl
        .get_text(
            cfg,
            "riseup account probe",
            "https://account.riseup.net/",
            &[],
            true,
        )
        .await
        .unwrap_or((500, String::new()));
    let probe = probe_body.to_lowercase();
    if probe_status == 429 {
        return Err(cloud_rate_limit_error("riseup account probe HTTP 429"));
    }
    if riseup_account_success(&probe, probe_status) {
        return Ok(());
    }

    Err(cloud_auth_error("riseup account login failed"))
}

fn riseup_account_success(blob: &str, status: u16) -> bool {
    if contains_any(blob, &[
        "session/new",
        "name=\"username\"",
        "log in",
        "riseup red log in",
    ]) && !contains_any(blob, &["logout", "sign out", "log out"])
    {
        return false;
    }
    contains_any(blob, &[
        "logout",
        "log out",
        "sign out",
        "account settings",
        "change your user account",
        "/users/",
    ]) || (status >= 200 && status < 400 && !blob.contains("session/new"))
}

async fn riseup_roundcube_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<()> {
    let (status, html) = curl
        .get_text(cfg, "riseup mail login page", MAIL_LOGIN_PAGE, &[], false)
        .await
        .context("riseup mail GET")?;
    if status >= 500 {
        return Err(anyhow!("riseup mail login page HTTP {status}"));
    }

    let token = extract_input_value(&html, "_token").unwrap_or_default();
    let task = extract_input_value(&html, "_task").unwrap_or_else(|| "login".into());

    let mut form: Vec<(&str, &str)> = vec![
        ("_task", task.as_str()),
        ("_action", "login"),
        ("_timezone", "_default_"),
        ("_user", email),
        ("_pass", password),
    ];
    if !token.is_empty() {
        form.push(("_token", token.as_str()));
    }

    let referer = [("Referer", MAIL_LOGIN_PAGE)];
    let (post_status, body) = curl
        .post_form(cfg, "riseup mail POST", MAIL_POST, &form, &referer, true)
        .await
        .context("riseup mail POST")?;

    let blob = body.to_lowercase();
    if post_status == 429 {
        return Err(cloud_rate_limit_error("riseup HTTP 429"));
    }
    if contains_any(&blob, &[
        "login failed",
        "invalid credentials",
        "logineerrormessage",
        "wrong_login",
        "login_denied",
        "invalid username or password",
    ]) {
        return Err(cloud_auth_error("invalid username or password"));
    }
    if contains_any(&blob, &["two_factor", "2fa", "otp", "verification_code"]) {
        return Err(cloud_auth_error("riseup: 2FA required"));
    }

    let ok = contains_any(&blob, &[
        "rcmcontent",
        "mailboxlist",
        "messagelist",
        "_task=mail",
        "_action=logout",
    ]);

    if !ok && post_status >= 400 {
        return Err(cloud_auth_error(format!("riseup mail login HTTP {post_status}")));
    }
    if !ok {
        return Err(cloud_auth_error("riseup mail login failed"));
    }
    Ok(())
}

fn extract_csrf_meta(html: &str) -> Option<String> {
    CSRF_META_RE
        .captures(html)
        .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
}

fn extract_input_value(html: &str, name: &str) -> Option<String> {
    let pat1 = format!(r#"name="{name}"[^>]*value="([^"]*)""#);
    if let Ok(re) = Regex::new(&pat1) {
        if let Some(c) = re.captures(html) {
            return c.get(1).map(|m| m.as_str().to_string());
        }
    }
    let pat2 = format!(r#"value="([^"]*)"[^>]*name="{name}""#);
    if let Ok(re) = Regex::new(&pat2) {
        if let Some(c) = re.captures(html) {
            return c.get(1).map(|m| m.as_str().to_string());
        }
    }
    None
}

fn contains_any(haystack: &str, needles: &[&str]) -> bool {
    needles.iter().any(|n| haystack.contains(n))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn riseup_user_parsing() {
        assert_eq!(
            riseup_users("fscheck"),
            ("fscheck".into(), "fscheck@riseup.net".into())
        );
        assert_eq!(
            riseup_users("fscheck@riseup.net"),
            ("fscheck".into(), "fscheck@riseup.net".into())
        );
    }

    #[test]
    fn parses_hidden_input() {
        let html = r#"<input type="hidden" name="_token" value="abc123" />"#;
        assert_eq!(extract_input_value(html, "_token").as_deref(), Some("abc123"));
    }

    #[test]
    fn parses_csrf_meta() {
        let html = r#"<meta name="csrf-token" content="tok123" />"#;
        assert_eq!(extract_csrf_meta(html).as_deref(), Some("tok123"));
    }
}
