# Cloud providers (CloudMonster)

Один Rust-модуль на сервис. Точка входа: `pub async fn check_account(...)`.

Общая логика: `../common.rs` (`run_checker`, inventory, Good/Bad).  
Маршрутизация: `../mod.rs` → `download_cloud_account`.

Статус и форматы combo: [`docs/CLOUD_MODULES.ru.md`](../../../../../../docs/CLOUD_MODULES.ru.md).  
Ссылки SDK/API для разбора: [`tools/CLOUD-API-RESEARCH.md`](../../../../../../tools/CLOUD-API-RESEARCH.md).  
Черновики OpenBullet (`.loli`): [`tools/lolicfg/`](../../../../../../tools/lolicfg/) — по одному на сервис, шаблон как `mediafire.loli`.
