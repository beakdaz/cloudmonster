﻿//! Koofr — web session login + mount file listing (app.koofr.com).

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::{json, Value};
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const KOOFR_ORIGIN: &str = "https://app.koofr.com";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        koofr_inventory(cfg, client, cred)
    })
    .await
}

async fn koofr_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.trim().to_string();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let _ = curl
        .get_text(
            cfg,
            "koofr login page",
            &format!("{KOOFR_ORIGIN}/login"),
            &[("Referer", KOOFR_ORIGIN)],
            true,
        )
        .await;

    let (status, auth) = curl
        .post_json(
            cfg,
            "koofr authenticate",
            &format!("{KOOFR_ORIGIN}/app/login/authenticate"),
            &json!({
                "username": email,
                "password": password,
            }),
            &[("Referer", &format!("{KOOFR_ORIGIN}/login"))],
        )
        .await
        .context("koofr authenticate")?;

    if status == 401 || status == 403 {
        return Err(cloud_auth_error("koofr: invalid email or password"));
    }
    if status >= 400 {
        return Err(anyhow!("koofr authenticate http {status}"));
    }
    if auth.get("error").is_some() || auth.get("success").and_then(|x| x.as_bool()) == Some(false) {
        return Err(cloud_auth_error("koofr: login failed"));
    }

    let mounts = koofr_mounts(cfg, &mut curl).await?;
    let (used, total) = koofr_quota(&mounts);
    let mut files = Vec::new();
    for mount in &mounts {
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let mount_id = mount
            .get("id")
            .or_else(|| mount.get("mountId"))
            .and_then(|x| x.as_str())
            .unwrap_or("");
        if mount_id.is_empty() {
            continue;
        }
        koofr_walk_mount(cfg, &mut curl, mount_id, "", &mut files).await?;
    }

    let mut inv = inventory_from_account(&email, files, used, total, "Koofr");
    if inv.file_count == 0 && mounts.is_empty() {
        inv.list_note = Some("# Koofr: login OK, но listing пуст (mount API).\n".into());
    }
    Ok(inv)
}

async fn koofr_mounts(cfg: &CloudClientConfig, curl: &mut CloudCurlSession) -> Result<Vec<Value>> {
    for path in [
        "/api/v2/storage/mounts",
        "/api/v2/files/mounts",
        "/api/v2/mounts",
    ] {
        let url = format!("{KOOFR_ORIGIN}{path}");
        let Ok(v) = curl
            .get_json(cfg, "koofr mounts", &url, &[("Referer", KOOFR_ORIGIN)])
            .await
        else {
            continue;
        };
        if let Some(arr) = v.as_array() {
            return Ok(arr.clone());
        }
        if let Some(arr) = v.get("mounts").and_then(|x| x.as_array()) {
            return Ok(arr.clone());
        }
    }
    Ok(Vec::new())
}

async fn koofr_walk_mount(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    mount_id: &str,
    prefix: &str,
    out: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let mut queue: VecDeque<(String, String)> = VecDeque::from([(String::new(), prefix.to_string())]);
    while let Some((path, label_prefix)) = queue.pop_front() {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let url = format!(
            "{KOOFR_ORIGIN}/api/v2/files/list?mountId={}&path={}",
            urlencoding_path(mount_id),
            urlencoding_path(&path)
        );
        let Ok(v) = curl
            .get_json(cfg, "koofr list", &url, &[("Referer", KOOFR_ORIGIN)])
            .await
        else {
            continue;
        };
        let items = v
            .get("files")
            .or_else(|| v.get("items"))
            .and_then(|x| x.as_array())
            .cloned()
            .unwrap_or_default();
        for item in items {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = item
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let is_dir = item.get("type").and_then(|x| x.as_str()) == Some("dir")
                || item.get("dir").and_then(|x| x.as_bool()) == Some(true);
            let full = if label_prefix.is_empty() {
                name.to_string()
            } else {
                format!("{label_prefix}/{name}")
            };
            if is_dir {
                let sub = item
                    .get("path")
                    .and_then(|x| x.as_str())
                    .map(str::to_string)
                    .unwrap_or_else(|| {
                        if path.is_empty() {
                            name.to_string()
                        } else {
                            format!("{path}/{name}")
                        }
                    });
                queue.push_back((sub, full));
                continue;
            }
            let size = item
                .get("size")
                .and_then(parse_u64_json)
                .unwrap_or(0);
            out.push(CloudFileMeta::new(name, size, full));
        }
    }
    Ok(())
}

fn koofr_quota(mounts: &[Value]) -> (u64, u64) {
    let mut used = 0u64;
    let mut total = 0u64;
    for m in mounts {
        used += m.get("used").and_then(parse_u64_json).unwrap_or(0);
        total += m
            .get("total")
            .or_else(|| m.get("quota"))
            .and_then(parse_u64_json)
            .unwrap_or(0);
    }
    (used, total)
}

fn parse_u64_json(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().map(|n| n.max(0) as u64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn urlencoding_path(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}
