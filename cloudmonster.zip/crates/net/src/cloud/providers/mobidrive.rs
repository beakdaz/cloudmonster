﻿//! MobiDrive — `connect.mobisystems.com` API (session tokens from browser).
//!
//! Combo `email:password` is **not** supported (reCAPTCHA on accounts.mobisystems.com).
//! Use exported session:
//! - `email:mobidrive:ACCOUNT_ID:CONNECT_TOKEN` (`msConnectToken` + numeric account id from mobidrive.com)
//! - `email:mobidrive:jwt:JWT` (`jwt` from localStorage on accounts / mobidrive)

use crate::cloud::common::{
    cloud_auth_error, cloud_format_error, cloud_network_error, inventory_from_account, run_checker,
    CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};

const CONNECT_API: &str = "https://connect.mobisystems.com/api";
const ACCOUNTS_API: &str = "https://accounts.mobisystems.com/api";
const MOBI_APP: &str = "com.mobisystems.web.mobidrive";
const MOBI_CLV: &str = "2.16.0";
const MOBI_PUSH: &str = "web";
const MOBI_LANG: &str = "en";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        mobidrive_inventory(cfg, client, cred)
    })
    .await
}

struct MobiSession {
    account_id: String,
    connect_token: String,
}

async fn mobidrive_inventory(
    cfg: &CloudClientConfig,
    client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let session = resolve_session(cfg, client, cred.password.trim()).await?;
    let mut curl = CloudCurlSession::new()?;

    let (used, quota, tariff) = mobi_storage(cfg, &mut curl, &session).await?;
    let files = mobi_list_my_files(cfg, &mut curl, &session).await?;

    let mut inv = inventory_from_account(&email, files, used, quota, tariff);
    inv.session_secret = Some(format!("{}:{}", session.account_id, session.connect_token));
    Ok(inv)
}

async fn resolve_session(
    cfg: &CloudClientConfig,
    client: Client,
    secret: &str,
) -> Result<MobiSession> {
    if let Some(rest) = secret.strip_prefix("mobidrive:") {
        if let Some(jwt) = rest.strip_prefix("jwt:") {
            let jwt = jwt.trim();
            if jwt.is_empty() {
                return Err(cloud_auth_error("mobidrive: пустой jwt"));
            }
            return mobi_session_from_jwt(cfg, client, jwt).await;
        }
        return parse_connect_combo(rest);
    }

    Err(cloud_format_error(
        "mobidrive: обычный email:password не поддерживается (reCAPTCHA на accounts.mobisystems.com). \
         В combo поле пароля: `mobidrive:ACCOUNT_ID:CONNECT_TOKEN` или `mobidrive:jwt:JWT` (localStorage mobidrive.com)",
    ))
}

fn parse_connect_combo(rest: &str) -> Result<MobiSession> {
    let rest = rest.trim();
    if rest.is_empty() {
        return Err(cloud_auth_error(
            "mobidrive: укажите `mobidrive:ACCOUNT_ID:CONNECT_TOKEN` или `mobidrive:jwt:…`",
        ));
    }
    let Some((account_id, token)) = rest.split_once(':') else {
        return Err(cloud_auth_error(
            "mobidrive: устаревший формат `mobidrive:TOKEN` — нужны account id и connect token: \
             `mobidrive:ACCOUNT_ID:CONNECT_TOKEN`",
        ));
    };
    let account_id = account_id.trim();
    let token = token.trim();
    if account_id.is_empty() || token.is_empty() {
        return Err(cloud_auth_error("mobidrive: пустой account id или connect token"));
    }
    Ok(MobiSession {
        account_id: account_id.to_string(),
        connect_token: token.to_string(),
    })
}

async fn mobi_session_from_jwt(
    cfg: &CloudClientConfig,
    client: Client,
    jwt: &str,
) -> Result<MobiSession> {
    let url = format!("{ACCOUNTS_API}/account-info");
    let resp = client
        .get(&url)
        .header("Authorization", format!("Bearer {jwt}"))
        .header("Accept", "application/json")
        .timeout(cfg.timeout)
        .send()
        .await
        .context("mobidrive account-info")?;
    let status = resp.status();
    let text = resp.text().await.context("mobidrive account-info body")?;
    if status.as_u16() == 401 || status.as_u16() == 403 {
        return Err(cloud_auth_error("mobidrive: jwt недействителен или истёк"));
    }
    if !status.is_success() {
        return Err(cloud_network_error(format!(
            "mobidrive account-info http {} — {}",
            status.as_u16(),
            preview(&text, 120)
        )));
    }
    let v: Value = serde_json::from_str(&text).context("mobidrive account-info json")?;
    let account_id = v
        .get("accountId")
        .or_else(|| v.get("account_id"))
        .and_then(|x| {
            x.as_str()
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .map(str::to_string)
                .or_else(|| x.as_i64().map(|n| n.to_string()))
        })
        .filter(|s| !s.is_empty())
        .ok_or_else(|| cloud_auth_error("mobidrive: account-info без accountId"))?;
    let accounts_token = v
        .get("token")
        .or_else(|| v.get("accountsToken"))
        .and_then(|x| x.as_str())
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .ok_or_else(|| cloud_auth_error("mobidrive: account-info без accounts token"))?;

    let mut curl = CloudCurlSession::new()?;
    let xcode = mobi_connect_form(
        cfg,
        &mut curl,
        "mobidrive issue-xchange",
        &account_id,
        accounts_token,
        &[
            ("path", "profile"),
            ("command", "issue-xchange-code"),
            ("account", &json_string(&account_id)),
            ("tkn", &json_string(accounts_token)),
        ],
    )
    .await?;
    let xcode_str = xcode
        .as_str()
        .map(str::to_string)
        .or_else(|| xcode.get("code").and_then(|c| c.as_str()).map(str::to_string))
        .filter(|s| !s.is_empty())
        .ok_or_else(|| cloud_auth_error("mobidrive: issue-xchange-code без кода"))?;

    let signed = mobi_connect_form(
        cfg,
        &mut curl,
        "mobidrive sign-in-xchange",
        &account_id,
        accounts_token,
        &[
            ("path", "auth"),
            ("command", "sign-in-by-xchange-code"),
            ("account", &json_string(&account_id)),
            ("tkn", &json_string(accounts_token)),
            ("xchangeCode", &json_string(&xcode_str)),
        ],
    )
    .await?;
    let connect_token = signed
        .get("token")
        .and_then(|t| t.as_str())
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .ok_or_else(|| cloud_auth_error("mobidrive: sign-in-by-xchange-code без connect token"))?;

    Ok(MobiSession {
        account_id,
        connect_token: connect_token.to_string(),
    })
}

async fn mobi_storage(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &MobiSession,
) -> Result<(u64, u64, String)> {
    let v = mobi_connect_form(
        cfg,
        curl,
        "mobidrive storage",
        &session.account_id,
        &session.connect_token,
        &[
            ("path", "files"),
            ("command", "storage"),
            ("account", &json_string(&session.account_id)),
            ("tkn", &json_string(&session.connect_token)),
        ],
    )
    .await?;
    let used = v.get("size").and_then(json_u64).unwrap_or(0);
    let quota = v.get("maximum").and_then(json_u64).unwrap_or(20 * 1024 * 1024 * 1024);
    let tariff = if quota > 50 * 1024 * 1024 * 1024 {
        "Paid"
    } else {
        "Free"
    };
    Ok((used, quota, tariff.to_string()))
}

async fn mobi_list_my_files(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &MobiSession,
) -> Result<Vec<CloudFileMeta>> {
    let mut out = Vec::new();
    let mut cursor: Option<String> = None;
    loop {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let request = json!({
            "root": {
                "account": session.account_id,
                "parent": null,
                "name": null,
                "key": null
            },
            "filter": null,
            "options": {
                "cursor": cursor,
                "size": 200,
                "order": null
            },
            "sortOrder": { "sort": "name", "direction": "asc" },
            "dirPosition": "dirsOnTop",
            "type": "flat",
            "dirsOrFiles": "both"
        });
        let request_str = serde_json::to_string(&request).context("mobidrive search json")?;
        let page = mobi_connect_form(
            cfg,
            curl,
            "mobidrive search-adv",
            &session.account_id,
            &session.connect_token,
            &[
                ("path", "files"),
                ("command", "search-adv"),
                ("request", &request_str),
            ],
        )
        .await?;

        if let Some(code) = page.get("code").and_then(|c| c.as_i64()) {
            if code != 0 {
                let msg = page
                    .get("error")
                    .and_then(|e| e.as_str())
                    .unwrap_or("connect error");
                if code == 401 || msg.contains("auth") {
                    return Err(cloud_auth_error(format!(
                        "mobidrive: connect token недействителен ({msg})"
                    )));
                }
                return Err(cloud_network_error(format!("mobidrive search-adv: {msg} (code {code})")));
            }
        }

        let items = page
            .get("items")
            .and_then(|i| i.as_array())
            .cloned()
            .unwrap_or_default();
        for item in &items {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = item
                .get("name")
                .and_then(|n| n.as_str())
                .unwrap_or("")
                .trim();
            if name.is_empty() {
                continue;
            }
            let is_dir = item.get("dir").and_then(|d| d.as_bool()).unwrap_or(false)
                || item.get("folder").and_then(|d| d.as_bool()).unwrap_or(false);
            if is_dir {
                continue;
            }
            let size = item.get("size").and_then(json_u64).unwrap_or(0);
            let key = item
                .get("key")
                .and_then(|k| k.as_str())
                .unwrap_or("")
                .to_string();
            let path = if key.is_empty() {
                name.to_string()
            } else {
                format!("{key}/{name}")
            };
            out.push(CloudFileMeta::new(name, size, path).with_remote_id(key));
        }

        cursor = page
            .get("cursor")
            .and_then(|c| c.as_str())
            .map(str::to_string)
            .filter(|s| !s.is_empty());
        if cursor.is_none() || items.is_empty() {
            break;
        }
    }
    Ok(out)
}

async fn mobi_connect_form(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ctx: &str,
    account_id: &str,
    connect_token: &str,
    fields: &[(&str, &str)],
) -> Result<Value> {
    let extra = [
        ("Referer", "https://mobidrive.com/"),
        ("Origin", "https://mobidrive.com"),
        ("account", account_id),
        ("tkn", connect_token),
        ("lang", MOBI_LANG),
        ("app", MOBI_APP),
        ("clv", MOBI_CLV),
        ("pushtkn", MOBI_PUSH),
    ];
    let (status, text) = curl
        .post_form(cfg, ctx, CONNECT_API, fields, &extra, false)
        .await
        .with_context(|| format!("{ctx} http"))?;
    if status == 401 || status == 403 {
        return Err(cloud_auth_error(format!("mobidrive: http {status} — session")));
    }
    if status >= 400 {
        return Err(cloud_network_error(format!(
            "mobidrive: http {status} — {}",
            preview(&text, 160)
        )));
    }
    parse_connect_envelope(&text).with_context(|| format!("{ctx} parse"))
}

fn parse_connect_envelope(text: &str) -> Result<Value> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Err(anyhow!("empty connect response"));
    }
    let root: Value = serde_json::from_str(trimmed).context("connect json")?;
    if let Some(data) = root.get("data") {
        if let Some(result) = data.get("result") {
            if let Some(s) = result.as_str() {
                return serde_json::from_str(s).context("connect result json");
            }
            return Ok(result.clone());
        }
        if let Some(code) = data.get("code") {
            let code_val: Value = if let Some(s) = code.as_str() {
                serde_json::from_str(s).unwrap_or_else(|_| json!(s))
            } else {
                code.clone()
            };
            if let Some(obj) = code_val.as_object() {
                return Ok(Value::Object(obj.clone()));
            }
            return Ok(code_val);
        }
    }
    Ok(root)
}

fn json_string(s: &str) -> String {
    serde_json::to_string(s).unwrap_or_else(|_| format!("\"{s}\""))
}

fn json_u64(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().and_then(|n| u64::try_from(n).ok()))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn parse_connect_combo_splits_account_and_token() {
        let s = parse_connect_combo("12345:abc:def:token").unwrap();
        assert_eq!(s.account_id, "12345");
        assert_eq!(s.connect_token, "abc:def:token");
    }

    #[test]
    fn parse_connect_envelope_result_string() {
        let body = r#"{"data":{"result":"{\"items\":[],\"cursor\":null}"}}"#;
        let v = parse_connect_envelope(body).unwrap();
        assert!(v.get("items").is_some());
    }

    #[test]
    fn plain_password_is_not_combo_prefix() {
        assert!(resolve_session_blocking("secret").is_err());
    }

    fn resolve_session_blocking(secret: &str) -> Result<MobiSession> {
        if secret.strip_prefix("mobidrive:").is_some() {
            return parse_connect_combo(secret.strip_prefix("mobidrive:").unwrap());
        }
        Err(cloud_auth_error("nope"))
    }
}
