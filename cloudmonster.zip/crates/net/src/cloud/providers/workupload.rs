﻿//! WorkUpload — PoW captcha + `/auth` mailpass, or `workupload:COOKIE` session combo.

use crate::cloud::common::{
    cloud_auth_error, cloud_network_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{header_pairs, parse_json_text, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::path::{Path, PathBuf};

const ORIGIN: &str = "https://workupload.com";
const LOGIN_URL: &str = "https://workupload.com/login";
const PUZZLE_URL: &str = "https://workupload.com/puzzle";
const CAPTCHA_URL: &str = "https://workupload.com/captcha";
const AUTH_URL: &str = "https://workupload.com/auth";

const WORKUPLOAD_LIST_PATHS: &[&str] = &[
    "/api/user/files",
    "/api/files",
    "/api/file/list",
    "/api/user/file/list",
];

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        workupload_inventory(cfg, client, cred)
    })
    .await
}

async fn workupload_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let secret = cred.password.trim();

    if let Some(cookie) = secret.strip_prefix("workupload:") {
        return workupload_inventory_with_cookie(cfg, &email, cookie.trim()).await;
    }

    let password = secret.to_string();
    let mut curl = CloudCurlSession::new()?;
    workupload_ensure_captcha_passed(cfg, &mut curl).await?;
    workupload_auth_mailpass(cfg, &mut curl, &email, &password).await?;
    let token = curl
        .cookie_value("token")
        .map(|s| s.to_string())
        .filter(|s| !s.is_empty())
        .ok_or_else(|| {
            cloud_auth_error("workupload: login OK, но нет cookie token — повторите или workupload:COOKIE")
        })?;
    workupload_inventory_with_cookie(cfg, &email, &token).await
}

fn workupload_page_is_human_gate(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("are you a human")
        || lower.contains("checking that you are not a robot")
        || lower.contains("security check")
}

fn workupload_sha256_hex(input: &str) -> String {
    hex::encode(Sha256::digest(input.as_bytes()))
}

fn workupload_solve_puzzle(puzzle: &str, find: &[String], range: u32) -> Option<String> {
    let mut hits = Vec::new();
    for i in 0..range {
        let digest = workupload_sha256_hex(&format!("{puzzle}{i}"));
        if find.iter().any(|want| want.eq_ignore_ascii_case(&digest)) {
            hits.push(i.to_string());
            if hits.len() == find.len() {
                break;
            }
        }
    }
    if hits.len() == find.len() {
        Some(format!("{} ", hits.join(" ")))
    } else {
        None
    }
}

async fn workupload_ensure_captcha_passed(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
) -> Result<()> {
    let refs = header_pairs(cfg, &[("Referer", LOGIN_URL)]);
    let refs: Vec<(&str, &str)> = refs.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
    let (_st, login_html) = curl
        .get_text(cfg, "workupload login page", LOGIN_URL, &refs, true)
        .await
        .context("workupload login page")?;

    if !workupload_page_is_human_gate(&login_html) {
        return Ok(());
    }

    let puzzle_v = curl
        .get_json(cfg, "workupload puzzle", PUZZLE_URL, &[("Referer", LOGIN_URL)])
        .await
        .context("workupload puzzle")?;
    let data = puzzle_v.get("data").context("workupload puzzle data")?;
    let puzzle = data
        .get("puzzle")
        .and_then(|x| x.as_str())
        .context("workupload puzzle string")?;
    let range = data
        .get("range")
        .and_then(|x| x.as_u64())
        .unwrap_or(10_000) as u32;
    let find_arr = data
        .get("find")
        .and_then(|x| x.as_array())
        .context("workupload puzzle find")?;
    let mut find = Vec::new();
    for item in find_arr {
        if let Some(s) = item.as_str() {
            find.push(s.to_string());
        }
    }
    if find.is_empty() {
        return Err(anyhow!("workupload puzzle find empty"));
    }

    let captcha = workupload_solve_puzzle(puzzle, &find, range).ok_or_else(|| {
        cloud_rate_limit_error("workupload: не удалось решить PoW captcha (puzzle)")
    })?;

    let post_refs = header_pairs(
        cfg,
        &[
            ("Referer", LOGIN_URL),
            ("Origin", ORIGIN),
        ],
    );
    let post_refs: Vec<(&str, &str)> = post_refs
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    curl.post_form(
        cfg,
        "workupload captcha",
        CAPTCHA_URL,
        &[("captcha", captcha.as_str())],
        &post_refs,
        false,
    )
    .await
    .context("workupload captcha post")?;

    let (_st2, login2) = curl
        .get_text(cfg, "workupload login after captcha", LOGIN_URL, &refs, true)
        .await
        .context("workupload login after captcha")?;
    if workupload_page_is_human_gate(&login2) {
        return Err(cloud_rate_limit_error(
            "workupload: captcha не принята — Direct, Threads 1–5, retry",
        ));
    }
    Ok(())
}

async fn workupload_auth_mailpass(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<()> {
    let headers = header_pairs(
        cfg,
        &[
            ("Referer", LOGIN_URL),
            ("Origin", ORIGIN),
        ],
    );
    let refs: Vec<(&str, &str)> = headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let (_st, body) = curl
        .post_form(
            cfg,
            "workupload auth",
            AUTH_URL,
            &[
                ("_target_path", "/member"),
                ("_username", email),
                ("_password", password),
            ],
            &refs,
            true,
        )
        .await
        .context("workupload auth")?;

    let lower = body.to_ascii_lowercase();
    if lower.contains("invalid credentials") {
        return Err(cloud_auth_error("workupload: invalid email or password"));
    }
    if lower.contains("are you a human") || lower.contains("security check") {
        return Err(cloud_rate_limit_error(
            "workupload: captcha снова после login — снизьте потоки",
        ));
    }
    if curl.cookie_value("token").is_none() && !lower.contains("/member") {
        return Err(cloud_network_error(format!(
            "workupload: неожиданный ответ login (preview: {})",
            body.chars().take(120).collect::<String>()
        )));
    }
    Ok(())
}

async fn workupload_inventory_with_cookie(
    cfg: &CloudClientConfig,
    email: &str,
    cookie_secret: &str,
) -> Result<CloudInventory> {
    let cookie_hdr = workupload_cookie_header(cookie_secret);
    let mut curl = CloudCurlSession::new()?;
    let mut files = Vec::new();
    let mut last_note = String::new();

    for path in WORKUPLOAD_LIST_PATHS {
        let url = format!("{ORIGIN}{path}");
        let Ok((status, text)) = curl
            .get_text(
                cfg,
                "workupload list",
                &url,
                &[("Cookie", cookie_hdr.as_str()), ("Referer", ORIGIN)],
                false,
            )
            .await
        else {
            continue;
        };
        if status == 401 || status == 403 {
            return Err(cloud_auth_error(
                "workupload: cookie/token недействителен — обновите session или mailpass",
            ));
        }
        if status >= 400 {
            last_note = format!("# WorkUpload {path}: HTTP {status}\n");
            continue;
        }
        let Ok(v) = parse_json_text(cfg.provider, status, &text, "workupload list") else {
            continue;
        };
        workupload_collect_files(&v, &mut files);
        if !files.is_empty() {
            let mut inv = inventory_from_account(email, files, 0, 0, "WorkUpload");
            inv.list_note = Some(format!(
                "# WorkUpload: listing via `{path}` (session)\n"
            ));
            return Ok(inv);
        }
        last_note = format!("# WorkUpload {path}: empty or unknown JSON shape\n");
    }

    let (_home_status, home) = curl
        .get_text(
            cfg,
            "workupload home",
            &format!("{ORIGIN}/"),
            &[("Cookie", cookie_hdr.as_str()), ("Referer", ORIGIN)],
            true,
        )
        .await
        .unwrap_or((0, String::new()));

    let mut inv = inventory_from_account(email, Vec::new(), 0, 0, "WorkUpload");
    inv.list_note = Some(format!(
        "{last_note}# WorkUpload: сессия OK, list API без файлов; home preview: {}\n",
        home.chars().take(80).collect::<String>()
    ));
    Ok(inv)
}

fn workupload_collect_files(v: &Value, out: &mut Vec<CloudFileMeta>) {
    if let Some(arr) = v
        .get("data")
        .and_then(|x| x.as_array())
        .or_else(|| v.get("files").and_then(|x| x.as_array()))
        .or_else(|| v.as_array())
    {
        for item in arr {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = item
                .get("name")
                .or_else(|| item.get("filename"))
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let size = item.get("size").and_then(|x| x.as_u64()).unwrap_or(0);
            let path = name.to_string();
            let mut meta = CloudFileMeta::new(name, size, path.clone());
            if let Some(id) = item.get("id").map(|x| x.to_string()) {
                meta = meta.with_remote_id(id);
            }
            out.push(meta);
        }
    }
}

/// Normalize combo secret to a `Cookie` header value (`token=…` or full cookie string).
pub fn workupload_cookie_header(secret: &str) -> String {
    let s = secret.trim();
    if s.contains('=') {
        s.to_string()
    } else {
        format!("token={s}")
    }
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn cookie_header_from_raw_token() {
        assert_eq!(workupload_cookie_header("abc123"), "token=abc123");
    }

    #[test]
    fn cookie_header_passthrough() {
        assert_eq!(
            workupload_cookie_header("token=xyz; other=1"),
            "token=xyz; other=1"
        );
    }

    #[test]
    fn puzzle_solver_finds_indices() {
        let puzzle = "1790157289.19846ab3a1e930722";
        let find = vec![
            "fd5320643ab21075000a4af836025f4488470cb1da3f71805d15c4bf5326e837".to_string(),
            "0b5cb063f390dc2ff3135a0ed258bf55a2848089a5dc450702070430ac7ac6b2".to_string(),
            "6870b9de006b376ece994434b4a43200410ef5f327507d307b68ae969f5d0831".to_string(),
        ];
        let cap = workupload_solve_puzzle(puzzle, &find, 10_000).expect("solution");
        assert!(cap.ends_with(' '));
        assert_eq!(cap.split_whitespace().count(), 3);
    }
}
