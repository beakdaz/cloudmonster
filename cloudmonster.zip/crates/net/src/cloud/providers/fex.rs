﻿//! FEX.net — POST /api/v1/auth/signin + file tree listing.

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::dispatch_download;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::{json, Value};
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const FEX_API: &str = "https://api.fex.net/api/v1";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        fex_inventory(cfg, client, cred)
    })
    .await
}

pub async fn download_filtered_files(
    cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let token = inv
        .session_secret
        .as_deref()
        .context("fex: missing bearer token for download")?;
    let auth = format!("Bearer {token}");
    let mut curl = CloudCurlSession::new()?;
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    for file in picks {
        let Some(id) = file.remote_id.as_deref() else {
            continue;
        };
        let url = format!("{FEX_API}/file/{id}");
        let Ok(v) = curl
            .get_json(
                cfg,
                "fex file meta",
                &url,
                &[
                    ("Authorization", auth.as_str()),
                    ("Origin", "https://fex.net"),
                ],
            )
            .await
        else {
            continue;
        };
        let Some(dl) = fex_download_url(&v) else {
            continue;
        };
        let leaf = if file.path.is_empty() {
            file.name.clone()
        } else {
            file.path.replace('/', "\\")
        };
        match dispatch_download::write_leaf(cred, run_output_dir, &leaf, &client, &dl).await {
            Ok((path, n)) => {
                count += 1;
                total += n;
                paths.push(path);
            }
            Err(_) => continue,
        }
    }
    Ok((count, total, paths))
}

async fn fex_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let login = cred.username.trim().to_string();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let mut payload = json!({ "login": login, "password": password });
    if login.starts_with('+') && login.chars().skip(1).all(|c| c.is_ascii_digit()) {
        payload = json!({ "phone": login, "password": password });
    }

    let (status, body) = curl
        .post_json(cfg, "fex signin", &format!("{FEX_API}/auth/signin"), &payload, &[
            ("Origin", "https://fex.net"),
            ("Referer", "https://fex.net/login"),
        ])
        .await
        .context("fex signin")?;

    let token = body
        .get("token")
        .and_then(|x| x.as_str())
        .map(str::to_string)
        .or_else(|| extract_fex_token(&body));
    let Some(token) = token else {
        if status == 401 || status == 403 {
            return Err(cloud_auth_error("fex: invalid login or password"));
        }
        return Err(cloud_auth_error("fex: signin failed (no token)"));
    };

    let mut files = Vec::new();
    fex_walk_folder(cfg, &mut curl, &token, 0, "", &mut files).await?;

    let used: u64 = files.iter().map(|f| f.size).sum();
    let mut inv = inventory_from_account(&login, files, used, 50 * 1024 * 1024 * 1024, "Free");
    inv.session_secret = Some(token);
    Ok(inv)
}

async fn fex_walk_folder(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
    folder_id: u64,
    prefix: &str,
    out: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let mut queue: VecDeque<(u64, String)> = VecDeque::from([(folder_id, prefix.to_string())]);
    while let Some((fid, pref)) = queue.pop_front() {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let url = format!("{FEX_API}/file/{fid}");
        let auth = format!("Bearer {token}");
        let Ok(v) = curl
            .get_json(
                cfg,
                "fex list folder",
                &url,
                &[
                    ("Authorization", auth.as_str()),
                    ("Origin", "https://fex.net"),
                ],
            )
            .await
        else {
            continue;
        };
        let children = v
            .get("children")
            .and_then(|x| x.as_array())
            .cloned()
            .unwrap_or_default();
        for child in children {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = child.get("name").and_then(|x| x.as_str()).unwrap_or("file");
            let is_dir = child
                .get("is_dir")
                .and_then(|x| x.as_bool())
                .unwrap_or(false);
            let path = format!("{pref}{name}");
            if is_dir {
                if let Some(id) = child.get("id").and_then(|x| x.as_u64()) {
                    queue.push_back((id, format!("{path}/")));
                }
                continue;
            }
            let size = child.get("size").and_then(|x| x.as_u64()).unwrap_or(0);
            let id = child.get("id").map(|x| x.to_string()).unwrap_or_default();
            let mut meta = CloudFileMeta::new(name, size, path)
                .with_keyword_extra(child.get("mimetype").and_then(|x| x.as_str()).unwrap_or(""));
            if !id.is_empty() {
                meta = meta.with_remote_id(id);
            }
            out.push(meta);
        }
    }
    Ok(())
}

fn extract_fex_token(v: &Value) -> Option<String> {
    v.as_str().map(str::to_string)
}

pub fn extract_fex_token_from_json_text(text: &str) -> Option<String> {
    serde_json::from_str::<Value>(text)
        .ok()?
        .get("token")?
        .as_str()
        .map(str::to_string)
}

pub fn fex_download_url(v: &Value) -> Option<String> {
    v.get("download_url")
        .and_then(|x| x.as_str())
        .map(str::to_string)
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn parse_token_from_signin_json() {
        assert_eq!(
            extract_fex_token_from_json_text(r#"{"token":"abc123"}"#).as_deref(),
            Some("abc123")
        );
    }

    #[test]
    fn parse_download_url_from_file_json() {
        let v: Value = serde_json::from_str(
            r#"{"id":1,"download_url":"https://fs20.fex.net/downloads/1","parent_id":0}"#,
        )
        .unwrap();
        assert_eq!(
            fex_download_url(&v).as_deref(),
            Some("https://fs20.fex.net/downloads/1")
        );
    }
}
