﻿//! InternXt Drive — gateway login + folder content listing.

use crate::cloud::internxt_crypto::encrypt_password_hash;
use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const GATEWAY: &str = "https://gateway.internxt.com";
const LOGIN: &str = "https://gateway.internxt.com/drive/auth/login";
const ACCESS: &str = "https://gateway.internxt.com/drive/auth/login/access";
const CLIENT_HDR: &str = "drive";
const CLIENT_VERSION: &str = "1.0.0";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        internxt_inventory(cfg, client, cred)
    })
    .await
}

async fn internxt_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let (token, root_folder) = internxt_login(cfg, &mut curl, &email, &password).await?;
    let used = internxt_usage(cfg, &mut curl, &token).await.unwrap_or(0);

    let mut files = Vec::new();
    let mut queue: VecDeque<String> = VecDeque::new();
    queue.push_back(root_folder);

    while let Some(folder_uuid) = queue.pop_front() {
        collect_files_in_folder(cfg, &mut curl, &token, &folder_uuid, &mut files, &mut queue).await?;
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
    }

    Ok(inventory_from_account(
        &email,
        files,
        used,
        0,
        "InternXt",
    ))
}

async fn internxt_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<(String, String)> {
    let hdrs = internxt_headers();
    let login_body = serde_json::json!({ "email": email });
    let (status, login_json) = curl
        .post_json(cfg, "internxt login", LOGIN, &login_body, &hdrs)
        .await
        .context("internxt login step")?;
    if status == 429 {
        return Err(cloud_rate_limit_error(format!("internxt login http {status}")));
    }
    if status >= 400 {
        return Err(cloud_auth_error(format!(
            "internxt login http {status}: {}",
            preview(&login_json)
        )));
    }
    if login_json.get("tfa").and_then(|x| x.as_bool()) == Some(true) {
        return Err(cloud_auth_error("internxt: 2FA enabled on account"));
    }
    let s_key = login_json
        .get("sKey")
        .and_then(|x| x.as_str())
        .context("internxt sKey")?;
    let enc_pass = encrypt_password_hash(password, s_key).context("internxt password crypto")?;
    let access_body = serde_json::json!({
        "email": email,
        "password": enc_pass,
        "tfa": "",
    });
    let (a_status, access_json) = curl
        .post_json(cfg, "internxt access", ACCESS, &access_body, &hdrs)
        .await
        .context("internxt access step")?;
    if a_status == 401 || a_status == 403 {
        return Err(cloud_auth_error("internxt: invalid email or password"));
    }
    if a_status == 402 {
        return Err(cloud_auth_error(format!(
            "internxt: plan does not allow API access ({})",
            preview(&access_json)
        )));
    }
    if a_status >= 400 {
        return Err(cloud_auth_error(format!(
            "internxt access http {a_status}: {}",
            preview(&access_json)
        )));
    }
    let token = access_json
        .get("newToken")
        .or_else(|| access_json.get("token"))
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
        .context("internxt token")?;
    let root = access_json
        .get("user")
        .and_then(|u| u.get("rootFolderId"))
        .and_then(|x| x.as_str())
        .context("internxt rootFolderId")?;
    Ok((token.to_string(), root.to_string()))
}

async fn internxt_usage(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
) -> Result<u64> {
    let url = format!("{GATEWAY}/drive/users/usage");
    let auth = format!("Bearer {token}");
    let hdrs = internxt_headers_with_auth(&auth);
    let v = curl
        .get_json(cfg, "internxt usage", &url, &hdrs)
        .await
        .context("internxt usage")?;
    Ok(v.get("drive")
        .and_then(|x| x.as_u64().or_else(|| x.as_i64().map(|n| n.max(0) as u64)))
        .unwrap_or(0))
}

async fn collect_files_in_folder(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
    folder_uuid: &str,
    files: &mut Vec<CloudFileMeta>,
    queue: &mut VecDeque<String>,
) -> Result<()> {
    let auth = format!("Bearer {token}");
    let hdrs = internxt_headers_with_auth(&auth);

    let mut offset = 0;
    loop {
        let offset_s = offset.to_string();
        let url = build_url(
            &format!("{GATEWAY}/drive/folders/content/{folder_uuid}/files"),
            &[
                ("offset", offset_s.as_str()),
                ("limit", "200"),
                ("sort", "plainName"),
                ("order", "ASC"),
            ],
        )?;
        let v = curl
            .get_json(cfg, "internxt list files", &url, &hdrs)
            .await
            .with_context(|| format!("internxt files in {folder_uuid}"))?;
        let arr = v.get("files").and_then(|x| x.as_array());
        let Some(items) = arr else {
            break;
        };
        if items.is_empty() {
            break;
        }
        for item in items {
            let name = item
                .get("plainName")
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let size = parse_size(item.get("size"));
            let uuid = item
                .get("uuid")
                .and_then(|x| x.as_str())
                .unwrap_or("");
            let path = if let Some(p) = item.get("plainName").and_then(|x| x.as_str()) {
                format!("/{p}")
            } else {
                name.to_string()
            };
            files.push(
                CloudFileMeta::new(name, size, path).with_remote_id(uuid.to_string()),
            );
            if files.len() >= MAX_CLOUD_LIST_LINES {
                return Ok(());
            }
        }
        if items.len() < 200 {
            break;
        }
        offset += 200;
    }

    offset = 0;
    loop {
        let offset_s = offset.to_string();
        let url = build_url(
            &format!("{GATEWAY}/drive/folders/content/{folder_uuid}/folders"),
            &[
                ("offset", offset_s.as_str()),
                ("limit", "200"),
                ("sort", "plainName"),
                ("order", "ASC"),
            ],
        )?;
        let v = curl
            .get_json(cfg, "internxt list folders", &url, &hdrs)
            .await
            .with_context(|| format!("internxt folders in {folder_uuid}"))?;
        let items = match v.get("folders").and_then(|x| x.as_array()) {
            Some(a) if !a.is_empty() => a,
            _ => break,
        };
        for item in items {
            if let Some(uuid) = item.get("uuid").and_then(|x| x.as_str()) {
                queue.push_back(uuid.to_string());
            }
        }
        if items.len() < 200 {
            break;
        }
        offset += 200;
    }
    Ok(())
}

fn internxt_headers() -> Vec<(&'static str, &'static str)> {
    vec![
        ("Content-Type", "application/json"),
        ("internxt-client", CLIENT_HDR),
        ("internxt-version", CLIENT_VERSION),
        ("Origin", "https://drive.internxt.com"),
        ("Referer", "https://drive.internxt.com/"),
    ]
}

fn internxt_headers_with_auth(bearer: &str) -> Vec<(&str, &str)> {
    vec![
        ("Authorization", bearer),
        ("internxt-client", CLIENT_HDR),
        ("internxt-version", CLIENT_VERSION),
        ("Origin", "https://drive.internxt.com"),
        ("Referer", "https://drive.internxt.com/"),
    ]
}

fn parse_size(v: Option<&Value>) -> u64 {
    v.and_then(|x| {
        x.as_u64()
            .or_else(|| x.as_i64().map(|n| n.max(0) as u64))
            .or_else(|| x.as_str().and_then(|s| s.parse().ok()))
    })
    .unwrap_or(0)
}

fn preview(v: &Value) -> String {
    let s = v.to_string();
    if s.len() > 180 {
        format!("{}…", &s[..180])
    } else {
        s
    }
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use crate::cloud::config::CloudClientConfig;
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use std::time::Duration;
    use url::Url;

    #[tokio::test]
    #[ignore = "local smoke: set INTERNXT_TEST_COMBO"]
    async fn internxt_local_smoke() {
        let path = std::env::var("INTERNXT_TEST_COMBO").expect("INTERNXT_TEST_COMBO");
        let line = std::fs::read_to_string(&path)
            .unwrap()
            .lines()
            .find(|l| !l.trim().is_empty())
            .unwrap()
            .trim()
            .to_string();
        let (user, pass) = line.split_once(':').unwrap();
        let cred = Credential {
            url: Url::parse("https://drive.internxt.com/").unwrap(),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::InternXt,
            Duration::from_secs(90),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .unwrap();
        let out = std::env::temp_dir().join("internxt-smoke-out");
        let (_stats, written) = check_account(&cfg, &cred, &out, None)
            .await
            .expect("check_account");
        assert!(!written.is_empty());
    }
}
