﻿//! Proton Drive — SRP/2FA; session export only (no combo password API).

use crate::cloud::common::{cloud_auth_error, cloud_debug_log, run_checker, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::Result;
use pma_core::Credential;
use reqwest::Client;
use std::path::{Path, PathBuf};

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        proton_inventory(cfg, client, cred)
    })
    .await
}

async fn proton_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    _cred: Credential,
) -> Result<CloudInventory> {
    let secret = _cred.password.trim();
    if secret.starts_with("proton_session:") {
        cloud_debug_log(
            "H4",
            "proton_drive.rs",
            "session mode not ready",
            serde_json::json!({"provider": cfg.provider.label()}),
        );
        return Err(cloud_auth_error(
            "proton drive: режим proton_session: в разработке (SRP) — пока не помечаем пустой Valid",
        ));
    }
    Err(cloud_auth_error(
        "proton drive: email:password не поддерживается (SRP/2FA) — нужен экспорт proton_session:",
    ))
}
