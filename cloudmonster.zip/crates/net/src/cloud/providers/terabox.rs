﻿//! TeraBox (terabox.com) — passport login + `/api/list` inventory.
//! Crypto flow ported from public `terabox-api` (RSA pwd, AES pubkey, prand SHA1).

use crate::cloud::common::{
    cloud_auth_error, cloud_captcha_error, cloud_network_error, cloud_rate_limit_error,
    inventory_from_account, run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{parse_json_text, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use aes::cipher::{block_padding::Pkcs7, BlockDecryptMut, KeyIvInit};
use aes::Aes128;
use anyhow::{anyhow, Context, Result};
use base64::Engine;
use cbc::Decryptor;
use md5::{Digest, Md5};
use pma_core::Credential;
use regex::Regex;
use reqwest::Client;
use rsa::pkcs1v15::Pkcs1v15Encrypt;
use rsa::pkcs1::DecodeRsaPublicKey;
use rsa::pkcs8::DecodePublicKey;
use rsa::RsaPublicKey;
use serde_json::Value;
use sha1::Sha1;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

const TERABOX_UA: &str = "terabox;1.40.0.132;PC;PC-Windows;10.0.26100;WindowsTeraBox";
const DEFAULT_WHOST: &str = "https://www.terabox.com";

fn map_terabox_transport(err: anyhow::Error) -> anyhow::Error {
    let flat = format!("{err:#}").to_lowercase();
    if flat.contains("cloud network:") || flat.contains("cloud captcha:") {
        return err;
    }
    if flat.contains("socks")
        || flat.contains("error sending request")
        || flat.contains("proxy")
        || flat.contains("timed out")
        || flat.contains("connect")
    {
        return cloud_network_error(format!("{err:#}"));
    }
    err
}

type Aes128CbcDec = Decryptor<Aes128>;

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        terabox_inventory(cfg, client, cred)
    })
    .await
}

async fn terabox_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    curl.seed_cookie("lang", "en");

    let mut session = TeraboxSession {
        whost: DEFAULT_WHOST.to_string(),
        pcftoken: String::new(),
        bdstoken: String::new(),
        pubkey_pem: String::new(),
    };

    session
        .update_app_data(cfg, &mut curl, "wap/outlogin/login")
        .await
        .context("terabox login page")?;
    terabox_debug("H1", "template", &format!(r#"{{"pcftoken_len":{}}}"#, session.pcftoken.len()));

    if session.pcftoken.is_empty() {
        return Err(anyhow!("terabox: missing pcftoken on login page"));
    }

    let pre = session.passport_prelogin(cfg, &mut curl, &email).await?;
    terabox_debug(
        "H2",
        "prelogin",
        &format!(
            r#"{{"errno":{},"has_seval":{}}}"#,
            pre.get("errno").and_then(|x| x.as_i64()).unwrap_or(-1),
            pre.get("seval").is_some() || pre.get("data").and_then(|d| d.get("seval")).is_some()
        ),
    );

    let pre_fields = parse_prelogin(&pre)?;
    session
        .ensure_pubkey(cfg, &mut curl)
        .await
        .context("terabox getpubkey")?;

    let login = session
        .passport_login(cfg, &mut curl, &email, &password, &pre_fields)
        .await
        .context("terabox passport login")?;
    let has_ndus = curl.cookie_value("ndus").is_some();
    let login_code = login.get("code").and_then(|x| x.as_i64()).unwrap_or(-1);
    let login_errno = login.get("errno").and_then(|x| x.as_i64()).unwrap_or(-1);
    let login_msg = login
        .get("msg")
        .or_else(|| login.get("errmsg"))
        .and_then(|x| x.as_str())
        .unwrap_or("");
    terabox_debug(
        "H3",
        "login",
        &format!(
            r#"{{"code":{login_code},"errno":{login_errno},"msg_kind":"{}","has_ndus":{has_ndus}}}"#,
            terabox_login_msg_kind(login_msg, login_errno)
        ),
    );
    check_passport_login(&login, has_ndus)?;

    session
        .update_app_data(cfg, &mut curl, "main")
        .await
        .context("terabox main")?;

    let list = session.list_root(cfg, &mut curl).await?;
    let errno = list.get("errno").and_then(|x| x.as_i64()).unwrap_or(-1);
    if errno != 0 {
        let msg = list
            .get("errmsg")
            .and_then(|x| x.as_str())
            .unwrap_or("list failed");
        if errno == -6 || errno == 9019 {
            return Err(cloud_auth_error(format!("terabox list: {msg} (errno {errno})")));
        }
        return Err(anyhow!("terabox list errno {errno}: {msg}"));
    }

    let mut files = Vec::new();
    if let Some(arr) = list.get("list").and_then(|x| x.as_array()) {
        for item in arr {
            if item_is_dir(item) {
                continue;
            }
            let name = item
                .get("server_filename")
                .or_else(|| item.get("filename"))
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let size = item
                .get("size")
                .and_then(|x| x.as_u64().or_else(|| x.as_i64().map(|n| n.max(0) as u64)))
                .unwrap_or(0);
            let path = item
                .get("path")
                .and_then(|x| x.as_str())
                .unwrap_or(name);
            let fs_id = item.get("fs_id").map(|x| x.to_string());
            let mut meta = CloudFileMeta::new(name, size, path);
            if let Some(id) = fs_id {
                meta = meta.with_remote_id(id);
            }
            files.push(meta);
            if files.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
        }
    }
    terabox_debug("H4", "list", &format!(r#"{{"errno":0,"files":{}}}"#, files.len()));

    let used = list
        .get("used")
        .and_then(parse_u64_value)
        .unwrap_or_else(|| files.iter().map(|f| f.size).sum());
    let total = list
        .get("total")
        .or_else(|| list.get("quota"))
        .and_then(parse_u64_value)
        .unwrap_or(0);
    let tariff = if session.bdstoken.is_empty() {
        "Free"
    } else {
        "TeraBox"
    };

    Ok(inventory_from_account(
        &email,
        files,
        used,
        total,
        tariff,
    ))
}

struct PreloginFields {
    seval: String,
    random: String,
    timestamp: String,
}

struct TeraboxSession {
    whost: String,
    pcftoken: String,
    bdstoken: String,
    pubkey_pem: String,
}

impl TeraboxSession {
    fn url(&self, path: &str) -> String {
        let p = path.trim_start_matches('/');
        format!("{}/{}", self.whost.trim_end_matches('/'), p)
    }

    fn terabox_headers(&self, referer: bool) -> Vec<(String, String)> {
        let mut h = vec![("User-Agent".to_string(), TERABOX_UA.to_string())];
        if referer {
            h.push(("Referer".to_string(), self.whost.clone()));
        }
        h
    }

    fn header_refs(headers: &[(String, String)]) -> Vec<(&str, &str)> {
        headers
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect()
    }

    async fn update_app_data(
        &mut self,
        cfg: &CloudClientConfig,
        curl: &mut CloudCurlSession,
        path: &str,
    ) -> Result<()> {
        let url = self.url(path);
        let hdrs = self.terabox_headers(false);
        let refs = Self::header_refs(&hdrs);
        let (status, text) = curl
            .get_text(cfg, "terabox updateAppData", &url, &refs, true)
            .await
            .map_err(map_terabox_transport)
            .context("terabox GET")?;
        if status == 401 || status == 403 {
            return Err(cloud_auth_error(format!("terabox page http {status}")));
        }
        if status == 429 {
            return Err(cloud_rate_limit_error(format!("terabox page http {status}")));
        }
        if status >= 400 {
            return Err(anyhow!(
                "terabox page http {status}: {}",
                preview(&text, 180)
            ));
        }
        if let Some(origin) = detect_whost_redirect(&text, &url) {
            if origin != self.whost {
                self.whost = origin;
            }
        }
        let tdata = parse_template_data(&text)?;
        if let Some(t) = tdata.get("pcftoken").and_then(|x| x.as_str()) {
            self.pcftoken = t.to_string();
        }
        if let Some(t) = tdata.get("bdstoken").and_then(|x| x.as_str()) {
            self.bdstoken = t.to_string();
        }
        Ok(())
    }

    async fn passport_prelogin(
        &self,
        cfg: &CloudClientConfig,
        curl: &mut CloudCurlSession,
        email: &str,
    ) -> Result<Value> {
        let url = self.url("passport/prelogin");
        let form = [
            ("client", "web"),
            ("pass_version", "2.8"),
            ("clientfrom", "h5"),
            ("pcftoken", self.pcftoken.as_str()),
            ("email", email),
        ];
        let hdrs = self.terabox_headers(true);
        let refs = Self::header_refs(&hdrs);
        let (status, text) = curl
            .post_form(
                cfg,
                "terabox prelogin",
                &url,
                &form,
                &refs,
                false,
            )
            .await
            .map_err(map_terabox_transport)?;
        if status == 429 {
            return Err(cloud_rate_limit_error(format!("terabox prelogin http {status}")));
        }
        if status >= 400 {
            return Err(anyhow!("terabox prelogin http {status}: {}", preview(&text, 200)));
        }
        parse_json_text(cfg.provider, status, &text, "terabox prelogin")
    }

    async fn ensure_pubkey(
        &mut self,
        cfg: &CloudClientConfig,
        curl: &mut CloudCurlSession,
    ) -> Result<()> {
        if !self.pubkey_pem.is_empty() {
            return Ok(());
        }
        let url = self.url("passport/getpubkey");
        let hdrs = self.terabox_headers(false);
        let refs = Self::header_refs(&hdrs);
        let (status, text) = curl
            .get_text(cfg, "terabox getpubkey", &url, &refs, false)
            .await?;
        if status >= 400 {
            return Err(anyhow!("terabox getpubkey http {status}: {}", preview(&text, 120)));
        }
        let v = parse_json_text(cfg.provider, status, &text, "terabox getpubkey")?;
        if v.get("code").and_then(|x| x.as_i64()) != Some(0) {
            return Err(anyhow!("terabox getpubkey bad response"));
        }
        let data = v.get("data").context("terabox getpubkey data")?;
        let pp1 = data.get("pp1").and_then(|x| x.as_str()).context("pp1")?;
        let pp2 = data.get("pp2").and_then(|x| x.as_str()).context("pp2")?;
        self.pubkey_pem = decrypt_aes_pubkey(pp1, pp2).context("terabox decrypt pubkey")?;
        Ok(())
    }

    async fn passport_login(
        &self,
        cfg: &CloudClientConfig,
        curl: &mut CloudCurlSession,
        email: &str,
        password: &str,
        pre: &PreloginFields,
    ) -> Result<Value> {
        let encpwd_std = encrypt_rsa_password(password, &self.pubkey_pem)?;
        let encpwd = change_base64_type(&encpwd_std, 1);
        let browserid = curl.cookie_value("browserid").unwrap_or("");
        let prand = prand_gen("web", &pre.seval, &encpwd, email, browserid, &pre.random);

        let url = self.url("passport/login");
        let form = [
            ("client", "web"),
            ("pass_version", "2.8"),
            ("clientfrom", "h5"),
            ("pcftoken", self.pcftoken.as_str()),
            ("prand", prand.as_str()),
            ("email", email),
            ("pwd", encpwd.as_str()),
            ("seval", pre.seval.as_str()),
            ("random", pre.random.as_str()),
            ("timestamp", pre.timestamp.as_str()),
        ];
        let hdrs = self.terabox_headers(true);
        let refs = Self::header_refs(&hdrs);
        let (status, text) = curl
            .post_form(
                cfg,
                "terabox login",
                &url,
                &form,
                &refs,
                false,
            )
            .await?;
        if status == 429 {
            return Err(cloud_rate_limit_error(format!("terabox login http {status}")));
        }
        if status >= 400 {
            return Err(anyhow!("terabox login http {status}: {}", preview(&text, 200)));
        }
        parse_json_text(cfg.provider, status, &text, "terabox login")
    }

    async fn list_root(&self, cfg: &CloudClientConfig, curl: &mut CloudCurlSession) -> Result<Value> {
        let url = self.url("api/list");
        let form = [
            ("order", "name"),
            ("desc", "0"),
            ("dir", "/"),
            ("num", "20000"),
            ("page", "1"),
            ("showempty", "0"),
        ];
        let hdrs = self.terabox_headers(false);
        let refs = Self::header_refs(&hdrs);
        let (status, text) = curl
            .post_form(
                cfg,
                "terabox list",
                &url,
                &form,
                &refs,
                false,
            )
            .await?;
        if status == 429 {
            return Err(cloud_rate_limit_error(format!("terabox list http {status}")));
        }
        if status >= 400 {
            return Err(anyhow!("terabox list http {status}: {}", preview(&text, 200)));
        }
        parse_json_text(cfg.provider, status, &text, "terabox list")
    }
}

fn terabox_signals_rate_limited(msg: &str) -> bool {
    let m = msg.to_lowercase();
    m.contains("hit frequency")
        || m.contains("too often")
        || m.contains("too fast")
        || m.contains("try again later")
        || m.contains("频繁")
        || m.contains("操作过于频繁")
}

fn terabox_login_requires_verification(errno: i64, msg: &str) -> bool {
    if errno == 460030 {
        return true;
    }
    msg.eq_ignore_ascii_case("dragdrop") || msg.contains("need verify")
}

fn terabox_login_msg_kind(msg: &str, errno: i64) -> &'static str {
    if terabox_login_requires_verification(errno, msg) {
        "verification"
    } else if terabox_signals_rate_limited(msg) {
        "rate_limit"
    } else if msg.contains("wrong pwd") || msg.contains("user not exist") {
        "bad_credential"
    } else if msg.is_empty() {
        "unknown"
    } else {
        "other"
    }
}

fn check_passport_login(login: &Value, has_ndus: bool) -> Result<()> {
    let code_ok = login.get("code").and_then(|x| x.as_i64()) == Some(0);
    if code_ok || has_ndus {
        if !has_ndus {
            return Err(cloud_auth_error("terabox login: missing ndus cookie"));
        }
        return Ok(());
    }
    if let Some(errno) = login.get("errno").and_then(|x| x.as_i64()) {
        let msg = login
            .get("errmsg")
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        if terabox_login_requires_verification(errno, msg) {
            return Err(cloud_captcha_error(format!(
                "terabox login: captcha/verification ({msg}, errno {errno})"
            )));
        }
        return Err(cloud_auth_error(format!("terabox login: {msg} (errno {errno})")));
    }
    let code = login.get("code").and_then(|x| x.as_i64()).unwrap_or(-1);
    let msg = login
        .get("msg")
        .or_else(|| login.get("errmsg"))
        .and_then(|x| x.as_str())
        .unwrap_or("login failed");
    if terabox_signals_rate_limited(msg) {
        return Err(cloud_rate_limit_error(format!("terabox login: {msg} (code {code})")));
    }
    Err(cloud_auth_error(format!("terabox login: {msg} (code {code})")))
}

fn terabox_prelogin_error(msg: &str, detail: Option<&str>) -> anyhow::Error {
    let text = match detail {
        Some(d) => format!("terabox prelogin: {msg} ({d})"),
        None => format!("terabox prelogin: {msg}"),
    };
    if terabox_signals_rate_limited(msg) {
        cloud_rate_limit_error(text)
    } else {
        cloud_auth_error(text)
    }
}

fn parse_prelogin(v: &Value) -> Result<PreloginFields> {
    if v.get("code").and_then(|x| x.as_i64()).is_some_and(|c| c != 0) {
        let msg = v
            .get("msg")
            .or_else(|| v.get("errmsg"))
            .and_then(|x| x.as_str())
            .unwrap_or("prelogin failed");
        return Err(terabox_prelogin_error(msg, None));
    }
    if let Some(errno) = v.get("errno").and_then(|x| x.as_i64()) {
        if errno != 0 {
            let msg = v
                .get("errmsg")
                .and_then(|x| x.as_str())
                .unwrap_or("prelogin failed");
            return Err(terabox_prelogin_error(msg, Some(&format!("errno {errno}"))));
        }
    }
    let node = if let Some(d) = v.get("data") {
        d
    } else if v.get("seval").is_some() {
        v
    } else {
        return Err(anyhow!("terabox prelogin: missing data"));
    };
    let seval = node
        .get("seval")
        .and_then(|x| x.as_str())
        .context("terabox prelogin seval")?
        .to_string();
    let random = node
        .get("random")
        .map(json_scalar_string)
        .context("terabox prelogin random")?;
    let timestamp = node
        .get("timestamp")
        .map(json_scalar_string)
        .unwrap_or_else(|| "0".to_string());
    Ok(PreloginFields {
        seval,
        random,
        timestamp,
    })
}

fn json_scalar_string(v: &Value) -> String {
    if let Some(n) = v.as_i64() {
        n.to_string()
    } else if let Some(n) = v.as_u64() {
        n.to_string()
    } else {
        v.as_str().unwrap_or("0").to_string()
    }
}

fn parse_template_data(html: &str) -> Result<Value> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        Regex::new(r"(?s)<script>var templateData = (.*?);</script>").expect("template regex")
    });
    let caps = re
        .captures(html)
        .context("terabox templateData not found")?;
    let json_str = caps.get(1).context("template capture")?.as_str();
    serde_json::from_str(json_str).context("terabox templateData json")
}

fn detect_whost_redirect(html: &str, _requested: &str) -> Option<String> {
    if html.contains("templateData") {
        return None;
    }
    None
}

fn change_base64_type(s: &str, mode: u8) -> String {
    if mode == 1 {
        s.replace('+', "-").replace('/', "_")
    } else {
        s.replace('-', "+").replace('_', "/")
    }
}

fn decrypt_aes_pubkey(pp1: &str, pp2: &str) -> Result<String> {
    let pp1 = change_base64_type(pp1, 2);
    let pp2 = change_base64_type(pp2, 2);
    if pp1.len() < 17 {
        anyhow::bail!("terabox pubkey pp1 too short");
    }
    let iv = &pp1.as_bytes()[..16];
    let key = pp2.as_bytes();
    if key.len() != 16 {
        anyhow::bail!("terabox pubkey key length {}", key.len());
    }
    let cipher_b64 = &pp1[16..];
    let mut buf = base64::engine::general_purpose::STANDARD
        .decode(cipher_b64)
        .context("terabox pubkey ciphertext b64")?;
    let dec = Aes128CbcDec::new_from_slices(key, iv).context("terabox aes key/iv")?;
    let plain = dec
        .decrypt_padded_mut::<Pkcs7>(&mut buf)
        .map_err(|e| anyhow!("terabox aes decrypt: {e:?}"))?;
    String::from_utf8(plain.to_vec()).context("terabox pubkey utf8")
}

fn parse_rsa_public_key_pem(pem: &str) -> Result<RsaPublicKey> {
    let pem = pem.trim();
    if !pem.contains("BEGIN") {
        anyhow::bail!("terabox pubkey missing PEM header (AES decrypt failed or blocked page?)");
    }
    if pem.contains("BEGIN RSA PUBLIC KEY") {
        return RsaPublicKey::from_pkcs1_pem(pem).context("terabox rsa pkcs1 pem");
    }
    RsaPublicKey::from_public_key_pem(pem).context("terabox rsa spki pem")
}

fn encrypt_rsa_password(password: &str, pem: &str) -> Result<String> {
    let mut hasher = Md5::new();
    hasher.update(password.as_bytes());
    let md5_hex = format!("{:x}", hasher.finalize());
    let md5_len = md5_hex.len();
    let padded = if md5_len < 10 {
        format!("{md5_hex}0{md5_len}")
    } else {
        format!("{md5_hex}{md5_len}")
    };

    let public_key = parse_rsa_public_key_pem(pem)?;
    let mut rng = rand::thread_rng();
    let encrypted = public_key
        .encrypt(&mut rng, Pkcs1v15Encrypt, padded.as_bytes())
        .context("terabox rsa encrypt")?;
    Ok(base64::engine::general_purpose::STANDARD.encode(encrypted))
}

fn prand_gen(
    client: &str,
    seval: &str,
    encpwd: &str,
    email: &str,
    browserid: &str,
    random: &str,
) -> String {
    let combined = format!("{client}-{seval}-{encpwd}-{email}-{browserid}-{random}");
    let mut hasher = Sha1::new();
    hasher.update(combined.as_bytes());
    format!("{:x}", hasher.finalize())
}

fn item_is_dir(v: &Value) -> bool {
    v.get("isdir")
        .map(|x| x.as_i64() == Some(1) || x.as_str() == Some("1"))
        .unwrap_or(false)
}

fn parse_u64_value(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().map(|n| n.max(0) as u64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

// #region agent log
fn terabox_debug(hypothesis_id: &str, step: &str, data_json: &str) {
    use std::fs::OpenOptions;
    use std::io::Write;
    use std::sync::Mutex;
    static LOCK: Mutex<()> = Mutex::new(());
    let _g = LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let line = format!(
        r#"{{"sessionId":"be3b27","hypothesisId":"{hypothesis_id}","location":"terabox.rs","message":"{step}","data":{data_json},"timestamp":{ts},"runId":"terabox"}}"#
    );
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use crate::cloud::config::CloudClientConfig;
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use std::time::Duration;
    use url::Url;

    #[test]
    fn md5_padding_suffix() {
        let md5_hex = "098f6bcd4621d373cade4e832627b4f6";
        let padded = format!("{md5_hex}0{}", md5_hex.len());
        assert_eq!(padded, "098f6bcd4621d373cade4e832627b4f6032");
    }

    #[test]
    fn parse_rsa_public_key_pem_pkcs1_and_spki() {
        use rsa::pkcs1::{EncodeRsaPublicKey, LineEnding};
        use rsa::pkcs8::EncodePublicKey;
        use rsa::RsaPrivateKey;
        let mut rng = rand::thread_rng();
        let priv_key = RsaPrivateKey::new(&mut rng, 512).expect("rsa key");
        let pkcs1 = priv_key
            .to_public_key()
            .to_pkcs1_pem(LineEnding::LF)
            .expect("pkcs1 pem");
        parse_rsa_public_key_pem(&pkcs1).expect("pkcs1 parse");
        let spki = priv_key
            .to_public_key()
            .to_public_key_pem(LineEnding::LF)
            .expect("spki pem");
        parse_rsa_public_key_pem(&spki).expect("spki parse");
    }

    #[test]
    fn parse_rsa_public_key_pem_rejects_garbage() {
        assert!(parse_rsa_public_key_pem("not pem").is_err());
    }

    #[test]
    fn prelogin_hit_frequency_is_rate_limit_not_auth() {
        let v = serde_json::json!({ "code": 2, "msg": "hit frequency" });
        let err = match parse_prelogin(&v) {
            Err(e) => e,
            Ok(_) => panic!("expected prelogin error"),
        };
        let text = format!("{err:#}");
        assert!(text.contains("cloud rate limit"), "{text}");
        assert!(!text.contains("cloud auth"), "{text}");
    }

    #[test]
    fn     passport_login_dragdrop_is_verification_not_auth() {
        let v = serde_json::json!({
            "errno": 460030,
            "errmsg": "dragdrop",
            "request_id": 1
        });
        let err = check_passport_login(&v, false).unwrap_err();
        let text = format!("{err:#}");
        assert!(text.contains("cloud captcha"), "{text}");
        assert!(text.contains("460030"), "{text}");
    }

    #[test]
    fn passport_login_wrong_pwd_is_auth() {
        let v = serde_json::json!({ "code": 18, "msg": "wrong pwd" });
        let err = check_passport_login(&v, false).unwrap_err();
        let text = format!("{err:#}");
        assert!(text.contains("cloud auth"), "{text}");
    }

    #[test]
    fn passport_login_code_zero_needs_ndus() {
        let v = serde_json::json!({ "code": 0, "data": {} });
        assert!(check_passport_login(&v, true).is_ok());
        assert!(check_passport_login(&v, false).is_err());
    }

    /// Local only: `TERABOX_TEST_COMBO=C:\path\combo.txt cargo test -p pma-net terabox_local_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "local smoke: set TERABOX_TEST_COMBO to a combo file outside the repo"]
    async fn terabox_local_smoke() {
        let path = std::env::var("TERABOX_TEST_COMBO").expect("TERABOX_TEST_COMBO");
        let line = std::fs::read_to_string(&path)
            .expect("read combo")
            .lines()
            .find(|l| !l.trim().is_empty() && !l.trim_start().starts_with('#'))
            .expect("combo line")
            .trim()
            .to_string();
        let (user, pass) = line.split_once(':').expect("email:password");
        let cred = Credential {
            url: Url::parse("https://www.terabox.com/").expect("url"),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::Terabox,
            Duration::from_secs(60),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("cloud cfg");
        let out = std::env::temp_dir().join("terabox-smoke-out");
        let (_stats, written) = check_account(&cfg, &cred, &out, None)
            .await
            .expect("check_account");
        assert!(!written.is_empty(), "expected Содержимое inventory");
    }
}
