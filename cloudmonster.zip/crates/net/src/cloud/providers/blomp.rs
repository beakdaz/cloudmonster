﻿//! Blomp — OpenStack Swift (Keystone v2) at authenticate.blomp.com, tenant `storage`.
//! Local tests: use combo file outside repo (`email:password`).

use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{parse_json_text, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const AUTH_URL: &str = "https://authenticate.blomp.com/v2.0/tokens";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        blomp_inventory(cfg, client, cred)
    })
    .await
}

async fn blomp_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let (token, storage_url) = blomp_authenticate(cfg, &mut curl, &email, &password).await?;

    let container = percent_encode_path_segment(&email);
    let list_url = format!("{storage_url}/{container}?format=json");
    let extra = [("X-Auth-Token", token.as_str())];
    let (status, text) = curl
        .get_text(cfg, "blomp list container", &list_url, &extra, false)
        .await
        .context("blomp list")?;
    if status == 401 || status == 403 {
        return Err(cloud_auth_error(format!("blomp list http {status}")));
    }
    if status == 429 {
        return Err(cloud_rate_limit_error(format!("blomp list http {status}")));
    }
    if status >= 400 {
        return Err(anyhow!("blomp list http {status}: {}", preview(&text, 200)));
    }

    let mut files = Vec::new();
    let trimmed = text.trim();
    if !trimmed.is_empty() {
        let v: Value = serde_json::from_str(trimmed).context("blomp list json")?;
        if let Some(arr) = v.as_array() {
            for item in arr {
                if item.get("subdir").is_some() {
                    continue;
                }
                let name = item
                    .get("name")
                    .or_else(|| item.get("filename"))
                    .and_then(|x| x.as_str())
                    .unwrap_or("file");
                let size = item
                    .get("bytes")
                    .or_else(|| item.get("size"))
                    .and_then(|x| x.as_u64())
                    .unwrap_or(0);
                files.push(CloudFileMeta::new(name, size, name));
                if files.len() >= MAX_CLOUD_LIST_LINES {
                    break;
                }
            }
        }
    }

    let used: u64 = files.iter().map(|f| f.size).sum();
    Ok(inventory_from_account(&email, files, used, 0, "Free"))
}

async fn blomp_authenticate(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<(String, String)> {
    let payload = serde_json::json!({
        "auth": {
            "passwordCredentials": {
                "username": email,
                "password": password
            },
            "tenantName": "storage"
        }
    });
    let body = serde_json::to_vec(&payload).context("blomp auth json")?;
    let headers = [
        ("Content-Type", "application/json"),
        ("Accept", "application/json"),
    ];
    let (status, text, _) = curl
        .exchange(
            cfg,
            "blomp auth",
            reqwest::Method::POST,
            AUTH_URL,
            Some(body),
            &headers,
            false,
        )
        .await
        .context("blomp auth curl")?;
    if status == 401 {
        return Err(cloud_auth_error("invalid Blomp credentials"));
    }
    if status == 429 {
        return Err(cloud_rate_limit_error(format!("blomp auth http {status}")));
    }
    if status >= 400 {
        return Err(anyhow!(
            "blomp auth http {status}: {}",
            preview(&text, 240)
        ));
    }
    let v = parse_json_text(cfg.provider, status, &text, "blomp auth")?;
    let token = v
        .pointer("/access/token/id")
        .and_then(|x| x.as_str())
        .ok_or_else(|| anyhow!("blomp: missing token id"))?
        .to_string();
    let storage_url = v
        .pointer("/access/serviceCatalog")
        .and_then(|x| x.as_array())
        .and_then(|catalog| {
            catalog.iter().find_map(|svc| {
                let t = svc.get("type")?.as_str()?;
                if t != "object-store" {
                    return None;
                }
                svc.get("endpoints")?
                    .as_array()?
                    .iter()
                    .find_map(|ep| {
                        ep.get("publicURL")
                            .and_then(|u| u.as_str())
                    })
            })
        })
        .ok_or_else(|| anyhow!("blomp: missing object-store publicURL"))?
        .trim_end_matches('/')
        .to_string();
    Ok((token, storage_url))
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

fn percent_encode_path_segment(s: &str) -> String {
    s.bytes()
        .map(|b| match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                (b as char).to_string()
            }
            _ => format!("%{b:02X}"),
        })
        .collect()
}
