﻿//! WPS Drive — passport sign-in (account.wps.com) + drive.wps.cn inventory.

use crate::cloud::common::{
    cloud_auth_error, cloud_network_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use base64::Engine;
use pma_core::Credential;
use rand::rngs::OsRng;
use reqwest::Client;
use rsa::pkcs1::DecodeRsaPublicKey;
use rsa::pkcs1v15::Pkcs1v15Encrypt;
use rsa::pkcs8::DecodePublicKey;
use rsa::RsaPublicKey;
use serde_json::Value;
use std::collections::VecDeque;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

const WPS_LOGIN_PAGE: &str = "https://account.wps.com/?cb=https://www.wps.com/";
const WPS_PASSKEY: &str = "https://account.wps.com/api/v3/passkey";
const WPS_SAFE_VERIFY: &str = "https://account.wps.com/api/v3/account/safe_verify";
const WPS_ISLOGIN: &str = "https://account.kdocs.cn/api/v3/islogin";
const WPS_SPACES: &str = "https://drive.wps.cn/api/v3/spaces";
const WPS_MAX_DIR_DEPTH: u32 = 48;
const WPS_FILE_PAGE_SIZE: u32 = 200;
/// Concurrent `wps_walk_group` calls per account (also gated by `login_semaphore`).
const WPS_GROUP_WALK_PARALLEL: usize = 3;

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        wps_inventory(cfg, client, cred)
    })
    .await
}

async fn wps_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let cookie_seeded = wps_seed_combo_cookies(&mut curl, &password);
    let combo_is_cookies = wps_combo_looks_like_cookies(&password);
    if combo_is_cookies && !wps_has_session_cookies(&curl) {
        return Err(cloud_auth_error(
            "wps: cookie combo must include wps_sid and csrf (or session expired)",
        ));
    }
    let mut islogin_v = if cookie_seeded && wps_has_session_cookies(&curl) {
        match wps_require_islogin(cfg, &mut curl).await {
            Ok(v) => Some(v),
            Err(e) if combo_is_cookies => {
                return Err(cloud_auth_error(format!(
                    "wps: exported cookies rejected by islogin ({e:#})"
                )));
            }
            Err(_) => None,
        }
    } else {
        None
    };

    if islogin_v.is_none() {
        if combo_is_cookies {
            return Err(cloud_auth_error(
                "wps: cookie combo must include wps_sid and csrf (or session expired)",
            ));
        }
        let page_headers = wps_page_headers();
        let page_refs: Vec<(&str, &str)> = page_headers
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();
        let (page_status, page_html) = curl
            .get_text(cfg, "wps login page", WPS_LOGIN_PAGE, &page_refs, true)
            .await
            .context("wps login page")?;
        if page_status >= 400 {
            return Err(wps_http_to_checker_error(
                page_status,
                "wps login page",
                &page_html,
            ));
        }
        if curl.cookie_value("csrf").is_none() {
            wps_bootstrap_csrf(cfg, &mut curl, &page_refs, &page_html, page_status).await?;
        }
        if curl.cookie_value("csrf").is_none() {
            let via_proxy = cfg.proxy.as_ref().is_some_and(|p| !p.trim().is_empty());
            return Err(cloud_rate_limit_error(wps_login_page_block_message(
                &page_html,
                page_status,
                via_proxy,
            )));
        }

        try_wps_login(cfg, &mut curl, WPS_LOGIN_PAGE, &email, &password).await?;
        islogin_v = Some(wps_require_islogin(cfg, &mut curl).await?);
    }

    let islogin = islogin_v.as_ref().expect("islogin after login path");
    let tariff = wps_tariff_from_islogin(islogin);

    let (files, used, total) = wps_list_personal_drive(cfg, &mut curl).await.unwrap_or_default();
    wps_debug(
        "H-wps",
        "list",
        &format!(
            r#"{{"files":{},"used":{used},"total":{total}}}"#,
            files.len()
        ),
    );

    let mut inv = inventory_from_account(&email, files, used, total, tariff);
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# WPS: login OK (wps_sid). Если FILES=0 — диск пуст или cookie-mode / Business.\n\
             # Cookie-mode: пароль = `wps_sid=...; csrf=...` или JSON экспорт cookies.\n"
                .into(),
        );
    }
    Ok(inv)
}

fn wps_page_headers() -> Vec<(String, String)> {
    vec![
        (
            "Accept".into(),
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8".into(),
        ),
        ("Accept-Language".into(), "en-US,en;q=0.9".into()),
        (
            "Referer".into(),
            "https://www.wps.com/".into(),
        ),
    ]
}

fn wps_xhr_headers(curl: &CloudCurlSession, referer: &str) -> Vec<(String, String)> {
    let mut out = vec![
        ("Accept".into(), "application/json".into()),
        ("X-Requested-With".into(), "XMLHttpRequest".into()),
        ("Referer".into(), referer.to_string()),
    ];
    if let Some(csrf) = curl.cookie_value("csrf") {
        out.push(("X-CSRFToken".into(), csrf.to_string()));
    }
    out
}

fn wps_login_page_block_message(html: &str, status: u16, via_proxy: bool) -> String {
    let trimmed = html.trim();
    if trimmed.is_empty() {
        return format!(
            "wps: empty login page (http {status}{})",
            if via_proxy {
                ", proxy drop?"
            } else {
                ", connection reset?"
            }
        );
    }
    let lower = trimmed.to_lowercase();
    if lower.contains("just a moment")
        || lower.contains("cf-browser-verification")
        || lower.contains("challenge-platform")
    {
        return "wps: WAF/challenge on account.wps.com (lower threads, retry later)".into();
    }
    if wps_looks_like_active_captcha(&lower) {
        return if via_proxy {
            "wps: captcha/rate limit (proxy IP blocked — try direct or fewer threads)".into()
        } else {
            "wps: captcha/rate limit on your IP (use Threads 1–5, pause, retry)".into()
        };
    }
    for marker in ["hiwifi", "arris", "homarr", "router", "mikrotik", "login.asp"] {
        if lower.contains(marker) {
            return format!(
                "wps: gateway/router HTML (http {status}), not WPS login"
            );
        }
    }
    if wps_looks_like_login_shell(&lower) {
        return if via_proxy {
            "wps: login page OK but no csrf cookie (proxy/TLS — try direct, Threads 1–3)".into()
        } else {
            "wps: login page OK but no csrf cookie (too many parallel logins? Threads 1–5)".into()
        };
    }
    if !lower.contains("wps") && !lower.contains("account.wps") {
        let preview: String = trimmed.chars().take(80).collect();
        return format!(
            "wps: unexpected page (http {status}): {preview}…"
        );
    }
    "wps: missing csrf cookie after login page (lower threads and retry)".into()
}

/// Normal sign-in shell includes account fields; `.captchaWrap` alone is not a block page.
fn wps_looks_like_login_shell(lower_html: &str) -> bool {
    lower_html.contains("busaccount")
        || lower_html.contains("loginemail")
        || lower_html.contains("api/v3/passkey")
        || lower_html.contains("sign in")
}

fn wps_looks_like_active_captcha(lower_html: &str) -> bool {
    lower_html.contains("getmergeimgcaptcha")
        || lower_html.contains("googleautherror")
        || lower_html.contains("buscaptchainput")
        || lower_html.contains("recaptcha-google")
        || (lower_html.contains("qrcodeexpired") && !lower_html.contains("busaccount"))
}

/// Browser bootstraps session with bare `/api/v3/passkey` before account login.
async fn wps_bootstrap_csrf(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    page_refs: &[(&str, &str)],
    page_html: &str,
    page_status: u16,
) -> Result<()> {
    let mut hdrs = page_refs.to_vec();
    hdrs.push(("Accept", "application/json"));
    let (status, text) = curl
        .get_text(
            cfg,
            "wps passkey bootstrap",
            WPS_PASSKEY,
            &hdrs,
            false,
        )
        .await
        .context("wps passkey bootstrap")?;
    wps_debug(
        "H-wps",
        "bootstrap",
        &format!(
            r#"{{"http":{status},"has_csrf":{},"preview":{}}}"#,
            curl.cookie_value("csrf").is_some(),
            json_str_preview(&text, 100)
        ),
    );
    if status == 429 {
        return Err(cloud_rate_limit_error("wps: passkey bootstrap rate limited"));
    }
    if status == 403 {
        return Err(cloud_rate_limit_error(
            "wps: passkey bootstrap blocked (WAF/IP challenge)",
        ));
    }
    if status >= 400 {
        return Err(wps_http_to_checker_error(status, "wps passkey bootstrap", &text));
    }
    if curl.cookie_value("csrf").is_some() {
        return Ok(());
    }
    let v: Value = serde_json::from_str(text.trim()).unwrap_or(Value::Null);
    if v.get("result").and_then(|x| x.as_str()) == Some("ok") {
        return Ok(());
    }
    let via_proxy = cfg.proxy.as_ref().is_some_and(|p| !p.trim().is_empty());
    Err(cloud_rate_limit_error(wps_login_page_block_message(
        page_html,
        page_status,
        via_proxy,
    )))
}

fn wps_http_to_checker_error(status: u16, ctx: &str, body: &str) -> anyhow::Error {
    match status {
        429 => cloud_rate_limit_error(format!("{ctx}: rate limited (429)")),
        403 => cloud_rate_limit_error(format!("{ctx}: forbidden/WAF (403)")),
        401 => cloud_auth_error(format!("{ctx}: unauthorized (401)")),
        500..=599 => cloud_network_error(format!("{ctx}: server error ({status})")),
        _ if status >= 400 => cloud_network_error(format!(
            "{ctx}: http {status} {}",
            preview(body, 120)
        )),
        _ => cloud_network_error(format!("{ctx}: http {status}")),
    }
}

async fn wps_require_islogin(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
) -> Result<Value> {
    let (status, text) = curl
        .get_text(cfg, "wps islogin", WPS_ISLOGIN, &[], false)
        .await
        .context("wps islogin")?;
    wps_debug(
        "H-wps",
        "islogin",
        &format!(
            r#"{{"http":{status},"preview":{}}}"#,
            json_str_preview(&text, 80)
        ),
    );
    if status == 429 {
        return Err(cloud_rate_limit_error("wps islogin rate limited"));
    }
    if status == 403 {
        return Err(cloud_rate_limit_error("wps islogin blocked (WAF/stale session)"));
    }
    if status >= 400 {
        return Err(wps_http_to_checker_error(status, "wps islogin", &text));
    }
    let v: Value = serde_json::from_str(text.trim()).unwrap_or(Value::Null);
    if v.get("result").and_then(|x| x.as_str()) != Some("ok") {
        return Err(cloud_auth_error("wps: islogin not ok (expired or invalid session)"));
    }
    Ok(v)
}

fn wps_tariff_from_islogin(v: &Value) -> String {
    let mut label = wps_tariff_label_from_islogin(v);
    if let Some(ver) = wps_islogin_api_version(v) {
        label.push_str(&format!("; api={ver}"));
    }
    label
}

fn wps_islogin_api_version(v: &Value) -> Option<String> {
    let raw = v
        .get("api_version")
        .or_else(|| v.get("apiVersion"))
        .or_else(|| v.get("version"))?;
    if let Some(s) = raw.as_str() {
        let t = s.trim();
        if !t.is_empty() {
            return Some(t.to_string());
        }
    }
    raw.as_i64()
        .or_else(|| raw.as_u64().map(|n| n as i64))
        .map(|n| n.to_string())
}

fn wps_tariff_label_from_islogin(v: &Value) -> String {
    let company_id = v
        .get("companyid")
        .or_else(|| v.get("company_id"))
        .and_then(parse_i64)
        .unwrap_or(0);
    let tenant_id = v
        .get("tenant_id")
        .or_else(|| v.get("tenantid"))
        .and_then(parse_i64)
        .unwrap_or(0);
    let is_company = v
        .get("is_company")
        .or_else(|| v.get("iscompany"))
        .and_then(|x| x.as_bool())
        .unwrap_or(false);
    if is_company || company_id > 0 || tenant_id > 0 {
        return "Business".into();
    }
    if let Some(vip) = v.get("vip_type").or_else(|| v.get("viptype")).and_then(|x| x.as_str()) {
        let t = vip.trim();
        if !t.is_empty() && !t.eq_ignore_ascii_case("0") && !t.eq_ignore_ascii_case("none") {
            return format!("Personal ({t})");
        }
    }
    if v.get("vip")
        .or_else(|| v.get("is_vip"))
        .and_then(|x| x.as_bool())
        == Some(true)
    {
        return "Personal (VIP)".into();
    }
    "Personal".into()
}

fn wps_has_session_cookies(curl: &CloudCurlSession) -> bool {
    curl.cookie_value("wps_sid").is_some() && curl.cookie_value("csrf").is_some()
}

fn wps_combo_looks_like_cookies(secret: &str) -> bool {
    let t = secret.trim();
    t.starts_with('[')
        || t.starts_with('{')
        || t.starts_with("cookie:")
        || t.contains("wps_sid=")
}

fn header_refs(headers: &[(String, String)]) -> Vec<(&str, &str)> {
    headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect()
}

/// Combo password field may hold exported cookies instead of the account password.
fn wps_seed_combo_cookies(curl: &mut CloudCurlSession, secret: &str) -> bool {
    let trimmed = secret.trim();
    if trimmed.is_empty() {
        return false;
    }
    if trimmed.starts_with('[') || trimmed.starts_with('{') {
        if let Ok(v) = serde_json::from_str::<Value>(trimmed) {
            wps_seed_cookies_from_json(curl, &v);
            return true;
        }
    }
    let cookie_text = trimmed
        .strip_prefix("cookie:")
        .unwrap_or(trimmed)
        .trim();
    if cookie_text.contains('=') {
        wps_seed_cookies_from_header(curl, cookie_text);
        return true;
    }
    false
}

fn wps_seed_cookies_from_header(curl: &mut CloudCurlSession, header: &str) {
    for part in header.split(';') {
        let part = part.trim();
        let Some((name, value)) = part.split_once('=') else {
            continue;
        };
        let name = name.trim();
        let value = value.trim();
        if !name.is_empty() && !value.is_empty() {
            curl.seed_cookie(name, value);
        }
    }
}

fn wps_seed_cookies_from_json(curl: &mut CloudCurlSession, v: &Value) {
    match v {
        Value::Array(items) => {
            for item in items {
                let name = item
                    .get("name")
                    .or_else(|| item.get("Name"))
                    .and_then(|x| x.as_str())
                    .unwrap_or("");
                let value = item
                    .get("value")
                    .or_else(|| item.get("Value"))
                    .and_then(|x| x.as_str())
                    .unwrap_or("");
                if !name.is_empty() {
                    curl.seed_cookie(name, value);
                }
            }
        }
        Value::Object(map) => {
            for (name, value) in map {
                if let Some(s) = value.as_str() {
                    curl.seed_cookie(name, s);
                }
            }
        }
        _ => {}
    }
}

async fn try_wps_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    referer: &str,
    email: &str,
    password: &str,
) -> Result<()> {
    if curl.cookie_value("csrf").is_none() {
        return Err(cloud_network_error(
            "wps: missing csrf after login page (blocked or captcha interstitial)",
        ));
    }

    let xhr = wps_xhr_headers(curl, referer);
    let xhr_refs = header_refs(&xhr);

    let passkey_url = build_url(WPS_PASSKEY, &[("account", email)])?;
    let (pk_status, pk_text) = curl
        .get_text(cfg, "wps passkey", &passkey_url, &xhr_refs, false)
        .await
        .context("wps passkey")?;
    wps_debug(
        "H-wps",
        "passkey",
        &format!(
            r#"{{"http":{pk_status},"preview":{}}}"#,
            json_str_preview(&pk_text, 120)
        ),
    );
    if pk_status == 429 {
        return Err(cloud_rate_limit_error("wps passkey rate limited"));
    }
    if pk_status == 403 {
        return Err(cloud_rate_limit_error("wps passkey blocked (WAF/IP challenge)"));
    }
    if pk_status >= 400 {
        return Err(wps_http_to_checker_error(pk_status, "wps passkey", &pk_text));
    }
    let pk: Value = serde_json::from_str(&pk_text).unwrap_or(Value::Null);
    if pk.get("result").and_then(|x| x.as_str()) != Some("ok") {
        let msg = pk
            .get("msg")
            .and_then(|x| x.as_str())
            .unwrap_or("passkey failed");
        return Err(wps_api_error(msg, &pk));
    }
    let pass_key = pk
        .get("pass_key")
        .and_then(|x| x.as_str())
        .context("wps passkey: no pass_key")?;
    let ssid = pk
        .get("ssid")
        .and_then(|x| x.as_str())
        .context("wps passkey: no ssid")?
        .to_string();

    let enc_password = wps_encrypt_password(password, pass_key)?;

    let verify_form = [
        ("account", email),
        ("password", enc_password.as_str()),
        ("ssid", ssid.as_str()),
        ("source", "web"),
        ("keeponline", "1"),
    ];
    let (v_status, v_body) = curl
        .post_form(
            cfg,
            "wps safe_verify",
            WPS_SAFE_VERIFY,
            &verify_form,
            &xhr_refs,
            true,
        )
        .await
        .context("wps safe_verify")?;
    wps_debug(
        "H-wps",
        "safe_verify",
        &format!(
            r#"{{"http":{v_status},"has_wps_sid":{},"preview":{}}}"#,
            curl.cookie_value("wps_sid").is_some(),
            json_str_preview(&v_body, 160)
        ),
    );
    if v_status == 429 {
        return Err(cloud_rate_limit_error("wps safe_verify rate limited"));
    }
    if v_status == 403 {
        return Err(cloud_rate_limit_error("wps safe_verify blocked (WAF/IP challenge)"));
    }
    if v_status >= 400 && curl.cookie_value("wps_sid").is_none() {
        return Err(wps_http_to_checker_error(v_status, "wps safe_verify", &v_body));
    }

    if curl.cookie_value("wps_sid").is_some() {
        return Ok(());
    }

    let v: Value = serde_json::from_str(&v_body).unwrap_or(Value::Null);
    if v.get("result").and_then(|x| x.as_str()) == Some("ok") {
        if let Some(next_ssid) = v.get("ssid").and_then(|x| x.as_str()) {
            wps_finish_login(cfg, curl, referer, next_ssid, &xhr_refs).await?;
        }
        if curl.cookie_value("wps_sid").is_some() {
            return Ok(());
        }
    }

    if curl.cookie_value("wps_sid").is_none() {
        return Err(wps_verify_failure(&v, &v_body));
    }
    Ok(())
}

async fn wps_finish_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    referer: &str,
    ssid: &str,
    xhr_refs: &[(&str, &str)],
) -> Result<()> {
    let choose = build_url(
        "https://account.wps.com/v1/chooseaccount",
        &[
            ("loginerrcode", ""),
            ("ssid", ssid),
            ("hash", ""),
            ("logintype", "v1/accountlogin"),
        ],
    )?;
    let _ = curl
        .get_text(cfg, "wps chooseaccount", &choose, xhr_refs, true)
        .await;
    let _referer = referer;
    Ok(())
}

fn wps_api_error(msg: &str, v: &Value) -> anyhow::Error {
    let lower = msg.to_lowercase();
    let result = v.get("result").and_then(|x| x.as_str()).unwrap_or("");
    if result.eq_ignore_ascii_case("GoogleAuthError")
        || lower.contains("captcha")
        || lower.contains("recaptcha")
    {
        return cloud_rate_limit_error("wps: captcha required");
    }
    if lower.contains("password")
        || lower.contains("incorrect")
        || lower.contains("not exist")
        || result.eq_ignore_ascii_case("LoginFailed")
    {
        return cloud_auth_error(format!("wps: {msg}"));
    }
    cloud_rate_limit_error(format!("wps: {msg}"))
}

fn wps_verify_failure(v: &Value, raw: &str) -> anyhow::Error {
    if let Some(result) = v.get("result").and_then(|x| x.as_str()) {
        if result.eq_ignore_ascii_case("GoogleAuthError") {
            return cloud_rate_limit_error("wps: captcha required");
        }
        if result.eq_ignore_ascii_case("LoginFailed")
            || result.eq_ignore_ascii_case("InvalidAccount")
        {
            return cloud_auth_error("wps: invalid email or password");
        }
        if let Some(msg) = v.get("msg").and_then(|x| x.as_str()) {
            return wps_api_error(msg, v);
        }
        return cloud_rate_limit_error(format!("wps verify: {result}"));
    }
    let lower = raw.to_lowercase();
    if lower.contains("captcha") || lower.contains("recaptcha") {
        return cloud_rate_limit_error("wps: captcha required");
    }
    cloud_rate_limit_error(format!(
        "wps login: no wps_sid ({})",
        preview(raw, 120)
    ))
}

fn wps_normalize_pass_key(pass_key: &str) -> String {
    let trimmed = pass_key.trim();
    if trimmed.contains("BEGIN PUBLIC KEY") || trimmed.contains("BEGIN RSA PUBLIC KEY") {
        return trimmed.to_string();
    }
    format!(
        "-----BEGIN PUBLIC KEY-----\n{trimmed}\n-----END PUBLIC KEY-----"
    )
}

fn wps_parse_public_key(pem: &str) -> Result<RsaPublicKey> {
    if pem.contains("BEGIN RSA PUBLIC KEY") {
        return RsaPublicKey::from_pkcs1_pem(pem).context("wps rsa pkcs1");
    }
    RsaPublicKey::from_public_key_pem(pem).context("wps rsa spki")
}

fn wps_encrypt_password(password: &str, pass_key: &str) -> Result<String> {
    let pem = wps_normalize_pass_key(pass_key);
    let public_key = wps_parse_public_key(&pem)?;
    let mut rng = OsRng;
    let encrypted = public_key
        .encrypt(&mut rng, Pkcs1v15Encrypt, password.as_bytes())
        .context("wps rsa encrypt")?;
    Ok(base64::engine::general_purpose::STANDARD.encode(encrypted))
}

async fn wps_list_personal_drive(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
) -> Result<(Vec<CloudFileMeta>, u64, u64)> {
    let (status, text) = curl
        .get_text(
            cfg,
            "wps groups",
            "https://drive.wps.cn/api/v3/groups",
            &[],
            false,
        )
        .await?;
    if status >= 400 {
        return Ok((Vec::new(), 0, 0));
    }
    let v: Value = serde_json::from_str(&text).unwrap_or(Value::Null);
    let mut groups = v
        .get("groups")
        .and_then(|x| x.as_array())
        .cloned()
        .unwrap_or_default();
    groups.sort_by_key(|g| wps_group_priority(g));

    let (used, total) = wps_get_quota(cfg, curl).await;

    let group_specs: Vec<(i64, String)> = groups
        .iter()
        .filter_map(|g| {
            let gid = g.get("id").and_then(parse_i64).unwrap_or(0);
            if gid == 0 {
                return None;
            }
            let gname = g
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("drive")
                .to_string();
            Some((gid, gname))
        })
        .collect();

    let files = if let Some(flat) = wps_try_flat_search_list(cfg, curl).await? {
        wps_debug(
            "H-wps",
            "flat_search",
            &format!(r#"{{"files":{},"source":"search"}}"#, flat.len()),
        );
        flat
    } else {
        wps_walk_groups_parallel(cfg, curl, group_specs).await?
    };
    Ok((files, used, total))
}

async fn wps_get_quota(cfg: &CloudClientConfig, curl: &mut CloudCurlSession) -> (u64, u64) {
    let (status, text) = curl
        .get_text(cfg, "wps spaces", WPS_SPACES, &[], false)
        .await
        .unwrap_or((0, String::new()));
    if status < 400 {
        parse_wps_spaces(&text)
    } else {
        (0, 0)
    }
}

fn wps_group_walk_parallelism(_cfg: &CloudClientConfig) -> usize {
    WPS_GROUP_WALK_PARALLEL.max(1)
}

/// Consumer drive has no documented recursive listing; probe search API once, then DFS per group.
async fn wps_try_flat_search_list(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
) -> Result<Option<Vec<CloudFileMeta>>> {
    let mut files = Vec::new();
    let mut offset = 0u32;
    let mut pages_ok = 0u32;
    loop {
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let url = format!(
            "https://drive.wps.cn/api/v3/search?keyword=&include_folder=0&offset={offset}&count={WPS_FILE_PAGE_SIZE}"
        );
        let (status, text) = curl
            .get_text(cfg, "wps search", &url, &[], false)
            .await?;
        if status >= 400 {
            if pages_ok == 0 {
                return Ok(None);
            }
            break;
        }
        let v: Value = serde_json::from_str(&text).unwrap_or(Value::Null);
        let arr = v
            .get("files")
            .or_else(|| v.get("items"))
            .and_then(|x| x.as_array());
        let Some(arr) = arr else {
            if pages_ok == 0 {
                return Ok(None);
            }
            break;
        };
        if arr.is_empty() {
            break;
        }
        pages_ok += 1;
        for item in arr {
            if files.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            if let Some(meta) = wps_file_meta_from_search_item(item) {
                files.push(meta);
            }
        }
        offset = offset.saturating_add(arr.len() as u32);
        if arr.len() < WPS_FILE_PAGE_SIZE as usize {
            break;
        }
    }
    if pages_ok == 0 {
        Ok(None)
    } else {
        Ok(Some(files))
    }
}

fn wps_file_meta_from_search_item(item: &Value) -> Option<CloudFileMeta> {
    let is_dir = item.get("ftype").and_then(|x| x.as_str()) == Some("folder");
    if is_dir {
        return None;
    }
    let name = item
        .get("fname")
        .or_else(|| item.get("name"))
        .and_then(|x| x.as_str())
        .unwrap_or("file");
    let size = item
        .get("fsize")
        .or_else(|| item.get("size"))
        .and_then(parse_u64)
        .unwrap_or(0);
    let path = item
        .get("path")
        .or_else(|| item.get("fullpath"))
        .and_then(|x| x.as_str())
        .map(|p| p.to_string())
        .unwrap_or_else(|| name.to_string());
    Some(CloudFileMeta::new(name, size, path))
}

async fn wps_walk_groups_parallel(
    cfg: &CloudClientConfig,
    curl: &CloudCurlSession,
    groups: Vec<(i64, String)>,
) -> Result<Vec<CloudFileMeta>> {
    if groups.is_empty() {
        return Ok(Vec::new());
    }
    let parallelism = wps_group_walk_parallelism(cfg);
    if parallelism <= 1 {
        let mut curl = curl.fork_session()?;
        let mut files = Vec::new();
        for (gid, gname) in groups {
            let budget = MAX_CLOUD_LIST_LINES.saturating_sub(files.len());
            if budget == 0 {
                break;
            }
            wps_walk_group(cfg, &mut curl, gid, &gname, &mut files, budget).await?;
        }
        return Ok(files);
    }

    let cfg = cfg.clone();
    let mut files = Vec::new();
    let mut idx = 0usize;
    while idx < groups.len() && files.len() < MAX_CLOUD_LIST_LINES {
        let batch_end = (idx + parallelism).min(groups.len());
        let batch = groups[idx..batch_end].to_vec();
        let budget = MAX_CLOUD_LIST_LINES.saturating_sub(files.len());
        let mut joins = Vec::with_capacity(batch.len());
        for (gid, gname) in batch {
            let cfg = cfg.clone();
            let fork = curl.fork_session()?;
            joins.push(tokio::spawn(async move {
                let mut curl = fork;
                let mut partial = Vec::new();
                wps_walk_group(&cfg, &mut curl, gid, &gname, &mut partial, budget).await?;
                Ok::<Vec<CloudFileMeta>, anyhow::Error>(partial)
            }));
        }
        for join in joins {
            let partial = join
                .await
                .map_err(|e| cloud_network_error(format!("wps walk task: {e}")))??;
            for meta in partial {
                if files.len() >= MAX_CLOUD_LIST_LINES {
                    break;
                }
                files.push(meta);
            }
        }
        idx = batch_end;
    }
    Ok(files)
}

/// Personal / special groups first so `MAX_CLOUD_LIST_LINES` fills with user files.
fn wps_group_priority(g: &Value) -> (u8, i64) {
    let id = g.get("id").and_then(parse_i64).unwrap_or(i64::MAX);
    let corp = g
        .get("corptype")
        .or_else(|| g.get("corp_type"))
        .or_else(|| g.get("type"))
        .and_then(parse_i64)
        .unwrap_or(0);
    let name = g.get("name").and_then(|x| x.as_str()).unwrap_or("").to_lowercase();
    let personal_hint = name.contains("personal")
        || name.contains("我的")
        || name.contains("private")
        || corp == 0;
    (if personal_hint { 0 } else { 1 }, id)
}

async fn wps_walk_group(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    group_id: i64,
    root_path: &str,
    out: &mut Vec<CloudFileMeta>,
    max_entries: usize,
) -> Result<()> {
    let mut dirs: VecDeque<(i64, String, u32)> =
        VecDeque::from([(0, root_path.to_string(), 0u32)]);
    while let Some((parent_id, path_prefix, depth)) = dirs.pop_front() {
        if out.len() >= max_entries {
            break;
        }
        if depth >= WPS_MAX_DIR_DEPTH {
            continue;
        }
        let mut offset = 0u32;
        loop {
            if out.len() >= max_entries {
                break;
            }
            let url = format!(
                "https://drive.wps.cn/api/v5/groups/{group_id}/files?parentid={parent_id}&offset={offset}&count={WPS_FILE_PAGE_SIZE}"
            );
            let (status, text) = curl
                .get_text(cfg, "wps file list", &url, &[], false)
                .await?;
            if status >= 400 {
                break;
            }
            let v: Value = serde_json::from_str(&text).unwrap_or(Value::Null);
            let Some(arr) = v.get("files").and_then(|x| x.as_array()) else {
                break;
            };
            if arr.is_empty() {
                break;
            }

            let mut subdirs: Vec<(i64, String)> = Vec::new();
            for item in arr {
                let name = item
                    .get("fname")
                    .or_else(|| item.get("name"))
                    .and_then(|x| x.as_str())
                    .unwrap_or("file");
                let is_dir = item.get("ftype").and_then(|x| x.as_str()) == Some("folder");
                let full_path = format!("{path_prefix}/{name}");
                if is_dir {
                    let fid = item.get("id").and_then(parse_i64).unwrap_or(0);
                    if fid != 0 {
                        subdirs.push((fid, full_path));
                    }
                    continue;
                }
                let size = item
                    .get("fsize")
                    .or_else(|| item.get("size"))
                    .and_then(parse_u64)
                    .unwrap_or(0);
                out.push(CloudFileMeta::new(name, size, full_path));
            }

            for (fid, subpath) in subdirs.into_iter().rev() {
                dirs.push_front((fid, subpath, depth + 1));
            }

            offset = offset.saturating_add(arr.len() as u32);
            if arr.len() < WPS_FILE_PAGE_SIZE as usize {
                break;
            }
        }
    }
    Ok(())
}

fn parse_wps_spaces(text: &str) -> (u64, u64) {
    let v: Value = serde_json::from_str(text).unwrap_or(Value::Null);
    let used = v.get("used").and_then(parse_u64).unwrap_or(0);
    let total = v.get("total").and_then(parse_u64).unwrap_or(0);
    (used, total)
}

fn parse_i64(v: &Value) -> Option<i64> {
    v.as_i64().or_else(|| v.as_u64().map(|n| n as i64))
}

fn parse_u64(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().map(|n| n.max(0) as u64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

fn json_str_preview(s: &str, max: usize) -> String {
    let p = preview(s, max);
    serde_json::to_string(&p).unwrap_or_else(|_| "\"\"".to_string())
}

// #region agent log
fn wps_debug_enabled() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| {
        std::env::var("WPS_DEBUG")
            .ok()
            .is_some_and(|v| v == "1" || v.eq_ignore_ascii_case("true"))
            || std::env::var("CM_CLOUD_DEBUG")
                .ok()
                .is_some_and(|v| v == "1" || v.eq_ignore_ascii_case("true"))
    })
}

fn wps_debug(hypothesis_id: &str, step: &str, data_json: &str) {
    if !wps_debug_enabled() {
        return;
    }
    use std::fs::OpenOptions;
    use std::io::Write;
    use std::sync::Mutex;
    static LOCK: Mutex<()> = Mutex::new(());
    let _g = LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let line = format!(
        r#"{{"sessionId":"be3b27","hypothesisId":"{hypothesis_id}","location":"wps.rs","message":"{step}","data":{data_json},"timestamp":{ts},"runId":"wps"}}"#
    );
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cloud::config::CloudClientConfig;
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use std::time::Duration;
    use url::Url;

    #[test]
    fn wps_tariff_business_from_company_id() {
        let v = serde_json::json!({ "result": "ok", "companyid": 42 });
        assert_eq!(wps_tariff_from_islogin(&v), "Business");
    }

    #[test]
    fn wps_tariff_personal_default() {
        let v = serde_json::json!({ "result": "ok", "userid": 1 });
        assert_eq!(wps_tariff_from_islogin(&v), "Personal");
    }

    #[test]
    fn wps_tariff_appends_api_version_from_islogin() {
        let v = serde_json::json!({ "result": "ok", "userid": 1, "api_version": "3.0" });
        assert_eq!(wps_tariff_from_islogin(&v), "Personal; api=3.0");
    }

    #[test]
    fn wps_tariff_business_from_tenant_id() {
        let v = serde_json::json!({ "result": "ok", "tenant_id": 9 });
        assert_eq!(wps_tariff_from_islogin(&v), "Business");
    }

    #[test]
    fn wps_group_priority_personal_before_business() {
        let personal = serde_json::json!({ "id": 100, "name": "Personal Space", "corptype": 0 });
        let business = serde_json::json!({ "id": 1, "name": "Corp", "corptype": 1 });
        assert!(wps_group_priority(&personal) < wps_group_priority(&business));
    }

    #[test]
    fn wps_session_cookies_require_sid_and_csrf() {
        let mut curl = CloudCurlSession::new().expect("curl");
        assert!(!wps_has_session_cookies(&curl));
        curl.seed_cookie("wps_sid", "abc");
        assert!(!wps_has_session_cookies(&curl));
        curl.seed_cookie("csrf", "tok");
        assert!(wps_has_session_cookies(&curl));
    }

    /// `WPS_TEST_EMAIL` + `WPS_TEST_PASSWORD` or one line `WPS_TEST_COMBO=email:pass`
    /// `cargo test -p pma-net wps_local_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "local smoke: set WPS_TEST_COMBO or WPS_TEST_EMAIL/WPS_TEST_PASSWORD"]
    async fn wps_local_smoke() {
        let (user, pass) = if let Ok(combo) = std::env::var("WPS_TEST_COMBO") {
            let line = combo.trim();
            let (u, p) = line.split_once(':').expect("email:password");
            (u.to_string(), p.to_string())
        } else {
            (
                std::env::var("WPS_TEST_EMAIL").expect("WPS_TEST_EMAIL"),
                std::env::var("WPS_TEST_PASSWORD").expect("WPS_TEST_PASSWORD"),
            )
        };
        let cred = Credential {
            url: Url::parse("https://account.wps.com/").expect("url"),
            username: user,
            password: pass,
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::Wps,
            Duration::from_secs(90),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("config");
        let client = cfg.http.clone();
        match wps_inventory(&cfg, client, cred).await {
            Ok(inv) => {
                eprintln!(
                    "WPS OK: files={} used={}/{} tariff={}",
                    inv.file_count,
                    inv.used_bytes,
                    inv.quota_bytes,
                    inv.tariff
                );
            }
            Err(e) => {
                eprintln!("WPS FAIL: {e:#}");
                panic!("wps smoke failed");
            }
        }
    }
}
