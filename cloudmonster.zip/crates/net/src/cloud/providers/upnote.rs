﻿//! UpNote — session token (`upnote:TOKEN` or `Bearer …`); GET `/v1/notes`.

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const UPNOTE_API: &str = "https://api.getupnote.com";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        upnote_inventory(cfg, client, cred)
    })
    .await
}

async fn upnote_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let secret = cred.password.trim();

    if !secret.starts_with("upnote:") && !secret.starts_with("Bearer ") {
        return Err(cloud_auth_error(
            "upnote: пароль = `upnote:TOKEN` или `Bearer …` из приложения UpNote",
        ));
    }

    let token = secret
        .strip_prefix("upnote:")
        .or_else(|| secret.strip_prefix("Bearer "))
        .unwrap_or(secret)
        .trim();
    if token.is_empty() {
        return Err(cloud_auth_error("upnote: пустой token"));
    }

    let mut curl = CloudCurlSession::new()?;
    let auth = format!("Bearer {token}");
    let (status, text) = curl
        .get_text(
            cfg,
            "upnote notes",
            &format!("{UPNOTE_API}/v1/notes"),
            &[("Authorization", auth.as_str())],
            false,
        )
        .await
        .context("upnote notes")?;

    if status == 401 || status == 403 {
        return Err(cloud_auth_error("upnote: invalid session token"));
    }
    if status >= 400 {
        return Err(cloud_auth_error(format!("upnote: HTTP {status}")));
    }

    let files = upnote_parse_notes_json(&text);
    Ok(inventory_from_account(&email, files, 0, 0, "UpNote"))
}

fn upnote_parse_notes_json(text: &str) -> Vec<CloudFileMeta> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Vec::new();
    }
    let Ok(v) = serde_json::from_str::<Value>(trimmed) else {
        return Vec::new();
    };
    let arr = v
        .as_array()
        .or_else(|| v.get("notes").and_then(|x| x.as_array()))
        .or_else(|| v.get("data").and_then(|x| x.as_array()));
    let Some(arr) = arr else {
        return Vec::new();
    };
    let mut out = Vec::new();
    for item in arr {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let title = item
            .get("title")
            .or_else(|| item.get("name"))
            .or_else(|| item.get("plainText"))
            .and_then(|x| x.as_str())
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .unwrap_or("note");
        let id = item
            .get("id")
            .or_else(|| item.get("_id"))
            .and_then(|x| x.as_str())
            .unwrap_or("");
        let path = if id.is_empty() {
            title.to_string()
        } else {
            format!("{id}/{title}")
        };
        let mut meta = CloudFileMeta::new(title, 0, path);
        if !id.is_empty() {
            meta = meta.with_remote_id(id);
        }
        out.push(meta);
    }
    out
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn upnote_parses_notes_array() {
        let body = r#"[{"id":"a1","title":"Meeting"},{"title":"Untitled"}]"#;
        let v = upnote_parse_notes_json(body);
        assert_eq!(v.len(), 2);
        assert_eq!(v[0].name, "Meeting");
    }
}
