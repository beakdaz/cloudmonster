﻿//! ToffeeShare — peer-to-peer; not a cloud account checker.

use crate::cloud::common::{cloud_auth_error, cloud_debug_log, run_checker, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::Result;
use pma_core::Credential;
use reqwest::Client;
use std::path::{Path, PathBuf};

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        toffeeshare_inventory(cfg, client, cred)
    })
    .await
}

async fn toffeeshare_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    cloud_debug_log(
        "H4",
        "toffeeshare.rs",
        "reject not cloud",
        serde_json::json!({
            "provider": cfg.provider.label(),
            "has_prefix": cred.password.trim().starts_with("toffeeshare:"),
        }),
    );
    let _ = cred.username;
    Err(cloud_auth_error(
        "toffeeshare: WebRTC P2P — нет облачных аккаунтов и listing; выберите другой сервис в Platforms",
    ))
}
