﻿//! Box.com — OAuth v2 login (email:password) + access/refresh token + REST inventory.

use crate::cloud::common::{
    cloud_auth_error, cloud_network_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::{json, Value};
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const BOX_ORIGIN: &str = "https://account.box.com";
const BOX_LOGIN_PAGE: &str = "https://account.box.com/login";
const BOX_LOGIN_V2: &str = "https://account.box.com/api/oauth2/v2/login";
const BOX_LOGIN_CREDENTIALS: &str =
    "https://account.box.com/login/credentials?redirect_url=%2F";
const BOX_APP_ACCOUNT: &str = "https://app.box.com/account";
const BOX_TOKEN: &str = "https://api.box.com/oauth2/token";
const BOX_API: &str = "https://api.box.com/2.0";
const BOX_REDIRECT: &str = "http://127.0.0.1:53682/";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        box_inventory(cfg, client, cred)
    })
    .await
}

async fn box_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.trim().to_string();
    let secret = cred.password.trim();
    let mut curl = CloudCurlSession::new()?;

    let access_token = if let Some(t) = secret.strip_prefix("box:refresh:") {
        let (client_id, client_secret) = box_oauth_app_creds()?;
        box_exchange_refresh(cfg, &mut curl, &client_id, &client_secret, t.trim()).await?
    } else if let Some(t) = secret.strip_prefix("box:") {
        let t = t.trim();
        if t.is_empty() {
            return Err(cloud_auth_error("box: empty token after box: prefix"));
        }
        t.to_string()
    } else if secret.len() > 30 && !secret.contains(' ') && !secret.contains(':') {
        secret.to_string()
    } else if secret.contains(':') && !secret.contains('@') {
        return Err(cloud_auth_error(
            "box: неизвестный формат — box:TOKEN, box:refresh:TOKEN или email:password",
        ));
    } else {
        box_login_combo(cfg, &mut curl, &email, secret).await?
    };

    let auth = format!("Bearer {access_token}");
    let auth_hdr = [("Authorization", auth.as_str())];

    let me = curl
        .get_json(cfg, "box users/me", &format!("{BOX_API}/users/me"), &auth_hdr)
        .await
        .context("box users/me")?;
    if me.get("status").and_then(|x| x.as_u64()) == Some(401) {
        return Err(cloud_auth_error("box: invalid access token"));
    }
    let (used, total) = parse_box_quota(&me);

    let mut files = Vec::new();
    box_walk_folder(cfg, &mut curl, &auth_hdr, "0", "", &mut files).await?;

    let mut inv = inventory_from_account(&email, files, used, total, "Box");
    inv.session_secret = Some(access_token);
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# Box: login OK. Root-only empty or flat account.\n\
             # Token mode: password = `box:ACCESS_TOKEN` or `box:refresh:REFRESH` (+ BOX_OAUTH_* env).\n"
                .into(),
        );
    }
    Ok(inv)
}

async fn box_login_combo(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    if let Ok(token) = box_login_v2_json(cfg, curl, email, password).await {
        return Ok(token);
    }

    // OpenBullet-style web login (request_token + /login/credentials), then OAuth code if needed.
    box_login_legacy_credentials(cfg, curl, email, password).await?;

    let (client_id, client_secret) = box_oauth_app_creds()?;
    let code = box_oauth_authorization_code(cfg, curl, &client_id, email).await?;
    box_exchange_code(cfg, curl, &client_id, &client_secret, &code).await
}

async fn box_login_v2_json(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    let _ = curl
        .get_text(
            cfg,
            "box login page",
            BOX_LOGIN_PAGE,
            &[("Referer", BOX_ORIGIN)],
            true,
        )
        .await;

    let xhr = [
        ("Accept", "application/json"),
        ("Content-Type", "application/json"),
        ("Origin", BOX_ORIGIN),
        ("Referer", &format!("{BOX_LOGIN_PAGE}")),
    ];
    let (status, body) = curl
        .post_json(
            cfg,
            "box oauth v2 login",
            BOX_LOGIN_V2,
            &json!({ "login": email, "password": password }),
            &xhr,
        )
        .await
        .context("box oauth v2 login")?;

    if status == 401 || status == 403 {
        return Err(cloud_auth_error("box: invalid email or password"));
    }
    if status == 429 {
        return Err(cloud_rate_limit_error("box login rate limited"));
    }
    if let Some(token) = body
        .get("access_token")
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
    {
        return Ok(token.to_string());
    }
    if body.get("error").is_some() || body.get("errors").is_some() {
        let msg = body
            .pointer("/error/message")
            .or_else(|| body.get("message"))
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        let lower = msg.to_lowercase();
        if lower.contains("password") || lower.contains("credential") || lower.contains("invalid") {
            return Err(cloud_auth_error(format!("box: {msg}")));
        }
        return Err(anyhow!("box v2 login: {msg} (http {status})"));
    }
    Err(anyhow!("box v2 login: no access_token in response"))
}

async fn box_login_legacy_credentials(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<()> {
    let headers = [
        ("Accept", "*/*"),
        ("Pragma", "no-cache"),
        ("Referer", BOX_LOGIN_PAGE),
    ];
    let (status, html) = curl
        .get_text(cfg, "box login page", BOX_LOGIN_PAGE, &headers, false)
        .await
        .context("box login page")?;
    if status >= 500 {
        return Err(cloud_network_error(format!("box login page http {status}")));
    }
    let request_token = parse_box_request_token(&html).ok_or_else(|| {
        cloud_network_error("box: request_token not found on login page (captcha/SSO layout?)")
    })?;

    let form = [
        ("login", email),
        ("password", password),
        ("_pw_sql", ""),
        ("request_token", request_token.as_str()),
        ("redirect_url", "/"),
    ];
    let post_headers = [
        ("Accept", "*/*"),
        ("Pragma", "no-cache"),
        ("Origin", BOX_ORIGIN),
        ("Referer", BOX_LOGIN_PAGE),
    ];
    let (post_status, post_body) = curl
        .post_form(
            cfg,
            "box login credentials",
            BOX_LOGIN_CREDENTIALS,
            &form,
            &post_headers,
            true,
        )
        .await
        .context("box login credentials")?;

    if post_body.contains("Invalid Login Credentials") {
        return Err(cloud_auth_error("box: Invalid Login Credentials"));
    }
    if post_body.contains("Invalid captcha response") {
        return Err(cloud_rate_limit_error("box: Invalid captcha response"));
    }
    if post_status == 401 || post_status == 403 {
        return Err(cloud_auth_error("box: login credentials denied"));
    }

    let (acc_status, account_body) = curl
        .get_text(cfg, "box app account", BOX_APP_ACCOUNT, &headers, true)
        .await
        .context("box app account")?;
    if account_body.contains("Invalid Login Credentials") {
        return Err(cloud_auth_error("box: Invalid Login Credentials"));
    }
    if acc_status >= 400 && !account_body.contains("isEnterpriseAccount") {
        return Err(cloud_network_error(format!(
            "box app account http {acc_status}"
        )));
    }
    if !account_body.contains("isEnterpriseAccount") && !account_body.contains("accountType") {
        return Err(cloud_auth_error("box: web login did not establish session"));
    }
    Ok(())
}

fn parse_box_request_token(html: &str) -> Option<String> {
    for needle in [
        "name=\"request_token\" value=\"",
        "name='request_token' value='",
    ] {
        if let Some(start) = html.find(needle) {
            let rest = &html[start + needle.len()..];
            let end = rest.find('"').or_else(|| rest.find('\''))?;
            let token = rest[..end].trim();
            if !token.is_empty() {
                return Some(token.to_string());
            }
        }
    }
    None
}

fn box_oauth_app_creds() -> Result<(String, String)> {
    let id = std::env::var("BOX_OAUTH_CLIENT_ID")
        .ok()
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty());
    let secret = std::env::var("BOX_OAUTH_CLIENT_SECRET")
        .ok()
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty());
    match (id, secret) {
        (Some(i), Some(s)) => Ok((i, s)),
        _ => Err(cloud_auth_error(
            "box: после web-login нужен OAuth code — задайте BOX_OAUTH_CLIENT_ID и BOX_OAUTH_CLIENT_SECRET (redirect http://127.0.0.1:53682/)",
        )),
    }
}

async fn box_oauth_authorization_code(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    client_id: &str,
    _email: &str,
) -> Result<String> {
    let auth_url = build_url(
        "https://account.box.com/api/oauth2/authorize",
        &[
            ("response_type", "code"),
            ("client_id", client_id),
            ("redirect_uri", BOX_REDIRECT),
        ],
    )?;
    let (status, text) = curl
        .get_text(
            cfg,
            "box oauth authorize",
            &auth_url,
            &[("Referer", BOX_ORIGIN)],
            false,
        )
        .await
        .context("box oauth authorize")?;
    if let Some(code) = extract_oauth_code(&text) {
        return Ok(code);
    }
    if status >= 400 {
        return Err(cloud_network_error(format!(
            "box oauth authorize http {status}: {}",
            preview(&text, 120)
        )));
    }
    Err(cloud_network_error(
        "box: OAuth authorize не вернул code (consent / SSO / captcha)",
    ))
}

async fn box_exchange_code(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    client_id: &str,
    client_secret: &str,
    code: &str,
) -> Result<String> {
    let form = [
        ("grant_type", "authorization_code"),
        ("code", code),
        ("client_id", client_id),
        ("client_secret", client_secret),
        ("redirect_uri", BOX_REDIRECT),
    ];
    let (status, text) = curl
        .post_form(cfg, "box oauth token", BOX_TOKEN, &form, &[], false)
        .await
        .context("box oauth token")?;
    let v: Value = serde_json::from_str(&text).unwrap_or(Value::Null);
    if status == 401 || status == 403 {
        return Err(cloud_auth_error("box: OAuth token exchange denied"));
    }
    if let Some(token) = v.get("access_token").and_then(|x| x.as_str()) {
        return Ok(token.to_string());
    }
    if let Some(ref_tok) = v.get("refresh_token").and_then(|x| x.as_str()) {
        return box_exchange_refresh(cfg, curl, client_id, client_secret, ref_tok).await;
    }
    let err = v
        .get("error_description")
        .or_else(|| v.get("error"))
        .and_then(|x| x.as_str())
        .unwrap_or("token exchange failed");
    Err(cloud_network_error(format!("box token: {err} (http {status})")))
}

async fn box_exchange_refresh(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    client_id: &str,
    client_secret: &str,
    refresh_token: &str,
) -> Result<String> {
    let form = [
        ("grant_type", "refresh_token"),
        ("refresh_token", refresh_token),
        ("client_id", client_id),
        ("client_secret", client_secret),
    ];
    let (status, text) = curl
        .post_form(cfg, "box oauth refresh", BOX_TOKEN, &form, &[], false)
        .await
        .context("box oauth refresh")?;
    let v: Value = serde_json::from_str(&text).unwrap_or(Value::Null);
    v.get("access_token")
        .and_then(|x| x.as_str())
        .map(|s| s.to_string())
        .ok_or_else(|| {
            cloud_auth_error(format!(
                "box refresh failed (http {status}): {}",
                preview(&text, 80)
            ))
        })
}

async fn box_walk_folder(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    auth: &[(&str, &str)],
    folder_id: &str,
    path_prefix: &str,
    out: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let mut pending: VecDeque<(String, String)> = VecDeque::from([(folder_id.to_string(), path_prefix.to_string())]);
    while let Some((fid, prefix)) = pending.pop_front() {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let mut offset = 0u32;
        loop {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let url = format!(
                "{BOX_API}/folders/{fid}/items?limit=1000&offset={offset}&fields=name,size,id,type"
            );
            let v = curl
                .get_json(cfg, "box folder items", &url, auth)
                .await
                .context("box folder items")?;
            if v.get("status").and_then(|x| x.as_u64()) == Some(404) {
                break;
            }
            let Some(entries) = v.get("entries").and_then(|x| x.as_array()) else {
                break;
            };
            if entries.is_empty() {
                break;
            }
            for item in entries {
                let kind = item.get("type").and_then(|x| x.as_str()).unwrap_or("");
                let name = item.get("name").and_then(|x| x.as_str()).unwrap_or("item");
                let full = if prefix.is_empty() {
                    name.to_string()
                } else {
                    format!("{prefix}/{name}")
                };
                if kind == "folder" {
                    if let Some(id) = item.get("id").and_then(|x| x.as_str()) {
                        pending.push_back((id.to_string(), full));
                    }
                    continue;
                }
                if kind != "file" {
                    continue;
                }
                let size = item.get("size").and_then(|x| x.as_u64()).unwrap_or(0);
                let id = item.get("id").and_then(|x| x.as_str()).unwrap_or("");
                let mut meta = CloudFileMeta::new(name, size, full);
                if !id.is_empty() {
                    meta = meta.with_remote_id(id);
                }
                out.push(meta);
            }
            offset += entries.len() as u32;
            let total = v.get("total_count").and_then(|x| x.as_u64()).unwrap_or(0) as u32;
            if offset >= total {
                break;
            }
        }
    }
    Ok(())
}

fn parse_box_quota(me: &Value) -> (u64, u64) {
    let used = me
        .get("space_used")
        .and_then(parse_u64)
        .unwrap_or(0);
    let total = me
        .get("space_amount")
        .and_then(parse_u64)
        .unwrap_or(0);
    (used, total)
}

fn parse_u64(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().map(|n| n.max(0) as u64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn extract_oauth_code(text: &str) -> Option<String> {
    if let Some(idx) = text.find("code=") {
        let rest = &text[idx + 5..];
        let end = rest.find('&').unwrap_or(rest.len());
        let code = rest[..end].trim();
        if !code.is_empty() {
            return Some(code.to_string());
        }
    }
    None
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

pub fn box_entry_is_file(v: &Value) -> bool {
    v.get("type").and_then(|x| x.as_str()) == Some("file")
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use serde_json::json;

    #[test]
    fn extracts_code_from_redirect_fragment() {
        let s = "http://127.0.0.1:53682/?code=abc123&state=x";
        assert_eq!(extract_oauth_code(s).as_deref(), Some("abc123"));
    }

    #[test]
    fn detects_file_entry() {
        assert!(box_entry_is_file(&json!({"type":"file"})));
        assert!(!box_entry_is_file(&json!({"type":"folder"})));
    }

    #[test]
    fn parses_request_token_from_login_html() {
        let html = r#"<input name="request_token" value="abc123token" />"#;
        assert_eq!(
            parse_box_request_token(html).as_deref(),
            Some("abc123token")
        );
    }
}
