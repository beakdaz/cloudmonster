﻿//! Icedrive — internal web API (session cookie) or `icedrive:` bearer token.

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{parse_json_text, CloudCurlSession};
use crate::cloud::dispatch_download;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use base64::engine::general_purpose::{STANDARD as B64_STD, URL_SAFE_NO_PAD as B64_URL};
use base64::Engine;
use pma_core::Credential;
use rand::RngCore;
use reqwest::Client;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const ICEDRIVE_ORIGIN: &str = "https://icedrive.net";
const ICEDRIVE_API: &str = "https://icedrive.net/API/Internal/V1/";
const ICEDRIVE_MOBILE_API: &str = "https://apis.icedrive.net/v3/mobile/api";
const ICEDRIVE_MOBILE_BASE: &str = "https://apis.icedrive.net/v3/mobile";
const ICEDRIVE_BEARER_PREFIX: &str = "bearer:";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        icedrive_inventory(cfg, client, cred)
    })
    .await
}

pub async fn download_filtered_files(
    cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let session = inv
        .session_secret
        .as_deref()
        .context("icedrive: missing session for download")?;
    let mut curl = CloudCurlSession::new()?;
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    for file in picks {
        let Some(uid) = file.remote_id.as_deref() else {
            continue;
        };
        let dl = match icedrive_resolve_download_url(cfg, &mut curl, session, uid).await {
            Ok(u) => u,
            Err(_) => continue,
        };
        let leaf = if file.path.is_empty() {
            file.name.clone()
        } else {
            file.path.replace('/', "\\")
        };
        match dispatch_download::write_leaf(cred, run_output_dir, &leaf, &client, &dl).await {
            Ok((path, n)) => {
                count += 1;
                total += n;
                paths.push(path);
            }
            Err(_) => continue,
        }
    }
    Ok((count, total, paths))
}

async fn icedrive_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let secret = cred.password.trim().to_string();

    let mut curl = CloudCurlSession::new()?;
    let session = if let Some(token) = secret.strip_prefix("icedrive:") {
        token.trim().to_string()
    } else {
        icedrive_login(cfg, &mut curl, &email, &secret).await?
    };

    let mut files = Vec::new();
    if icedrive_session_is_bearer(&session) {
        icedrive_walk_mobile_collection(cfg, &mut curl, &session, 0, "", &mut files).await?;
    } else {
        icedrive_walk_collection(cfg, &mut curl, &session, "0", "", &mut files).await?;
    }

    let mut inv = inventory_from_account(&email, files, 0, 0, "Free");
    inv.session_secret = Some(session);
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# Icedrive: encrypted vault may hide listing; combo: password `icedrive:COOKIE` (value of icedrive=… from browser)\n"
                .into(),
        );
    }
    Ok(inv)
}

async fn icedrive_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    let warmup_referer = format!("{ICEDRIVE_ORIGIN}/");
    let warmup_headers = [
        ("Origin", ICEDRIVE_ORIGIN),
        ("Referer", warmup_referer.as_str()),
        ("X-Requested-With", "XMLHttpRequest"),
    ];
    let _ = curl
        .get_text(
            cfg,
            "icedrive login page",
            &format!("{ICEDRIVE_ORIGIN}/login"),
            &warmup_headers,
            true,
        )
        .await;

    if let Ok(token) = icedrive_v1_login(cfg, curl, email, password).await {
        return Ok(token);
    }

    icedrive_mobile_pow_login(cfg, curl, email, password)
        .await
        .context("icedrive mobile PoW login")
}

async fn icedrive_v1_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    let url = format!("{ICEDRIVE_API}?request=login");
    let payload = json!({ "email": email, "password": password });
    let referer = format!("{ICEDRIVE_ORIGIN}/login");
    let login_headers = [
        ("Origin", ICEDRIVE_ORIGIN),
        ("Referer", referer.as_str()),
        ("X-Requested-With", "XMLHttpRequest"),
    ];
    let (status, body) = curl
        .post_json(
            cfg,
            "icedrive login",
            &url,
            &payload,
            &login_headers,
        )
        .await
        .context("icedrive login")?;

    if body.get("error").and_then(|x| x.as_bool()) == Some(true) {
        let msg = body
            .get("message")
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        return Err(cloud_auth_error(format!("icedrive: {msg}")));
    }
    if status == 401 || status == 403 {
        return Err(cloud_auth_error("icedrive: invalid email or password"));
    }
    body.get("token")
        .and_then(|x| x.as_str())
        .map(str::trim)
        .filter(|t| !t.is_empty())
        .map(str::to_string)
        .ok_or_else(|| cloud_auth_error("icedrive: login needs PoW/captcha or session combo"))
}

async fn icedrive_mobile_pow_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    let pow_form = "app=ios&request=pow-new&scope=login";
    let (status, text) = curl
        .post_body(
            cfg,
            "icedrive pow-new",
            ICEDRIVE_MOBILE_API,
            pow_form.as_bytes().to_vec(),
            "application/x-www-form-urlencoded",
            &[("User-Agent", "icedrive-ios/2.3.1")],
            false,
        )
        .await
        .context("icedrive pow-new")?;
    let challenge = parse_json_text(cfg.provider, status, &text, "icedrive pow-new")?;
    let difficulty = challenge
        .get("difficultyBits")
        .and_then(|x| x.as_i64())
        .unwrap_or(0);
    let challenge_b64 = challenge
        .get("challenge")
        .and_then(|x| x.as_str())
        .ok_or_else(|| anyhow!("icedrive pow-new: missing challenge"))?
        .to_string();

    let (nonce_b64, hash_hex) = tokio::task::spawn_blocking(move || {
        solve_icedrive_pow(&challenge_b64, difficulty)
    })
    .await
    .context("icedrive pow join")?
    .context("icedrive pow solve")?;

    let pow_inner = json!({
        "client_id": "",
        "token": challenge.get("token"),
        "challenge": challenge.get("challenge"),
        "ver": "1",
        "hash": hash_hex,
        "nonce": nonce_b64,
        "exp": challenge.get("exp"),
        "difficultyBits": challenge.get("difficultyBits"),
        "scope": challenge.get("scope"),
    });
    let pow_proof = B64_STD.encode(serde_json::to_vec(&pow_inner)?);

    let login_form = format!(
        "password={}&pow_proof={}&request=login&email={}&no_token_check=true&app=ios",
        urlencoding_encode(password),
        urlencoding_encode(&pow_proof),
        urlencoding_encode(email),
    );
    let (login_status, login_text) = curl
        .post_body(
            cfg,
            "icedrive mobile login",
            ICEDRIVE_MOBILE_API,
            login_form.into_bytes(),
            "application/x-www-form-urlencoded",
            &[("User-Agent", "icedrive-ios/2.3.1")],
            false,
        )
        .await
        .context("icedrive mobile login")?;
    let login_json = parse_json_text(cfg.provider, login_status, &login_text, "icedrive mobile login")?;
    login_json
        .get("token")
        .and_then(|x| x.as_str())
        .map(str::trim)
        .filter(|t| !t.is_empty())
        .map(|t| format!("{ICEDRIVE_BEARER_PREFIX}{t}"))
        .ok_or_else(|| cloud_auth_error("icedrive: mobile login failed (2FA or bad combo)"))
}

fn icedrive_session_is_bearer(session: &str) -> bool {
    session.starts_with(ICEDRIVE_BEARER_PREFIX)
}

fn icedrive_bearer_token(session: &str) -> &str {
    session
        .strip_prefix(ICEDRIVE_BEARER_PREFIX)
        .unwrap_or(session)
}

async fn icedrive_walk_mobile_collection(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &str,
    folder_id: u64,
    prefix: &str,
    out: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let token = icedrive_bearer_token(session);
    let auth = format!("Bearer {token}");
    let mut queue: VecDeque<(u64, String)> = VecDeque::from([(folder_id, prefix.to_string())]);
    while let Some((fid, pref)) = queue.pop_front() {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let url = format!("{ICEDRIVE_MOBILE_BASE}/collection?type=cloud&folderId={fid}");
        let Ok(v) = curl
            .get_json(
                cfg,
                "icedrive mobile collection",
                &url,
                &[
                    ("Authorization", auth.as_str()),
                    ("User-Agent", "icedrive-ios/2.3.1"),
                ],
            )
            .await
        else {
            continue;
        };
        let items = v
            .get("data")
            .and_then(|x| x.as_array())
            .cloned()
            .unwrap_or_default();
        for item in items {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = item
                .get("filename")
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let uid = item.get("uid").and_then(|x| x.as_str()).unwrap_or("");
            let is_folder = item.get("isFolder").and_then(|x| x.as_i64()).unwrap_or(0) == 1;
            let path = format!("{pref}{name}");
            if is_folder {
                if let Some(id) = item.get("id").and_then(|x| x.as_u64()) {
                    queue.push_back((id, format!("{path}/")));
                }
                continue;
            }
            let size = item.get("filesize").and_then(|x| x.as_u64()).unwrap_or(0);
            let mut meta = CloudFileMeta::new(name, size, path);
            if !uid.is_empty() {
                meta = meta.with_remote_id(uid);
            }
            out.push(meta);
        }
    }
    Ok(())
}

fn urlencoding_encode(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}

async fn icedrive_resolve_download_url(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &str,
    file_uid: &str,
) -> Result<String> {
    if icedrive_session_is_bearer(session) {
        return icedrive_mobile_download_url(cfg, curl, session, file_uid).await;
    }
    let url = format!(
        "{ICEDRIVE_API}?request=download-multi&items={file_uid}&sess=1"
    );
    let cookie = format!("icedrive={session}");
    let v = curl
        .get_json(
            cfg,
            "icedrive download-multi",
            &url,
            &[
                ("Referer", &format!("{ICEDRIVE_ORIGIN}/dashboard/")),
                ("Cookie", cookie.as_str()),
            ],
        )
        .await
        .context("icedrive download-multi")?;
    icedrive_download_url_from_multi(&v).ok_or_else(|| anyhow!("icedrive: no download url"))
}

async fn icedrive_mobile_download_url(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &str,
    file_uid: &str,
) -> Result<String> {
    let token = icedrive_bearer_token(session);
    let item = if file_uid.starts_with("file-") {
        file_uid.to_string()
    } else {
        format!("file-{file_uid}")
    };
    let boundary = "icedrive-boundary";
    let body = format!(
        "--{boundary}\r\nContent-Disposition: form-data; name=\"items\"\r\n\r\n{item}\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"crypto\"\r\n\r\n0\r\n--{boundary}--\r\n"
    );
    let content_type = format!("multipart/form-data; boundary={boundary}");
    let auth = format!("Bearer {token}");
    let (status, text) = curl
        .post_body(
            cfg,
            "icedrive mobile download-multi",
            &format!("{ICEDRIVE_MOBILE_BASE}/download-multi"),
            body.into_bytes(),
            &content_type,
            &[
                ("Authorization", auth.as_str()),
                ("User-Agent", "icedrive-ios/2.3.1"),
            ],
            false,
        )
        .await
        .context("icedrive mobile download-multi")?;
    let v = parse_json_text(cfg.provider, status, &text, "icedrive mobile download-multi")?;
    icedrive_download_url_from_multi(&v).ok_or_else(|| anyhow!("icedrive: no mobile download url"))
}

pub fn icedrive_download_url_from_multi(v: &Value) -> Option<String> {
    v.get("urls")
        .and_then(|x| x.as_array())
        .and_then(|arr| arr.first())
        .and_then(|item| item.get("url"))
        .and_then(|x| x.as_str())
        .map(str::to_string)
}

async fn icedrive_walk_collection(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &str,
    folder_id: &str,
    prefix: &str,
    out: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let mut queue: VecDeque<(String, String)> = VecDeque::from([(folder_id.to_string(), prefix.to_string())]);
    while let Some((fid, pref)) = queue.pop_front() {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let url = format!(
            "{ICEDRIVE_API}?request=collection&type=cloud&folderId={fid}&sess=1"
        );
        let cookie = format!("icedrive={session}");
        let Ok(v) = curl
            .get_json(
                cfg,
                "icedrive collection",
                &url,
                &[
                    ("Referer", &format!("{ICEDRIVE_ORIGIN}/dashboard/")),
                    ("Cookie", cookie.as_str()),
                ],
            )
            .await
        else {
            continue;
        };
        let items = icedrive_items_array(&v);
        for item in items {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = item
                .get("filename")
                .or_else(|| item.get("name"))
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let uid = item
                .get("uid")
                .or_else(|| item.get("id"))
                .and_then(|x| x.as_str())
                .unwrap_or("");
            let is_folder = item
                .get("isFolder")
                .or_else(|| item.get("is_folder"))
                .and_then(|x| x.as_bool())
                .unwrap_or_else(|| uid.starts_with("folder-"));
            let path = format!("{pref}{name}");
            if is_folder {
                if !uid.is_empty() {
                    queue.push_back((uid.to_string(), format!("{path}/")));
                }
                continue;
            }
            let size = item
                .get("size")
                .or_else(|| item.get("filesize"))
                .and_then(|x| x.as_u64())
                .unwrap_or(0);
            let mut meta = CloudFileMeta::new(name, size, path);
            if !uid.is_empty() {
                meta = meta.with_remote_id(uid);
            }
            out.push(meta);
        }
    }
    Ok(())
}

fn icedrive_items_array(v: &Value) -> Vec<Value> {
    if let Some(arr) = v.get("data").and_then(|x| x.as_array()) {
        return arr.clone();
    }
    if let Some(arr) = v.as_array() {
        return arr.clone();
    }
    if let Some(arr) = v.get("items").and_then(|x| x.as_array()) {
        return arr.clone();
    }
    Vec::new()
}

pub fn count_leading_zero_bits(data: &[u8]) -> u32 {
    let mut count = 0u32;
    for &b in data {
        if b == 0 {
            count += 8;
        } else {
            for bit in (0..8).rev() {
                if (b >> bit) & 1 == 0 {
                    count += 1;
                } else {
                    return count;
                }
            }
        }
    }
    count
}

pub fn solve_icedrive_pow(challenge_b64: &str, difficulty_bits: i64) -> Result<(String, String)> {
    let difficulty_bits = difficulty_bits as u32;
    if difficulty_bits == 0 || difficulty_bits > 256 {
        anyhow::bail!("invalid difficulty bits");
    }
    let challenge_bytes = B64_URL
        .decode(challenge_b64)
        .or_else(|_| B64_URL.decode(challenge_b64.trim_end_matches('=')))
        .context("decode pow challenge")?;
    let nonce_size = 12usize;
    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let mut buf = Vec::with_capacity(challenge_bytes.len() + nonce_size + 4);
    buf.extend_from_slice(&challenge_bytes);
    buf.extend_from_slice(&nonce_bytes);
    buf.resize(challenge_bytes.len() + nonce_size + 4, 0);

    let counter_offset = challenge_bytes.len() + nonce_size;
    for counter in 0u32.. {
        buf[counter_offset] = (counter >> 24) as u8;
        buf[counter_offset + 1] = (counter >> 16) as u8;
        buf[counter_offset + 2] = (counter >> 8) as u8;
        buf[counter_offset + 3] = counter as u8;
        let hash = Sha256::digest(&buf);
        if count_leading_zero_bits(&hash) >= difficulty_bits {
            let mut nonce_result = Vec::with_capacity(nonce_size + 4);
            nonce_result.extend_from_slice(&nonce_bytes);
            nonce_result.extend_from_slice(&buf[counter_offset..counter_offset + 4]);
            let nonce_b64 = B64_URL.encode(&nonce_result);
            let hash_hex = hex::encode(hash);
            return Ok((nonce_b64, hash_hex));
        }
        if counter == u32::MAX {
            anyhow::bail!("pow counter overflow");
        }
    }
    unreachable!()
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn leading_zero_bits_empty_hash() {
        assert_eq!(count_leading_zero_bits(&[0, 0, 0]), 24);
        assert_eq!(count_leading_zero_bits(&[0, 0, 1]), 23);
    }

    #[test]
    fn download_url_from_multi_json() {
        let v: Value = serde_json::from_str(
            r#"{"error":false,"urls":[{"url":"https://icecube.example/download?p=x"}]}"#,
        )
        .unwrap();
        assert_eq!(
            icedrive_download_url_from_multi(&v).as_deref(),
            Some("https://icecube.example/download?p=x")
        );
    }
}
