﻿//! Nimbus Note / FuseBase (Nimbus Notes cloud provider).
//!
//! Combo: `email:password` (web login).
//! Session reuse: `email:nimbus:SESSION_ID` or `email:nimbus:SESSION_ID:api.host.nimbusweb.me`.
//!
//! Flow mirrors the public [nimbus-note-exporter](https://github.com/thecodrr/nimbus-note-exporter):
//! auth → `eversessionid` cookie → organizations/workspaces on `teams.nimbusweb.me` → notes on user API host.

use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use reqwest::Method;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};

const AUTH_PAGE: &str = "https://app.nimbusweb.me/auth/";
const AUTH_API_APP: &str = "https://app.nimbusweb.me/auth/api/auth";
const AUTH_API_ROOT: &str = "https://nimbusweb.me/auth/api/auth";
const TEAMS_HOST: &str = "teams.nimbusweb.me";
const ORIGIN: &str = "https://app.nimbusweb.me";
const CLIENT_REFERER: &str = "https://app.nimbusweb.me/client";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        nimbus_inventory(cfg, client, cred)
    })
    .await
}

struct NimbusSession {
    session_id: String,
    api_domain: String,
}

async fn nimbus_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let mut curl = CloudCurlSession::new()?;
    curl.set_browser_profile(cloud_browser_profile());

    let session = nimbus_authenticate(cfg, &mut curl, &cred).await?;
    curl.seed_cookie("eversessionid", &session.session_id);

    let files = nimbus_list_all_notes(cfg, &mut curl, &session).await;
    let total_size: u64 = files.iter().map(|f| f.size).sum();
    let mut inv = inventory_from_account(&email, files, total_size, 0, "Nimbus");
    inv.session_secret = Some(format!(
        "nimbus:{}:{}",
        session.session_id, session.api_domain
    ));
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# Nimbus: login OK, но список заметок пуст (права/workspace или API изменился).\n"
                .into(),
        );
    }
    Ok(inv)
}

fn cloud_browser_profile() -> Vec<(String, String)> {
    vec![
        (
            "User-Agent".to_string(),
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0"
                .to_string(),
        ),
        ("Accept".to_string(), "*/*".to_string()),
        (
            "Accept-Language".to_string(),
            "en-GB,en;q=0.5".to_string(),
        ),
    ]
}

async fn nimbus_authenticate(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    cred: &Credential,
) -> Result<NimbusSession> {
    if let Some(parsed) = parse_nimbus_session_secret(cred.password.trim()) {
        return Ok(parsed);
    }

    let _ = curl
        .get_text(cfg, "nimbus auth page", AUTH_PAGE, &[], true)
        .await
        .context("nimbus auth page")?;

    let payload = json!({
        "login": cred.username,
        "password": cred.password,
    });
    let refs = [("Referer", AUTH_PAGE), ("Origin", ORIGIN)];

    let mut last_err: Option<anyhow::Error> = None;
    for url in [AUTH_API_APP, AUTH_API_ROOT] {
        match nimbus_try_login(cfg, curl, url, &payload, &refs).await {
            Ok(session) => return Ok(session),
            Err(e) => last_err = Some(e),
        }
    }
    Err(last_err.unwrap_or_else(|| anyhow::anyhow!("nimbus login failed")))
}

fn parse_nimbus_session_secret(secret: &str) -> Option<NimbusSession> {
    let rest = secret.strip_prefix("nimbus:")?;
    let (session_id, domain) = if let Some((sid, host)) = rest.split_once(':') {
        (sid.trim(), host.trim())
    } else {
        (rest.trim(), "")
    };
    if session_id.is_empty() {
        return None;
    }
    Some(NimbusSession {
        session_id: session_id.to_string(),
        api_domain: if domain.is_empty() {
            "app.nimbusweb.me".to_string()
        } else {
            domain.to_string()
        },
    })
}

async fn nimbus_try_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    url: &str,
    payload: &Value,
    refs: &[(&str, &str)],
) -> Result<NimbusSession> {
    let (status, v) = curl
        .post_json(cfg, "nimbus auth", url, payload, refs)
        .await
        .context("nimbus auth POST")?;

    if status == 429 {
        return Err(cloud_rate_limit_error("nimbus auth rate limited"));
    }

    if let Some(code) = v.get("errorCode").and_then(|x| x.as_i64()) {
        if code != 0 {
            if let Some(ch) = v.pointer("/body/challenge") {
                let kind = ch.get("type").and_then(|x| x.as_str()).unwrap_or("?");
                return Err(cloud_auth_error(format!(
                    "nimbus: challenge ({kind}) — 2FA/captcha/email code"
                )));
            }
            let desc = v
                .pointer("/body/_errorDesc")
                .or_else(|| v.pointer("/body/error"))
                .or_else(|| v.get("message"))
                .and_then(|x| x.as_str())
                .unwrap_or("login failed");
            return Err(cloud_auth_error(format!("nimbus: {desc} (errorCode {code})")));
        }
    } else if let Some(code) = v.get("error").and_then(|x| x.as_i64()) {
        if code != 0 {
            return Err(cloud_auth_error(format!("nimbus: login error {code}")));
        }
    } else if !(200..300).contains(&status) {
        return Err(cloud_auth_error(format!("nimbus: HTTP {status}")));
    }

    let session_id = v
        .pointer("/body/sessionId")
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
        .context("nimbus: missing body.sessionId")?
        .to_string();

    curl.seed_cookie("eversessionid", &session_id);
    let api_domain = nimbus_resolve_api_domain(cfg, curl, &session_id).await?;
    Ok(NimbusSession {
        session_id,
        api_domain,
    })
}

async fn nimbus_resolve_api_domain(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session_id: &str,
) -> Result<String> {
    curl.seed_cookie("eversessionid", session_id);
    let refs = [("Referer", CLIENT_REFERER)];
    for base in ["https://nimbusweb.me", "https://app.nimbusweb.me"] {
        let url = format!("{base}/client?t=regfsour:header");
        if let Ok((status, _, _)) = curl
            .exchange(
                cfg,
                "nimbus domain HEAD",
                Method::HEAD,
                &url,
                None,
                &refs,
                true,
            )
            .await
        {
            if (200..400).contains(&status) {
                if base.contains("app.") {
                    return Ok("app.nimbusweb.me".to_string());
                }
            }
        }
    }
    Ok("app.nimbusweb.me".to_string())
}

async fn nimbus_list_all_notes(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &NimbusSession,
) -> Vec<CloudFileMeta> {
    let mut out = Vec::new();
    let teams_refs = [("Referer", CLIENT_REFERER), ("Origin", ORIGIN)];

    let orgs_url = format!("https://{TEAMS_HOST}/api/organizations");
    let Ok((status, org_body)) = curl
        .get_text(cfg, "nimbus orgs", &orgs_url, &teams_refs, false)
        .await
    else {
        nimbus_fetch_notes_legacy(cfg, curl, session, &mut out).await;
        return out;
    };
    if !(200..300).contains(&status) {
        nimbus_fetch_notes_legacy(cfg, curl, session, &mut out).await;
        return out;
    }

    let Ok(orgs) = serde_json::from_str::<Value>(&org_body) else {
        nimbus_fetch_notes_legacy(cfg, curl, session, &mut out).await;
        return out;
    };
    let Some(org_list) = orgs.as_array() else {
        nimbus_fetch_notes_legacy(cfg, curl, session, &mut out).await;
        return out;
    };

    for org in org_list {
        let Some(org_id) = pick_string(org, &["globalId", "id"]) else {
            continue;
        };
        let ws_url = format!("https://{TEAMS_HOST}/api/workspaces/{org_id}");
        let Ok((ws_status, ws_body)) = curl
            .get_text(cfg, "nimbus workspaces", &ws_url, &teams_refs, false)
            .await
        else {
            continue;
        };
        if !(200..300).contains(&ws_status) {
            continue;
        }
        let Ok(workspaces) = serde_json::from_str::<Value>(&ws_body) else {
            continue;
        };
        let Some(ws_arr) = workspaces.as_array() else {
            continue;
        };
        for ws in ws_arr {
            if out.len() >= MAX_CLOUD_LIST_LINES {
                return out;
            }
            let Some(ws_id) = pick_string(ws, &["globalId", "id"]) else {
                continue;
            };
            let notes_count = pick_u64(ws, &["notesCount", "notes_count"]) as usize;
            if notes_count == 0 {
                continue;
            }
            nimbus_fetch_workspace_notes(cfg, curl, session, &ws_id, notes_count, &mut out).await;
        }
    }

    if out.is_empty() {
        nimbus_fetch_notes_legacy(cfg, curl, session, &mut out).await;
    }
    out
}

async fn nimbus_fetch_workspace_notes(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &NimbusSession,
    workspace_id: &str,
    notes_count: usize,
    out: &mut Vec<CloudFileMeta>,
) {
    let page_size = 500usize;
    let mut offset = 0usize;
    let api_refs = [("Referer", CLIENT_REFERER), ("Origin", ORIGIN)];

    while offset < notes_count && out.len() < MAX_CLOUD_LIST_LINES {
        let range = json!({ "limit": page_size, "offset": offset });
        let url = format!(
            "https://{}/api/workspaces/{workspace_id}/notes?range={}",
            session.api_domain,
            serde_json::to_string(&range).unwrap_or_else(|_| "{}".into())
        );
        let Ok((status, body)) = curl
            .get_text(cfg, "nimbus notes page", &url, &api_refs, false)
            .await
        else {
            break;
        };
        if !(200..300).contains(&status) {
            break;
        }
        let before = out.len();
        nimbus_collect_notes_json(&body, workspace_id, out);
        if out.len() == before {
            break;
        }
        offset += page_size;
    }
}

async fn nimbus_fetch_notes_legacy(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    session: &NimbusSession,
    out: &mut Vec<CloudFileMeta>,
) {
    let urls = [
        format!("https://{}/v2/api/notes", session.api_domain),
        format!("https://{}/v2/api/note/list", session.api_domain),
        "https://app.nimbusweb.me/v2/api/notes".to_string(),
    ];
    let refs = [("Referer", CLIENT_REFERER), ("Origin", ORIGIN)];
    for url in urls {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let Ok((status, body)) = curl.get_text(cfg, "nimbus notes legacy", &url, &refs, true).await
        else {
            continue;
        };
        if !(200..300).contains(&status) {
            continue;
        }
        let before = out.len();
        nimbus_collect_notes_json(&body, "", out);
        if out.len() > before {
            break;
        }
    }
}

fn nimbus_collect_notes_json(body: &str, workspace_id: &str, out: &mut Vec<CloudFileMeta>) {
    let trimmed = body.trim();
    if trimmed.is_empty() {
        return;
    }
    let Ok(v) = serde_json::from_str::<Value>(trimmed) else {
        return;
    };

    if let Some(arr) = v.as_array() {
        for item in arr {
            push_note_item(item, workspace_id, out);
        }
        return;
    }

    for key in ["notes", "items", "data", "body"] {
        if let Some(arr) = v.get(key).and_then(|x| x.as_array()) {
            for item in arr {
                push_note_item(item, workspace_id, out);
            }
            if !out.is_empty() {
                return;
            }
        }
    }

    let mut arrays: Vec<&Value> = Vec::new();
    collect_arrays(&v, &mut arrays, 0);
    for arr_val in arrays {
        let Some(arr) = arr_val.as_array() else {
            continue;
        };
        for item in arr {
            push_note_item(item, workspace_id, out);
        }
    }
}

fn push_note_item(item: &Value, workspace_id: &str, out: &mut Vec<CloudFileMeta>) {
    if out.len() >= MAX_CLOUD_LIST_LINES {
        return;
    }
    if !item.is_object() {
        return;
    }
    let note_type = pick_string(item, &["type"]).unwrap_or_default();
    if note_type.eq_ignore_ascii_case("folder") {
        return;
    }
    let title = pick_string(item, &["title", "name", "subject", "fileName"])
        .unwrap_or_else(|| "note".to_string());
    let id = pick_string(item, &["globalId", "Id", "id", "noteId", "uuid"]).unwrap_or_default();
    let ws = pick_string(item, &["workspaceId"]).unwrap_or_else(|| workspace_id.to_string());
    let size = pick_u64(item, &["size", "fileSize", "contentLength", "bytes"]);
    let path = if id.is_empty() {
        title.clone()
    } else if ws.is_empty() {
        format!("{id}/{title}")
    } else {
        format!("{ws}/{id}/{title}")
    };
    let mut meta = CloudFileMeta::new(title, size, path);
    if !id.is_empty() {
        meta = meta.with_remote_id(id);
    }
    let tags = item
        .get("tags")
        .and_then(|t| t.as_array())
        .map(|a| {
            a.iter()
                .filter_map(|x| x.as_str())
                .collect::<Vec<_>>()
                .join(",")
        })
        .unwrap_or_default();
    if !tags.is_empty() {
        meta = meta.with_keyword_extra(tags);
    }
    out.push(meta);
}

fn value_as_string(v: &Value) -> Option<String> {
    match v {
        Value::String(s) => {
            let t = s.trim();
            if t.is_empty() {
                None
            } else {
                Some(t.to_string())
            }
        }
        Value::Number(n) => Some(n.to_string()),
        Value::Bool(b) => Some(b.to_string()),
        _ => None,
    }
}

fn pick_string(item: &Value, keys: &[&str]) -> Option<String> {
    for k in keys {
        if let Some(v) = item.get(*k) {
            if let Some(s) = value_as_string(v) {
                return Some(s);
            }
        }
    }
    None
}

fn pick_u64(item: &Value, keys: &[&str]) -> u64 {
    for k in keys {
        if let Some(v) = item.get(*k) {
            if let Some(n) = v.as_u64() {
                return n;
            }
            if let Some(n) = v.as_i64() {
                if n >= 0 {
                    return n as u64;
                }
            }
            if let Some(s) = v.as_str() {
                if let Ok(n) = s.trim().parse::<u64>() {
                    return n;
                }
            }
        }
    }
    0
}

fn collect_arrays<'a>(v: &'a Value, out: &mut Vec<&'a Value>, depth: usize) {
    if depth > 6 {
        return;
    }
    match v {
        Value::Array(_) => out.push(v),
        Value::Object(map) => {
            for (_, child) in map {
                collect_arrays(child, out, depth + 1);
            }
        }
        _ => {}
    }
}
