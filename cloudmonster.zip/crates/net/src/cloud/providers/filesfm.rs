﻿//! Files.fm cloud inventory via legacy API V1 (`api.files.fm`).
//!
//! Local smoke tests: use your own combo file **outside the repo** (one `email:password` line);
//! never commit credentials or put them in `.env` / source.

use crate::cloud::common::{
    cloud_auth_error, cloud_network_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, parse_json_text, CloudCurlSession};
use crate::cloud::dispatch_download;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const API_ORIGIN: &str = "https://api.files.fm";
const FF_API_HEADERS: &[(&str, &str)] = &[
    ("Accept", "application/json, text/plain, */*"),
    ("Origin", "https://files.fm"),
    ("Referer", "https://files.fm/"),
];

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        filesfm_inventory(cfg, client, cred)
    })
    .await
}

pub async fn download_filtered_files(
    _cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let session_id = inv
        .session_secret
        .as_deref()
        .context("files.fm session")?;
    let email = cred.username.as_str();
    let password = cred.password.as_str();
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    for file in picks {
        let Some(file_hash) = file.remote_id.as_deref() else {
            continue;
        };
        let url = build_url(
            &format!("{API_ORIGIN}/down.php"),
            &[
                ("i", file_hash),
                ("user", email),
                ("pass", password),
                ("PHPSESSID", session_id),
            ],
        )?;
        match dispatch_download::write_leaf(cred, run_output_dir, &file.name, &client, &url).await
        {
            Ok((path, n)) => {
                count += 1;
                total += n;
                paths.push(path);
            }
            Err(_) => continue,
        }
    }
    Ok((count, total, paths))
}

async fn filesfm_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let session = filesfm_login(cfg, &mut curl, &email, &password).await?;
    let mut files =
        list_all_files(cfg, &mut curl, &email, &password, &session).await?;
    if files.len() > MAX_CLOUD_LIST_LINES {
        files.truncate(MAX_CLOUD_LIST_LINES);
    }
    let total_bytes: u64 = files.iter().map(|f| f.size).sum();
    let mut inv = inventory_from_account(
        &email,
        files,
        total_bytes,
        session.quota_bytes,
        session.tariff,
    );
    inv.session_secret = Some(session.session_id);
    Ok(inv)
}

struct FilesfmSession {
    root_hash: String,
    root_delete_key: String,
    session_id: String,
    user_id: String,
    quota_bytes: u64,
    tariff: String,
}

async fn filesfm_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<FilesfmSession> {
    // Primary API — do not fall back to login.php on Bad creds (returns HTTP 200 + empty body → misleading "empty login response").
    auth_via_authenticate_user(cfg, curl, email, password).await
}

async fn auth_via_authenticate_user(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<FilesfmSession> {
    let url = build_url(
        &format!("{API_ORIGIN}/api/authenticate_user.php"),
        &[("user", email), ("pass", password)],
    )?;
    let (status, text) = curl
        .get_text(cfg, "files.fm authenticate", &url, FF_API_HEADERS, false)
        .await
        .context("files.fm authenticate")?;
    check_filesfm_rate_limit(status, &text)?;
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Err(cloud_network_error(format!(
            "files.fm authenticate: empty body (http {status})"
        )));
    }
    if trimmed.starts_with('<') {
        return Err(cloud_network_error(format!(
            "files.fm authenticate: HTML response (proxy/block?) http {status}"
        )));
    }
    let body: Value = parse_json_text(cfg.provider, status, &text, "files.fm authenticate")?;
    let mut session = parse_auth_json(&body)?;
    if session.session_id.is_empty() {
        session.session_id = curl
            .cookie_value("PHPSESSID")
            .unwrap_or("")
            .to_string();
    }
    Ok(session)
}

fn parse_auth_json(body: &Value) -> Result<FilesfmSession> {
    if body
        .get("Status")
        .and_then(|x| x.as_str())
        .is_some_and(|s| s.eq_ignore_ascii_case("two_factor_auth_required"))
    {
        return Err(cloud_auth_error(
            "two-factor authentication required (confirm email link from same IP)",
        ));
    }
    let success = body.get("Success").and_then(|x| x.as_bool()).unwrap_or(false);
    if !success {
        let msg = body
            .get("Message")
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        let normalized = if msg.to_ascii_lowercase().contains("login failed") {
            "invalid login or password"
        } else {
            msg
        };
        return Err(cloud_auth_error(normalized));
    }
    let ud = body
        .get("UserData")
        .or_else(|| body.get("userdata"))
        .cloned()
        .unwrap_or_else(|| body.clone());
    let root_hash = pick_str(&ud, &["root_upload_hash", "RootUploadHash", "hash"])
        .ok_or_else(|| anyhow!("files.fm: missing root_upload_hash"))?;
    let root_delete_key = pick_str(&ud, &["root_upload_key", "RootUploadKey", "delete_key"])
        .unwrap_or_default();
    let user_id = pick_str(&ud, &["ID", "id", "Email", "email"])
        .unwrap_or_else(|| "filesfm".to_string());
    let session_id = body
        .get("SessionID")
        .and_then(|x| x.as_str())
        .unwrap_or("")
        .to_string();
    let quota = ud
        .get("file_size_limit")
        .and_then(parse_u64_value)
        .unwrap_or(0);
    Ok(FilesfmSession {
        root_hash,
        root_delete_key,
        session_id,
        user_id,
        quota_bytes: quota,
        tariff: "Free".to_string(),
    })
}

fn parse_login_plain(text: &str, curl: &CloudCurlSession) -> Result<FilesfmSession> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Err(cloud_auth_error("empty login response"));
    }
    let lower = trimmed.to_lowercase();
    if lower.contains("error: incorrect login") || lower.contains("error:no_user") {
        return Err(cloud_auth_error("invalid login or password"));
    }
    if lower.starts_with("error:") {
        return Err(cloud_auth_error(trimmed.trim_start_matches("error:").trim()));
    }
    let payload = trimmed
        .strip_prefix("cookie:")
        .unwrap_or(trimmed)
        .trim();
    let mut root_hash = None;
    let mut root_delete_key = None;
    let mut user_id = None;
    let mut session_id = None;
    for part in payload.split(';') {
        let part = part.trim();
        let Some((k, v)) = part.split_once('=') else {
            continue;
        };
        match k.trim() {
            "root_upload_hash" => root_hash = Some(v.to_string()),
            "root_upload_key" => root_delete_key = Some(v.to_string()),
            "ID" => user_id = Some(v.to_string()),
            "PHPSESSID" => session_id = Some(v.to_string()),
            _ => {}
        }
    }
    if session_id.is_none() {
        session_id = curl.cookie_value("PHPSESSID").map(|s| s.to_string());
    }
    let root_hash =
        root_hash.ok_or_else(|| cloud_auth_error("login ok but root_upload_hash missing"))?;
    Ok(FilesfmSession {
        root_hash,
        root_delete_key: root_delete_key.unwrap_or_default(),
        session_id: session_id.unwrap_or_default(),
        user_id: user_id.unwrap_or_else(|| "filesfm".to_string()),
        quota_bytes: 0,
        tariff: "Free".to_string(),
    })
}

async fn list_all_files(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
    session: &FilesfmSession,
) -> Result<Vec<CloudFileMeta>> {
    if !session.root_delete_key.is_empty() {
        if let Ok(files) = list_via_upload_tree(cfg, curl, email, password, session).await {
            if !files.is_empty() {
                return Ok(files);
            }
        }
    }
    list_via_bfs(cfg, curl, email, password, &session.root_hash).await
}

async fn list_via_upload_tree(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
    session: &FilesfmSession,
) -> Result<Vec<CloudFileMeta>> {
    let url = build_url(
        &format!("{API_ORIGIN}/api/get_upload_tree.php"),
        &[
            ("Hash", session.root_hash.as_str()),
            ("DeleteKey", session.root_delete_key.as_str()),
            ("user", email),
            ("pass", password),
        ],
    )?;
    let (status, text) = curl
        .get_text(cfg, "files.fm upload tree", &url, FF_API_HEADERS, false)
        .await?;
    check_filesfm_rate_limit(status, &text)?;
    let body = parse_json_text(cfg.provider, status, &text, "files.fm upload tree")?;
    if body
        .get("error")
        .and_then(|x| x.as_str())
        .is_some_and(|e| !e.is_empty())
    {
        anyhow::bail!("files.fm tree: {}", body.get("error").and_then(|x| x.as_str()).unwrap_or("error"));
    }
    let mut out = Vec::new();
    if let Some(data) = body.get("data") {
        walk_tree_node(data, "", &mut out);
    }
    Ok(out)
}

fn walk_tree_node(node: &Value, prefix: &str, out: &mut Vec<CloudFileMeta>) {
    if out.len() >= MAX_CLOUD_LIST_LINES {
        return;
    }
    let ty = node
        .get("Type")
        .or_else(|| node.get("type"))
        .and_then(|x| x.as_str())
        .unwrap_or("");
    let name = node
        .get("Name")
        .or_else(|| node.get("name"))
        .and_then(|x| x.as_str())
        .unwrap_or("");
    if ty.eq_ignore_ascii_case("File") && !name.is_empty() {
        let path = if prefix.is_empty() {
            name.to_string()
        } else {
            format!("{prefix}{name}")
        };
        let size = node
            .get("Size")
            .or_else(|| node.get("size"))
            .and_then(parse_u64_value)
            .unwrap_or(0);
        let hash = node
            .get("Hash")
            .or_else(|| node.get("hash"))
            .and_then(|x| x.as_str())
            .unwrap_or("");
        let mut meta = CloudFileMeta::new(name, size, path);
        if !hash.is_empty() {
            meta = meta.with_remote_id(hash);
        }
        out.push(meta);
        return;
    }
    if ty.eq_ignore_ascii_case("Folder") && !name.is_empty() && name != "ROOT" {
        let child_prefix = if prefix.is_empty() {
            format!("{name}/")
        } else {
            format!("{prefix}{name}/")
        };
        collect_tree_children(node.get("Children").or_else(|| node.get("children")), &child_prefix, out);
        return;
    }
    collect_tree_children(node.get("Children").or_else(|| node.get("children")), prefix, out);
}

fn collect_tree_children(children: Option<&Value>, prefix: &str, out: &mut Vec<CloudFileMeta>) {
    let Some(children) = children else {
        return;
    };
    if children.is_boolean() {
        return;
    }
    let Some(list) = children.as_array() else {
        return;
    };
    for child in list {
        walk_tree_node(child, prefix, out);
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
    }
}

async fn list_via_bfs(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
    root_hash: &str,
) -> Result<Vec<CloudFileMeta>> {
    let mut files = Vec::new();
    let mut queue: VecDeque<(String, String)> = VecDeque::new();
    queue.push_back((root_hash.to_string(), String::new()));
    while let Some((folder_hash, prefix)) = queue.pop_front() {
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let url = build_url(
            &format!("{API_ORIGIN}/api/get_file_list_for_upload.php"),
            &[
                ("hash", folder_hash.as_str()),
                ("include_folders", "1"),
                ("user", email),
                ("pass", password),
            ],
        )?;
        let (status, text) = curl
            .get_text(cfg, "files.fm folder list", &url, FF_API_HEADERS, false)
            .await?;
        if check_filesfm_rate_limit(status, &text).is_err() {
            continue;
        }
        let body = match parse_json_text(cfg.provider, status, &text, "files.fm folder list") {
            Ok(v) => v,
            Err(_) => continue,
        };
        let Some(items) = body.as_array() else {
            continue;
        };
        for item in items {
            let ty = item
                .get("type")
                .or_else(|| item.get("Type"))
                .and_then(|x| x.as_str())
                .unwrap_or("File");
            let name = item
                .get("name")
                .or_else(|| item.get("Name"))
                .and_then(|x| x.as_str())
                .unwrap_or("");
            if name.is_empty() {
                continue;
            }
            let hash = item
                .get("hash")
                .or_else(|| item.get("Hash"))
                .and_then(|x| x.as_str())
                .unwrap_or("");
            if ty.eq_ignore_ascii_case("Folder") {
                if !hash.is_empty() {
                    let next_prefix = format!("{prefix}{name}/");
                    queue.push_back((hash.to_string(), next_prefix));
                }
                continue;
            }
            let path = if prefix.is_empty() {
                name.to_string()
            } else {
                format!("{prefix}{name}")
            };
            let size = item
                .get("Size")
                .or_else(|| item.get("size"))
                .and_then(parse_u64_value)
                .unwrap_or(0);
            let mut meta = CloudFileMeta::new(name, size, path);
            if !hash.is_empty() {
                meta = meta.with_remote_id(hash);
            }
            files.push(meta);
        }
    }
    Ok(files)
}

fn check_filesfm_rate_limit(status: u16, body: &str) -> Result<()> {
    if status == 429 {
        return Err(cloud_rate_limit_error(format!("files.fm http {status}")));
    }
    let trimmed = body.trim();
    if trimmed.contains("rate_limited") || trimmed.contains("\"error\":\"rate_limited\"") {
        return Err(cloud_rate_limit_error("files.fm rate limited"));
    }
    Ok(())
}

fn pick_str(v: &Value, keys: &[&str]) -> Option<String> {
    for k in keys {
        if let Some(s) = v.get(*k).and_then(|x| x.as_str()) {
            if !s.is_empty() {
                return Some(s.to_string());
            }
        }
    }
    None
}

fn parse_u64_value(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use crate::cloud::config::CloudClientConfig;
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use url::Url;
    use std::time::Duration;

    #[test]
    fn parse_auth_json_login_failed_is_auth_not_empty() {
        let v = serde_json::json!({
            "Success": false,
            "Message": "Login failed!",
            "SessionID": null
        });
        let err = match parse_auth_json(&v) {
            Err(e) => e,
            Ok(_) => panic!("expected auth error"),
        };
        let t = format!("{err:#}");
        assert!(t.contains("cloud auth:"), "{t}");
        assert!(t.contains("invalid login or password"), "{t}");
    }

    /// Local only: `FILESFM_TEST_COMBO=C:\path\outside\repo\combo.txt cargo test -p pma-net filesfm_local_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "local smoke: set FILESFM_TEST_COMBO to a combo file outside the repo"]
    async fn filesfm_local_smoke() {
        let path = std::env::var("FILESFM_TEST_COMBO").expect("FILESFM_TEST_COMBO");
        let line = std::fs::read_to_string(&path)
            .expect("read combo")
            .lines()
            .find(|l| !l.trim().is_empty() && !l.trim_start().starts_with('#'))
            .expect("combo line")
            .trim()
            .to_string();
        let (user, pass) = line.split_once(':').expect("email:password");
        let cred = Credential {
            url: Url::parse("https://files.fm/").expect("url"),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::Filesfm,
            Duration::from_secs(60),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("cloud cfg");
        let out = std::env::temp_dir().join("filesfm-smoke-out");
        let (_stats, written) = check_account(&cfg, &cred, &out, None)
            .await
            .expect("check_account");
        assert!(!written.is_empty(), "expected Содержимое inventory");
    }
}
