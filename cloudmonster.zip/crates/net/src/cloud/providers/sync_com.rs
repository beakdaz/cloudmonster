﻿//! Sync.com — cp.sync.com API (getloginsalt + sessionnew + pathlist).

use crate::cloud::sync_com_crypto::{sync_filename_decrypt, sync_password_decrypt};
use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{header_pairs, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use base64::Engine;
use hmac::{Hmac, Mac};
use pma_core::Credential;
use reqwest::Client;
use serde_json::{json, Value};
use sha1::{Digest, Sha1};
use sha2::{Digest as Sha256Digest, Sha256};
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

type HmacSha1 = Hmac<Sha1>;

const SYNC_API: &str = "https://cp.sync.com/api/?command=";
const SYNC_CP_HOME: &str = "https://cp.sync.com/";

fn sync_json_extra() -> &'static [(&'static str, &'static str)] {
    &[
        ("Origin", "https://cp.sync.com"),
        ("Referer", "https://cp.sync.com/"),
    ]
}

fn sync_err_proxy_or_waf(err: &anyhow::Error) -> bool {
    let t = format!("{err:#}").to_ascii_lowercase();
    t.contains("cloud rate limit:")
        || t.contains("cloud network:")
        || t.contains("curl-impersonate")
        || t.contains(" over proxy ")
        || t.contains("proxy connect aborted")
        || t.contains("could not connect to server")
}

async fn sync_warmup(cfg: &CloudClientConfig, curl: &mut CloudCurlSession) {
    let h = header_pairs(cfg, &[("Referer", "https://www.sync.com/")]);
    let refs: Vec<(&str, &str)> = h
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let _ = curl
        .get_text(cfg, "sync cp warmup", SYNC_CP_HOME, &refs, true)
        .await;
}

async fn sync_post_json(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ctx: &str,
    url: &str,
    body: &Value,
) -> Result<(u16, Value)> {
    curl.post_json(cfg, ctx, url, body, sync_json_extra())
        .await
        .with_context(|| ctx.to_string())
}

async fn sync_getloginsalt(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
) -> Result<(CloudClientConfig, String)> {
    let username_b64 = base64::engine::general_purpose::STANDARD.encode(email.as_bytes());
    let url = format!("{SYNC_API}getloginsalt");
    let payload = json!({ "username_b64": username_b64 });

    sync_warmup(cfg, curl).await;
    match sync_post_json(cfg, curl, "sync getloginsalt", &url, &payload).await {
        Ok((status, salt_v)) if status < 400 => {
            let salt = salt_v
                .get("salt")
                .and_then(|x| x.as_str())
                .context("sync: missing salt")?
                .to_string();
            Ok((cfg.clone(), salt))
        }
        Ok((status, _)) => Err(anyhow!("sync getloginsalt http {status}")),
        Err(e) if cfg.proxy.is_some() && sync_err_proxy_or_waf(&e) => {
            let direct = cfg.clone_with_proxy(None).context("sync direct cfg")?;
            sync_warmup(&direct, curl).await;
            let (status, salt_v) = sync_post_json(
                &direct,
                curl,
                "sync getloginsalt",
                &url,
                &payload,
            )
            .await
            .context("sync getloginsalt (direct after proxy fail)")?;
            if status >= 400 {
                return Err(anyhow!("sync getloginsalt http {status}"));
            }
            let salt = salt_v
                .get("salt")
                .and_then(|x| x.as_str())
                .context("sync: missing salt")?
                .to_string();
            Ok((direct, salt))
        }
        Err(e) => Err(e),
    }
}

struct SyncSession {
    access_token: String,
    access_secret: String,
    uid: i64,
    web_device_id: i64,
    web_sync_id: i64,
    used_bytes: u64,
    quota_bytes: u64,
}

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        sync_inventory(cfg, client, cred)
    })
    .await
}

async fn sync_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.trim().to_lowercase();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;

    let (api_cfg, salt) = sync_getloginsalt(cfg, &mut curl, &email).await?;

    let hash_pass = sync_password_hash(&salt, &password)?;

    let (status2, session) = sync_post_json(
        &api_cfg,
        &mut curl,
        "sync sessionnew",
        &format!("{SYNC_API}sessionnew"),
        &json!({
            "username": email,
            "password": hash_pass,
            "twofacode": ""
        }),
    )
    .await
    .context("sync sessionnew")?;

    if status2 >= 400 {
        return Err(anyhow!("sync sessionnew http {status2}"));
    }

    if session.get("success").and_then(|x| x.as_i64()) != Some(1) {
        let errcode = session.get("errcode").and_then(|x| x.as_i64()).unwrap_or(-1);
        let msg = session
            .get("errmsg")
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        if errcode == 9429 {
            return Err(cloud_rate_limit_error(format!("sync login: {msg} (errcode {errcode})")));
        }
        if errcode == 6001 || msg.to_lowercase().contains("incorrect") {
            return Err(cloud_auth_error(format!("sync login: {msg} (errcode {errcode})")));
        }
        return Err(cloud_auth_error(format!("sync login: {msg} (errcode {errcode})")));
    }

    let sess = parse_sync_session(&session)?;

    let (status3, keys) = sync_post_json(
        &api_cfg,
        &mut curl,
        "sync getuserkeys",
        &format!("{SYNC_API}getuserkeys"),
        &json!({
            "username": email,
            "password": hash_pass,
        }),
    )
    .await
    .context("sync getuserkeys")?;
    if status3 >= 400 {
        return Err(anyhow!("sync getuserkeys http {status3}"));
    }
    let enc_meta = keys
        .get("enc_meta_key")
        .and_then(|x| x.as_str())
        .context("sync: missing enc_meta_key")?;
    let meta_key = sync_password_decrypt(enc_meta, &password)
        .context("sync meta key decrypt")?;

    let mut files = sync_list_tree(&api_cfg, &mut curl, &sess, &meta_key).await?;
    if files.len() > MAX_CLOUD_LIST_LINES {
        files.truncate(MAX_CLOUD_LIST_LINES);
    }

    let mut inv = inventory_from_account(
        &email,
        files,
        sess.used_bytes,
        sess.quota_bytes,
        "Sync",
    );
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# Sync.com: сессия OK; FILES=0 — пустой vault или не удалось расшифровать имена.\n"
                .into(),
        );
    }
    Ok(inv)
}

fn parse_sync_session(v: &Value) -> Result<SyncSession> {
    let access_token = v
        .get("access_token")
        .and_then(|x| x.as_str())
        .context("sync: access_token")?
        .to_string();
    let access_secret = v
        .get("access_secret")
        .and_then(|x| x.as_str())
        .context("sync: access_secret")?
        .to_string();
    let uid = v.get("uid").and_then(parse_i64).context("sync: uid")?;
    let web_device_id = v
        .get("web_device_id")
        .and_then(parse_i64)
        .context("sync: web_device_id")?;
    let web_sync_id = v
        .get("web_sync_id")
        .or_else(|| v.get("syncus_sync_id"))
        .and_then(parse_i64)
        .context("sync: web_sync_id")?;
    let used_bytes = v
        .get("used")
        .or_else(|| v.get("used_bytes"))
        .and_then(parse_u64)
        .unwrap_or(0);
    let quota_bytes = v
        .get("quota")
        .or_else(|| v.get("quota_bytes"))
        .and_then(parse_u64)
        .unwrap_or(0);
    Ok(SyncSession {
        access_token,
        access_secret,
        uid,
        web_device_id,
        web_sync_id,
        used_bytes,
        quota_bytes,
    })
}

async fn sync_list_tree(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    sess: &SyncSession,
    meta_key: &str,
) -> Result<Vec<CloudFileMeta>> {
    let mut files = Vec::new();
    let mut queue: VecDeque<(i64, String)> = VecDeque::from([(sess.web_sync_id, String::new())]);
    while let Some((sync_id, prefix)) = queue.pop_front() {
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let items = sync_pathlist(cfg, curl, sess, sync_id).await?;
        for item in items {
            if files.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let id = item.get("id").and_then(parse_i64).unwrap_or(0);
            let enc_name = item
                .get("enc_name")
                .and_then(|x| x.as_str())
                .unwrap_or("");
            let name = sync_filename_decrypt(enc_name, meta_key).unwrap_or_else(|_| {
                enc_name
                    .split_once(':')
                    .map(|(_, t)| t)
                    .unwrap_or(enc_name)
                    .chars()
                    .take(64)
                    .collect()
            });
            let path = if prefix.is_empty() {
                name.clone()
            } else {
                format!("{prefix}/{name}")
            };
            let kind = item
                .get("type")
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            if kind.eq_ignore_ascii_case("dir") || kind.eq_ignore_ascii_case("folder") {
                if id != 0 {
                    queue.push_back((id, path));
                }
                continue;
            }
            let size = item.get("size").and_then(parse_u64).unwrap_or(0);
            files.push(
                CloudFileMeta::new(name, size, path).with_remote_id(id.to_string()),
            );
        }
    }
    Ok(files)
}

async fn sync_pathlist(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    sess: &SyncSession,
    sync_id: i64,
) -> Result<Vec<Value>> {
    let mut merged = Vec::new();
    let mut offset_metaname_digest = 0i64;
    loop {
        let servtime = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis() as i64)
            .unwrap_or(0);
        let sig_payload = format!(
            "{}{}{}{servtime}",
            sess.access_token, sess.uid, sess.web_device_id
        );
        let signature = sync_api_hmac(&sess.access_secret, &sig_payload)?;
        let body = json!({
            "showdeleted": 0,
            "hist_id": 0,
            "sync_id": sync_id,
            "offset_metaname_digest": offset_metaname_digest,
            "servtime": servtime,
            "access_token": sess.access_token,
            "signature": signature,
        });
        let (status, page) = sync_post_json(
            cfg,
            curl,
            "sync pathlist",
            &format!("{SYNC_API}pathlist"),
            &body,
        )
        .await
        .context("sync pathlist")?;
        if status >= 400 {
            return Err(anyhow!("sync pathlist http {status}"));
        }
        if page.get("success").and_then(|x| x.as_i64()) != Some(1) {
            let msg = page
                .get("errmsg")
                .and_then(|x| x.as_str())
                .unwrap_or("pathlist failed");
            return Err(anyhow!("sync pathlist: {msg}"));
        }
        if let Some(list) = page.get("pathlist").and_then(|x| x.as_array()) {
            merged.extend(list.iter().cloned());
        }
        let last = page
            .get("last_metaname_digest")
            .and_then(parse_i64)
            .unwrap_or(offset_metaname_digest);
        if last == offset_metaname_digest {
            break;
        }
        offset_metaname_digest = last;
    }
    Ok(merged)
}

fn sync_api_hmac(secret: &str, payload: &str) -> Result<String> {
    let mut mac =
        HmacSha1::new_from_slice(secret.as_bytes()).context("sync hmac key")?;
    mac.update(payload.as_bytes());
    Ok(hex::encode(mac.finalize().into_bytes()))
}

fn sync_password_hash(salt: &str, password: &str) -> Result<String> {
    let sha1pass = hex::encode(Sha1::digest(password.as_bytes()));
    let mid = sha1pass.get(4..24).unwrap_or("");
    let mangle = hex::encode(Sha256::digest(format!("{sha1pass}{mid}").as_bytes()));
    sync_bcrypt_hash(&mangle, salt).context("sync bcrypt")
}

fn sync_bcrypt_hash(mangle: &str, salt: &str) -> Result<String> {
    use bcrypt::{hash_with_salt, Version, BASE_64, DEFAULT_COST};

    let (cost, salt22) = if salt.starts_with("$2") && salt.len() >= 29 {
        let cost: u32 = salt[4..6].parse().unwrap_or(DEFAULT_COST);
        (cost, salt[7..29].to_string())
    } else {
        (10u32, salt.to_string())
    };

    let mut salt_bytes = [0u8; 16];
    BASE_64
        .decode_slice(salt22.as_bytes(), &mut salt_bytes)
        .map_err(|e| anyhow!("sync bcrypt salt: {e}"))?;
    let parts = hash_with_salt(mangle.as_bytes(), cost, salt_bytes).map_err(|e| anyhow!("{e}"))?;
    Ok(parts.format_for_version(Version::TwoA))
}

fn parse_i64(v: &Value) -> Option<i64> {
    v.as_i64()
        .or_else(|| v.as_u64().map(|n| n as i64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn parse_u64(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().map(|n| n.max(0) as u64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}
