//! Cloud Mega checker bridge for note-suite providers (email:password lists).

use crate::cloud::common::{inventory_from_account, run_checker, CloudFileMeta, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use crate::note_export::{download_note_export_account, NoteExportClientConfig};
use anyhow::{Context, Result};
use pma_core::{Credential, NoteExportService};
use reqwest::Client;
use std::path::{Path, PathBuf};

pub async fn check_account(
    service: NoteExportService,
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    if service == NoteExportService::Obsidian {
        return crate::cloud::providers::obsidian::check_account(cfg, cred, output_dir, on_check_started)
            .await;
    }

    let output_buf = output_dir.to_path_buf();
    run_checker(cfg, cred, output_dir, on_check_started, move |client, cred| {
        note_export_inventory(service, cfg, output_buf, client, cred)
    })
    .await
}

async fn note_export_inventory(
    service: NoteExportService,
    cfg: &CloudClientConfig,
    output_dir: PathBuf,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let mut url = cred.url.clone();
    if url.host_str().unwrap_or("").is_empty() {
        url = url::Url::parse(service.default_origin()).context("default origin")?;
    }
    let mut cred = cred;
    cred.url = url;

    let client_cfg = NoteExportClientConfig {
        timeout: cfg.timeout,
        insecure: cfg.insecure,
    };
    let (stats, files) = download_note_export_account(
        service,
        &cred,
        &client_cfg,
        &output_dir,
        true,
    )
    .await
    .context("note export login")?;

    let cloud_files: Vec<CloudFileMeta> = files
        .into_iter()
        .map(|(path, size)| {
            let name = path
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or("export")
                .to_string();
            let p = path.to_string_lossy().into_owned();
            CloudFileMeta::new(name, size, p)
        })
        .collect();
    let total_size: u64 = cloud_files.iter().map(|f| f.size).sum();
    let mut inv = inventory_from_account(
        &cred.username,
        cloud_files,
        total_size,
        0,
        service.label(),
    );
    inv.list_note = Some(format!(
        "# {}: {} ({} files, {})\n",
        service.label(),
        stats.detail_line(),
        stats.downloaded,
        stats.bytes,
    ));
    Ok(inv)
}
