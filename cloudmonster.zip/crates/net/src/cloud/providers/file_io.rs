﻿//! file.io — API key auth (paid); combo email:api_key or `fileio:` prefix.

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const FILEIO_ORIGIN: &str = "https://www.file.io";

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        file_io_inventory(cfg, client, cred)
    })
    .await
}

async fn file_io_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let secret = cred.password.trim();

    let Some(api_key) = secret.strip_prefix("fileio:") else {
        return Err(cloud_auth_error(
            "file.io: пароль = API key с префиксом `fileio:` (не голый email:password)",
        ));
    };
    let api_key = api_key.trim();
    if api_key.is_empty() {
        return Err(cloud_auth_error(
            "file.io: anonymous uploads only — пароль = API key с file.io/account/apikeys (`fileio:` prefix)",
        ));
    }

    let mut curl = CloudCurlSession::new()?;
    let auth = format!("Bearer {api_key}");
    let list_url = build_url(FILEIO_ORIGIN, &[("limit", "200"), ("offset", "0")])?;
    let list_json = curl
        .get_json(
            cfg,
            "file.io list",
            &list_url,
            &[
                ("Authorization", auth.as_str()),
                ("Referer", FILEIO_ORIGIN),
            ],
        )
        .await
        .context("file.io list")?;
    if list_json.get("success").and_then(|x| x.as_bool()) == Some(false) {
        return Err(cloud_auth_error("file.io: invalid API key"));
    }

    let me_url = format!("{FILEIO_ORIGIN}/me");
    let me_json = curl
        .get_json(
            cfg,
            "file.io me",
            &me_url,
            &[
                ("Authorization", auth.as_str()),
                ("Referer", FILEIO_ORIGIN),
            ],
        )
        .await
        .unwrap_or(Value::Null);

    let mut files = Vec::new();
    if let Some(arr) = list_json.get("files").and_then(|x| x.as_array()) {
        for item in arr {
            if files.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let name = item
                .get("name")
                .or_else(|| item.get("key"))
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let size = item.get("size").and_then(|x| x.as_u64()).unwrap_or(0);
            let key = item.get("key").and_then(|x| x.as_str()).unwrap_or("");
            let link = item.get("link").and_then(|x| x.as_str()).unwrap_or("");
            let mut meta = CloudFileMeta::new(name, size, name).with_keyword_extra(link);
            if !key.is_empty() {
                meta = meta.with_remote_id(key);
            }
            files.push(meta);
        }
    }

    let used = me_json
        .get("usedStorageBytes")
        .and_then(|x| x.as_u64())
        .unwrap_or_else(|| files.iter().map(|f| f.size).sum());
    let quota = me_json
        .get("maxStorageBytes")
        .and_then(|x| x.as_u64())
        .unwrap_or(0);

    Ok(inventory_from_account(&email, files, used, quota, "file.io"))
}

pub fn file_io_api_key_from_combo(password: &str) -> Option<&str> {
    password
        .strip_prefix("fileio:")
        .map(str::trim)
        .filter(|s| !s.is_empty())
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn strips_fileio_prefix() {
        assert_eq!(
            file_io_api_key_from_combo("fileio:abc123"),
            Some("abc123")
        );
    }
}
