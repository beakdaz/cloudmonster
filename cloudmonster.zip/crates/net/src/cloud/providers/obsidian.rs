﻿//! Obsidian account — optional `ob login --json` if obsidian-headless CLI is installed.

use crate::cloud::common::{cloud_auth_error, inventory_from_account, run_checker, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use std::path::{Path, PathBuf};
use std::process::Command;

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        obsidian_inventory(cfg, client, cred)
    })
    .await
}

async fn obsidian_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();

    if let Ok(inv) = obsidian_via_cli(&email, &password) {
        return Ok(inv);
    }

    if let Ok(token) = std::env::var("OBSIDIAN_AUTH_TOKEN") {
        if !token.trim().is_empty() {
            let mut curl = CloudCurlSession::new()?;
            let (status, v) = curl
                .post_json(
                    cfg,
                    "obsidian vault list",
                    "https://api.obsidian.md/vault/list",
                    &serde_json::json!({ "token": token.trim() }),
                    &[],
                )
                .await
                .context("obsidian vault list")?;
            if status == 200 && v.get("vaults").is_some() {
                let mut inv = inventory_from_account(&email, Vec::new(), 0, 0, "Obsidian");
                inv.list_note = Some(
                    "# Obsidian: vault/list OK по OBSIDIAN_AUTH_TOKEN (не combo-пароль).\n".into(),
                );
                return Ok(inv);
            }
        }
    }

    Err(anyhow!(
        "obsidian: установите obsidian-headless (`ob login`) или задайте OBSIDIAN_AUTH_TOKEN; публичного email/password REST API нет"
    ))
}

fn obsidian_via_cli(email: &str, password: &str) -> Result<CloudInventory> {
    let output = Command::new("ob")
        .args([
            "login",
            "--email",
            email,
            "--password",
            password,
            "--json",
        ])
        .output()
        .context("obsidian: `ob` CLI not found (npm i -g obsidian-headless)")?;

    if !output.status.success() {
        let err = String::from_utf8_lossy(&output.stderr);
        let out = String::from_utf8_lossy(&output.stdout);
        let text = format!("{err} {out}").to_lowercase();
        if text.contains("invalid") || text.contains("incorrect") || text.contains("password") {
            return Err(cloud_auth_error("obsidian: invalid email or password"));
        }
        return Err(anyhow!("obsidian ob login failed: {}", preview(&err, 200)));
    }

    let mut inv = inventory_from_account(email, Vec::new(), 0, 0, "Obsidian");
    inv.list_note = Some(
        "# Obsidian: `ob login --json` OK. Sync vault list: `ob sync-list-remote`.\n".into(),
    );
    Ok(inv)
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}
