﻿//! OneDrive (personal) — Microsoft account login + OneDrive REST (`api.onedrive.com`).

use crate::cloud::common::{
    cloud_auth_error, cloud_banned_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{header_pairs, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use regex::Regex;
use reqwest::Client;
use serde_json::Value;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;

const CHROME_UA: &str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

/// Public OneDrive web client id (implicit grant).
const ONEDRIVE_CLIENT_ID: &str = "00000000481710A4";
const OAUTH_REDIRECT: &str = "https://p.sfx.ms/sa.html";
const OAUTH_SCOPE: &str = "onedrive_implicit.access";

static RE_URL_POST: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#""urlPost"\s*:\s*"((?:\\.|[^"\\])*)""#).expect("urlPost re"));
static RE_URL_POST_MSA: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#""urlPostMsa"\s*:\s*"((?:\\.|[^"\\])*)""#).expect("urlPostMsa re")
});
static RE_PPFT_JSON: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#""sFT"\s*:\s*"((?:\\.|[^"\\])*)""#).expect("sFT re"));
static RE_FLOW_TOKEN: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#""flowToken"\s*:\s*"((?:\\.|[^"\\])*)""#).expect("flowToken re")
});
static RE_SFT_TAG: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#""sFTTag"\s*:\s*"((?:\\.|[^"\\])*)""#).expect("sFTTag re")
});
static RE_PPFT_INPUT: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"name="PPFT"[^>]*value="([^"]+)""#).expect("PPFT input re")
});
static RE_PPFT_INPUT_REV: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"value="([^"]+)"[^>]*name="PPFT""#).expect("PPFT input rev re")
});
static RE_PPFT_INPUT_SQ: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"name='PPFT'[^>]*value='([^']+)'"#).expect("PPFT input sq re")
});
static RE_CANARY: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#""sCanary"\s*:\s*"((?:\\.|[^"\\])*)""#).expect("sCanary re")
});
static RE_HIDDEN_INPUT: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"id="([^"]+)"[^>]*value="([^"]+)""#).expect("hidden input re")
});
static RE_ACCESS_TOKEN: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"access_token=([^&\s"'#]+)"#).expect("access_token re")
});

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        onedrive_inventory(cfg, client, cred)
    })
    .await
}

async fn onedrive_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let token = onedrive_access_token(cfg, &email, &password).await?;
    let mut curl = CloudCurlSession::new()?;
    let (files, used, total, tariff) =
        onedrive_list_and_quota(cfg, &mut curl, &token).await?;
    let mut inv = inventory_from_account(&email, files, used, total, tariff);
    inv.session_secret = Some(token);
    Ok(inv)
}

fn oauth_authorize_url(login_hint: Option<&str>) -> String {
    let mut url = format!(
        "https://login.live.com/oauth20_authorize.srf?client_id={ONEDRIVE_CLIENT_ID}\
         &response_type=token&redirect_uri={}&scope={}&display=none",
        urlencoding_path(OAUTH_REDIRECT),
        urlencoding_path(OAUTH_SCOPE),
    );
    if let Some(h) = login_hint {
        url.push_str("&login_hint=");
        url.push_str(&urlencoding_path(h));
    }
    url
}

fn urlencoding_path(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}

fn unescape_ms_json(s: &str) -> String {
    s.replace("\\u0026", "&")
        .replace("\\u002f", "/")
        .replace("\\u003a", ":")
        .replace("\\u003d", "=")
        .replace("\\u002b", "+")
        .replace("\\u002d", "-")
        .replace("\\u005f", "_")
        .replace("\\u002e", ".")
        .replace("\\/", "/")
        .replace("\\\"", "\"")
        .replace("\\\\", "\\")
}

fn capture_unescaped(re: &Regex, html: &str) -> Option<String> {
    re.captures(html)
        .and_then(|c| c.get(1).map(|m| unescape_ms_json(m.as_str())))
        .filter(|s| !s.is_empty())
}

fn extract_ppft(html: &str) -> Option<String> {
    for re in [
        &*RE_PPFT_JSON,
        &*RE_FLOW_TOKEN,
        &*RE_PPFT_INPUT,
        &*RE_PPFT_INPUT_REV,
        &*RE_PPFT_INPUT_SQ,
    ] {
        if let Some(v) = capture_unescaped(re, html) {
            return Some(v);
        }
    }
    if let Some(tag) = capture_unescaped(&RE_SFT_TAG, html) {
        for re in [&*RE_PPFT_INPUT, &*RE_PPFT_INPUT_REV, &*RE_PPFT_INPUT_SQ] {
            if let Some(v) = capture_unescaped(re, &tag) {
                return Some(v);
            }
        }
    }
    None
}

fn extract_url_post(html: &str) -> Option<String> {
    capture_unescaped(&RE_URL_POST_MSA, html).or_else(|| capture_unescaped(&RE_URL_POST, html))
}

fn extract_canary(html: &str) -> Option<String> {
    capture_unescaped(&RE_CANARY, html)
}

fn onedrive_login_page_looks_valid(html: &str) -> bool {
    extract_ppft(html).is_some() && extract_url_post(html).is_some()
}

fn onedrive_page_headers(cfg: &CloudClientConfig, referer: Option<&str>) -> Vec<(String, String)> {
    let mut extra: Vec<(&str, &str)> = vec![
        ("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
        ("Accept-Language", "en-US,en;q=0.9"),
        ("Origin", "https://login.live.com"),
    ];
    if let Some(r) = referer {
        extra.push(("Referer", r));
    }
    header_pairs(cfg, &extra)
}

fn onedrive_ms_login_shell(html: &str) -> bool {
    let l = html.to_ascii_lowercase();
    l.contains("login.live.com")
        || l.contains("microsoftonline.com")
        || l.contains("serverdata")
        || l.contains("$config")
        || l.contains("ppsecure/post.srf")
}

fn onedrive_ppft_parse_error(html: &str) -> anyhow::Error {
    if html.is_empty() {
        return cloud_rate_limit_error("onedrive: empty login page (proxy/WAF?)");
    }
    if !onedrive_ms_login_shell(html) {
        return cloud_rate_limit_error("onedrive: not a Microsoft login page (proxy/WAF?)");
    }
    if html.to_ascii_lowercase().contains("captcha") || html.contains("Human Verification") {
        return cloud_rate_limit_error("onedrive: captcha on login page");
    }
    cloud_auth_error("onedrive: could not parse login form (PPFT)")
}

async fn fetch_onedrive_login_page(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
) -> Result<(String, String)> {
    let oauth_hint = oauth_authorize_url(Some(email));
    let oauth_plain = oauth_authorize_url(None);
    let candidates = [
        oauth_hint.clone(),
        oauth_plain.clone(),
        format!(
            "https://login.live.com/login.srf?wa=wsignin1.0&wp=MBI_SSL&wreply={}",
            urlencoding_path(&oauth_plain)
        ),
    ];
    let mut last_html = String::new();
    let mut last_url = oauth_hint;
    for url in candidates {
        let headers = onedrive_page_headers(cfg, None);
        let refs: Vec<(&str, &str)> = headers
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();
        let (_st, html) = curl
            .get_text(cfg, "onedrive login page", &url, &refs, true)
            .await
            .with_context(|| format!("onedrive login page {url}"))?;
        last_url = url;
        last_html = html;
        if onedrive_login_page_looks_valid(&last_html) {
            return Ok((last_html, last_url));
        }
    }
    Ok((last_html, last_url))
}

fn extract_access_token_from_text(text: &str) -> Option<String> {
    if let Some(c) = RE_ACCESS_TOKEN.captures(text) {
        if let Some(m) = c.get(1) {
            return Some(
                urlencoding_decode(m.as_str()).unwrap_or_else(|| m.as_str().to_string()),
            );
        }
    }
    if let Some(hash) = text.find('#') {
        let frag = &text[hash + 1..];
        for part in frag.split('&') {
            if let Some(val) = part.strip_prefix("access_token=") {
                return Some(
                    urlencoding_decode(val).unwrap_or_else(|| val.to_string()),
                );
            }
        }
    }
    None
}

fn urlencoding_decode(s: &str) -> Option<String> {
    let mut out = String::new();
    let mut bytes = s.as_bytes();
    while !bytes.is_empty() {
        if bytes[0] == b'%' && bytes.len() >= 3 {
            if let Ok(v) = u8::from_str_radix(std::str::from_utf8(&bytes[1..3]).ok()?, 16) {
                out.push(v as char);
                bytes = &bytes[3..];
                continue;
            }
        }
        out.push(bytes[0] as char);
        bytes = &bytes[1..];
    }
    Some(out)
}

fn onedrive_signals_rate_limited(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("too many times with an incorrect")
        || lower.contains("exceeded the maximum number of attempts")
        || lower.contains("80048820")
        || lower.contains("80041103")
        || (lower.contains("serrorcode") && lower.contains("800488fb"))
}

fn login_page_signals_failure(html: &str, final_url: &str) -> Option<anyhow::Error> {
    let lower = html.to_ascii_lowercase();
    let url_l = final_url.to_ascii_lowercase();
    if url_l.contains("account.live.com/abuse") {
        return Some(cloud_banned_error("onedrive: account flagged (Abuse)"));
    }
    if url_l.contains("account.live.com/recover")
        || url_l.contains("recoveraccount")
        || lower.contains("recover your account")
    {
        return Some(cloud_auth_error("onedrive: account recovery required"));
    }
    if lower.contains("identity/confirm") || lower.contains("proofs/add") {
        return Some(cloud_auth_error("onedrive: 2FA / proof required"));
    }
    if lower.contains("password is incorrect")
        || (lower.contains("serrorcode")
            && (lower.contains("80041012") || lower.contains("8004102f")))
    {
        return Some(cloud_auth_error("onedrive: invalid email or password"));
    }
    if onedrive_signals_rate_limited(&lower) {
        return Some(cloud_rate_limit_error("onedrive: too many login attempts"));
    }
    None
}

async fn onedrive_access_token(
    cfg: &CloudClientConfig,
    email: &str,
    password: &str,
) -> Result<String> {
    let mut curl = CloudCurlSession::new()?;
    let auth_url = oauth_authorize_url(Some(email));
    let (html, _page_url) = fetch_onedrive_login_page(cfg, &mut curl, email).await?;

    if let Some(tok) = extract_access_token_from_text(&html) {
        return Ok(tok);
    }

    let ppft = extract_ppft(&html).ok_or_else(|| onedrive_ppft_parse_error(&html))?;
    let post_url = extract_url_post(&html).ok_or_else(|| {
        cloud_auth_error("onedrive: could not parse login form (urlPost)")
    })?;
    let canary = extract_canary(&html).unwrap_or_default();

    let mut form: Vec<(&str, &str)> = vec![
        ("login", email),
        ("loginfmt", email),
        ("passwd", password),
        ("PPFT", &ppft),
        ("type", "11"),
        ("LoginOptions", "3"),
        ("ps", "2"),
        ("PPSX", "PassportRN"),
        ("NewUser", "1"),
        ("i13", "0"),
        ("i19", "39295"),
    ];
    if !canary.is_empty() {
        form.push(("canary", canary.as_str()));
    }

    let post_headers = onedrive_page_headers(cfg, Some(&auth_url));
    let post_refs: Vec<(&str, &str)> = post_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let (_st, login_html) = curl
        .post_form(
            cfg,
            "onedrive login post",
            &post_url,
            &form,
            &post_refs,
            true,
        )
        .await
        .context("onedrive login post")?;

    if let Some(err) = login_page_signals_failure(&login_html, "") {
        return Err(err);
    }

    if let Some(tok) = extract_access_token_from_text(&login_html) {
        return Ok(tok);
    }

    if login_html.contains("onedrive.live.com/_forms/default.aspx")
        || login_html.contains("_forms/default.aspx")
    {
        onedrive_bridge_form(cfg, &mut curl, &login_html).await?;
        let retry_url = oauth_authorize_url(Some(email));
        let bridge_headers = onedrive_page_headers(cfg, Some(&auth_url));
        let bridge_refs: Vec<(&str, &str)> = bridge_headers
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();
        let (_st, ob) = curl
            .get_text(cfg, "onedrive oauth after bridge", &retry_url, &bridge_refs, true)
            .await
            .context("onedrive oauth after bridge")?;
        if let Some(tok) = extract_access_token_from_text(&ob) {
            return Ok(tok);
        }
    }

    let retry_url = oauth_authorize_url(Some(email));
    let retry_headers = onedrive_page_headers(cfg, Some(&auth_url));
    let retry_refs: Vec<(&str, &str)> = retry_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let (_st, rb) = curl
        .get_text(cfg, "onedrive oauth retry", &retry_url, &retry_refs, true)
        .await
        .context("onedrive oauth retry")?;
    if let Some(err) = login_page_signals_failure(&rb, "") {
        return Err(err);
    }
    extract_access_token_from_text(&rb)
        .ok_or_else(|| cloud_auth_error("onedrive: login succeeded but no access_token"))
}

async fn onedrive_bridge_form(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    html: &str,
) -> Result<()> {
    let mut fields: HashMap<String, String> = HashMap::new();
    for cap in RE_HIDDEN_INPUT.captures_iter(html) {
        let id = cap.get(1).map(|m| m.as_str()).unwrap_or("");
        let val = cap.get(2).map(|m| m.as_str()).unwrap_or("");
        if matches!(id, "NAP" | "ANON" | "t" | "pprid") {
            fields.insert(id.to_string(), val.to_string());
        }
    }
    if fields.len() < 3 {
        return Err(cloud_auth_error("onedrive: missing SSO form tokens"));
    }
    let form: Vec<(&str, &str)> = fields
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let sso_headers = onedrive_page_headers(cfg, None);
    let sso_refs: Vec<(&str, &str)> = sso_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    curl.post_form(
        cfg,
        "onedrive sso post",
        "https://onedrive.live.com/_forms/default.aspx?apr=1&wa=wsignin1.0",
        &form,
        &sso_refs,
        true,
    )
    .await
    .context("onedrive sso post")?;
    Ok(())
}

async fn onedrive_list_and_quota(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
) -> Result<(Vec<CloudFileMeta>, u64, u64, String)> {
    let auth = format!("bearer {token}");
    let quota_url = "https://api.onedrive.com/v2.1/drive?expand=unifiedStorageQuota&select=quota";
    let mut used = 0u64;
    let mut total = 0u64;
    let mut tariff = "OneDrive".to_string();
    if let Ok(v) = curl
        .get_json(
            cfg,
            "onedrive quota",
            quota_url,
            &[("Authorization", auth.as_str())],
        )
        .await
    {
        if let Some(q) = v.get("quota") {
            used = q.get("used").and_then(|x| x.as_u64()).unwrap_or(0);
            total = q
                .get("total")
                .or_else(|| q.get("storageTotal"))
                .and_then(|x| x.as_u64())
                .unwrap_or(0);
        }
        if let Some(plan) = v.get("plan").and_then(|x| x.as_str()) {
            if !plan.is_empty() {
                tariff = plan.to_string();
            }
        }
    }

    let mut files = Vec::new();
    let mut next_url = Some(
        "https://api.onedrive.com/v1.0/drive/root/children?$select=id,name,size&$top=200".to_string(),
    );
    while let Some(url) = next_url.take() {
        let body = match curl
            .get_json(
                cfg,
                "onedrive list",
                &url,
                &[("Authorization", auth.as_str())],
            )
            .await
        {
            Ok(v) => v,
            Err(e) => {
                if files.is_empty() {
                    return Err(e.context(format!("onedrive list {url}")));
                }
                break;
            }
        };
        if let Some(items) = body.get("value").and_then(|x| x.as_array()) {
            for item in items {
                let name = item
                    .get("name")
                    .and_then(|x| x.as_str())
                    .unwrap_or("file");
                let size = item.get("size").and_then(|x| x.as_u64()).unwrap_or(0);
                let id = item
                    .get("id")
                    .and_then(|x| x.as_str())
                    .unwrap_or("")
                    .to_string();
                files.push(
                    CloudFileMeta::new(name, size, format!("/{name}"))
                        .with_remote_id(id),
                );
                if files.len() >= MAX_CLOUD_LIST_LINES {
                    break;
                }
            }
        }
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        next_url = body
            .get("@odata.nextLink")
            .and_then(|x| x.as_str())
            .map(|s| s.to_string());
    }

    Ok((files, used, total, tariff))
}

pub async fn download_filtered_files(
    _cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    use crate::cloud::dispatch_download;
    let token = inv
        .session_secret
        .as_deref()
        .context("onedrive: missing access token for download")?;
    let auth = format!("bearer {token}");
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    for file in picks {
        let Some(id) = file.remote_id.as_deref() else {
            continue;
        };
        let url = format!("https://api.onedrive.com/v1.0/drive/items/{id}/content");
        let resp = client
            .get(&url)
            .header("Authorization", &auth)
            .send()
            .await
            .with_context(|| format!("onedrive download {id}"))?;
        if !resp.status().is_success() {
            continue;
        }
        let bytes = resp.bytes().await.context("onedrive download body")?;
        let leaf = file.path.replace('/', "\\");
        let (dest, n) = dispatch_download::write_bytes(cred, run_output_dir, &leaf, &bytes).await?;
        paths.push(dest);
        total += n;
        count += 1;
    }
    Ok((count, total, paths))
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn rate_limit_not_generic_phrase() {
        assert!(!onedrive_signals_rate_limited(
            "help: if you try too many times read our FAQ"
        ));
        assert!(onedrive_signals_rate_limited(
            "You've tried to sign in too many times with an incorrect account or password"
        ));
    }

    #[test]
    fn parses_url_post_json() {
        let sample = r#""urlPost":"https://login.live.com/ppsecure/post.srf?contextid=ABC\u0026bk=1""#;
        let u = extract_url_post(sample).unwrap();
        assert!(u.contains("contextid=ABC&bk=1"));
    }

    #[test]
    fn parses_url_post_msa() {
        let sample = r#""urlPostMsa":"https://login.live.com/ppsecure/post.srf?id=1\u0026bk=2""#;
        let u = extract_url_post(sample).unwrap();
        assert!(u.contains("id=1&bk=2"));
    }

    #[test]
    fn parses_ppft_from_flow_token() {
        let sample = r#""flowToken":"-Dm7longtoken\u0026part=2""#;
        let p = extract_ppft(sample).unwrap();
        assert!(p.starts_with("-Dm7"));
        assert!(p.contains("&part=2"));
    }

    #[test]
    fn parses_ppft_from_sft_tag() {
        let sample = r#""sFTTag":"<input type=\"hidden\" name=\"PPFT\" id=\"i0327\" value=\"TOKEN123\"/>""#;
        let p = extract_ppft(sample).unwrap();
        assert_eq!(p, "TOKEN123");
    }

    #[test]
    fn parses_access_token_fragment() {
        let u = "https://p.sfx.ms/sa.html#access_token=eyJ.test&token_type=bearer";
        let t = extract_access_token_from_text(u).unwrap();
        assert_eq!(t, "eyJ.test");
    }

    #[tokio::test]
    #[ignore = "local smoke: set ONEDRIVE_TEST_COMBO=file with email:password line"]
    async fn onedrive_local_smoke() {
        let path = std::env::var("ONEDRIVE_TEST_COMBO").expect("ONEDRIVE_TEST_COMBO");
        let line = std::fs::read_to_string(&path).unwrap();
        let line = line
            .lines()
            .find(|l| !l.trim().is_empty())
            .unwrap()
            .trim();
        let (user, pass) = line.split_once(':').unwrap();
        let cred = Credential {
            url: url::Url::parse("https://onedrive.live.com/").unwrap(),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            pma_core::CloudProvider::OneDrive,
            std::time::Duration::from_secs(90),
            false,
            None,
            1,
            false,
            pma_core::CloudDownloadFilter::default(),
        )
        .unwrap();
        let out = std::env::temp_dir().join("onedrive-smoke-out");
        check_account(&cfg, &cred, &out, None)
            .await
            .expect("check_account");
    }
}
