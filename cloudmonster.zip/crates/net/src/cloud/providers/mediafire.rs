﻿use crate::cloud::common::{
    cloud_auth_error, cloud_banned_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, parse_json_text, CloudCurlSession};
use crate::cloud::dispatch_download;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use reqwest::Method;
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use sha1::{Digest, Sha1};
use std::collections::VecDeque;
use std::path::{Path, PathBuf};

const MF_BUILTIN_APPS: &[(&str, &str)] = &[(
    "36434",
    "mqio689reumyxs7p2xjd18asj388lle2h6hpx6m5",
)];

const MF_API_HEADERS: &[(&str, &str)] = &[
    (
        "Accept",
        "application/json, text/javascript, */*; q=0.01",
    ),
    ("Origin", "https://www.mediafire.com"),
    ("Referer", "https://www.mediafire.com/"),
];

const MF_WEB_LOGIN_URL: &str = "https://www.mediafire.com/application/login.php";
const MF_WEB_LOGIN_HEADERS: &[(&str, &str)] = &[
    ("Accept", "*/*"),
    ("Pragma", "no-cache"),
    ("Origin", "https://www.mediafire.com"),
    ("Referer", "https://www.mediafire.com/login/"),
];

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        mediafire_inventory(cfg, client, cred)
    })
    .await
}

pub async fn download_filtered_files(
    cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let session_token = inv
        .session_secret
        .as_deref()
        .or(Some(inv.account_tag_source.as_str()))
        .context("mediafire session")?;
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    let mut curl = CloudCurlSession::new()?;
    for file in picks {
        let Some(quickkey) = file.remote_id.as_deref() else {
            continue;
        };
        let url = build_url(
            "https://www.mediafire.com/api/1.5/file/get_links.php",
            &[
                ("session_token", session_token),
                ("quickkey", quickkey),
                ("response_format", "json"),
            ],
        )?;
        let links = mf_get_json(cfg, &mut curl, "file/get_links.php", &url).await;
        let Ok(links) = links else {
            continue;
        };
        let url = links
            .pointer("/response/links/normal_download")
            .and_then(|x| x.as_str())
            .or_else(|| {
                links
                    .pointer("/response/links/direct_download")
                    .and_then(|x| x.as_str())
            });
        let Some(url) = url else {
            continue;
        };
        match dispatch_download::write_leaf(cred, run_output_dir, &file.name, &client, url).await {
            Ok((path, n)) => {
                count += 1;
                total += n;
                paths.push(path);
            }
            Err(_) => continue,
        }
    }
    Ok((count, total, paths))
}

async fn mediafire_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let session_token = mf_acquire_session_token(cfg, &mut curl, &email, &password).await?;

    let info = mf_get(
        cfg,
        &mut curl,
        "user/get_info.php",
        &[("session_token", session_token.as_str())],
    )
    .await?;
    let (used, quota, premium) = parse_user_info(&info)?;

    let mut files: Vec<CloudFileMeta> = Vec::new();
    let mut pending: VecDeque<String> = VecDeque::new();
    pending.push_back("myfiles".to_string());
    while let Some(folder_key) = pending.pop_front() {
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let content = mf_get(
            cfg,
            &mut curl,
            "folder/get_content.php",
            &[
                ("session_token", session_token.as_str()),
                ("folder_key", folder_key.as_str()),
                ("content_type", "files,folders"),
                ("chunk", "1"),
                ("chunk_size", "100"),
            ],
        )
        .await;
        let Ok(content) = content else {
            continue;
        };
        if let Some(list) = content
            .pointer("/response/folder_content/files")
            .and_then(|x| x.as_array())
        {
            for f in list {
                let name = f
                    .get("filename")
                    .and_then(|x| x.as_str())
                    .unwrap_or("file");
                let size = f.get("size").and_then(parse_u64_value).unwrap_or(0);
                let quickkey = f.get("quickkey").and_then(|x| x.as_str()).unwrap_or("");
                let mut meta = CloudFileMeta::new(name, size, name);
                if !quickkey.is_empty() {
                    meta = meta.with_remote_id(quickkey);
                }
                files.push(meta);
            }
        }
        if let Some(folders) = content
            .pointer("/response/folder_content/folders")
            .and_then(|x| x.as_array())
        {
            for folder in folders {
                if let Some(key) = folder.get("folderkey").and_then(|x| x.as_str()) {
                    if !key.is_empty() {
                        pending.push_back(key.to_string());
                    }
                }
            }
        }
    }

    let file_bytes: u64 = files.iter().map(|f| f.size).sum();
    let used_bytes = if used > 0 { used } else { file_bytes };
    let mut inv = inventory_from_account(
        &email,
        files,
        used_bytes,
        quota,
        if premium { "Premium" } else { "Free" },
    );
    inv.session_secret = Some(session_token);
    Ok(inv)
}

fn mf_app_pairs() -> Vec<(String, String)> {
    let id = std::env::var("MEDIAFIRE_APPLICATION_ID").unwrap_or_default();
    let key = std::env::var("MEDIAFIRE_API_KEY").unwrap_or_default();
    if !id.is_empty() && !key.is_empty() {
        return vec![(id, key)];
    }
    MF_BUILTIN_APPS
        .iter()
        .map(|(a, k)| ((*a).to_string(), (*k).to_string()))
        .collect()
}

fn mf_login_signature(email: &str, password: &str, app_id: &str, api_key: &str) -> String {
    let mut hasher = Sha1::new();
    hasher.update(format!("{email}{password}{app_id}{api_key}").as_bytes());
    hex::encode(hasher.finalize())
}

/// OpenBullet-style `application/login.php`, then signed API `get_session_token`.
async fn mf_acquire_session_token(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    match mf_login_web(cfg, curl, email, password).await {
        Ok(token) => return Ok(token),
        Err(e) => {
            if format!("{e:#}").contains("cloud auth:")
                || format!("{e:#}").contains("cloud banned:")
            {
                return Err(e);
            }
        }
    }
    let token_resp = mf_login_api(cfg, curl, email, password).await?;
    parse_session_token(&token_resp)
}

async fn mf_login_web(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    let form = [("email", email), ("password", password)];
    let (status, text) = curl
        .post_form(
            cfg,
            "mediafire login.php",
            MF_WEB_LOGIN_URL,
            &form,
            MF_WEB_LOGIN_HEADERS,
            false,
        )
        .await?;
    parse_login_php_session(cfg.provider, status, &text)
}

fn parse_login_php_session(
    provider: pma_core::CloudProvider,
    status: u16,
    text: &str,
) -> Result<String> {
    if text.contains("The owner of mediafire.com has banned you temporarily from accessing this website.")
    {
        return Err(cloud_banned_error("mediafire temporary IP ban"));
    }
    let body = parse_json_text(provider, status, text, "mediafire login.php")?;
    if let Some(token) = body
        .get("session_token")
        .or_else(|| body.pointer("/response/session_token"))
        .and_then(|x| x.as_str())
    {
        if !token.is_empty() {
            return Ok(token.to_string());
        }
    }
    // login.php codes (2003 OB fail, 2006 common on bad pass) are not final — API get_session_token decides AUTH.
    if let Some(code) = body.pointer("/response/error").and_then(parse_u64_value) {
        return Err(anyhow::anyhow!(
            "mediafire login.php: no session_token (error {code})"
        ));
    }
    Err(anyhow::anyhow!("mediafire login.php: no session_token"))
}

async fn mf_login_api(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<Value> {
    let url = "https://www.mediafire.com/api/1.5/user/get_session_token.php";
    let mut last_err = None;
    for (app_id, api_key) in mf_app_pairs() {
        let signature = mf_login_signature(email, password, &app_id, &api_key);
        let form = [
            ("email", email),
            ("password", password),
            ("application_id", app_id.as_str()),
            ("signature", signature.as_str()),
            ("version", "1"),
            ("response_format", "json"),
        ];
        let (status, text) = curl
            .post_form(cfg, "mediafire login", url, &form, MF_API_HEADERS, false)
            .await?;
        let body = parse_json_text(cfg.provider, status, &text, "mediafire login")?;
        match parse_api_result(&body) {
            Ok(()) => return Ok(body),
            Err(e) => {
                if format!("{e:#}").contains("cloud auth:") {
                    return Err(e);
                }
                last_err = Some(anyhow::anyhow!(
                    "mediafire login app_id={app_id}: {e:#}"
                ));
            }
        }
    }
    Err(last_err.unwrap_or_else(|| anyhow::anyhow!("mediafire login failed")))
}

async fn mf_get(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    path: &str,
    params: &[(&str, &str)],
) -> Result<Value> {
    let mut pairs: Vec<(&str, &str)> = params.to_vec();
    pairs.push(("response_format", "json"));
    let url = build_url(
        &format!("https://www.mediafire.com/api/1.5/{path}"),
        &pairs,
    )?;
    mf_get_json(cfg, curl, path, &url).await
}

async fn mf_get_json(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    path: &str,
    url: &str,
) -> Result<Value> {
    let (status, text) = curl
        .exchange(
            cfg,
            &format!("mediafire GET {path}"),
            Method::GET,
            url,
            None,
            MF_API_HEADERS,
            false,
        )
        .await
        .map(|(s, t, _)| (s, t))?;
    let body = parse_json_text(cfg.provider, status, &text, &format!("mediafire GET {path}"))?;
    parse_api_result(&body)?;
    Ok(body)
}

fn parse_api_result(v: &Value) -> Result<()> {
    let result = v
        .pointer("/response/result")
        .and_then(|x| x.as_str())
        .unwrap_or("");
    if result == "Success" {
        return Ok(());
    }
    let code = mf_error_code(v);
    let msg = mf_error_message(v, result);
    if mf_is_bad_credentials(&code, &msg) {
        return Err(cloud_auth_error(msg));
    }
    Err(anyhow::anyhow!("mediafire api: {msg} (code {code})"))
}

fn mf_error_code(v: &Value) -> String {
    if let Some(code) = v.pointer("/response/error_code").and_then(parse_error_code_value) {
        if !code.is_empty() {
            return code;
        }
    }
    if let Some(err) = v.pointer("/response/error") {
        match err {
            Value::Number(n) => return n.to_string(),
            Value::String(s) => return s.clone(),
            Value::Object(o) => {
                if let Some(c) = o.get("code") {
                    return match c {
                        Value::Number(n) => n.to_string(),
                        Value::String(s) => s.clone(),
                        _ => c.to_string(),
                    };
                }
            }
            _ => {}
        }
    }
    String::new()
}

fn parse_error_code_value(v: &Value) -> Option<String> {
    match v {
        Value::Number(n) => Some(n.to_string()),
        Value::String(s) if !s.is_empty() => Some(s.clone()),
        _ => None,
    }
}

fn mf_error_message(v: &Value, result: &str) -> String {
    v.pointer("/response/message")
        .and_then(|x| x.as_str())
        .or_else(|| v.pointer("/response/error/message").and_then(|x| x.as_str()))
        .unwrap_or(result)
        .to_string()
}

fn mf_is_bad_credentials(code: &str, msg: &str) -> bool {
    let lower = msg.to_lowercase();
    matches!(code, "102" | "103" | "107" | "109" | "129")
        || lower.contains("password")
        || lower.contains("email")
        || lower.contains("credentials")
        || lower.contains("do not match")
        || lower.contains("invalid email")
}

fn parse_session_token(v: &Value) -> Result<String> {
    parse_api_result(v)?;
    v.pointer("/response/session_token")
        .and_then(|x| x.as_str())
        .map(|s| s.to_string())
        .ok_or_else(|| anyhow::anyhow!("mediafire: missing session_token"))
}

fn parse_user_info(v: &Value) -> Result<(u64, u64, bool)> {
    let info = v
        .pointer("/response/user_info")
        .ok_or_else(|| anyhow::anyhow!("mediafire: missing user_info"))?;
    let used = info
        .get("used_quota_size")
        .and_then(parse_u64_value)
        .unwrap_or(0);
    let quota = info
        .get("storage_limit")
        .and_then(parse_u64_value)
        .unwrap_or(0);
    let premium = info
        .get("premium")
        .and_then(|x| x.as_str())
        .map(|s| s != "0")
        .unwrap_or(false);
    Ok((used, quota, premium))
}

fn parse_u64_value(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use crate::cloud::common::scan_status_for_cloud_anyhow;
    use crate::cloud::curl_http::parse_json_text;
    use pma_core::CloudProvider;

    #[test]
    fn mf_code_107_is_cloud_auth() {
        let v = serde_json::json!({
            "response": {
                "result": "Error",
                "error": 107,
                "message": "The Credentials you entered are invalid"
            }
        });
        let err = parse_api_result(&v).unwrap_err();
        let text = format!("{err:#}");
        assert!(text.contains("cloud auth:"), "{text}");
        assert_eq!(
            scan_status_for_cloud_anyhow(&err),
            pma_core::ScanStatus::InvalidCredentials
        );
    }

    #[test]
    fn login_php_error_2006_is_soft_fail_not_auth() {
        let body = r#"{"response":{"error":2006,"remaining":10}}"#;
        let err = parse_login_php_session(CloudProvider::Mediafire, 200, body).unwrap_err();
        let text = format!("{err:#}");
        assert!(!text.contains("cloud auth:"), "{text}");
        assert!(text.contains("2006"), "{text}");
    }

    #[test]
    fn login_php_session_token_at_root() {
        let body = r#"{"session_token":"abc123xyz"}"#;
        let token = parse_login_php_session(CloudProvider::Mediafire, 200, body)
        .unwrap();
        assert_eq!(token, "abc123xyz");
    }

    #[test]
    fn proxy_html_login_page_is_network_not_invalid_json() {
        let body = "<html><head><title>HIWIFI</title></head><body></body></html>";
        let err = parse_json_text(
            CloudProvider::Mediafire,
            200,
            body,
            "mediafire login",
        )
        .unwrap_err();
        let text = format!("{err:#}");
        assert!(text.contains("cloud network:"), "{text}");
        assert!(text.contains("non-API body"), "{text}");
    }
}
