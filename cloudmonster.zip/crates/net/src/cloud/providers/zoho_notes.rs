﻿//! Zoho Notebook — Zoho Accounts web sign-in (servicename Notebook), US + EU DC.
//! HTTP via `CloudCurlSession` (= reqwest + manual cookies, not curl-impersonate).

use crate::cloud::common::{
    cloud_auth_error, cloud_network_error, cloud_rate_limit_error, inventory_from_account,
    run_checker, CloudFileMeta, CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use base64::Engine;
use pma_core::Credential;
use rand::rngs::OsRng;
use regex::Regex;
use reqwest::Client;
use rsa::pkcs1::DecodeRsaPublicKey;
use rsa::pkcs8::DecodePublicKey;
use rsa::{Pkcs1v15Encrypt, RsaPublicKey};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug)]
struct ZohoDc {
    accounts_host: &'static str,
    notebook_origin: &'static str,
}

impl ZohoDc {
    const ALL: &'static [ZohoDc] = &[
        ZohoDc {
            accounts_host: "accounts.zoho.com",
            notebook_origin: "https://notebook.zoho.com",
        },
        ZohoDc {
            accounts_host: "accounts.zoho.eu",
            notebook_origin: "https://notebook.zoho.eu",
        },
    ];

    fn index(&self) -> usize {
        if self.accounts_host.contains(".eu") {
            1
        } else {
            0
        }
    }

    fn by_index(i: usize) -> &'static ZohoDc {
        &Self::ALL[i.min(Self::ALL.len() - 1)]
    }

    /// Preemptive DC from email domain TLD (fallback DC only on WrongDatacenter).
    fn determine_by_email(email: &str) -> &'static ZohoDc {
        if zoho_email_suggests_eu_dc(email) {
            Self::by_index(1)
        } else {
            Self::by_index(0)
        }
    }

    fn alternate(&self) -> &'static ZohoDc {
        Self::by_index(1 - self.index())
    }

    fn signin_page(&self) -> String {
        let serviceurl = zoho_pct(&format!("{}/", self.notebook_origin));
        format!(
            "https://{}/signin?v=2&servicename=ZohoNotebook&serviceurl={serviceurl}",
            self.accounts_host,
        )
    }

    fn signin_auth_url(&self) -> String {
        format!("https://{}/signin/auth", self.accounts_host)
    }

    fn notebook_api(&self) -> String {
        format!("{}/api/v1", self.notebook_origin)
    }
}

static ZOHO_DC_CACHE: OnceLock<Mutex<HashMap<String, u8>>> = OnceLock::new();

fn zoho_email_cache_key(email: &str) -> String {
    let mut h = Sha256::new();
    h.update(email.trim().to_ascii_lowercase().as_bytes());
    hex::encode(h.finalize())
}

fn zoho_cached_dc_index(email: &str) -> Option<usize> {
    let key = zoho_email_cache_key(email);
    ZOHO_DC_CACHE
        .get_or_init(|| Mutex::new(HashMap::new()))
        .lock()
        .ok()
        .and_then(|g| g.get(&key).copied())
        .map(|i| i as usize)
}

fn zoho_remember_dc(email: &str, dc: &ZohoDc) {
    let key = zoho_email_cache_key(email);
    let idx = dc.index() as u8;
    if let Ok(mut g) = ZOHO_DC_CACHE
        .get_or_init(|| Mutex::new(HashMap::new()))
        .lock()
    {
        g.insert(key, idx);
    }
}

fn zoho_email_domain_lower(email: &str) -> String {
    email
        .trim()
        .split('@')
        .nth(1)
        .unwrap_or("")
        .to_ascii_lowercase()
}

const ZOHO_EU_DOMAIN_SUFFIXES: &[&str] = &[".eu", ".de", ".uk", ".fr", ".co.uk"];
const ZOHO_US_DOMAIN_SUFFIXES: &[&str] = &[".com", ".net", ".org"];

fn zoho_email_suggests_eu_dc(email: &str) -> bool {
    let domain = zoho_email_domain_lower(email);
    if domain.is_empty() {
        return false;
    }
    ZOHO_EU_DOMAIN_SUFFIXES
        .iter()
        .any(|suf| domain.ends_with(suf))
}

fn zoho_primary_dc(email: &str) -> &'static ZohoDc {
    if let Some(i) = zoho_cached_dc_index(email) {
        return ZohoDc::by_index(i);
    }
    ZohoDc::determine_by_email(email)
}

fn zoho_dc_attempt_order(email: &str) -> Vec<&'static ZohoDc> {
    vec![zoho_primary_dc(email)]
}

const ZOHO_UA_POOL: &[(&str, &str, &str)] = &[
    (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        r#""Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24""#,
        "Windows",
    ),
    (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        r#""Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122""#,
        "Windows",
    ),
    (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        r#""Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24""#,
        "macOS",
    ),
];

struct ZohoBrowserProfile {
    headers: Vec<(String, String)>,
}

impl ZohoBrowserProfile {
    fn for_email(email: &str) -> Self {
        let mut h = Sha256::new();
        h.update(email.trim().to_ascii_lowercase().as_bytes());
        let digest = h.finalize();
        let slot = (digest[0] as usize) % ZOHO_UA_POOL.len();
        let (ua, sec_ch, platform) = ZOHO_UA_POOL[slot];
        let headers = vec![
            ("User-Agent".into(), ua.into()),
            ("sec-ch-ua".into(), sec_ch.into()),
            ("sec-ch-ua-mobile".into(), "?0".into()),
            ("sec-ch-ua-platform".into(), format!("\"{platform}\"")),
            (
                "Accept".into(),
                "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
                    .into(),
            ),
            (
                "Accept-Language".into(),
                "en-US,en;q=0.9,ru;q=0.8".into(),
            ),
        ];
        Self { headers }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ZohoFlowKind {
    InvalidCredentials,
    AccountMissing,
    MfaOrCaptcha,
    RateLimitOrWaf,
    ServerError,
    WrongDatacenter,
    SigninInfrastructure,
    NetworkOrUnknown,
}

#[derive(Debug)]
struct ZohoTaggedError {
    kind: ZohoFlowKind,
}

impl std::fmt::Display for ZohoTaggedError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "zoho flow kind {:?}", self.kind)
    }
}

impl std::error::Error for ZohoTaggedError {}

fn zoho_tag(kind: ZohoFlowKind, err: anyhow::Error) -> anyhow::Error {
    err.context(ZohoTaggedError { kind })
}

fn zoho_flow_kind(err: &anyhow::Error) -> ZohoFlowKind {
    for cause in err.chain() {
        if let Some(t) = cause.downcast_ref::<ZohoTaggedError>() {
            return t.kind;
        }
    }
    zoho_flow_kind_from_text(&format!("{err:#}"))
}

fn zoho_flow_kind_from_text(text: &str) -> ZohoFlowKind {
    let t = text.to_ascii_lowercase();
    if t.contains("cloud auth:") {
        if t.contains("invalid") || t.contains("not authorized") || t.contains("signin failed") {
            return ZohoFlowKind::InvalidCredentials;
        }
        if t.contains("not registered") || t.contains("does not exist") {
            return ZohoFlowKind::AccountMissing;
        }
        return ZohoFlowKind::InvalidCredentials;
    }
    if t.contains("cloud rate limit:") || t.contains("captcha") || t.contains("mfa") {
        return ZohoFlowKind::MfaOrCaptcha;
    }
    if t.contains("waf blocked") || t.contains("forbidden (403)") {
        return ZohoFlowKind::RateLimitOrWaf;
    }
    if t.contains("server error (5") || t.contains("server error (6") {
        return ZohoFlowKind::ServerError;
    }
    if t.contains("another dc")
        || t.contains("another datacenter")
        || t.contains("regional datacenter")
        || t.contains("u400")
    {
        return ZohoFlowKind::WrongDatacenter;
    }
    if t.contains("cloud network:") {
        return ZohoFlowKind::NetworkOrUnknown;
    }
    if t.contains("no success confirmation")
        || t.contains("login not verified")
        || t.contains("no iam session")
        || t.contains("missing iamcsr")
        || t.contains("signin page http")
        || t.contains("signin auth http 404")
        || t.contains("unsupported signin mode")
        || t.contains("zoho lookup http")
        || t.contains("zoho iam error")
    {
        return ZohoFlowKind::SigninInfrastructure;
    }
    ZohoFlowKind::NetworkOrUnknown
}

/// Maps HTTP status from Zoho/IAM to checker-visible errors (403/401/5xx differentiation).
fn zoho_http_status_error(status: u16, ctx: &str, body: &str) -> anyhow::Error {
    let preview = preview(body, 160);
    match status {
        401 => cloud_auth_error(format!("{ctx}: invalid credentials (401)")),
        403 => {
            let lower = body.to_ascii_lowercase();
            let waf = lower.contains("captcha")
                || lower.contains("waf")
                || lower.contains("access denied")
                || lower.contains("cf-browser-verification");
            cloud_rate_limit_error(format!(
                "{ctx}: {} (403) {}",
                if waf { "waf/rate limit" } else { "forbidden" },
                preview
            ))
        }
        429 => cloud_rate_limit_error(format!("{ctx}: rate limit exceeded (429)")),
        500..=599 => cloud_network_error(format!("{ctx}: server error ({status})")),
        n if (400..500).contains(&n) => zoho_tag(
            ZohoFlowKind::SigninInfrastructure,
            anyhow!("{ctx}: http {status} {preview}"),
        ),
        _ => anyhow!("{ctx}: http {status}"),
    }
}

fn zoho_http_status_result(status: u16, ctx: &str, body: &str) -> Result<()> {
    if status < 400 {
        return Ok(());
    }
    Err(zoho_http_status_error(status, ctx, body))
}

/// One account = one `CloudCurlSession` pipeline; auth token filled after sign-in.
struct ZohoSessionContext {
    curl: CloudCurlSession,
    dc: &'static ZohoDc,
    auth_token: Option<String>,
}

impl ZohoSessionContext {
    fn new(email: &str, dc: &'static ZohoDc) -> Result<Self> {
        let mut curl = CloudCurlSession::new()?;
        curl.set_browser_profile(ZohoBrowserProfile::for_email(email).headers);
        Ok(Self {
            curl,
            dc,
            auth_token: None,
        })
    }

    fn curl_mut(&mut self) -> &mut CloudCurlSession {
        &mut self.curl
    }
}

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        zoho_inventory(cfg, client, cred)
    })
    .await
}

async fn zoho_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();

    let primary = zoho_primary_dc(&email);
    match zoho_inventory_dc(cfg, primary, &email, &password).await {
        Ok(inv) => {
            zoho_remember_dc(&email, primary);
            return Ok(inv);
        }
        Err(e) if zoho_try_next_dc(&e) => {
            let alt = primary.alternate();
            if alt.index() == primary.index() {
                return Err(e);
            }
            match zoho_inventory_dc(cfg, alt, &email, &password).await {
                Ok(inv) => {
                    zoho_remember_dc(&email, alt);
                    Ok(inv)
                }
                Err(e2) => Err(e2),
            }
        }
        Err(e) => Err(e),
    }
}

fn zoho_try_next_dc(err: &anyhow::Error) -> bool {
    matches!(zoho_flow_kind(err), ZohoFlowKind::WrongDatacenter)
}

async fn zoho_inventory_dc(
    cfg: &CloudClientConfig,
    dc: &'static ZohoDc,
    email: &str,
    password: &str,
) -> Result<CloudInventory> {
    let mut session = ZohoSessionContext::new(email, dc)?;
    let signin_page = dc.signin_page();

    let body = {
        let curl = session.curl_mut();
        let accounts_origin = format!("https://{}", dc.accounts_host);
        let signin_hdrs = [
            ("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
            ("Referer", accounts_origin.as_str()),
            ("Origin", accounts_origin.as_str()),
        ];
        let (status, html) = curl
            .get_text(cfg, "zoho signin page", &signin_page, &signin_hdrs, true)
            .await
            .context("zoho signin page")?;
        zoho_http_status_result(status, "zoho signin page", &html)?;

        let iamcsr = curl
            .cookie_value("iamcsr")
            .map(str::to_string)
            .or_else(|| parse_hidden_iamcsr(&html))
            .ok_or_else(|| {
                zoho_tag(
                    ZohoFlowKind::SigninInfrastructure,
                    anyhow!(
                        "zoho: missing iamcsr (http {status}, {} bytes): {}",
                        html.len(),
                        preview(&html, 120)
                    ),
                )
            })?;

        let waf_key = parse_zoho_waf_public_key(&html);

        let cli_time = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_millis().to_string())
            .unwrap_or_else(|_| "0".into());

        curl.seed_cookie("iamcsr", &iamcsr);

        let body = match zoho_signin_password_flow(
            cfg,
            curl,
            dc,
            &signin_page,
            email,
            password,
            &iamcsr,
            &cli_time,
            waf_key.as_deref(),
        )
        .await
        {
            Ok(b) => b,
            Err(v2_err) => {
                if zoho_skip_legacy_after_v2(&v2_err) {
                    return Err(v2_err);
                }
                zoho_signin_legacy_form(cfg, curl, dc, email, password, &iamcsr, &cli_time)
                    .await
                    .map_err(|legacy_err| {
                        anyhow!(
                            "v2: {v2_err:#}; legacy: {legacy_err:#} (report v2 line only — legacy is deprecated)"
                        )
                    })?
            }
        };
        body
    };

    session.auth_token = extract_access_token(&body);
    let access_token = session.auth_token.clone();
    let curl = session.curl_mut();

    if !zoho_iam_session_established(curl) {
        return Err(cloud_auth_error("zoho: no iam session"));
    }

    zoho_open_notebook_app(cfg, curl, dc).await?;
    let profile = zoho_load_notebook_profile(cfg, curl, dc).await?;

    let (files, _, _) =
        zoho_list_notecards(cfg, curl, dc, access_token.as_deref()).await?;
    let (used, quota, tariff, list_note) =
        zoho_inventory_from_profile(email, dc, profile.as_ref());
    let mut inv = inventory_from_account(email, files, used, quota, tariff);
    inv.list_note = list_note;
    Ok(inv)
}

fn zoho_pct(s: &str) -> String {
    url::form_urlencoded::byte_serialize(s.as_bytes()).collect()
}

fn zoho_signin_query(dc: &ZohoDc, cli_time: &str) -> String {
    format!(
        "cli_time={cli_time}&servicename=ZohoNotebook&serviceurl={}",
        zoho_pct(&format!("{}/", dc.notebook_origin))
    )
}

fn zoho_csrf_headers(iamcsr: &str) -> Vec<(String, String)> {
    vec![
        ("X-ZCSRF-TOKEN".into(), format!("iamcsrcoo={iamcsr}")),
        ("Accept".into(), "application/json".into()),
    ]
}

fn zoho_signin_request_headers(
    dc: &ZohoDc,
    iamcsr: &str,
    signin_page: &str,
) -> Vec<(String, String)> {
    let mut h = zoho_csrf_headers(iamcsr);
    h.push(("Referer".into(), signin_page.to_string()));
    h.push(("Origin".into(), format!("https://{}", dc.accounts_host)));
    h
}

fn zoho_skip_legacy_after_v2(err: &anyhow::Error) -> bool {
    let t = format!("{err:#}").to_lowercase();
    // v2 IAM already answered — legacy HTML form always 404 on modern Zoho.
    if t.contains("cloud auth:") {
        return true;
    }
    t.contains("no passwordauth")
        || t.contains("zoho iam")
        || t.contains("zoho lookup json")
        || t.contains("zoho lookup http")
        || t.contains("regional datacenter")
        || t.contains("unsupported signin mode")
        || t.contains("missing identifier")
        || t.contains("missing digest")
        || t.contains("invalid email or password")
        || t.contains("in102")
        || t.contains("in103")
}

fn zoho_sync_iamcsr(curl: &CloudCurlSession, fallback: &str) -> String {
    curl.cookie_value("iamcsr")
        .map(str::to_string)
        .unwrap_or_else(|| fallback.to_string())
}

fn zoho_json_redirect_url(v: &Value) -> Option<String> {
    for key in [
        "redirect_uri",
        "redirect_url",
        "serviceurl",
        "service_url",
        "location",
    ] {
        if let Some(s) = v.get(key).and_then(|x| x.as_str()) {
            let t = s.trim();
            if !t.is_empty() {
                return Some(t.to_string());
            }
        }
    }
    v.get("data")
        .and_then(zoho_json_redirect_url)
        .or_else(|| v.get("lookup").and_then(zoho_json_redirect_url))
}

async fn zoho_follow_signin_redirect(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
    body: &str,
) {
    let Ok(v) = serde_json::from_str::<Value>(body.trim()) else {
        return;
    };
    let Some(mut url) = zoho_json_redirect_url(&v) else {
        return;
    };
    if url.starts_with('/') {
        url = format!("https://{}{url}", dc.accounts_host);
    }
    let _ = curl
        .get_text(
            cfg,
            "zoho signin redirect",
            &url,
            &[("Accept", "text/html,application/json")],
            true,
        )
        .await;
}

fn zoho_signin_code_indicates_progress(code: &str, v: &Value) -> bool {
    let upper = code.to_ascii_uppercase();
    if upper == "SUCCESS" {
        return true;
    }
    // IAM v2: SI302 = post-password redirect handshake (not invalid password).
    if upper == "SI302" {
        return true;
    }
    false
}

fn zoho_password_step_accepted(curl: &CloudCurlSession, body: &str) -> bool {
    if zoho_iam_session_established(curl) || body.contains("showsuccess(") {
        return true;
    }
    let Ok(v) = serde_json::from_str::<Value>(body.trim()) else {
        return false;
    };
    if let Some(code) = v.get("code").and_then(|x| x.as_str()) {
        return zoho_signin_code_indicates_progress(code, &v);
    }
    false
}

async fn zoho_signin_password_flow(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
    signin_page: &str,
    email: &str,
    password: &str,
    iamcsr: &str,
    cli_time: &str,
    waf_public_key: Option<&str>,
) -> Result<String> {
    let signin_q = zoho_signin_query(dc, cli_time);
    let mut csrf = zoho_signin_request_headers(dc, iamcsr, signin_page);
    if let Some(waf_hdr) = zoho_waf_encryption_header(waf_public_key, email)? {
        csrf.push(("Waf-Encryption-Key".into(), waf_hdr));
    }
    let csrf_refs = header_string_refs(&csrf);

    let lookup_url = format!(
        "https://{}/signin/v2/lookup/{}",
        dc.accounts_host,
        zoho_pct(email)
    );
    let lookup_body = format!("mode=primary&{signin_q}");
    let (lookup_status, lookup_text) = curl
        .post_body(
            cfg,
            "zoho signin lookup",
            &lookup_url,
            lookup_body.into_bytes(),
            "application/x-www-form-urlencoded;charset=UTF-8",
            &csrf_refs,
            false,
        )
        .await
        .context("zoho signin lookup")?;

    if lookup_status == 429 {
        return Err(cloud_rate_limit_error("zoho signin rate limited"));
    }
    if lookup_status >= 400 {
        return Err(zoho_http_status_error(
            lookup_status,
            "zoho signin lookup",
            &lookup_text,
        ));
    }

    let lookup: Value = serde_json::from_str(lookup_text.trim())
        .with_context(|| format!("zoho lookup json: {}", preview(&lookup_text, 160)))?;

    let lookup = if zoho_lookup_needs_regional_dc(&lookup) {
        zoho_regional_lookup_retry(
            cfg,
            curl,
            dc,
            email,
            iamcsr,
            signin_page,
            cli_time,
            waf_public_key,
            &signin_q,
            &lookup,
        )
        .await?
    } else if zoho_lookup_is_wrong_dc(&lookup) {
        return Err(zoho_tag(
            ZohoFlowKind::WrongDatacenter,
            anyhow!("zoho lookup: regional datacenter (account registered on another Zoho DC)"),
        ));
    } else if let Some(target) = zoho_lookup_redirect_accounts_host(&lookup) {
        if target != dc.accounts_host {
            return Err(zoho_tag(
                ZohoFlowKind::WrongDatacenter,
                anyhow!("zoho lookup: regional datacenter (redirect to {target})"),
            ));
        }
        lookup
    } else {
        lookup
    };

    zoho_json_auth_errors(&lookup)?;

    let mut iamcsr = zoho_sync_iamcsr(curl, iamcsr);
    curl.seed_cookie("iamcsr", &iamcsr);

    let (auth_mode, pa) = zoho_pick_auth_block(&lookup)?;
    if auth_mode != "passwordauth" {
        return Err(cloud_rate_limit_error(format!(
            "zoho: unsupported signin mode {auth_mode} (use app password / disable federated-only)"
        )));
    }
    let zuid = pa
        .get("identifier")
        .and_then(|x| x.as_str())
        .context("zoho lookup: missing identifier")?;
    let digest = pa
        .get("digest")
        .and_then(|x| x.as_str())
        .context("zoho lookup: missing digest")?;

    let pass_json = serde_json::json!({
        "passwordauth": { "password": password }
    });
    let pass_body = serde_json::to_string(&pass_json).context("zoho password json")?;
    let pass_urls = zoho_password_post_urls(dc, &lookup, pa, zuid, digest, &signin_q);
    let mut last_pass_err = None;
    for pass_url in pass_urls {
        iamcsr = zoho_sync_iamcsr(curl, &iamcsr);
        curl.seed_cookie("iamcsr", &iamcsr);
        let mut pass_csrf = zoho_signin_request_headers(dc, &iamcsr, signin_page);
        if let Some(waf_hdr) = zoho_waf_encryption_header(waf_public_key, password)? {
            pass_csrf.push(("Waf-Encryption-Key".into(), waf_hdr));
        }
        let pass_csrf_refs = header_string_refs(&pass_csrf);
        let (pass_status, pass_text) = curl
            .post_body(
                cfg,
                "zoho signin password",
                &pass_url,
                pass_body.clone().into_bytes(),
                "application/json;charset=UTF-8",
                &pass_csrf_refs,
                true,
            )
            .await
            .context("zoho signin password")?;

        if pass_status == 429 {
            return Err(cloud_rate_limit_error("zoho signin rate limited"));
        }
        if pass_status == 404 {
            last_pass_err = Some(anyhow!("zoho password http 404 ({pass_url})"));
            continue;
        }
        if pass_status >= 400 {
            last_pass_err = Some(zoho_http_status_error(
                pass_status,
                "zoho signin password",
                &pass_text,
            ));
            continue;
        }

        let pass_v: Value = serde_json::from_str(pass_text.trim()).unwrap_or(Value::Null);
        if let Err(e) = zoho_json_auth_errors(&pass_v) {
            last_pass_err = Some(e);
            continue;
        }

        zoho_follow_signin_redirect(cfg, curl, dc, &pass_text).await;
        iamcsr = zoho_sync_iamcsr(curl, &iamcsr);
        curl.seed_cookie("iamcsr", &iamcsr);

        if zoho_password_step_accepted(curl, &pass_text) {
            return Ok(pass_text);
        }
        if let Err(e) = zoho_require_signin_success(&pass_text) {
            last_pass_err = Some(e);
            continue;
        }
        return Ok(pass_text);
    }

    Err(last_pass_err.unwrap_or_else(|| anyhow!("zoho password: all URL variants failed")))
}

fn zoho_password_post_urls(
    dc: &ZohoDc,
    lookup: &Value,
    pa: &Value,
    zuid: &str,
    digest: &str,
    signin_q: &str,
) -> Vec<String> {
    let mut urls = Vec::new();
    if let Some(href) = pa.get("href").and_then(|x| x.as_str()) {
        urls.push(zoho_password_href_url(dc, href, digest, signin_q));
    }
    let v2_prefix = zoho_signin_v2_prefix(lookup);
    for prefix in [
        v2_prefix,
        "signin/v2/l",
        "signin/v2",
        "signin/v2/accounts",
    ] {
        urls.push(format!(
            "https://{}/{prefix}/primary/{zuid}/password?digest={}&{signin_q}",
            dc.accounts_host,
            zoho_pct(digest)
        ));
    }
    urls.sort();
    urls.dedup();
    urls
}

fn zoho_password_href_url(dc: &ZohoDc, href: &str, digest: &str, signin_q: &str) -> String {
    let href = href.trim();
    if href.starts_with("http://") || href.starts_with("https://") {
        if href.contains('?') {
            return format!("{href}&digest={}&{signin_q}", zoho_pct(digest));
        }
        return format!("{href}?digest={}&{signin_q}", zoho_pct(digest));
    }
    let path = href.trim_start_matches('/');
    format!(
        "https://{}/{path}?digest={}&{signin_q}",
        dc.accounts_host,
        zoho_pct(digest)
    )
}

async fn zoho_signin_legacy_form(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
    email: &str,
    password: &str,
    iamcsr: &str,
    cli_time: &str,
) -> Result<String> {
    let serviceurl = format!("{}/", dc.notebook_origin);
    let form = [
        ("LOGIN_ID", email),
        ("PASSWORD", password),
        ("servicename", "ZohoNotebook"),
        ("serviceurl", serviceurl.as_str()),
        ("cli_time", cli_time),
        ("remember", "1"),
        ("iamcsrcoo", "true"),
    ];
    let auth_url = dc.signin_auth_url();
    let (post_status, body) = curl
        .post_form(
            cfg,
            "zoho signin auth",
            &auth_url,
            &form,
            &[("X-ZCSRF-TOKEN", &format!("iamcsrcoo={iamcsr}"))],
            true,
        )
        .await
        .context("zoho signin auth")?;

    if post_status == 429 {
        return Err(cloud_rate_limit_error("zoho signin rate limited"));
    }
    if post_status >= 400 {
        return Err(cloud_auth_error(format!(
            "zoho signin auth http {post_status} ({})",
            dc.accounts_host
        )));
    }

    let lower = body.to_lowercase();
    if lower.contains("hit frequency") || lower.contains("too many") {
        return Err(cloud_rate_limit_error("zoho signin: hit frequency"));
    }

    zoho_require_signin_success(&body)?;
    Ok(body)
}

fn header_string_refs(headers: &[(String, String)]) -> Vec<(&str, &str)> {
    headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect()
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

fn zoho_lookup_needs_regional_dc(v: &Value) -> bool {
    v.get("lookup")
        .and_then(|l| l.get("regional_dc_list"))
        .and_then(|x| x.as_array())
        .is_some_and(|a| !a.is_empty())
}

fn zoho_lookup_is_wrong_dc(v: &Value) -> bool {
    if zoho_lookup_redirect_accounts_host(v).is_some() {
        return true;
    }
    if let Some(errors) = v.get("errors").and_then(|x| x.as_array()) {
        for e in errors {
            let code = e.get("code").and_then(|x| x.as_str()).unwrap_or("");
            let msg = e
                .get("message")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_ascii_lowercase();
            if code.eq_ignore_ascii_case("U400")
                || msg.contains("another dc")
                || msg.contains("another datacenter")
            {
                return true;
            }
        }
    }
    v.get("message")
        .and_then(|x| x.as_str())
        .is_some_and(|m| {
            let ml = m.to_ascii_lowercase();
            ml.contains("another dc") || ml.contains("another datacenter")
        })
}

/// Zoho returns HTTP 200 with `status_code:500` + `data.redirect_uri` when email belongs on another DC.
fn zoho_lookup_redirect_accounts_host(v: &Value) -> Option<&'static str> {
    let uri = v
        .get("data")
        .and_then(|d| d.get("redirect_uri"))
        .and_then(|x| x.as_str())
        .or_else(|| v.get("redirect_uri").and_then(|x| x.as_str()))?;
    let lower = uri.to_ascii_lowercase();
    if lower.contains("accounts.zoho.eu") {
        Some("accounts.zoho.eu")
    } else if lower.contains("accounts.zoho.in") {
        Some("accounts.zoho.in")
    } else if lower.contains("accounts.zoho.com") {
        Some("accounts.zoho.com")
    } else {
        None
    }
}

fn zoho_signin_v2_prefix(v: &Value) -> &'static str {
    let href = v
        .get("lookup")
        .and_then(|l| l.get("href"))
        .and_then(|h| h.as_str())
        .or_else(|| v.get("href").and_then(|h| h.as_str()));
    if href.is_some_and(|h| h.contains("/signin/v2/l/")) {
        "signin/v2/l"
    } else {
        "signin/v2"
    }
}

fn zoho_lookup_roots(v: &Value) -> Vec<&Value> {
    let mut roots = vec![v];
    if let Some(inner) = v.get("lookup").filter(|l| l.is_object()) {
        roots.push(inner);
    }
    roots
}

fn zoho_pick_auth_block(v: &Value) -> Result<(&str, &Value)> {
    const MODES: &[&str] = &["passwordauth", "ldappasswordauth"];
    for root in zoho_lookup_roots(v) {
        for mode in MODES {
            if let Some(block) = root.get(mode).filter(|b| b.get("identifier").is_some()) {
                return Ok((*mode, block));
            }
        }
    }
    for root in zoho_lookup_roots(v) {
        let mode = root
            .get("signinathmode")
            .and_then(|x| x.as_str())
            .unwrap_or("");
        if !mode.is_empty() {
            if let Some(block) = root.get(mode).filter(|b| b.get("identifier").is_some()) {
                return Ok((mode, block));
            }
        }
    }
    for root in zoho_lookup_roots(v) {
        let id = root.get("identifier").and_then(|x| x.as_str()).unwrap_or("");
        let digest = root.get("digest").and_then(|x| x.as_str()).unwrap_or("");
        if id.is_empty() || digest.is_empty() {
            continue;
        }
        let password_allowed = root
            .get("modes")
            .and_then(|m| m.get("allowed_modes"))
            .and_then(|x| x.as_array())
            .map(|modes| {
                modes
                    .iter()
                    .filter_map(|m| m.as_str())
                    .any(|m| m.eq_ignore_ascii_case("password"))
            })
            .unwrap_or(true);
        if password_allowed {
            return Ok(("passwordauth", root));
        }
    }
    if zoho_lookup_needs_regional_dc(v) {
        return Err(zoho_tag(
            ZohoFlowKind::WrongDatacenter,
            anyhow!("zoho lookup: regional datacenter selection required"),
        ));
    }
    if zoho_is_iam_error_envelope(v) {
        return Err(zoho_iam_envelope_error(v));
    }
    let keys: Vec<_> = v
        .as_object()
        .map(|m| m.keys().map(String::as_str).collect())
        .unwrap_or_default();
    Err(anyhow!(
        "zoho lookup: no passwordauth (modes={keys:?}; use app-specific password?)"
    ))
}

fn zoho_is_iam_error_envelope(v: &Value) -> bool {
    v.get("errors").and_then(|x| x.as_array()).is_some_and(|a| !a.is_empty())
        || v.get("status_code")
            .and_then(|x| x.as_u64())
            .is_some_and(|s| !(200..300).contains(&s))
}

fn zoho_iam_envelope_error(v: &Value) -> anyhow::Error {
    if let Some(errors) = v.get("errors").and_then(|x| x.as_array()) {
        if let Some(first) = errors.first() {
            let code = first
                .get("code")
                .and_then(|x| x.as_str())
                .unwrap_or("");
            let msg = first
                .get("message")
                .or_else(|| first.get("localized_message"))
                .and_then(|x| x.as_str())
                .or_else(|| v.get("message").and_then(|x| x.as_str()))
                .unwrap_or("zoho iam rejected lookup");
            let upper = code.to_ascii_uppercase();
            if upper.contains("NOT_EXIST")
                || upper == "IN101"
                || upper == "U401"
                || upper == "ACCOUNT_NOT_EXISTS"
            {
                return cloud_auth_error("zoho: account not registered");
            }
            if upper == "IN102" || upper == "IN103" || upper == "INVALID_PASSWORD" {
                return cloud_auth_error(
                    "zoho: invalid email or password (Notebook: app-specific password в Zoho Account → Security)",
                );
            }
            if upper == "IN107" || upper == "IN108" {
                return cloud_rate_limit_error("zoho: captcha required");
            }
            let msg_lc = msg.to_ascii_lowercase();
            if upper == "U400" || msg_lc.contains("another dc") || msg_lc.contains("another datacenter")
            {
                return zoho_tag(
                    ZohoFlowKind::WrongDatacenter,
                    anyhow!("zoho lookup: regional datacenter ({code}: {msg})"),
                );
            }
            return cloud_network_error(format!("zoho iam: {code} {msg}"));
        }
    }
    let status = v
        .get("status_code")
        .and_then(|x| x.as_u64())
        .unwrap_or(0);
    let msg = v
        .get("message")
        .or_else(|| v.get("localized_message"))
        .and_then(|x| x.as_str())
        .unwrap_or("zoho iam error");
    if status == 404 || msg.to_ascii_lowercase().contains("not exist") {
        return cloud_auth_error("zoho: account not registered");
    }
    if let Some(data) = v.get("data") {
        if let Some(uri) = data.get("redirect_uri").and_then(|x| x.as_str()) {
            return zoho_tag(
                ZohoFlowKind::WrongDatacenter,
                anyhow!("zoho lookup: regional datacenter (redirect {uri})"),
            );
        }
    }
    cloud_network_error(format!("zoho iam error ({status}): {msg}"))
}

fn parse_zoho_waf_public_key(html: &str) -> Option<String> {
    static RE_PEM: OnceLock<Regex> = OnceLock::new();
    let re_pem = RE_PEM.get_or_init(|| {
        Regex::new(
            r"-----BEGIN PUBLIC KEY-----[\s\S]+?-----END PUBLIC KEY-----",
        )
        .expect("zoho pem re")
    });
    if let Some(m) = re_pem.find(html) {
        return Some(m.as_str().to_string());
    }
    static RE_WAF: OnceLock<Regex> = OnceLock::new();
    let re = RE_WAF.get_or_init(|| {
        Regex::new(
            r#"(?i)(?:waf[_-]?public[_-]?key|wafpkkey)\s*[:=]\s*["']([^"']+)["']"#,
        )
        .expect("waf re")
    });
    re.captures(html)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn zoho_normalize_rsa_pem(raw: &str) -> String {
    let t = raw.trim();
    if t.contains("BEGIN PUBLIC KEY") || t.contains("BEGIN RSA PUBLIC KEY") {
        return t.to_string();
    }
    let b64: String = t.chars().filter(|c| !c.is_whitespace()).collect();
    let mut lines = String::from("-----BEGIN PUBLIC KEY-----\n");
    for chunk in b64.as_bytes().chunks(64) {
        lines.push_str(std::str::from_utf8(chunk).unwrap_or(""));
        lines.push('\n');
    }
    lines.push_str("-----END PUBLIC KEY-----");
    lines
}

fn zoho_parse_public_key(pem: &str) -> Result<RsaPublicKey> {
    if pem.contains("BEGIN RSA PUBLIC KEY") {
        return RsaPublicKey::from_pkcs1_pem(pem).context("zoho rsa pkcs1");
    }
    RsaPublicKey::from_public_key_pem(pem).context("zoho rsa spki")
}

fn zoho_rsa_encrypt_field(raw_key: &str, value: &str) -> Result<String> {
    let pem = zoho_normalize_rsa_pem(raw_key);
    let public_key = zoho_parse_public_key(&pem)?;
    let mut rng = OsRng;
    let encrypted = public_key
        .encrypt(&mut rng, Pkcs1v15Encrypt, value.as_bytes())
        .context("zoho waf rsa encrypt")?;
    Ok(base64::engine::general_purpose::STANDARD.encode(encrypted))
}

fn zoho_waf_encryption_header(public_key_pem: Option<&str>, value: &str) -> Result<Option<String>> {
    match public_key_pem {
        None => Ok(None),
        Some(k) if k.trim().is_empty() => Ok(None),
        Some(k) => zoho_rsa_encrypt_field(k, value).map(Some),
    }
}

async fn zoho_regional_lookup_retry(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
    email: &str,
    iamcsr: &str,
    signin_page: &str,
    cli_time: &str,
    waf_public_key: Option<&str>,
    signin_q: &str,
    first: &Value,
) -> Result<Value> {
    let list = first
        .get("lookup")
        .and_then(|l| l.get("regional_dc_list"))
        .and_then(|x| x.as_array())
        .filter(|a| !a.is_empty())
        .context("zoho regional: empty list")?;

    let prefer_eu = dc.accounts_host.contains(".eu");
    let entry = list
        .iter()
        .find(|e| {
            prefer_eu
                && e.get("domain")
                    .or_else(|| e.get("accounts_url"))
                    .and_then(|x| x.as_str())
                    .is_some_and(|s| s.contains("zoho.eu"))
        })
        .or_else(|| list.first())
        .context("zoho regional: no entry")?;

    let region = entry
        .get("domain")
        .or_else(|| entry.get("region"))
        .or_else(|| entry.get("dc"))
        .or_else(|| entry.get("location"))
        .and_then(|x| x.as_str())
        .unwrap_or(if prefer_eu { "eu" } else { "com" });

    let lookup_url = format!(
        "https://{}/signin/v2/lookup/{}",
        dc.accounts_host,
        zoho_pct(email)
    );

    for extra in [
        format!("mode=primary&{signin_q}&region={}", zoho_pct(region)),
        format!("mode=primary&{signin_q}&domain={}", zoho_pct(region)),
        format!(
            "mode=primary&{signin_q}&cli_time={cli_time}&servicename=ZohoNotebook&region={}",
            zoho_pct(region)
        ),
    ] {
        let mut csrf = zoho_signin_request_headers(dc, iamcsr, signin_page);
        if let Some(waf_hdr) = zoho_waf_encryption_header(waf_public_key, email)? {
            csrf.push(("Waf-Encryption-Key".into(), waf_hdr));
        }
        let csrf_refs = header_string_refs(&csrf);
        let (status, text) = curl
            .post_body(
                cfg,
                "zoho signin lookup regional",
                &lookup_url,
                extra.into_bytes(),
                "application/x-www-form-urlencoded;charset=UTF-8",
                &csrf_refs,
                false,
            )
            .await
            .context("zoho regional lookup")?;
        if status >= 400 {
            continue;
        }
        let v: Value = serde_json::from_str(text.trim()).unwrap_or(Value::Null);
        zoho_json_auth_errors(&v)?;
        if zoho_pick_auth_block(&v).is_ok() {
            return Ok(v);
        }
    }

    Err(zoho_tag(
        ZohoFlowKind::WrongDatacenter,
        anyhow!(
            "zoho lookup: regional datacenter selection required ({})",
            dc.accounts_host
        ),
    ))
}

fn zoho_json_auth_errors(v: &Value) -> Result<()> {
    if zoho_is_iam_error_envelope(v) {
        return Err(zoho_iam_envelope_error(v));
    }
    if let Some(code) = v.get("code").and_then(|x| x.as_str()) {
        let upper = code.to_ascii_uppercase();
        if upper == "SUCCESS" {
            return Ok(());
        }
        if upper.contains("PASSWORD") || upper == "INVALID_PASSWORD" {
            return Err(cloud_auth_error("zoho: invalid email or password"));
        }
        if upper.contains("MFA") || upper.contains("OTP") || upper.contains("TFA") {
            return Err(cloud_rate_limit_error("zoho: mfa/otp required"));
        }
    }
    if let Some(errors) = v.get("errors").and_then(|x| x.as_array()) {
        if let Some(first) = errors.first() {
            if let Some(code) = first.get("code").and_then(|x| x.as_str()) {
                if code == "IN102" || code == "IN103" || code == "INVALID_PASSWORD" {
                    return Err(cloud_auth_error("zoho: invalid email or password"));
                }
                if code == "IN107" || code == "IN108" {
                    return Err(cloud_rate_limit_error("zoho: captcha required"));
                }
            }
        }
    }
    if let Some(status) = v.get("status_code").and_then(|x| x.as_u64()) {
        if (200..300).contains(&status) {
            return Ok(());
        }
        return Err(zoho_iam_envelope_error(v));
    }
    Ok(())
}

/// Real login (EU/US): `_iamadt`, `_iambdt`, `IAMSATCK_*`, `_z_identity=true` — not `JSESSIONID` alone.
fn zoho_iam_session_established(curl: &CloudCurlSession) -> bool {
    curl.cookie_value("_iamadt").is_some()
        || curl.cookie_value("_iambdt").is_some()
        || curl.cookie_value("__Secure-iamsdt").is_some()
        || curl.any_cookie_name_starts_with("IAMSATCK_")
        || curl
            .cookie_value("_z_identity")
            .is_some_and(|v| v.eq_ignore_ascii_case("true"))
}

fn zoho_require_signin_success(body: &str) -> Result<()> {
    if body.contains("showsuccess(") {
        return Ok(());
    }

    if let Ok(v) = serde_json::from_str::<Value>(body.trim()) {
        if let Some(code) = v.get("code").and_then(|x| x.as_str()) {
            let upper = code.to_ascii_uppercase();
            if upper == "SUCCESS" {
                return Ok(());
            }
            if upper.contains("PASSWORD")
                || upper.contains("INVALID")
                || upper == "LOGIN_FAILED"
                || upper == "ACCOUNT_NOT_EXISTS"
                || upper == "ACCOUNT_DOES_NOT_EXIST"
            {
                return Err(cloud_auth_error("zoho: invalid email or password"));
            }
            if upper.contains("MFA") || upper.contains("TFA") || upper.contains("OTP") {
                return Err(cloud_rate_limit_error("zoho: mfa/otp required"));
            }
            if upper.contains("CAPTCHA") {
                return Err(cloud_rate_limit_error("zoho: captcha required"));
            }
            if zoho_signin_code_indicates_progress(&upper, &v) {
                return Ok(());
            }
            if upper == "SI302" {
                return Err(cloud_rate_limit_error(
                    "zoho: signin redirect (SI302) — session not established; retry or use app-specific password",
                ));
            }
            return Err(cloud_auth_error(format!("zoho signin: {code}")));
        }
        if v.get("status").and_then(|x| x.as_str()) == Some("failed") {
            return Err(cloud_auth_error("zoho: signin failed"));
        }
    }

    let lower = body.to_lowercase();
    if lower.contains("invalid password")
        || lower.contains("incorrect password")
        || lower.contains("password is incorrect")
        || lower.contains("account does not exist")
    {
        return Err(cloud_auth_error("zoho: invalid email or password"));
    }

    Err(cloud_auth_error("zoho signin: no success confirmation"))
}

async fn zoho_load_notebook_profile(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
) -> Result<Option<Value>> {
    let base_headers = zoho_api_headers(dc, None);
    let base_refs = header_refs(&base_headers);
    let api = dc.notebook_api();

    let mut last_profile: Option<Value> = None;
    for url in [
        format!("{api}/userprofile"),
        format!("{api}/user/profile"),
        format!("{api}/storage"),
        format!("{api}/user/storage"),
    ] {
        let Ok((status, text)) = curl
            .get_text(cfg, "zoho notebook profile", &url, &base_refs, false)
            .await
        else {
            continue;
        };
        if status == 401 {
            return Err(cloud_auth_error("zoho: session not authorized (401)"));
        }
        if status == 403 {
            return Err(zoho_http_status_error(
                status,
                "zoho notebook profile",
                &text,
            ));
        }
        if status >= 500 {
            return Err(zoho_http_status_error(
                status,
                "zoho notebook profile",
                &text,
            ));
        }
        if status >= 400 {
            continue;
        }
        if let Ok(v) = serde_json::from_str::<Value>(text.trim()) {
            if zoho_profile_indicates_login(&text) || !v.is_null() {
                last_profile = Some(v);
                if zoho_profile_indicates_login(&text) {
                    return Ok(last_profile);
                }
            }
        }
    }

    if zoho_iam_session_established(curl) {
        return Ok(last_profile);
    }

    Err(cloud_auth_error(
        "zoho: login not verified (notebook API)",
    ))
}

fn zoho_profile_indicates_login(text: &str) -> bool {
    let Ok(v) = serde_json::from_str::<Value>(text.trim()) else {
        return false;
    };
    if v.get("code")
        .and_then(|x| x.as_str())
        .is_some_and(|c| !c.eq_ignore_ascii_case("SUCCESS") && !c.is_empty())
    {
        return false;
    }
    for key in ["email", "zuid", "user_id", "ZUID", "login_id"] {
        if v.get(key).and_then(|x| x.as_str()).is_some_and(|s| !s.is_empty()) {
            return true;
        }
    }
    if let Some(user) = v.get("user") {
        if user.get("email").or_else(|| user.get("zuid")).is_some() {
            return true;
        }
    }
    false
}

fn zoho_api_headers(dc: &ZohoDc, token: Option<&str>) -> Vec<(String, String)> {
    let mut h = vec![
        ("Accept".to_string(), "application/json".to_string()),
        (
            "Referer".to_string(),
            format!("{}/", dc.notebook_origin),
        ),
        ("Origin".to_string(), dc.notebook_origin.to_string()),
    ];
    if let Some(t) = token {
        h.push(("Authorization".to_string(), format!("Zoho-oauthtoken {t}")));
    }
    h
}

fn header_refs(headers: &[(String, String)]) -> Vec<(&str, &str)> {
    headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect()
}

async fn zoho_open_notebook_app(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
) -> Result<()> {
    let _ = curl
        .get_text(
            cfg,
            "zoho notebook app",
            dc.notebook_origin,
            &[("Accept", "text/html")],
            true,
        )
        .await;
    Ok(())
}

fn zoho_json_u64(v: &Value, keys: &[&str]) -> u64 {
    for key in keys {
        if let Some(n) = v.get(*key).and_then(parse_u64_json) {
            return n;
        }
    }
    0
}

fn zoho_json_str<'a>(v: &'a Value, keys: &[&str]) -> Option<&'a str> {
    keys.iter()
        .find_map(|key| v.get(*key).and_then(|x| x.as_str()).filter(|s| !s.is_empty()))
}

fn zoho_plan_label(v: &Value) -> String {
    if let Some(plan) = zoho_json_str(
        v,
        &[
            "plan_name",
            "plan",
            "user_plan",
            "subscription_plan",
            "service_plan",
            "edition",
        ],
    ) {
        let lower = plan.to_ascii_lowercase();
        if lower.contains("premium") || lower.contains("business") || lower.contains("workplace") {
            return plan.to_string();
        }
        if lower != "free" && lower != "basic" {
            return plan.to_string();
        }
    }
    for key in ["is_premium", "premium", "paid_user", "is_paid"] {
        if v.get(key).and_then(|x| x.as_bool()) == Some(true) {
            return "Premium".into();
        }
    }
    "Free".into()
}

fn zoho_inventory_from_profile(
    _email: &str,
    dc: &ZohoDc,
    profile: Option<&Value>,
) -> (u64, u64, String, Option<String>) {
    let Some(v) = profile else {
        return (
            0,
            0,
            format!("Zoho Notebook ({})", dc.accounts_host),
            None,
        );
    };
    let roots: Vec<&Value> = std::iter::once(v)
        .chain(v.get("user").into_iter())
        .chain(v.get("profile").into_iter())
        .chain(v.get("data").into_iter())
        .collect();

    let mut used = 0u64;
    let mut quota = 0u64;
    let mut plan = String::from("Free");
    let mut last_login = None;

    for root in roots {
        used = used.max(zoho_json_u64(
            root,
            &[
                "used_space",
                "used_storage",
                "storage_used",
                "used_bytes",
                "used",
            ],
        ));
        quota = quota.max(zoho_json_u64(
            root,
            &[
                "total_space",
                "storage_limit",
                "total_storage",
                "quota",
                "allowed_storage",
                "max_storage",
            ],
        ));
        plan = zoho_plan_label(root);
        if last_login.is_none() {
            last_login = zoho_json_str(
                root,
                &[
                    "last_login_time",
                    "last_login",
                    "last_access_time",
                    "last_sign_in",
                    "last_logged_in",
                ],
            )
            .map(str::to_string);
        }
    }

    let tariff = format!("Zoho Notebook {plan} ({})", dc.accounts_host);
    let list_note = last_login.map(|t| format!("Last login: {t}"));
    (used, quota, tariff, list_note)
}

async fn zoho_list_notecards(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    dc: &ZohoDc,
    access_token: Option<&str>,
) -> Result<(Vec<CloudFileMeta>, u64, u64)> {
    let base_headers = zoho_api_headers(dc, access_token);
    let base_refs = header_refs(&base_headers);
    let api = dc.notebook_api();

    let mut files = Vec::new();
    let mut notebook_ids: Vec<(String, String)> = Vec::new();

    if let Ok(v) = curl
        .get_json(cfg, "zoho notebooks", &format!("{api}/notebooks"), &base_refs)
        .await
    {
        notebook_ids = parse_notebook_ids(&v);
    }

    if !notebook_ids.is_empty() {
        for (id, name) in &notebook_ids {
            if files.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let url = format!("{api}/notebooks/{id}/notecards");
            let Ok(v) = curl
                .get_json(cfg, "zoho notecards", &url, &base_refs)
                .await
            else {
                continue;
            };
            push_notecards(&mut files, &v, Some(name.as_str()));
        }
    }

    if files.is_empty() {
        for path in [
            format!("{api}/notecards?limit=200&offset=0"),
            format!("{api}/notecards/all?limit=200"),
            format!("{api}/search/notecards?q=&limit=200"),
        ] {
            if files.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
            let Ok(v) = curl
                .get_json(cfg, "zoho notecards all", &path, &base_refs)
                .await
            else {
                continue;
            };
            push_notecards(&mut files, &v, None);
            if !files.is_empty() {
                break;
            }
        }
    }

    let count = files.len() as u64;
    Ok((files, count, 0))
}

fn parse_notebook_ids(v: &Value) -> Vec<(String, String)> {
    let mut out = Vec::new();
    let items = v
        .get("notebooks")
        .and_then(|x| x.as_array())
        .or_else(|| v.as_array());
    let Some(items) = items else {
        return out;
    };
    for nb in items {
        let id = nb
            .get("notebook_id")
            .or_else(|| nb.get("id"))
            .and_then(|x| x.as_str())
            .unwrap_or("");
        if id.is_empty() {
            continue;
        }
        let name = nb
            .get("name")
            .or_else(|| nb.get("notebook_name"))
            .and_then(|x| x.as_str())
            .unwrap_or("notebook");
        out.push((id.to_string(), name.to_string()));
    }
    out
}

fn push_notecards(out: &mut Vec<CloudFileMeta>, v: &Value, notebook: Option<&str>) {
    let items = v
        .get("notecards")
        .and_then(|x| x.as_array())
        .or_else(|| v.get("data").and_then(|x| x.as_array()))
        .or_else(|| v.as_array());
    let Some(items) = items else {
        return;
    };
    for card in items {
        if out.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
        let title = card
            .get("name")
            .or_else(|| card.get("title"))
            .or_else(|| card.get("notecard_name"))
            .and_then(|x| x.as_str())
            .unwrap_or("note");
        let path = match notebook {
            Some(nb) => format!("{nb}/{title}"),
            None => title.to_string(),
        };
        let size = card
            .get("size")
            .or_else(|| card.get("content_length"))
            .and_then(parse_u64_json)
            .unwrap_or(0);
        let extra = notecard_keyword_snippet(card);
        out.push(
            CloudFileMeta::new(title, size, path).with_keyword_extra(extra),
        );
    }
}

/// Plain-text fields from list API used for keyword filter (not shown in «Содержимое»).
fn notecard_keyword_snippet(card: &Value) -> String {
    for key in [
        "description",
        "content",
        "note_content",
        "plain_text",
        "snippet",
        "text",
        "summary",
    ] {
        if let Some(s) = card.get(key).and_then(|x| x.as_str()) {
            let t = s.trim();
            if !t.is_empty() {
                return t.chars().take(2048).collect();
            }
        }
    }
    String::new()
}

fn parse_u64_json(v: &Value) -> Option<u64> {
    v.as_u64()
        .or_else(|| v.as_i64().map(|n| n.max(0) as u64))
        .or_else(|| v.as_str().and_then(|s| s.parse().ok()))
}

fn extract_access_token(body: &str) -> Option<String> {
    if let Ok(v) = serde_json::from_str::<Value>(body) {
        for key in ["access_token", "token", "oauth_token"] {
            if let Some(t) = v.get(key).and_then(|x| x.as_str()) {
                if !t.is_empty() {
                    return Some(t.to_string());
                }
            }
        }
    }
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        Regex::new(r#"(?i)"access_token"\s*:\s*"([^"]+)""#).expect("access_token re")
    });
    re.captures(body)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn parse_hidden_iamcsr(html: &str) -> Option<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| Regex::new(r#"name="iamcsr"\s+value="([^"]+)""#).expect("iamcsr re"));
    re.captures(html)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cloud::config::CloudClientConfig;
    use anyhow::anyhow;
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use std::time::Duration;
    use url::Url;

    #[test]
    fn zoho_signin_page_serviceurl_matches_lookup_body() {
        let dc = ZohoDc::by_index(0);
        let page = dc.signin_page();
        let q = zoho_signin_query(&dc, "1234567890");
        let serviceurl = zoho_pct(&format!("{}/", dc.notebook_origin));
        assert!(
            page.contains(&format!("serviceurl={serviceurl}")),
            "page: {page}"
        );
        assert!(
            !page.ends_with(&format!("{serviceurl}/")),
            "extra slash after encoded serviceurl: {page}"
        );
        assert!(
            q.contains(&format!("serviceurl={serviceurl}")),
            "query: {q}"
        );
    }

    #[test]
    fn zoho_si302_is_signin_progress_not_hard_fail() {
        let body = r#"{"code":"SI302","redirect_uri":"https://notebook.zoho.com/"}"#;
        assert!(zoho_password_step_accepted(
            &CloudCurlSession::new().expect("curl"),
            body
        ));
    }

    #[test]
    fn zoho_determine_by_email_eu_hint() {
        assert!(ZohoDc::determine_by_email("user@company.eu").accounts_host.contains(".eu"));
        assert!(ZohoDc::determine_by_email("user@firma.de").accounts_host.contains(".eu"));
        assert!(ZohoDc::determine_by_email("user@mail.co.uk").accounts_host.contains(".eu"));
        assert!(ZohoDc::determine_by_email("user@entreprise.fr").accounts_host.contains(".eu"));
        assert!(
            ZohoDc::determine_by_email("user@gmail.com")
                .accounts_host
                .contains(".com")
        );
        assert!(
            ZohoDc::determine_by_email("user@example.org")
                .accounts_host
                .contains(".com")
        );
    }

    #[test]
    fn zoho_dc_attempt_order_single_predicted() {
        let order = zoho_dc_attempt_order("fresh@gmail.com");
        assert_eq!(order.len(), 1);
        assert!(order[0].accounts_host.contains(".com"));
    }

    #[test]
    fn zoho_dc_attempt_order_prefers_cache() {
        let email = "cache-test@example.com";
        zoho_remember_dc(email, ZohoDc::by_index(1));
        let order = zoho_dc_attempt_order(email);
        assert_eq!(order.len(), 1);
        assert!(order[0].accounts_host.contains(".eu"));
    }

    #[test]
    fn zoho_try_next_dc_wrong_datacenter() {
        let err = zoho_tag(
            ZohoFlowKind::WrongDatacenter,
            anyhow!("zoho lookup: regional datacenter (redirect accounts.zoho.eu)"),
        );
        assert!(zoho_try_next_dc(&err));
    }

    #[test]
    fn zoho_try_next_dc_invalid_password() {
        let err = cloud_auth_error("zoho: invalid email or password");
        assert!(!zoho_try_next_dc(&err));
    }

    #[test]
    fn notecard_keyword_snippet_from_content() {
        let card = serde_json::json!({
            "name": "Shopping",
            "content": "My SECRET wallet phrase here"
        });
        let snip = notecard_keyword_snippet(&card);
        assert!(snip.contains("SECRET"));
    }

    #[test]
    fn zoho_skip_legacy_after_cloud_auth() {
        let e = cloud_auth_error("zoho: invalid email or password");
        assert!(
            zoho_skip_legacy_after_v2(&e),
            "legacy /signin/auth must not run after v2 cloud auth"
        );
    }

    #[test]
    fn zoho_iam_error_envelope_not_passwordauth() {
        let v = serde_json::json!({
            "status_code": 400,
            "message": "Invalid Request",
            "errors": [{ "code": "INVALID_REQUEST", "message": "bad csrf" }]
        });
        assert!(zoho_is_iam_error_envelope(&v));
        let err = zoho_json_auth_errors(&v).unwrap_err();
        let text = format!("{err:#}");
        assert!(text.contains("cloud network"), "{text}");
    }

    #[test]
    fn zoho_pick_auth_flat_lookup_object() {
        let v = serde_json::json!({
            "code": "SUCCESS",
            "lookup": {
                "identifier": "20079980031",
                "digest": "abc123",
                "modes": { "allowed_modes": ["password", "email"] }
            }
        });
        let (mode, block) = zoho_pick_auth_block(&v).expect("password lookup");
        assert_eq!(mode, "passwordauth");
        assert_eq!(block.get("identifier").and_then(|x| x.as_str()), Some("20079980031"));
    }

    #[test]
    fn zoho_account_not_registered_tag() {
        let v = serde_json::json!({
            "status_code": 404,
            "message": "Account does not exist"
        });
        let err = zoho_json_auth_errors(&v).unwrap_err();
        let text = format!("{err:#}");
        assert!(text.contains("cloud auth"), "{text}");
    }

    /// `ZOHO_TEST_COMBO=email:pass` or `ZOHO_TEST_EMAIL` + `ZOHO_TEST_PASSWORD`
    /// `cargo test -p pma-net zoho_local_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "local smoke: set ZOHO_TEST_COMBO or ZOHO_TEST_EMAIL/ZOHO_TEST_PASSWORD"]
    async fn zoho_local_smoke() {
        let (user, pass) = if let Ok(combo) = std::env::var("ZOHO_TEST_COMBO") {
            let line = combo.trim();
            let (u, p) = line.split_once(':').expect("email:password");
            (u.to_string(), p.to_string())
        } else {
            (
                std::env::var("ZOHO_TEST_EMAIL").expect("ZOHO_TEST_EMAIL"),
                std::env::var("ZOHO_TEST_PASSWORD").expect("ZOHO_TEST_PASSWORD"),
            )
        };
        let cred = Credential {
            url: Url::parse("https://accounts.zoho.com/").expect("url"),
            username: user,
            password: pass,
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::ZohoNotes,
            Duration::from_secs(90),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("config");
        let client = cfg.http.clone();
        match zoho_inventory(&cfg, client, cred).await {
            Ok(inv) => {
                eprintln!(
                    "Zoho OK: files={} tariff={}",
                    inv.file_count, inv.tariff
                );
            }
            Err(e) => {
                eprintln!("Zoho FAIL: {e:#}");
                panic!("zoho smoke failed");
            }
        }
    }
}
