﻿//! Degoo — REST login + AppSync GraphQL inventory (`GetFileChildren5`).

use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::{json, Value};
use std::collections::{HashSet, VecDeque};
use std::path::{Path, PathBuf};

const DEGOO_LOGIN: &str = "https://rest-api.degoo.com/login";
const DEGOO_TOKEN: &str = "https://rest-api.degoo.com/access-token/v2";
const DEGOO_GRAPHQL: &str = "https://production-appsync.degoo.com/graphql";
const DEGOO_API_KEY: &str = "da2-vs6twz5vnjdavpqndtbzg3prra";
const LIST_LIMIT: i64 = 1000;
const FEED_LIMIT: i64 = 1000;
const SEARCH_LIMIT: i64 = 500;

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        degoo_inventory(cfg, client, cred)
    })
    .await
}

async fn degoo_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let token = degoo_login(cfg, &mut curl, &email, &password).await?;

    let user = degoo_user_info(cfg, &mut curl, &token).await.unwrap_or_default();
    let used = user.used_quota;
    let total = user.total_quota;
    let tariff = user.plan;

    let mut files = degoo_walk_tree(cfg, &mut curl, &token).await?;
    if files.is_empty() {
        // When API reports used space but the tree is empty, search usually finds files feed misses.
        if used > 0 {
            degoo_collect_search(cfg, &mut curl, &token, &mut files).await?;
            if files.is_empty() {
                degoo_collect_feed(cfg, &mut curl, &token, &mut files).await?;
            }
        } else {
            degoo_collect_feed(cfg, &mut curl, &token, &mut files).await?;
            if files.is_empty() {
                degoo_collect_search(cfg, &mut curl, &token, &mut files).await?;
            }
        }
    }

    let used_bytes = if used > 0 {
        used
    } else {
        files.iter().map(|f| f.size).sum()
    };

    let mut inv = inventory_from_account(&email, files, used_bytes, total, &tariff);
    if inv.file_count == 0 && used_bytes > 1_048_576 {
        inv.list_note = Some(
            "# Degoo: login OK, UsedQuota > 0, но список файлов пуст (getFileChildren5/search)\n"
                .to_string(),
        );
    }
    Ok(inv)
}

struct DegooUserInfo {
    used_quota: u64,
    total_quota: u64,
    plan: String,
}

impl Default for DegooUserInfo {
    fn default() -> Self {
        Self {
            used_quota: 0,
            total_quota: 0,
            plan: "Degoo".to_string(),
        }
    }
}

struct DegooItem {
    id: i64,
    name: String,
    size: u64,
    path: String,
    category: i64,
    is_recycle: bool,
    is_folder: bool,
}

fn degoo_rest_headers() -> Vec<(String, String)> {
    vec![
        ("Accept".to_string(), "*/*".to_string()),
        (
            "Accept-Language".to_string(),
            "en-US,en;q=0.9".to_string(),
        ),
        ("Content-Type".to_string(), "application/json".to_string()),
        ("Origin".to_string(), "https://app.degoo.com".to_string()),
        ("Referer".to_string(), "https://app.degoo.com/".to_string()),
        (
            "x-amz-content".to_string(),
            "https://app.degoo.com".to_string(),
        ),
        (
            "x-api-authentication".to_string(),
            "iNDNjhDZzYWMxQTNtM2Y0IWLxIjY00COzcDNtYGN2Y2Y1gzM".to_string(),
        ),
        (
            "x-version".to_string(),
            "DegooWebClient/1.0:2022.11.11".to_string(),
        ),
    ]
}

fn header_refs(headers: &[(String, String)]) -> Vec<(&str, &str)> {
    headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect()
}

async fn degoo_login(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<String> {
    let headers = degoo_rest_headers();
    let refs = header_refs(&headers);
    let body = json!({
        "GenerateToken": true,
        "Username": email,
        "Password": password,
    });
    let (status, login_json) = curl
        .post_json(cfg, "degoo login", DEGOO_LOGIN, &body, &refs)
        .await
        .context("degoo login")?;
    if status == 401 || status == 403 {
        return Err(cloud_auth_error(format!("degoo login http {status}")));
    }
    if status == 429 {
        return Err(cloud_rate_limit_error(format!("degoo login http {status}")));
    }
    if status >= 400 {
        return Err(cloud_auth_error(format!(
            "degoo login http {status}: {}",
            preview_json(&login_json)
        )));
    }

    if let Some(refresh) = login_json
        .get("RefreshToken")
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
    {
        return degoo_exchange_access_token(cfg, curl, refresh, &refs).await;
    }

    login_json
        .get("Token")
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .ok_or_else(|| cloud_auth_error("degoo login: missing Token/RefreshToken"))
}

async fn degoo_exchange_access_token(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    refresh: &str,
    refs: &[(&str, &str)],
) -> Result<String> {
    let token_body = json!({ "RefreshToken": refresh });
    let (t_status, token_json) = curl
        .post_json(cfg, "degoo access-token", DEGOO_TOKEN, &token_body, refs)
        .await
        .context("degoo token")?;
    if t_status == 401 || t_status == 403 {
        return Err(cloud_auth_error("degoo: invalid credentials"));
    }
    if t_status >= 400 {
        return Err(cloud_auth_error(format!(
            "degoo token http {t_status}: {}",
            preview_json(&token_json)
        )));
    }
    token_json
        .get("AccessToken")
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .ok_or_else(|| cloud_auth_error("degoo: missing AccessToken"))
}

async fn degoo_user_info(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
) -> Result<DegooUserInfo> {
    let query = "query GetUserInfo($Token: String!) { getUserInfo(Token: $Token) { Name Email AccountType UsedQuota TotalQuota __typename } }";
    let body = json!({
        "operationName": "GetUserInfo",
        "variables": { "Token": token },
        "query": query,
    });
    let v = degoo_graphql(cfg, curl, token, "degoo user", &body).await?;
    let node = v
        .get("data")
        .and_then(|d| d.get("getUserInfo"))
        .context("degoo getUserInfo")?;
    let plan_code = node.get("AccountType").and_then(|x| x.as_i64()).unwrap_or(0);
    let total_raw = parse_u64(node.get("TotalQuota"));
    Ok(DegooUserInfo {
        used_quota: parse_u64(node.get("UsedQuota")),
        total_quota: degoo_effective_total_quota(total_raw),
        plan: degoo_plan_label(plan_code, total_raw),
    })
}

async fn degoo_walk_tree(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
) -> Result<Vec<CloudFileMeta>> {
    let mut files = Vec::new();
    let mut seen_dirs: HashSet<i64> = HashSet::new();
    let mut queue: VecDeque<(i64, Vec<String>)> = VecDeque::new();
    queue.push_back((0, Vec::new()));
    while let Some((dir_id, ancestors)) = queue.pop_front() {
        if !seen_dirs.insert(dir_id) {
            continue;
        }
        let mut next_token: Option<String> = None;
        loop {
            let (items, pagination) = degoo_list_children(
                cfg,
                curl,
                token,
                dir_id,
                ancestors.as_slice(),
                next_token.as_deref(),
            )
            .await?;
            for item in items {
                if item.is_recycle {
                    continue;
                }
                if item.is_folder {
                    if files.len() < MAX_CLOUD_LIST_LINES && seen_dirs.len() < 50_000 {
                        let mut chain = ancestors.clone();
                        chain.push(dir_id.to_string());
                        queue.push_back((item.id, chain));
                    }
                    continue;
                }
                files.push(
                    CloudFileMeta::new(item.name.clone(), item.size, item.path)
                        .with_remote_id(item.id.to_string()),
                );
                if files.len() >= MAX_CLOUD_LIST_LINES {
                    return Ok(files);
                }
            }
            match pagination {
                Some(t) if !t.is_empty() => next_token = Some(t),
                _ => break,
            }
        }
    }
    Ok(files)
}

async fn degoo_collect_feed(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
    files: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let query = "query GetFeed($Token: String!, $Limit: Int!, $Random: Float) { getFeed(Token: $Token, Limit: $Limit, Random: $Random) { ID Name Size Category FilePath IsInRecycleBin __typename } }";
    let body = json!({
        "operationName": "GetFeed",
        "variables": {
            "Token": token,
            "Limit": FEED_LIMIT,
            "Random": 0.42_f64,
        },
        "query": query,
    });
    let v = degoo_graphql(cfg, curl, token, "degoo feed", &body).await?;
    let items = v
        .get("data")
        .and_then(|d| d.get("getFeed"))
        .and_then(|x| x.as_array())
        .cloned()
        .unwrap_or_default();
    push_degoo_file_items(items, 0, files);
    Ok(())
}

async fn degoo_collect_search(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
    files: &mut Vec<CloudFileMeta>,
) -> Result<()> {
    let query = "query GetSearchContent3($Token: String!, $SearchTerm: String!, $Limit: Int!, $NextToken: String) { getSearchContent3(Token: $Token, SearchTerm: $SearchTerm, Limit: $Limit, NextToken: $NextToken) { Items { ID Name Size Category FilePath IsInRecycleBin __typename } NextToken __typename } }";
    let mut seen_ids: HashSet<String> = files
        .iter()
        .filter_map(|f| f.remote_id.clone())
        .collect();
    for term in [".", "a", "e", "1", "jpg", "pdf", "mp4", "zip"] {
        let mut next_token: Option<String> = None;
        loop {
            let mut variables = json!({
                "Token": token,
                "SearchTerm": term,
                "Limit": SEARCH_LIMIT,
            });
            if let Some(t) = &next_token {
                variables["NextToken"] = json!(t);
            }
            let body = json!({
                "operationName": "GetSearchContent3",
                "variables": variables,
                "query": query,
            });
            let v = degoo_graphql(cfg, curl, token, "degoo search", &body).await?;
            let block = match v.get("data").and_then(|d| d.get("getSearchContent3")) {
                Some(b) => b,
                None => break,
            };
            if let Some(items) = block.get("Items").and_then(|x| x.as_array()) {
                for item in items {
                    if let Some(parsed) = parse_degoo_item(item, 0) {
                        if parsed.is_recycle || parsed.is_folder {
                            continue;
                        }
                        let id = parsed.id.to_string();
                        if !seen_ids.insert(id.clone()) {
                            continue;
                        }
                        files.push(
                            CloudFileMeta::new(parsed.name, parsed.size, parsed.path)
                                .with_remote_id(id),
                        );
                        if files.len() >= MAX_CLOUD_LIST_LINES {
                            return Ok(());
                        }
                    }
                }
            }
            next_token = block
                .get("NextToken")
                .and_then(|x| x.as_str())
                .filter(|s| !s.is_empty())
                .map(|s| s.to_string());
            if next_token.is_none() {
                break;
            }
        }
        if files.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
    }
    Ok(())
}

fn push_degoo_file_items(items: Vec<Value>, parent_id: i64, files: &mut Vec<CloudFileMeta>) {
    for item in items {
        if let Some(parsed) = parse_degoo_item(&item, parent_id) {
            if parsed.is_recycle || parsed.is_folder {
                continue;
            }
            files.push(
                CloudFileMeta::new(parsed.name, parsed.size, parsed.path)
                    .with_remote_id(parsed.id.to_string()),
            );
            if files.len() >= MAX_CLOUD_LIST_LINES {
                return;
            }
        }
    }
}

async fn degoo_list_children(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    token: &str,
    parent_id: i64,
    all_parent_ids: &[String],
    next_token: Option<&str>,
) -> Result<(Vec<DegooItem>, Option<String>)> {
    let query = "query GetFileChildren5($Token: String!, $ParentID: String, $AllParentIDs: [String], $Limit: Int!, $Order: Int!, $NextToken: String) { getFileChildren5(Token: $Token, ParentID: $ParentID, AllParentIDs: $AllParentIDs, Limit: $Limit, Order: $Order, NextToken: $NextToken) { Items { ID Name Size Category FilePath IsInRecycleBin __typename } NextToken __typename } }";
    let mut variables = json!({
        "Token": token,
        "ParentID": parent_id.to_string(),
        "Limit": LIST_LIMIT,
        "Order": 3,
    });
    if !all_parent_ids.is_empty() {
        variables["AllParentIDs"] = json!(all_parent_ids);
    }
    if let Some(t) = next_token {
        variables["NextToken"] = json!(t);
    }
    let body = json!({
        "operationName": "GetFileChildren5",
        "variables": variables,
        "query": query,
    });
    let v = degoo_graphql(cfg, curl, token, "degoo list", &body).await?;
    let block = v
        .get("data")
        .and_then(|d| d.get("getFileChildren5"))
        .context("degoo getFileChildren5")?;
    let pagination = block
        .get("NextToken")
        .and_then(|x| x.as_str())
        .map(|s| s.to_string());
    let mut out = Vec::new();
    if let Some(items) = block.get("Items").and_then(|x| x.as_array()) {
        for item in items {
            if let Some(parsed) = parse_degoo_item(item, parent_id) {
                out.push(parsed);
            }
        }
    }
    Ok((out, pagination))
}

async fn degoo_graphql(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    _token: &str,
    ctx: &str,
    body: &Value,
) -> Result<Value> {
    let mut headers = degoo_rest_headers();
    headers.push(("x-api-key".to_string(), DEGOO_API_KEY.to_string()));
    let refs = header_refs(&headers);
    let (status, v) = curl
        .post_json(cfg, ctx, DEGOO_GRAPHQL, body, &refs)
        .await
        .with_context(|| format!("{ctx} graphql"))?;
    if status == 429 {
        return Err(cloud_rate_limit_error(format!("{ctx} http {status}")));
    }
    if status >= 400 {
        return Err(anyhow!("{ctx} http {status}: {}", preview_json(&v)));
    }
    if let Some(errors) = v.get("errors").and_then(|x| x.as_array()) {
        if !errors.is_empty() {
            let msg = errors
                .iter()
                .filter_map(|e| e.get("message").and_then(|m| m.as_str()))
                .collect::<Vec<_>>()
                .join("; ");
            if msg.contains("Unauthorized") || msg.contains("Not Authorized") {
                return Err(cloud_auth_error(format!("degoo graphql: {msg}")));
            }
            return Err(anyhow!("degoo graphql: {msg}"));
        }
    }
    Ok(v)
}

fn parse_degoo_item(v: &Value, parent_id: i64) -> Option<DegooItem> {
    let id = v
        .get("ID")
        .and_then(|x| x.as_i64().or_else(|| x.as_str()?.parse().ok()))?;
    let name = v.get("Name").and_then(|x| x.as_str())?.to_string();
    let category = v
        .get("Category")
        .and_then(|x| x.as_i64().or_else(|| x.as_str()?.parse().ok()))
        .unwrap_or(0);
    let is_recycle = v
        .get("IsInRecycleBin")
        .and_then(|x| x.as_bool())
        .unwrap_or(false)
        || category == 10;
    let is_folder = matches!(category, 1 | 2) && !is_recycle;
    let size = parse_u64(v.get("Size"));
    let path = v
        .get("FilePath")
        .and_then(|x| x.as_str())
        .map(|p| {
            if p.starts_with('/') {
                p.to_string()
            } else if parent_id == 0 {
                format!("/{name}")
            } else {
                format!("/{name}")
            }
        })
        .unwrap_or_else(|| format!("/{name}"));
    Some(DegooItem {
        id,
        name,
        size,
        path,
        category,
        is_recycle,
        is_folder,
    })
}

const DEGOO_GB: u64 = 1024 * 1024 * 1024;
/// GraphQL `TotalQuota` is often `2147483648` (2 GiB) even on free plans — not usable storage.
const DEGOO_FREE_QUOTA_SENTINEL_MAX: u64 = 4 * DEGOO_GB;
const DEGOO_FREE_STORAGE_BYTES: u64 = 100 * DEGOO_GB;
const DEGOO_PRO_MIN_BYTES: u64 = 400 * DEGOO_GB;
const DEGOO_ULTIMATE_MIN_BYTES: u64 = 5 * 1024 * DEGOO_GB;

fn degoo_effective_total_quota(raw: u64) -> u64 {
    if raw == 0 || raw <= DEGOO_FREE_QUOTA_SENTINEL_MAX {
        DEGOO_FREE_STORAGE_BYTES
    } else {
        raw
    }
}

/// Tariff from `TotalQuota` thresholds; `AccountType` alone is unreliable (free accounts often return `1`).
fn degoo_plan_label(account_type: i64, total_quota_raw: u64) -> String {
    let total = degoo_effective_total_quota(total_quota_raw);
    if total >= DEGOO_ULTIMATE_MIN_BYTES {
        return "Ultimate 10 TB".to_string();
    }
    if total >= DEGOO_PRO_MIN_BYTES {
        return "Pro 500 GB".to_string();
    }
    let _ = account_type;
    "Free 100 GB".to_string()
}

fn parse_u64(v: Option<&Value>) -> u64 {
    v.and_then(|x| {
        x.as_u64()
            .or_else(|| x.as_i64().map(|n| n.max(0) as u64))
            .or_else(|| x.as_str().and_then(|s| s.parse().ok()))
    })
    .unwrap_or(0)
}

fn preview_json(v: &Value) -> String {
    let s = v.to_string();
    if s.len() > 200 {
        format!("{}…", &s[..200])
    } else {
        s
    }
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;
    use crate::cloud::config::CloudClientConfig;

    #[test]
    fn degoo_free_account_with_account_type_1_is_not_pro() {
        assert_eq!(
            degoo_plan_label(1, 2_147_483_648),
            "Free 100 GB"
        );
        assert_eq!(
            degoo_effective_total_quota(2_147_483_648),
            100 * DEGOO_GB
        );
    }

    #[test]
    fn degoo_pro_from_quota_not_account_type() {
        assert_eq!(
            degoo_plan_label(0, 500 * DEGOO_GB),
            "Pro 500 GB"
        );
    }
    use pma_core::{CloudDownloadFilter, CloudProvider, Credential};
    use std::time::Duration;
    use url::Url;

    /// `DEGOO_TEST_COMBO=C:\path\combo.txt cargo test -p pma-net degoo_local_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "local smoke: set DEGOO_TEST_COMBO"]
    async fn degoo_local_smoke() {
        let path = std::env::var("DEGOO_TEST_COMBO").expect("DEGOO_TEST_COMBO");
        let line = std::fs::read_to_string(&path)
            .expect("read combo")
            .lines()
            .find(|l| !l.trim().is_empty() && !l.trim_start().starts_with('#'))
            .expect("combo line")
            .trim()
            .to_string();
        let (user, pass) = line.split_once(':').expect("email:password");
        let cred = Credential {
            url: Url::parse("https://app.degoo.com/").expect("url"),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::Degoo,
            Duration::from_secs(90),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("cloud cfg");
        let out = std::env::temp_dir().join("degoo-smoke-out");
        let (_stats, written) = check_account(&cfg, &cred, &out, None)
            .await
            .expect("check_account");
        assert!(!written.is_empty(), "expected Содержимое inventory");
    }
}
