﻿//! ADrive — WebDAV listing at https://www.adrive.com/webDAV.php/ (Signature/Premium plans).
//! Requires paid tier for WebDAV; Basic free accounts may fail auth.

use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, parse_webdav_file_names, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use std::path::{Path, PathBuf};

const WEBDAV_ROOT: &str = "https://www.adrive.com/webDAV.php/";

const PROPFIND_BODY: &str = r#"<?xml version="1.0" encoding="utf-8"?>
<D:propfind xmlns:D="DAV:">
  <D:prop><D:displayname/><D:getcontentlength/></D:prop>
</D:propfind>"#;

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        adrive_inventory(cfg, client, cred)
    })
    .await
}

async fn adrive_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let (status, text) = curl
        .webdav_propfind_basic(
            cfg,
            "adrive webdav",
            WEBDAV_ROOT,
            &email,
            &password,
            "infinity",
            PROPFIND_BODY,
            &[],
        )
        .await
        .context("adrive webdav propfind")?;

    if status == 401 || status == 403 {
        return Err(cloud_auth_error(format!(
            "adrive webdav http {status} (WebDAV needs Signature/Premium plan?)"
        )));
    }
    if status >= 400 {
        return Err(anyhow!("adrive webdav http {status}"));
    }

    let mut files = parse_webdav_file_names(&text);
    files.sort_unstable();
    files.dedup();
    if files.len() > MAX_CLOUD_LIST_LINES {
        files.truncate(MAX_CLOUD_LIST_LINES);
    }
    let metas: Vec<CloudFileMeta> = files
        .into_iter()
        .map(|n| CloudFileMeta::new(n.clone(), 0, n))
        .collect();
    let used = 0u64;
    Ok(inventory_from_account(&email, metas, used, 0, "ADrive"))
}
