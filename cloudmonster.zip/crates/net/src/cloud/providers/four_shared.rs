﻿use crate::cloud::common::{
    cloud_auth_error, inventory_from_account, parse_embedded_json_string,
    parse_embedded_json_u64, parse_webdav_file_names, run_checker, CloudFileMeta, CloudInventory,
    MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{header_pairs, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::collections::{HashSet, VecDeque};
use std::path::{Path, PathBuf};

const RETURN_TO: &str = "https://www.4shared.com/account/home.jsp";
const LOGIN_URL: &str = "https://www.4shared.com/web/login";
const FILES_URL: &str = "https://www.4shared.com/web/account/files";
const HOME_URL: &str = "https://www.4shared.com/account/home.jsp";
const TREE_URL: &str = "https://www.4shared.com/web/account/getTree";
const FILE_LIST_URL: &str = "https://www.4shared.com/web/account/fileList";
const DIR_CONTENT_URL: &str = "https://www.4shared.com/account/getDirContent";
const WEBDAV_ROOT: &str = "https://webdav.4shared.com/";
const FOUR_SHARED_WWW: &str = "https://www.4shared.com";

/// Базовые URL API; после geo-заглушки переключаемся на `https://dc{id}.4shared.com`.
struct FourSharedEndpoints {
    base: String,
}

impl FourSharedEndpoints {
    fn www() -> Self {
        Self {
            base: FOUR_SHARED_WWW.to_string(),
        }
    }

    fn dc(dc_id: u64) -> Self {
        Self {
            base: format!("https://dc{dc_id}.4shared.com"),
        }
    }

    fn path(&self, suffix: &str) -> String {
        format!("{}{}", self.base.trim_end_matches('/'), suffix)
    }

    fn home(&self) -> String {
        self.path("/account/home.jsp")
    }

    fn files_page(&self) -> String {
        self.path("/web/account/files")
    }

    fn tree(&self) -> String {
        self.path("/web/account/getTree")
    }

    fn file_list(&self) -> String {
        self.path("/web/account/fileList")
    }

    fn dir_content(&self) -> String {
        self.path("/account/getDirContent")
    }
}

fn four_shared_parse_geo_dc(body: &str) -> Option<u64> {
    if !four_shared_is_geo_stub_json(body) {
        return None;
    }
    let v: Value = serde_json::from_str(body.trim()).ok()?;
    v.get("dc.id").and_then(|x| {
        x.as_u64()
            .or_else(|| x.as_i64().filter(|n| *n >= 0).map(|n| n as u64))
            .or_else(|| x.as_str()?.parse().ok())
    })
}

fn four_shared_seed_dc_cookies(curl: &mut CloudCurlSession, dc_id: u64) {
    let id = dc_id.to_string();
    for name in ["UserDC", "userDC", "dcId", "dc.id", "selectedDC"] {
        curl.seed_cookie(name, &id);
    }
}

async fn four_shared_ajax_get_body(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ctx: &str,
    url: &str,
    referer: &str,
    pages: Option<&str>,
    origin_base: &str,
) -> Option<String> {
    let headers = four_shared_ajax_headers(cfg, curl, referer, pages, origin_base);
    let refs: Vec<(&str, &str)> = headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    curl.get_text(cfg, ctx, url, &refs, true)
        .await
        .ok()
        .map(|(_st, body)| body)
}

async fn four_shared_api_usable_at_url(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ctx: &str,
    url: &str,
    referer: &str,
    pages: &str,
    origin_base: &str,
) -> bool {
    let Some(body) =
        four_shared_ajax_get_body(cfg, curl, ctx, url, referer, Some(pages), origin_base).await
    else {
        return false;
    };
    four_shared_api_json_from_body(&body).is_some_and(|v| four_shared_api_usable(&v))
}

async fn four_shared_login_on_host(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ep: &FourSharedEndpoints,
    email: &str,
    password: &str,
) -> Result<()> {
    let login_url = ep.path("/web/login");
    let return_to = ep.home();
    let warm = header_pairs(cfg, &[("Referer", login_url.as_str())]);
    let warm_r: Vec<(&str, &str)> = warm
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    curl.get_text(cfg, "4shared host login page", &login_url, &warm_r, true)
        .await
        .context("4shared host login page")?;
    let login_headers = header_pairs(
        cfg,
        &[
            ("Referer", login_url.as_str()),
            ("Origin", ep.base.as_str()),
        ],
    );
    let login_r: Vec<(&str, &str)> = login_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    curl.post_form(
        cfg,
        "4shared host login",
        &login_url,
        &[
            ("returnTo", return_to.as_str()),
            ("ausk", ""),
            ("inviteId", ""),
            ("inviterName", ""),
            ("email", email),
            ("login", email),
            ("password", password),
            ("remember", "true"),
            ("_remember", "on"),
        ],
        &login_r,
        true,
    )
    .await
    .context("4shared host login")?;
    Ok(())
}

/// www отдаёт `{"country","dc.id"}` — прогреваем хост аккаунта и повторяем getTree/fileList там.
async fn four_shared_bind_datacenter(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    pages: &str,
    email: &str,
    password: &str,
) -> FourSharedEndpoints {
    let www = FourSharedEndpoints::www();
    let referer = www.files_page();

    if four_shared_api_usable_at_url(cfg, curl, "4shared getTree", &www.tree(), &referer, pages, &www.base)
        .await
    {
        return www;
    }

    let mut dc_ids: Vec<u64> = Vec::new();
    for url in [
        www.tree(),
        format!("{}?dirId=-1&limit=1&offset=0", www.file_list()),
    ] {
        if let Some(body) = four_shared_ajax_get_body(
            cfg,
            curl,
            "4shared geo probe",
            &url,
            &referer,
            Some(pages),
            &www.base,
        )
        .await
        {
            if let Some(id) = four_shared_parse_geo_dc(&body) {
                dc_ids.push(id);
            }
        }
    }
    dc_ids.sort_unstable();
    dc_ids.dedup();

    if dc_ids.is_empty() {
        return www;
    }

    let warm = header_pairs(cfg, &[("Referer", LOGIN_URL)]);
    let warm_r: Vec<(&str, &str)> = warm
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();

    for dc_id in &dc_ids {
        four_shared_seed_dc_cookies(curl, *dc_id);
        let ep = FourSharedEndpoints::dc(*dc_id);
        let _ = curl
            .get_text(cfg, "4shared dc home", &ep.home(), &warm_r, true)
            .await;
        let _ = curl
            .get_text(cfg, "4shared dc files", &ep.files_page(), &warm_r, true)
            .await;
        let _ = four_shared_login_on_host(cfg, curl, &ep, email, password).await;
        let _ = curl
            .get_text(cfg, "4shared dc home relogin", &ep.home(), &warm_r, true)
            .await;

        if four_shared_api_usable_at_url(
            cfg,
            curl,
            "4shared dc getTree",
            &ep.tree(),
            &ep.files_page(),
            pages,
            &ep.base,
        )
        .await
        {
            return ep;
        }
        let fl_probe = format!("{}?dirId=-1&limit=1&offset=0", ep.file_list());
        if four_shared_api_usable_at_url(
            cfg,
            curl,
            "4shared dc fileList",
            &fl_probe,
            &ep.files_page(),
            pages,
            &ep.base,
        )
        .await
        {
            return ep;
        }
    }

    FourSharedEndpoints::dc(*dc_ids.first().unwrap_or(&517))
}

/// `Login=<userId>`, `Password=<md5>`, `ulin=true`, `JSESSIONID` / `WWW_JSESSIONID`.
fn four_shared_session_logged_in(curl: &CloudCurlSession) -> bool {
    let login_id = curl.cookie_value("Login").unwrap_or("");
    let has_login = !login_id.is_empty() && login_id.chars().all(|c| c.is_ascii_digit());
    let ulin = curl
        .cookie_value("ulin")
        .is_some_and(|v| v.eq_ignore_ascii_case("true"));
    let has_session = curl.cookie_value("JSESSIONID").is_some()
        || curl.cookie_value("WWW_JSESSIONID").is_some();
    let remember = curl
        .cookie_value("Password")
        .is_some_and(|v| !v.is_empty());
    if has_login && (ulin || remember) {
        return true;
    }
    if has_login && has_session {
        return true;
    }
    ulin && has_session
}

/// Cookies иногда не приходят из curl — тогда смотрим HTML аккаунта (как раньше).
fn four_shared_logged_in(curl: &CloudCurlSession, pages: &str) -> bool {
    if four_shared_session_logged_in(curl) {
        return true;
    }
    let lower = pages.to_lowercase();
    four_shared_body_looks_like_account(&lower) && !four_shared_html_auth_failure(pages)
}

/// Не считаем аккаунт готовым к инвентаризации только по слову «logout» в HTML.
fn four_shared_inventory_ready(curl: &CloudCurlSession, pages: &str) -> bool {
    if four_shared_session_logged_in(curl) {
        return true;
    }
    let lower = pages.to_lowercase();
    lower.contains("4shared file manager")
        && four_shared_body_looks_like_account(&lower)
        && !four_shared_html_auth_failure(pages)
}

fn four_shared_login_form_still_visible(body: &str) -> bool {
    let lower = body.to_lowercase();
    lower.contains("name=\"password\"")
        && (lower.contains("name=\"login\"")
            || lower.contains("id=\"login\"")
            || lower.contains("type=\"password\""))
        && !four_shared_body_looks_like_account(&lower)
}

fn four_shared_body_looks_like_account(lower: &str) -> bool {
    lower.contains("account/home")
        || lower.contains("web/account/files")
        || lower.contains("my account")
        || lower.contains("logout")
        || lower.contains("sign out")
        || lower.contains("data-filename=")
}

fn four_shared_html_auth_failure(body: &str) -> bool {
    let lower = body.to_lowercase();
    if lower.contains("wrong password")
        || lower.contains("invalid login")
        || lower.contains("incorrect password")
        || lower.contains("invalid password")
        || lower.contains("login or password is incorrect")
    {
        return true;
    }
    if four_shared_body_looks_like_account(&lower) {
        return false;
    }
    four_shared_login_form_still_visible(body)
}

const FOUR_SHARED_FREE_BYTES: u64 = 15 * 1024 * 1024 * 1024;

fn four_shared_tariff(pages: &str, total: u64) -> &'static str {
    if let Some(plan) = parse_embedded_json_string(pages, "plan") {
        match plan.to_ascii_lowercase().as_str() {
            "premium" | "pro" => return "Premium",
            "free" => return "Free",
            _ => {}
        }
    }
    // Не ищем слово "premium" в HTML — там всегда есть upsell «Get Premium».
    if total > 16 * 1024 * 1024 * 1024 {
        return "Premium";
    }
    "Free"
}

fn four_shared_stats(pages: &str) -> (u64, u64, &'static str) {
    let total = parse_embedded_json_u64(pages, "totalSpace").unwrap_or(FOUR_SHARED_FREE_BYTES);
    let used_explicit = parse_embedded_json_u64(pages, "usedSpace")
        .or_else(|| parse_embedded_json_u64(pages, "used"))
        .or_else(|| parse_embedded_json_u64(pages, "spaceUsed"));
    let free = parse_embedded_json_u64(pages, "freeSpace");
    let used = if let Some(u) = used_explicit {
        u
    } else if let Some(f) = free {
        if f > 0 && f <= total {
            total.saturating_sub(f)
        } else {
            0
        }
    } else {
        0
    };
    let tariff = four_shared_tariff(pages, total);
    (used, total, tariff)
}

fn four_shared_collect_files(pages: &str) -> Vec<CloudFileMeta> {
    let mut metas = four_shared_collect_files_html(pages);
    four_shared_collect_files_json(pages, &mut metas);
    metas
}

fn four_shared_collect_files_html(pages: &str) -> Vec<CloudFileMeta> {
    use std::collections::HashSet;
    let mut seen = HashSet::new();
    let mut metas = Vec::new();
    let patterns = [
        r#"data-filename="([^"]+)""#,
        r#"data-filename='([^']+)'"#,
        r#""fileName"\s*:\s*"([^"]+)""#,
        r#""name"\s*:\s*"([^"]+\.[A-Za-z0-9]{1,8})""#,
    ];
    for pat in patterns {
        let Ok(re) = regex::Regex::new(pat) else {
            continue;
        };
        for cap in re.captures_iter(pages) {
            if let Some(m) = cap.get(1) {
                let name = m.as_str().trim();
                if name.is_empty() || name.len() > 512 || !seen.insert(name.to_string()) {
                    continue;
                }
                metas.push(CloudFileMeta::new(name, 0, name));
                if metas.len() >= MAX_CLOUD_LIST_LINES {
                    return metas;
                }
            }
        }
    }
    metas
}

fn four_shared_collect_files_json(pages: &str, metas: &mut Vec<CloudFileMeta>) {
    use std::collections::HashSet;
    let mut seen: HashSet<String> = metas.iter().map(|m| m.name.clone()).collect();
    if let Some(blob) = four_shared_next_data_json(pages) {
        four_shared_walk_json_files(&blob, metas, &mut seen);
    }
    for pat in [
        r#""fileName"\s*:\s*"([^"\\]+)""#,
        r#""name"\s*:\s*"([^"\\]+\.[A-Za-z0-9]{1,8})""#,
        r#""descr"\s*:\s*"([^"\\]+)""#,
    ] {
        let Ok(re) = regex::Regex::new(pat) else {
            continue;
        };
        for cap in re.captures_iter(pages) {
            if let Some(m) = cap.get(1) {
                let name = m.as_str().trim();
                if name.is_empty() || name.len() > 512 || !seen.insert(name.to_string()) {
                    continue;
                }
                metas.push(CloudFileMeta::new(name, 0, name));
                if metas.len() >= MAX_CLOUD_LIST_LINES {
                    return;
                }
            }
        }
    }
}

fn four_shared_next_data_json(pages: &str) -> Option<Value> {
    let marker = "id=\"__NEXT_DATA__\" type=\"application/json\">";
    let start = pages.find(marker)?;
    let json_start = start + marker.len();
    let rest = pages.get(json_start..)?;
    let end = rest.find("</script>")?;
    serde_json::from_str(rest.get(..end)?.trim()).ok()
}

fn four_shared_walk_json_files(
    v: &Value,
    out: &mut Vec<CloudFileMeta>,
    seen: &mut std::collections::HashSet<String>,
) {
    match v {
        Value::Array(arr) => {
            for item in arr {
                four_shared_walk_json_files(item, out, seen);
            }
        }
        Value::Object(map) => {
            let name = map
                .get("fileName")
                .or_else(|| map.get("name"))
                .or_else(|| map.get("descr"))
                .and_then(|x| x.as_str())
                .map(str::trim)
                .filter(|s| !s.is_empty() && s.len() <= 512);
            let looks_like_file = name.is_some_and(|n| {
                n.contains('.')
                    || map.contains_key("size")
                    || map.contains_key("fileId")
                    || map.contains_key("id")
            });
            if looks_like_file {
                if let Some(n) = name {
                    if seen.insert(n.to_string()) {
                        let size = map
                            .get("size")
                            .and_then(|x| x.as_u64().or_else(|| x.as_str()?.parse().ok()))
                            .unwrap_or(0);
                        out.push(CloudFileMeta::new(n, size, n));
                        if out.len() >= MAX_CLOUD_LIST_LINES {
                            return;
                        }
                    }
                }
            }
            for val in map.values() {
                four_shared_walk_json_files(val, out, seen);
            }
        }
        _ => {}
    }
}

fn four_shared_parse_api_json_chunks(blob: &str, metas: &mut Vec<CloudFileMeta>) {
    use std::collections::HashSet;
    let mut seen: HashSet<String> = metas.iter().map(|m| m.name.clone()).collect();
    for chunk in blob.split('\n') {
        let chunk = chunk.trim();
        if chunk.is_empty() || (!chunk.starts_with('{') && !chunk.starts_with('[')) {
            continue;
        }
        if let Ok(v) = serde_json::from_str::<Value>(chunk) {
            four_shared_walk_json_files(&v, metas, &mut seen);
            if metas.len() >= MAX_CLOUD_LIST_LINES {
                return;
            }
        }
    }
}

fn four_shared_is_geo_stub_json(body: &str) -> bool {
    let t = body.trim();
    t.starts_with('{')
        && t.contains("\"country\"")
        && t.contains("\"dc.id\"")
        && !t.contains("\"status\"")
}

/// fileList/getTree через SOCKS часто отдают geo JSON вместо API; логин оставляем на прокси, листинг — direct.
fn four_shared_listing_config(cfg: &CloudClientConfig) -> CloudClientConfig {
    if cfg.proxy.is_some() {
        if let Ok(direct) = cfg.clone_with_proxy(None) {
            return direct;
        }
    }
    cfg.clone()
}

fn four_shared_security_user_id(curl: &CloudCurlSession, pages: &str) -> Option<String> {
    if let Some(id) = curl.cookie_value("Login") {
        let id = id.trim();
        if !id.is_empty() && id.chars().all(|c| c.is_ascii_digit()) {
            return Some(id.to_string());
        }
    }
    for key in ["userId", "userID", "loginId", "loginID"] {
        if let Some(n) = parse_embedded_json_u64(pages, key) {
            if n > 0 {
                return Some(n.to_string());
            }
        }
    }
    if let Ok(re) = regex::Regex::new(r#"id="jsCurUserId"[^>]*value="(\d{4,})""#) {
        if let Some(cap) = re.captures(pages) {
            if let Some(m) = cap.get(1) {
                return Some(m.as_str().to_string());
            }
        }
    }
    if let Ok(re) = regex::Regex::new(r#"(?i)"(?:userId|loginId)"\s*:\s*"?(\d{5,})"?"#) {
        if let Some(cap) = re.captures(pages) {
            if let Some(m) = cap.get(1) {
                return Some(m.as_str().to_string());
            }
        }
    }
    None
}

fn four_shared_ajax_headers(
    cfg: &CloudClientConfig,
    curl: &CloudCurlSession,
    referer: &str,
    pages: Option<&str>,
    origin_base: &str,
) -> Vec<(String, String)> {
    let security_id = pages
        .and_then(|p| four_shared_security_user_id(curl, p))
        .or_else(|| four_shared_security_user_id(curl, ""));
    let extra: Vec<(&str, &str)> = vec![
        ("Referer", referer),
        ("Origin", origin_base),
        ("X-Requested-With", "XMLHttpRequest"),
        (
            "Accept",
            "application/json, text/javascript, text/html, */*; q=0.01",
        ),
    ];
    let mut headers = header_pairs(cfg, &extra);
    if let Some(id) = security_id {
        headers.retain(|(k, _)| !k.eq_ignore_ascii_case("x-security"));
        headers.push(("X-Security".to_string(), id.clone()));
        headers.push(("x-security".to_string(), id));
    }
    headers
}

fn four_shared_api_json_from_body(body: &str) -> Option<Value> {
    let mut trimmed = body.trim();
    if trimmed.is_empty() {
        return None;
    }
    // JSONP: callback({...});
    if let Some(start) = trimmed.find('(') {
        if trimmed.ends_with(')')
            && trimmed[..start]
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || c == '_')
        {
            if let Some(inner) = trimmed.get(start + 1..trimmed.len().saturating_sub(1)) {
                trimmed = inner.trim();
            }
        }
    }
    if !trimmed.starts_with('{') || four_shared_is_geo_stub_json(trimmed) {
        return None;
    }
    serde_json::from_str(trimmed).ok()
}

fn four_shared_json_has_file_payload(v: &Value) -> bool {
    if let Some(info) = v.get("info") {
        if info.get("files").and_then(|x| x.as_array()).is_some_and(|a| !a.is_empty()) {
            return true;
        }
        if info.get("dirs").and_then(|x| x.as_array()).is_some_and(|a| !a.is_empty()) {
            return true;
        }
    }
    v.get("files").and_then(|x| x.as_array()).is_some_and(|a| !a.is_empty())
}

fn four_shared_api_ok(v: &Value) -> bool {
    if four_shared_json_has_file_payload(v) {
        return true;
    }
    if let Some(s) = v.get("status").and_then(|x| x.as_str()) {
        if s.eq_ignore_ascii_case("ok") || s.eq_ignore_ascii_case("success") {
            return true;
        }
    }
    if v.get("success").and_then(|x| x.as_bool()) == Some(true) {
        return true;
    }
    if v.get("result").and_then(|x| x.as_str()).is_some_and(|r| r.eq_ignore_ascii_case("ok")) {
        return true;
    }
    false
}

fn four_shared_api_usable(v: &Value) -> bool {
    if four_shared_api_ok(v) || four_shared_json_has_file_payload(v) {
        return true;
    }
    // getTree / пустой fileList часто без status, только tree или info.
    v.get("tree").is_some() || v.get("info").is_some()
}

fn four_shared_dir_bootstrap_ids(pages: &str, tree: Option<&Value>) -> Vec<String> {
    let mut ids = Vec::new();
    if let Some(t) = tree {
        if let Some(rights) = t.get("rights").and_then(|x| x.as_array()) {
            for r in rights {
                if let Some(id) = r.get("dirId").and_then(|x| x.as_str()) {
                    if !id.is_empty() {
                        ids.push(id.to_string());
                    }
                }
            }
        }
        if let Some(root) = four_shared_tree_root_dir_id(t) {
            ids.push(root);
        }
    }
    if let Some(id) = parse_embedded_json_string(pages, "rootFolderId") {
        if !id.is_empty() {
            ids.push(id);
        }
    }
    if let Ok(re) = regex::Regex::new(
        r#"id="jsRootFolderIdForCurrentUser"[^>]*value="([A-Za-z0-9_-]{6,})""#,
    ) {
        if let Some(cap) = re.captures(pages) {
            if let Some(m) = cap.get(1) {
                ids.push(m.as_str().to_string());
            }
        }
    }
    if let Ok(re) = regex::Regex::new(r#""dirId"\s*:\s*"([A-Za-z0-9_-]{6,})""#) {
        for cap in re.captures_iter(pages) {
            if let Some(m) = cap.get(1) {
                ids.push(m.as_str().to_string());
            }
        }
    }
    ids.sort_unstable();
    ids.dedup();
    ids
}

fn four_shared_decode_name(raw: &str) -> String {
    raw.replace("&nbsp;", " ")
        .replace("<wbr/>", "")
        .replace("<wbr>", "")
        .trim()
        .to_string()
}

fn four_shared_json_u64_field(v: &Value, key: &str) -> Option<u64> {
    v.get(key).and_then(|x| {
        x.as_u64()
            .or_else(|| x.as_i64().filter(|n| *n >= 0).map(|n| n as u64))
            .or_else(|| x.as_str()?.parse().ok())
    })
}

fn four_shared_stats_from_file_list(v: &Value) -> Option<(u64, u64)> {
    let used_arr = v.get("info")?.get("used")?.as_array()?;
    let total = used_arr.get(2).and_then(|x| {
        x.as_u64()
            .or_else(|| x.as_i64().filter(|n| *n >= 0).map(|n| n as u64))
    })?;
    let used = if let Some(pct) = used_arr.get(1).and_then(|x| x.as_u64()) {
        total.saturating_mul(pct).saturating_div(100)
    } else {
        0
    };
    Some((used, total))
}

fn four_shared_collect_dir_list_page(
    v: &Value,
    path_prefix: &[String],
    metas: &mut Vec<CloudFileMeta>,
    seen: &mut HashSet<String>,
) -> Vec<(String, String)> {
    let Some(info) = v.get("info") else {
        return Vec::new();
    };
    if let Some(files) = info.get("files").and_then(|x| x.as_array()) {
        for f in files {
            let Some(name) = f
                .get("name")
                .or_else(|| f.get("fileName"))
                .or_else(|| f.get("descr"))
                .and_then(|x| x.as_str())
                .map(four_shared_decode_name)
                .filter(|n| !n.is_empty() && n.len() <= 512)
            else {
                continue;
            };
            let path = four_shared_join_path(path_prefix, &name);
            if !seen.insert(path.clone()) {
                continue;
            }
            let size = four_shared_json_u64_field(f, "size").unwrap_or(0);
            let remote = f
                .get("id")
                .and_then(|x| x.as_str())
                .map(|s| s.to_string());
            let mut meta = CloudFileMeta::new(name, size, path);
            if let Some(id) = remote {
                meta = meta.with_remote_id(id);
            }
            metas.push(meta);
            if metas.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
        }
    }
    let mut subdirs = Vec::new();
    if let Some(dirs) = info.get("dirs").and_then(|x| x.as_array()) {
        for d in dirs {
            let Some(id) = d.get("id").and_then(|x| x.as_str()).filter(|s| !s.is_empty()) else {
                continue;
            };
            let name = d
                .get("name")
                .and_then(|x| x.as_str())
                .map(four_shared_decode_name)
                .unwrap_or_default();
            subdirs.push((id.to_string(), name));
        }
    }
    subdirs
}

fn four_shared_collect_tree_dirs(node: &Value, path: &[String], out: &mut Vec<(String, Vec<String>)>) {
    if let Some(id) = node
        .get("id")
        .and_then(|x| x.as_str())
        .filter(|s| !s.is_empty())
    {
        out.push((id.to_string(), path.to_vec()));
    }
    let mut child_path = path.to_vec();
    if let Some(text) = node.get("text").and_then(|x| x.as_str()) {
        let name = four_shared_decode_name(text);
        if !name.is_empty() {
            child_path.push(name);
        }
    }
    if let Some(children) = node.get("children").and_then(|x| x.as_array()) {
        for child in children {
            four_shared_collect_tree_dirs(child, &child_path, out);
        }
    }
}

fn four_shared_tree_root_dir_id(tree: &Value) -> Option<String> {
    tree.get("tree")?
        .get("children")?
        .as_array()?
        .iter()
        .find_map(|node| {
            let id = node.get("id")?.as_str()?;
            if node.get("nodeType").and_then(|x| x.as_str()) == Some("rootFolder") {
                Some(id.to_string())
            } else if node.get("text").and_then(|x| x.as_str()) == Some("My 4shared") {
                Some(id.to_string())
            } else {
                None
            }
        })
}

async fn four_shared_get_json(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ctx: &str,
    url: &str,
    referer: &str,
    pages: Option<&str>,
    origin_base: &str,
) -> Option<Value> {
    let headers = four_shared_ajax_headers(cfg, curl, referer, pages, origin_base);
    let refs: Vec<(&str, &str)> = headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let (_st, body) = curl
        .get_text(cfg, ctx, url, &refs, true)
        .await
        .ok()?;
    let v = four_shared_api_json_from_body(&body)?;
    if four_shared_api_usable(&v) {
        Some(v)
    } else {
        None
    }
}

async fn four_shared_fetch_file_list_page(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ep: &FourSharedEndpoints,
    dir_id: &str,
    offset: u32,
    referer: &str,
    pages: Option<&str>,
) -> Option<Value> {
    let headers = four_shared_ajax_headers(cfg, curl, referer, pages, &ep.base);
    let refs: Vec<(&str, &str)> = headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let url = format!(
        "{}?dirId={dir_id}&limit=500&offset={offset}&order=created",
        ep.file_list()
    );
    if let Ok((_st, body)) = curl
        .get_text(cfg, "4shared fileList", &url, &refs, true)
        .await
    {
        if let Some(v) = four_shared_api_json_from_body(&body) {
            if four_shared_api_usable(&v) {
                return Some(v);
            }
        }
    }
    let offset_s = offset.to_string();
    if let Ok((_st, body)) = curl
        .post_form(
            cfg,
            "4shared fileList post",
            &ep.file_list(),
            &[
                ("dirId", dir_id),
                ("limit", "500"),
                ("offset", offset_s.as_str()),
                ("order", "created"),
            ],
            &refs,
            true,
        )
        .await
    {
        if let Some(v) = four_shared_api_json_from_body(&body) {
            if four_shared_api_usable(&v) {
                return Some(v);
            }
        }
    }
    None
}

async fn four_shared_inventory_via_file_list(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    pages: &str,
    ep: &FourSharedEndpoints,
) -> (Vec<CloudFileMeta>, Option<(u64, u64)>) {
    let referer = ep.files_page();
    let mut metas = Vec::new();
    let mut seen_paths = HashSet::new();
    let mut quota: Option<(u64, u64)> = None;

    if four_shared_security_user_id(curl, pages).is_none() {
        return (metas, quota);
    }

    let tree = four_shared_get_json(
        cfg,
        curl,
        "4shared getTree",
        &ep.tree(),
        &referer,
        Some(pages),
        &ep.base,
    )
    .await;
    let mut dirs = Vec::new();
    if let Some(ref t) = tree {
        if let Some(tree_node) = t.get("tree") {
            four_shared_collect_tree_dirs(tree_node, &[], &mut dirs);
        }
    }
    if dirs.is_empty() {
        for id in four_shared_dir_bootstrap_ids(pages, tree.as_ref()) {
            dirs.push((id, Vec::new()));
        }
    }
    let mut queue: VecDeque<(String, Vec<String>)> = dirs.into_iter().collect();

    let mut seen_dirs = HashSet::new();
    while let Some((dir_id, path)) = queue.pop_front() {
        if !seen_dirs.insert(dir_id.clone()) {
            continue;
        }
        let mut offset = 0u32;
        loop {
            let Some(page) = four_shared_fetch_file_list_page(
                cfg,
                curl,
                ep,
                &dir_id,
                offset,
                &referer,
                Some(pages),
            )
            .await
            else {
                break;
            };
            if quota.is_none() {
                quota = four_shared_stats_from_file_list(&page);
            }
            let subdirs = four_shared_collect_dir_list_page(
                &page,
                &path,
                &mut metas,
                &mut seen_paths,
            );
            for (sub_id, sub_name) in subdirs {
                let mut subpath = path.clone();
                if !sub_name.is_empty() {
                    subpath.push(sub_name);
                }
                queue.push_back((sub_id, subpath));
            }
            let file_count = page
                .get("info")
                .and_then(|i| i.get("files"))
                .and_then(|x| x.as_array())
                .map(|a| a.len())
                .unwrap_or(0);
            if file_count < 500 {
                break;
            }
            offset = offset.saturating_add(500);
            if metas.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
        }
        if metas.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
    }
    (metas, quota)
}

fn four_shared_root_dir_candidates(home: &str) -> Vec<String> {
    let mut ids = Vec::new();
    if let Some(id) = parse_embedded_json_string(home, "rootFolderId") {
        if !id.is_empty() {
            ids.push(id);
        }
    }
    for key in ["rootDirId", "currentDirId", "dirId"] {
        if let Some(n) = parse_embedded_json_u64(home, key) {
            ids.push(n.to_string());
        }
    }
    if let Ok(re) = regex::Regex::new(r#"class="jsItemDirId"[^>]*value="(\d+)""#) {
        for cap in re.captures_iter(home) {
            if let Some(m) = cap.get(1) {
                ids.push(m.as_str().to_string());
            }
        }
    }
    ids.push("-1".to_string());
    ids.push("0".to_string());
    ids.sort_unstable();
    ids.dedup();
    ids
}

fn four_shared_join_path(prefix: &[String], leaf: &str) -> String {
    if prefix.is_empty() {
        leaf.to_string()
    } else {
        format!("{}/{}", prefix.join("/"), leaf)
    }
}

fn four_shared_collect_legacy_file_manager_html(
    html: &str,
    path_prefix: &[String],
    metas: &mut Vec<CloudFileMeta>,
    seen: &mut HashSet<String>,
) {
    let Ok(file_re) = regex::Regex::new(
        r#"(?s)id="ml_file_\d+"[^>]*>.*?class="jsName"[^>]*>([^<]+)<"#,
    ) else {
        return;
    };
    for cap in file_re.captures_iter(html) {
        if let Some(m) = cap.get(1) {
            let name = m.as_str().trim();
            if name.is_empty() || name.len() > 512 || !seen.insert(name.to_string()) {
                continue;
            }
            let path = four_shared_join_path(path_prefix, name);
            metas.push(CloudFileMeta::new(name, 0, path));
            if metas.len() >= MAX_CLOUD_LIST_LINES {
                return;
            }
        }
    }
}

fn four_shared_subfolder_ids(html: &str) -> Vec<(String, String)> {
    let Ok(re) = regex::Regex::new(
        r#"(?s)id="ml_folder_(\d+)"[^>]*>.*?class="jsName"[^>]*>([^<]+)<"#,
    ) else {
        return Vec::new();
    };
    re.captures_iter(html)
        .filter_map(|cap| {
            let id = cap.get(1)?.as_str().to_string();
            let name = cap.get(2)?.as_str().trim().to_string();
            if name.is_empty() {
                None
            } else {
                Some((id, name))
            }
        })
        .collect()
}

async fn four_shared_fetch_dir_body(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ep: &FourSharedEndpoints,
    dir_id: &str,
    pages: &str,
) -> String {
    let referer = ep.home();
    let headers = four_shared_ajax_headers(cfg, curl, &referer, Some(pages), &ep.base);
    let refs: Vec<(&str, &str)> = headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let mut blob = String::new();
    for url in [
        format!("{}?dirId={dir_id}", ep.dir_content()),
        format!("{}?dirId={dir_id}&json=1", ep.dir_content()),
        format!(
            "{}?dirId={dir_id}&limit=500&offset=0&order=created",
            ep.file_list()
        ),
    ] {
        if let Ok((_st, body)) = curl
            .get_text(cfg, "4shared dir content", &url, &refs, true)
            .await
        {
            if body.contains("ml_file_")
                || body.contains("jsName")
                || body.trim_start().starts_with('{')
            {
                blob.push_str(&body);
                blob.push('\n');
            }
        }
    }
    if let Ok((_st, body)) = curl
        .post_form(
            cfg,
            "4shared fileList post",
            &ep.file_list(),
            &[
                ("dirId", dir_id),
                ("limit", "500"),
                ("offset", "0"),
                ("order", "created"),
            ],
            &refs,
            true,
        )
        .await
    {
        if !body.is_empty() {
            blob.push_str(&body);
            blob.push('\n');
        }
    }
    blob
}

async fn four_shared_walk_account_tree(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ep: &FourSharedEndpoints,
    home_html: &str,
) -> Vec<CloudFileMeta> {
    if four_shared_security_user_id(curl, home_html).is_none() {
        return Vec::new();
    }
    let roots = four_shared_root_dir_candidates(home_html);
    let mut metas = Vec::new();
    let mut seen_names = HashSet::new();
    let mut seen_dirs = HashSet::new();
    let mut queue: VecDeque<(String, Vec<String>)> = roots
        .into_iter()
        .map(|id| (id, Vec::new()))
        .collect();
    while let Some((dir_id, path)) = queue.pop_front() {
        if !seen_dirs.insert(dir_id.clone()) {
            continue;
        }
        let body = four_shared_fetch_dir_body(cfg, curl, ep, &dir_id, home_html).await;
        if body.is_empty() {
            continue;
        }
        four_shared_collect_legacy_file_manager_html(&body, &path, &mut metas, &mut seen_names);
        four_shared_parse_api_json_chunks(&body, &mut metas);
        for (sub_id, sub_name) in four_shared_subfolder_ids(&body) {
            let mut subpath = path.clone();
            subpath.push(sub_name);
            queue.push_back((sub_id, subpath));
        }
        if metas.len() >= MAX_CLOUD_LIST_LINES {
            break;
        }
    }
    metas
}

async fn four_shared_fetch_api_lists(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    ep: &FourSharedEndpoints,
    pages: &str,
) -> String {
    let referer = ep.files_page();
    let headers = four_shared_ajax_headers(cfg, curl, &referer, Some(pages), &ep.base);
    let refs: Vec<(&str, &str)> = headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let mut blob = String::new();
    for url in [
        format!("{}?dirId=-1&json=1", ep.dir_content()),
        format!("{}?dirId=0&json=1", ep.dir_content()),
        format!("{}?dirId=-1&output=json", ep.tree()),
        format!("{}?dirId=0&output=json", ep.tree()),
        format!(
            "{}?dirId=-1&limit=500&offset=0&order=created",
            ep.file_list()
        ),
        format!("{}?dirId=-1&limit=500&offset=0", ep.file_list()),
    ] {
        if let Ok((_st, body)) = curl
            .get_text(cfg, "4shared file list api", &url, &refs, true)
            .await
        {
            if body.trim_start().starts_with('{') || body.trim_start().starts_with('[') {
                blob.push_str(&body);
                blob.push('\n');
            }
        }
    }
    blob
}

async fn four_shared_webdav_files(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
) -> Result<Vec<CloudFileMeta>> {
    const PROPFIND_BODY: &str = r#"<?xml version="1.0" encoding="utf-8"?>
<D:propfind xmlns:D="DAV:">
  <D:prop><D:displayname/><D:getcontentlength/><D:resourcetype/></D:prop>
</D:propfind>"#;
    let webdav_secret = curl
        .cookie_value("Password")
        .filter(|p| !p.is_empty())
        .map(|s| s.to_string())
        .unwrap_or_else(|| password.to_string());
    let (status, text) = curl
        .webdav_propfind_basic(
            cfg,
            "4shared webdav",
            WEBDAV_ROOT,
            email,
            webdav_secret.as_str(),
            "infinity",
            PROPFIND_BODY,
            &[],
        )
        .await
        .context("4shared webdav propfind")?;
    if status == 401 || status == 403 {
        return Ok(Vec::new());
    }
    if status >= 400 {
        return Ok(Vec::new());
    }
    let mut names = parse_webdav_file_names(&text);
    names.sort_unstable();
    names.dedup();
    if names.len() > MAX_CLOUD_LIST_LINES {
        names.truncate(MAX_CLOUD_LIST_LINES);
    }
    Ok(names
        .into_iter()
        .map(|n| CloudFileMeta::new(n.clone(), 0, n))
        .collect())
}

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        four_shared_inventory(cfg, client, cred)
    })
    .await
}

async fn four_shared_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let inv = four_shared_inventory_session(cfg, &email, &password).await?;
    if inv.file_count > 0 || cfg.proxy.is_none() {
        return Ok(inv);
    }
    let Ok(direct) = cfg.clone_with_proxy(None) else {
        return Ok(inv);
    };
    match four_shared_inventory_session(&direct, &email, &password).await {
        Ok(direct_inv) => Ok(direct_inv),
        Err(_) => Ok(inv),
    }
}

async fn four_shared_inventory_session(
    cfg: &CloudClientConfig,
    email: &str,
    password: &str,
) -> Result<CloudInventory> {
    let mut curl = CloudCurlSession::new()?;
    curl.seed_cookie("4langcookie", "en");

    let warm_headers = header_pairs(cfg, &[("Referer", LOGIN_URL)]);
    let warm_refs: Vec<(&str, &str)> = warm_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    curl.get_text(cfg, "4shared login page", LOGIN_URL, &warm_refs, true)
        .await
        .context("4shared login page")?;

    let login_headers = header_pairs(
        cfg,
        &[
            ("Referer", LOGIN_URL),
            ("Origin", "https://www.4shared.com"),
        ],
    );
    let login_refs: Vec<(&str, &str)> = login_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();

    let (_status, body) = curl
        .post_form(
            cfg,
            "4shared login",
            LOGIN_URL,
            &[
                ("returnTo", RETURN_TO),
                ("ausk", ""),
                ("inviteId", ""),
                ("inviterName", ""),
                ("email", email),
                ("login", email),
                ("password", password),
                ("remember", "true"),
                ("_remember", "on"),
            ],
            &login_refs,
            true,
        )
        .await
        .context("4shared login")?;

    let home_headers = header_pairs(cfg, &[("Referer", LOGIN_URL)]);
    let home_refs: Vec<(&str, &str)> = home_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let (_hs, home_after_login) = curl
        .get_text(cfg, "4shared home after login", HOME_URL, &home_refs, true)
        .await
        .context("4shared home after login")?;
    let probe = format!("{body}{home_after_login}");
    if four_shared_login_form_still_visible(&home_after_login)
        && !four_shared_session_logged_in(&curl)
    {
        return Err(cloud_auth_error("invalid login or password"));
    }
    if !four_shared_logged_in(&curl, &probe) {
        if four_shared_html_auth_failure(&probe) {
            return Err(cloud_auth_error("invalid login or password"));
        }
        return Err(cloud_auth_error("invalid login or password"));
    }

    let home_html = home_after_login;

    let list_cfg = four_shared_listing_config(cfg);

    let files_headers = header_pairs(&list_cfg, &[("Referer", HOME_URL)]);
    let files_refs: Vec<(&str, &str)> = files_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let (_st, html) = curl
        .get_text(
            &list_cfg,
            "4shared files page",
            FILES_URL,
            &files_refs,
            true,
        )
        .await
        .unwrap_or((0, String::new()));

    let mut page_blob = body;
    page_blob.push_str(&home_html);
    page_blob.push_str(&html);

    let session_pages = page_blob.clone();

    let ep = four_shared_bind_datacenter(
        &list_cfg,
        &mut curl,
        &session_pages,
        email,
        password,
    )
    .await;
    let dc_files = ep.files_page();
    let dc_home = ep.home();
    let dc_files_headers = header_pairs(&list_cfg, &[("Referer", dc_home.as_str())]);
    let dc_files_refs: Vec<(&str, &str)> = dc_files_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    if let Ok((_st, dc_html)) = curl
        .get_text(
            &list_cfg,
            "4shared files page dc",
            &dc_files,
            &dc_files_refs,
            true,
        )
        .await
    {
        page_blob.push_str(&dc_html);
    }

    let session_pages = page_blob.clone();
    let (mut metas, mut file_list_quota) = four_shared_inventory_via_file_list(
        &list_cfg,
        &mut curl,
        &session_pages,
        &ep,
    )
    .await;
    let api_blob = four_shared_fetch_api_lists(&list_cfg, &mut curl, &ep, &session_pages).await;
    page_blob.push_str(&api_blob);

    if metas.is_empty()
        && file_list_quota.is_none()
        && cfg.proxy.is_some()
        && list_cfg.proxy.is_none()
    {
        let (m2, q2) = four_shared_inventory_via_file_list(
            cfg,
            &mut curl,
            &session_pages,
            &ep,
        )
        .await;
        if !m2.is_empty() || q2.is_some() {
            metas = m2;
            file_list_quota = q2;
            page_blob.push_str(
                &four_shared_fetch_api_lists(cfg, &mut curl, &ep, &session_pages).await,
            );
        }
    }

    if !four_shared_inventory_ready(&curl, &page_blob) {
        return Err(cloud_auth_error("invalid login or password"));
    }

    if metas.is_empty() {
        metas = four_shared_walk_account_tree(&list_cfg, &mut curl, &ep, &session_pages).await;
    }

    if metas.is_empty() {
        metas = four_shared_collect_files(&page_blob);
        four_shared_parse_api_json_chunks(&api_blob, &mut metas);
    }

    if metas.is_empty() {
        if let Ok(wdav) =
            four_shared_webdav_files(&list_cfg, &mut curl, &email, &password).await
        {
            metas = wdav;
        }
    }

    let (mut used, mut quota, tariff) = four_shared_stats(&page_blob);
    if let Some((u, q)) = file_list_quota {
        used = u;
        quota = q;
    }
    let mut inv = inventory_from_account(email, metas, used, quota, tariff);
    if inv.file_count == 0 {
        if four_shared_security_user_id(&curl, &session_pages).is_none() {
            inv.list_note = Some(
                "# 4shared: нет userId / cookie Login — API fileList недоступен\n".to_string(),
            );
        } else if used > 0 {
            inv.list_note = Some(
                "# 4shared: квота занята по API, но имена файлов не получены (WAF/формат API)\n"
                    .to_string(),
            );
        } else if file_list_quota.is_some() {
            inv.list_note = Some(
                "# 4shared: fileList OK — аккаунт пуст (files=[])\n".to_string(),
            );
        } else if cfg.proxy.is_some() {
            inv.list_note = Some(format!(
                "# 4shared: fileList через Direct/geo и через прокси не дали файлов (хост {})\n",
                ep.base
            ));
        } else {
            inv.list_note = Some(format!(
                "# 4shared: getTree/fileList — только geo/dc.id (часто IP датацентра); пробовали {}; нужен резидентный прокси\n",
                ep.base
            ));
        }
    }
    Ok(inv)
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn four_shared_parse_geo_dc_id() {
        let stub = r#"{"country":"Germany","dc.id":517,"ip":"1.2.3.4","cause":null}"#;
        assert_eq!(four_shared_parse_geo_dc(stub), Some(517));
    }

    #[test]
    fn four_shared_dc_endpoint_paths() {
        let ep = FourSharedEndpoints::dc(243);
        assert_eq!(
            ep.file_list(),
            "https://dc243.4shared.com/web/account/fileList"
        );
    }

    #[test]
    fn four_shared_api_usable_tree_without_status() {
        let v: Value = serde_json::from_str(r#"{"tree":{"children":[]}}"#).unwrap();
        assert!(four_shared_api_usable(&v));
    }

    #[test]
    fn four_shared_tariff_not_from_upsell_html() {
        let pages = r#""totalSpace":16106127360,"freeSpace":15973048320,"plan":"Free"
        Get Premium now upgrade to premium account"#;
        assert_eq!(four_shared_stats(pages).2, "Free");
    }

    #[test]
    fn four_shared_used_not_full_when_free_space_missing() {
        let pages = r#""totalSpace":16106127360,"freeSpace":0"#;
        let (used, total, _) = four_shared_stats(pages);
        assert_eq!(total, FOUR_SHARED_FREE_BYTES);
        assert_eq!(used, 0);
    }

    #[test]
    fn four_shared_legacy_html_lists_js_name_files() {
        let html = r#"<div id="ml_file_123" class="jsItem jsIsFile"><span class="jsName">java_ch1.pdf</span></div>"#;
        let mut metas = Vec::new();
        let mut seen = HashSet::new();
        four_shared_collect_legacy_file_manager_html(html, &[], &mut metas, &mut seen);
        assert_eq!(metas.len(), 1);
        assert_eq!(metas[0].name, "java_ch1.pdf");
    }

    #[test]
    fn four_shared_file_list_used_array_maps_quota() {
        let v: Value = serde_json::from_str(
            r#"{"status":"ok","info":{"used":["13.75 GB",91,16106127360],"files":[]}}"#,
        )
        .unwrap();
        let (used, total) = four_shared_stats_from_file_list(&v).unwrap();
        assert_eq!(total, 16_106_127_360);
        assert_eq!(used, total * 91 / 100);
    }

    #[test]
    fn four_shared_decode_name_strips_html() {
        assert_eq!(
            four_shared_decode_name("My&nbsp;4shared&nbsp;Sync"),
            "My 4shared Sync"
        );
    }

    #[test]
    fn four_shared_geo_stub_is_not_api_json() {
        let stub = r#"{"country":"United States","dc.id":558,"ip":"1.2.3.4","cause":null}"#;
        assert!(four_shared_is_geo_stub_json(stub));
        assert!(four_shared_api_json_from_body(stub).is_none());
    }

    #[test]
    fn four_shared_security_id_from_js_cur_user_id() {
        let html = r#"<input type="hidden" id="jsCurUserId" name="jsCurUserId" value="2682607">"#;
        let curl = CloudCurlSession::new().expect("curl");
        assert_eq!(
            four_shared_security_user_id(&curl, html).as_deref(),
            Some("2682607")
        );
    }

    /// `FOUR_SHARED_TEST_COMBO=email:pass` — dumps getTree/fileList bodies after login.
    #[tokio::test]
    #[ignore = "local diag: set FOUR_SHARED_TEST_COMBO"]
    async fn four_shared_local_diag() {
        use pma_core::{CloudDownloadFilter, CloudProvider};
        use std::time::Duration;
        let combo = std::env::var("FOUR_SHARED_TEST_COMBO").expect("FOUR_SHARED_TEST_COMBO");
        let (email, password) = combo.trim().split_once(':').expect("email:password");
        let cfg = CloudClientConfig::build(
            CloudProvider::FourShared,
            Duration::from_secs(90),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("config");
        let mut curl = CloudCurlSession::new().expect("curl");
        curl.seed_cookie("4langcookie", "en");
        let warm = header_pairs(&cfg, &[("Referer", LOGIN_URL)]);
        let warm_r: Vec<(&str, &str)> = warm.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
        curl.get_text(&cfg, "login page", LOGIN_URL, &warm_r, true)
            .await
            .expect("warm");
        let login_h = header_pairs(
            &cfg,
            &[("Referer", LOGIN_URL), ("Origin", "https://www.4shared.com")],
        );
        let login_r: Vec<(&str, &str)> =
            login_h.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
        let (_s, body) = curl
            .post_form(
                &cfg,
                "login",
                LOGIN_URL,
                &[
                    ("returnTo", RETURN_TO),
                    ("ausk", ""),
                    ("inviteId", ""),
                    ("inviterName", ""),
                    ("email", email),
                    ("login", email),
                    ("password", password),
                    ("remember", "true"),
                    ("_remember", "on"),
                ],
                &login_r,
                true,
            )
            .await
            .expect("post login");
        let home_h = header_pairs(&cfg, &[("Referer", LOGIN_URL)]);
        let home_r: Vec<(&str, &str)> =
            home_h.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
        let (_hs, home) = curl
            .get_text(&cfg, "home", HOME_URL, &home_r, true)
            .await
            .expect("home");
        let (_fs, files) = curl
            .get_text(
                &cfg,
                "files",
                FILES_URL,
                &header_pairs(&cfg, &[("Referer", HOME_URL)])
                    .iter()
                    .map(|(k, v)| (k.as_str(), v.as_str()))
                    .collect::<Vec<_>>(),
                true,
            )
            .await
            .unwrap_or((0, String::new()));
        let pages = format!("{body}{home}{files}");
        eprintln!(
            "cookies Login={:?} ulin={:?} JSESSIONID={}",
            curl.cookie_value("Login"),
            curl.cookie_value("ulin"),
            curl.cookie_value("JSESSIONID").is_some()
        );
        eprintln!(
            "userId={:?} logged_in={}",
            four_shared_security_user_id(&curl, &pages),
            four_shared_logged_in(&curl, &pages)
        );
        let list_cfg = four_shared_listing_config(&cfg);
        let ep = four_shared_bind_datacenter(&list_cfg, &mut curl, &pages, email, password).await;
        eprintln!("bound datacenter base={}", ep.base);
        for (label, url) in [
            ("getTree", ep.tree()),
            (
                "fileList",
                format!("{}?dirId=-1&limit=5&offset=0", ep.file_list()),
            ),
        ] {
            let headers =
                four_shared_ajax_headers(&list_cfg, &curl, &ep.files_page(), Some(&pages), &ep.base);
            let refs: Vec<(&str, &str)> =
                headers.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
            if let Ok((_st, raw)) = curl.get_text(&list_cfg, label, url.as_str(), &refs, true).await {
                let preview: String = raw.chars().take(800).collect();
                eprintln!("--- {label} len={} ---\n{preview}", raw.len());
            } else {
                eprintln!("--- {label} FAILED ---");
            }
        }
        for needle in ["rootFolder", "dc.", "517", "getTree", "fileList", "__NEXT_DATA__"] {
            eprintln!(
                "files page contains {needle:?}: {}",
                files.contains(needle)
            );
        }
        if let Some(blob) = four_shared_next_data_json(&files) {
            eprintln!(
                "NEXT_DATA keys: {:?}",
                blob.as_object().map(|m| m.keys().collect::<Vec<_>>())
            );
        }
        let wdav = four_shared_webdav_files(&list_cfg, &mut curl, email, password)
            .await
            .unwrap_or_default();
        eprintln!("webdav file count={}", wdav.len());
    }

    /// `FOUR_SHARED_TEST_COMBO=email:pass` — Direct, no proxy.
    /// `cargo test -p pma-net four_shared_local_smoke -- --ignored --nocapture`
    #[tokio::test]
    #[ignore = "local smoke: set FOUR_SHARED_TEST_COMBO"]
    async fn four_shared_local_smoke() {
        use pma_core::{CloudDownloadFilter, CloudProvider};
        use std::time::Duration;
        let combo = std::env::var("FOUR_SHARED_TEST_COMBO").expect("FOUR_SHARED_TEST_COMBO");
        let (user, pass) = combo
            .trim()
            .split_once(':')
            .expect("email:password");
        let cred = Credential {
            url: url::Url::parse("https://www.4shared.com/").expect("url"),
            username: user.to_string(),
            password: pass.to_string(),
        };
        let cfg = CloudClientConfig::build(
            CloudProvider::FourShared,
            Duration::from_secs(90),
            false,
            None,
            1,
            false,
            CloudDownloadFilter::default(),
        )
        .expect("config");
        let out = std::env::temp_dir().join("four_shared_smoke");
        let _ = std::fs::create_dir_all(&out);
        match check_account(&cfg, &cred, &out, None).await {
            Ok((_stats, paths)) => {
                if let Ok(inv) = std::fs::read_to_string(paths.first().expect("contents file")) {
                    eprintln!("{inv}");
                }
                eprintln!("4shared smoke OK: wrote {} file(s)", paths.len());
            }
            Err(e) => panic!("4shared smoke FAIL: {e:#}"),
        }
    }
}
