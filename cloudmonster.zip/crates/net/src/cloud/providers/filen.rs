﻿use crate::cloud::common::{cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{json_api_header_pairs, CloudCurlSession};
use crate::cloud::filen_crypto::filen_derive_login_password;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const FILEN_AUTH_INFO: &str = "https://gateway.filen.io/v3/auth/info";
const FILEN_LOGIN_HOSTS: &[&str] = &[
    "https://gateway.filen-4.net/v3/login",
    "https://gateway.filen.io/v3/login",
];

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        filen_inventory(cfg, client, cred)
    })
    .await
}

async fn filen_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let base_headers = json_api_header_pairs(cfg, Some("https://app.filen.io/"));
    let header_refs: Vec<(&str, &str)> = base_headers
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();

    let info_payload = serde_json::json!({ "email": email });
    let (_info_status, info_json) = curl
        .post_json(cfg, "filen auth info", FILEN_AUTH_INFO, &info_payload, &header_refs)
        .await
        .context("filen auth/info")?;
    let salt = parse_filen_salt(&info_json).context("filen: salt from auth/info")?;
    let (_master_key, send_pwd) = filen_derive_login_password(&password, &salt);

    let login_payload = serde_json::json!({
        "email": email,
        "password": send_pwd,
        "twoFactorCode": "XXXXXX",
        "authVersion": 2
    });

    let mut login_json = Value::Null;
    let mut last_login_body = Value::Null;
    let mut login_ok = false;
    for url in FILEN_LOGIN_HOSTS {
        let (_status, body) = curl
            .post_json(cfg, "filen login", url, &login_payload, &header_refs)
            .await
            .with_context(|| format!("filen login {url}"))?;
        last_login_body = body.clone();
        match classify_filen_login(&body) {
            FilenLoginOutcome::Success => {
                login_json = body;
                login_ok = true;
                break;
            }
            FilenLoginOutcome::BadCredentials => {
                return Err(cloud_auth_error("Email address or password wrong."));
            }
            FilenLoginOutcome::TwoFactor => {
                return Err(cloud_auth_error(
                    "Please enter your Two Factor Authentication code.",
                ));
            }
            FilenLoginOutcome::RetryOtherHost => continue,
        }
    }
    if !login_ok {
        let msg = last_login_body
            .get("message")
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        return Err(cloud_auth_error(msg));
    }

    let data = login_json
        .get("data")
        .ok_or_else(|| anyhow::anyhow!("filen: missing data"))?;
    let api_key = data
        .get("apiKey")
        .and_then(|x| x.as_str())
        .ok_or_else(|| anyhow::anyhow!("filen: missing apiKey"))?;
    let root_uuid = data
        .get("baseFolderUUID")
        .or_else(|| data.get("root"))
        .and_then(|x| x.as_str())
        .unwrap_or("");

    let mut file_names: Vec<String> = Vec::new();
    if !root_uuid.is_empty() {
        let mut dir_headers = base_headers.clone();
        dir_headers.retain(|(k, _)| !k.eq_ignore_ascii_case("authorization"));
        dir_headers.push(("Authorization".to_string(), format!("Bearer {api_key}")));
        let dir_refs: Vec<(&str, &str)> = dir_headers
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();
        let dir_payload = serde_json::json!({ "uuid": root_uuid });
        if let Ok((_st, body)) = curl
            .post_json(
                cfg,
                "filen dir content",
                "https://gateway.filen.io/v3/dir/content",
                &dir_payload,
                &dir_refs,
            )
            .await
        {
            collect_filen_names(&body, &mut file_names);
        }
    }

    let files: Vec<CloudFileMeta> = file_names
        .iter()
        .map(|n| CloudFileMeta::new(n.as_str(), 0, n.as_str()))
        .collect();

    let used = json_u64_field(data, &["storageUsed", "storage", "usedStorage"]);
    let quota = json_u64_field(data, &["storageLimit", "maxStorage", "quota"]);

    let mut inv = inventory_from_account(
        &email,
        files,
        used.unwrap_or(0),
        quota.unwrap_or(0),
        "Free",
    );
    if inv.file_count == 0 {
        inv.list_note = Some(
            "# Filen: имена файлов зашифрованы на клиенте; при успешном login аккаунт считается Good\n"
                .to_string(),
        );
    }
    Ok(inv)
}

enum FilenLoginOutcome {
    Success,
    BadCredentials,
    TwoFactor,
    RetryOtherHost,
}

fn classify_filen_login(json: &Value) -> FilenLoginOutcome {
    let msg = json
        .get("message")
        .and_then(|x| x.as_str())
        .unwrap_or("");
    let blob = serde_json::to_string(json).unwrap_or_default();

    if msg.contains("Email address or password wrong.")
        || blob.contains("Email address or password wrong.")
    {
        return FilenLoginOutcome::BadCredentials;
    }
    if msg.contains("Please enter your Two Factor Authentication code.")
        || blob.contains("Please enter your Two Factor Authentication code.")
    {
        return FilenLoginOutcome::TwoFactor;
    }
    if msg.contains("Login successful.") || blob.contains("Login successful.") {
        return FilenLoginOutcome::Success;
    }
    if json.get("status").and_then(|x| x.as_bool()) == Some(true) {
        if json.get("data").and_then(|d| d.get("apiKey")).is_some() {
            return FilenLoginOutcome::Success;
        }
    }
    FilenLoginOutcome::RetryOtherHost
}

fn parse_filen_salt(info: &Value) -> Option<String> {
    info.get("data")
        .and_then(|d| d.get("salt"))
        .and_then(|x| x.as_str())
        .map(str::to_string)
        .or_else(|| {
            info.get("salt")
                .and_then(|x| x.as_str())
                .map(str::to_string)
        })
}

fn json_u64_field(v: &Value, keys: &[&str]) -> Option<u64> {
    for key in keys {
        if let Some(n) = v.get(*key).and_then(|x| x.as_u64()) {
            return Some(n);
        }
        if let Some(n) = v.get(*key).and_then(|x| x.as_i64()).filter(|n| *n >= 0) {
            return Some(n as u64);
        }
    }
    None
}

fn collect_filen_names(v: &Value, out: &mut Vec<String>) {
    if let Some(uploads) = v.get("uploads").and_then(|x| x.as_array()) {
        for u in uploads {
            if let Some(meta) = u.get("metadata").and_then(|x| x.as_str()) {
                if !meta.is_empty() {
                    out.push(meta.to_string());
                }
            } else if let Some(name) = u.get("filename").and_then(|x| x.as_str()) {
                out.push(name.to_string());
            }
        }
    }
    if let Some(dirs) = v.get("folders").and_then(|x| x.as_array()) {
        for d in dirs {
            if let Some(name) = d.get("name").and_then(|x| x.as_str()) {
                out.push(format!("{name}/"));
            }
        }
    }
}
