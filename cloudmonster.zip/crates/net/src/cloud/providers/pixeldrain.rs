﻿use crate::cloud::common::{cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::CloudCurlSession;
use crate::cloud::dispatch_download;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use std::path::{Path, PathBuf};

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        pixeldrain_inventory(cfg, client, cred)
    })
    .await
}

pub async fn download_filtered_files(
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    for file in picks {
        let Some(id) = file.remote_id.as_deref() else {
            continue;
        };
        let url = format!("https://pixeldrain.com/api/file/{id}");
        match dispatch_download::write_leaf(cred, run_output_dir, &file.name, &client, &url).await {
            Ok((path, n)) => {
                count += 1;
                total += n;
                paths.push(path);
            }
            Err(_) => continue,
        }
    }
    Ok((count, total, paths))
}

async fn pixeldrain_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let payload = serde_json::json!({
        "username": email,
        "password": password,
    });
    let (status, _login_json) = curl
        .post_json(
            cfg,
            "pixeldrain login",
            "https://pixeldrain.com/api/user/login",
            &payload,
            &[],
        )
        .await
        .context("pixeldrain login")?;
    if status == 401 {
        return Err(cloud_auth_error("invalid username or password"));
    }
    if status >= 400 {
        return Err(anyhow::anyhow!("pixeldrain login http {status}"));
    }

    let files_json = curl
        .get_json(
            cfg,
            "pixeldrain list files",
            "https://pixeldrain.com/api/user/files",
            &[],
        )
        .await
        .context("pixeldrain list files")?;

    let mut files: Vec<CloudFileMeta> = Vec::new();
    if let Some(arr) = files_json.as_array() {
        for item in arr {
            let name = item
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("file");
            let size = item.get("size").and_then(|x| x.as_u64()).unwrap_or(0);
            let id = item.get("id").and_then(|x| x.as_str()).unwrap_or("");
            let mut meta = CloudFileMeta::new(name, size, name);
            if !id.is_empty() {
                meta = meta.with_remote_id(id);
            }
            files.push(meta);
        }
    }

    let used: u64 = files.iter().map(|f| f.size).sum();
    Ok(inventory_from_account(&email, files, used, 0, "Free"))
}
