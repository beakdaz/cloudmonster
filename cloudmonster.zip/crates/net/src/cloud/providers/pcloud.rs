﻿//! pCloud - userinfo login + listfolder inventory (US/EU API hosts).

use crate::cloud::common::{
    cloud_auth_error, cloud_rate_limit_error, inventory_from_account, run_checker, CloudFileMeta,
    CloudInventory, MAX_CLOUD_LIST_LINES,
};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, parse_json_text, CloudCurlSession};
use crate::cloud::dispatch_download;
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{anyhow, Context, Result};
use pma_core::Credential;
use reqwest::Client;
use serde_json::Value;
use std::path::{Path, PathBuf};

const PCLOUD_HOSTS: [&str; 2] = ["api.pcloud.com", "eapi.pcloud.com"];
const PCLOUD_SESSION_SEP: char = '\x1f';

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        pcloud_inventory(cfg, client, cred)
    })
    .await
}

pub async fn download_filtered_files(
    cfg: &CloudClientConfig,
    client: Client,
    cred: &Credential,
    run_output_dir: &Path,
    inv: &CloudInventory,
    picks: &[&CloudFileMeta],
) -> Result<(usize, u64, Vec<PathBuf>)> {
    let session = inv
        .session_secret
        .as_deref()
        .context("pcloud: missing auth for download")?;
    let (host, auth) = pcloud_unpack_session(session);
    let mut curl = CloudCurlSession::new()?;
    let mut paths = Vec::new();
    let mut total = 0u64;
    let mut count = 0usize;
    for file in picks {
        let Some(fileid) = file.remote_id.as_deref() else {
            continue;
        };
        let fileid = fileid.trim_matches('"');
        let url = match pcloud_getfilelink(&mut curl, cfg, host, auth, fileid).await {
            Ok(u) => u,
            Err(_) => continue,
        };
        let leaf = if file.path.is_empty() {
            file.name.clone()
        } else {
            file.path.replace('/', "\\")
        };
        match dispatch_download::write_leaf(cred, run_output_dir, &leaf, &client, &url).await {
            Ok((path, n)) => {
                count += 1;
                total += n;
                paths.push(path);
            }
            Err(_) => continue,
        }
    }
    Ok((count, total, paths))
}

async fn pcloud_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let secret = password.trim();

    if secret.starts_with("pcloud:") || secret.starts_with("pcloud_auth:") {
        let auth = secret
            .strip_prefix("pcloud:")
            .or_else(|| secret.strip_prefix("pcloud_auth:"))
            .unwrap_or(secret)
            .trim();
        let mut curl = CloudCurlSession::new()?;
        return pcloud_inventory_with_auth(cfg, &mut curl, &email, auth, None).await;
    }

    let mut curl = CloudCurlSession::new()?;
    let mut last_err = None;
    for host in PCLOUD_HOSTS {
        match pcloud_login_and_list(cfg, &mut curl, &email, &password, host).await {
            Ok(inv) => return Ok(inv),
            Err(e) => last_err = Some(e),
        }
    }
    Err(last_err.unwrap_or_else(|| cloud_auth_error("pcloud: login failed")))
}

async fn pcloud_login_and_list(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    password: &str,
    host: &str,
) -> Result<CloudInventory> {
    let userinfo = pcloud_userinfo(curl, cfg, host, email, password).await?;
    let result = userinfo.get("result").and_then(|x| x.as_i64()).unwrap_or(-1);
    if result == 4000 {
        return Err(cloud_rate_limit_error("pcloud: too many login tries from this IP"));
    }
    if result == 2000 || result == 1000 {
        return Err(cloud_auth_error("pcloud: invalid email or password"));
    }
    if result != 0 {
        let msg = userinfo
            .get("error")
            .and_then(|x| x.as_str())
            .unwrap_or("login failed");
        return Err(cloud_auth_error(format!("pcloud: {msg} (code {result})")));
    }
    let auth = userinfo
        .get("auth")
        .and_then(|x| x.as_str())
        .ok_or_else(|| anyhow!("pcloud: missing auth token"))?
        .to_string();
    pcloud_inventory_with_auth(cfg, curl, email, &auth, Some(userinfo)).await
}

async fn pcloud_inventory_with_auth(
    cfg: &CloudClientConfig,
    curl: &mut CloudCurlSession,
    email: &str,
    auth: &str,
    userinfo: Option<Value>,
) -> Result<CloudInventory> {
    let host = userinfo
        .as_ref()
        .and_then(|u| u.get("api").and_then(|x| x.as_str()))
        .unwrap_or("api.pcloud.com");
    let host = if host.is_empty() { "api.pcloud.com" } else { host };

    let folder = pcloud_listfolder(curl, cfg, host, auth, 0)
        .await
        .context("pcloud listfolder")?;

    let mut files = Vec::new();
    collect_pcloud_metadata(&folder, "", &mut files);

    let used = userinfo
        .as_ref()
        .map(|u| field_u64(u, "usedquota"))
        .unwrap_or(0);
    let quota = userinfo
        .as_ref()
        .map(|u| field_u64(u, "quota"))
        .unwrap_or(0);
    let premium = userinfo
        .as_ref()
        .and_then(|u| u.get("premium").and_then(|x| x.as_bool()))
        .unwrap_or(false);

    let tariff = if premium { "Premium" } else { "Free" };
    let mut inv = inventory_from_account(email, files, used, quota, tariff);
    inv.session_secret = Some(pcloud_pack_session(host, auth));
    Ok(inv)
}

async fn pcloud_userinfo(
    curl: &mut CloudCurlSession,
    cfg: &CloudClientConfig,
    host: &str,
    email: &str,
    password: &str,
) -> Result<Value> {
    let url = build_url(
        &format!("https://{host}/userinfo"),
        &[
            ("getauth", "1"),
            ("logout", "1"),
            ("username", email),
            ("password", password),
        ],
    )?;
    let (status, text) = curl
        .get_text(cfg, "pcloud userinfo", &url, &[], false)
        .await
        .context("pcloud userinfo")?;
    if status >= 400 {
        return Err(anyhow!(
            "pcloud userinfo http {status}: {}",
            preview(&text, 200)
        ));
    }
    parse_json_text(cfg.provider, status, &text, "pcloud userinfo")
}

async fn pcloud_listfolder(
    curl: &mut CloudCurlSession,
    cfg: &CloudClientConfig,
    host: &str,
    auth: &str,
    folderid: u64,
) -> Result<Value> {
    let url = build_url(
        &format!("https://{host}/listfolder"),
        &[
            ("auth", auth),
            ("folderid", &folderid.to_string()),
            ("recursive", "1"),
        ],
    )?;
    let (status, text) = curl
        .get_text(cfg, "pcloud listfolder", &url, &[], false)
        .await
        .context("pcloud listfolder")?;
    if status == 401 || status == 403 {
        return Err(cloud_auth_error("pcloud: invalid auth token"));
    }
    let v = parse_json_text(cfg.provider, status, &text, "pcloud listfolder")?;
    let result = v.get("result").and_then(|x| x.as_i64()).unwrap_or(-1);
    if result == 2000 || result == 1000 {
        return Err(cloud_auth_error("pcloud: auth expired"));
    }
    if result != 0 {
        return Err(anyhow!("pcloud listfolder code {result}"));
    }
    Ok(v.get("metadata").cloned().unwrap_or(Value::Null))
}

async fn pcloud_getfilelink(
    curl: &mut CloudCurlSession,
    cfg: &CloudClientConfig,
    host: &str,
    auth: &str,
    fileid: &str,
) -> Result<String> {
    let url = build_url(
        &format!("https://{host}/getfilelink"),
        &[("auth", auth), ("fileid", fileid), ("forcedownload", "1")],
    )?;
    let (status, text) = curl
        .get_text(cfg, "pcloud getfilelink", &url, &[], false)
        .await
        .context("pcloud getfilelink")?;
    let v = parse_json_text(cfg.provider, status, &text, "pcloud getfilelink")?;
    let result = v.get("result").and_then(|x| x.as_i64()).unwrap_or(-1);
    if result != 0 {
        anyhow::bail!("pcloud getfilelink code {result}");
    }
    pcloud_download_url_from_link(&v).ok_or_else(|| anyhow!("pcloud getfilelink: missing hosts/path"))
}

pub fn pcloud_pack_session(host: &str, auth: &str) -> String {
    format!("{host}{PCLOUD_SESSION_SEP}{auth}")
}

pub fn pcloud_unpack_session(session: &str) -> (&str, &str) {
    session
        .split_once(PCLOUD_SESSION_SEP)
        .map(|(h, a)| (h, a))
        .unwrap_or(("api.pcloud.com", session))
}

pub fn pcloud_download_url_from_link(v: &Value) -> Option<String> {
    let host = v.get("hosts")?.as_array()?.first()?.as_str()?;
    let path = v.get("path")?.as_str()?;
    Some(format!("https://{host}{path}"))
}

fn collect_pcloud_metadata(node: &Value, prefix: &str, out: &mut Vec<CloudFileMeta>) {
    if out.len() >= MAX_CLOUD_LIST_LINES {
        return;
    }
    let is_folder = node
        .get("isfolder")
        .and_then(|x| x.as_bool())
        .unwrap_or(false);
    let name = node
        .get("name")
        .and_then(|x| x.as_str())
        .unwrap_or("");
    if !name.is_empty() && !is_folder {
        let path = if prefix.is_empty() {
            name.to_string()
        } else {
            format!("{prefix}{name}")
        };
        let size = node
            .get("size")
            .and_then(|x| x.as_u64())
            .or_else(|| node.get("size").and_then(|x| x.as_i64()).map(|n| n.max(0) as u64))
            .unwrap_or(0);
        let id = node
            .get("fileid")
            .or_else(|| node.get("id"))
            .map(|x| x.to_string());
        let mut meta = CloudFileMeta::new(name, size, path);
        if let Some(id) = id {
            meta = meta.with_remote_id(id);
        }
        out.push(meta);
    }
    if let Some(contents) = node.get("contents").and_then(|x| x.as_array()) {
        let next_prefix = if is_folder && !name.is_empty() {
            format!("{prefix}{name}/")
        } else {
            prefix.to_string()
        };
        for child in contents {
            collect_pcloud_metadata(child, &next_prefix, out);
            if out.len() >= MAX_CLOUD_LIST_LINES {
                break;
            }
        }
    }
}

fn field_u64(v: &Value, key: &str) -> u64 {
    v.get(key)
        .and_then(|x| x.as_u64())
        .or_else(|| v.get(key).and_then(|x| x.as_i64()).map(|n| n.max(0) as u64))
        .unwrap_or(0)
}

fn preview(s: &str, max: usize) -> String {
    let mut out: String = s.chars().take(max).collect();
    if s.chars().count() > max {
        out.push('…');
    }
    out
}

pub fn pcloud_result_code(body: &str) -> Option<i64> {
    serde_json::from_str::<Value>(body)
        .ok()?
        .get("result")?
        .as_i64()
}

#[cfg(test)]
mod tests {
    use crate::cloud::*;

    #[test]
    fn parse_result_code_ok() {
        assert_eq!(pcloud_result_code(r#"{"result":0,"auth":"x"}"#), Some(0));
        assert_eq!(pcloud_result_code(r#"{"result":2000}"#), Some(2000));
    }

    #[test]
    fn session_pack_unpack() {
        let s = pcloud_pack_session("eapi.pcloud.com", "tok");
        let (h, a) = pcloud_unpack_session(&s);
        assert_eq!(h, "eapi.pcloud.com");
        assert_eq!(a, "tok");
    }

    #[test]
    fn download_url_from_getfilelink_json() {
        let v: Value = serde_json::from_str(
            r#"{"result":0,"hosts":["p-def7.pcloud.com"],"path":"/abc/file.pdf"}"#,
        )
        .unwrap();
        assert_eq!(
            pcloud_download_url_from_link(&v).as_deref(),
            Some("https://p-def7.pcloud.com/abc/file.pdf")
        );
    }
}
