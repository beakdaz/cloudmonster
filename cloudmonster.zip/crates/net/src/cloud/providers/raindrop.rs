﻿use crate::cloud::common::{cloud_auth_error, inventory_from_account, run_checker, CloudFileMeta, CloudInventory};
use crate::cloud::config::CloudClientConfig;
use crate::cloud::curl_http::{build_url, CloudCurlSession};
use crate::cloud::CheckStartedHook;
use crate::cloud::CloudAccountStats;
use anyhow::{Context, Result};
use pma_core::Credential;
use reqwest::Client;
use std::path::{Path, PathBuf};

pub async fn check_account(
    cfg: &CloudClientConfig,
    cred: &Credential,
    output_dir: &Path,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(CloudAccountStats, Vec<PathBuf>)> {
    run_checker(cfg, cred, output_dir, on_check_started, |client, cred| {
        raindrop_inventory(cfg, client, cred)
    })
    .await
}

async fn raindrop_inventory(
    cfg: &CloudClientConfig,
    _client: Client,
    cred: Credential,
) -> Result<CloudInventory> {
    let email = cred.username.clone();
    let password = cred.password.clone();
    let mut curl = CloudCurlSession::new()?;
    let payload = serde_json::json!({
        "email": email,
        "password": password,
    });
    let (status, auth_json) = curl
        .post_json(
            cfg,
            "raindrop auth",
            "https://api.raindrop.io/v1/auth/email",
            &payload,
            &[],
        )
        .await
        .context("raindrop auth")?;
    if status == 401 {
        return Err(cloud_auth_error("invalid email or password"));
    }
    let token = auth_json
        .get("access_token")
        .and_then(|x| x.as_str())
        .ok_or_else(|| cloud_auth_error("missing access_token"))?;

    let mut metas: Vec<CloudFileMeta> = Vec::new();
    let mut page = 0u32;
    loop {
        let page_s = page.to_string();
        let url = build_url(
            "https://api.raindrop.io/v1/raindrops/0",
            &[("page", page_s.as_str()), ("perpage", "50")],
        )?;
        let auth = format!("Bearer {token}");
        let body = curl
            .get_json(cfg, "raindrop list", &url, &[("Authorization", auth.as_str())])
            .await;
        let Ok(body) = body else {
            break;
        };
        let Some(items) = body.get("items").and_then(|x| x.as_array()) else {
            break;
        };
        if items.is_empty() {
            break;
        }
        for item in items {
            let title = item
                .get("title")
                .and_then(|x| x.as_str())
                .unwrap_or("bookmark");
            metas.push(CloudFileMeta::new(title, 0, title));
        }
        if items.len() < 50 {
            break;
        }
        page += 1;
        if page > 200 {
            break;
        }
    }

    Ok(inventory_from_account(&email, metas, 0, 0, "Free"))
}
