//! Harvest + validate free proxy lists (ProxyScraper.exe parity).

use anyhow::{Context, Result};
use reqwest::Client;
use std::collections::HashSet;
use std::net::IpAddr;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

#[derive(Debug, Clone, serde::Serialize)]
pub struct ProxyScrapeResult {
    pub protocol: String,
    pub ip: String,
    pub port: u16,
    pub latency_ms: Option<u32>,
    pub status: String,
    pub endpoint: String,
}

impl ProxyScrapeResult {
    pub fn addr(&self) -> String {
        format!("{}:{}", self.ip, self.port)
    }

    pub fn line_with_protocol(&self) -> String {
        format!("{}://{}:{}", self.scheme(), self.ip, self.port)
    }

    pub fn line_host_port(&self) -> String {
        self.addr()
    }

    fn scheme(&self) -> &str {
        match self.protocol.as_str() {
            "socks4" => "socks4",
            "socks5" => "socks5",
            _ => "http",
        }
    }

    pub fn reqwest_proxy_url(&self) -> String {
        match self.protocol.as_str() {
            "socks4" => format!("socks4://{}:{}", self.ip, self.port),
            "socks5" => format!("socks5://{}:{}", self.ip, self.port),
            _ => format!("http://{}:{}", self.ip, self.port),
        }
    }
}

#[derive(Debug, Clone)]
pub struct ScrapeConfig {
    pub http: bool,
    pub socks4: bool,
    pub socks5: bool,
    pub workers: usize,
    pub timeout_secs: u64,
}

#[derive(Debug, Clone)]
pub enum ScrapeEvent {
    Status(String),
    Progress {
        harvested: u32,
        tested: u32,
        valid: u32,
        failed: u32,
        fraction: f32,
    },
    Valid(ProxyScrapeResult),
    Finished {
        avg_latency_ms: Option<f64>,
        elapsed_secs: f64,
    },
}

struct TestEndpoint {
    url: &'static str,
    json_key: Option<&'static str>,
}

const TEST_ENDPOINTS: [TestEndpoint; 3] = [
    TestEndpoint {
        url: "https://httpbin.org/ip",
        json_key: Some("origin"),
    },
    TestEndpoint {
        url: "https://api.ipify.org?format=json",
        json_key: Some("ip"),
    },
    TestEndpoint {
        url: "https://ifconfig.me/ip",
        json_key: None,
    },
];

fn sources(protocol: &str) -> &'static [&'static str] {
    match protocol {
        "http" => &[
            "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt",
            "https://raw.githubusercontent.com/Mohammedcha/ProxRipper/main/http.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
            "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/http_all.txt",
            "https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/http.txt",
            "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
        ],
        "socks4" => &[
            "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.txt",
            "https://raw.githubusercontent.com/Mohammedcha/ProxRipper/main/socks4.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
            "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/socks4_all.txt",
            "https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/sock4.txt",
            "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt",
        ],
        _ => &[
            "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt",
            "https://raw.githubusercontent.com/Mohammedcha/ProxRipper/main/socks5.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
            "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/socks5_all.txt",
            "https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/sock5.txt",
            "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",
        ],
    }
}

fn parse_proxy_line(line: &str, default_proto: &str) -> Option<(String, String, u16)> {
    let mut t = line.trim();
    if t.is_empty() || t.starts_with('#') {
        return None;
    }
    let mut proto = default_proto.to_string();
    if let Some((scheme, rest)) = t.split_once("://") {
        proto = scheme.to_ascii_lowercase();
        t = rest.trim();
    }
    let (host, port_str) = t.rsplit_once(':')?;
    let port: u16 = port_str.parse().ok()?;
    if port == 0 {
        return None;
    }
    let host = host.trim();
    if host.parse::<IpAddr>().is_err() && !host.contains('.') {
        return None;
    }
    Some((proto, host.to_string(), port))
}

async fn harvest_protocol(
    client: &Client,
    protocol: &str,
    cancel: &AtomicBool,
) -> Result<Vec<(String, String, u16)>> {
    let mut out = Vec::new();
    let mut seen = HashSet::new();
    for url in sources(protocol) {
        if cancel.load(Ordering::Relaxed) {
            break;
        }
        let Ok(resp) = client.get(*url).send().await else {
            continue;
        };
        let Ok(text) = resp.text().await else {
            continue;
        };
        for line in text.lines() {
            if let Some((proto, ip, port)) = parse_proxy_line(line, protocol) {
                let key = format!("{proto}|{ip}:{port}");
                if seen.insert(key) {
                    out.push((proto, ip, port));
                }
            }
        }
    }
    Ok(out)
}

async fn validate_one(
    proto: &str,
    ip: &str,
    port: u16,
    timeout: Duration,
) -> ProxyScrapeResult {
    let proxy_url = match proto {
        "socks4" => format!("socks4://{ip}:{port}"),
        "socks5" => format!("socks5://{ip}:{port}"),
        _ => format!("http://{ip}:{port}"),
    };
    let proxy = match reqwest::Proxy::all(&proxy_url) {
        Ok(p) => p,
        Err(e) => {
            return ProxyScrapeResult {
                protocol: proto.to_string(),
                ip: ip.to_string(),
                port,
                latency_ms: None,
                status: "proxy_error".to_string(),
                endpoint: e.to_string(),
            };
        }
    };
    let client = match Client::builder()
        .proxy(proxy)
        .timeout(timeout)
        .connect_timeout(timeout)
        .danger_accept_invalid_certs(true)
        .build()
    {
        Ok(c) => c,
        Err(e) => {
            return ProxyScrapeResult {
                protocol: proto.to_string(),
                ip: ip.to_string(),
                port,
                latency_ms: None,
                status: "proxy_error".to_string(),
                endpoint: e.to_string(),
            };
        }
    };

    for ep in TEST_ENDPOINTS {
        let start = Instant::now();
        let resp = client.get(ep.url).send().await;
        let Ok(resp) = resp else {
            continue;
        };
        let status = resp.status();
        if !status.is_success() {
            continue;
        }
        let Ok(body) = resp.text().await else {
            continue;
        };
        let ok = match ep.json_key {
            Some(key) => body.contains(key),
            None => {
                let trimmed = body.trim();
                !trimmed.is_empty() && trimmed.len() < 64
            }
        };
        if ok {
            let ms = start.elapsed().as_millis().min(u128::from(u32::MAX)) as u32;
            return ProxyScrapeResult {
                protocol: proto.to_string(),
                ip: ip.to_string(),
                port,
                latency_ms: Some(ms),
                status: status.as_str().to_string(),
                endpoint: ep.url.to_string(),
            };
        }
    }

    ProxyScrapeResult {
        protocol: proto.to_string(),
        ip: ip.to_string(),
        port,
        latency_ms: None,
        status: "no_endpoint_passed".to_string(),
        endpoint: String::new(),
    }
}

fn is_valid_result(r: &ProxyScrapeResult) -> bool {
    r.latency_ms.is_some()
}

fn tasks_to_proxy_urls(tasks: &[(String, String, u16)]) -> Vec<String> {
    tasks
        .iter()
        .map(|(proto, ip, port)| match proto.as_str() {
            "socks5" => format!("socks5://{ip}:{port}"),
            "socks4" => format!("socks4://{ip}:{port}"),
            _ => format!("http://{ip}:{port}"),
        })
        .collect()
}

#[derive(Debug, Clone)]
pub enum ParseHarvestEvent {
    Status(String),
    Done {
        count: usize,
        proxies: Vec<String>,
    },
}

/// Download public lists and parse lines — no proxy validation (parse-only).
pub fn run_parse_harvest_blocking(
    protocol: &str,
    cancel: Arc<AtomicBool>,
    tx: std::sync::mpsc::Sender<ParseHarvestEvent>,
) -> Result<()> {
    let _ = tx.send(ParseHarvestEvent::Status(format!(
        "parse {protocol} — loading lists…"
    )));
    let rt = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(4)
        .enable_all()
        .build()
        .context("tokio runtime")?;
    let harvest_client = Client::builder()
        .timeout(Duration::from_secs(30))
        .user_agent("Mozilla/5.0 (compatible; CloudMonster-ProxyParse/1.0)")
        .build()
        .context("harvest client")?;
    let tasks = rt.block_on(harvest_protocol(&harvest_client, protocol, &cancel))?;
    if cancel.load(Ordering::Relaxed) {
        let _ = tx.send(ParseHarvestEvent::Status("cancelled".to_string()));
        return Ok(());
    }
    let proxies = tasks_to_proxy_urls(&tasks);
    let count = proxies.len();
    let _ = tx.send(ParseHarvestEvent::Done { count, proxies });
    let _ = tx.send(ParseHarvestEvent::Status(format!(
        "parse done — {count} {protocol} proxies (no check)"
    )));
    Ok(())
}

/// Blocking scrape run — call from a dedicated std thread.
pub fn run_scrape_blocking(
    config: ScrapeConfig,
    cancel: Arc<AtomicBool>,
    tx: std::sync::mpsc::Sender<ScrapeEvent>,
) -> Result<()> {
    let started = Instant::now();
    let _ = tx.send(ScrapeEvent::Status(
        "harvesting sources...".to_string(),
    ));

    let rt = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(config.workers.clamp(1, 64))
        .enable_all()
        .build()
        .context("tokio runtime")?;

    let harvest_client = Client::builder()
        .timeout(Duration::from_secs(30))
        .user_agent("Mozilla/5.0 (compatible; CloudMonster-ProxyScraper/1.0)")
        .build()
        .context("harvest client")?;

    let mut tasks: Vec<(String, String, u16)> = Vec::new();
    if config.http {
        tasks.extend(rt.block_on(harvest_protocol(&harvest_client, "http", &cancel))?);
    }
    if config.socks4 {
        tasks.extend(rt.block_on(harvest_protocol(
            &harvest_client,
            "socks4",
            &cancel,
        ))?);
    }
    if config.socks5 {
        tasks.extend(rt.block_on(harvest_protocol(
            &harvest_client,
            "socks5",
            &cancel,
        ))?);
    }

    let harvested = tasks.len() as u32;
    if cancel.load(Ordering::Relaxed) {
        let _ = tx.send(ScrapeEvent::Status("cancelled".to_string()));
        return Ok(());
    }

    let _ = tx.send(ScrapeEvent::Progress {
        harvested,
        tested: 0,
        valid: 0,
        failed: 0,
        fraction: 0.0,
    });
    let _ = tx.send(ScrapeEvent::Status(format!(
        "harvested {harvested} · validating..."
    )));

    if tasks.is_empty() {
        let _ = tx.send(ScrapeEvent::Finished {
            avg_latency_ms: None,
            elapsed_secs: started.elapsed().as_secs_f64(),
        });
        let _ = tx.send(ScrapeEvent::Status(
            "done — no proxies harvested".to_string(),
        ));
        return Ok(());
    }

    let timeout = Duration::from_secs(config.timeout_secs.max(1));
    let workers = config.workers.max(1);
    let total = tasks.len();
    let mut tested = 0u32;
    let mut valid = 0u32;
    let mut failed = 0u32;
    let mut latency_sum = 0u64;
    let mut latency_n = 0u32;

    for chunk in tasks.chunks(workers) {
        if cancel.load(Ordering::Relaxed) {
            let _ = tx.send(ScrapeEvent::Status("cancelled".to_string()));
            return Ok(());
        }
        let mut handles = Vec::with_capacity(chunk.len());
        for (proto, ip, port) in chunk {
            let proto = proto.clone();
            let ip = ip.clone();
            let port = *port;
            handles.push(rt.spawn(async move {
                validate_one(&proto, &ip, port, timeout).await
            }));
        }
        for handle in handles {
            if cancel.load(Ordering::Relaxed) {
                break;
            }
            let Ok(result) = rt.block_on(handle) else {
                continue;
            };
            tested += 1;
            if is_valid_result(&result) {
                valid += 1;
                if let Some(ms) = result.latency_ms {
                    latency_sum += u64::from(ms);
                    latency_n += 1;
                }
                let _ = tx.send(ScrapeEvent::Valid(result));
            } else {
                failed += 1;
            }
            let fraction = tested as f32 / total as f32;
            let _ = tx.send(ScrapeEvent::Progress {
                harvested,
                tested,
                valid,
                failed,
                fraction,
            });
        }
    }

    let avg = if latency_n > 0 {
        Some(latency_sum as f64 / f64::from(latency_n))
    } else {
        None
    };
    let elapsed = started.elapsed().as_secs_f64();
    let pct = if tested > 0 {
        (f64::from(valid) / f64::from(tested)) * 100.0
    } else {
        0.0
    };
    let _ = tx.send(ScrapeEvent::Status(format!(
        "done in {elapsed:.1}s · {valid}/{tested} valid ({pct:.0}%)"
    )));
    let _ = tx.send(ScrapeEvent::Finished {
        avg_latency_ms: avg,
        elapsed_secs: elapsed,
    });
    Ok(())
}

pub fn export_lines(results: &[ProxyScrapeResult], with_protocol: bool) -> Vec<String> {
    results
        .iter()
        .filter(|r| is_valid_result(r))
        .map(|r| {
            if with_protocol {
                r.line_with_protocol()
            } else {
                r.line_host_port()
            }
        })
        .collect()
}

pub fn write_export_txt(path: &std::path::Path, lines: &[String]) -> Result<()> {
    std::fs::write(path, lines.join("\n")).context("write txt export")?;
    Ok(())
}

pub fn write_export_json(path: &std::path::Path, results: &[ProxyScrapeResult]) -> Result<()> {
    let valid: Vec<_> = results
        .iter()
        .filter(|r| is_valid_result(r))
        .collect();
    let json = serde_json::to_string_pretty(&valid).context("json export")?;
    std::fs::write(path, json).context("write json export")?;
    Ok(())
}

pub fn write_export_csv(path: &std::path::Path, results: &[ProxyScrapeResult]) -> Result<()> {
    let mut w = String::from("protocol,address,latency_ms,status,endpoint\n");
    for r in results.iter().filter(|r| is_valid_result(r)) {
        let lat = r.latency_ms.map(|v| v.to_string()).unwrap_or_else(|| "—".to_string());
        w.push_str(&format!(
            "{},{},{},{},{}\n",
            r.protocol,
            r.addr(),
            lat,
            csv_escape(&r.status),
            csv_escape(&r.endpoint),
        ));
    }
    std::fs::write(path, w).context("write csv export")?;
    Ok(())
}

fn csv_escape(s: &str) -> String {
    if s.contains(',') || s.contains('"') {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_string()
    }
}
