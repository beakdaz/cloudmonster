//! FortiGate / Fortinet SSL-VPN client: logincheck, API status, optional config backup.

use anyhow::{bail, Context, Result};
use crate::http_client::apply_proxy;
use pma_core::{fortinet_appliance_base, is_excluded_media_filename, output_file_path, Credential};
use reqwest::{Client, StatusCode, Url};
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::debug;

#[derive(Debug, Clone)]
pub struct FortinetClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
    pub proxy: Option<String>,
}

impl Default for FortinetClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
            proxy: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct FortinetAccountStats {
    pub username: String,
    pub auth_method: String,
    pub hostname: String,
    pub model: String,
    pub version: String,
    pub downloaded: usize,
    pub bytes: u64,
}

impl FortinetAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "auth={} user={} host={} model={} ver={} files={} ({})",
            self.auth_method,
            self.username,
            self.hostname,
            self.model,
            self.version,
            self.downloaded,
            format_bytes(self.bytes),
        )
    }
}

pub(crate) struct FortinetSession {
    auth_method: String,
    csrf: Option<String>,
}

pub struct FortinetClient {
    http: Client,
    base: Url,
    username: String,
    password: String,
}

impl FortinetClient {
    pub fn new(
        base: Url,
        username: &str,
        password: &str,
        config: &FortinetClientConfig,
    ) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(8))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-fortinet/0.1");
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        builder = apply_proxy(builder, config.proxy.as_deref())?;
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            base,
            username: username.to_string(),
            password: password.to_string(),
        })
    }

    pub async fn detect(&self) -> Result<bool> {
        if page_looks_like_fortinet(&self.fetch_root_body().await?) {
            return Ok(true);
        }
        let login = self
            .base
            .join("login")
            .context("login url")?
            .to_string();
        if let Ok(body) = self.fetch_text(&login).await {
            if page_looks_like_fortinet(&body) {
                return Ok(true);
            }
        }
        let remote = self
            .base
            .join("remote/login")
            .context("remote login url")?
            .to_string();
        if let Ok(body) = self.fetch_text(&remote).await {
            if page_looks_like_fortinet(&body) {
                return Ok(true);
            }
        }
        Ok(false)
    }

    async fn fetch_root_body(&self) -> Result<String> {
        self.fetch_text(self.base.as_str()).await
    }

    async fn fetch_text(&self, url: &str) -> Result<String> {
        Ok(self
            .http
            .get(url)
            .send()
            .await
            .context("GET")?
            .text()
            .await
            .unwrap_or_default())
    }

    pub async fn authenticate(&self) -> Result<FortinetSession> {
        if let Some(session) = self.try_admin_logincheck().await? {
            return Ok(session);
        }
        if let Some(session) = self.try_api_v2_auth().await? {
            return Ok(session);
        }
        if let Some(session) = self.try_remote_logincheck().await? {
            return Ok(session);
        }
        bail!("Fortinet login failed (invalid admin/VPN credentials or unsupported portal)")
    }

    async fn try_admin_logincheck(&self) -> Result<Option<FortinetSession>> {
        let url = self.base.join("logincheck").context("logincheck url")?;
        let form = [
            ("username", self.username.as_str()),
            ("secretkey", self.password.as_str()),
            ("ajax", "1"),
        ];
        let resp = self
            .http
            .post(url)
            .form(&form)
            .send()
            .await
            .context("logincheck POST")?;
        let csrf = csrf_from_headers(resp.headers());
        let body = resp.text().await.unwrap_or_default();
        if !logincheck_body_ok(&body) {
            debug!(body = %body.chars().take(80).collect::<String>(), "logincheck failed");
            return Ok(None);
        }
        if self.monitor_status_ok().await? {
            return Ok(Some(FortinetSession {
                auth_method: "admin".into(),
                csrf,
            }));
        }
        Ok(None)
    }

    async fn try_api_v2_auth(&self) -> Result<Option<FortinetSession>> {
        let url = self
            .base
            .join("api/v2/authentication")
            .context("api auth url")?;
        let body = serde_json::json!({
            "username": self.username,
            "secretkey": self.password,
        });
        let resp = self.http.post(url).json(&body).send().await?;
        if !resp.status().is_success() {
            return Ok(None);
        }
        let csrf = csrf_from_headers(resp.headers());
        if self.monitor_status_ok().await? {
            return Ok(Some(FortinetSession {
                auth_method: "api_v2".into(),
                csrf,
            }));
        }
        Ok(None)
    }

    async fn try_remote_logincheck(&self) -> Result<Option<FortinetSession>> {
        let url = self
            .base
            .join("remote/logincheck")
            .context("remote logincheck url")?;
        let form = [
            ("ajax", "1"),
            ("username", self.username.as_str()),
            ("credential", self.password.as_str()),
        ];
        let resp = self.http.post(url).form(&form).send().await?;
        let csrf = csrf_from_headers(resp.headers());
        let body = resp.text().await.unwrap_or_default();
        if !logincheck_body_ok(&body) {
            return Ok(None);
        }
        Ok(Some(FortinetSession {
            auth_method: "sslvpn".into(),
            csrf,
        }))
    }

    async fn monitor_status_ok(&self) -> Result<bool> {
        let url = self
            .base
            .join("api/v2/monitor/system/status")
            .context("status url")?;
        let resp = self.http.get(url).send().await?;
        if resp.status() != StatusCode::OK {
            return Ok(false);
        }
        let v: Value = resp.json().await.unwrap_or(Value::Null);
        Ok(v.get("results").is_some() || v.get("status").is_some() || v.get("version").is_some())
    }

    pub async fn system_status(&self) -> Result<Value> {
        let url = self
            .base
            .join("api/v2/monitor/system/status")
            .context("status url")?;
        let resp = self.http.get(url).send().await?;
        if resp.status() != StatusCode::OK {
            bail!("Fortinet status API HTTP {}", resp.status());
        }
        Ok(resp.json().await.unwrap_or(Value::Null))
    }

    pub async fn download_config_backup(
        &self,
        session: &FortinetSession,
        dest: &Path,
    ) -> Result<(PathBuf, u64)> {
        let url = self
            .base
            .join("api/v2/monitor/system/config/backup?scope=global")
            .context("backup url")?;
        let mut req = self.http.get(url);
        if let Some(ref csrf) = session.csrf {
            req = req.header("X-CSRFTOKEN", csrf.as_str());
        }
        let resp = req.send().await?;
        if resp.status() != StatusCode::OK {
            bail!("config backup HTTP {}", resp.status());
        }
        let bytes = resp.bytes().await?.to_vec();
        if bytes.is_empty() {
            bail!("empty config backup");
        }
        if let Some(parent) = dest.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut f = fs::File::create(dest).await?;
        f.write_all(&bytes).await?;
        Ok((dest.to_path_buf(), bytes.len() as u64))
    }
}

fn page_looks_like_fortinet(body: &str) -> bool {
    let lower = body.to_ascii_lowercase();
    lower.contains("fortigate")
        || lower.contains("fortios")
        || lower.contains("fortinet")
        || lower.contains("forticloud")
        || lower.contains("/remote/login")
        || lower.contains("logincheck")
}

fn logincheck_body_ok(body: &str) -> bool {
    let t = body.trim();
    t == "1"
        || t.starts_with("1\n")
        || t.contains("ret=1")
        || t.contains("\"ret\":\"1\"")
        || t.contains("\"status\":\"success\"")
}

fn csrf_from_headers(headers: &reqwest::header::HeaderMap) -> Option<String> {
    for value in headers.get_all("set-cookie") {
        let Ok(s) = value.to_str() else {
            continue;
        };
        let lower = s.to_ascii_lowercase();
        if !lower.starts_with("ccsrftoken=") {
            continue;
        }
        let token = s
            .split(';')
            .next()
            .unwrap_or(s)
            .trim_start_matches("ccsrftoken=")
            .trim_matches('"');
        if !token.is_empty() {
            return Some(token.to_string());
        }
    }
    None
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

fn status_fields(status: &Value) -> (String, String, String) {
    let results = status.get("results").unwrap_or(status);
    let hostname = results
        .get("hostname")
        .or_else(|| results.get("host_name"))
        .and_then(|v| v.as_str())
        .unwrap_or("-")
        .to_string();
    let model = results
        .get("model")
        .or_else(|| results.get("model_name"))
        .and_then(|v| v.as_str())
        .unwrap_or("-")
        .to_string();
    let version = results
        .get("version")
        .or_else(|| results.get("firmware_version"))
        .and_then(|v| v.as_str())
        .unwrap_or("-")
        .to_string();
    (hostname, model, version)
}

pub async fn download_fortinet_account(
    cred: &Credential,
    config: &FortinetClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(FortinetAccountStats, Vec<PathBuf>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_fortinet_account_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_fortinet_account_once(
    cred: Credential,
    config: &FortinetClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(FortinetAccountStats, Vec<PathBuf>)> {
    let base = fortinet_appliance_base(&cred.url)?;
    let client = FortinetClient::new(base, &cred.username, &cred.password, config)?;
    if !client.detect().await? {
        bail!(
            "{} is not a Fortinet/FortiGate portal",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let session = client
        .authenticate()
        .await
        .with_context(|| format!("Fortinet login failed for {}", cred.display_line()))?;

    let (hostname, model, version) = match client.system_status().await {
        Ok(st) => status_fields(&st),
        Err(_) => ("-".into(), "-".into(), "-".into()),
    };

    if !download_files {
        return Ok((
            FortinetAccountStats {
                username: cred.username.clone(),
                auth_method: session.auth_method.clone(),
                hostname,
                model,
                version,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "fortinet");
    fs::create_dir_all(&site_dir).await?;
    let prefix = cred.account_file_prefix();
    let rel = format!("{prefix}__config_backup.conf");
    let path = output_file_path(&site_dir, &rel);
    if is_excluded_media_filename(path.file_name().and_then(|n| n.to_str()).unwrap_or("")) {
        bail!("excluded filename");
    }

    let mut written = Vec::new();
    let mut total_bytes = 0u64;
    match client.download_config_backup(&session, &path).await {
        Ok((p, n)) => {
            total_bytes = n;
            written.push(p);
        }
        Err(err) => {
            debug!(%err, "config backup skipped (SSL-VPN or insufficient rights)");
        }
    }

    Ok((
        FortinetAccountStats {
            username: cred.username.clone(),
            auth_method: session.auth_method.clone(),
            hostname,
            model,
            version,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}
