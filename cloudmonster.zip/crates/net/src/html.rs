// Source: C# PhpMyAdminClient HTML/token parsing from project_final/_tzYCdx01jabRi9YINoZruASmPDF.cs

use regex::Regex;
use std::sync::LazyLock;

static TOKEN_RE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#"name="token"\s+value="([^"]+)""#).unwrap());

static TOKEN_RE_ALT: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#"name='token'\s+value='([^']+)'"#).unwrap());

static TOKEN_RE_VALUE_FIRST: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#"value="([^"]+)"\s+name="token""#).unwrap());

static TOKEN_RE_VALUE_FIRST_ALT: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"value='([^']+)'\s+name='token'"#).unwrap()
});

static TOKEN_JSON_RE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#""token"\s*:\s*"([^"]+)""#).unwrap());

static TOKEN_JSON_BARE_RE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#"token\s*:\s*"([^"]+)""#).unwrap());

static SESSION_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"name="set_session"\s+value="([^"]+)""#).unwrap()
});

static DB_LINK_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"db=([a-zA-Z0-9_$-]+)"#).unwrap()
});

static DB_SELECT_ESC_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"<option value=\\"([^\\"]+)\\""#).unwrap()
});

static DB_SELECT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"<option value="([^"]+)""#).unwrap()
});

static DB_SELECT_BLOCK_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<select[^>]*name=["']db_select\[\]["'][^>]*>(.*?)</select>"#).unwrap()
});

static REFRESH_URL_RE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r#"(?i)url=(https?://[^;\s]+)"#).unwrap());

pub fn decode_html_entities(input: &str) -> String {
    input
        .replace("&quot;", "\"")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&#39;", "'")
}

pub fn extract_token(html: &str) -> Option<String> {
    let decoded = decode_html_entities(html);
    TOKEN_RE
        .captures(&decoded)
        .or_else(|| TOKEN_RE_ALT.captures(&decoded))
        .or_else(|| TOKEN_RE_VALUE_FIRST.captures(&decoded))
        .or_else(|| TOKEN_RE_VALUE_FIRST_ALT.captures(&decoded))
        .or_else(|| TOKEN_JSON_RE.captures(&decoded))
        .or_else(|| TOKEN_JSON_BARE_RE.captures(&decoded))
        .and_then(|caps| caps.get(1).map(|m| m.as_str().to_string()))
}

pub fn extract_set_session(html: &str) -> Option<String> {
    SESSION_RE
        .captures(html)
        .and_then(|caps| caps.get(1).map(|m| m.as_str().to_string()))
}

pub fn looks_like_adminer(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    if !lower.contains("adminer") {
        return false;
    }
    lower.contains("auth[username]")
        || lower.contains("name=\"auth[username]\"")
        || lower.contains("name='auth[username]'")
        || lower.contains("adminer.org")
        || (lower.contains("logout") && (lower.contains("?db=") || lower.contains("&db=")))
}

pub fn looks_like_phpmyadmin(html: &str) -> bool {
    html.contains("<title>phpMyAdmin") || {
        let lower = html.to_ascii_lowercase();
        lower.contains("phpmyadmin")
            || lower.contains("pma_username")
            || lower.contains("name=\"token\"")
    }
}

pub fn is_login_page(html: &str) -> bool {
    if html.contains("id='loginform'")
        || html.contains("id=\"loginform\"")
        || html.contains("id=loginform")
        || html.contains("body id=loginform")
    {
        return true;
    }
    if html.contains("logged_in:false")
        || html.contains("logged_in: false")
        || html.contains("\"logged_in\":false")
    {
        return true;
    }
    let lower = html.to_ascii_lowercase();
    lower.contains("welcome to")
        && lower.contains("phpmyadmin")
        && lower.contains("pma_username")
        && lower.contains("pma_password")
        && !lower.contains("pma_navigation")
}

pub fn appears_logged_in(html: &str) -> bool {
    if is_login_page(html) {
        return false;
    }
    html.contains("logged_in:true")
        || html.contains("logged_in: true")
        || html.contains("\"logged_in\":true")
        || html.contains("'logged_in':true")
}

pub fn is_sql_dump(content: &str) -> bool {
    if is_login_page(content) {
        return false;
    }
    let trimmed = content.trim_start();
    if trimmed.starts_with("<!DOCTYPE") || trimmed.starts_with("<html") {
        return false;
    }
    let lower = content.to_ascii_lowercase();
    lower.contains("create table")
        || lower.contains("insert into")
        || lower.contains("create database")
        || lower.contains("-- phpmyadmin sql dump")
}

pub fn login_succeeded(html: &str, final_url: &str) -> bool {
    if is_login_page(html) {
        return false;
    }

    let lower = html.to_ascii_lowercase();
    let url_lower = final_url.to_ascii_lowercase();

    if url_lower.contains("main.php") || url_lower.contains("navigation.php") {
        return true;
    }

    if url_lower.contains("index.php?route=") && !url_lower.contains("route=/") {
        // generic route after login, not export/login routes only
    }

    lower.contains("id=\"pma_navigation\"")
        || lower.contains("navigation tree")
        || appears_logged_in(html)
}

pub fn login_failed(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("cannot log in")
        || lower.contains("access denied")
        || lower.contains("the server is not responding")
        || lower.contains("login without a password is forbidden")
        || lower.contains("mysqli_real_connect")
        || lower.contains("wrong username/password")
}

pub fn is_captcha_or_cloudflare(html: &str) -> bool {
    html.contains("Missing reCAPTCHA verification")
        || html.contains("<title>Just a moment...</title>")
}

pub fn uses_route_export(html: &str) -> bool {
    html.contains("route=/server/export")
        || html.contains("route=/database/structure")
        || html.contains("index.php?route=/")
        || html.contains("version:\"5.")
        || html.contains("version: \"5.")
}

pub fn is_plausible_database_name(name: &str) -> bool {
    if name.is_empty() || name.len() > 64 {
        return false;
    }
    if name.chars().all(|c| c.is_ascii_digit()) {
        return false;
    }
    let upper = name.to_ascii_uppercase();
    const BLOCKLIST: &[&str] = &[
        "ANSI", "DB2", "MAXDB", "MSSQL", "MYSQL323", "MYSQL40", "ORACLE", "INSERT", "REPLACE",
        "UPDATE", "NONE", "TRADITIONAL", "COMPLETE", "CSV", "EXCEL", "GZIP", "BOTH", "DATA",
        "EXTENDED", "CUSTOM", "CUSTOM-NO-FORM", "SHIFT_JIS", "SJIS", "SJIS-WIN", "BIG5",
        "GB2312", "EUC-JP", "HTMLWORD", "HTMLEXCEL", "CODEGEN", "QUICK", "STRUCTURE",
        "STRUCTURE_AND_DATA", "SENDIT", "TEXT", "SQL", "INTERNAL", "INFORMATION_SCHEMA",
        "PERFORMANCE_SCHEMA", "MYSQL", "SYS", "PHPMYADMIN",
    ];
    if BLOCKLIST.contains(&upper.as_str()) {
        return false;
    }
    if upper.starts_with("ISO-8859-") {
        return false;
    }
    true
}

pub fn extract_refresh_url(refresh_header: &str) -> Option<String> {
    REFRESH_URL_RE
        .captures(refresh_header)
        .and_then(|caps| caps.get(1).map(|m| m.as_str().to_string()))
}

pub fn has_pma_auth_cookie(cookie_pairs: &[(String, String)]) -> bool {
    cookie_pairs.iter().any(|(name, value)| {
        name.starts_with("pmaAuth") || (name == "pmaPass" && value != "deleted")
    })
}

pub fn extract_databases(html: &str) -> Vec<String> {
    if is_login_page(html) {
        return Vec::new();
    }

    let mut dbs = extract_db_select_options(html);
    if dbs.is_empty() {
        dbs = DB_LINK_RE
            .captures_iter(html)
            .filter_map(|caps| caps.get(1).map(|m| m.as_str().to_string()))
            .filter(|db| is_plausible_database_name(db) && !is_system_db(db))
            .collect();
    }

    dbs.sort();
    dbs.dedup();
    dbs
}

fn extract_options_from_select_block(block: &str) -> Vec<String> {
    let mut dbs: Vec<String> = DB_SELECT_ESC_RE
        .captures_iter(block)
        .filter_map(|caps| caps.get(1).map(|m| m.as_str().to_string()))
        .filter(|db| is_plausible_database_name(db) && !is_system_db(db))
        .collect();

    if dbs.is_empty() {
        dbs = DB_SELECT_RE
            .captures_iter(block)
            .filter_map(|caps| caps.get(1).map(|m| m.as_str().to_string()))
            .filter(|db| is_plausible_database_name(db) && !is_system_db(db))
            .collect();
    }

    dbs
}

pub fn extract_db_select_options(html: &str) -> Vec<String> {
    let mut dbs = DB_SELECT_BLOCK_RE
        .captures(html)
        .and_then(|caps| caps.get(1).map(|m| m.as_str()))
        .map(extract_options_from_select_block)
        .unwrap_or_default();

    if dbs.is_empty() {
        dbs = extract_options_from_select_block(html);
    }

    dbs.sort();
    dbs.dedup();
    dbs
}

fn is_system_db(name: &str) -> bool {
    matches!(
        name,
        "information_schema" | "mysql" | "performance_schema" | "sys" | "phpmyadmin"
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_login_token() {
        let html = r#"<input type="hidden" name="token" value="abc123" />"#;
        assert_eq!(extract_token(html), Some("abc123".into()));
    }

    #[test]
    fn extracts_json_token() {
        let html = r#"{"token":"json-token","success":true}"#;
        assert_eq!(extract_token(html), Some("json-token".into()));
    }

    #[test]
    fn detects_failed_login_message() {
        assert!(login_failed("Cannot log in to the MySQL server"));
    }

    #[test]
    fn detects_captcha() {
        assert!(is_captcha_or_cloudflare("Missing reCAPTCHA verification"));
    }

    #[test]
    fn detects_login_page_html() {
        assert!(is_login_page("<body id='loginform'><input name=\"pma_username\">"));
        assert!(!is_sql_dump("<body id='loginform'>"));
    }

    #[test]
    fn detects_sql_dump() {
        assert!(is_sql_dump("CREATE TABLE users (id INT);"));
        assert!(is_sql_dump("-- phpMyAdmin SQL Dump\nINSERT INTO t VALUES (1);"));
    }

    #[test]
    fn extracts_db_select() {
        let html = r#"<select name="db_select[]"><option value="appdb">app</option></select>"#;
        assert_eq!(extract_db_select_options(html), vec!["appdb".to_string()]);
    }
}
