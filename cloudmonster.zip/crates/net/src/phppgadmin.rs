//! phpPgAdmin / pgAdmin4 web UI: login and export PostgreSQL SQL dumps.

use anyhow::{bail, Context, Result};
use crate::html::extract_db_select_options;
use crate::http_client::apply_proxy;
use pma_core::{output_file_path, Credential};
use regex::Regex;
use reqwest::{Client, Url};
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::Duration;
use tracing::{debug, warn};

// #region agent log
fn phppgadmin_debug(hypothesis_id: &str, location: &str, message: &str, data: serde_json::Value) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let line = serde_json::json!({
        "sessionId": "be3b27",
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0),
        "runId": "phppgadmin-export"
    });
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}

fn host_only(url: &Url) -> String {
    url.host_str().unwrap_or("unknown").to_string()
}
// #endregion

static DB_TARGET_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)subject=database(?:&amp;|&)[^"'<>]*server=([^"'&<>]+)(?:&amp;|&)[^"'<>]*database=([^"'&<>]+)"#,
    )
    .unwrap()
});

static DB_TARGET_LOOSE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)server=([^"'&<>\s#]+)[^"'<>]*database=([^"'&<>\s#]+)"#).unwrap()
});

static DB_TARGET_REV_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)database=([^"'&<>\s#]+)[^"'<>]*server=([^"'&<>\s#]+)"#).unwrap()
});

static DB_REDIRECT_HREF_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)redirect\.php\?[^"'<>]*subject=database[^"'<>]*server=([^"'&<>\s#]+)[^"'<>]*database=([^"'&<>\s#]+)"#,
    )
    .unwrap()
});

static SERVER_LINK_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)subject=server(?:&amp;|&)[^"'<>]*server=([^"'&<>\s#]+)"#).unwrap()
});

static LOGIN_PASSWORD_FIELD_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*type\s*=\s*["']password["'][^>]*name\s*=\s*["']([^"']+)["']"#,
    )
    .unwrap()
});

static LOGIN_PASSWORD_FIELD_REV_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*name\s*=\s*["'](loginPassword[^"']*)["'][^>]*type\s*=\s*["']password["']"#,
    )
    .unwrap()
});

static HIDDEN_INPUT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*type\s*=\s*["']hidden["'][^>]*name\s*=\s*["']([^"']+)["'][^>]*value\s*=\s*["']([^"']*)["']"#,
    )
    .unwrap()
});

static HIDDEN_INPUT_ALT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*name\s*=\s*["']([^"']+)["'][^>]*type\s*=\s*["']hidden["'][^>]*value\s*=\s*["']([^"']*)["']"#,
    )
    .unwrap()
});

static LOGIN_PASSWORD_NAME_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*name\s*=\s*["'](loginPassword[^"']*)["'][^>]*type\s*=\s*["']password["']"#,
    )
    .unwrap()
});

static LOGIN_PASSWORD_NAME_ALT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*type\s*=\s*["']password["'][^>]*name\s*=\s*["'](loginPassword[^"']*)["']"#,
    )
    .unwrap()
});

static LOGIN_SUBMIT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*type\s*=\s*["']submit["'][^>]*name\s*=\s*["']([^"']+)["'][^>]*value\s*=\s*["']([^"']*)["']"#,
    )
    .unwrap()
});

static LOGIN_FORM_ACTION_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)<form[^>]*action\s*=\s*["']([^"']*)["']"#).unwrap()
});

static SERVER_LOGIN_HREF_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)href\s*=\s*["'](redirect\.php\?subject=server[^"']*)["']"#).unwrap()
});

static SERVERS_USER_ROW_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?is)<tr[^>]*class\s*=\s*["']data\d+["'][^>]*>.*?<td>\s*\d+\s*</td>\s*<td>\s*[^<\s][^<]*\s*</td>"#,
    )
    .unwrap()
});

static PGADMIN4_CSRF_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#""csrfToken"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)""#).unwrap()
});

static PGADMIN4_LOGIN_URL_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#""loginUrl"\s*:\s*"([^"]+)""#).unwrap()
});

#[derive(Debug, Clone)]
pub struct PhpPgAdminClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
    /// HTTP(S) or SOCKS5 proxy, e.g. `socks5://127.0.0.1:1080`
    pub proxy: Option<String>,
}

impl Default for PhpPgAdminClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(120),
            insecure: false,
            proxy: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct PhpPgAdminAccountStats {
    pub username: String,
    pub backend: &'static str,
    pub databases: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl PhpPgAdminAccountStats {
    pub fn detail_line(&self) -> String {
        let downloaded = crate::stats_display::file_count(self.downloaded, self.databases);
        format!(
            "user={} backend={} databases={} downloaded={downloaded} ({})",
            self.username,
            self.backend,
            self.databases,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
struct DbTarget {
    server: String,
    database: String,
    /// pgAdmin4 browser database node id (required for backup API).
    pgadmin_db_id: Option<String>,
}

#[derive(PartialEq, Eq)]
enum BackendKind {
    PhpPgAdmin,
    PgAdmin4,
}

struct PhpPgAdminClient {
    http: Client,
    app_root: Url,
    auth_entry: Url,
    backend: BackendKind,
    username: String,
    password: String,
    pgadmin_csrf: Option<String>,
    request_timeout: Duration,
}

impl PhpPgAdminClient {
    fn new(cred: &Credential, config: &PhpPgAdminClientConfig) -> Result<Self> {
        let http = apply_proxy(
            Client::builder()
                .cookie_store(true)
                .timeout(config.timeout)
                .connect_timeout(Duration::from_secs(20))
                .danger_accept_invalid_certs(config.insecure)
                .redirect(reqwest::redirect::Policy::limited(12))
                .user_agent(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 \
                 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                ),
            config.proxy.as_deref(),
        )?
        .build()
        .context("build HTTP client")?;

        let path = cred.url.path().to_ascii_lowercase();
        if path.contains("pgadmin3") {
            bail!(
                "pgAdmin3 is not supported (use phpPgAdmin URL ending in /phppgadmin/redirect.php)"
            );
        }
        let backend = if path.contains("phppgadmin") {
            BackendKind::PhpPgAdmin
        } else if path.contains("pgadmin4") || path.contains("/pgadmin/") {
            BackendKind::PgAdmin4
        } else {
            BackendKind::PhpPgAdmin
        };

        let (app_root, auth_entry) = match backend {
            BackendKind::PgAdmin4 => pgadmin4_roots(&cred.url)?,
            BackendKind::PhpPgAdmin => phppgadmin_roots(&cred.url)?,
        };

        Ok(Self {
            http,
            app_root,
            auth_entry,
            backend,
            username: cred.username.clone(),
            password: cred.password.clone(),
            pgadmin_csrf: None,
            request_timeout: config.timeout,
        })
    }

    async fn run(
        &mut self,
        output_dir: &Path,
        download_files: bool,
    ) -> Result<(PhpPgAdminAccountStats, Vec<(String, PathBuf, u64)>)> {
        self.authenticate().await?;
        let mut targets = self.list_databases().await?;
        if targets.is_empty() {
            targets = self.probe_database_targets().await;
        }
        // #region agent log
        phppgadmin_debug(
            "P2",
            "phppgadmin.rs:run:after_list",
            "database targets",
            serde_json::json!({
                "host": host_only(&self.app_root),
                "backend": backend_label(&self.backend),
                "db_count": targets.len(),
                "download_files": download_files,
            }),
        );
        // #endregion
        if targets.is_empty() {
            // #region agent log
            let servers = self.discover_servers().await;
            let mut export_db_samples = serde_json::Map::new();
            for server in servers.iter().take(5) {
                let dbs = self.databases_from_export_pages(server).await;
                export_db_samples.insert(
                    server.clone(),
                    serde_json::json!(dbs.len()),
                );
            }
            phppgadmin_debug(
                "H-NO",
                "phppgadmin.rs:run:no_targets",
                "login ok but zero DB targets",
                serde_json::json!({
                    "host": host_only(&self.app_root),
                    "discovered_servers": servers,
                    "export_page_db_counts": export_db_samples,
                }),
            );
            // #endregion
            let hint = match self.backend {
                BackendKind::PgAdmin4 => {
                    "pgAdmin4 session ok but no servers/databases visible in browser tree (no registered PostgreSQL servers or insufficient privileges)"
                }
                BackendKind::PhpPgAdmin => {
                    "phpPgAdmin session ok but no databases found in UI (wrong server id or insufficient privileges)"
                }
            };
            bail!(hint);
        }

        let db_count = targets.len();
        // #region agent log
        phppgadmin_debug(
            "H0",
            "phppgadmin.rs:run:targets",
            "database targets before export",
            serde_json::json!({
                "host": host_only(&self.app_root),
                "db_count": db_count,
                "download_files": download_files,
                "sample": targets.iter().take(8).map(|t| format!("{}:{}", t.server, t.database)).collect::<Vec<_>>(),
            }),
        );
        // #endregion
        if !download_files {
            return Ok((
                PhpPgAdminAccountStats {
                    username: self.username.clone(),
                    backend: backend_label(&self.backend),
                    databases: db_count,
                    downloaded: 0,
                    bytes: 0,
                },
                Vec::new(),
            ));
        }

        let prefix = Credential::safe_path_component(&self.username);
        let mut written = Vec::new();
        for target in targets.iter().take(64) {
            match self.export_database_sql(target, output_dir, &prefix).await {
                Ok((path, bytes)) => written.push((target.database.clone(), path, bytes)),
                Err(err) => warn!(
                    "sql export failed for {} server={} db={}: {err}",
                    self.username,
                    target.server,
                    target.database
                ),
            }
        }

        if written.is_empty() {
            bail!(
                "found {db_count} databases for {} but failed to export any SQL dump \
                 (PostgreSQL login on server/export page failed, empty export, or disk write error)",
                self.username
            );
        }

        let bytes: u64 = written.iter().map(|(_, _, b)| *b).sum();
        Ok((
            PhpPgAdminAccountStats {
                username: self.username.clone(),
                backend: backend_label(&self.backend),
                databases: db_count,
                downloaded: written.len(),
                bytes,
            },
            written,
        ))
    }

    async fn authenticate(&mut self) -> Result<()> {
        match self.backend {
            BackendKind::PhpPgAdmin => self.login_phppgadmin().await,
            BackendKind::PgAdmin4 => self.login_pgadmin4().await,
        }
    }

    async fn login_phppgadmin(&mut self) -> Result<()> {
        let entries = self.login_entry_urls();
        let try_count = entries.len();
        let mut saw_http_page = false;
        let mut last_transport: Option<anyhow::Error> = None;

        for entry in entries {
            let resp = match self.http.get(entry.clone()).send().await {
                Ok(r) => r,
                Err(e) => {
                    last_transport = Some(anyhow::Error::from(e).context(format!("GET {}", entry)));
                    continue;
                }
            };
            let status = resp.status();
            let html = match resp.text().await {
                Ok(h) => h,
                Err(e) => {
                    last_transport = Some(e.into());
                    continue;
                }
            };
            if !status.is_success() && html.is_empty() {
                continue;
            }
            saw_http_page = true;

            if !looks_like_phppgadmin(&html)
                && !entry.path().to_ascii_lowercase().contains("phppgadmin")
                && !entry.path().ends_with("redirect.php")
                && !entry.path().ends_with("servers.php")
            {
                continue;
            }

            if looks_logged_in(&html) {
                self.rebase_from_login_url(&entry);
                return self.ensure_phppgadmin_session().await;
            }
            if !has_login_form(&html) {
                continue;
            }

            let post_url = login_form_post_url(&entry, &html);
            let posts = build_login_posts(&html, &self.username, &self.password);
            for form in posts {
                let form_refs: Vec<(&str, &str)> = form
                    .iter()
                    .map(|(k, v)| (k.as_str(), v.as_str()))
                    .collect();
                let resp = self.http.post(post_url.clone()).form(&form_refs).send().await;
                let Ok(resp) = resp else { continue };
                let body = resp.text().await.unwrap_or_default();
                if looks_logged_in(&body) {
                    self.rebase_from_login_url(&entry);
                    return self.ensure_phppgadmin_session().await;
                }
            }
        }

        if !saw_http_page {
            if let Some(err) = last_transport {
                let root = err
                    .chain()
                    .map(|e| e.to_string())
                    .next()
                    .unwrap_or_else(|| err.to_string());
                bail!(
                    "cannot reach phpPgAdmin (tried {try_count} login URLs): {root}"
                );
            }
            bail!("cannot reach phpPgAdmin — no HTTP response from host");
        }

        if self.login_postgres_on_servers().await? {
            return self.ensure_phppgadmin_session().await;
        }

        bail!("phpPgAdmin login failed (host reachable, bad credentials or unsupported login form)");
    }

    async fn discover_servers(&self) -> Vec<String> {
        let Ok(url) = self.app_root.join("servers.php") else {
            return Vec::new();
        };
        let Ok(resp) = self.http.get(url).send().await else {
            return Vec::new();
        };
        let html = resp.text().await.unwrap_or_default();
        extract_server_ids_from_html(&html)
    }

    async fn login_postgres_on_servers(&mut self) -> Result<bool> {
        let mut servers = self.discover_servers().await;
        if servers.is_empty() {
            servers = (0..=6).map(|n| n.to_string()).collect();
        }

        for server in servers {
            let Ok(mut url) = self.app_root.join("redirect.php") else {
                continue;
            };
            url.set_query(Some(&format!(
                "subject=server&server={}",
                urlencoding_minimal(&server)
            )));

            let Ok(resp) = self.http.get(url.clone()).send().await else {
                continue;
            };
            let html = resp.text().await.unwrap_or_default();
            if looks_logged_in(&html) {
                return Ok(true);
            }
            if self.finish_postgres_login_if_needed(&url, &html).await? {
                return Ok(true);
            }
        }
        Ok(false)
    }

    async fn finish_postgres_login_if_needed(
        &mut self,
        page_url: &Url,
        html: &str,
    ) -> Result<bool> {
        if !has_login_form(html) {
            return Ok(looks_logged_in(html));
        }
        if looks_logged_in(html) {
            return Ok(true);
        }

        let post_url = login_form_post_url(page_url, html);
        for form in build_login_posts(html, &self.username, &self.password) {
            let form_refs: Vec<(&str, &str)> = form
                .iter()
                .map(|(k, v)| (k.as_str(), v.as_str()))
                .collect();
            let Ok(resp) = self.http.post(post_url.clone()).form(&form_refs).send().await else {
                continue;
            };
            let body = resp.text().await.unwrap_or_default();
            if looks_logged_in(&body) {
                return Ok(true);
            }
        }
        Ok(false)
    }

    async fn ensure_postgres_server_session(&mut self, server: &str) -> Result<()> {
        let enc = urlencoding_minimal(server);
        let queries = [
            format!("subject=server&server={enc}"),
            format!("subject=server&action=tree&server={enc}"),
        ];
        for q in queries {
            let mut url = self
                .app_root
                .join("redirect.php")
                .context("join redirect.php for server login")?;
            url.set_query(Some(&q));
            let resp = self
                .http
                .get(url.clone())
                .timeout(self.request_timeout)
                .send()
                .await
                .with_context(|| format!("GET server session {}", url))?;
            let html = resp.text().await.unwrap_or_default();
            if self.finish_postgres_login_if_needed(&url, &html).await? {
                return Ok(());
            }
            if looks_logged_in(&html) {
                return Ok(());
            }
        }
        bail!("PostgreSQL server login failed for server {server}");
    }

    async fn ensure_postgres_database_session(&mut self, target: &DbTarget) -> Result<()> {
        self.ensure_postgres_server_session(&target.server).await?;
        let mut url = self
            .app_root
            .join("redirect.php")
            .context("join redirect.php for database session")?;
        url.set_query(Some(&format!(
            "subject=database&server={}&database={}",
            urlencoding_minimal(&target.server),
            urlencoding_minimal(&target.database)
        )));
        let resp = self
            .http
            .get(url.clone())
            .timeout(self.request_timeout)
            .send()
            .await
            .with_context(|| format!("GET database session {}", url))?;
        let html = resp.text().await.unwrap_or_default();
        if self.finish_postgres_login_if_needed(&url, &html).await? {
            return Ok(());
        }
        if looks_logged_in(&html) || looks_like_phppgadmin_export_page(&html) {
            return Ok(());
        }
        Ok(())
    }

    fn login_entry_urls(&self) -> Vec<Url> {
        let mut urls = Vec::new();
        let mut push = |u: Url| {
            if !urls.iter().any(|x: &Url| x.as_str() == u.as_str()) {
                urls.push(u);
            }
        };

        push(self.auth_entry.clone());
        if let Ok(u) = self.app_root.join("redirect.php") {
            push(u);
        }
        if let Ok(u) = self.app_root.join("servers.php") {
            push(u);
        }
        if let Ok(u) = self.app_root.join("index.php") {
            push(u);
        }
        push(self.app_root.clone());

        let app_path = self.app_root.path().to_ascii_lowercase();
        let at_site_root = app_path == "/" || app_path == "/phppgadmin/";
        if at_site_root {
            let mut root_redirect = self.auth_entry.clone();
            root_redirect.set_path("/redirect.php");
            root_redirect.set_query(None);
            root_redirect.set_fragment(None);
            push(root_redirect);

            let mut sub_redirect = self.auth_entry.clone();
            sub_redirect.set_path("/phppgadmin/redirect.php");
            sub_redirect.set_query(None);
            sub_redirect.set_fragment(None);
            push(sub_redirect);
        }

        let mut expanded = Vec::new();
        for u in urls {
            push_url_variants(&mut expanded, u);
        }
        expanded
    }

    async fn ensure_phppgadmin_session(&self) -> Result<()> {
        for rel in ["servers.php", "redirect.php", "index.php", "intro.php"] {
            let Ok(url) = self.app_root.join(rel) else {
                continue;
            };
            let Ok(resp) = self.http.get(url.clone()).send().await else {
                continue;
            };
            let html = resp.text().await.unwrap_or_default();
            if has_login_form(&html) && !looks_logged_in(&html) {
                continue;
            }
            if looks_logged_in(&html) {
                return Ok(());
            }
        }
        bail!("phpPgAdmin login failed (session not established)");
    }

    async fn databases_from_export_pages(&self, server: &str) -> Vec<String> {
        for script in ["dataexport.php", "export.php", "display.php"] {
            let Ok(mut url) = self.app_root.join(script) else {
                continue;
            };
            url.set_query(Some(&format!(
                "server={}",
                urlencoding_minimal(server)
            )));
            let Ok(resp) = self.http.get(url).send().await else {
                continue;
            };
            if !resp.status().is_success() {
                continue;
            }
            let html = resp.text().await.unwrap_or_default();
            if has_login_form(&html) && !looks_logged_in(&html) {
                continue;
            }
            let dbs = extract_db_select_options(&html);
            if !dbs.is_empty() {
                return dbs;
            }
        }
        Vec::new()
    }

    async fn probe_database_targets(&self) -> Vec<DbTarget> {
        let mut found = BTreeSet::new();
        let default_names = ["postgres", "template1"];
        let mut servers = self.discover_servers().await;
        if servers.is_empty() {
            servers = (0..=6).map(|n| n.to_string()).collect();
        }
        for server in servers {
            let export_dbs = self.databases_from_export_pages(&server).await;
            if !export_dbs.is_empty() {
                for db in export_dbs {
                    push_db_target(&mut found, &server, &db);
                }
                continue;
            }
            for name in default_names {
                let target = DbTarget {
                    server: server.clone(),
                    database: name.to_string(),
                    pgadmin_db_id: None,
                };
                if self.database_page_open(&target).await {
                    found.insert(target);
                }
            }
        }
        found.into_iter().collect()
    }

    async fn database_page_open(&self, target: &DbTarget) -> bool {
        let Ok(mut url) = self.app_root.join("redirect.php") else {
            return false;
        };
        url.set_query(Some(&format!(
            "subject=database&server={}&database={}",
            urlencoding_minimal(&target.server),
            urlencoding_minimal(&target.database)
        )));
        let Ok(resp) = self.http.get(url).send().await else {
            return false;
        };
        if !resp.status().is_success() {
            return false;
        }
        let html = resp.text().await.unwrap_or_default();
        if has_login_form(&html) && !looks_logged_in(&html) {
            return false;
        }
        let lower = html.to_ascii_lowercase();
        lower.contains(&target.database.to_ascii_lowercase())
            || lower.contains("dataexport")
            || lower.contains("export")
            || lower.contains("subject=database")
    }

    fn rebase_from_login_url(&mut self, entry: &Url) {
        self.auth_entry = entry.clone();
        self.app_root = app_root_from_auth(entry);
    }

    async fn login_pgadmin4(&mut self) -> Result<()> {
        let (login_page_url, html) = self.fetch_pgadmin4_login_page().await?;
        if !pgadmin4_allows_internal_login(&html) {
            bail!(
                "pgAdmin4 requires OAuth2/Kerberos/SSO login (internal email/password disabled on this instance)"
            );
        }

        let csrf = extract_pgadmin4_csrf(&html)
            .context("pgAdmin4 login page missing csrfToken (unsupported or blocked login UI)")?;
        let login_path = extract_pgadmin4_login_url(&html)
            .unwrap_or_else(|| "/pgadmin4/authenticate/login".to_string());
        let post_url = absolute_path_url(&login_page_url, &login_path)?;

        let mut req = self.http.post(post_url).form(&[
            ("email", self.username.as_str()),
            ("password", self.password.as_str()),
            ("csrf_token", csrf.as_str()),
        ]);
        req = req.header("X-pgA-CSRFToken", csrf.as_str());
        let resp = req.send().await.context("pgAdmin4 login POST")?;
        if !resp.status().is_success() && !resp.status().is_redirection() {
            bail!("pgAdmin4 login HTTP {}", resp.status());
        }

        self.pgadmin_csrf = Some(csrf.to_string());
        self.pgadmin4_refresh_csrf_from_browser().await.ok();
        if self.pgadmin4_session_ok().await? {
            return Ok(());
        }
        bail!("pgAdmin4 login failed (bad email/password, locked account, or CSRF rejected)");
    }

    async fn fetch_pgadmin4_login_page(&self) -> Result<(Url, String)> {
        let mut candidates: Vec<Url> = Vec::new();
        let mut push = |url: Url| {
            if !candidates.iter().any(|u| u.as_str() == url.as_str()) {
                candidates.push(url);
            }
        };
        if let Ok(mut u) = absolute_path_url(&self.app_root, "/pgadmin4/login") {
            u.set_query(Some("next=/pgadmin4/browser/"));
            push(u);
        }
        if let Ok(u) = absolute_path_url(&self.app_root, "/pgadmin4/login") {
            push(u);
        }
        push(self.auth_entry.clone());
        push(self.app_root.clone());

        let mut last_status = None::<reqwest::StatusCode>;
        let mut saw_page = false;
        for url in candidates {
            let resp = match self.http.get(url.clone()).send().await {
                Ok(r) => r,
                Err(_) => continue,
            };
            last_status = Some(resp.status());
            let status = resp.status();
            let html = resp.text().await.unwrap_or_default();
            if html.is_empty() && !status.is_success() {
                continue;
            }
            saw_page = true;
            if extract_pgadmin4_csrf(&html).is_some() || looks_like_pgadmin4(&html) {
                return Ok((url, html));
            }
        }
        if !saw_page {
            bail!("cannot reach pgAdmin4 login page");
        }
        if let Some(status) = last_status {
            bail!("cannot reach pgAdmin4 login UI (HTTP {status}; try https://host/pgadmin4/login user:pass)");
        }
        bail!(
            "URL does not look like pgAdmin4 (expected /pgadmin4/login or /pgadmin4/browser/)"
        );
    }

    async fn pgadmin4_session_ok(&self) -> Result<bool> {
        let resp = self.http.get(self.app_root.clone()).send().await?;
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        Ok(status.is_success() && !looks_like_pgadmin4_login_page(&body))
    }

    fn pgadmin4_browser_referer(&self) -> String {
        absolute_path_url(&self.app_root, "/pgadmin4/browser/")
            .map(|u| u.to_string())
            .unwrap_or_else(|_| self.app_root.to_string())
    }

    async fn pgadmin4_refresh_csrf_from_browser(&mut self) -> Result<()> {
        let url = absolute_path_url(&self.app_root, "/pgadmin4/browser/")?;
        let resp = self.http.get(url).send().await.context("GET pgAdmin browser")?;
        let html = resp.text().await.unwrap_or_default();
        if let Some(token) = extract_pgadmin4_csrf(&html) {
            self.pgadmin_csrf = Some(token);
        }
        Ok(())
    }

    async fn pgadmin4_file_manager_trans_id(&self) -> Result<String> {
        let url = pgadmin4_tool_api(&self.app_root, "file_manager", "init")?;
        let v = self.pgadmin4_get_json(url).await?;
        v.pointer("/data/transId")
            .or_else(|| v.pointer("/data/trans_id"))
            .or_else(|| v.get("transId"))
            .and_then(json_id_string)
            .context("file_manager init missing transId")
    }

    fn pgadmin4_process_status(value: &serde_json::Value) -> Option<i64> {
        let candidates = [
            value.pointer("/data/status"),
            value.get("status"),
            value.pointer("/data/process_status"),
        ];
        for c in candidates.into_iter().flatten() {
            if let Some(n) = c.as_i64() {
                return Some(n);
            }
            if let Some(s) = c.as_str() {
                if let Ok(n) = s.parse::<i64>() {
                    return Some(n);
                }
            }
        }
        None
    }

    async fn pgadmin4_get_json(&self, url: Url) -> Result<serde_json::Value> {
        let mut req = self
            .http
            .get(url.clone())
            .header("Accept", "application/json")
            .header("Referer", self.pgadmin4_browser_referer());
        if let Some(csrf) = self.pgadmin_csrf.as_deref() {
            req = req.header("X-pgA-CSRFToken", csrf);
        }
        let resp = req.send().await.context("pgAdmin4 API GET")?;
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        if status.as_u16() == 401 || body.contains("PGADMIN_LOGIN_REQUIRED") {
            bail!("pgAdmin4 session expired (login required)");
        }
        if !status.is_success() {
            bail!("pgAdmin4 API HTTP {status}");
        }
        serde_json::from_str(&body).with_context(|| {
            format!(
                "pgAdmin4 API returned non-JSON ({} bytes)",
                body.len().min(256)
            )
        })
    }

    async fn list_pgadmin4_databases(&self) -> Result<Vec<DbTarget>> {
        let mut found = BTreeSet::new();
        let groups_url = pgadmin4_browser_api(&self.app_root, "server_group/nodes/")?;
        let groups = self
            .pgadmin4_get_json(groups_url)
            .await
            .unwrap_or(serde_json::Value::Null);
        let mut gids = pgadmin4_top_level_ids(&groups);
        if gids.is_empty() {
            gids.push("1".into());
        }

        for gid in gids {
            let servers_url = pgadmin4_browser_api(&self.app_root, &format!("server/nodes/{gid}/"))?;
            let servers = match self.pgadmin4_get_json(servers_url).await {
                Ok(v) => v,
                Err(_) => continue,
            };
            for (sid, _) in pgadmin4_server_nodes(&servers) {
                let db_url =
                    pgadmin4_browser_api(&self.app_root, &format!("database/nodes/{gid}/{sid}/"))?;
                let dbs = match self.pgadmin4_get_json(db_url).await {
                    Ok(v) => v,
                    Err(_) => continue,
                };
                for (name, did) in pgadmin4_database_nodes(&dbs) {
                    found.insert(DbTarget {
                        server: format!("{gid}/{sid}"),
                        database: name,
                        pgadmin_db_id: Some(did),
                    });
                }
            }
        }
        Ok(found.into_iter().collect())
    }

    async fn list_databases(&self) -> Result<Vec<DbTarget>> {
        if self.backend == BackendKind::PgAdmin4 {
            return self.list_pgadmin4_databases().await;
        }
        self.list_phppgadmin_databases().await
    }

    async fn list_phppgadmin_databases(&self) -> Result<Vec<DbTarget>> {
        let mut pages: Vec<Url> = Vec::new();
        for rel in [
            "servers.php",
            "redirect.php",
            "index.php",
            "intro.php",
            "display.php",
        ] {
            if let Ok(u) = self.app_root.join(rel) {
                pages.push(u);
            }
        }
        pages.push(self.app_root.clone());

        let mut server_ids: BTreeSet<String> = (0..=12).map(|n| n.to_string()).collect();
        for s in self.discover_servers().await {
            server_ids.insert(s);
        }
        for server in &server_ids {
            let enc = urlencoding_minimal(server);
            for q in [
                format!("subject=server&server={enc}"),
                format!("subject=server&action=tree&server={enc}"),
                format!("subject=database&server={enc}"),
                format!("subject=database&action=redirect&server={enc}"),
            ] {
                if let Ok(mut u) = self.app_root.join("redirect.php") {
                    u.set_query(Some(&q));
                    pages.push(u);
                }
            }
        }

        let mut found = BTreeSet::new();
        for page in pages {
            let Ok(resp) = self.http.get(page.clone()).send().await else {
                continue;
            };
            let html = resp.text().await.unwrap_or_default();
            if has_login_form(&html) && !looks_logged_in(&html) {
                continue;
            }
            collect_db_targets_from_html(&html, &mut found);
        }

        for server in &server_ids {
            for db in self.databases_from_export_pages(server).await {
                push_db_target(&mut found, server, &db);
            }
        }

        Ok(found.into_iter().collect())
    }

    async fn fetch_phppgadmin_export_page(
        &mut self,
        page_url: &Url,
        target: &DbTarget,
    ) -> Result<(reqwest::StatusCode, String)> {
        for attempt in 0..3 {
            let page_resp = self
                .http
                .get(page_url.clone())
                .timeout(self.request_timeout)
                .send()
                .await
                .with_context(|| format!("GET {}", page_url))?;
            let page_status = page_resp.status();
            let page_html = page_resp.text().await.unwrap_or_default();

            if looks_like_phppgadmin_export_page(&page_html) {
                return Ok((page_status, page_html));
            }
            if has_login_form(&page_html) && !looks_logged_in(&page_html) {
                if attempt + 1 < 3 {
                    let _ = self.ensure_postgres_database_session(target).await;
                    let _ = self
                        .finish_postgres_login_if_needed(page_url, &page_html)
                        .await;
                    continue;
                }
                bail!("export page requires login");
            }
            return Ok((page_status, page_html));
        }
        bail!("export page requires login");
    }

    async fn export_database_sql(
        &mut self,
        target: &DbTarget,
        output_dir: &Path,
        prefix: &str,
    ) -> Result<(PathBuf, u64)> {
        match self.backend {
            BackendKind::PhpPgAdmin => self.export_phppgadmin_sql(target, output_dir, prefix).await,
            BackendKind::PgAdmin4 => {
                self.export_pgadmin4_sql(target, output_dir, prefix).await
            }
        }
    }

    async fn export_pgadmin4_sql(
        &mut self,
        target: &DbTarget,
        site_dir: &Path,
        prefix: &str,
    ) -> Result<(PathBuf, u64)> {
        let (gid, sid) = parse_pgadmin4_gid_sid(&target.server)?;
        self.pgadmin4_connect_server(&gid, &sid).await?;

        let storage_file = format!(
            "/pma_rs_{}_{}.sql",
            Credential::safe_path_component(&target.database),
            Credential::safe_path_component(&sid)
        );

        let job_id = self
            .pgadmin4_start_database_backup(&sid, &target.database, &storage_file)
            .await?;
        self.pgadmin4_wait_process(&job_id).await?;

        let bytes = self
            .pgadmin4_download_storage_file(&storage_file)
            .await
            .with_context(|| format!("download pgAdmin backup file {storage_file}"))?;

        if bytes.is_empty() {
            bail!("pgAdmin4 backup job finished but export file is empty");
        }
        if looks_like_html(&bytes) || !looks_like_sql_dump(&bytes) {
            bail!("pgAdmin4 backup file is not a SQL dump ({} bytes)", bytes.len());
        }

        let leaf = format!(
            "{}__pgadmin4_{}__{}.sql",
            prefix,
            Credential::safe_path_component(&format!("{gid}_{sid}")),
            Credential::safe_path_component(&target.database)
        );
        let path = output_file_path(site_dir, &leaf);
        if let Some(parent) = path.parent() {
            tokio::fs::create_dir_all(parent)
                .await
                .with_context(|| format!("create dir {}", parent.display()))?;
        }
        tokio::fs::write(&path, &bytes)
            .await
            .with_context(|| format!("write {}", path.display()))?;
        Ok((path, bytes.len() as u64))
    }

    async fn pgadmin4_post_json(&self, url: Url, body: &serde_json::Value) -> Result<serde_json::Value> {
        let mut req = self
            .http
            .post(url.clone())
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("Referer", self.pgadmin4_browser_referer());
        if let Some(csrf) = self.pgadmin_csrf.as_deref() {
            req = req.header("X-pgA-CSRFToken", csrf);
        }
        let resp = req.json(body).send().await.with_context(|| format!("POST {url}"))?;
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if status.as_u16() == 401 || text.contains("PGADMIN_LOGIN_REQUIRED") {
            bail!("pgAdmin4 session expired (login required)");
        }
        if !status.is_success() {
            bail!("pgAdmin4 API HTTP {status}: {}", text.chars().take(200).collect::<String>());
        }
        serde_json::from_str(&text).with_context(|| {
            format!(
                "pgAdmin4 API returned non-JSON ({} bytes)",
                text.len().min(256)
            )
        })
    }

    async fn pgadmin4_connect_server(&self, gid: &str, sid: &str) -> Result<()> {
        let path = format!("server/connect/{gid}/{sid}");
        let url = pgadmin4_browser_api(&self.app_root, &path)?;
        for (use_get, use_put) in [(true, false), (false, false), (false, true)] {
            let mut req = if use_get {
                self.http.get(url.clone())
            } else if use_put {
                self.http.put(url.clone())
            } else {
                self.http.post(url.clone())
            };
            req = req
                .header("Accept", "application/json")
                .header("Referer", self.pgadmin4_browser_referer());
            if let Some(csrf) = self.pgadmin_csrf.as_deref() {
                req = req.header("X-pgA-CSRFToken", csrf);
            }
            let Ok(resp) = req.send().await else {
                continue;
            };
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            if status.as_u16() == 404 {
                continue;
            }
            if body.contains("PGADMIN_LOGIN_REQUIRED") {
                bail!("pgAdmin4 session expired (login required)");
            }
            if status.is_success() {
                if let Ok(v) = serde_json::from_str::<serde_json::Value>(&body) {
                    if pgadmin4_json_success(&v) {
                        return Ok(());
                    }
                    if let Some(msg) = v
                        .get("errormsg")
                        .or_else(|| v.pointer("/data/errormsg"))
                        .and_then(|m| m.as_str())
                    {
                        if msg.contains("connect") || msg.contains("Connect") {
                            bail!("pgAdmin4 server connect failed: {msg}");
                        }
                    }
                }
                return Ok(());
            }
        }
        bail!("pgAdmin4 could not connect to PostgreSQL server (gid={gid}, sid={sid})");
    }

    async fn pgadmin4_start_database_backup(
        &self,
        sid: &str,
        database: &str,
        storage_file: &str,
    ) -> Result<String> {
        let url = pgadmin4_tool_api(&self.app_root, "backup", &format!("job/{sid}/object"))?;
        let body = serde_json::json!({
            "type": "objects",
            "file": storage_file,
            "format": "plain",
            "verbose": true,
            "database": database,
            "pre_data": true,
            "data": true,
            "post_data": true,
        });
        let v = self.pgadmin4_post_json(url, &body).await?;
        if !pgadmin4_json_success(&v) {
            let msg = v
                .get("errormsg")
                .and_then(|m| m.as_str())
                .unwrap_or("backup job rejected");
            bail!("pgAdmin4 backup job failed: {msg}");
        }
        v.pointer("/data/job_id")
            .or_else(|| v.get("job_id"))
            .and_then(json_id_string)
            .context("pgAdmin4 backup response missing job_id")
    }

    async fn pgadmin4_wait_process(&self, pid: &str) -> Result<()> {
        let url = pgadmin4_misc_api(&self.app_root, &format!("bgprocess/{pid}"))?;
        let deadline = std::time::Instant::now() + self.request_timeout.max(Duration::from_secs(300));
        loop {
            if std::time::Instant::now() > deadline {
                bail!("pgAdmin4 backup job {pid} timed out");
            }
            let v = self.pgadmin4_get_json(url.clone()).await?;
            let status = Self::pgadmin4_process_status(&v);
            match status {
                Some(2) => return Ok(()),
                Some(3) => {
                    let detail = v
                        .pointer("/data/command_info")
                        .or_else(|| v.pointer("/data/details"))
                        .cloned()
                        .unwrap_or(v);
                    bail!("pgAdmin4 backup job failed: {detail}");
                }
                _ => tokio::time::sleep(Duration::from_millis(750)).await,
            }
        }
    }

    async fn pgadmin4_download_storage_file(&self, storage_path: &str) -> Result<Vec<u8>> {
        let trans_id = self
            .pgadmin4_file_manager_trans_id()
            .await
            .unwrap_or_else(|_| "1".to_string());
        let fm_url =
            pgadmin4_tool_api(&self.app_root, "file_manager", &format!("filemanager/{trans_id}/"))?;
        for mode in ["getfile", "download"] {
            let mut req = self
                .http
                .post(fm_url.clone())
                .header("Referer", self.pgadmin4_browser_referer())
                .form(&[("mode", mode), ("path", storage_path)]);
            if let Some(csrf) = self.pgadmin_csrf.as_deref() {
                req = req.header("X-pgA-CSRFToken", csrf);
            }
            let Ok(resp) = req.send().await else {
                continue;
            };
            if !resp.status().is_success() {
                continue;
            }
            let bytes = resp.bytes().await.unwrap_or_default();
            if bytes.is_empty() || looks_like_html(&bytes) {
                continue;
            }
            if looks_like_sql_dump(&bytes) {
                return Ok(bytes.to_vec());
            }
        }

        let prefix = pgadmin4_prefix(&self.app_root);
        let enc = urlencoding_minimal(storage_path);
        let candidates = [
            format!("{prefix}/storage/load/?fpath={enc}"),
            format!("{prefix}/storage/load?fpath={enc}"),
        ];
        for path in candidates {
            let Ok(url) = absolute_path_url(&self.app_root, &path) else {
                continue;
            };
            let mut req = self
                .http
                .get(url.clone())
                .header("Accept", "*/*")
                .header("Referer", self.pgadmin4_browser_referer());
            if let Some(csrf) = self.pgadmin_csrf.as_deref() {
                req = req.header("X-pgA-CSRFToken", csrf);
            }
            let Ok(resp) = req.send().await else {
                continue;
            };
            if !resp.status().is_success() {
                continue;
            }
            let bytes = resp.bytes().await.unwrap_or_default();
            if bytes.is_empty() || looks_like_html(&bytes) {
                continue;
            }
            return Ok(bytes.to_vec());
        }
        bail!("could not download pgAdmin4 backup from storage path {storage_path}");
    }

    async fn export_phppgadmin_sql(
        &mut self,
        target: &DbTarget,
        site_dir: &Path,
        prefix: &str,
    ) -> Result<(PathBuf, u64)> {
        let scripts = ["dataexport.php", "export.php"];
        let mut last_err: Option<anyhow::Error> = None;
        for script in scripts {
            match self
                .try_phppgadmin_export_script(script, target, site_dir, prefix)
                .await
            {
                Ok(path) => return Ok(path),
                    Err(err) => {
                        // #region agent log
                        phppgadmin_debug(
                            if err.to_string().contains("write ") {
                                "H-WIN"
                            } else {
                                "H-A"
                            },
                            "phppgadmin.rs:export_script_fail",
                            "export attempt failed",
                            serde_json::json!({
                                "host": host_only(&self.app_root),
                                "script": script,
                                "server": target.server,
                                "database": target.database,
                                "err_prefix": err.to_string().chars().take(160).collect::<String>(),
                            }),
                        );
                        // #endregion
                        last_err = Some(err);
                    }
            }
        }
        Err(last_err.unwrap_or_else(|| anyhow::anyhow!("export failed")))
    }

    async fn try_phppgadmin_export_script(
        &mut self,
        script: &str,
        target: &DbTarget,
        site_dir: &Path,
        prefix: &str,
    ) -> Result<(PathBuf, u64)> {
        self.ensure_postgres_database_session(target).await.ok();

        let mut page_url = self
            .app_root
            .join(script)
            .with_context(|| format!("join {script}"))?;
        page_url.set_query(Some(&format!(
            "server={}&database={}",
            urlencoding_minimal(&target.server),
            urlencoding_minimal(&target.database)
        )));

        let (page_status, page_html) = self
            .fetch_phppgadmin_export_page(&page_url, target)
            .await?;
        if !page_status.is_success() {
            bail!("export page HTTP {page_status}");
        }

        let hidden = extract_hidden_fields(&page_html);
        // #region agent log
        phppgadmin_debug(
            "H-C",
            "phppgadmin.rs:export_page_get",
            "export form page loaded",
            serde_json::json!({
                "host": host_only(&self.app_root),
                "script": script,
                "page_status": page_status.as_u16(),
                "page_html_len": page_html.len(),
                "app_root_path": self.app_root.path(),
                "hidden_field_names": hidden.iter().map(|(k, _)| k.as_str()).collect::<Vec<_>>(),
                "has_dataexport_action": page_html.to_ascii_lowercase().contains("dataexport"),
            }),
        );
        // #endregion
        let mut form = hidden;
        form.extend(export_form_for_script(script, target));
        merge_form_last_wins(&mut form);
        // #region agent log
        phppgadmin_debug(
            "H-B",
            "phppgadmin.rs:export_form_merged",
            "POST form field names",
            serde_json::json!({
                "host": host_only(&self.app_root),
                "script": script,
                "database": target.database,
                "form_field_names": form.iter().map(|(k, _)| k.as_str()).collect::<Vec<_>>(),
            }),
        );
        // #endregion

        let post_url = self
            .app_root
            .join(script)
            .with_context(|| format!("POST url {script}"))?;
        let form_refs: Vec<(&str, &str)> = form
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();

        let resp = self
            .http
            .post(post_url.clone())
            .header("Referer", page_url.as_str())
            .timeout(self.request_timeout)
            .form(&form_refs)
            .send()
            .await
            .with_context(|| format!("POST {}", post_url))?;

        let status = resp.status();
        let content_type = resp
            .headers()
            .get(reqwest::header::CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .unwrap_or("")
            .to_string();
        let bytes = resp.bytes().await.context("read export body")?;
        let body_snippet: String = String::from_utf8_lossy(&bytes[..bytes.len().min(120)])
            .chars()
            .filter(|c| !c.is_control() || *c == '\n')
            .take(120)
            .collect();
        // #region agent log
        phppgadmin_debug(
            "H-A",
            "phppgadmin.rs:export_response",
            "export POST result",
            serde_json::json!({
                "host": host_only(&self.app_root),
                "script": script,
                "database": target.database,
                "status": status.as_u16(),
                "content_type": content_type,
                "bytes": bytes.len(),
                "looks_html": looks_like_html(&bytes),
                "looks_sql": looks_like_sql_dump(&bytes),
                "body_snippet": body_snippet,
            }),
        );
        // #endregion
        if !status.is_success() || bytes.is_empty() {
            bail!("empty export response (HTTP {status})");
        }
        if looks_like_html(&bytes) || !looks_like_sql_dump(&bytes) {
            bail!("export returned HTML or non-SQL payload");
        }

        let leaf = format!(
            "{}__server{}__{}.sql",
            prefix,
            Credential::safe_path_component(&target.server),
            Credential::safe_path_component(&target.database)
        );
        let path = output_file_path(site_dir, &leaf);
        if let Some(parent) = path.parent() {
            tokio::fs::create_dir_all(parent)
                .await
                .with_context(|| format!("create dir {}", parent.display()))?;
        }
        tokio::fs::write(&path, &bytes)
            .await
            .with_context(|| format!("write {}", path.display()))?;
        debug!(
            "exported phpPgAdmin SQL via {} {} ({} bytes)",
            script,
            path.display(),
            bytes.len()
        );

        Ok((path, bytes.len() as u64))
    }
}

fn phppgadmin_roots(entry: &Url) -> Result<(Url, Url)> {
    let mut auth = entry.clone();
    let path = auth.path().to_string();
    let lower = path.to_ascii_lowercase();

    if lower.ends_with("redirect.php") || lower.ends_with("servers.php") {
        // keep user path (/redirect.php, /servers.php, or /phppgadmin/*.php)
    } else if lower.contains("phppgadmin") {
        if lower.ends_with("/phppgadmin") || lower.ends_with("/phppgadmin/") {
            auth.set_path(&format!(
                "{}/redirect.php",
                path.trim_end_matches('/')
            ));
        }
    } else if path == "/" || path.is_empty() {
        auth.set_path("/phppgadmin/redirect.php");
    } else {
        auth.set_path("/phppgadmin/redirect.php");
    }

    auth.set_query(None);
    auth.set_fragment(None);
    let root = app_root_from_auth(&auth);
    Ok((root, auth))
}

fn app_root_from_auth(auth: &Url) -> Url {
    let mut root = auth.clone();
    let path = auth.path();
    let lower = path.to_ascii_lowercase();

    if lower.ends_with("/redirect.php") {
        let parent = path
            .strip_suffix("/redirect.php")
            .unwrap_or("/");
        if parent.is_empty() {
            root.set_path("/");
        } else {
            let p = format!("{parent}/");
            root.set_path(&p);
        }
    } else if lower.ends_with("/servers.php") {
        let parent = path.strip_suffix("/servers.php").unwrap_or("/");
        if parent.is_empty() {
            root.set_path("/");
        } else {
            let p = format!("{parent}/");
            root.set_path(&p);
        }
    } else if let Some(idx) = lower.find("phppgadmin") {
        let end = idx + "phppgadmin".len();
        root.set_path(&format!("{}/", &path[..end]));
    } else {
        root.set_path("/");
    }

    root.set_query(None);
    root.set_fragment(None);
    root
}

fn push_url_variants(out: &mut Vec<Url>, url: Url) {
    let mut push = |u: Url| {
        if !out.iter().any(|x: &Url| x.as_str() == u.as_str()) {
            out.push(u);
        }
    };
    push(url.clone());
    if let Some(alt) = crate::http_client::alternate_http_scheme(&url) {
        push(alt);
    }
}

fn pgadmin4_roots(entry: &Url) -> Result<(Url, Url)> {
    let mut root = entry.clone();
    let lower = root.path().to_ascii_lowercase();
    if lower.contains("/pgadmin4/") {
        root.set_path("/pgadmin4/browser/");
    } else if !lower.contains("pgadmin4") {
        root.set_path("/pgadmin4/browser/");
    }
    root.set_query(None);
    root.set_fragment(None);
    let mut login = absolute_path_url(&root, "/pgadmin4/login").unwrap_or(root.clone());
    login.set_query(Some("next=/pgadmin4/browser/"));
    Ok((root, login))
}

fn pgadmin4_prefix(app_root: &Url) -> String {
    let path = app_root.path();
    let lower = path.to_ascii_lowercase();
    if let Some(pos) = lower.find("/pgadmin4") {
        return path[..pos + "/pgadmin4".len()].to_string();
    }
    "/pgadmin4".to_string()
}

fn pgadmin4_browser_api(app_root: &Url, suffix: &str) -> Result<Url> {
    let prefix = pgadmin4_prefix(app_root);
    let suffix = suffix.trim_start_matches('/');
    let path = format!("{prefix}/browser/{suffix}");
    absolute_path_url(app_root, &path)
}

fn pgadmin4_tool_api(app_root: &Url, tool: &str, suffix: &str) -> Result<Url> {
    let prefix = pgadmin4_prefix(app_root);
    let suffix = suffix.trim_start_matches('/');
    let path = format!("{prefix}/{tool}/{suffix}");
    absolute_path_url(app_root, &path)
}

fn pgadmin4_misc_api(app_root: &Url, suffix: &str) -> Result<Url> {
    let prefix = pgadmin4_prefix(app_root);
    let suffix = suffix.trim_start_matches('/');
    let path = format!("{prefix}/misc/{suffix}");
    absolute_path_url(app_root, &path)
}

fn parse_pgadmin4_gid_sid(server: &str) -> Result<(String, String)> {
    let parts: Vec<&str> = server.split('/').collect();
    if parts.len() == 2 && !parts[0].is_empty() && !parts[1].is_empty() {
        return Ok((parts[0].to_string(), parts[1].to_string()));
    }
    if parts.len() == 1 && !parts[0].is_empty() {
        return Ok(("1".into(), parts[0].to_string()));
    }
    bail!("invalid pgAdmin4 server target {server:?} (expected gid/sid)");
}

fn pgadmin4_json_success(value: &serde_json::Value) -> bool {
    if value.get("success").and_then(|v| v.as_i64()) == Some(1) {
        return true;
    }
    if value.get("Success").and_then(|v| v.as_i64()) == Some(1) {
        return true;
    }
    value
        .pointer("/data/Success")
        .and_then(|v| v.as_i64())
        == Some(1)
}

fn absolute_path_url(base: &Url, path: &str) -> Result<Url> {
    if path.starts_with("http://") || path.starts_with("https://") {
        return Url::parse(path).context("absolute url");
    }
    let mut u = base.clone();
    u.set_path(path);
    u.set_query(None);
    u.set_fragment(None);
    Ok(u)
}

fn extract_pgadmin4_csrf(html: &str) -> Option<String> {
    PGADMIN4_CSRF_RE
        .captures(html)
        .map(|cap| decode_json_string_escape(&cap[1]))
}

fn extract_pgadmin4_login_url(html: &str) -> Option<String> {
    PGADMIN4_LOGIN_URL_RE
        .captures(html)
        .map(|cap| cap[1].to_string())
}

fn decode_json_string_escape(raw: &str) -> String {
    raw.replace("\\u003c", "<")
        .replace("\\u003e", ">")
        .replace("\\\"", "\"")
        .replace("\\\\", "\\")
}

fn pgadmin4_allows_internal_login(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    if lower.contains("\"authsources\":[\"internal\"")
        || lower.contains("\"authsources\": [\"internal\"")
    {
        return true;
    }
    if lower.contains("\"authsources\":[]") || lower.contains("\"authsources\": []") {
        return false;
    }
    // Legacy pages: internal form present
    lower.contains("login_user") && lower.contains("csrfToken")
}

fn looks_like_pgadmin4(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("pgadmin 4")
        || lower.contains("rendersecuritypage")
        || lower.contains("/pgadmin4/")
        || lower.contains("csrftoken")
        || lower.contains("pgadmin_login_required")
}

fn looks_like_pgadmin4_login_page(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("rendersecuritypage(") && lower.contains("login_user")
}

fn pgadmin4_top_level_ids(value: &serde_json::Value) -> Vec<String> {
    let Some(items) = value.as_array() else {
        return Vec::new();
    };
    items
        .iter()
        .filter_map(|item| item.get("id").and_then(json_id_string))
        .collect()
}

fn pgadmin4_server_nodes(value: &serde_json::Value) -> Vec<(String, String)> {
    let mut out = Vec::new();
    let Some(items) = value.as_array() else {
        return out;
    };
    for item in items {
        let Some(obj) = item.as_object() else {
            continue;
        };
        let sid = obj
            .get("id")
            .and_then(json_id_string)
            .unwrap_or_default();
        if sid.is_empty() {
            continue;
        }
        let label = obj
            .get("label")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        out.push((sid, label));
    }
    out
}

fn pgadmin4_database_nodes(value: &serde_json::Value) -> Vec<(String, String)> {
    let mut out = Vec::new();
    let Some(items) = value.as_array() else {
        return out;
    };
    for item in items {
        let Some(obj) = item.as_object() else {
            continue;
        };
        let node_type = obj
            .get("_type")
            .or_else(|| obj.get("type"))
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let label = obj.get("label").and_then(|v| v.as_str()).unwrap_or("");
        if label.is_empty() || !is_plausible_db_name(label) {
            continue;
        }
        if !node_type.eq_ignore_ascii_case("database") && !node_type.is_empty() {
            continue;
        }
        let did = obj
            .get("id")
            .or_else(|| obj.get("_id"))
            .and_then(json_id_string)
            .unwrap_or_else(|| label.to_string());
        out.push((label.to_string(), did));
    }
    out
}

fn json_id_string(value: &serde_json::Value) -> Option<String> {
    match value {
        serde_json::Value::Number(n) => Some(n.to_string()),
        serde_json::Value::String(s) => Some(s.clone()),
        _ => None,
    }
}

fn backend_label(kind: &BackendKind) -> &'static str {
    match kind {
        BackendKind::PhpPgAdmin => "phppgadmin",
        BackendKind::PgAdmin4 => "pgadmin4",
    }
}

fn export_form_for_script(script: &str, target: &DbTarget) -> Vec<(String, String)> {
    if script == "dataexport.php" {
        vec![
            ("action".into(), "export".into()),
            ("subject".into(), "database".into()),
            ("server".into(), target.server.clone()),
            ("database".into(), target.database.clone()),
            ("what".into(), "structureanddata".into()),
            ("sd_format".into(), "sql".into()),
            ("output".into(), "download".into()),
            ("go".into(), "Export".into()),
        ]
    } else {
        vec![
            ("subject".into(), "database".into()),
            ("action".into(), "export".into()),
            ("server".into(), target.server.clone()),
            ("database".into(), target.database.clone()),
            ("go".into(), "Export".into()),
            ("output".into(), "download".into()),
            ("format".into(), "sql".into()),
        ]
    }
}

fn merge_form_last_wins(form: &mut Vec<(String, String)>) {
    let mut map = std::collections::BTreeMap::new();
    for (k, v) in form.drain(..) {
        map.insert(k, v);
    }
    form.extend(map);
}

fn dedupe_form(form: &mut Vec<(String, String)>) {
    let mut seen = BTreeSet::new();
    form.retain(|(k, _)| seen.insert(k.clone()));
}

fn urlencoding_minimal(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

fn looks_like_sql_dump(bytes: &[u8]) -> bool {
    if bytes.len() < 8 {
        return false;
    }
    let head = String::from_utf8_lossy(&bytes[..bytes.len().min(4096)]).to_ascii_lowercase();
    head.contains("create table")
        || head.contains("create database")
        || head.contains("create schema")
        || head.contains("insert into")
        || head.contains("copy ")
        || head.contains("postgresql database dump")
        || head.contains("pg_dump")
        || head.contains("set search_path")
        || head.contains("set client_encoding")
        || head.trim_start().starts_with("--")
}

fn collect_db_targets_from_html(html: &str, found: &mut BTreeSet<DbTarget>) {
    for cap in DB_TARGET_RE.captures_iter(html) {
        push_db_target(found, &cap[1], &cap[2]);
    }
    for cap in DB_TARGET_LOOSE_RE.captures_iter(html) {
        push_db_target(found, &cap[1], &cap[2]);
    }
    for cap in DB_TARGET_REV_RE.captures_iter(html) {
        push_db_target(found, &cap[2], &cap[1]);
    }
    for cap in DB_REDIRECT_HREF_RE.captures_iter(html) {
        push_db_target(found, &cap[1], &cap[2]);
    }
}

fn push_db_target(found: &mut BTreeSet<DbTarget>, server: &str, database: &str) {
    let server = decode_db_name(server);
    let database = decode_db_name(database);
    if server.is_empty() || !is_plausible_db_name(&database) {
        return;
    }
    found.insert(DbTarget {
        server,
        database,
        pgadmin_db_id: None,
    });
}

fn is_plausible_db_name(name: &str) -> bool {
    !name.is_empty()
        && name.len() <= 128
        && !name.eq_ignore_ascii_case("database")
        && !name.contains(".php")
        && !name.contains('<')
}

fn decode_db_name(raw: &str) -> String {
    let mut s = decode_entities(raw);
    if s.contains('%') {
        s = percent_decode_lossy(&s);
    }
    s
}

fn percent_decode_lossy(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            if let Ok(v) = u8::from_str_radix(&s[i + 1..i + 3], 16) {
                out.push(v);
                i += 3;
                continue;
            }
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn decode_entities(s: &str) -> String {
    s.replace("&amp;", "&")
}

fn extract_hidden_fields(html: &str) -> Vec<(String, String)> {
    let mut fields = Vec::new();
    let mut seen = BTreeSet::new();
    for re in [&*HIDDEN_INPUT_RE, &*HIDDEN_INPUT_ALT_RE] {
        for cap in re.captures_iter(html) {
            let name = cap[1].to_string();
            if seen.insert(name.clone()) {
                fields.push((name, cap[2].to_string()));
            }
        }
    }
    fields
}

fn extract_password_field_name(html: &str) -> Option<String> {
    LOGIN_PASSWORD_FIELD_REV_RE
        .captures(html)
        .or_else(|| LOGIN_PASSWORD_FIELD_RE.captures(html))
        .or_else(|| LOGIN_PASSWORD_NAME_RE.captures(html))
        .or_else(|| LOGIN_PASSWORD_NAME_ALT_RE.captures(html))
        .map(|cap| cap[1].to_string())
}

fn extract_server_ids_from_html(html: &str) -> Vec<String> {
    let mut seen = BTreeSet::new();
    for cap in SERVER_LINK_RE.captures_iter(html) {
        seen.insert(decode_db_name(&cap[1]));
    }
    for cap in SERVER_LOGIN_HREF_RE.captures_iter(html) {
        let href = decode_entities(&cap[1]);
        if let Some(id) = SERVER_LINK_RE
            .captures(&href)
            .map(|c| decode_db_name(&c[1]))
        {
            seen.insert(id);
        }
    }
    seen.into_iter().collect()
}

fn extract_submit_button(html: &str) -> Option<(String, String)> {
    LOGIN_SUBMIT_RE
        .captures(html)
        .map(|cap| (cap[1].to_string(), cap[2].to_string()))
}

fn extract_server_login_urls(html: &str, base: &Url) -> Vec<Url> {
    let mut urls = Vec::new();
    let mut seen = BTreeSet::new();
    for cap in SERVER_LOGIN_HREF_RE.captures_iter(html) {
        let href = decode_entities(&cap[1]);
        if let Ok(u) = base.join(&href) {
            let key = u.as_str().to_string();
            if seen.insert(key) {
                urls.push(u);
            }
        }
    }
    urls
}

fn login_form_post_url(page: &Url, html: &str) -> Url {
    let action = LOGIN_FORM_ACTION_RE
        .captures(html)
        .map(|cap| cap[1].to_string())
        .unwrap_or_else(|| "redirect.php".into());
    if action.starts_with("http://") || action.starts_with("https://") {
        return Url::parse(&action).unwrap_or_else(|_| page.clone());
    }
    if let Ok(u) = page.join(&action) {
        let mut post = u;
        post.set_query(None);
        post.set_fragment(None);
        return post;
    }
    page.clone()
}

fn build_login_posts(html: &str, username: &str, password: &str) -> Vec<Vec<(String, String)>> {
    if let Some(password_field) = extract_password_field_name(html) {
        let mut form = extract_hidden_fields(html);
        form.push(("loginUsername".into(), username.to_string()));
        form.push((password_field, password.to_string()));
        if let Some((submit_name, submit_val)) = extract_submit_button(html) {
            form.push((submit_name, submit_val));
        }
        dedupe_form(&mut form);
        return vec![form];
    }

    let mut variants = login_form_variants(username, password);
    let hidden = extract_hidden_fields(html);
    for form in &mut variants {
        form.extend(hidden.clone());
        dedupe_form(form);
    }
    variants
}

fn login_form_variants(username: &str, password: &str) -> Vec<Vec<(String, String)>> {
    let mut variants = Vec::new();
    for server_id in ["0", "1", "2"] {
        variants.push(vec![
            ("loginUsername".into(), username.to_string()),
            ("loginPassword".into(), password.to_string()),
            ("loginServer".into(), server_id.into()),
            ("submitLogin".into(), "Login".into()),
        ]);
        variants.push(vec![
            ("loginUsername".into(), username.to_string()),
            ("loginPassword".into(), password.to_string()),
            ("loginServer".into(), server_id.into()),
            ("submit".into(), "Login".into()),
        ]);
    }
    variants.push(vec![
        ("loginUsername".into(), username.to_string()),
        ("loginPassword".into(), password.to_string()),
        ("submit".into(), "Login".into()),
    ]);
    variants
}

fn looks_like_phppgadmin(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("phppgadmin") || lower.contains("loginusername")
}

fn looks_like_phppgadmin_export_page(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    if lower.contains("name=\"sd_format\"") || lower.contains("dataexport.php") {
        return true;
    }
    let fields = extract_hidden_fields(html);
    let has_export_action = fields
        .iter()
        .any(|(k, v)| k.eq_ignore_ascii_case("action") && v.eq_ignore_ascii_case("export"));
    let has_server = fields
        .iter()
        .any(|(k, _)| k.eq_ignore_ascii_case("server"));
    let has_what = fields
        .iter()
        .any(|(k, _)| k.eq_ignore_ascii_case("what"));
    has_export_action && has_server && (has_what || lower.contains("name=\"go\""))
}

fn has_login_form(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("loginpassword") || lower.contains("name=\"loginusername\"")
}

fn looks_logged_in(html: &str) -> bool {
    if has_login_form(html) {
        return false;
    }
    let lower = html.to_ascii_lowercase();
    if lower.contains("login to postgresql") || lower.contains("id=\"login_form\"") {
        return false;
    }
    lower.contains("logout")
        || lower.contains("log out")
        || lower.contains("subject=logout")
        || (lower.contains("subject=database") && lower.contains("server="))
        || looks_like_servers_landing(&lower)
}

/// phpPgAdmin 7.x may redirect to `servers.php` after PostgreSQL login; the public
/// servers list looks similar but leaves the Username column empty.
fn looks_like_servers_landing(lower: &str) -> bool {
    if lower.contains("login to postgresql") || lower.contains("id=\"login_form\"") {
        return false;
    }
    if !lower.contains("phppgadmin - servers") || !lower.contains("<th class=\"data\">server</th>") {
        return false;
    }
    SERVERS_USER_ROW_RE.is_match(lower)
}

fn looks_like_html(bytes: &[u8]) -> bool {
    let head = String::from_utf8_lossy(&bytes[..bytes.len().min(256)]).to_ascii_lowercase();
    head.contains("<html") || head.contains("<!doctype")
}

pub async fn download_personal_dumps(
    cred: &Credential,
    config: &PhpPgAdminClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(PhpPgAdminAccountStats, Vec<(String, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_personal_dumps_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_personal_dumps_once(
    cred: Credential,
    config: &PhpPgAdminClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(PhpPgAdminAccountStats, Vec<(String, PathBuf, u64)>)> {
    let mut client = PhpPgAdminClient::new(&cred, config)?;
    let site_dir = cred.account_site_output_dir(output_dir, "phppgadmin");
    client.run(&site_dir, download_files).await
}
