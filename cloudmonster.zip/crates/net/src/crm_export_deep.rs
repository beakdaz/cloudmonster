//! Pipedrive REST API (api_token, moka cache, parallel endpoints, proxy via runtime).

use anyhow::{Context, Result};
use cached::proc_macro::cached;
use pma_core::{output_file_path, Credential, CrmExportService};
use rand::Rng;
use reqwest::Client;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;
use tokio::fs;
use tokio::task::JoinSet;

use crate::NoteRuntime;
use crate::note_app_common::NoteAppSpec;

const PIPEDRIVE_API: &str = "https://api.pipedrive.com/v1";

pub fn pipedrive_api_token(cred: &Credential) -> Option<String> {
    let pass = cred.password.trim();
    let pass = pass
        .strip_prefix("token:")
        .or_else(|| pass.strip_prefix("api:"))
        .unwrap_or(pass)
        .trim();
    if pass.len() >= 16 && !pass.contains(' ') {
        return Some(pass.to_string());
    }
    None
}

#[cached(
    time = 3600,
    size = 5000,
    key = "String",
    convert = r#"{ format!("pipedrive-token:{}", cred.username) }"#
)]
fn pipedrive_api_token_cached(cred: &Credential) -> Option<String> {
    pipedrive_api_token(cred)
}

async fn pipedrive_jitter() {
    let ms = rand::thread_rng().gen_range(100..500);
    tokio::time::sleep(Duration::from_millis(ms)).await;
}

async fn write_json(
    site_dir: &Path,
    prefix: &str,
    name: &str,
    value: &Value,
) -> Result<(PathBuf, u64)> {
    let leaf = format!("{prefix}__deep_{name}.json");
    let path = output_file_path(site_dir, &leaf);
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await.ok();
    }
    let text = serde_json::to_string_pretty(value)?;
    let bytes = text.len() as u64;
    fs::write(&path, &text).await?;
    Ok((path, bytes))
}

async fn pipedrive_get_json(
    runtime: &NoteRuntime,
    http: &Client,
    api_token: &str,
    path: &str,
    extra_query: &[(&str, &str)],
) -> Result<Value> {
    let mut url = reqwest::Url::parse(&format!("{PIPEDRIVE_API}/{path}"))?;
    {
        let mut q = url.query_pairs_mut();
        q.append_pair("api_token", api_token);
        for (k, v) in extra_query {
            q.append_pair(k, v);
        }
    }
    let cache_key = format!("pipedrive:GET:{}", url);
    if let Some(hit) = runtime.cache().get_json(&cache_key) {
        return Ok(hit);
    }

    pipedrive_jitter().await;

    let resp = http.get(url.clone()).send().await.context("pipedrive request")?;
    if resp.status() == reqwest::StatusCode::TOO_MANY_REQUESTS {
        anyhow::bail!("pipedrive rate limit (429)");
    }
    if resp.status() == reqwest::StatusCode::UNAUTHORIZED {
        anyhow::bail!("pipedrive invalid api token");
    }
    if !resp.status().is_success() {
        anyhow::bail!("pipedrive HTTP {}", resp.status());
    }
    let v: Value = resp.json().await.context("pipedrive json")?;
    runtime.cache().set_json(cache_key, v.clone());
    Ok(v)
}

fn pipedrive_item_count(v: &Value) -> usize {
    if let Some(n) = v
        .get("additional_data")
        .and_then(|a| a.get("pagination"))
        .and_then(|p| p.get("count"))
        .and_then(|c| c.as_u64())
    {
        return n as usize;
    }
    v.get("data")
        .and_then(|d| d.as_array())
        .map(|a| a.len())
        .unwrap_or(0)
}

pub async fn pipedrive_validate_api_token(
    runtime: Arc<NoteRuntime>,
    api_token: &str,
) -> Result<(String, usize)> {
    let http = runtime.client().await?;
    let me = pipedrive_get_json(&runtime, &http, api_token, "users/me", &[]).await?;
    let name = me
        .pointer("/data/name")
        .or_else(|| me.pointer("/data/email"))
        .and_then(|x| x.as_str())
        .unwrap_or("pipedrive-api")
        .to_string();

    let probes = ["deals", "persons", "organizations", "leads"];
    let mut set = JoinSet::new();
    for ep in probes {
        let rt = runtime.clone();
        let tok = api_token.to_string();
        set.spawn(async move {
            let http = rt.client().await.ok()?;
            let v = pipedrive_get_json(&rt, &http, &tok, ep, &[("limit", "1")])
                .await
                .ok()?;
            Some(pipedrive_item_count(&v))
        });
    }
    let mut total = 0usize;
    while let Some(res) = set.join_next().await {
        if let Ok(Some(n)) = res {
            total += n;
        }
    }
    Ok((name, total.max(1)))
}

async fn pipedrive_fetch_endpoint(
    runtime: Arc<NoteRuntime>,
    api_token: String,
    endpoint: &'static str,
) -> Result<Value> {
    let http = runtime.client().await?;
    pipedrive_get_json(&runtime, &http, &api_token, endpoint, &[("limit", "500")]).await
}

pub async fn pipedrive_deep_exports(
    runtime: Arc<NoteRuntime>,
    site_dir: &Path,
    prefix: &str,
    api_token: &str,
) -> Result<Vec<(PathBuf, u64)>> {
    let endpoints = ["deals", "persons", "organizations", "leads"];
    let mut set = JoinSet::new();
    for ep in endpoints {
        let rt = runtime.clone();
        let tok = api_token.to_string();
        set.spawn(async move {
            let v = pipedrive_fetch_endpoint(rt, tok, ep).await.ok()?;
            Some((ep.to_string(), v))
        });
    }

    let mut out = Vec::new();
    while let Some(res) = set.join_next().await {
        if let Ok(Some((name, v))) = res {
            out.push(write_json(site_dir, prefix, &format!("pipedrive_{name}"), &v).await?);
        }
    }
    Ok(out)
}

pub async fn pipedrive_account_via_api_token(
    cred: &Credential,
    runtime: Arc<NoteRuntime>,
    output_dir: &Path,
    download_files: bool,
    spec: &NoteAppSpec,
    api_token: &str,
) -> Result<(crate::note_app_common::NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let (session_user, items) = pipedrive_validate_api_token(runtime.clone(), api_token).await?;
    let username = if session_user.is_empty() {
        cred.username.clone()
    } else {
        session_user
    };
    let auth_method = "pipedrive-api-token".to_string();

    if !download_files {
        return Ok((
            crate::note_app_common::NoteAppAccountStats {
                service: spec.service_label.to_string(),
                username,
                auth_method,
                inventory_items: items,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, spec.output_slug);
    let prefix = cred.account_file_prefix();
    let mut written = Vec::new();
    let mut total_bytes = 0u64;

    let snapshot = json!({
        "service": spec.service_label,
        "url": cred.url.as_str(),
        "user": username,
        "auth_method": auth_method,
        "inventory_items": items,
        "api": PIPEDRIVE_API,
    });
    let snap_path = output_file_path(&site_dir, &format!("{prefix}__snapshot.json"));
    if let Some(parent) = snap_path.parent() {
        fs::create_dir_all(parent).await.ok();
    }
    let snap_text = serde_json::to_string_pretty(&snapshot)?;
    let snap_bytes = snap_text.len() as u64;
    fs::write(&snap_path, &snap_text).await?;
    written.push((snap_path, snap_bytes));
    total_bytes += snap_bytes;

    for pair in pipedrive_deep_exports(runtime.clone(), &site_dir, &prefix, api_token).await? {
        total_bytes += pair.1;
        written.push(pair);
    }

    Ok((
        crate::note_app_common::NoteAppAccountStats {
            service: spec.service_label.to_string(),
            username,
            auth_method,
            inventory_items: items,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}

pub async fn deep_crm_exports(
    service: CrmExportService,
    runtime: Arc<NoteRuntime>,
    cred: &Credential,
    site_dir: &Path,
    prefix: &str,
) -> Result<Vec<(PathBuf, u64)>> {
    match service {
        CrmExportService::Pipedrive => {
            let Some(tok) = pipedrive_api_token_cached(cred) else {
                return Ok(Vec::new());
            };
            pipedrive_deep_exports(runtime, site_dir, prefix, &tok).await
        }
        _ => Ok(Vec::new()),
    }
}
