//! CRM-suite export facade (same stack as notes: reqwest + tokio + moka + proxy).

pub use crate::crm::{
    crm_app_spec, download_crm_export_standalone, download_crm_export_with_runtime,
};
pub use crate::note::{NoteExportClientConfig, NoteRuntime, NoteRuntimeConfig};

use anyhow::Result;
use pma_core::{Credential, CrmExportService};
use std::path::{Path, PathBuf};

pub use crate::note_app_common::NoteAppAccountStats;

pub async fn download_crm_export_account(
    service: CrmExportService,
    cred: &Credential,
    config: &NoteExportClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    download_crm_export_standalone(service, cred, config, output_dir, download_files).await
}
