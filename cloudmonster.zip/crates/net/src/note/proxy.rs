//! Round-robin and random proxy rotation for note-suite reqwest clients.

use rand::Rng;
use reqwest::Proxy;
use std::sync::Arc;
use tokio::sync::Mutex;

#[derive(Debug, Clone)]
pub enum ProxyPick {
    /// `index = (index + 1) % len`
    RoundRobin,
    /// Uniform random entry per pick
    Random,
}

pub struct ProxyManager {
    proxies: Vec<String>,
    current_index: Arc<Mutex<usize>>,
    pick: ProxyPick,
}

impl ProxyManager {
    pub fn new(proxies: Vec<String>) -> Self {
        Self {
            proxies,
            current_index: Arc::new(Mutex::new(0)),
            pick: ProxyPick::RoundRobin,
        }
    }

    pub fn with_pick(proxies: Vec<String>, pick: ProxyPick) -> Self {
        Self {
            proxies,
            current_index: Arc::new(Mutex::new(0)),
            pick,
        }
    }

    pub fn is_empty(&self) -> bool {
        self.proxies.is_empty()
    }

    pub fn len(&self) -> usize {
        self.proxies.len()
    }

    pub async fn get_proxy(&self) -> Option<String> {
        if self.proxies.is_empty() {
            return None;
        }
        match self.pick {
            ProxyPick::RoundRobin => {
                let mut index = self.current_index.lock().await;
                let proxy = self.proxies.get(*index).cloned();
                *index = (*index + 1) % self.proxies.len();
                proxy
            }
            ProxyPick::Random => {
                let idx = rand::thread_rng().gen_range(0..self.proxies.len());
                self.proxies.get(idx).cloned()
            }
        }
    }

    /// Build reqwest proxy for the next rotated URL (socks/http URL as stored in list).
    pub async fn next_reqwest_proxy(&self) -> Option<Proxy> {
        let url = self.get_proxy().await?;
        Proxy::all(url).ok()
    }
}

/// Build rotating proxy manager from single URL and/or list (list wins when non-empty).
pub fn proxy_manager_from_run(
    single: Option<&str>,
    list: Option<&Arc<Vec<String>>>,
) -> Option<Arc<ProxyManager>> {
    if let Some(list) = list {
        if !list.is_empty() {
            return Some(Arc::new(ProxyManager::new(list.as_ref().clone())));
        }
    }
    if let Some(s) = single {
        let t = s.trim();
        if !t.is_empty() {
            return Some(Arc::new(ProxyManager::new(vec![t.to_string()])));
        }
    }
    None
}
