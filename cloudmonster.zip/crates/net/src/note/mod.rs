//! Note-suite stack: reqwest + tokio + moka cache + proxy rotation + rayon (manifest CPU).

mod cache;
mod cf;
pub mod export;
mod html;
mod proxy;
mod runtime;
mod specs;

pub use cache::NoteResponseCache;
pub use html::{estimate_html_inventory_items, html_document_title, looks_like_login_page as html_looks_like_login};
pub use cf::{apply_cloudflare_headers, looks_like_cloudflare_challenge, note_fetch_text};
pub use export::{
    download_note_export_standalone, download_note_export_with_runtime, download_with_runtime,
};
pub use proxy::{proxy_manager_from_run, ProxyManager, ProxyPick};
pub use runtime::{NoteRuntime, NoteRuntimeConfig};
pub use specs::note_app_spec;

pub use crate::note_app_common::{NoteAppAccountStats, NoteAppClientConfig, NoteAppSpec};

/// Alias used by GUI / app orchestration.
pub use crate::note_app_common::NoteAppClientConfig as NoteExportClientConfig;
