//! Moka sync cache for note-suite API JSON (1h TTL, 10k entries).

use moka::sync::Cache;
use serde_json::Value;
use std::sync::Arc;
use std::time::Duration;

const DEFAULT_CAPACITY: u64 = 10_000;
const DEFAULT_TTL_SECS: u64 = 3600;

#[derive(Clone)]
pub struct NoteResponseCache {
    cache: Cache<String, Value>,
    body_cache: Cache<String, Arc<str>>,
}

impl NoteResponseCache {
    pub fn new() -> Self {
        Self::with_capacity_and_ttl(DEFAULT_CAPACITY, Duration::from_secs(DEFAULT_TTL_SECS))
    }

    pub fn with_capacity_and_ttl(max_capacity: u64, ttl: Duration) -> Self {
        let cache = Cache::builder()
            .max_capacity(max_capacity)
            .time_to_live(ttl)
            .build();
        let body_cache = Cache::builder()
            .max_capacity(max_capacity)
            .time_to_live(ttl)
            .build();
        Self { cache, body_cache }
    }

    pub fn get_json(&self, key: &str) -> Option<Value> {
        self.cache.get(key)
    }

    pub fn set_json(&self, key: String, value: Value) {
        self.cache.insert(key, value);
    }

    pub fn get_body(&self, key: &str) -> Option<String> {
        self.body_cache.get(key).map(|s| s.to_string())
    }

    pub fn set_body(&self, key: String, body: impl Into<String>) {
        self.body_cache.insert(key, Arc::from(body.into().as_str()));
    }
}

impl Default for NoteResponseCache {
    fn default() -> Self {
        Self::new()
    }
}
