//! HTML helpers for note-suite (scraper / causal-agent).

use scraper::{Html, Selector};

/// Detect login / signup pages via DOM (more reliable than substring heuristics).
pub fn looks_like_login_page(html: &str) -> bool {
    if html.len() > 500_000 {
        return false;
    }
    let document = Html::parse_document(html);
    let password = Selector::parse("input[type='password']").ok();
    let email = Selector::parse("input[type='email'], input[name='email'], input[name='username']").ok();
    let has_password = password
        .map(|sel| document.select(&sel).next().is_some())
        .unwrap_or(false);
    if !has_password {
        return false;
    }
    let has_user = email
        .map(|sel| document.select(&sel).next().is_some())
        .unwrap_or(false);
    if has_user {
        return true;
    }
    let lower = html.to_ascii_lowercase();
    lower.contains("sign in") || lower.contains("log in") || lower.contains("login")
}

/// Rough inventory size from list/table/note-like nodes in HTML dashboards.
pub fn estimate_html_inventory_items(html: &str) -> usize {
    let document = Html::parse_document(html);
    let selectors = [
        "tr[data-id]",
        "li[data-id]",
        "[data-note-id]",
        "[data-item-id]",
        "article",
        ".note-list-item",
        ".list-item",
    ];
    let mut best = 0usize;
    for sel_str in selectors {
        let Ok(sel) = Selector::parse(sel_str) else {
            continue;
        };
        best = best.max(document.select(&sel).count());
    }
    best
}

/// Extract `<title>` for session display name fallback.
pub fn html_document_title(html: &str) -> Option<String> {
    let document = Html::parse_document(html);
    let title_sel = Selector::parse("title").ok()?;
    document
        .select(&title_sel)
        .next()
        .map(|n| n.text().collect::<String>().trim().to_string())
        .filter(|t| !t.is_empty())
}
