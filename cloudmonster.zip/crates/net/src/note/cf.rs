//! Cloudflare challenge detection + bypass (Anorov cfscrape → cloudscraper → ghostwire).

use anyhow::{Context, Result};
use ghostwire::Ghostwire;
use reqwest::header::{HeaderMap, HeaderValue, COOKIE, USER_AGENT};
use reqwest::{Client, Url};

/// Typical CF interstitial / block page markers.
pub fn looks_like_cloudflare_challenge(body: &str, status: reqwest::StatusCode) -> bool {
    if status.as_u16() == 403 || status.as_u16() == 503 || status.as_u16() == 429 {
        return true;
    }
    let lower = body.to_ascii_lowercase();
    lower.contains("cf-browser-verification")
        || lower.contains("challenge-platform")
        || lower.contains("just a moment")
        || lower.contains("attention required")
        || lower.contains("/cdn-cgi/challenge-platform/")
}

pub fn apply_cloudflare_headers(headers: &mut HeaderMap, cookie: &str, user_agent: &str) {
    if let Ok(v) = HeaderValue::from_str(cookie) {
        headers.insert(COOKIE, v);
    }
    if let Ok(v) = HeaderValue::from_str(user_agent) {
        headers.insert(USER_AGENT, v);
    }
}

/// GET with reqwest; on CF page, retry via ghostwire (Rust cloudscraper / Anorov lineage).
pub async fn note_fetch_text(
    client: &Client,
    url: Url,
    bearer: Option<&str>,
) -> Result<String> {
    let mut req = client.get(url.clone());
    if let Some(tok) = bearer {
        req = req.header("Authorization", format!("Bearer {tok}"));
    }
    let resp = req.send().await.context("note GET")?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if status.is_success() && !looks_like_cloudflare_challenge(&body, status) {
        return Ok(body);
    }
    if looks_like_cloudflare_challenge(&body, status) {
        if let Ok(text) = ghostwire_fetch(&url).await {
            if !text.is_empty() && !looks_like_cloudflare_challenge(&text, reqwest::StatusCode::OK) {
                return Ok(text);
            }
        }
    }
    if status.is_success() {
        return Ok(body);
    }
    anyhow::bail!("HTTP {} for {} (cloudflare bypass failed)", status, url)
}

/// GET returning status + body (used for session probes — 401/404 JSON still parsed).
pub async fn note_fetch_any(
    client: &Client,
    url: Url,
    bearer: Option<&str>,
) -> Result<(reqwest::StatusCode, String)> {
    let mut req = client.get(url.clone());
    if let Some(tok) = bearer {
        req = req.header("Authorization", format!("Bearer {tok}"));
    }
    let resp = req.send().await.context("note GET")?;
    let status = resp.status();
    let body = resp.text().await.unwrap_or_default();
    if looks_like_cloudflare_challenge(&body, status) {
        if let Ok(text) = ghostwire_fetch(&url).await {
            if !text.is_empty() && !looks_like_cloudflare_challenge(&text, reqwest::StatusCode::OK) {
                return Ok((reqwest::StatusCode::OK, text));
            }
        }
    }
    Ok((status, body))
}

async fn ghostwire_fetch(url: &Url) -> Result<String> {
    let mut gw = Ghostwire::new().context("ghostwire client")?;
    let resp = gw.get(url.as_str()).await.context("ghostwire GET")?;
    resp.text().await.context("ghostwire body")
}
