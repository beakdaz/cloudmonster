//! Per-service HTTP paths and labels for the note suite.

use crate::note_app_common::NoteAppSpec;
use pma_core::NoteExportService;

pub fn note_app_spec(service: NoteExportService) -> &'static NoteAppSpec {
    use NoteExportService as S;
    static OBSIDIAN: NoteAppSpec = NoteAppSpec {
        service_label: "Obsidian",
        output_slug: "obsidian",
        user_agent: "cloudmonster-obsidian/0.1",
        login_paths: &["account", "login", ""],
        post_paths: &["api/auth/login", "login"],
        json_login_paths: &["api/auth/login"],
        success_probe_paths: &["account", ""],
        inventory_api_paths: &["api/vault/list", "api/sync/status"],
    };
    static DYNALIST: NoteAppSpec = NoteAppSpec {
        service_label: "Dynalist",
        output_slug: "dynalist",
        user_agent: "cloudmonster-dynalist/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/v1/auth/login", "login"],
        json_login_paths: &["api/v1/auth/login", "api/login"],
        success_probe_paths: &["api/v1/doc/list", "app", ""],
        inventory_api_paths: &["api/v1/doc/list", "api/v1/file/list"],
    };
    static CAPACITIES: NoteAppSpec = NoteAppSpec {
        service_label: "Capacities",
        output_slug: "capacities",
        user_agent: "cloudmonster-capacities/0.1",
        login_paths: &["login", "auth", ""],
        post_paths: &["api/auth/login", "api/login"],
        json_login_paths: &["api/auth/login", "api/v1/auth/login"],
        success_probe_paths: &["api/spaces", "app", ""],
        inventory_api_paths: &["api/spaces", "api/objects", "api/export"],
    };
    static GNOTES: NoteAppSpec = NoteAppSpec {
        service_label: "GNotes",
        output_slug: "gnotes",
        user_agent: "cloudmonster-gnotes/0.1",
        login_paths: &["login", "signin", ""],
        post_paths: &["api/login", "api/auth/login", "login"],
        json_login_paths: &["api/login", "api/user/login"],
        success_probe_paths: &["api/notes", "api/notebooks", ""],
        inventory_api_paths: &["api/notes", "api/notebooks", "api/sync"],
    };
    static JOPLIN: NoteAppSpec = NoteAppSpec {
        service_label: "Joplin",
        output_slug: "joplin",
        user_agent: "cloudmonster-joplin/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/sessions", "login"],
        json_login_paths: &["api/sessions", "api/auth/login"],
        success_probe_paths: &["api/items", "api/folders", ""],
        inventory_api_paths: &["api/items", "api/folders", "api/tags"],
    };
    static KORTEX: NoteAppSpec = NoteAppSpec {
        service_label: "Kortex",
        output_slug: "kortex",
        user_agent: "cloudmonster-kortex/0.1",
        login_paths: &["login", "auth", ""],
        post_paths: &["api/auth/login", "login"],
        json_login_paths: &["api/auth/login", "api/login"],
        success_probe_paths: &["api/documents", "app", ""],
        inventory_api_paths: &["api/documents", "api/collections"],
    };
    static MINDLOG: NoteAppSpec = NoteAppSpec {
        service_label: "Mindlog",
        output_slug: "mindlog",
        user_agent: "cloudmonster-mindlog/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/auth/login", "login"],
        json_login_paths: &["api/auth/login", "api/login"],
        success_probe_paths: &["api/entries", "api/logs", ""],
        inventory_api_paths: &["api/entries", "api/logs", "api/export"],
    };
    static NOTEJOY: NoteAppSpec = NoteAppSpec {
        service_label: "Notejoy",
        output_slug: "notejoy",
        user_agent: "cloudmonster-notejoy/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/login", "login"],
        json_login_paths: &["api/login", "api/auth"],
        success_probe_paths: &["api/notes", "api/libraries", ""],
        inventory_api_paths: &["api/notes", "api/libraries", "api/search"],
    };
    static NOTESNOOK: NoteAppSpec = NoteAppSpec {
        service_label: "Notesnook",
        output_slug: "notesnook",
        user_agent: "cloudmonster-notesnook/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/v1/session", "api/login", "login"],
        json_login_paths: &["api/v1/session", "api/v1/auth/login", "api/login"],
        success_probe_paths: &["api/v1/notes", "api/v1/notebooks", ""],
        inventory_api_paths: &["api/v1/notes", "api/v1/notebooks", "api/v1/attachments"],
    };
    static STANDARD_NOTES: NoteAppSpec = NoteAppSpec {
        service_label: "Standard Notes",
        output_slug: "standardnotes",
        user_agent: "cloudmonster-standardnotes/0.1",
        login_paths: &["login", ""],
        post_paths: &["v1/users/sign_in", "api/auth/sign_in", "login"],
        json_login_paths: &["v1/users/sign_in", "api/v1/login", "api/auth/sign_in"],
        success_probe_paths: &["v1/items", "api/v1/items", ""],
        inventory_api_paths: &["v1/items", "api/v1/items", "v1/extensions"],
    };
    static TODOIST: NoteAppSpec = NoteAppSpec {
        service_label: "Todoist",
        output_slug: "todoist",
        user_agent: "cloudmonster-todoist/0.1",
        login_paths: &["users/showlogin", "login", ""],
        post_paths: &["api/v1/user/login", "login"],
        json_login_paths: &["api/v1/user/login", "api/v1/access_tokens"],
        success_probe_paths: &["api/v1/projects", "api/v1/sync", ""],
        inventory_api_paths: &[
            "api/v1/projects",
            "api/v1/tasks",
            "api/v1/labels",
            "sync/v9/sync",
        ],
    };
    static TURTL: NoteAppSpec = NoteAppSpec {
        service_label: "Turtl",
        output_slug: "turtl",
        user_agent: "cloudmonster-turtl/0.1",
        login_paths: &["users/login", "login", ""],
        post_paths: &["users/login", "api/login"],
        json_login_paths: &["users/login", "api/users/login"],
        success_probe_paths: &["notes", "api/notes", ""],
        inventory_api_paths: &["notes", "api/notes", "api/sync"],
    };
    static ZOTERO: NoteAppSpec = NoteAppSpec {
        service_label: "Zotero",
        output_slug: "zotero",
        user_agent: "cloudmonster-zotero/0.1",
        login_paths: &["user/login", "login", ""],
        post_paths: &["user/login", "api/login"],
        json_login_paths: &["api/users/login"],
        success_probe_paths: &["api/users/0/items", "api/keys", ""],
        inventory_api_paths: &["api/users/0/items", "api/users/0/collections", "api/keys"],
    };

    match service {
        S::Obsidian => &OBSIDIAN,
        S::Dynalist => &DYNALIST,
        S::Capacities => &CAPACITIES,
        S::Gnotes => &GNOTES,
        S::Joplin => &JOPLIN,
        S::Kortex => &KORTEX,
        S::Mindlog => &MINDLOG,
        S::Notejoy => &NOTEJOY,
        S::Notesnook => &NOTESNOOK,
        S::StandardNotes => &STANDARD_NOTES,
        S::Todoist => &TODOIST,
        S::Turtl => &TURTL,
        S::Zotero => &ZOTERO,
    }
}
