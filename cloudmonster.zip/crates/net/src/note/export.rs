//! Note account check/export (reqwest + tokio + moka + rayon).

use crate::note::html::{estimate_html_inventory_items, html_document_title};
use crate::note::runtime::{NoteRuntime, NoteRuntimeConfig};
use crate::note::specs::note_app_spec;
use crate::note_app_common::{NoteAppAccountStats, NoteAppClientConfig, NoteAppSpec};
use crate::note_export_deep::deep_note_exports;
use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, Credential, NoteExportService};
use reqwest::Url;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;
use tokio::fs;
use tokio::sync::Semaphore;
use tokio::task::JoinSet;

pub async fn download_note_export_standalone(
    service: NoteExportService,
    cred: &Credential,
    config: &NoteAppClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let spec = note_app_spec(service);
    let runtime = Arc::new(NoteRuntime::new(
        NoteRuntimeConfig::from_legacy(config.timeout, config.insecure),
        spec.user_agent,
        None,
    )?);
    download_note_export_with_runtime(service, cred, runtime, output_dir, download_files).await
}

pub async fn download_note_export_with_runtime(
    service: NoteExportService,
    cred: &Credential,
    runtime: Arc<NoteRuntime>,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let spec = note_app_spec(service);
    let (mut stats, mut files) =
        download_with_runtime(cred, runtime.clone(), output_dir, download_files, spec).await?;

    if download_files
        && matches!(
            service,
            NoteExportService::Todoist | NoteExportService::Joplin | NoteExportService::Zotero
        )
    {
        let site_dir = cred.site_output_dir(output_dir, spec.output_slug);
        let prefix = cred.account_file_prefix();
        if let Ok(http) = runtime.client().await {
            if let Ok(extra) = deep_note_exports(service, &http, cred, &site_dir, &prefix).await {
                for (path, size) in extra {
                    stats.bytes += size;
                    files.push((path, size));
                }
                stats.downloaded = files.len();
                stats.inventory_items = stats.inventory_items.max(files.len());
            }
        }
    }
    Ok((stats, files))
}

pub async fn download_with_runtime(
    cred: &Credential,
    runtime: Arc<NoteRuntime>,
    output_dir: &Path,
    download_files: bool,
    spec: &NoteAppSpec,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let base = cred.url.clone();
    let http = runtime.client().await?;
    let mut auth_method = "none".to_string();
    let password_trim = cred.password.trim();
    let bearer_token = password_trim
        .strip_prefix("token:")
        .or_else(|| password_trim.strip_prefix("api:"))
        .map(str::trim)
        .filter(|t| t.len() >= 8);

    let mut session_user = String::new();
    let mut items = 0usize;

    if let Some(tok) = bearer_token {
        if let Ok((u, n)) = try_bearer_session(&runtime, &base, tok, spec.success_probe_paths).await
        {
            auth_method = "bearer-token".into();
            session_user = u;
            items = n;
        }
    }

    if auth_method == "none" {
        let (su, n, method) = authenticate_password_session(
            &http,
            &runtime,
            &base,
            &cred.username,
            &cred.password,
            spec,
        )
        .await
        .context(format!(
            "{} login failed for {}",
            spec.service_label,
            cred.display_line()
        ))?;
        auth_method = method;
        session_user = su;
        items = n;
    }

    let username = if session_user.is_empty() || session_user == "session" {
        cred.username.clone()
    } else {
        session_user
    };

    if !download_files {
        return Ok((
            NoteAppAccountStats {
                service: spec.service_label.to_string(),
                username,
                auth_method,
                inventory_items: items,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, spec.output_slug);
    let prefix = cred.account_file_prefix();
    let mut written = Vec::new();
    let mut total_bytes = 0u64;

    let snapshot = json!({
        "service": spec.service_label,
        "url": base.as_str(),
        "user": username,
        "auth_method": auth_method,
        "inventory_items": items,
    });
    push_json_file(&site_dir, &prefix, "snapshot", &snapshot, &mut written, &mut total_bytes)
        .await?;

    let html = format!(
        r#"<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>{title}</title></head>
<body>
<h1>{title}</h1>
<p>URL: {url}</p>
<p>User: {user}</p>
<p>Auth: {auth}</p>
<p>Inventory items (estimate): {items}</p>
</body></html>"#,
        title = html_escape(spec.service_label),
        url = html_escape(base.as_str()),
        user = html_escape(&username),
        auth = html_escape(&auth_method),
        items = items,
    );
    let html_path = output_file_path(&site_dir, &format!("{prefix}__inventory.html"));
    fs::write(&html_path, &html).await?;
    let hb = html.len() as u64;
    total_bytes += hb;
    written.push((html_path, hb));

    let api_files = fetch_inventory_parallel(
        runtime.clone(),
        base.clone(),
        spec,
        site_dir.clone(),
        prefix.clone(),
        bearer_token,
    )
    .await;
    for (p, n) in api_files {
        total_bytes += n;
        written.push((p, n));
    }
    items = items.max(written.len().saturating_sub(2));

    let manifest = json!({
        "service": spec.service_label,
        "files": written.iter().map(|(p, n)| json!({
            "path": p.file_name().and_then(|s| s.to_str()).unwrap_or(""),
            "bytes": n,
        })).collect::<Vec<_>>(),
        "total_bytes": total_bytes,
    });
    let manifest_text = tokio::task::spawn_blocking(move || {
        serde_json::to_string_pretty(&manifest).context("manifest json")
    })
    .await
    .context("manifest task")??;
    let manifest_path = output_file_path(&site_dir, &format!("{prefix}__files.manifest.json"));
    fs::write(&manifest_path, &manifest_text).await?;
    let mb = manifest_text.len() as u64;
    total_bytes += mb;
    written.push((manifest_path, mb));

    Ok((
        NoteAppAccountStats {
            service: spec.service_label.to_string(),
            username,
            auth_method,
            inventory_items: items,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}

async fn push_json_file(
    site_dir: &Path,
    prefix: &str,
    name: &str,
    value: &Value,
    written: &mut Vec<(PathBuf, u64)>,
    total_bytes: &mut u64,
) -> Result<()> {
    let path = output_file_path(site_dir, &format!("{prefix}__{name}.json"));
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await.ok();
    }
    let text = tokio::task::spawn_blocking({
        let value = value.clone();
        move || serde_json::to_string_pretty(&value)
    })
    .await??;
    let n = text.len() as u64;
    fs::write(&path, &text).await?;
    *total_bytes += n;
    written.push((path, n));
    Ok(())
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn is_login_page(body: &str) -> bool {
    crate::note::html::looks_like_login_page(body)
        || {
            let lower = body.to_ascii_lowercase();
            lower.contains("sign in")
                || lower.contains("log in")
                || lower.contains("login")
        } && body.len() < 80_000
}

async fn authenticate_password_session(
    http: &reqwest::Client,
    runtime: &NoteRuntime,
    base: &Url,
    username: &str,
    password: &str,
    spec: &NoteAppSpec,
) -> Result<(String, usize, String)> {
    let _ = runtime.fetch_any(base.clone(), None).await;
    tokio::time::sleep(Duration::from_millis(250)).await;

    if let Some((user, items)) =
        attempt_json_login_posts(http, base, username, password, spec.json_login_paths).await
    {
        return Ok((user, items, "json-login".into()));
    }
    if let Ok((user, items)) =
        verify_authenticated_session(runtime, base, spec.success_probe_paths, username).await
    {
        return Ok((user, items, "json-login".into()));
    }

    if let Some((user, items)) = attempt_form_login_posts(
        http,
        base,
        username,
        password,
        spec.login_paths,
        spec.post_paths,
    )
    .await
    {
        return Ok((user, items, "form-session".into()));
    }
    let (user, items) =
        verify_authenticated_session(runtime, base, spec.success_probe_paths, username).await?;
    Ok((user, items, "form-session".into()))
}

async fn attempt_json_login_posts(
    http: &reqwest::Client,
    base: &Url,
    username: &str,
    password: &str,
    paths: &[&str],
) -> Option<(String, usize)> {
    for path in paths {
        let Ok(url) = base.join(path.trim_start_matches('/')) else {
            continue;
        };
        for body in [
            json!({"email": username, "password": password}),
            json!({"username": username, "password": password}),
            json!({"login": username, "password": password}),
        ] {
            let Ok(resp) = http.post(url.clone()).json(&body).send().await else {
                continue;
            };
            let text = resp.text().await.unwrap_or_default();
            if let Some(pair) = score_login_response(&text, username) {
                return Some(pair);
            }
        }
    }
    None
}

async fn attempt_form_login_posts(
    http: &reqwest::Client,
    base: &Url,
    username: &str,
    password: &str,
    login_paths: &[&str],
    post_paths: &[&str],
) -> Option<(String, usize)> {
    for login_path in login_paths {
        let Ok(page_url) = base.join(login_path.trim_start_matches('/')) else {
            continue;
        };
        let _ = http.get(page_url.clone()).send().await;
        for post_path in post_paths {
            let Ok(post_url) = base.join(post_path.trim_start_matches('/')) else {
                continue;
            };
            for fields in [
                [("email", username), ("password", password)],
                [("username", username), ("password", password)],
                [("login", username), ("password", password)],
            ] {
                let Ok(resp) = http.post(post_url.clone()).form(&fields).send().await else {
                    continue;
                };
                let text = resp.text().await.unwrap_or_default();
                if let Some(pair) = score_login_response(&text, username) {
                    return Some(pair);
                }
            }
        }
    }
    None
}

fn json_indicates_auth_failure(v: &Value) -> bool {
    if let Some(code) = v.get("code").and_then(|c| c.as_i64()) {
        if code != 0 && code != 200 {
            return true;
        }
    }
    if let Some(err) = v.get("error") {
        if !(err.is_null() || err.as_str().is_some_and(|s| s.is_empty())) {
            return true;
        }
    }
    if v.get("success") == Some(&Value::Bool(false)) {
        return true;
    }
    if matches!(v.get("authenticated"), Some(Value::Bool(false))) {
        return true;
    }
    let msg = v
        .get("message")
        .or_else(|| v.get("msg"))
        .and_then(|m| m.as_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    msg.contains("unauthorized")
        || msg.contains("invalid password")
        || msg.contains("invalid credentials")
        || msg.contains("wrong password")
        || msg.contains("login required")
        || msg.contains("not logged")
}

fn user_from_json(v: &Value) -> Option<String> {
    v.pointer("/user/email")
        .or_else(|| v.pointer("/data/user/email"))
        .or_else(|| v.pointer("/data/email"))
        .or_else(|| v.pointer("/email"))
        .or_else(|| v.pointer("/user/name"))
        .or_else(|| v.pointer("/name"))
        .and_then(|x| x.as_str())
        .map(str::to_string)
}

fn score_login_response(body: &str, username: &str) -> Option<(String, usize)> {
    let trimmed = body.trim();
    if !trimmed.starts_with('{') {
        return None;
    }
    let v = serde_json::from_str::<Value>(trimmed).ok()?;
    if json_indicates_auth_failure(&v) {
        return None;
    }
    let has_token = v.get("token").is_some()
        || v.get("access_token").is_some()
        || v.pointer("/data/token").is_some()
        || v.pointer("/data/accessToken").is_some();
    let code_ok = matches!(v.get("code").and_then(|c| c.as_i64()), Some(0) | Some(200));
    let success = v.get("success").and_then(|b| b.as_bool()) == Some(true);
    if !(has_token || success || code_ok) {
        return None;
    }
    let user = user_from_json(&v).unwrap_or_else(|| username.to_string());
    Some((user, 1))
}

fn html_shows_logged_in_user(body: &str, username: &str) -> bool {
    if username.is_empty() || body.len() < 400 || is_login_page(body) {
        return false;
    }
    body.to_ascii_lowercase()
        .contains(&username.to_ascii_lowercase())
}

fn login_matches(found: &str, expected: &str) -> bool {
    if found.eq_ignore_ascii_case(expected) {
        return true;
    }
    let fe = found.to_ascii_lowercase();
    let ee = expected.to_ascii_lowercase();
    fe == ee || (ee.contains('@') && fe.contains('@') && fe == ee)
}

/// Confirmed session: JSON API success, or HTML app with real list nodes (not bare marketing pages).
fn score_session_body(body: &str, expected_login: &str) -> Option<(String, usize)> {
    if body.trim().is_empty() || is_login_page(body) {
        return None;
    }
    let trimmed = body.trim_start();
    if trimmed.starts_with('{') || trimmed.starts_with('[') {
        let v = serde_json::from_str::<Value>(body).ok()?;
        if json_indicates_auth_failure(&v) {
            return None;
        }
        let mut items = v
            .get("data")
            .and_then(|d| d.as_array())
            .map(|a| a.len())
            .or_else(|| v.as_array().map(|a| a.len()))
            .unwrap_or(0);
        let has_token = v.get("token").is_some()
            || v.get("access_token").is_some()
            || v.pointer("/data/token").is_some();
        let user = user_from_json(&v).unwrap_or_default();
        let explicit_ok = v.get("success").and_then(|b| b.as_bool()) == Some(true);
        let authenticated = has_token || explicit_ok || !user.is_empty() || items > 0;
        if !authenticated {
            return None;
        }
        if !user.is_empty() && !expected_login.is_empty() && !login_matches(&user, expected_login) {
            return None;
        }
        let display = if user.is_empty() {
            expected_login.to_string()
        } else {
            user
        };
        if items == 0 && (has_token || explicit_ok || !display.is_empty()) {
            items = 1;
        }
        return Some((display, items));
    }
    let items = estimate_html_inventory_items(body);
    if items > 0 {
        let display = html_document_title(body).unwrap_or_else(|| expected_login.to_string());
        return Some((display, items));
    }
    if html_shows_logged_in_user(body, expected_login) {
        return Some((expected_login.to_string(), 1));
    }
    None
}

async fn verify_authenticated_session(
    runtime: &NoteRuntime,
    base: &Url,
    probes: &[&str],
    expected_login: &str,
) -> Result<(String, usize)> {
    let mut last_status = String::new();
    for path in probes {
        if path.trim().is_empty() {
            continue;
        }
        let Ok(url) = base.join(path.trim_start_matches('/')) else {
            continue;
        };
        let probe = url.to_string();
        let (status, body) = match runtime.fetch_any(url, None).await {
            Ok(pair) => pair,
            Err(e) => {
                last_status = e.to_string();
                continue;
            }
        };
        last_status = format!("HTTP {} {}", status.as_u16(), probe);
        if let Some(pair) = score_session_body(&body, expected_login) {
            return Ok(pair);
        }
    }
    bail!(
        "authenticated session not confirmed ({})",
        if last_status.is_empty() {
            "no probe response".into()
        } else {
            last_status
        }
    )
}

async fn try_bearer_session(
    runtime: &NoteRuntime,
    base: &Url,
    token: &str,
    probes: &[&str],
) -> Result<(String, usize)> {
    for path in probes {
        let Ok(url) = base.join(path.trim_start_matches('/')) else {
            continue;
        };
        let (_status, body) = runtime.fetch_any(url, Some(token)).await?;
        if let Some((user, items)) = score_session_body(&body, "") {
            let name = if user.is_empty() {
                "token-session".to_string()
            } else {
                user
            };
            return Ok((name, items));
        }
    }
    bail!("bearer session probe failed")
}

fn api_path_slug(path: &str) -> String {
    path.trim_start_matches('/')
        .replace('/', "_")
        .replace(['?', '&', '='], "_")
}

async fn fetch_inventory_parallel(
    runtime: Arc<NoteRuntime>,
    base: Url,
    spec: &NoteAppSpec,
    site_dir: PathBuf,
    prefix: String,
    bearer: Option<&str>,
) -> Vec<(PathBuf, u64)> {
    let sem = Arc::new(Semaphore::new(
        runtime.config().http_concurrency.max(1),
    ));
    let mut set = JoinSet::new();
    for path in spec.inventory_api_paths {
        let Ok(url) = base.join(path.trim_start_matches('/')) else {
            continue;
        };
        let rt = runtime.clone();
        let site_dir = site_dir.clone();
        let prefix = prefix.clone();
        let slug = api_path_slug(path);
        let bearer = bearer.map(str::to_string);
        let sem = sem.clone();
        set.spawn(async move {
            let _permit = sem.acquire_owned().await.ok()?;
            let body = rt
                .get_text_cached(url, bearer.as_deref(), true)
                .await
                .ok()?;
            if body.is_empty() || is_login_page(&body) {
                return None;
            }
            let file_path = output_file_path(&site_dir, &format!("{prefix}__api_{slug}.json"));
            if let Some(parent) = file_path.parent() {
                fs::create_dir_all(parent).await.ok();
            }
            fs::write(&file_path, &body).await.ok()?;
            Some((file_path, body.len() as u64))
        });
    }
    let mut out = Vec::new();
    while let Some(res) = set.join_next().await {
        if let Ok(Some(pair)) = res {
            out.push(pair);
        }
    }
    out
}
