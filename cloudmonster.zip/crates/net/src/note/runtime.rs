//! Shared reqwest client, moka cache, optional proxy rotation.

use crate::note::cache::NoteResponseCache;
use crate::note::cf::{note_fetch_any, note_fetch_text};
use crate::note::proxy::ProxyManager;
use anyhow::{Context, Result};
use reqwest::{Client, Url};
use std::sync::Arc;
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct NoteRuntimeConfig {
    pub timeout: Duration,
    pub insecure: bool,
    pub cache_ttl: Duration,
    pub cache_capacity: u64,
    pub http_concurrency: usize,
}

impl NoteRuntimeConfig {
    pub fn from_legacy(timeout: Duration, insecure: bool) -> Self {
        Self {
            timeout,
            insecure,
            cache_ttl: Duration::from_secs(3600),
            cache_capacity: 10_000,
            http_concurrency: 8,
        }
    }
}

pub struct NoteRuntime {
    client: Client,
    cache: Arc<NoteResponseCache>,
    proxy_manager: Option<Arc<ProxyManager>>,
    config: NoteRuntimeConfig,
    user_agent: String,
}

const NOTE_BROWSER_USER_AGENT: &str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

impl NoteRuntime {
    pub fn new(
        config: NoteRuntimeConfig,
        user_agent: impl Into<String>,
        proxy_manager: Option<Arc<ProxyManager>>,
    ) -> Result<Self> {
        let ua = user_agent.into();
        let user_agent = if ua.starts_with("cloudmonster-") {
            NOTE_BROWSER_USER_AGENT.to_string()
        } else {
            ua
        };
        let client = Self::build_client(&config, &user_agent, None)?;
        let cache = Arc::new(NoteResponseCache::with_capacity_and_ttl(
            config.cache_capacity,
            config.cache_ttl,
        ));
        Ok(Self {
            client,
            cache,
            proxy_manager,
            config,
            user_agent,
        })
    }

    fn build_client(
        config: &NoteRuntimeConfig,
        user_agent: &str,
        proxy_url: Option<&str>,
    ) -> Result<Client> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(8))
            .timeout(config.timeout)
            .user_agent(user_agent);
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        if let Some(p) = proxy_url {
            if let Ok(px) = reqwest::Proxy::all(p) {
                builder = builder.proxy(px);
            }
        }
        builder.build().context("note reqwest client")
    }

    pub async fn client(&self) -> Result<Client> {
        if let Some(pm) = &self.proxy_manager {
            if let Some(url) = pm.get_proxy().await {
                return Self::build_client(&self.config, &self.user_agent, Some(&url));
            }
        }
        Ok(self.client.clone())
    }

    pub fn cache(&self) -> &NoteResponseCache {
        &self.cache
    }

    pub fn config(&self) -> &NoteRuntimeConfig {
        &self.config
    }

    fn cache_key(method: &str, url: &Url, auth_tag: &str) -> String {
        format!("{method}:{url}:{auth_tag}")
    }

    pub async fn get_text_cached(
        &self,
        url: Url,
        bearer: Option<&str>,
        use_cache: bool,
    ) -> Result<String> {
        let auth_tag = bearer.unwrap_or("");
        let key = Self::cache_key("GET", &url, auth_tag);
        if use_cache {
            if let Some(hit) = self.cache.get_body(&key) {
                return Ok(hit);
            }
        }
        let http = self.client().await?;
        let body = note_fetch_text(&http, url.clone(), bearer).await?;
        if use_cache && !body.is_empty() {
            self.cache.set_body(key, body.clone());
        }
        Ok(body)
    }

    pub async fn fetch_any(
        &self,
        url: Url,
        bearer: Option<&str>,
    ) -> Result<(reqwest::StatusCode, String)> {
        let http = self.client().await?;
        note_fetch_any(&http, url, bearer).await
    }
}
