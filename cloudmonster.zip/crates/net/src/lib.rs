//! HTTP client for phpMyAdmin login, database enumeration, and SQL export.
//!
//! Source inspiration: phpMyAdmin Exploiter scan/export workflow and sqldump-tool.

mod adminer;
mod appflowy;
mod bamboo;
mod bitbucket;
mod bitrix;
mod client;
mod citrix;
mod cloud;
mod confluence;
mod concurrency;
mod fortinet;
mod rdweb;
mod gitlab;
mod html;
mod http_client;
mod proxy_scraper;
mod jenkins;
mod jira;
mod note_app_common;
mod opencart;
mod redmine;
mod roamresearch;
mod secondbrain;
mod snowflake;
mod services_add;
mod mega;
mod note;
mod note_export;
mod note_export_deep;
mod crm;
mod crm_export;
mod crm_export_deep;
mod workflowy;
mod xwiki;
mod phppgadmin;
mod slack;
mod stats_display;

pub use appflowy::{download_appflowy_account, AppflowyClientConfig};
pub use confluence::{
    download_confluence_account, ConfluenceAccountStats, ConfluenceClientConfig,
};
pub use opencart::{download_opencart_account, OpencartAccountStats, OpencartClientConfig};
pub use roamresearch::{download_roamresearch_account, RoamresearchClientConfig};
pub use secondbrain::{download_secondbrain_account, SecondbrainClientConfig};
pub use workflowy::{download_workflowy_account, WorkflowyClientConfig};
pub use note_export::{download_note_export_account, NoteExportClientConfig};
pub use crm_export::{download_crm_export_account, download_crm_export_with_runtime, crm_app_spec};
pub use note::{
    download_note_export_with_runtime, note_app_spec, NoteResponseCache, NoteRuntime, NoteRuntimeConfig,
    proxy_manager_from_run, ProxyManager, ProxyPick,
};
pub use note_app_common::NoteAppAccountStats;
pub use bamboo::{download_bamboo_account, BambooAccountStats, BambooClientConfig};
pub use bitbucket::{
    download_personal_repos, BitbucketAccountStats, BitbucketClientConfig, BitbucketRepo,
};
pub use bitrix::{
    download_personal_backups, BitrixAccountStats, BitrixBackup, BitrixClientConfig,
};
pub use adminer::{
    download_adminer_account, AdminerAccountStats, AdminerClientConfig,
};
pub use client::{
    download_phpmyadmin_account, dump_databases, scan_credential, LoginOutcome, PhpMyAdminAccountStats,
    PhpMyAdminClient, PhpMyAdminClientConfig,
};
pub use citrix::{download_citrix_account, CitrixAccountStats, CitrixClientConfig};
pub use http_client::{
    base_url_variants, load_proxy_list, load_proxy_list_with, normalize_proxy_field,
    normalize_proxy_line_with, ProxyListFormat, ProxyListScheme, try_http_https_for_cred,
};
pub use proxy_scraper::{
    export_lines, run_parse_harvest_blocking, run_scrape_blocking, write_export_csv,
    write_export_json, write_export_txt, ParseHarvestEvent, ProxyScrapeResult, ScrapeConfig,
    ScrapeEvent,
};
pub use fortinet::{
    download_fortinet_account, FortinetAccountStats, FortinetClientConfig,
};
pub use rdweb::{download_rdweb_account, RdWebAccountStats, RdWebClientConfig};
pub use gitlab::{
    download_personal_projects, GitLabAccountStats, GitLabClientConfig, GitLabProject,
};
pub use jenkins::{
    download_personal_jobs, JenkinsAccountStats, JenkinsClientConfig, JenkinsJob,
};
pub use jira::{download_jira_projects, JiraAccountStats, JiraClientConfig, JiraProject};
pub use redmine::{
    download_redmine_projects, RedmineAccountStats, RedmineClientConfig, RedmineExportOptions,
    RedmineProject,
};
pub use snowflake::{
    download_snowflake_account, SnowflakeAccountStats, SnowflakeClientConfig,
    SnowflakeExportOptions,
};
pub use services_add::{
    download_webapp_account, WebappAccountStats, WebappClientConfig,
};
pub use concurrency::{
    megax_cloud_login_parallel, megax_cloud_workers, megax_curl_parallel,
    megax_mega_login_parallel,
};
pub use cloud::{
    build_reqwest_browser_client, cloud_browser_headers, cloud_client_config_for_index,
    download_cloud_account,
    build_mega_http, download_mega_account, mega_is_banned_anyhow, scan_status_for_mega_anyhow,
    cloud_retryable_with_other_proxy, scan_status_for_mega_error, scan_status_for_cloud_anyhow,
    CloudAccountStats, CloudClientConfig,
    MegaAccountStats, MegaClientConfig, MEGA_LOGIN_CONCURRENCY, CONTENTS_DIR,
};
pub use xwiki::{download_xwiki_content, XWikiAccountStats, XWikiClientConfig, XWikiPage};
pub use slack::{download_slack_exports, SlackAccountStats, SlackChannel, SlackClientConfig};
pub use phppgadmin::{
    download_personal_dumps as download_phppgadmin_dumps, PhpPgAdminAccountStats,
    PhpPgAdminClientConfig,
};
