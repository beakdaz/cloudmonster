//! Runtime tuning via environment (CloudMonster / MEGAX).

/// Read `name` as usize, clamp to `1..=max`, or return `default`.
pub fn env_usize(name: &str, default: usize, max: usize) -> usize {
    std::env::var(name)
        .ok()
        .and_then(|s| s.trim().parse::<usize>().ok())
        .map(|n| n.clamp(1, max))
        .unwrap_or(default)
}

/// Max parallel curl-impersonate subprocesses (global, all providers).
pub fn megax_curl_parallel() -> usize {
    env_usize("MEGAX_CURL_PARALLEL", 32, 128)
}

/// Worker tasks for cloud export pool (UI threads are capped by this).
pub fn megax_cloud_workers(threads: usize) -> usize {
    let cap = env_usize("MEGAX_CLOUD_WORKERS_MAX", 128, 500);
    threads.clamp(1, cap)
}

/// Concurrent login checks per shared `CloudClientConfig` (default: provider spec).
pub fn megax_cloud_login_parallel(provider_default: usize, checker_threads: usize) -> usize {
    let cap = env_usize("MEGAX_CLOUD_LOGIN_PARALLEL", provider_default, 128);
    checker_threads.min(cap).max(1)
}

/// Concurrent MEGA `Client::login` (hashcash / rate limits).
pub fn megax_mega_login_parallel(checker_threads: usize) -> usize {
    let cap = env_usize(
        "MEGAX_MEGA_LOGIN_PARALLEL",
        crate::mega::MEGA_LOGIN_CONCURRENCY,
        32,
    );
    checker_threads.min(cap).max(1)
}
