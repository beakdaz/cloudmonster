//! Bitbucket Server REST client: detect, authenticate, list owned repos, download archives.

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, Credential};
use reqwest::{Client, Response, StatusCode, Url};
use serde::Deserialize;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

#[derive(Debug, Clone)]
pub struct BitbucketClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for BitbucketClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct BitbucketRepo {
    pub project_key: String,
    pub slug: String,
    pub name: String,
}

#[derive(Debug, Clone)]
pub struct BitbucketAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub owned_repos: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl BitbucketAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "user={} admin={} repos={} downloaded={} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.owned_repos,
            self.downloaded,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

#[derive(Debug, Deserialize)]
struct ApplicationProperties {
    #[serde(default, rename = "displayName")]
    display_name: Option<String>,
    #[serde(default)]
    version: Option<String>,
}

#[derive(Debug, Deserialize)]
struct BitbucketProjectRef {
    key: String,
}

#[derive(Debug, Deserialize)]
struct BitbucketRepoNode {
    slug: String,
    name: String,
    project: BitbucketProjectRef,
}

#[derive(Debug, Deserialize)]
struct BitbucketPage<T> {
    values: Vec<T>,
    #[serde(default, rename = "isLastPage")]
    is_last_page: bool,
    #[serde(default, rename = "nextPageStart")]
    next_page_start: Option<u32>,
}

pub struct BitbucketClient {
    http: Client,
    base: Url,
    username: String,
    password: String,
}

impl BitbucketClient {
    pub fn new(base: Url, username: &str, password: &str, config: &BitbucketClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-bitbucket/0.1");

        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }

        Ok(Self {
            http: builder.build().context("failed to build HTTP client")?,
            base,
            username: username.to_string(),
            password: password.to_string(),
        })
    }

    fn rest_url(&self, path: &str) -> Result<Url> {
        let path = path.trim_start_matches('/');
        self.base
            .join(&format!("rest/api/1.0/{path}"))
            .context("failed to build Bitbucket REST url")
    }

    fn authed(&self, builder: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        builder.basic_auth(&self.username, Some(self.password.as_str()))
    }

    pub async fn detect(&self) -> Result<bool> {
        let url = self.rest_url("application-properties")?;
        let resp = match self.http.get(url.clone()).send().await {
            Ok(resp) => resp,
            Err(err) => {
                return Err(err).with_context(|| {
                    format!(
                        "cannot reach Bitbucket at {} (check VPN/network; enable Allow invalid TLS for bad certificates)",
                        self.base
                    )
                });
            }
        };
        if !resp.status().is_success() {
            return Ok(false);
        }
        let body = resp.text().await?;
        if let Ok(props) = serde_json::from_str::<ApplicationProperties>(&body) {
            if props
                .display_name
                .as_deref()
                .is_some_and(|n| n.eq_ignore_ascii_case("bitbucket"))
            {
                return Ok(true);
            }
            if props.version.is_some() && body.contains("Bitbucket") {
                return Ok(true);
            }
        }
        Ok(body.contains("\"displayName\":\"Bitbucket\""))
    }

    pub async fn authenticate(&self) -> Result<(String, bool)> {
        let url = self.rest_url("repos?role=OWNER&limit=1")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        let status = resp.status();
        if status == StatusCode::UNAUTHORIZED || status == StatusCode::FORBIDDEN {
            bail!(
                "Bitbucket authentication failed for {} (check username/password or app password)",
                self.username
            );
        }
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            bail!(
                "Bitbucket auth probe failed HTTP {}: {}",
                status,
                preview_body(&body)
            );
        }

        let session_user = resp
            .headers()
            .get("x-ausername")
            .and_then(|v| v.to_str().ok())
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .unwrap_or(self.username.as_str())
            .to_string();

        let is_admin = self.check_admin().await.unwrap_or(false);
        Ok((session_user, is_admin))
    }

    async fn check_admin(&self) -> Result<bool> {
        let url = self.rest_url("admin/users?limit=1")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        Ok(resp.status().is_success())
    }

    pub async fn list_owned_repos(&self) -> Result<Vec<BitbucketRepo>> {
        let mut repos = Vec::new();
        let mut start = 0u32;
        loop {
            let path = format!("repos?role=OWNER&limit=100&start={start}");
            let url = self.rest_url(&path)?;
            let resp = self.authed(self.http.get(url)).send().await?;
            let page: BitbucketPage<BitbucketRepoNode> =
                parse_json_response(resp, "repos").await?;
            for node in page.values {
                repos.push(BitbucketRepo {
                    project_key: node.project.key,
                    slug: node.slug,
                    name: node.name,
                });
            }
            if page.is_last_page || page.next_page_start.is_none() {
                break;
            }
            start = page.next_page_start.unwrap_or(start + 100);
        }
        Ok(repos)
    }

    pub async fn download_repo_archive(
        &self,
        repo: &BitbucketRepo,
        output_path: &Path,
    ) -> Result<u64> {
        let encoded_project = percent_encode(&repo.project_key);
        let encoded_slug = percent_encode(&repo.slug);
        let path = format!(
            "projects/{encoded_project}/repos/{encoded_slug}/archive?format=zip"
        );
        let url = self.rest_url(&path)?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!(
                "archive download failed for {}/{}: HTTP {}",
                repo.project_key,
                repo.slug,
                resp.status()
            );
        }
        let bytes = resp.bytes().await?;
        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut file = fs::File::create(output_path).await?;
        file.write_all(&bytes).await?;
        Ok(bytes.len() as u64)
    }
}

async fn parse_json_response<T: serde::de::DeserializeOwned>(
    resp: Response,
    endpoint: &str,
) -> Result<T> {
    let status = resp.status();
    let body = resp.text().await?;
    let trimmed = body.trim_start();
    let looks_html = trimmed.starts_with("<!DOCTYPE")
        || trimmed.starts_with("<html")
        || trimmed.starts_with("<HTML");
    if !status.is_success() {
        bail!(
            "Bitbucket API error {status} on {endpoint}: {}",
            preview_body(&body)
        );
    }
    if looks_html {
        bail!(
            "Bitbucket API returned HTML instead of JSON on {endpoint} (session not authenticated?)"
        );
    }
    serde_json::from_str(&body).with_context(|| {
        format!(
            "failed to decode Bitbucket API JSON from {endpoint}: {}",
            preview_body(&body)
        )
    })
}

fn preview_body(body: &str) -> String {
    body.chars().take(200).collect::<String>().replace('\n', " ")
}

fn percent_encode(input: &str) -> String {
    input.bytes().fold(String::new(), |mut acc, b| {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                acc.push(b as char);
            }
            _ => {
                use std::fmt::Write;
                let _ = write!(acc, "%{b:02X}");
            }
        }
        acc
    })
}

pub fn safe_path_component(input: &str) -> String {
    input
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

pub async fn download_personal_repos(
    cred: &Credential,
    config: &BitbucketClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(BitbucketAccountStats, Vec<(BitbucketRepo, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_personal_repos_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_personal_repos_once(
    cred: Credential,
    config: &BitbucketClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(BitbucketAccountStats, Vec<(BitbucketRepo, PathBuf, u64)>)> {
    let client = BitbucketClient::new(
        cred.url.clone(),
        &cred.username,
        &cred.password,
        config,
    )?;
    if !client.detect().await? {
        bail!(
            "{} is not a Bitbucket Server (no /rest/api/1.0/application-properties Bitbucket response)",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let (session_user, is_admin) = client
        .authenticate()
        .await
        .with_context(|| format!("login failed for {}", cred.display_line()))?;

    let repos = client.list_owned_repos().await?;
    let owned_repos = repos.len();

    if repos.is_empty() {
        warn!("no owned repos for {}", cred.display_line());
        return Ok((
            BitbucketAccountStats {
                username: session_user,
                is_admin,
                owned_repos: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    if !download_files {
        return Ok((
            BitbucketAccountStats {
                username: session_user,
                is_admin,
                owned_repos,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "bitbucket");
    let prefix = cred.account_file_prefix();

    let mut written = Vec::new();
    for repo in repos {
        let leaf = format!(
            "{}__{}__{}.zip",
            prefix,
            safe_path_component(&repo.project_key),
            safe_path_component(&repo.slug)
        );
        let path = output_file_path(&site_dir, &leaf);
        match client.download_repo_archive(&repo, &path).await {
            Ok(bytes) => {
                debug!(
                    "downloaded {}/{} ({} bytes) for {}",
                    repo.project_key,
                    repo.slug,
                    bytes,
                    cred.display_line()
                );
                written.push((repo, path, bytes));
            }
            Err(err) => warn!(
                "failed to download {}/{} for {}: {err}",
                repo.project_key,
                repo.slug,
                cred.display_line()
            ),
        }
    }

    let bytes: u64 = written.iter().map(|(_, _, b)| *b).sum();
    let downloaded = written.len();
    Ok((
        BitbucketAccountStats {
            username: session_user,
            is_admin,
            owned_repos,
            downloaded,
            bytes,
        },
        written,
    ))
}
