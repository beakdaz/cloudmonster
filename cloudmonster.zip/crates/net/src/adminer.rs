//! Adminer single-file DB UI: login and export SQL dumps.

use anyhow::{bail, Context, Result};
use crate::html::{decode_html_entities, extract_token, looks_like_adminer};
use crate::http_client::apply_proxy;
use pma_core::{output_file_path, Credential};
use regex::Regex;
use reqwest::{Client, RequestBuilder, Response, StatusCode, Url};
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::warn;

static ADMINER_DB_OPTION_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)<option[^>]*value="([^"]+)"[^>]*>"#).unwrap()
});

static ADMINER_DB_LINK_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)[?&]db=([^&"'<>]+)"#).unwrap()
});

static ADMINER_EXPORT_TABLE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<input[^>]*name\s*=\s*["']tables\[\]["'][^>]*value\s*=\s*["']([^"']+)["']"#)
        .unwrap()
});

static ADMINER_EXPORT_TABLE_VALUE_FIRST_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<input[^>]*value\s*=\s*["']([^"']+)["'][^>]*name\s*=\s*["']tables\[\]["']"#)
        .unwrap()
});

static ADMINER_TABLE_CHECKBOX_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?is)<input[^>]*type\s*=\s*["']checkbox["'][^>]*name\s*=\s*["']tables\[\]["'][^>]*value\s*=\s*["']([^"']+)["']"#,
    )
    .unwrap()
});

const ADMINER_EXPORT_TABLE_BATCH: usize = 60;

static ADMINER_TABLE_LINK_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)[?&]table=([^&"'<>]+)"#).unwrap()
});

static ADMINER_HIDDEN_INPUT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<input[^>]*type\s*=\s*["']hidden["'][^>]*>"#).unwrap()
});

static ADMINER_ATTR_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)\s(name|value)\s*=\s*["']([^"']*)["']"#).unwrap()
});

static ADMINER_DRIVER_OPTION_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<select[^>]*name\s*=\s*["']auth\[driver\]["'][^>]*>(.*?)</select>"#).unwrap()
});

static ADMINER_SELECTED_DRIVER_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<option[^>]*selected[^>]*value\s*=\s*["']([^"']+)["']"#).unwrap()
});

static ADMINER_AUTH_SERVER_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)name\s*=\s*["']auth\[server\]["'][^>]*value\s*=\s*["']([^"']*)["']"#).unwrap()
});

static ADMINER_DRIVER_VALUE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)<option[^>]*value\s*=\s*["']([^"']+)["']"#).unwrap()
});

#[derive(Debug, Clone)]
pub struct AdminerClientConfig {
    pub timeout: Duration,
    pub export_timeout: Duration,
    pub insecure: bool,
    pub proxy: Option<String>,
}

impl Default for AdminerClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            export_timeout: Duration::from_secs(120),
            insecure: false,
            proxy: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct AdminerAccountStats {
    pub username: String,
    pub databases: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl AdminerAccountStats {
    pub fn detail_line(&self) -> String {
        let downloaded =
            crate::stats_display::file_count(self.downloaded, self.databases);
        format!(
            "user={} databases={} downloaded={downloaded} ({})",
            self.username,
            self.databases,
            format_bytes(self.bytes)
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

struct AdminerClient {
    http: Client,
    base: Url,
    /// URL after login (usually includes `username=` query); used for list/export.
    session: Url,
    export_timeout: Duration,
    driver: String,
    auth_server: String,
    cred_user: String,
    cred_pass: String,
    /// Site-wide HTTP Basic (401 before Adminer form), same user/pass as DB line unless retried.
    http_basic: Option<(String, String)>,
}

impl AdminerClient {
    fn new(cred: &Credential, config: &AdminerClientConfig) -> Result<Self> {
        let timeout = config.export_timeout.max(config.timeout);
        let http = apply_proxy(
            Client::builder()
                .cookie_store(true)
                .timeout(timeout)
                .connect_timeout(Duration::from_secs(20))
                .danger_accept_invalid_certs(config.insecure)
                .redirect(reqwest::redirect::Policy::limited(12))
                .user_agent(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 \
                 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                ),
            config.proxy.as_deref(),
        )?
        .build()
        .context("failed to build HTTP client")?;
        let base = cred.url.clone();
        Ok(Self {
            http,
            session: base.clone(),
            base,
            export_timeout: timeout,
            driver: "server".to_string(),
            auth_server: String::new(),
            cred_user: cred.username.clone(),
            cred_pass: cred.password.clone(),
            http_basic: None,
        })
    }

    fn apply_request_auth(&self, req: RequestBuilder) -> RequestBuilder {
        if let Some((user, pass)) = &self.http_basic {
            req.basic_auth(user, Some(pass.as_str()))
        } else {
            req
        }
    }

    fn build_get(&self, url: Url, timeout: Option<Duration>) -> RequestBuilder {
        let mut req = self.http.get(url);
        if let Some(t) = timeout {
            req = req.timeout(t);
        }
        self.apply_request_auth(req)
    }

    async fn send_get(&mut self, url: Url) -> Result<Response> {
        self.send_get_timeout(url, None).await
    }

    async fn send_get_timeout(&mut self, url: Url, timeout: Option<Duration>) -> Result<Response> {
        let resp = self
            .build_get(url.clone(), timeout)
            .send()
            .await
            .context("GET failed")?;
        if resp.status() == StatusCode::UNAUTHORIZED && self.http_basic.is_none() {
            self.http_basic = Some((self.cred_user.clone(), self.cred_pass.clone()));
            let resp = self
                .build_get(url, timeout)
                .basic_auth(&self.cred_user, Some(self.cred_pass.as_str()))
                .send()
                .await
                .context("GET failed")?;
            return Ok(resp);
        }
        Ok(resp)
    }

    fn send_post(&self, url: Url) -> RequestBuilder {
        self.apply_request_auth(self.http.post(url))
    }

    fn sync_script_base_force(&mut self, url: &Url) {
        let mut script = url.clone();
        script.set_query(None);
        script.set_fragment(None);
        self.base = script.clone();
        self.session = script;
    }

    fn sync_script_base(&mut self, url: &Url) {
        let path = url.path().to_ascii_lowercase();
        if !path.contains("adminer") {
            return;
        }
        let mut script = url.clone();
        script.set_query(None);
        script.set_fragment(None);
        self.base = script.clone();
        self.session = script;
    }

    fn adminer_url_with_query(&self, pairs: &[(&str, &str)]) -> Url {
        let mut u = adminer_script_url(&self.base);
        {
            let mut q = u.query_pairs_mut();
            for (k, v) in pairs {
                q.append_pair(k, v);
            }
        }
        u
    }

    fn apply_session_after_login(
        &mut self,
        username: &str,
        landing: &Url,
        cookie_session: bool,
    ) {
        self.sync_script_base(landing);
        if cookie_session {
            self.session = adminer_script_url(&self.base);
            return;
        }
        let mut session = landing.clone();
        session.set_fragment(None);
        let has_user = session
            .query_pairs()
            .any(|(k, _)| k.eq_ignore_ascii_case("username"));
        if !has_user {
            session = adminer_url_with_username(&self.base, username);
        } else {
            self.sync_script_base(&session);
            session = adminer_script_url(&self.base);
            session
                .query_pairs_mut()
                .append_pair("username", username);
        }
        self.session = session;
    }

    async fn get_text(&mut self, url: Url) -> Result<String> {
        let resp = self.send_get(url).await?;
        let final_url = resp.url().clone();
        self.sync_script_base(&final_url);
        let status = resp.status();
        let text = resp.text().await.context("read body")?;
        if looks_like_adminer(&text) {
            self.sync_script_base_force(&final_url);
        }
        if !status.is_success() && !looks_like_adminer(&text) {
            bail!("Adminer HTTP {status}");
        }
        Ok(text)
    }

    async fn detect(&mut self) -> Result<bool> {
        let html = self.get_text(self.base.clone()).await?;
        Ok(looks_like_adminer(&html))
    }

    async fn login(&mut self, username: &str, password: &str) -> Result<bool> {
        let html = self.get_text(self.base.clone()).await?;
        if !looks_like_adminer(&html) {
            bail!("URL does not look like Adminer (expected adminer.php login form)");
        }
        if html.contains("logout") && html.contains("db=") && !html.contains("auth[username]") {
            let landing = self.base.clone();
            self.apply_session_after_login(username, &landing, true);
            return Ok(true);
        }

        self.auth_server = parse_adminer_auth_server(&html);
        let drivers = adminer_drivers_to_try(&html);
        for driver in drivers {
            self.driver = driver;
            if self.post_login(username, password, &html).await? {
                return Ok(true);
            }
        }
        Ok(false)
    }

    async fn post_login(
        &mut self,
        username: &str,
        password: &str,
        login_html: &str,
    ) -> Result<bool> {
        let mut form: Vec<(String, String)> = extract_adminer_hidden_fields(login_html);
        form.push(("auth[driver]".into(), self.driver.clone()));
        form.push(("auth[server]".into(), self.auth_server.clone()));
        form.push(("auth[username]".into(), username.to_string()));
        form.push(("auth[password]".into(), password.to_string()));
        form.push(("auth[db]".into(), String::new()));
        if let Some(token) = extract_token(login_html) {
            form.push(("token".into(), token));
        }
        merge_form_last_wins(&mut form);
        let form_refs: Vec<(&str, &str)> = form
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();

        let post_url = adminer_script_url(&self.base);
        let resp = self
            .send_post(post_url.clone())
            .header("Referer", post_url.as_str())
            .form(&form_refs)
            .send()
            .await
            .context("Adminer login POST failed")?;
        let landing = resp.url().clone();
        let cookie_session = response_has_adminer_session(&resp);
        let text = resp.text().await.context("login response")?;
        if adminer_login_failed(&text) {
            return Ok(false);
        }
        if adminer_login_ok(&text) || cookie_session {
            self.apply_session_after_login(username, &landing, cookie_session);
            return Ok(true);
        }
        let html2 = self.get_text(adminer_script_url(&self.base)).await?;
        if adminer_login_ok(&html2) {
            let landing = self.base.clone();
            self.apply_session_after_login(username, &landing, true);
            return Ok(true);
        }
        let session_probe = adminer_url_with_username(&self.base, username);
        let html3 = self.get_text(session_probe.clone()).await?;
        if adminer_login_ok(&html3) {
            self.apply_session_after_login(username, &session_probe, false);
            return Ok(true);
        }
        Ok(false)
    }

    fn parse_databases(html: &str) -> Vec<String> {
        let decoded = decode_html_entities(html);
        let mut dbs: Vec<String> = ADMINER_DB_LINK_RE
            .captures_iter(&decoded)
            .filter_map(|c| c.get(1).map(|m| m.as_str().to_string()))
            .filter(|d| {
                !d.is_empty()
                    && d != "information_schema"
                    && d != "mysql"
                    && d != "performance_schema"
                && d != "sys"
                && d != "template0"
                && d != "template1"
            })
            .collect();
        if dbs.is_empty() {
            for cap in ADMINER_DB_OPTION_RE.captures_iter(&decoded) {
                if let Some(m) = cap.get(1) {
                    let name = m.as_str().trim();
                    if !name.is_empty()
                        && name != "information_schema"
                    && name != "mysql"
                    && name != "performance_schema"
                    && name != "sys"
                    && name != "template0"
                    && name != "template1"
                    {
                        dbs.push(name.to_string());
                    }
                }
            }
        }
        dbs.sort();
        dbs.dedup();
        dbs
    }

    async fn list_databases(&mut self) -> Result<Vec<String>> {
        let html = self.get_text(adminer_script_url(&self.base)).await?;
        Ok(Self::parse_databases(&html))
    }

    async fn fetch_table_names(&mut self, db: &str) -> Result<Vec<String>> {
        let url = self.adminer_url_with_query(&[("db", db)]);
        let html = self.get_text(url).await?;
        Ok(parse_adminer_table_links(&html))
    }

    async fn export_database(&mut self, db: &str) -> Result<Vec<u8>> {
        let export_page_url = self.adminer_url_with_query(&[("db", db), ("export", "")]);
        let export_page = self.get_text(export_page_url.clone()).await?;
        if export_page.contains("auth[username]") && !export_page.contains("logout") {
            bail!("export page requires login for `{db}`");
        }

        let mut tables = parse_adminer_export_tables(&export_page);
        if tables.is_empty() {
            tables = self.fetch_table_names(db).await.unwrap_or_default();
        }

        let post_db_only = self.adminer_url_with_query(&[("db", db)]);
        let mut last_err = String::new();
        let attempts: [(&Url, bool); 4] = [
            (&export_page_url, true),
            (&export_page_url, false),
            (&post_db_only, true),
            (&post_db_only, false),
        ];
        for (post_url, with_extras) in attempts {
            match self
                .try_export_post(db, &tables, post_url, with_extras, &export_page)
                .await
            {
                Ok(bytes) if export_bytes_ok(&bytes) => return Ok(bytes),
                Ok(bytes) => last_err = format!("not SQL ({} bytes)", bytes.len()),
                Err(e) => last_err = e.to_string(),
            }
        }

        if let Ok(fallback) = self.export_database_get_dump(db).await {
            if export_bytes_ok(&fallback) {
                return Ok(fallback);
            }
            last_err = format!("GET dump=sql returned {} bytes (not SQL)", fallback.len());
        }

        bail!(
            "export failed for `{db}` ({})",
            if last_err.is_empty() {
                "no tables or empty response".to_string()
            } else {
                last_err
            }
        );
    }

    async fn try_export_post(
        &mut self,
        db: &str,
        tables: &[String],
        post_url: &Url,
        with_extras: bool,
        export_page: &str,
    ) -> Result<Vec<u8>> {
        if tables.len() > ADMINER_EXPORT_TABLE_BATCH {
            let mut combined = Vec::new();
            for chunk in tables.chunks(ADMINER_EXPORT_TABLE_BATCH) {
                let export_page_url = self.adminer_url_with_query(&[("db", db), ("export", "")]);
                let page = self.get_text(export_page_url).await?;
                let part = self
                    .export_database_post(&page, db, chunk, post_url, with_extras)
                    .await?;
                if !export_bytes_ok(&part) {
                    bail!("batch export not SQL ({} bytes)", part.len());
                }
                if !combined.is_empty() {
                    combined.push(b'\n');
                }
                combined.extend_from_slice(&part);
            }
            return Ok(combined);
        }
        self.export_database_post(export_page, db, tables, post_url, with_extras)
            .await
    }

    async fn export_database_post(
        &self,
        export_page: &str,
        db: &str,
        tables: &[String],
        post_url: &Url,
        with_extras: bool,
    ) -> Result<Vec<u8>> {
        let mut form: Vec<(String, String)> = extract_adminer_hidden_fields(export_page);
        form.push(("export".into(), "1".into()));
        form.push(("format".into(), "sql".into()));
        form.push(("output".into(), "save".into()));
        form.push(("db".into(), db.to_string()));
        form.push(("data".into(), "1".into()));
        form.push(("structure".into(), "1".into()));
        if with_extras {
            form.push(("events".into(), "1".into()));
            form.push(("routines".into(), "1".into()));
            form.push(("triggers".into(), "1".into()));
        }
        for table in tables {
            form.push(("tables[]".into(), table.clone()));
        }
        if let Some(token) = extract_token(export_page) {
            form.push(("token".into(), token));
        }
        merge_form_last_wins(&mut form);

        let form_refs: Vec<(&str, &str)> = form
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();

        let bytes = self
            .post_export_form(post_url.clone(), &form_refs)
            .await
            .context("export POST")?;
        Ok(bytes)
    }

    async fn post_export_form(&self, url: Url, form: &[(&str, &str)]) -> Result<Vec<u8>> {
        let resp = self
            .send_post(url.clone())
            .header("Referer", url.as_str())
            .timeout(self.export_timeout)
            .form(form)
            .send()
            .await
            .context("export POST")?;
        let status = resp.status();
        let bytes = resp.bytes().await.context("export body")?;
        if !status.is_success() && bytes.is_empty() {
            bail!("export HTTP {status}");
        }
        Ok(bytes.to_vec())
    }

    async fn export_database_get_dump(&mut self, db: &str) -> Result<Vec<u8>> {
        let url = self.adminer_url_with_query(&[("db", db), ("dump", "sql")]);
        let resp = self
            .send_get_timeout(url, Some(self.export_timeout))
            .await
            .context("export GET dump=sql")?;
        Ok(resp.bytes().await.context("export GET body")?.to_vec())
    }

    async fn run(
        &mut self,
        cred: &Credential,
        site_dir: &Path,
        download_files: bool,
    ) -> Result<(AdminerAccountStats, Vec<(String, PathBuf, u64)>)> {
        if !self.detect().await? {
            bail!("URL does not look like Adminer (expected adminer.php login form)");
        }
        if !self.login(&cred.username, &cred.password).await? {
            bail!("Adminer authentication failed");
        }

        let dbs = self.list_databases().await?;
        if dbs.is_empty() {
            bail!("Adminer login ok but no databases visible");
        }

        if !download_files {
            return Ok((
                AdminerAccountStats {
                    username: cred.username.clone(),
                    databases: dbs.len(),
                    downloaded: 0,
                    bytes: 0,
                },
                Vec::new(),
            ));
        }

        let prefix = cred.account_file_prefix();
        let mut files = Vec::new();
        let mut total_bytes = 0u64;

        let mut first_export_err: Option<String> = None;
        for db in &dbs {
            match self.export_database(db).await {
                Ok(bytes) => {
                    let leaf = format!(
                        "{}__{}.sql",
                        prefix,
                        Credential::safe_path_component(db)
                    );
                    let path = output_file_path(site_dir, &leaf);
                    if let Some(parent) = path.parent() {
                        fs::create_dir_all(parent).await?;
                    }
                    let mut file = fs::File::create(&path).await?;
                    file.write_all(&bytes).await?;
                    let n = bytes.len() as u64;
                    total_bytes += n;
                    files.push((db.clone(), path, n));
                }
                Err(err) => {
                    if first_export_err.is_none() {
                        first_export_err = Some(format!("{db}: {err}"));
                    }
                    warn!("Adminer export failed for {db}: {err}");
                }
            }
        }

        if files.is_empty() {
            let _ = fs::remove_dir_all(site_dir).await;
            let hint = first_export_err.unwrap_or_else(|| "unknown".into());
            bail!(
                "Adminer: found {} databases for {} but failed to export any SQL dump ({hint})",
                dbs.len(),
                cred.username,
            );
        }

        Ok((
            AdminerAccountStats {
                username: cred.username.clone(),
                databases: dbs.len(),
                downloaded: files.len(),
                bytes: total_bytes,
            },
            files,
        ))
    }
}

fn looks_like_html_export(bytes: &[u8]) -> bool {
    let head = String::from_utf8_lossy(&bytes[..bytes.len().min(256)]).to_ascii_lowercase();
    head.contains("<html") || head.contains("<!doctype")
}

pub async fn download_adminer_account(
    cred: &Credential,
    config: &AdminerClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(AdminerAccountStats, Vec<(String, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_adminer_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_adminer_once(
    cred: Credential,
    config: &AdminerClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(AdminerAccountStats, Vec<(String, PathBuf, u64)>)> {
    let mut client = AdminerClient::new(&cred, config)?;
    let site_dir = cred.account_site_output_dir(output_dir, "adminer");
    client.run(&cred, &site_dir, download_files).await
}

fn adminer_login_failed(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("invalid credentials")
        || lower.contains("access denied")
        || lower.contains("wrong username")
        || lower.contains("authentication failed")
        || (lower.contains("auth[username]") && lower.contains("adminer") && lower.contains("login"))
}

fn adminer_login_ok(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    if lower.contains("auth[username]") || lower.contains("auth[password]") {
        return false;
    }
    if lower.contains("logout") {
        return true;
    }
    lower.contains("?db=") || lower.contains("&db=")
}

fn adminer_script_url(base: &Url) -> Url {
    let mut u = base.clone();
    u.set_query(None);
    u.set_fragment(None);
    u
}

fn adminer_url_with_username(base: &Url, username: &str) -> Url {
    let mut u = adminer_script_url(base);
    u.query_pairs_mut().append_pair("username", username);
    u
}

fn response_has_adminer_session(resp: &Response) -> bool {
    resp.cookies().any(|c| {
        let name = c.name();
        name == "adminer_sid" || name == "adminer_key"
    })
}

fn export_bytes_ok(bytes: &[u8]) -> bool {
    !bytes.is_empty() && looks_like_sql_dump(bytes) && !looks_like_html_export(bytes)
}

fn parse_adminer_auth_server(html: &str) -> String {
    ADMINER_AUTH_SERVER_RE
        .captures(html)
        .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
        .unwrap_or_default()
}

fn adminer_drivers_to_try(html: &str) -> Vec<String> {
    let mut drivers = Vec::new();
    let mut push = |d: &str| {
        if !d.is_empty() && !drivers.iter().any(|x| x == d) {
            drivers.push(d.to_string());
        }
    };
    if let Some(cap) = ADMINER_DRIVER_OPTION_RE.captures(html) {
        if let Some(sel) = ADMINER_SELECTED_DRIVER_RE.captures(&cap[1]) {
            push(&sel[1]);
        }
        for cap in ADMINER_DRIVER_VALUE_RE.captures_iter(&cap[1]) {
            push(&cap[1]);
        }
    }
    push("server");
    push("pgsql");
    push("sqlite");
    drivers
}

fn extract_adminer_hidden_fields(html: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    for cap in ADMINER_HIDDEN_INPUT_RE.captures_iter(html) {
        let tag = cap.get(0).map(|m| m.as_str()).unwrap_or("");
        let mut name = None;
        let mut value = String::new();
        for attr in ADMINER_ATTR_RE.captures_iter(tag) {
            match &attr[1].to_ascii_lowercase()[..] {
                "name" => name = Some(attr[2].to_string()),
                "value" => value = attr[2].to_string(),
                _ => {}
            }
        }
        if let Some(n) = name {
            if !n.is_empty() {
                out.push((n, value));
            }
        }
    }
    out
}

fn parse_adminer_export_tables(html: &str) -> Vec<String> {
    let mut tables: Vec<String> = ADMINER_EXPORT_TABLE_RE
        .captures_iter(html)
        .chain(ADMINER_EXPORT_TABLE_VALUE_FIRST_RE.captures_iter(html))
        .chain(ADMINER_TABLE_CHECKBOX_RE.captures_iter(html))
        .filter_map(|c| c.get(1).map(|m| decode_html_entities(m.as_str())))
        .filter(|t| !t.is_empty())
        .collect();
    tables.sort();
    tables.dedup();
    tables
}

fn parse_adminer_table_links(html: &str) -> Vec<String> {
    let decoded = decode_html_entities(html);
    let mut tables: Vec<String> = ADMINER_TABLE_LINK_RE
        .captures_iter(&decoded)
        .filter_map(|c| c.get(1).map(|m| m.as_str().to_string()))
        .filter(|t| !t.is_empty())
        .collect();
    tables.sort();
    tables.dedup();
    tables
}

fn merge_form_last_wins(form: &mut Vec<(String, String)>) {
    let mut map = std::collections::BTreeMap::new();
    for (k, v) in form.drain(..) {
        map.insert(k, v);
    }
    form.extend(map);
}

fn looks_like_sql_dump(bytes: &[u8]) -> bool {
    if bytes.len() < 4 {
        return false;
    }
    let head = String::from_utf8_lossy(&bytes[..bytes.len().min(4096)]).to_ascii_lowercase();
    head.contains("create table")
        || head.contains("create database")
        || head.contains("insert into")
        || head.contains("postgresql database dump")
        || head.contains("mysqldump")
        || head.contains("set names")
        || head.contains("lock tables")
        || head.contains("drop table")
        || head.contains("adminer")
        || head.trim_start().starts_with("--")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_db_names_from_html() {
        let html = r#"<a href="?db=testdb&select=">testdb</a>"#;
        let dbs = AdminerClient::parse_databases(html);
        assert!(dbs.contains(&"testdb".to_string()));
    }
}
