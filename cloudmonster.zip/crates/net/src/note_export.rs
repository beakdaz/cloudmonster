//! Note-suite export facade (reqwest + tokio + moka + proxy).

pub use crate::note::{
    download_note_export_standalone, download_note_export_with_runtime, note_app_spec,
    NoteExportClientConfig, NoteResponseCache, NoteRuntime, NoteRuntimeConfig, ProxyManager,
    ProxyPick,
};

use anyhow::Result;
use pma_core::{Credential, NoteExportService};
use std::path::{Path, PathBuf};

/// Single-account export (creates ephemeral runtime + cache). Used by cloud checker.
pub async fn download_note_export_account(
    service: NoteExportService,
    cred: &Credential,
    config: &NoteExportClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(crate::note_app_common::NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    download_note_export_standalone(service, cred, config, output_dir, download_files).await
}
