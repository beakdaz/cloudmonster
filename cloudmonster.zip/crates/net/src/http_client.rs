//! Shared reqwest client options (proxy, TLS) and HTTP/HTTPS base URL variants.

use anyhow::{bail, Context, Result};
use pma_core::Credential;
use reqwest::ClientBuilder;
use std::future::Future;
use std::path::Path;
use url::Url;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProxyListScheme {
    Http,
    Socks5,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProxyListFormat {
    HostPort,
    UserPassAtHostPort,
}

impl ProxyListScheme {
    pub fn prefix(self) -> &'static str {
        match self {
            Self::Http => "http://",
            Self::Socks5 => "socks5://",
        }
    }
}

/// One proxy per line: full URL or formatted per GUI scheme/format settings.
pub fn normalize_proxy_line(line: &str) -> Option<String> {
    normalize_proxy_line_with(line, ProxyListScheme::Socks5, ProxyListFormat::HostPort)
}

pub fn normalize_proxy_line_with(
    line: &str,
    scheme: ProxyListScheme,
    format: ProxyListFormat,
) -> Option<String> {
    let t = line.trim();
    if t.is_empty() || t.starts_with('#') {
        return None;
    }
    if t.contains("://") {
        return Some(t.to_string());
    }
    match format {
        ProxyListFormat::HostPort => Some(format!("{}{t}", scheme.prefix())),
        ProxyListFormat::UserPassAtHostPort => {
            let (auth, hostport) = t.rsplit_once('@').unwrap_or(("", t));
            if auth.is_empty() {
                return None;
            }
            Some(format!("{}{auth}@{hostport}", scheme.prefix()))
        }
    }
}

pub fn normalize_proxy_field(
    raw: &str,
    scheme: ProxyListScheme,
    format: ProxyListFormat,
) -> Option<String> {
    let t = raw.trim();
    if t.is_empty() {
        None
    } else {
        normalize_proxy_line_with(t, scheme, format)
    }
}

pub fn load_proxy_list(path: &Path) -> Result<Vec<String>> {
    load_proxy_list_with(path, ProxyListScheme::Socks5, ProxyListFormat::HostPort)
}

pub fn load_proxy_list_with(
    path: &Path,
    scheme: ProxyListScheme,
    format: ProxyListFormat,
) -> Result<Vec<String>> {
    let content = std::fs::read_to_string(path)
        .with_context(|| format!("read proxy list {}", path.display()))?;
    let list: Vec<String> = content
        .lines()
        .filter_map(|line| normalize_proxy_line_with(line, scheme, format))
        .collect();
    if list.is_empty() {
        bail!("no proxies in {}", path.display());
    }
    Ok(list)
}

/// Attach an HTTP(S) or SOCKS5 proxy to a client builder (`http://`, `https://`, `socks5://`).
pub fn apply_proxy(mut builder: ClientBuilder, proxy: Option<&str>) -> Result<ClientBuilder> {
    let Some(raw) = proxy else {
        return Ok(builder);
    };
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Ok(builder);
    }
    let proxy = reqwest::Proxy::all(trimmed)
        .with_context(|| format!("invalid proxy URL: {trimmed}"))?;
    builder = builder.proxy(proxy);
    Ok(builder)
}

/// Same host/path with the opposite scheme (`http` ↔ `https`).
pub fn alternate_http_scheme(url: &Url) -> Option<Url> {
    let mut alt = url.clone();
    match url.scheme() {
        "http" => {
            alt.set_scheme("https").ok()?;
            Some(alt)
        }
        "https" => {
            alt.set_scheme("http").ok()?;
            Some(alt)
        }
        _ => None,
    }
}

/// Primary URL plus http/https alternate (deduped). Missing scheme → try both https and http.
pub fn base_url_variants(primary: &Url) -> Vec<Url> {
    let mut out = Vec::new();
    let mut push = |u: Url| {
        if !out.iter().any(|x: &Url| x.as_str() == u.as_str()) {
            out.push(u);
        }
    };
    match primary.scheme() {
        "http" | "https" => {
            push(primary.clone());
            if let Some(alt) = alternate_http_scheme(primary) {
                push(alt);
            }
        }
        _ if primary.host_str().is_some() => {
            for scheme in ["https", "http"] {
                let mut u = primary.clone();
                if u.set_scheme(scheme).is_ok() {
                    push(u);
                }
            }
        }
        _ => push(primary.clone()),
    }
    out
}

fn prefer_https_first_for_bamboo(url: &Url) -> bool {
    url.host_str()
        .map(|h| {
            let h = h.to_ascii_lowercase();
            h.contains("storage-bamboo") || h.contains("storage.bamboo")
        })
        .unwrap_or(false)
}

/// Run `run` for each http/https variant; return first success or the last error.
pub async fn try_http_https_for_cred<T, F, Fut>(cred: &Credential, run: F) -> Result<T>
where
    F: Fn(Credential) -> Fut,
    Fut: Future<Output = Result<T>>,
{
    let mut last: Option<anyhow::Error> = None;
    let mut variants = base_url_variants(&cred.url);
    if prefer_https_first_for_bamboo(&cred.url) {
        variants.sort_by(|a, b| match (a.scheme(), b.scheme()) {
            ("https", "http") => std::cmp::Ordering::Less,
            ("http", "https") => std::cmp::Ordering::Greater,
            _ => std::cmp::Ordering::Equal,
        });
    }
    for base in variants {
        let mut attempt = cred.clone();
        attempt.url = base;
        match run(attempt).await {
            Ok(v) => return Ok(v),
            Err(e) => last = Some(e),
        }
    }
    Err(last.unwrap_or_else(|| {
        anyhow::anyhow!(
            "cannot reach {} (tried http and https)",
            cred.url.host_str().unwrap_or("host")
        )
    }))
}
