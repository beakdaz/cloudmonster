//! Per-service HTTP paths for the CRM check suite.

use crate::note_app_common::NoteAppSpec;
use pma_core::CrmExportService;

pub fn crm_app_spec(service: CrmExportService) -> &'static NoteAppSpec {
    use CrmExportService as S;
    static TRELLO: NoteAppSpec = NoteAppSpec {
        service_label: "Trello",
        output_slug: "trello",
        user_agent: "cloudmonster-trello/0.1",
        login_paths: &["login", "auth", ""],
        post_paths: &["authentication", "login", "api/login"],
        json_login_paths: &["authentication", "api/login"],
        success_probe_paths: &["api/member/me", "boards", ""],
        inventory_api_paths: &["api/member/me", "1/members/me/boards"],
    };
    static HUBSPOT: NoteAppSpec = NoteAppSpec {
        service_label: "HubSpot",
        output_slug: "hubspot",
        user_agent: "cloudmonster-hubspot/0.1",
        login_paths: &["login", ""],
        post_paths: &["login", "api/login"],
        json_login_paths: &["api/login", "api/v1/login"],
        success_probe_paths: &["api/contacts/v1/lists", "home", ""],
        inventory_api_paths: &["api/contacts/v1/lists", "api/deals/v1/deal", "api/companies/v2/companies"],
    };
    static PIPEDRIVE: NoteAppSpec = NoteAppSpec {
        service_label: "Pipedrive",
        output_slug: "pipedrive",
        user_agent: "cloudmonster-pipedrive/0.1",
        login_paths: &["auth/login", "login", ""],
        post_paths: &["auth/login", "api/v1/users/login", "login"],
        json_login_paths: &["api/v1/users/login", "auth/login"],
        success_probe_paths: &["api/v1/users/me", "deals", ""],
        inventory_api_paths: &[
            "api/v1/deals",
            "api/v1/persons",
            "api/v1/organizations",
            "api/v1/leads",
        ],
    };
    static FRESHWORKS: NoteAppSpec = NoteAppSpec {
        service_label: "Freshworks",
        output_slug: "freshworks",
        user_agent: "cloudmonster-freshworks/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/login", "login"],
        json_login_paths: &["api/login", "api/auth/login"],
        success_probe_paths: &["api/contacts", "crm", ""],
        inventory_api_paths: &["api/contacts", "api/deals", "api/accounts"],
    };
    static INSIGHTLY: NoteAppSpec = NoteAppSpec {
        service_label: "Insightly",
        output_slug: "insightly",
        user_agent: "cloudmonster-insightly/0.1",
        login_paths: &["login", ""],
        post_paths: &["User/Login", "login"],
        json_login_paths: &["api/User/Login", "api/login"],
        success_probe_paths: &["api/Contacts", "Home", ""],
        inventory_api_paths: &["api/Contacts", "api/Organisations", "api/Opportunities"],
    };
    static SUGARCRM: NoteAppSpec = NoteAppSpec {
        service_label: "SugarCRM",
        output_slug: "sugarcrm",
        user_agent: "cloudmonster-sugarcrm/0.1",
        login_paths: &["login", ""],
        post_paths: &["rest/v11/login", "login"],
        json_login_paths: &["rest/v11/login", "api/login"],
        success_probe_paths: &["rest/v11/me", "api/me", ""],
        inventory_api_paths: &["rest/v11/Accounts", "rest/v11/Contacts", "rest/v11/Leads"],
    };
    static SAP: NoteAppSpec = NoteAppSpec {
        service_label: "SAP",
        output_slug: "sap",
        user_agent: "cloudmonster-sap/0.1",
        login_paths: &["saml2/idp/sso", "login", ""],
        post_paths: &["login", "api/login"],
        json_login_paths: &["api/login"],
        success_probe_paths: &["api/user", "home", ""],
        inventory_api_paths: &["api/crm/accounts", "api/crm/contacts"],
    };
    static KEAP: NoteAppSpec = NoteAppSpec {
        service_label: "Keap",
        output_slug: "keap",
        user_agent: "cloudmonster-keap/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/login", "login"],
        json_login_paths: &["api/login", "api/v1/login"],
        success_probe_paths: &["api/contacts", "app", ""],
        inventory_api_paths: &["api/contacts", "api/opportunities", "api/companies"],
    };
    static NIMBLE: NoteAppSpec = NoteAppSpec {
        service_label: "Nimble",
        output_slug: "nimble",
        user_agent: "cloudmonster-nimble/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/login", "login"],
        json_login_paths: &["api/login", "api/auth/login"],
        success_probe_paths: &["api/contacts", "app", ""],
        inventory_api_paths: &["api/contacts", "api/companies", "api/tasks"],
    };
    static CREATIO: NoteAppSpec = NoteAppSpec {
        service_label: "Creatio",
        output_slug: "creatio",
        user_agent: "cloudmonster-creatio/0.1",
        login_paths: &["Login", "login", ""],
        post_paths: &["ServiceModel/AuthService.svc/Login", "login"],
        json_login_paths: &["ServiceModel/AuthService.svc/Login", "api/login"],
        success_probe_paths: &["0/rest/ContactService/GetContacts", "Nui", ""],
        inventory_api_paths: &["0/rest/ContactService/GetContacts", "0/rest/AccountService/GetAccounts"],
    };
    static MONDAY: NoteAppSpec = NoteAppSpec {
        service_label: "monday.com",
        output_slug: "monday",
        user_agent: "cloudmonster-monday/0.1",
        login_paths: &["login", ""],
        post_paths: &["users/sign_in", "login"],
        json_login_paths: &["api/v2/login", "login"],
        success_probe_paths: &["api/v2/me", "boards", ""],
        inventory_api_paths: &["api/v2/boards", "api/v2/users", "api/v2/items"],
    };
    static CLICKUP: NoteAppSpec = NoteAppSpec {
        service_label: "ClickUp",
        output_slug: "clickup",
        user_agent: "cloudmonster-clickup/0.1",
        login_paths: &["login", ""],
        post_paths: &["api/v2/user/login", "login"],
        json_login_paths: &["api/v2/user/login", "login"],
        success_probe_paths: &["api/v2/user", "api/v2/team", ""],
        inventory_api_paths: &["api/v2/team", "api/v2/task", "api/v2/list"],
    };
    static SALESFORCE: NoteAppSpec = NoteAppSpec {
        service_label: "Salesforce",
        output_slug: "salesforce",
        user_agent: "cloudmonster-salesforce/0.1",
        login_paths: &["", "login"],
        post_paths: &["login", "secur/frontdoor.jsp"],
        json_login_paths: &["services/oauth2/token", "login"],
        success_probe_paths: &["services/data/v58.0/sobjects", "home/home.jsp", ""],
        inventory_api_paths: &[
            "services/data/v58.0/sobjects/Account/describe",
            "services/data/v58.0/query",
        ],
    };

    match service {
        S::Trello => &TRELLO,
        S::Hubspot => &HUBSPOT,
        S::Pipedrive => &PIPEDRIVE,
        S::Freshworks => &FRESHWORKS,
        S::Insightly => &INSIGHTLY,
        S::Sugarcrm => &SUGARCRM,
        S::Sap => &SAP,
        S::Keap => &KEAP,
        S::Nimble => &NIMBLE,
        S::Creatio => &CREATIO,
        S::Monday => &MONDAY,
        S::Clickup => &CLICKUP,
        S::Salesforce => &SALESFORCE,
    }
}
