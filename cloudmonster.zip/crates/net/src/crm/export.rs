//! CRM account check/export (reuses note runtime: reqwest + tokio + moka + proxy).

use crate::crm::specs::crm_app_spec;
use crate::crm_export_deep::{
    deep_crm_exports, pipedrive_account_via_api_token, pipedrive_api_token,
};
use crate::note::export::download_with_runtime;
use crate::{NoteRuntime, NoteRuntimeConfig};
use crate::note_app_common::{NoteAppAccountStats, NoteAppClientConfig};
use anyhow::Result;
use pma_core::{Credential, CrmExportService};
use std::path::{Path, PathBuf};
use std::sync::Arc;

pub async fn download_crm_export_standalone(
    service: CrmExportService,
    cred: &Credential,
    config: &NoteAppClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let spec = crm_app_spec(service);
    let runtime = Arc::new(NoteRuntime::new(
        NoteRuntimeConfig::from_legacy(config.timeout, config.insecure),
        spec.user_agent,
        None,
    )?);
    download_crm_export_with_runtime(service, cred, runtime, output_dir, download_files).await
}

pub async fn download_crm_export_with_runtime(
    service: CrmExportService,
    cred: &Credential,
    runtime: Arc<NoteRuntime>,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    let spec = crm_app_spec(service);

    if service == CrmExportService::Pipedrive {
        if let Some(tok) = pipedrive_api_token(cred) {
            if let Ok(pair) = pipedrive_account_via_api_token(
                cred,
                runtime.clone(),
                output_dir,
                download_files,
                spec,
                &tok,
            )
            .await
            {
                return Ok(pair);
            }
        }
    }

    let (mut stats, mut files) =
        download_with_runtime(cred, runtime.clone(), output_dir, download_files, spec).await?;

    if download_files {
        let site_dir = cred.site_output_dir(output_dir, spec.output_slug);
        let prefix = cred.account_file_prefix();
        if let Ok(extra) =
            deep_crm_exports(service, runtime.clone(), cred, &site_dir, &prefix).await
        {
            for (path, size) in extra {
                stats.bytes += size;
                files.push((path, size));
            }
            stats.downloaded = files.len();
            stats.inventory_items = stats.inventory_items.max(files.len());
        }
    }

    Ok((stats, files))
}
