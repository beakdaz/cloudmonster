//! Jira REST client: detect, authenticate, list projects, export issue JSON.

use anyhow::{bail, Context, Result};
use pma_core::{is_excluded_media_filename, output_file_path, output_relative_href, Credential};
use reqwest::{Client, Response, StatusCode, Url};
use serde::Deserialize;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

const MAX_PROJECTS: usize = 100;
const MAX_ISSUES_PER_PROJECT: u32 = 500;
const MAX_ATTACHMENTS_PER_PROJECT: usize = 400;
const MAX_ATTACHMENT_FILE_BYTES: u64 = 100 * 1024 * 1024;
/// Total attachment bytes per Jira account run (JSON exports are not counted).
const MAX_ATTACHMENTS_TOTAL_BYTES: u64 = 1024 * 1024 * 1024;
const PAGE_SIZE: u32 = 100;

#[derive(Debug, Clone)]
pub struct JiraClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for JiraClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct JiraProject {
    pub key: String,
    pub name: String,
}

#[derive(Debug, Clone)]
pub struct JiraAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub projects: usize,
    pub issues_exported: usize,
    pub attachments: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl JiraAccountStats {
    pub fn detail_line(&self) -> String {
        let check_metric = self.projects.max(self.issues_exported).max(self.attachments);
        let files = crate::stats_display::file_count(self.downloaded, check_metric);
        format!(
            "user={} admin={} projects={} issues={} attachments={} files={files} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.projects,
            self.issues_exported,
            self.attachments,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

#[derive(Debug, Deserialize)]
struct JiraServerInfo {
    #[serde(default, rename = "baseUrl")]
    base_url: Option<String>,
    #[serde(default)]
    version: Option<String>,
    #[serde(default, rename = "serverTitle")]
    server_title: Option<String>,
    #[serde(default, rename = "deploymentType")]
    deployment_type: Option<String>,
}

#[derive(Debug, Deserialize)]
struct JiraGroupList {
    #[serde(default)]
    items: Vec<JiraGroupItem>,
}

#[derive(Debug, Deserialize)]
struct JiraGroupItem {
    name: String,
}

#[derive(Debug, Deserialize)]
struct JiraMyself {
    #[serde(default)]
    name: Option<String>,
    #[serde(default, rename = "displayName")]
    display_name: Option<String>,
    #[serde(default)]
    groups: Option<JiraGroupList>,
}

#[derive(Debug, Deserialize)]
struct JiraProjectNode {
    key: String,
    name: String,
}

#[derive(Debug, Deserialize)]
struct JiraSearchResult {
    #[serde(default)]
    total: u32,
    #[serde(default)]
    issues: Vec<serde_json::Value>,
}

pub struct JiraClient {
    http: Client,
    base: Url,
    username: String,
    password: String,
    api_prefix: String,
}

impl JiraClient {
    pub fn new(
        base: Url,
        username: &str,
        password: &str,
        config: &JiraClientConfig,
    ) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-jira/0.1");

        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }

        Ok(Self {
            http: builder.build().context("failed to build HTTP client")?,
            base,
            username: username.to_string(),
            password: password.to_string(),
            api_prefix: "rest/api/2".to_string(),
        })
    }

    fn api_url(&self, path: &str) -> Result<Url> {
        let path = path.trim_start_matches('/');
        self.base
            .join(&format!("{}/{path}", self.api_prefix))
            .context("failed to build Jira REST url")
    }

    fn authed(&self, builder: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        builder.basic_auth(&self.username, Some(self.password.as_str()))
    }

    pub async fn detect(&mut self) -> Result<bool> {
        let mut last_transport: Option<anyhow::Error> = None;
        for base in candidate_jira_bases(&self.base) {
            for prefix in ["rest/api/2", "rest/api/3", "rest/api/latest"] {
                for use_auth in [false, true] {
                    match self.probe_server_info(&base, prefix, use_auth).await {
                        Ok(true) => {
                            self.base = base.clone();
                            self.api_prefix = prefix.to_string();
                            return Ok(true);
                        }
                        Ok(false) => {}
                        Err(err) => last_transport = Some(err),
                    }
                }
            }
        }

        for base in candidate_jira_bases(&self.base) {
            for prefix in ["rest/api/2", "rest/api/3"] {
                self.base = base.clone();
                self.api_prefix = prefix.to_string();
                let url = match self.api_url("myself") {
                    Ok(u) => u,
                    Err(_) => continue,
                };
                let resp = match self.authed(self.http.get(url)).send().await {
                    Ok(r) => r,
                    Err(err) => {
                        last_transport = Some(err.into());
                        continue;
                    }
                };
                if !resp.status().is_success() {
                    continue;
                }
                let body = resp.text().await.unwrap_or_default();
                if body.trim_start().starts_with('<') {
                    continue;
                }
                if serde_json::from_str::<JiraMyself>(&body).is_ok() {
                    return Ok(true);
                }
            }
        }

        if let Some(err) = last_transport {
            return Err(err).with_context(|| {
                format!(
                    "cannot reach Jira at {} (check VPN/network; enable Allow invalid TLS for bad certificates)",
                    self.base
                )
            });
        }
        Ok(false)
    }

    async fn probe_server_info(
        &self,
        base: &Url,
        prefix: &str,
        use_auth: bool,
    ) -> Result<bool> {
        let url = base
            .join(&format!("{prefix}/serverInfo"))
            .context("serverInfo url")?;
        let mut req = self.http.get(url);
        if use_auth {
            req = self.authed(req);
        }
        let resp = req.send().await?;
        let is_atlassian = resp.headers().contains_key("x-arequestid");
        let status = resp.status();
        let body = resp.text().await?;
        let trimmed = body.trim_start();
        if trimmed.starts_with('<') {
            return Ok(false);
        }
        if status.is_success() {
            if let Ok(info) = serde_json::from_str::<JiraServerInfo>(&body) {
                if info.version.is_some()
                    || info.server_title.is_some()
                    || info.base_url.is_some()
                    || info.deployment_type.is_some()
                {
                    return Ok(true);
                }
            }
            if body.contains("serverTitle")
                || body.contains("\"version\"")
                || body.contains("baseUrl")
                || body.contains("deploymentType")
            {
                return Ok(true);
            }
            if is_atlassian {
                return Ok(true);
            }
        }
        if (status == StatusCode::UNAUTHORIZED || status == StatusCode::FORBIDDEN)
            && trimmed.starts_with('{')
        {
            return Ok(true);
        }
        Ok(false)
    }

    async fn establish_web_session(&self) -> Result<()> {
        let session_url = self
            .base
            .join("rest/auth/1/session")
            .context("session url")?;
        let payload = serde_json::json!({
            "username": self.username,
            "password": self.password,
        });
        let resp = self
            .http
            .post(session_url)
            .json(&payload)
            .send()
            .await?;
        if resp.status().is_success() {
            debug!("Jira REST session established for {}", self.username);
            return Ok(());
        }

        let login_url = self.base.join("login.jsp").context("login.jsp url")?;
        let page = self.http.get(login_url.clone()).send().await?;
        let html = page.text().await?;
        let token = extract_atl_token(&html);
        let mut form: Vec<(&str, &str)> = vec![
            ("os_username", &self.username),
            ("os_password", &self.password),
            ("os_destination", ""),
            ("user_role", ""),
        ];
        if let Some(ref t) = token {
            form.push(("atl_token", t));
        }
        let resp = self.http.post(login_url).form(&form).send().await?;
        let status = resp.status();
        let final_path = resp.url().path().to_ascii_lowercase();
        if status.is_success() || status.is_redirection() {
            if !final_path.contains("login.jsp") {
                debug!("Jira form login succeeded for {}", self.username);
                return Ok(());
            }
        }
        bail!("Jira web session login failed (REST session HTTP {})", status);
    }

    async fn use_working_api_prefix(&mut self) -> Result<()> {
        let mut auth_rejected = false;
        for prefix in ["rest/api/2", "rest/api/3"] {
            let url = self
                .base
                .join(&format!("{prefix}/myself"))
                .context("myself url")?;
            let resp = self.authed(self.http.get(url)).send().await?;
            if resp.status().is_success() {
                self.api_prefix = prefix.to_string();
                return Ok(());
            }
            if resp.status() == StatusCode::UNAUTHORIZED || resp.status() == StatusCode::FORBIDDEN {
                auth_rejected = true;
                continue;
            }
        }
        if auth_rejected {
            bail!(
                "Jira authentication failed for {} (use email + API token on Cloud, or valid Jira password)",
                self.username
            );
        }
        bail!(
            "Jira authentication failed for {} (check username/password or API token)",
            self.username
        );
    }

    pub async fn authenticate(&mut self) -> Result<(String, bool)> {
        self.use_working_api_prefix().await?;
        let _ = self.establish_web_session().await;
        let url = self.api_url("myself")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        let user: JiraMyself = parse_json_response(resp, "myself").await?;
        let username = user
            .name
            .or(user.display_name)
            .unwrap_or_else(|| self.username.clone());
        let is_admin = user
            .groups
            .map(|g| {
                g.items.iter().any(|item| {
                    let n = item.name.to_ascii_lowercase();
                    n.contains("jira-administrators")
                        || n.contains("jira-system-administrators")
                        || n == "administrators"
                })
            })
            .unwrap_or(false);
        Ok((username, is_admin))
    }

    pub async fn list_projects(&self) -> Result<Vec<JiraProject>> {
        match self.fetch_projects().await {
            Ok(projects) => Ok(projects),
            Err(err) if is_html_instead_of_json_error(&err) => {
                self.establish_web_session().await?;
                self.fetch_projects().await
            }
            Err(err) => Err(err),
        }
    }

    async fn fetch_projects(&self) -> Result<Vec<JiraProject>> {
        let url = self.api_url("project")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        let nodes: Vec<JiraProjectNode> = parse_json_response(resp, "project").await?;
        let mut projects: Vec<JiraProject> = nodes
            .into_iter()
            .take(MAX_PROJECTS)
            .map(|n| JiraProject {
                key: n.key,
                name: n.name,
            })
            .collect();
        if projects.is_empty() {
            if let Ok(extra) = self.fetch_projects_search().await {
                projects = extra;
            }
        }
        Ok(projects)
    }

    async fn fetch_projects_search(&self) -> Result<Vec<JiraProject>> {
        let mut url = self.api_url("project/search")?;
        url.query_pairs_mut().append_pair("maxResults", "100");
        let resp = self.authed(self.http.get(url)).send().await?;
        #[derive(Debug, Deserialize)]
        struct SearchPage {
            #[serde(default)]
            values: Vec<JiraProjectNode>,
        }
        let page: SearchPage = parse_json_response(resp, "project/search").await?;
        Ok(page
            .values
            .into_iter()
            .take(MAX_PROJECTS)
            .map(|n| JiraProject {
                key: n.key,
                name: n.name,
            })
            .collect())
    }

    pub async fn export_project_issues(
        &self,
        project: &JiraProject,
    ) -> Result<(u32, u32, Vec<serde_json::Value>)> {
        match self.export_project_issues_once(project).await {
            Ok(v) => Ok(v),
            Err(err) if is_html_instead_of_json_error(&err) => {
                self.establish_web_session().await?;
                self.export_project_issues_once(project).await
            }
            Err(err) => Err(err),
        }
    }

    async fn export_project_issues_once(
        &self,
        project: &JiraProject,
    ) -> Result<(u32, u32, Vec<serde_json::Value>)> {
        let mut all_issues = Vec::new();
        let mut start_at = 0u32;
        let mut total = 0u32;
        let jql = format!("project={} ORDER BY created DESC", project.key);
        loop {
            let mut url = self.api_url("search")?;
            url.query_pairs_mut()
                .append_pair("jql", &jql)
                .append_pair("maxResults", &PAGE_SIZE.to_string())
                .append_pair("startAt", &start_at.to_string())
                .append_pair(
                    "fields",
                    "summary,status,assignee,reporter,created,updated,attachment,description,priority,issuetype",
                );
            let resp = self.authed(self.http.get(url)).send().await?;
            let page: JiraSearchResult = parse_json_response(resp, "search").await?;
            if start_at == 0 {
                total = page.total;
            }
            if page.issues.is_empty() {
                break;
            }
            all_issues.extend(page.issues);
            start_at += PAGE_SIZE;
            if start_at >= total || all_issues.len() as u32 >= MAX_ISSUES_PER_PROJECT {
                break;
            }
        }
        let exported = all_issues.len() as u32;
        Ok((exported, total, all_issues))
    }

    pub async fn download_issue_attachments(
        &self,
        project: &JiraProject,
        issues: &[serde_json::Value],
        output_dir: &Path,
        file_prefix: &str,
        account_attachment_bytes: &mut u64,
    ) -> Result<(usize, u64)> {
        let mut saved = 0usize;
        let mut total_bytes = 0u64;
        let mut budget = MAX_ATTACHMENTS_PER_PROJECT;

        for issue in issues {
            if budget == 0 || *account_attachment_bytes >= MAX_ATTACHMENTS_TOTAL_BYTES {
                break;
            }
            let issue_key = issue
                .get("key")
                .and_then(|v| v.as_str())
                .unwrap_or("issue");
            let Some(attachments) = issue
                .get("fields")
                .and_then(|f| f.get("attachment"))
                .and_then(|a| a.as_array())
            else {
                continue;
            };

            let mut used_names = std::collections::HashSet::new();

            for att in attachments {
                if budget == 0 || *account_attachment_bytes >= MAX_ATTACHMENTS_TOTAL_BYTES {
                    break;
                }
                let Some(filename) = att.get("filename").and_then(|v| v.as_str()) else {
                    continue;
                };
                if is_excluded_media_filename(filename) {
                    debug!("skip Jira media attachment {} on {}", filename, issue_key);
                    continue;
                }
                let size = att.get("size").and_then(|v| v.as_u64()).unwrap_or(0);
                if size > MAX_ATTACHMENT_FILE_BYTES {
                    warn!(
                        "skip oversized Jira attachment {} ({} bytes) on {}",
                        filename, size, issue_key
                    );
                    continue;
                }
                let remaining_total =
                    MAX_ATTACHMENTS_TOTAL_BYTES.saturating_sub(*account_attachment_bytes);
                if size > remaining_total {
                    warn!(
                        "skip Jira attachment {} — would exceed 1 GB attachment cap for this account",
                        filename
                    );
                    continue;
                }

                let download_url = attachment_download_url(&self.base, &self.api_prefix, att)?;
                let safe_name = unique_filename(filename, &mut used_names);
                let leaf = flat_attachment_name(
                    file_prefix,
                    &project.key,
                    issue_key,
                    &safe_name,
                );
                let path = output_file_path(output_dir, &leaf);

                match self
                    .download_attachment_to(&download_url, &path, remaining_total)
                    .await
                {
                    Ok(bytes) => {
                        saved += 1;
                        total_bytes += bytes;
                        *account_attachment_bytes += bytes;
                        budget -= 1;
                        debug!(
                            "downloaded Jira attachment {} ({} bytes) for {}",
                            filename, bytes, issue_key
                        );
                    }
                    Err(err) => warn!(
                        "failed to download Jira attachment {} on {}: {err}",
                        filename, issue_key
                    ),
                }
            }
        }

        Ok((saved, total_bytes))
    }

    async fn download_attachment_to(
        &self,
        url: &Url,
        output_path: &Path,
        max_bytes: u64,
    ) -> Result<u64> {
        let resp = self.authed(self.http.get(url.clone())).send().await?;
        if !resp.status().is_success() {
            bail!("attachment HTTP {}", resp.status());
        }
        if let Some(len) = resp.content_length() {
            if len > max_bytes || len > MAX_ATTACHMENT_FILE_BYTES {
                bail!("attachment exceeds size limit");
            }
        }
        let bytes = resp.bytes().await?;
        let n = bytes.len() as u64;
        if n > max_bytes || n > MAX_ATTACHMENT_FILE_BYTES {
            bail!("attachment exceeds size limit");
        }
        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut file = fs::File::create(output_path).await?;
        file.write_all(&bytes).await?;
        Ok(bytes.len() as u64)
    }
}

struct ProjectIssueExport {
    project: JiraProject,
    issues: Vec<serde_json::Value>,
    exported: u32,
    total_matching: u32,
}

fn candidate_jira_bases(base: &Url) -> Vec<Url> {
    let mut bases = Vec::new();
    let mut push = |u: Url| {
        if !bases.iter().any(|x: &Url| x.as_str() == u.as_str()) {
            bases.push(u);
        }
    };
    for variant in crate::http_client::base_url_variants(base) {
        push(variant.clone());
        let path = variant.path();
        if path.is_empty() || path == "/" {
            if let Ok(jira) = variant.join("jira/") {
                push(jira);
            }
        }
    }
    bases
}

fn extract_atl_token(html: &str) -> Option<String> {
    let re_name = regex::Regex::new(r#"name="atl_token"\s+value="([^"]+)""#).ok()?;
    if let Some(caps) = re_name.captures(html) {
        return caps.get(1).map(|m| m.as_str().to_string());
    }
    let re_id = regex::Regex::new(r#"id="atl_token"\s+value="([^"]+)""#).ok()?;
    re_id
        .captures(html)
        .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
}

fn is_html_instead_of_json_error(err: &anyhow::Error) -> bool {
    err.to_string()
        .contains("HTML instead of JSON")
}

async fn parse_json_response<T: serde::de::DeserializeOwned>(
    resp: Response,
    endpoint: &str,
) -> Result<T> {
    let status = resp.status();
    let body = resp.text().await?;
    let trimmed = body.trim_start();
    let looks_html = trimmed.starts_with("<!DOCTYPE")
        || trimmed.starts_with("<html")
        || trimmed.starts_with("<HTML");
    if !status.is_success() {
        bail!(
            "Jira API error {status} on {endpoint}: {}",
            preview_body(&body)
        );
    }
    if looks_html {
        bail!(
            "Jira API returned HTML instead of JSON on {endpoint} (not authenticated?)"
        );
    }
    serde_json::from_str(&body).with_context(|| {
        format!(
            "failed to decode Jira API JSON from {endpoint}: {}",
            preview_body(&body)
        )
    })
}

fn preview_body(body: &str) -> String {
    body.chars().take(200).collect::<String>().replace('\n', " ")
}

pub fn safe_path_component(input: &str) -> String {
    input
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

fn attachment_download_url(base: &Url, api_prefix: &str, att: &serde_json::Value) -> Result<Url> {
    if let Some(content) = att.get("content").and_then(|v| v.as_str()) {
        if let Ok(url) = Url::parse(content) {
            return Ok(url);
        }
        return base
            .join(content.trim_start_matches('/'))
            .context("attachment content url");
    }
    let id = att
        .get("id")
        .and_then(|v| v.as_str())
        .context("attachment missing id")?;
    base.join(&format!("{api_prefix}/attachment/content/{id}"))
        .context("attachment content url")
}

fn unique_filename(name: &str, used: &mut std::collections::HashSet<String>) -> String {
    let base = safe_path_component(name);
    if used.insert(base.clone()) {
        return base;
    }
    let path = std::path::Path::new(name);
    let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
    let stem = path
        .file_stem()
        .and_then(|s| s.to_str())
        .map(safe_path_component)
        .unwrap_or_else(|| "file".to_string());
    for i in 2..1000 {
        let candidate = if ext.is_empty() {
            format!("{stem}_{i}")
        } else {
            format!("{stem}_{i}.{ext}")
        };
        let safe = safe_path_component(&candidate);
        if used.insert(safe.clone()) {
            return safe;
        }
    }
    format!("{}_{}", base, used.len())
}

fn escape_html(input: &str) -> String {
    input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn issue_field_str(issue: &serde_json::Value, field: &str) -> String {
    issue
        .get("fields")
        .and_then(|f| f.get(field))
        .map(field_value_to_string)
        .unwrap_or_default()
}

fn field_value_to_string(value: &serde_json::Value) -> String {
    match value {
        serde_json::Value::String(s) => s.clone(),
        serde_json::Value::Object(obj) => obj
            .get("name")
            .or_else(|| obj.get("displayName"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string(),
        serde_json::Value::Null => String::new(),
        other => other.to_string(),
    }
}

fn flat_attachment_name(prefix: &str, project_key: &str, issue_key: &str, filename: &str) -> String {
    format!(
        "{}__{}__{}__{}",
        safe_path_component(prefix),
        safe_path_component(project_key),
        safe_path_component(issue_key),
        safe_path_component(filename),
    )
}

fn issue_attachments_html(
    issues_html_leaf: &str,
    file_prefix: &str,
    project_key: &str,
    issue: &serde_json::Value,
) -> String {
    let issue_key = issue.get("key").and_then(|v| v.as_str()).unwrap_or("issue");
    let Some(list) = issue
        .get("fields")
        .and_then(|f| f.get("attachment"))
        .and_then(|a| a.as_array())
    else {
        return String::new();
    };
    if list.is_empty() {
        return String::new();
    }
    let mut out = String::from("<ul class=\"att\">");
    for att in list {
        let name = att
            .get("filename")
            .and_then(|v| v.as_str())
            .unwrap_or("file");
        if is_excluded_media_filename(name) {
            continue;
        }
        let safe_name = safe_path_component(name);
        let att_leaf = flat_attachment_name(file_prefix, project_key, issue_key, &safe_name);
        let href = output_relative_href(issues_html_leaf, &att_leaf);
        out.push_str(&format!(
            "<li><a href=\"{href}\">{}</a></li>",
            escape_html(name)
        ));
    }
    out.push_str("</ul>");
    out
}

fn render_issues_html(
    base: &Url,
    session_user: &str,
    file_prefix: &str,
    sections: &[ProjectIssueExport],
) -> String {
    let issues_html_leaf = format!("{file_prefix}__issues.html");
    let site = base.to_string();
    let mut body = String::new();
    for section in sections {
        body.push_str(&format!(
            "<section><h2>{} — {}</h2><p class=\"meta\">exported {} / {} issues</p><table><thead><tr>\
            <th>Key</th><th>Type</th><th>Priority</th><th>Status</th><th>Summary</th>\
            <th>Assignee</th><th>Reporter</th><th>Created</th><th>Updated</th><th>Attachments</th>\
            </tr></thead><tbody>",
            escape_html(&section.project.key),
            escape_html(&section.project.name),
            section.exported,
            section.total_matching,
        ));
        for issue in &section.issues {
            let key = issue.get("key").and_then(|v| v.as_str()).unwrap_or("");
            let summary = issue_field_str(issue, "summary");
            let status = issue_field_str(issue, "status");
            let assignee = issue_field_str(issue, "assignee");
            let reporter = issue_field_str(issue, "reporter");
            let created = issue_field_str(issue, "created");
            let updated = issue_field_str(issue, "updated");
            let priority = issue_field_str(issue, "priority");
            let issuetype = issue_field_str(issue, "issuetype");
            let attachments =
                issue_attachments_html(&issues_html_leaf, file_prefix, &section.project.key, issue);
            body.push_str(&format!(
                "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>\
                <td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>",
                escape_html(key),
                escape_html(&issuetype),
                escape_html(&priority),
                escape_html(&status),
                escape_html(&summary),
                escape_html(&assignee),
                escape_html(&reporter),
                escape_html(&created),
                escape_html(&updated),
                attachments,
            ));
        }
        body.push_str("</tbody></table></section>");
    }

    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Jira issues export</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f4f5f7;color:#172b4d}}
h1{{font-size:1.4rem;margin-bottom:4px}}
.meta{{color:#5e6c84;font-size:0.9rem}}
section{{background:#fff;border:1px solid #dfe1e6;border-radius:8px;padding:16px;margin:20px 0}}
table{{width:100%;border-collapse:collapse;font-size:0.85rem}}
th,td{{border:1px solid #dfe1e6;padding:6px 8px;vertical-align:top;text-align:left}}
th{{background:#f4f5f7}}
ul.att{{margin:0;padding-left:18px}}
a{{color:#0052cc}}
</style>
</head>
<body>
<h1>Jira issues export</h1>
<p class="meta">Site: {site}<br/>User: {user}</p>
{body}
</body>
</html>"#,
        site = escape_html(&site),
        user = escape_html(session_user),
        body = body,
    )
}

async fn write_issues_html(path: &Path, html: &str) -> Result<u64> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(path, html.as_bytes()).await?;
    Ok(html.len() as u64)
}

pub async fn download_jira_projects(
    cred: &Credential,
    config: &JiraClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(JiraAccountStats, Vec<(JiraProject, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_jira_projects_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_jira_projects_once(
    cred: Credential,
    config: &JiraClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(JiraAccountStats, Vec<(JiraProject, PathBuf, u64)>)> {
    let mut client = JiraClient::new(
        cred.url.clone(),
        &cred.username,
        &cred.password,
        config,
    )?;
    if !client.detect().await? {
        bail!(
            "{} is not a Jira server (no /rest/api/2/serverInfo JSON response)",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let (session_user, is_admin) = client
        .authenticate()
        .await
        .with_context(|| format!("login failed for {}", cred.display_line()))?;

    let projects = client.list_projects().await?;
    let project_count = projects.len();

    if projects.is_empty() {
        warn!("no Jira projects visible for {}", cred.display_line());
        return Ok((
            JiraAccountStats {
                username: session_user,
                is_admin,
                projects: 0,
                issues_exported: 0,
                attachments: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    if !download_files {
        return Ok((
            JiraAccountStats {
                username: session_user,
                is_admin,
                projects: project_count,
                issues_exported: 0,
                attachments: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "jira");
    let prefix = cred.account_file_prefix();

    let mut written = Vec::new();
    let mut issues_total = 0u32;
    let mut attachment_total = 0usize;
    let mut total_bytes = 0u64;
    let mut attachment_bytes_account = 0u64;
    let mut export_sections = Vec::new();

    for project in projects {
        match client.export_project_issues(&project).await {
            Ok((exported, total_matching, issues)) => {
                issues_total += exported;
                export_sections.push(ProjectIssueExport {
                    project: project.clone(),
                    issues: issues.clone(),
                    exported,
                    total_matching,
                });

                match client
                    .download_issue_attachments(
                        &project,
                        &issues,
                        &site_dir,
                        &prefix,
                        &mut attachment_bytes_account,
                    )
                    .await
                {
                    Ok((count, att_bytes)) => {
                        attachment_total += count;
                        total_bytes += att_bytes;
                        if count > 0 {
                            debug!(
                                "downloaded {} Jira attachments ({} bytes) for project {}",
                                count, att_bytes, project.key
                            );
                        }
                    }
                    Err(err) => warn!(
                        "failed to download attachments for project {} for {}: {err}",
                        project.key,
                        cred.display_line()
                    ),
                }
            }
            Err(err) => warn!(
                "failed to export Jira project {} for {}: {err}",
                project.key,
                cred.display_line()
            ),
        }
    }

    if !export_sections.is_empty() {
        let html_leaf = format!("{prefix}__issues.html");
        let html_path = output_file_path(&site_dir, &html_leaf);
        let html = render_issues_html(&cred.url, &session_user, &prefix, &export_sections);
        match write_issues_html(&html_path, &html).await {
            Ok(bytes) => {
                total_bytes += bytes;
                debug!(
                    "wrote Jira HTML export ({} bytes, {} issues) for {}",
                    bytes,
                    issues_total,
                    cred.display_line()
                );
                written.push((
                    JiraProject {
                        key: "HTML".into(),
                        name: "issues.html".into(),
                    },
                    html_path,
                    bytes,
                ));
            }
            Err(err) => warn!(
                "failed to write Jira HTML export for {}: {err}",
                cred.display_line()
            ),
        }
    }

    Ok((
        JiraAccountStats {
            username: session_user,
            is_admin,
            projects: project_count,
            issues_exported: issues_total as usize,
            attachments: attachment_total,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}
