//! Bitrix admin client: authenticate, list backups, download `/bitrix/backup` archives.

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, output_file_path_in_bucket, extension_bucket, Credential};
use regex::Regex;
use reqwest::{Client, Response, Url};
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};

// #region agent log
fn bitrix_debug(hypothesis_id: &str, location: &str, message: &str, data: serde_json::Value) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let line = serde_json::json!({
        "sessionId": "be3b27",
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0),
        "runId": "bitrix-debug"
    });
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}

fn host_only(url: &Url) -> String {
    url.host_str().unwrap_or("unknown").to_string()
}
// #endregion

static SESSID_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)(?:['"]bitrix_sessid['"]\s*:\s*['"]|name=["']sessid["']\s+value=["']|sessid=)([a-f0-9]{32})"#,
    )
    .unwrap()
});

/// Backup filenames as linked from dump_list / fileman.
static BACKUP_NAME_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)(?:f_id=|/bitrix/backup/|path=/%2Fbitrix%2Fbackup%2F|path=/bitrix/backup/)([a-z0-9._-]+\.(?:tar\.gz|enc|sql|tar)(?:\.\d+)?)"#,
    )
    .unwrap()
});

static BACKUP_LOOSE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)\b([a-z0-9][a-z0-9._-]{5,}\.(?:tar\.gz|enc|sql|tar)(?:\.\d+)?)\b"#).unwrap()
});

static BACKUP_PART_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"^(.+\.(?:tar\.gz|enc|sql|tar))\.\d+$"#).unwrap()
});

static WINDOW_OPEN_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)window\.open\(\s*["']([^"']+)["']"#).unwrap()
});

static HIDDEN_NAME_VALUE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*type\s*=\s*["']hidden["'][^>]*name\s*=\s*["']([^"']+)["'][^>]*value\s*=\s*["']([^"']*)["']"#,
    )
    .unwrap()
});

static HIDDEN_VALUE_NAME_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"(?i)<input[^>]*type\s*=\s*["']hidden["'][^>]*value\s*=\s*["']([^"']*)["'][^>]*name\s*=\s*["']([^"']+)["']"#,
    )
    .unwrap()
});

static BACKUP_HREF_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)href\s*=\s*["']([^"']+\.(?:tar\.gz|enc|sql|tar)(?:\.\d+)?)["']"#).unwrap()
});

#[derive(Debug, Clone)]
pub struct BitrixClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for BitrixClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct BitrixBackup {
    pub name: String,
    pub bucket_id: i32,
}

/// Summary shown for successful Bitrix downloads (Good log lines).
#[derive(Debug, Clone)]
pub struct BitrixAccountStats {
    pub username: String,
    pub is_admin: bool,
    pub backups: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl BitrixAccountStats {
    pub fn detail_line(&self) -> String {
        let downloaded = crate::stats_display::file_count(self.downloaded, self.backups);
        format!(
            "user={} admin={} backups={} downloaded={downloaded} ({})",
            self.username,
            if self.is_admin { "yes" } else { "no" },
            self.backups,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

struct BitrixClient {
    http: Client,
    /// Always `https://host/bitrix/admin/` — for dump_list, fileman, etc.
    admin_root: Url,
    /// Login page: `/bitrix/admin/` or `/bitrix/admin/index.php`.
    auth_entry: Url,
    username: String,
    password: String,
}

impl BitrixClient {
    fn new(cred: &Credential, config: &BitrixClientConfig) -> Result<Self> {
        let http = Client::builder()
            .cookie_store(true)
            .timeout(config.timeout)
            .connect_timeout(Duration::from_secs(20))
            .danger_accept_invalid_certs(config.insecure)
            .redirect(reqwest::redirect::Policy::limited(10))
            .user_agent(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 \
                 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            )
            .build()
            .context("build HTTP client")?;

        let mut auth_entry = cred.url.clone();
        let trimmed = auth_entry.path().trim_end_matches('/').to_string();
        auth_entry.set_path(&trimmed);

        let mut admin_root = auth_entry.clone();
        admin_root.set_path("/bitrix/admin/");
        admin_root.set_query(None);
        admin_root.set_fragment(None);

        Ok(Self {
            http,
            admin_root,
            auth_entry,
            username: cred.username.clone(),
            password: cred.password.clone(),
        })
    }

    fn host(&self) -> String {
        host_only(&self.admin_root)
    }

    fn origin(&self) -> Result<Url> {
        let mut origin = self.admin_root.clone();
        origin.set_path("/");
        origin.set_query(None);
        origin.set_fragment(None);
        Ok(origin)
    }

    fn admin_url(&self, rel: &str) -> Result<Url> {
        self.admin_root
            .join(rel.trim_start_matches('/'))
            .with_context(|| format!("join admin url `{rel}`"))
    }

    fn site_url(&self, path: &str) -> Result<Url> {
        self.origin()?
            .join(path.trim_start_matches('/'))
            .with_context(|| format!("join site url `{path}`"))
    }

    async fn authenticate(&self) -> Result<(String, String)> {
        let auth_page = self.auth_entry.clone();
        let index = if self
            .auth_entry
            .path()
            .to_ascii_lowercase()
            .contains("index.php")
        {
            self.auth_entry.clone()
        } else {
            self.admin_url("index.php")?
        };
        let admin_dir = self.admin_root.clone();

        let probe = self
            .http
            .get(auth_page.clone())
            .send()
            .await
            .context("cannot reach Bitrix admin")?;
        let probe_status = probe.status().as_u16();
        let probe_html = probe.text().await.unwrap_or_default();
        let probe_has_captcha = probe_html.to_ascii_lowercase().contains("captcha");
        // #region agent log
        bitrix_debug(
            "H1",
            "bitrix.rs:authenticate:probe",
            "admin probe",
            serde_json::json!({
                "host": self.host(),
                "auth_path": self.auth_entry.path(),
                "status": probe_status,
                "html_len": probe_html.len(),
                "has_password_field": has_password_field(&probe_html),
                "looks_bitrix": looks_like_bitrix(&probe_html),
                "has_captcha": probe_has_captcha,
            }),
        );
        // #endregion
        if probe_html.is_empty() {
            bail!("empty response from Bitrix admin");
        }
        if !looks_like_bitrix(&probe_html)
            && !self.auth_entry.path().to_ascii_lowercase().contains("bitrix")
        {
            bail!("not a Bitrix admin panel");
        }

        if probe_html.to_ascii_lowercase().contains("bx_rsa")
            || probe_html.to_ascii_lowercase().contains("rsa_encryption")
        {
            bail!("RSA-encrypted auth not supported");
        }

        // Already authenticated (cookie jar / prior attempt).
        if !has_password_field(&probe_html) && looks_like_admin_session(&probe_html) {
            return Ok((
                self.username.clone(),
                extract_sessid(&probe_html).unwrap_or_default(),
            ));
        }

        let hidden = extract_hidden_fields(&probe_html);
        let mut sessid = extract_sessid(&probe_html);
        let origin = self.origin()?;

        let login_targets = [
            with_query(&auth_page, "login=yes&lang=ru"),
            with_query(&auth_page, "login=yes"),
            auth_page.clone(),
            with_query(&index, "login=yes&lang=ru"),
            with_query(&index, "login=yes"),
            index.clone(),
            with_query(&admin_dir, "login=yes&lang=ru"),
            with_query(&admin_dir, "login=yes"),
            with_query(&origin, "login=yes"),
        ];

        let mut saw_auth_cookie = false;

        for login_url in login_targets {
            let mut form = hidden.clone();
            form.push(("AUTH_FORM".into(), "Y".into()));
            form.push(("TYPE".into(), "AUTH".into()));
            form.push(("USER_LOGIN".into(), self.username.clone()));
            form.push(("USER_PASSWORD".into(), self.password.clone()));
            form.push(("USER_REMEMBER".into(), "Y".into()));
            form.push(("Login".into(), "Y".into()));
            form.push(("backurl".into(), "/bitrix/admin/".into()));
            if let Some(ref s) = sessid {
                form.push(("sessid".into(), s.clone()));
            }
            dedupe_form(&mut form);

            let login_resp = self
                .http
                .post(login_url.clone())
                .header(reqwest::header::REFERER, auth_page.as_str())
                .form(&form.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect::<Vec<_>>())
                .send()
                .await
                .with_context(|| format!("Bitrix login POST {login_url}"))?;

            saw_auth_cookie |= response_has_bitrix_auth_cookie(&login_resp);
            let login_html = login_resp.text().await.unwrap_or_default();
            if sessid.is_none() {
                sessid = extract_sessid(&login_html);
            }

            let check_html = self.get_text(auth_page.clone()).await.unwrap_or_default();
            if sessid.is_none() {
                sessid = extract_sessid(&check_html);
            }
            saw_auth_cookie |= html_indicates_auth_user(&check_html, &self.username);

            if !has_password_field(&check_html)
                && (looks_like_admin_session(&check_html) || saw_auth_cookie)
            {
                // #region agent log
                bitrix_debug(
                    "H4",
                    "bitrix.rs:authenticate:ok",
                    "session ok in login loop",
                    serde_json::json!({
                        "host": self.host(),
                        "saw_auth_cookie": saw_auth_cookie,
                        "login_path": login_url.path(),
                    }),
                );
                // #endregion
                return Ok((
                    self.username.clone(),
                    sessid.unwrap_or_default(),
                ));
            }

            if login_html.to_ascii_lowercase().contains("captcha") {
                // #region agent log
                bitrix_debug(
                    "H2",
                    "bitrix.rs:authenticate:captcha",
                    "captcha in login response",
                    serde_json::json!({ "host": self.host() }),
                );
                // #endregion
                bail!("captcha required");
            }
        }

        let check_html = self.get_text(auth_page.clone()).await.unwrap_or_default();
        if has_password_field(&check_html) {
            // #region agent log
            bitrix_debug(
                "H3",
                "bitrix.rs:authenticate:invalid",
                "still on password form",
                serde_json::json!({
                    "host": self.host(),
                    "saw_auth_cookie": saw_auth_cookie,
                }),
            );
            // #endregion
            if let Some(msg) = extract_auth_error_message(&check_html) {
                bail!("invalid credentials — {msg}");
            }
            bail!("invalid credentials");
        }
        if looks_like_admin_session(&check_html) || saw_auth_cookie {
            // #region agent log
            bitrix_debug(
                "H4",
                "bitrix.rs:authenticate:ok_final",
                "session ok after loop",
                serde_json::json!({
                    "host": self.host(),
                    "saw_auth_cookie": saw_auth_cookie,
                }),
            );
            // #endregion
            return Ok((
                self.username.clone(),
                sessid.unwrap_or_default(),
            ));
        }
        // #region agent log
        bitrix_debug(
            "H4",
            "bitrix.rs:authenticate:no_session",
            "no admin session",
            serde_json::json!({
                "host": self.host(),
                "saw_auth_cookie": saw_auth_cookie,
                "final_has_password": has_password_field(&check_html),
                "final_admin_like": looks_like_admin_session(&check_html),
            }),
        );
        // #endregion
        bail!("no Bitrix admin session after login attempts");
    }

    async fn fetch_dump_list(&self, sessid: &str) -> Result<(String, Option<String>)> {
        let mut pages = Vec::new();

        let mut url = self.admin_url("dump_list.php")?;
        url.set_query(Some("lang=ru"));
        pages.push(self.get_text(url).await?);

        let mut list_url = self.admin_url("dump_list.php")?;
        let q = if sessid.is_empty() {
            "lang=ru&mode=list&table_id=tbl_dump".to_string()
        } else {
            format!("lang=ru&mode=list&table_id=tbl_dump&sessid={sessid}")
        };
        list_url.set_query(Some(&q));
        if let Ok(t) = self.get_text(list_url).await {
            pages.push(t);
        }

        let mut fileman = self.admin_url("fileman_admin.php")?;
        fileman.set_query(Some("lang=ru&path=%2Fbitrix%2Fbackup"));
        if let Ok(t) = self.get_text(fileman).await {
            pages.push(t);
        }

        let mut fileman2 = self.admin_url("fileman_admin.php")?;
        fileman2.set_query(Some("lang=ru&site=&path=%2Fbitrix%2Fbackup"));
        if let Ok(t) = self.get_text(fileman2).await {
            pages.push(t);
        }

        let combined = pages.join("\n");
        let sid = extract_sessid(&combined);
        Ok((combined, sid))
    }

    async fn get_text(&self, url: Url) -> Result<String> {
        let resp = self
            .http
            .get(url.clone())
            .send()
            .await
            .with_context(|| format!("GET {url}"))?;
        Ok(resp.text().await.unwrap_or_default())
    }

    async fn list_backups(&self, sessid: &str) -> Result<Vec<BitrixBackup>> {
        let (html, _) = self.fetch_dump_list(sessid).await?;

        if has_password_field(&html) {
            bail!("session expired — dump_list requires login");
        }
        if is_access_denied(&html) {
            bail!("access denied to backup tools (not admin)");
        }

        let mut names = extract_backup_names(&html);

        if names.is_empty() {
            if let Ok(dir_html) = self.get_text(self.site_url("bitrix/backup/")?).await {
                if !has_password_field(&dir_html) {
                    for caps in BACKUP_HREF_RE.captures_iter(&dir_html) {
                        if let Some(m) = caps.get(1) {
                            let name = m
                                .as_str()
                                .trim_start_matches('/')
                                .rsplit('/')
                                .next()
                                .unwrap_or(m.as_str());
                            let name = strip_part_suffix(name);
                            if is_plausible_backup_name(&name) {
                                names.push(name);
                            }
                        }
                    }
                    names.sort();
                    names.dedup();
                }
            }
        }

        let backups: Vec<BitrixBackup> = names
            .into_iter()
            .map(|name| BitrixBackup {
                name,
                bucket_id: 0,
            })
            .collect();
        self.log_list_backups(&html, &backups);
        Ok(backups)
    }

    fn log_list_backups(&self, html: &str, names: &[BitrixBackup]) {
        // #region agent log
        let lower = html.to_ascii_lowercase();
        bitrix_debug(
            "H5",
            "bitrix.rs:list_backups",
            "backup listing",
            serde_json::json!({
                "host": self.host(),
                "names_found": names.len(),
                "html_len": html.len(),
                "has_password_field": has_password_field(html),
                "has_tbl_dump": lower.contains("tbl_dump"),
                "has_fileman_backup": lower.contains("fileman") && lower.contains("backup"),
            }),
        );
        // #endregion
    }

    async fn download_backup(
        &self,
        backup: &BitrixBackup,
        sessid: &str,
        run_output_dir: &Path,
        file_prefix: &str,
    ) -> Result<u64> {
        let primary_leaf = format!(
            "{}__{}",
            file_prefix,
            safe_path_component(&backup.name)
        );
        let bucket = extension_bucket(&primary_leaf);

        let mut total = 0u64;
        let mut part = 0u32;
        let mut name = backup.name.clone();

        loop {
            let bytes = self
                .download_one_part(&name, backup.bucket_id, sessid)
                .await?;
            let Some(bytes) = bytes else { break };

            let leaf = format!("{}__{}", file_prefix, safe_path_component(&name));
            let dest = output_file_path_in_bucket(run_output_dir, &leaf, &bucket);
            if let Some(parent) = dest.parent() {
                fs::create_dir_all(parent).await?;
            }
            let mut file = fs::File::create(&dest)
                .await
                .with_context(|| format!("create {}", dest.display()))?;
            file.write_all(&bytes).await?;
            total += bytes.len() as u64;
            debug!(
                "saved Bitrix backup {} ({} bytes)",
                dest.display(),
                bytes.len()
            );

            part += 1;
            if part > 64 {
                break;
            }
            name = format!("{}.{}", backup.name, part);
        }

        if total == 0 {
            bail!("empty or inaccessible backup {}", backup.name);
        }
        Ok(total)
    }

    async fn download_one_part(
        &self,
        name: &str,
        bucket_id: i32,
        sessid: &str,
    ) -> Result<Option<Vec<u8>>> {
        // 1) Official dump_list download action → window.open URLs
        if let Some(bytes) = self.try_dump_list_download(name, bucket_id, sessid).await? {
            return Ok(Some(bytes));
        }

        // 2) fileman download (works when /bitrix/backup is blocked by nginx)
        if let Some(bytes) = self.try_fileman_download(name).await? {
            return Ok(Some(bytes));
        }

        // 3) Direct path with session cookies
        let path = format!("bitrix/backup/{name}");
        let url = self.site_url(&path)?;
        let resp = self.http.get(url).send().await?;
        if !resp.status().is_success() {
            return Ok(None);
        }
        let bytes = resp.bytes().await?.to_vec();
        if bytes.is_empty() || looks_like_html_bytes(&bytes) {
            return Ok(None);
        }
        Ok(Some(bytes))
    }

    async fn try_dump_list_download(
        &self,
        name: &str,
        bucket_id: i32,
        sessid: &str,
    ) -> Result<Option<Vec<u8>>> {
        let mut url = self.admin_url("dump_list.php")?;
        let mut q = format!(
            "action=download&f_id={}&BUCKET_ID={}",
            urlencoding_minimal(name),
            bucket_id
        );
        if !sessid.is_empty() {
            q.push_str("&sessid=");
            q.push_str(sessid);
        }
        q.push_str("&lang=ru");
        url.set_query(Some(&q));

        let resp = self.http.get(url).send().await?;
        if !resp.status().is_success() {
            return Ok(None);
        }
        let ctype = content_type(&resp);
        let bytes = resp.bytes().await?.to_vec();
        if !bytes.is_empty() && !looks_like_html_bytes(&bytes) && !ctype.contains("text/html") {
            return Ok(Some(bytes));
        }

        let html = String::from_utf8_lossy(&bytes);
        for caps in WINDOW_OPEN_RE.captures_iter(&html) {
            let href = caps.get(1).map(|m| m.as_str()).unwrap_or("");
            if href.is_empty() {
                continue;
            }
            let file_url = if href.starts_with("http") {
                Url::parse(href).ok()
            } else {
                self.site_url(href.trim_start_matches('/')).ok()
            };
            let Some(file_url) = file_url else { continue };
            let file_resp = self.http.get(file_url).send().await?;
            if !file_resp.status().is_success() {
                continue;
            }
            let file_bytes = file_resp.bytes().await?.to_vec();
            if !file_bytes.is_empty() && !looks_like_html_bytes(&file_bytes) {
                return Ok(Some(file_bytes));
            }
        }
        Ok(None)
    }

    async fn try_fileman_download(&self, name: &str) -> Result<Option<Vec<u8>>> {
        let path = format!("/bitrix/backup/{name}");
        for site in ["s1", ""] {
            let mut url = self.admin_url("fileman_file_download.php")?;
            let q = if site.is_empty() {
                format!(
                    "lang=ru&path={}",
                    urlencoding_minimal(&path)
                )
            } else {
                format!(
                    "lang=ru&site={site}&path={}",
                    urlencoding_minimal(&path)
                )
            };
            url.set_query(Some(&q));
            let resp = self.http.get(url).send().await?;
            if !resp.status().is_success() {
                continue;
            }
            let ctype = content_type(&resp);
            let bytes = resp.bytes().await?.to_vec();
            if bytes.is_empty() || looks_like_html_bytes(&bytes) || ctype.contains("text/html") {
                continue;
            }
            return Ok(Some(bytes));
        }
        Ok(None)
    }
}

fn dedupe_form(form: &mut Vec<(String, String)>) {
    let mut seen = BTreeSet::new();
    form.retain(|(k, _)| seen.insert(k.to_ascii_lowercase()));
}

fn extract_hidden_fields(html: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    for caps in HIDDEN_NAME_VALUE_RE.captures_iter(html) {
        let name = caps.get(1).map(|m| m.as_str()).unwrap_or("");
        if name.eq_ignore_ascii_case("USER_LOGIN") || name.eq_ignore_ascii_case("USER_PASSWORD") {
            continue;
        }
        out.push((name.to_string(), caps.get(2).map(|m| m.as_str()).unwrap_or("").to_string()));
    }
    for caps in HIDDEN_VALUE_NAME_RE.captures_iter(html) {
        let name = caps.get(2).map(|m| m.as_str()).unwrap_or("");
        if name.eq_ignore_ascii_case("USER_LOGIN") || name.eq_ignore_ascii_case("USER_PASSWORD") {
            continue;
        }
        out.push((name.to_string(), caps.get(1).map(|m| m.as_str()).unwrap_or("").to_string()));
    }
    out
}

fn response_has_bitrix_auth_cookie(resp: &Response) -> bool {
    resp.headers()
        .get_all(reqwest::header::SET_COOKIE)
        .iter()
        .any(|v| {
            let s = v.to_str().unwrap_or("").to_ascii_uppercase();
            s.contains("BITRIX_SM_LOGIN=")
                || s.contains("BITRIX_SM_UIDH=")
                || s.contains("BITRIX_SM_UIDL=")
        })
}

fn html_indicates_auth_user(html: &str, username: &str) -> bool {
    if username.is_empty() {
        return false;
    }
    let lower = html.to_ascii_lowercase();
    let user = username.to_ascii_lowercase();
    lower.contains(&format!("bitrix_sm_login={user}"))
        || lower.contains(&format!(">{user}<"))
}

fn extract_auth_error_message(html: &str) -> Option<String> {
    let patterns = [
        r#"(?is)"MESSAGE"\s*=>\s*"([^"]+)""#,
        r#"(?is)'MESSAGE'\s*:\s*'([^']+)'"#,
        r#"(?is)admin_authorize_error[^>]*>\s*([^<]+)"#,
    ];
    for pat in patterns {
        if let Ok(re) = Regex::new(pat) {
            if let Some(caps) = re.captures(html) {
                let msg = caps.get(1)?.as_str().trim();
                if !msg.is_empty() && msg.len() < 200 {
                    return Some(msg.replace('\n', " "));
                }
            }
        }
    }
    None
}

fn content_type(resp: &Response) -> String {
    resp.headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_ascii_lowercase()
}

fn urlencoding_minimal(s: &str) -> String {
    let mut out = String::with_capacity(s.len() * 2);
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' | b'/' => {
                out.push(b as char);
            }
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

fn with_query(url: &Url, query: &str) -> Url {
    let mut u = url.clone();
    u.set_query(Some(query));
    u
}

fn looks_like_html_bytes(bytes: &[u8]) -> bool {
    let sample = String::from_utf8_lossy(&bytes[..bytes.len().min(512)]).to_ascii_lowercase();
    sample.contains("<html")
        || sample.contains("<!doctype")
        || sample.contains("bitrix_sessid")
        || sample.contains("<script")
        || sample.contains("window.open")
}

fn extract_sessid(html: &str) -> Option<String> {
    SESSID_RE
        .captures(html)
        .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
}

fn extract_backup_names(html: &str) -> Vec<String> {
    let mut set = BTreeSet::new();
    for re in [&BACKUP_NAME_RE, &BACKUP_LOOSE_RE] {
        for caps in re.captures_iter(html) {
            if let Some(m) = caps.get(1) {
                let name = strip_part_suffix(m.as_str());
                if is_plausible_backup_name(&name) {
                    set.insert(name);
                }
            }
        }
    }
    set.into_iter().collect()
}

fn strip_part_suffix(name: &str) -> String {
    if let Some(caps) = BACKUP_PART_RE.captures(name) {
        return caps.get(1).unwrap().as_str().to_string();
    }
    name.to_string()
}

fn is_plausible_backup_name(name: &str) -> bool {
    let lower = name.to_ascii_lowercase();
    if lower.contains("restore.php") || lower.contains("index.php") {
        return false;
    }
    lower.ends_with(".enc")
        || lower.ends_with(".tar.gz")
        || lower.ends_with(".tar")
        || lower.ends_with(".sql")
}

fn looks_like_bitrix(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("bitrix")
        || lower.contains("bx-")
        || lower.contains("bitrix_sessid")
        || lower.contains("user_login")
}

fn has_password_field(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("name=\"user_password\"")
        || lower.contains("name='user_password'")
        || lower.contains("id=\"user_password\"")
        || lower.contains("id='user_password'")
}

fn looks_like_admin_session(html: &str) -> bool {
    if has_password_field(html) {
        return false;
    }
    let lower = html.to_ascii_lowercase();
    lower.contains("logout")
        || lower.contains("выход")
        || lower.contains("dump_list")
        || lower.contains("bx-panel")
        || lower.contains("menu_main")
        || lower.contains("adm-header")
        || lower.contains("adm-workarea")
        || lower.contains("adm-detail-content")
        || lower.contains("bitrix/admin/index.php")
}

fn is_access_denied(html: &str) -> bool {
    let lower = html.to_ascii_lowercase();
    lower.contains("access denied")
        || lower.contains("доступ запрещен")
        || lower.contains("доступ запрещён")
}

/// Real backup UI — not the login shell and not a random admin page.
#[allow(dead_code)]
fn is_dump_list_page(html: &str) -> bool {
    if has_password_field(html) || html.trim().is_empty() {
        return false;
    }
    let lower = html.to_ascii_lowercase();
    lower.contains("tbl_dump")
        || lower.contains("adm-list-table")
        || lower.contains("dump.php?lang")
        || (lower.contains("dump_list")
            && (lower.contains("backup") || lower.contains("резерв") || lower.contains("архив")))
        || (lower.contains("fileman") && lower.contains("/bitrix/backup"))
}

fn safe_path_component(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        if c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == '_' {
            out.push(c);
        } else {
            out.push('_');
        }
    }
    if out.is_empty() {
        "file".into()
    } else {
        out
    }
}

/// Login to Bitrix admin and download available local backups.
pub async fn download_personal_backups(
    cred: &Credential,
    config: &BitrixClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(BitrixAccountStats, Vec<(BitrixBackup, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_personal_backups_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_personal_backups_once(
    cred: Credential,
    config: &BitrixClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(BitrixAccountStats, Vec<(BitrixBackup, PathBuf, u64)>)> {
    // #region agent log
    bitrix_debug(
        "H1",
        "bitrix.rs:download_start",
        "target begin",
        serde_json::json!({
            "host": host_only(&cred.url),
            "user_len": cred.username.len(),
        }),
    );
    // #endregion
    let client = BitrixClient::new(&cred, config)?;
    let (username, sessid) = match client.authenticate().await {
        Ok(v) => v,
        Err(e) => {
            // #region agent log
            let err = e.to_string();
            bitrix_debug(
                "H1",
                "bitrix.rs:download_auth_fail",
                "authenticate failed",
                serde_json::json!({
                    "host": host_only(&cred.url),
                    "err_prefix": err.chars().take(80).collect::<String>(),
                    "is_network": err.to_ascii_lowercase().contains("cannot reach")
                        || err.to_ascii_lowercase().contains("timed out")
                        || err.to_ascii_lowercase().contains("error sending request"),
                }),
            );
            // #endregion
            return Err(e);
        }
    };

    let backups = match client.list_backups(&sessid).await {
        Ok(v) => v,
        Err(e) => {
            // #region agent log
            bitrix_debug(
                "H5",
                "bitrix.rs:download_list_fail",
                "list_backups failed",
                serde_json::json!({
                    "host": host_only(&cred.url),
                    "err_prefix": e.to_string().chars().take(80).collect::<String>(),
                }),
            );
            // #endregion
            return Err(e);
        }
    };

    let site_dir = cred.site_output_dir(output_dir, "bitrix");
    let prefix = cred.account_file_prefix();

    let backup_count = backups.len();
    if backup_count == 0 {
        bail!(
            "no Bitrix backups found for {} (admin ok, dump_list empty)",
            cred.display_line()
        );
    }

    if !download_files {
        return Ok((
            BitrixAccountStats {
                username,
                is_admin: true,
                backups: backup_count,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let mut written = Vec::new();
    for backup in &backups {
        match client
            .download_backup(backup, &sessid, &site_dir, &prefix)
            .await
        {
            Ok(bytes) => {
                let leaf = format!(
                    "{}__{}",
                    prefix,
                    safe_path_component(&backup.name)
                );
                let path = output_file_path(&site_dir, &leaf);
                written.push((backup.clone(), path, bytes));
            }
            Err(err) => warn!(
                "failed to download Bitrix backup {} for {}: {err}",
                backup.name,
                cred.display_line()
            ),
        }
    }

    if written.is_empty() {
        bail!(
            "found {backup_count} Bitrix backups for {} but failed to download any",
            cred.display_line()
        );
    }

    let bytes: u64 = written.iter().map(|(_, _, b)| *b).sum();
    Ok((
        BitrixAccountStats {
            username,
            is_admin: true,
            backups: backup_count,
            downloaded: written.len(),
            bytes,
        },
        written,
    ))
}
