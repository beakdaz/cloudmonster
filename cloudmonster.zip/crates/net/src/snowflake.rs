//! Snowflake session login + SQL export (databases / warehouses / roles HTML).

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, snowflake_account_from_url, Credential};
use reqwest::{Client, Url};
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tracing::debug;

const MAX_DATABASES: usize = 100;
const MAX_SCHEMAS_PER_DB: usize = 80;
const MAX_WAREHOUSES: usize = 100;
const MAX_ROLES: usize = 200;

#[derive(Debug, Clone)]
pub struct SnowflakeClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for SnowflakeClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SnowflakeExportOptions {
    pub databases: bool,
    pub warehouses: bool,
    pub roles: bool,
}

impl SnowflakeExportOptions {
    pub fn all_enabled() -> Self {
        Self {
            databases: true,
            warehouses: true,
            roles: true,
        }
    }

    pub fn any_selected(self) -> bool {
        self.databases || self.warehouses || self.roles
    }
}

impl Default for SnowflakeExportOptions {
    fn default() -> Self {
        Self::all_enabled()
    }
}

#[derive(Debug, Clone)]
pub struct SnowflakeAccountStats {
    pub username: String,
    pub role: String,
    pub warehouse: Option<String>,
    pub databases: usize,
    pub schemas: usize,
    pub warehouses_listed: usize,
    pub roles_listed: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl SnowflakeAccountStats {
    pub fn detail_line(&self) -> String {
        let check_metric = self
            .databases
            .max(self.schemas)
            .max(self.warehouses_listed)
            .max(self.roles_listed);
        let files = crate::stats_display::file_count(self.downloaded, check_metric);
        format!(
            "user={} role={} wh={} db={} schemas={} wh_list={} roles={} files={files} ({})",
            self.username,
            self.role,
            self.warehouse.as_deref().unwrap_or("-"),
            self.databases,
            self.schemas,
            self.warehouses_listed,
            self.roles_listed,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

struct SnowflakeSession {
    http: Client,
    base: Url,
    token: String,
    role: String,
    warehouse: Option<String>,
    display_user: String,
}

impl SnowflakeSession {
    fn new(base: Url, config: &SnowflakeClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(8))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-snowflake/0.1");
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            base,
            token: String::new(),
            role: String::new(),
            warehouse: None,
            display_user: String::new(),
        })
    }

    fn join(&self, path: &str) -> Result<Url> {
        self.base
            .join(path.trim_start_matches('/'))
            .context("snowflake url join")
    }

    async fn resolve_base_url(&mut self) -> Result<()> {
        if let Some(acct) = snowflake_account_from_url(&self.base) {
            if let Some(u) = account_locator_base_urls(&acct).into_iter().next() {
                self.base = u;
                return Ok(());
            }
        }

        let host = self.base.host_str().unwrap_or("").to_ascii_lowercase();
        if host.ends_with(".snowflakecomputing.com") {
            return Ok(());
        }

        if host.ends_with(".snowflake.com") && host != "app.snowflake.com" {
            let probe = self.base.clone();
            match self.http.get(probe).send().await {
                Ok(resp) => {
                    let mut final_url = resp.url().clone();
                    if let Some(h) = final_url.host_str() {
                        if h.ends_with(".snowflakecomputing.com") {
                            final_url.set_path("/");
                            final_url.set_query(None);
                            final_url.set_fragment(None);
                            self.base = final_url;
                            debug!("Snowflake vanity resolved to {}", self.base);
                        }
                    }
                }
                Err(err) => debug!("Snowflake vanity probe {}: {err}", self.base),
            }
        }
        Ok(())
    }

    async fn login(&mut self, username: &str, password: &str) -> Result<()> {
        self.resolve_base_url().await?;
        let bases = login_base_candidates(&self.base);
        let mut last_err: Option<anyhow::Error> = None;

        for base in bases {
            self.base = base.clone();
            let account_candidates =
                account_name_candidates(&self.base, username, snowflake_account_from_url(&self.base));
            for account in account_candidates {
                for app_id in ["Snowflake UI", "GoClient", "JDBC"] {
                    match self
                        .try_login(username, password, &account, app_id)
                        .await
                    {
                        Ok(()) => return Ok(()),
                        Err(err) => {
                            debug!(
                                "Snowflake login base={} account=`{account}` app={app_id}: {err:#}",
                                self.base
                            );
                            last_err = Some(err);
                        }
                    }
                }
            }
        }
        Err(last_err.unwrap_or_else(|| anyhow::anyhow!("Snowflake login failed")))
    }

    async fn try_login(
        &mut self,
        username: &str,
        password: &str,
        account: &str,
        client_app_id: &str,
    ) -> Result<()> {
        let url = self.join("/session/v1/login-request")?;
        let body = serde_json::json!({
            "data": {
                "CLIENT_APP_ID": client_app_id,
                "CLIENT_APP_VERSION": "1.0.0",
                "ACCOUNT_NAME": account,
                "LOGIN_NAME": username,
                "PASSWORD": password,
            }
        });
        let resp = self
            .http
            .post(url)
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .json(&body)
            .send()
            .await
            .context("login-request")?;
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            bail!("login HTTP {status}: {}", truncate(&text, 400));
        }
        let parsed: Value = serde_json::from_str(&text).context("login json")?;
        if parsed.get("success").and_then(|v| v.as_bool()) == Some(false) {
            let msg = snowflake_error_message(&parsed);
            bail!("{msg}");
        }
        let data = parsed
            .get("data")
            .context("login response missing data")?;
        let token = data
            .get("token")
            .and_then(|v| v.as_str())
            .context("login missing token")?
            .to_string();
        self.token = token;
        self.display_user = data
            .get("displayUserName")
            .or_else(|| data.get("loginName"))
            .and_then(|v| v.as_str())
            .unwrap_or(username)
            .to_string();
        self.role = data
            .get("role")
            .and_then(|v| v.as_str())
            .unwrap_or("UNKNOWN")
            .to_string();
        self.warehouse = data
            .get("warehouse")
            .and_then(|v| v.as_str())
            .filter(|s| !s.is_empty())
            .map(str::to_string);

        if let Some(wh) = self.warehouse.clone() {
            let _ = self
                .exec_sql(&format!("USE WAREHOUSE \"{}\"", escape_ident(&wh)))
                .await;
        }
        Ok(())
    }

    async fn exec_sql(&self, sql: &str) -> Result<SqlResult> {
        let request_id = format!("{:016x}", rand::random::<u64>());
        let url = self.join(&format!(
            "/queries/v1/query-request?requestId={request_id}",
        ))?;
        let body = serde_json::json!({
            "sqlText": sql,
            "asyncExec": false,
            "sequenceId": 1,
            "isInternal": false,
        });
        let resp = self
            .http
            .post(url)
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .header("Authorization", format!("Snowflake Token=\"{}\"", self.token))
            .header("X-Snowflake-Authorization-Token-Type", "SNOWFLAKE")
            .json(&body)
            .send()
            .await
            .with_context(|| format!("query: {sql}"))?;
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            bail!("query HTTP {status}: {}", truncate(&text, 400));
        }
        parse_query_response(&text)
    }

    async fn show_databases(&self) -> Result<Vec<Vec<String>>> {
        let result = self.exec_sql("SHOW DATABASES").await?;
        Ok(result.rows)
    }

    async fn show_schemas_in_db(&self, db: &str) -> Result<Vec<Vec<String>>> {
        let sql = format!("SHOW SCHEMAS IN DATABASE \"{}\"", escape_ident(db));
        let result = self.exec_sql(&sql).await?;
        Ok(result.rows)
    }

    async fn show_warehouses(&self) -> Result<Vec<Vec<String>>> {
        let result = self.exec_sql("SHOW WAREHOUSES").await?;
        Ok(result.rows)
    }

    async fn show_roles(&self) -> Result<Vec<Vec<String>>> {
        let result = self.exec_sql("SHOW ROLES").await?;
        Ok(result.rows)
    }
}

struct SqlResult {
    columns: Vec<String>,
    rows: Vec<Vec<String>>,
}

fn parse_query_response(text: &str) -> Result<SqlResult> {
    let parsed: Value = serde_json::from_str(text).context("query json")?;
    if parsed.get("success").and_then(|v| v.as_bool()) == Some(false) {
        bail!("{}", snowflake_error_message(&parsed));
    }
    let data = parsed.get("data").context("query missing data")?;
    let columns: Vec<String> = data
        .get("rowtype")
        .and_then(|v| v.as_array())
        .map(|arr| {
            arr.iter()
                .filter_map(|c| c.get("name").and_then(|n| n.as_str()))
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default();
    let mut rows = Vec::new();
    if let Some(rowset) = data.get("rowset").and_then(|v| v.as_array()) {
        for row in rowset {
            if let Some(cells) = row.as_array() {
                let line: Vec<String> = cells
                    .iter()
                    .map(|c| match c {
                        Value::Null => String::new(),
                        Value::String(s) => s.clone(),
                        other => other.to_string(),
                    })
                    .collect();
                rows.push(line);
            }
        }
    }
    Ok(SqlResult { columns, rows })
}

fn escape_ident(s: &str) -> String {
    s.replace('"', "\"\"")
}

fn truncate(s: &str, max: usize) -> String {
    if s.len() <= max {
        s.to_string()
    } else {
        format!("{}…", &s[..max])
    }
}

fn snowflake_error_message(parsed: &Value) -> String {
    let msg = parsed
        .pointer("/message")
        .and_then(|v| v.as_str())
        .unwrap_or("request failed");
    let code = parsed
        .get("code")
        .or_else(|| parsed.pointer("/data/code"))
        .map(|c| c.to_string())
        .unwrap_or_default();
    if code.is_empty() {
        msg.to_string()
    } else {
        format!("{msg} ({code})")
    }
}

fn account_locator_base_urls(account: &str) -> Vec<Url> {
    let a = account.trim();
    let mut out: Vec<Url> = Vec::new();
    let mut push = |s: &str| {
        if let Ok(u) = Url::parse(s) {
            if !out.iter().any(|x| x.as_str() == u.as_str()) {
                out.push(u);
            }
        }
    };
    push(&format!("https://{a}.snowflakecomputing.com/"));
    push(&format!("https://{a}.us-east-1.snowflakecomputing.com/"));
    push(&format!("https://{a}.us-west-2.aws.snowflakecomputing.com/"));
    out
}

fn login_base_candidates(base: &Url) -> Vec<Url> {
    let mut out: Vec<Url> = Vec::new();
    let mut push = |u: Url| {
        if !out.iter().any(|x| x.as_str() == u.as_str()) {
            out.push(u);
        }
    };
    if let Some(acct) = snowflake_account_from_url(base) {
        for u in account_locator_base_urls(&acct) {
            push(u);
        }
    }
    push(base.clone());

    let host = base.host_str().unwrap_or("").to_ascii_lowercase();
    if host.ends_with(".snowflake.com") {
        if let Some(prefix) = host.strip_suffix(".snowflake.com") {
            if !prefix.is_empty() {
                if let Ok(u) = Url::parse(&format!("https://{prefix}.snowflakecomputing.com/")) {
                    push(u);
                }
                if let Ok(u) = Url::parse(&format!("https://{prefix}.us-east-1.snowflakecomputing.com/")) {
                    push(u);
                }
            }
        }
    }
    if host == "app.snowflake.com" {
        // Many lists use app.snowflake.com without account host — still try app endpoint.
        if let Ok(u) = Url::parse("https://app.snowflakecomputing.com/") {
            push(u);
        }
    }
    out
}

fn account_name_candidates(
    base: &Url,
    username: &str,
    explicit_account: Option<String>,
) -> Vec<String> {
    let host = base.host_str().unwrap_or("").to_ascii_lowercase();
    let mut raw: Vec<String> = Vec::new();
    let mut push = |s: String| {
        let s = s.trim().to_string();
        if s.is_empty() {
            return;
        }
        if !raw.iter().any(|x| x.eq_ignore_ascii_case(&s)) {
            raw.push(s);
        }
    };

    if let Some(acct) = explicit_account {
        push(acct.clone());
        if acct.contains('-') {
            push(acct.replace('-', "_"));
        }
    }

    if host.ends_with(".snowflakecomputing.com") {
        let prefix = host
            .strip_suffix(".snowflakecomputing.com")
            .unwrap_or(&host);
        push(prefix.to_string());
        let parts: Vec<&str> = prefix.split('.').collect();
        for n in 1..=parts.len() {
            push(parts[..n].join("."));
        }
        if let Some(stripped) = prefix
            .strip_suffix(".aws")
            .or_else(|| prefix.strip_suffix(".azure"))
            .or_else(|| prefix.strip_suffix(".gcp"))
        {
            push(stripped.to_string());
            let p2: Vec<&str> = stripped.split('.').collect();
            for n in 1..=p2.len() {
                push(p2[..n].join("."));
            }
        }
    } else if host.ends_with(".snowflake.com") {
        if let Some(prefix) = host.strip_suffix(".snowflake.com") {
            push(prefix.to_string());
            if prefix.contains('-') {
                push(prefix.replace('-', "_"));
            }
        }
    } else if host == "app.snowflake.com" {
        if let Some((acct, _user)) = username.split_once('.') {
            if !acct.is_empty() && acct.len() <= 64 && !acct.contains('@') {
                push(acct.to_string());
            }
        }
        push("app".to_string());
    }

    let mut out: Vec<String> = Vec::new();
    for a in raw {
        for v in [a.clone(), a.to_uppercase(), a.to_lowercase()] {
            if !out.iter().any(|x| x.eq_ignore_ascii_case(&v)) {
                out.push(v);
            }
        }
    }
    if out.is_empty() && !host.is_empty() {
        out.push(host.clone());
    }
    out
}

fn db_name_from_show_row(row: &[String]) -> Option<String> {
    row.get(1)
        .cloned()
        .filter(|s| !s.is_empty())
        .or_else(|| row.first().cloned().filter(|s| !s.is_empty()))
}

fn render_table_html(title: &str, account: &str, columns: &[String], rows: &[Vec<String>]) -> String {
    let cols = if columns.is_empty() {
        vec!["value".to_string()]
    } else {
        columns.to_vec()
    };
    let mut thead = String::new();
    for col in &cols {
        thead.push_str(&format!("<th>{}</th>", html_escape(col)));
    }
    let mut tbody = String::new();
    for row in rows {
        tbody.push_str("<tr>");
        if cols.len() == 1 && row.len() > 1 {
            tbody.push_str(&format!("<td>{}</td>", html_escape(&row.join(" | "))));
        } else {
            for cell in row {
                tbody.push_str(&format!("<td>{}</td>", html_escape(cell)));
            }
        }
        tbody.push_str("</tr>");
    }
    format!(
        r#"<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>{title}</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 1.5rem; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #ccc; padding: 0.35rem 0.5rem; text-align: left; font-size: 13px; }}
th {{ background: #29b5e8; color: #fff; }}
</style></head>
<body>
<h1>{title}</h1>
<p>Account: {account}</p>
<table><thead><tr>{thead}</tr></thead><tbody>{tbody}</tbody></table>
</body></html>"#
    )
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

pub async fn download_snowflake_account(
    cred: &Credential,
    config: &SnowflakeClientConfig,
    output_dir: &Path,
    download_files: bool,
    export_options: SnowflakeExportOptions,
) -> Result<(SnowflakeAccountStats, Vec<(PathBuf, u64)>)> {
    let base = cred.url.clone();
    let mut session = SnowflakeSession::new(base.clone(), config)?;
    session
        .login(&cred.username, &cred.password)
        .await
        .with_context(|| format!("Snowflake login failed for {}", cred.display_line()))?;

    let username = session.display_user.clone();
    let role = session.role.clone();
    let warehouse = session.warehouse.clone();

    let db_rows = session.show_databases().await.unwrap_or_default();
    let db_count = db_rows.len().min(MAX_DATABASES);

    if !download_files {
        return Ok((
            SnowflakeAccountStats {
                username,
                role,
                warehouse,
                databases: db_count,
                schemas: 0,
                warehouses_listed: 0,
                roles_listed: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    if !export_options.any_selected() {
        return Ok((
            SnowflakeAccountStats {
                username,
                role,
                warehouse,
                databases: db_count,
                schemas: 0,
                warehouses_listed: 0,
                roles_listed: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "snowflake");
    let prefix = cred.account_file_prefix();
    let account_label = base.host_str().unwrap_or("snowflake");
    let mut written = Vec::new();
    let mut total_bytes = 0u64;
    let mut schema_total = 0usize;
    let mut wh_count = 0usize;
    let mut role_count = 0usize;

    if export_options.databases {
        let mut schema_sections = String::new();
        for row in db_rows.iter().take(MAX_DATABASES) {
            if let Some(db) = db_name_from_show_row(row) {
                match session.show_schemas_in_db(&db).await {
                    Ok(schema_rows) => {
                        schema_total += schema_rows.len().min(MAX_SCHEMAS_PER_DB);
                        let section = render_table_html(
                            &format!("Schemas — {db}"),
                            account_label,
                            &[],
                            &schema_rows,
                        );
                        schema_sections.push_str(&format!("<h2>Database {db}</h2>\n{section}\n"));
                    }
                    Err(err) => {
                        schema_sections.push_str(&format!("<p>SHOW SCHEMAS IN {db}: {err}</p>"));
                    }
                }
            }
        }
        let db_html = render_table_html(
            "Snowflake — databases",
            account_label,
            &[],
            &db_rows.iter().take(MAX_DATABASES).cloned().collect::<Vec<_>>(),
        );
        let combined = format!("{db_html}\n<hr/>\n{schema_sections}");
        let leaf = format!("{prefix}__databases.html");
        let path = output_file_path(&site_dir, &leaf);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).await.ok();
        }
        fs::write(&path, &combined).await?;
        let len = combined.len() as u64;
        total_bytes += len;
        written.push((path, len));
    }

    if export_options.warehouses {
        match session.show_warehouses().await {
            Ok(rows) => {
                wh_count = rows.len().min(MAX_WAREHOUSES);
                let html = render_table_html(
                    "Snowflake — warehouses",
                    account_label,
                    &[],
                    &rows.iter().take(MAX_WAREHOUSES).cloned().collect::<Vec<_>>(),
                );
                let leaf = format!("{prefix}__warehouses.html");
                let path = output_file_path(&site_dir, &leaf);
                fs::write(&path, &html).await?;
                let len = html.len() as u64;
                total_bytes += len;
                written.push((path, len));
            }
            Err(err) => debug!("SHOW WAREHOUSES: {err}"),
        }
    }

    if export_options.roles {
        match session.show_roles().await {
            Ok(rows) => {
                role_count = rows.len().min(MAX_ROLES);
                let html = render_table_html(
                    "Snowflake — roles",
                    account_label,
                    &[],
                    &rows.iter().take(MAX_ROLES).cloned().collect::<Vec<_>>(),
                );
                let leaf = format!("{prefix}__roles.html");
                let path = output_file_path(&site_dir, &leaf);
                fs::write(&path, &html).await?;
                let len = html.len() as u64;
                total_bytes += len;
                written.push((path, len));
            }
            Err(err) => debug!("SHOW ROLES: {err}"),
        }
    }

    Ok((
        SnowflakeAccountStats {
            username,
            role,
            warehouse,
            databases: db_count,
            schemas: schema_total,
            warehouses_listed: wh_count,
            roles_listed: role_count,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}
