//! OWA / Kibana / Zabbix / Zimbra / Drupal / Grafana / SonarQube / Mattermost check & export.

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, AddServiceKind, Credential};
use regex::Regex;
use reqwest::{Client, Url};
use std::sync::LazyLock;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tracing::warn;

#[derive(Debug, Clone)]
pub struct WebappClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for WebappClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct WebappAccountStats {
    pub kind: AddServiceKind,
    pub username: String,
    pub auth_method: String,
    /// Named counters from the remote account (hosts, dashboards, …).
    pub inventory: Vec<(String, u64)>,
    pub export_files: usize,
    pub bytes: u64,
}

impl WebappAccountStats {
    fn inventory_total(&self) -> usize {
        self.inventory.iter().map(|(_, v)| *v).sum::<u64>() as usize
    }

    pub fn detail_line(&self) -> String {
        let inv = if self.inventory.is_empty() {
            "totals=n/a".to_string()
        } else {
            self.inventory
                .iter()
                .map(|(k, v)| format!("{k}={v}"))
                .collect::<Vec<_>>()
                .join(" ")
        };
        let export_files = crate::stats_display::file_count(self.export_files, self.inventory_total());
        format!(
            "{} user={} auth={} {inv} export_files={export_files} ({})",
            self.kind.label(),
            self.username,
            self.auth_method,
            format_bytes(self.bytes),
        )
    }
}

#[cfg(test)]
mod webapp_stats_tests {
    use super::*;
    use super::AddServiceKind;

    #[test]
    fn check_only_detail_uses_inventory_for_export_files() {
        let stats = WebappAccountStats {
            kind: AddServiceKind::Grafana,
            username: "admin".into(),
            auth_method: "grafana-json".into(),
            inventory: vec![
                ("dashboards".into(), 31),
                ("folders".into(), 2),
            ],
            export_files: 0,
            bytes: 0,
        };
        let line = stats.detail_line();
        assert!(line.contains("export_files=33"), "line was: {line}");
        assert!(line.contains("(0 B)"));
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

struct WebappClient {
    http: Client,
    base: Url,
    username: String,
    password: String,
    kind: AddServiceKind,
    zabbix_token: Option<String>,
}

impl WebappClient {
    fn new(
        kind: AddServiceKind,
        base: Url,
        username: &str,
        password: &str,
        config: &WebappClientConfig,
    ) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent(format!("phpmyadmin-rs-{}/0.1", kind.output_tag()));
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            base,
            username: username.to_string(),
            password: password.to_string(),
            kind,
            zabbix_token: None,
        })
    }

    async fn apply_http_to_https_redirect(&mut self) -> Result<()> {
        if self.base.scheme() != "http" {
            return Ok(());
        }
        let probe = self.base.clone();
        let probe_client = Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .timeout(Duration::from_secs(30))
            .build()?;
        let resp = probe_client.get(probe).send().await?;
        if !resp.status().is_redirection() {
            return Ok(());
        }
        let Some(loc) = resp.headers().get(reqwest::header::LOCATION) else {
            return Ok(());
        };
        let loc_str = loc.to_str().unwrap_or_default();
        let target = Url::parse(loc_str)
            .or_else(|_| self.base.join(loc_str))
            .ok();
        if let Some(target) = target {
            if target.scheme() == "https" && target.host() == self.base.host() {
                self.base
                    .set_scheme("https")
                    .map_err(|_| anyhow::anyhow!("https scheme"))?;
            }
        }
        Ok(())
    }

    async fn connect(&mut self) -> Result<String> {
        self.apply_http_to_https_redirect().await.ok();
        let auth = match self.kind {
            AddServiceKind::Owa => self.owa_login().await,
            AddServiceKind::Zabbix => self.zabbix_api_login().await,
            AddServiceKind::Mattermost => self.mattermost_api_login().await,
            AddServiceKind::SonarQube => self.sonar_api_login().await,
            AddServiceKind::Grafana => self.grafana_login().await,
            AddServiceKind::Kibana => self.kibana_login().await,
            _ => self.form_login().await,
        }?;
        Ok(auth)
    }

    async fn gather_inventory(&mut self, _auth: &str) -> Vec<(String, u64)> {
        match self.kind {
            AddServiceKind::Zabbix => self.zabbix_inventory().await,
            AddServiceKind::Grafana => self.grafana_inventory().await,
            AddServiceKind::Kibana => self.kibana_inventory().await,
            AddServiceKind::SonarQube => self.sonar_inventory().await,
            AddServiceKind::Mattermost => self.mattermost_inventory().await,
            AddServiceKind::Owa => self.owa_inventory().await,
            AddServiceKind::Drupal => self.drupal_inventory().await,
            AddServiceKind::Zimbra => vec![("webmail".into(), 1)],
            _ => Vec::new(),
        }
    }

    async fn zabbix_inventory(&mut self) -> Vec<(String, u64)> {
        if self.zabbix_token.is_none() {
            let _ = self.zabbix_api_login().await;
        }
        let Some(token) = self.zabbix_token.clone() else {
            return Vec::new();
        };
        let methods = [
            ("hosts", "host.get"),
            ("items", "item.get"),
            ("triggers", "trigger.get"),
            ("problems", "problem.get"),
            ("templates", "template.get"),
            ("users", "user.get"),
            ("host_groups", "hostgroup.get"),
        ];
        let mut out = Vec::new();
        for (label, method) in methods {
            if let Ok(n) = self
                .zabbix_rpc(method, json!({ "countOutput": true }), Some(&token))
                .await
                .and_then(|v| zabbix_count(v))
            {
                out.push((label.to_string(), n));
            }
        }
        out
    }

    async fn grafana_inventory(&self) -> Vec<(String, u64)> {
        let mut out = Vec::new();
        if let Ok(n) = self.count_json_array("api/search?type=dash-db&limit=5000").await {
            out.push(("dashboards".into(), n));
        }
        if let Ok(n) = self.count_json_array("api/datasources").await {
            out.push(("datasources".into(), n));
        }
        if let Ok(n) = self.count_json_array("api/folders?limit=5000").await {
            out.push(("folders".into(), n));
        }
        if let Ok(n) = self.count_json_array("api/search?type=dash-folder&limit=5000").await {
            out.push(("folder_items".into(), n));
        }
        out
    }

    async fn kibana_inventory(&self) -> Vec<(String, u64)> {
        let mut out = Vec::new();
        if let Ok(n) = self
            .kibana_saved_object_count("index-pattern")
            .await
        {
            out.push(("index_patterns".into(), n));
        }
        if let Ok(n) = self.kibana_saved_object_count("dashboard").await {
            out.push(("dashboards".into(), n));
        }
        if let Ok(n) = self.kibana_saved_object_count("search").await {
            out.push(("saved_searches".into(), n));
        }
        out
    }

    async fn sonar_inventory(&self) -> Vec<(String, u64)> {
        let mut out = Vec::new();
        if let Ok(n) = self.sonar_paging_total("api/projects/search?ps=1").await {
            out.push(("projects".into(), n));
        }
        if let Ok(n) = self.sonar_paging_total("api/issues/search?ps=1&resolved=false").await {
            out.push(("open_issues".into(), n));
        }
        if let Ok(n) = self.sonar_paging_total("api/users/search?ps=1").await {
            out.push(("users".into(), n));
        }
        out
    }

    async fn mattermost_inventory(&self) -> Vec<(String, u64)> {
        let mut out = Vec::new();
        if let Ok(n) = self.count_json_array("api/v4/users/me/teams").await {
            out.push(("teams".into(), n));
        }
        if let Ok(n) = self.count_json_array("api/v4/users/me/channels").await {
            out.push(("channels".into(), n));
        }
        out
    }

    async fn owa_inventory(&self) -> Vec<(String, u64)> {
        if self.verify_owa_mailbox().await.unwrap_or(false) {
            vec![("mailbox".into(), 1)]
        } else {
            Vec::new()
        }
    }

    async fn drupal_inventory(&self) -> Vec<(String, u64)> {
        let mut out = Vec::new();
        for (label, path) in [
            ("nodes", "jsonapi/node/article?page[limit]=0"),
            ("users", "jsonapi/user/user?page[limit]=0"),
        ] {
            if let Ok(url) = self.api_join(path) {
                if let Ok(resp) = self.http.get(url).send().await {
                    if resp.status().is_success() {
                        if let Ok(v) = resp.json::<Value>().await {
                            if let Some(n) = v
                                .get("meta")
                                .and_then(|m| m.get("count"))
                                .and_then(|c| c.as_u64())
                            {
                                out.push((label.to_string(), n));
                            }
                        }
                    }
                }
            }
        }
        out
    }

    async fn count_json_array(&self, path: &str) -> Result<u64> {
        let url = self.api_join(path)?;
        let resp = self.http.get(url).send().await?;
        if !resp.status().is_success() {
            bail!("HTTP {}", resp.status());
        }
        let v: Value = resp.json().await?;
        if let Some(arr) = v.as_array() {
            return Ok(arr.len() as u64);
        }
        Ok(0)
    }

    async fn kibana_saved_object_count(&self, obj_type: &str) -> Result<u64> {
        let path = format!("api/saved_objects/_find?type={obj_type}&per_page=1");
        let url = self.api_join(&path)?;
        let resp = self.http.get(url).send().await?;
        if !resp.status().is_success() {
            bail!("HTTP {}", resp.status());
        }
        let v: Value = resp.json().await?;
        Ok(v.get("total").and_then(|t| t.as_u64()).unwrap_or(0))
    }

    async fn sonar_paging_total(&self, path: &str) -> Result<u64> {
        let url = self.api_join(path)?;
        let resp = self.http.get(url).send().await?;
        if !resp.status().is_success() {
            bail!("HTTP {}", resp.status());
        }
        let v: Value = resp.json().await?;
        Ok(v.get("paging")
            .and_then(|p| p.get("total"))
            .and_then(|t| t.as_u64())
            .or_else(|| v.get("total").and_then(|t| t.as_u64()))
            .unwrap_or(0))
    }

    async fn owa_login(&self) -> Result<String> {
        let login_paths = ["auth/logon.aspx", "auth.owa", "owa/auth/logon.aspx"];
        let mut last_err: Option<anyhow::Error> = None;
        for path in login_paths {
            match self.try_owa_logon(path).await {
                Ok(()) => {
                    if self.verify_owa_mailbox().await? {
                        return Ok("owa-session".into());
                    }
                    last_err = Some(anyhow::anyhow!("OWA session not authenticated"));
                }
                Err(e) => last_err = Some(e),
            }
        }
        Err(last_err.unwrap_or_else(|| anyhow::anyhow!("OWA login failed")))
    }

    async fn try_owa_logon(&self, login_path: &str) -> Result<()> {
        let page_url = self.join_service_path(login_path)?;
        let page = self.http.get(page_url.clone()).send().await?;
        if !page.status().is_success() && !page.status().is_redirection() {
            bail!("logon page HTTP {}", page.status());
        }
        let html = page.text().await.unwrap_or_default();
        if !html.to_ascii_lowercase().contains("password") {
            bail!("not an OWA logon page");
        }
        let mut form: Vec<(String, String)> = vec![
            ("username".into(), self.username.clone()),
            ("password".into(), self.password.clone()),
            ("destination".into(), String::new()),
            ("flags".into(), "4".into()),
            ("isOutlook".into(), "true".into()),
        ];
        for (name, value) in extract_hidden_inputs(&html) {
            if name.eq_ignore_ascii_case("username") || name.eq_ignore_ascii_case("password") {
                continue;
            }
            if !form.iter().any(|(k, _)| k.eq_ignore_ascii_case(&name)) {
                form.push((name, value));
            }
        }
        let post_form: Vec<(String, String)> = form;
        let post_refs: Vec<(&str, &str)> = post_form
            .iter()
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();
        let resp = self.http.post(page_url).form(&post_refs).send().await?;
        let status = resp.status();
        let landed = resp.url().clone();
        let body = resp.text().await.unwrap_or_default();
        if owa_failure(&landed, &body) {
            bail!("OWA rejected credentials");
        }
        if !(status.is_success() || status.is_redirection()) {
            bail!("OWA post HTTP {status}");
        }
        Ok(())
    }

    async fn verify_owa_mailbox(&self) -> Result<bool> {
        let probes = ["", "default.aspx", "?ae=Item&t=IPM.Note"];
        for probe in probes {
            let url = self.join_service_path(probe)?;
            let resp = match self.http.get(url).send().await {
                Ok(r) => r,
                Err(_) => continue,
            };
            if !resp.status().is_success() && !resp.status().is_redirection() {
                continue;
            }
            let final_url = resp.url().clone();
            let body = resp.text().await.unwrap_or_default();
            if owa_failure(&final_url, &body) {
                return Ok(false);
            }
            if owa_authenticated(&final_url, &body) {
                return Ok(true);
            }
        }
        Ok(false)
    }

    async fn zabbix_api_login(&mut self) -> Result<String> {
        for api_path in ["api_jsonrpc.php", "zabbix/api_jsonrpc.php"] {
            if let Ok(token) = self.zabbix_try_user_login(api_path, "username").await {
                self.zabbix_token = Some(token);
                return Ok("zabbix-api".into());
            }
            if let Ok(token) = self.zabbix_try_user_login(api_path, "user").await {
                self.zabbix_token = Some(token);
                return Ok("zabbix-api".into());
            }
        }
        let auth = self.form_login().await?;
        for api_path in ["api_jsonrpc.php", "zabbix/api_jsonrpc.php"] {
            if let Ok(token) = self.zabbix_try_user_login(api_path, "username").await {
                self.zabbix_token = Some(token);
                return Ok(format!("{auth}+api"));
            }
            if let Ok(token) = self.zabbix_try_user_login(api_path, "user").await {
                self.zabbix_token = Some(token);
                return Ok(format!("{auth}+api"));
            }
        }
        Ok(auth)
    }

    async fn zabbix_try_user_login(&self, api_path: &str, user_field: &str) -> Result<String> {
        let api_url = self.api_join(api_path)?;
        let mut params = serde_json::Map::new();
        params.insert(user_field.into(), json!(self.username));
        params.insert("password".into(), json!(self.password));
        let body = json!({
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": Value::Object(params),
            "id": 1
        });
        let resp = self.http.post(api_url).json(&body).send().await?;
        let v: Value = resp.json().await?;
        if let Some(err) = v.get("error") {
            bail!("zabbix api: {err}");
        }
        let token = v
            .get("result")
            .and_then(|x| x.as_str())
            .map(str::to_string)
            .context("no zabbix token")?;
        Ok(token)
    }

    async fn zabbix_rpc(
        &self,
        method: &str,
        params: Value,
        auth: Option<&str>,
    ) -> Result<Value> {
        let api_url = self
            .api_join("api_jsonrpc.php")
            .or_else(|_| self.api_join("zabbix/api_jsonrpc.php"))?;
        let mut body = json!({
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": 2
        });
        if let Some(token) = auth {
            body["auth"] = json!(token);
        }
        let resp = self.http.post(api_url).json(&body).send().await?;
        let v: Value = resp.json().await?;
        if v.get("error").is_some() {
            bail!("zabbix rpc {method}: {}", v["error"]);
        }
        Ok(v.get("result").cloned().unwrap_or(Value::Null))
    }

    async fn mattermost_api_login(&self) -> Result<String> {
        let url = self.api_join("api/v4/users/login")?;
        let body = json!({ "login_id": self.username, "password": self.password });
        let resp = self.http.post(url).json(&body).send().await?;
        if resp.status().is_success() {
            return Ok("mattermost-api".into());
        }
        self.form_login().await
    }

    async fn sonar_api_login(&self) -> Result<String> {
        let url = self.api_join("api/authentication/login")?;
        let body = json!({ "login": self.username, "password": self.password });
        let resp = self.http.post(url).json(&body).send().await?;
        if resp.status().is_success() {
            return Ok("sonar-api".into());
        }
        self.form_login().await
    }

    async fn grafana_login(&self) -> Result<String> {
        let url = self.api_join("login")?;
        let body = json!({ "user": self.username, "password": self.password });
        let resp = self.http.post(url).json(&body).send().await?;
        if resp.status().is_success() {
            return Ok("grafana-json".into());
        }
        self.form_login().await
    }

    async fn kibana_login(&self) -> Result<String> {
        let url = self.api_join("internal/security/login")?;
        let body = json!({
            "providerType": "basic",
            "providerName": "basic",
            "currentURL": self.base.to_string(),
            "params": { "username": self.username, "password": self.password }
        });
        let resp = self.http.post(url).json(&body).send().await?;
        if resp.status().is_success() {
            return Ok("kibana-internal".into());
        }
        let url2 = self.api_join("login")?;
        let resp2 = self
            .http
            .post(url2)
            .form(&[
                ("username", self.username.as_str()),
                ("password", self.password.as_str()),
            ])
            .send()
            .await?;
        if resp2.status().is_success() || resp2.status().is_redirection() {
            return Ok("kibana-form".into());
        }
        self.form_login().await
    }

    async fn form_login(&self) -> Result<String> {
        let login_paths = login_paths_for(self.kind);
        for path in login_paths {
            let page_url = self.api_join(path)?;
            let page = self.http.get(page_url.clone()).send().await?;
            let status = page.status();
            let html = page.text().await.unwrap_or_default();
            if !status.is_success() && !status.is_redirection() {
                continue;
            }
            let mut form = vec![
                ("username", self.username.as_str()),
                ("password", self.password.as_str()),
                ("user", self.username.as_str()),
                ("pass", self.password.as_str()),
                ("login", "Login"),
                ("Login", "Log in"),
            ];
            if self.kind == AddServiceKind::Owa {
                form.push(("destination", ""));
                form.push(("flags", "4"));
            }
            let resp = self.http.post(page_url).form(&form).send().await?;
            let ok = resp.status().is_success() || resp.status().is_redirection();
            let landed = resp.url().clone();
            let body = resp.text().await.unwrap_or_default();
            if ok && !looks_like_login_page(&landed, &body) && post_login_success(self.kind, &landed, &body) {
                return Ok("form".into());
            }
        }
        bail!("{} login failed", self.kind.label())
    }

    fn join_service_path(&self, path: &str) -> Result<Url> {
        join_under_base(&self.base, path)
    }

    async fn export_snapshots(&self, auth: &str) -> Result<Vec<(String, Vec<u8>)>> {
        let mut out = Vec::new();
        let endpoints = export_paths_for(self.kind);
        for (name, path) in endpoints {
            let url = match self.api_join(path) {
                Ok(u) => u,
                Err(_) => continue,
            };
            let resp = match self.http.get(url).send().await {
                Ok(r) => r,
                Err(err) => {
                    warn!("{name} fetch: {err}");
                    continue;
                }
            };
            if !resp.status().is_success() {
                continue;
            }
            let bytes = resp.bytes().await.unwrap_or_default();
            if bytes.is_empty() {
                continue;
            }
            out.push((format!("{name}.json"), bytes.to_vec()));
        }
        let meta = json!({
            "service": self.kind.label(),
            "base": self.base.as_str(),
            "username": self.username,
            "auth_method": auth,
            "exports": out.iter().map(|(n, _)| n).collect::<Vec<_>>(),
        });
        out.push((
            "account_meta.json".to_string(),
            serde_json::to_vec_pretty(&meta)?,
        ));
        Ok(out)
    }

    fn api_join(&self, path: &str) -> Result<Url> {
        join_under_base(&self.base, path)
    }
}

fn join_under_base(base: &Url, path: &str) -> Result<Url> {
    let path = path.trim_start_matches('/');
    let base_path = base.path().trim_end_matches('/').to_ascii_lowercase();
    let joined = if base_path.ends_with("/owa") && path.starts_with("owa/") {
        base.join(path.strip_prefix("owa/").unwrap_or(path))
    } else {
        base.join(path)
    };
    joined.context("url join")
}

static HIDDEN_INPUT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?i)<input[^>]+type=["']hidden["'][^>]*>"#).unwrap()
});
static INPUT_NAME_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)name=["']([^"']+)["']"#).unwrap()
});
static INPUT_VALUE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r#"(?is)value=["']([^"']*)["']"#).unwrap()
});

fn extract_hidden_inputs(html: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    for cap in HIDDEN_INPUT_RE.captures_iter(html) {
        let tag = cap.get(0).map(|m| m.as_str()).unwrap_or("");
        let name = INPUT_NAME_RE
            .captures(tag)
            .and_then(|c| c.get(1))
            .map(|m| m.as_str().to_string());
        let Some(name) = name else { continue };
        let value = INPUT_VALUE_RE
            .captures(tag)
            .and_then(|c| c.get(1))
            .map(|m| m.as_str().to_string())
            .unwrap_or_default();
        out.push((name, value));
    }
    out
}

fn owa_failure(url: &Url, body: &str) -> bool {
    let path = url.path().to_ascii_lowercase();
    let lower = body.to_ascii_lowercase();
    path.contains("logon.aspx")
        || path.contains("errorfe.aspx")
        || path.contains("sessiontimeout.aspx")
        || lower.contains("incorrect user id or password")
        || lower.contains("incorrect user name or password")
        || lower.contains("the user name or password")
        || lower.contains("sign in with your organizational account")
        || lower.contains("lgnstsfailure")
        || lower.contains("reason=2")
        || lower.contains("reason=1")
        || lower.contains("logon.aspx?reason")
}

fn owa_authenticated(url: &Url, body: &str) -> bool {
    if owa_failure(url, body) {
        return false;
    }
    let path = url.path().to_ascii_lowercase();
    let lower = body.to_ascii_lowercase();
    if path.contains("/owa") && !path.contains("logon") && !path.contains("errorfe") {
        if lower.contains("owafolder")
            || lower.contains("name=\"logout")
            || lower.contains("id=\"logout")
            || lower.contains("owalogout")
            || lower.contains("action=\"logout")
            || lower.contains("x-owa-version")
            || lower.contains("inbox")
                && lower.contains("outlook")
        {
            return true;
        }
    }
    lower.contains("owafolder") || lower.contains("clsid=0006f062")
}

fn post_login_success(kind: AddServiceKind, url: &Url, body: &str) -> bool {
    match kind {
        AddServiceKind::Drupal => {
            let lower = body.to_ascii_lowercase();
            !lower.contains("login-form") && !url.path().to_ascii_lowercase().contains("login")
        }
        AddServiceKind::Zimbra => {
            let lower = body.to_ascii_lowercase();
            lower.contains("zimbra") && !lower.contains("zloginform")
        }
        _ => !looks_like_login_page(url, body),
    }
}

fn login_paths_for(kind: AddServiceKind) -> &'static [&'static str] {
    match kind {
        AddServiceKind::Owa => &["owa/auth/logon.aspx", "owa/auth.owa"],
        AddServiceKind::Kibana => &["login", "app/login"],
        AddServiceKind::Zabbix => &["index.php", "zabbix/index.php"],
        AddServiceKind::Zimbra => &["zimbra/", "zimbraAdmin/"],
        AddServiceKind::Drupal => &["user/login", "drupal/user/login"],
        AddServiceKind::Grafana => &["login", "grafana/login"],
        AddServiceKind::SonarQube => &["sessions/new", "login"],
        AddServiceKind::Mattermost => &["login"],
    }
}

fn export_paths_for(kind: AddServiceKind) -> Vec<(&'static str, &'static str)> {
    match kind {
        AddServiceKind::Kibana => vec![
            ("status", "api/status"),
            ("saved_objects", "api/saved_objects/_find?type=index-pattern&per_page=50"),
        ],
        AddServiceKind::Grafana => vec![
            ("dashboards", "api/search?type=dash-db&limit=50"),
            ("datasources", "api/datasources"),
        ],
        AddServiceKind::Zabbix => vec![],
        AddServiceKind::SonarQube => vec![
            ("projects", "api/projects/search?ps=50"),
        ],
        AddServiceKind::Mattermost => vec![
            ("teams", "api/v4/users/me/teams"),
        ],
        _ => vec![],
    }
}

fn looks_like_login_page(url: &Url, body: &str) -> bool {
    let path = url.path().to_ascii_lowercase();
    let lower = body.to_ascii_lowercase();
    path.contains("logon")
        || path.contains("/login")
        || path.contains("sessions/new")
        || lower.contains("name=\"password\"")
            && lower.contains("name=\"username\"")
        || lower.contains("sign in")
}

pub async fn download_webapp_account(
    kind: AddServiceKind,
    cred: &Credential,
    config: &WebappClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(WebappAccountStats, Vec<(PathBuf, u64)>)> {
    let mut client = WebappClient::new(kind, cred.url.clone(), &cred.username, &cred.password, config)?;
    let auth = client
        .connect()
        .await
        .with_context(|| format!("{} login failed for {}", kind.label(), cred.display_line()))?;
    let inventory = client.gather_inventory(&auth).await;

    if !download_files {
        let inv = if inventory.is_empty() {
            vec![("session".into(), 1_u64)]
        } else {
            inventory
        };
        return Ok((
            WebappAccountStats {
                kind,
                username: cred.username.clone(),
                auth_method: auth,
                inventory: inv,
                export_files: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let snapshots = client.export_snapshots(&auth).await.unwrap_or_default();
    let site_dir = cred.site_output_dir(output_dir, kind.output_tag());
    let prefix = cred.account_file_prefix();
    let mut written = Vec::new();
    let mut total_bytes = 0u64;
    for (leaf_suffix, bytes) in snapshots {
        let leaf = format!("{prefix}__{leaf_suffix}");
        let path = output_file_path(&site_dir, &leaf);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).await.ok();
        }
        fs::write(&path, &bytes).await.with_context(|| format!("write {}", path.display()))?;
        let n = bytes.len() as u64;
        total_bytes += n;
        written.push((path, n));
    }

    Ok((
        WebappAccountStats {
            kind,
            username: cred.username.clone(),
            auth_method: auth,
            inventory,
            export_files: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}

fn zabbix_count(v: Value) -> Result<u64> {
    if let Some(s) = v.as_str() {
        return Ok(s.parse().unwrap_or(0));
    }
    if let Some(arr) = v.as_array() {
        return Ok(arr.len() as u64);
    }
    Ok(0)
}
