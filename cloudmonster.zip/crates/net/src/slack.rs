//! Slack Web API client: detect workspace, authenticate (token or email/password), export files/messages.

use anyhow::{bail, Context, Result};
use pma_core::{is_excluded_media_filename, looks_like_slack_api_token, output_file_path, Credential};
use reqwest::{Client, StatusCode};
use serde::Deserialize;
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tracing::{debug, warn};
use regex::Regex;
use std::sync::OnceLock;
use url::Url;

const SLACK_API: &str = "https://slack.com/api/";
const MAX_CHANNELS: usize = 150;
const MAX_MESSAGES: usize = 2000;
const MAX_FILES: usize = 500;
const MAX_FILE_BYTES: u64 = 100 * 1024 * 1024;
const MAX_FILES_TOTAL_BYTES: u64 = 1024 * 1024 * 1024;

#[derive(Debug, Clone)]
pub struct SlackClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for SlackClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(90),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct SlackChannel {
    pub id: String,
    pub name: String,
}

#[derive(Debug, Clone)]
pub struct SlackAccountStats {
    pub username: String,
    pub channels: usize,
    pub messages_exported: usize,
    pub files: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl SlackAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "user={} channels={} messages={} files={} downloaded={} ({})",
            self.username,
            self.channels,
            self.messages_exported,
            self.files,
            self.downloaded,
            format_bytes(self.bytes),
        )
    }
}

#[derive(Debug, Deserialize)]
struct SlackAuthTest {
    #[serde(default)]
    ok: bool,
    #[serde(default)]
    user: Option<String>,
    #[serde(default, rename = "user_id")]
    user_id: Option<String>,
    #[serde(default)]
    error: Option<String>,
}

pub struct SlackClient {
    http: Client,
    team_base: Url,
    username: String,
    password: String,
    token: Option<String>,
}

impl SlackClient {
    pub fn new(
        team_base: Url,
        username: &str,
        password: &str,
        config: &SlackClientConfig,
    ) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-slack/0.1");
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        let token = resolve_api_token(username, password);
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            team_base,
            username: username.to_string(),
            password: password.to_string(),
            token,
        })
    }

    pub async fn detect(&self) -> Result<bool> {
        if let Some(ref token) = self.token {
            if self.auth_test(token).await?.ok {
                return Ok(true);
            }
        }

        let host = self
            .team_base
            .host_str()
            .unwrap_or("")
            .to_ascii_lowercase();
        if host.ends_with(".slack.com") || host == "app.slack.com" || host == "slack.com" {
            let resp = self.http.get(self.team_base.clone()).send().await;
            if let Ok(r) = resp {
                if r.status().is_success() || r.status().is_redirection() {
                    let body = r.text().await.unwrap_or_default().to_ascii_lowercase();
                    if body.contains("slack")
                        || body.contains("c-wss")
                        || body.contains("team_id")
                    {
                        return Ok(true);
                    }
                }
            }
            return Ok(host.ends_with(".slack.com"));
        }
        Ok(false)
    }

    pub async fn authenticate(&mut self) -> Result<String> {
        let mut notes: Vec<String> = Vec::new();
        if self.token.is_none() {
            if let Some(token) = self.password_signin(&mut notes).await? {
                self.token = Some(token);
            }
        }
        let token = self.token.as_ref().with_context(|| {
            if notes.is_empty() {
                "Slack authentication failed (need valid password, xoxp-/xoxc- token, or workspace may require SSO/MFA)"
                    .to_string()
            } else {
                format!("Slack authentication failed: {}", notes.join("; "))
            }
        })?;
        let auth = self.auth_test(token).await?;
        if !auth.ok {
            bail!(
                "Slack authentication failed: {}",
                auth.error.unwrap_or_else(|| "auth.test not ok".into())
            );
        }
        Ok(auth
            .user
            .or(auth.user_id)
            .unwrap_or_else(|| self.username.clone()))
    }

    pub fn api_token(&self) -> Option<&str> {
        self.token.as_deref()
    }

    async fn auth_test(&self, token: &str) -> Result<SlackAuthTest> {
        let v = self.api_call(token, "auth.test", &[]).await?;
        Ok(serde_json::from_value(v).unwrap_or(SlackAuthTest {
            ok: false,
            user: None,
            user_id: None,
            error: Some("decode auth.test".into()),
        }))
    }

    async fn password_signin(&self, notes: &mut Vec<String>) -> Result<Option<String>> {
        let login = self.username.trim();
        if login.is_empty() || self.password.is_empty() {
            return Ok(None);
        }

        if login.contains('@') {
            return self.password_signin_email(login, notes).await;
        }
        self.password_signin_username(login, notes).await
    }

    async fn password_signin_email(&self, email: &str, notes: &mut Vec<String>) -> Result<Option<String>> {
        let boot = self.fetch_signin_boot_token().await;

        let find = self
            .post_signin_method("signin.findTeam", &[("email", email)], boot.as_deref())
            .await?;
        if find.get("ok").and_then(|b| b.as_bool()) != Some(true) {
            push_slack_api_note(notes, "findTeam", &find);
        }
        let signin_token = find
            .get("token")
            .and_then(|t| t.as_str())
            .map(|s| s.to_string())
            .or(boot);

        let mut teams = collect_signin_teams(&find);
        if self.is_named_workspace_host() {
            sort_teams_for_workspace(&mut teams, self.team_base.host_str().unwrap_or(""));
        }

        for (team_id, domain) in &teams {
            if let Some(token) = self
                .try_check_password(email, team_id, signin_token.as_deref(), notes)
                .await?
            {
                return Ok(Some(token));
            }
            if let Some(ref domain) = domain {
                if let Some(workspace) = Url::parse(&format!("https://{domain}.slack.com/")).ok() {
                    if let Some(token) = self.auth_signin_at(&workspace, email, notes).await? {
                        return Ok(Some(token));
                    }
                }
            }
        }

        if self.is_named_workspace_host() {
            if let Some(team_id) = self.fetch_workspace_team_id().await? {
                if let Some(token) = self
                    .try_check_password(email, &team_id, signin_token.as_deref(), notes)
                    .await?
                {
                    return Ok(Some(token));
                }
            }
            if let Some(token) = self.auth_signin_at(&self.team_base, email, notes).await? {
                return Ok(Some(token));
            }
        }

        let root = Url::parse("https://slack.com/")?;
        self.auth_signin_at(&root, email, notes).await
    }

    async fn password_signin_username(&self, username: &str, notes: &mut Vec<String>) -> Result<Option<String>> {
        let team_id = self.fetch_workspace_team_id().await?;
        if let Some(ref team_id) = team_id {
            if let Some(token) = self
                .try_check_password(username, team_id, None, notes)
                .await?
            {
                return Ok(Some(token));
            }

            if let Some(synthetic) = synthetic_workspace_email(self.team_base.as_str(), username) {
                if synthetic != username {
                    if let Some(token) = self
                        .try_check_password(&synthetic, team_id, None, notes)
                        .await?
                    {
                        return Ok(Some(token));
                    }
                }
            }
        }

        if self.is_named_workspace_host() {
            return self.auth_signin_at(&self.team_base, username, notes).await;
        }

        let root = Url::parse("https://slack.com/")?;
        self.auth_signin_at(&root, username, notes).await
    }

    async fn try_check_password(
        &self,
        login: &str,
        team_id: &str,
        signin_token: Option<&str>,
        notes: &mut Vec<String>,
    ) -> Result<Option<String>> {
        let mut params: Vec<(&str, &str)> = vec![
            ("email", login),
            ("password", &self.password),
            ("team", team_id),
            ("remember", "true"),
        ];
        if let Some(t) = signin_token {
            params.push(("token", t));
        }
        let check = self
            .post_signin_method("signin.checkPassword", &params, signin_token.as_deref())
            .await?;
        if check.get("ok").and_then(|b| b.as_bool()) != Some(true) {
            push_slack_api_note(notes, &format!("checkPassword team={team_id}"), &check);
            debug!(
                login = login,
                team_id = team_id,
                error = ?check.get("error"),
                "signin.checkPassword failed"
            );
            return Ok(None);
        }
        extract_token(&check)
    }

    async fn fetch_workspace_team_id(&self) -> Result<Option<String>> {
        let host = self
            .team_base
            .host_str()
            .unwrap_or("")
            .to_ascii_lowercase();
        if !host.ends_with(".slack.com") || host == "app.slack.com" || host == "slack.com" {
            return Ok(None);
        }
        let body = self.fetch_workspace_html().await?;
        Ok(extract_team_id_from_html(&body))
    }

    async fn fetch_workspace_html(&self) -> Result<String> {
        let resp = self.http.get(self.team_base.clone()).send().await?;
        Ok(resp.text().await.unwrap_or_default())
    }

    async fn auth_signin_at(
        &self,
        api_root: &Url,
        login: &str,
        notes: &mut Vec<String>,
    ) -> Result<Option<String>> {
        let resp = self
            .http
            .get(api_root.clone())
            .send()
            .await
            .with_context(|| format!("fetch {}", api_root.host_str().unwrap_or("slack")))?;
        let body = resp.text().await.unwrap_or_default();

        let boot_token = extract_boot_token_from_html(&body);
        let mut params: Vec<(&str, &str)> = vec![
            ("email", login),
            ("password", &self.password),
            ("signin_wanted", "true"),
        ];
        if let Some(ref t) = boot_token {
            params.push(("token", t.as_str()));
        }

        let url = api_root
            .join("api/auth.signin")
            .context("auth.signin url")?;
        let mut req = self.http.post(url).form(&params);
        req = req
            .header("Origin", "https://app.slack.com")
            .header("Referer", "https://app.slack.com/");
        let resp = req.send().await.context("auth.signin")?;
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            debug!(%status, body = preview(&text), "auth.signin HTTP error");
            return Ok(None);
        }
        let v: Value = match serde_json::from_str(&text) {
            Ok(v) => v,
            Err(_) => {
                debug!(body = preview(&text), "auth.signin decode failed");
                return Ok(None);
            }
        };
        if v.get("ok").and_then(|b| b.as_bool()) != Some(true) {
            push_slack_api_note(
                notes,
                &format!("auth.signin host={}", api_root.host_str().unwrap_or("?")),
                &v,
            );
            debug!(error = ?v.get("error"), "auth.signin not ok");
            return Ok(None);
        }
        extract_token(&v)
    }

    fn is_named_workspace_host(&self) -> bool {
        let host = self
            .team_base
            .host_str()
            .unwrap_or("")
            .to_ascii_lowercase();
        host.ends_with(".slack.com") && host != "app.slack.com" && host != "slack.com"
    }

    async fn fetch_signin_boot_token(&self) -> Option<String> {
        if !self.is_named_workspace_host() {
            return None;
        }
        let html = self.fetch_workspace_html().await.ok()?;
        extract_boot_token_from_html(&html)
    }

    async fn post_signin_method(
        &self,
        method: &str,
        params: &[(&str, &str)],
        boot_token: Option<&str>,
    ) -> Result<Value> {
        let mut form: Vec<(&str, &str)> = params.to_vec();
        if let Some(t) = boot_token {
            if !form.iter().any(|(k, _)| *k == "token") {
                form.push(("token", t));
            }
        }

        let global = format!("{SLACK_API}{method}");
        match self.post_signin_url(&global, &form).await {
            Ok(v) if v.get("ok").and_then(|b| b.as_bool()) == Some(true) => return Ok(v),
            Ok(v) if v.get("error").is_some() && !self.is_named_workspace_host() => return Ok(v),
            Ok(v) if !self.is_named_workspace_host() => return Ok(v),
            Ok(v) => {
                if self.is_named_workspace_host() {
                    if let Ok(team_url) = self.team_base.join(&format!("api/{method}")) {
                        if let Ok(v2) = self.post_signin_url(team_url.as_str(), &form).await {
                            if v2.get("ok").and_then(|b| b.as_bool()) == Some(true) {
                                return Ok(v2);
                            }
                            if v2.get("error").is_some() {
                                return Ok(v2);
                            }
                        }
                    }
                }
                Ok(v)
            }
            Err(e) if self.is_named_workspace_host() => {
                if let Ok(team_url) = self.team_base.join(&format!("api/{method}")) {
                    self.post_signin_url(team_url.as_str(), &form)
                        .await
                        .map_err(|_| e)
                } else {
                    Err(e)
                }
            }
            Err(e) => Err(e),
        }
    }

    async fn post_signin_url(&self, url: &str, params: &[(&str, &str)]) -> Result<Value> {
        let mut req = self.http.post(url).form(params);
        req = req
            .header("Origin", "https://app.slack.com")
            .header("Referer", "https://app.slack.com/");
        let resp = req.send().await?;
        let status = resp.status();
        let body = resp.text().await?;
        if !status.is_success() && status != StatusCode::OK {
            bail!("Slack signin HTTP {status}: {}", preview(&body));
        }
        serde_json::from_str(&body).with_context(|| preview(&body))
    }

    async fn api_call(&self, token: &str, method: &str, extra: &[(&str, &str)]) -> Result<Value> {
        let mut params: Vec<(&str, &str)> = vec![("token", token)];
        params.extend_from_slice(extra);
        self.raw_api(method, &params, Some(token)).await
    }

    async fn raw_api(
        &self,
        method: &str,
        params: &[(&str, &str)],
        bearer: Option<&str>,
    ) -> Result<Value> {
        let url = format!("{SLACK_API}{method}");
        let mut req = self.http.post(&url).form(params);
        if method.starts_with("signin.") {
            req = req
                .header("Origin", "https://app.slack.com")
                .header("Referer", "https://app.slack.com/");
        }
        if let Some(t) = bearer {
            req = req.bearer_auth(t);
        }
        let resp = req.send().await?;
        let status = resp.status();
        let body = resp.text().await?;
        if !status.is_success() && status != StatusCode::OK {
            bail!("Slack API HTTP {status}: {}", preview(&body));
        }
        serde_json::from_str(&body).with_context(|| preview(&body))
    }

    pub async fn list_channels(&self) -> Result<Vec<SlackChannel>> {
        let token = self.token.as_ref().context("not authenticated")?;
        let mut channels = Vec::new();
        let mut cursor = String::new();
        loop {
            let mut params = vec![
                ("limit", "200"),
                ("types", "public_channel,private_channel,mpim,im"),
                ("exclude_archived", "true"),
            ];
            if !cursor.is_empty() {
                params.push(("cursor", cursor.as_str()));
            }
            let v = self.api_call(token, "conversations.list", &params).await?;
            if v.get("ok").and_then(|b| b.as_bool()) != Some(true) {
                bail!(
                    "Slack conversations.list: {}",
                    v.get("error")
                        .and_then(|e| e.as_str())
                        .unwrap_or("unknown error")
                );
            }
            if let Some(list) = v.get("channels").and_then(|c| c.as_array()) {
                for ch in list {
                    let id = ch.get("id").and_then(|i| i.as_str()).unwrap_or("");
                    let name = ch
                        .get("name")
                        .or_else(|| ch.get("user"))
                        .and_then(|n| n.as_str())
                        .unwrap_or("dm");
                    if !id.is_empty() {
                        channels.push(SlackChannel {
                            id: id.to_string(),
                            name: name.to_string(),
                        });
                    }
                }
            }
            if channels.len() >= MAX_CHANNELS {
                channels.truncate(MAX_CHANNELS);
                break;
            }
            cursor = v
                .pointer("/response_metadata/next_cursor")
                .and_then(|c| c.as_str())
                .unwrap_or("")
                .to_string();
            if cursor.is_empty() {
                break;
            }
        }
        Ok(channels)
    }

    pub async fn export_channel_messages(&self, channel: &SlackChannel) -> Result<Vec<Value>> {
        let token = self.token.as_ref().context("not authenticated")?;
        let mut messages = Vec::new();
        let mut cursor = String::new();
        while messages.len() < MAX_MESSAGES {
            let mut params = vec![("channel", channel.id.as_str()), ("limit", "200")];
            if !cursor.is_empty() {
                params.push(("cursor", cursor.as_str()));
            }
            let v = self.api_call(token, "conversations.history", &params).await?;
            if v.get("ok").and_then(|b| b.as_bool()) != Some(true) {
                warn!(
                    "Slack history #{}: {}",
                    channel.name,
                    v.get("error").and_then(|e| e.as_str()).unwrap_or("?")
                );
                break;
            }
            if let Some(list) = v.get("messages").and_then(|m| m.as_array()) {
                if list.is_empty() {
                    break;
                }
                messages.extend(list.iter().cloned());
            }
            cursor = v
                .pointer("/response_metadata/next_cursor")
                .and_then(|c| c.as_str())
                .unwrap_or("")
                .to_string();
            if cursor.is_empty() {
                break;
            }
        }
        Ok(messages)
    }

    pub async fn list_files(&self) -> Result<Vec<Value>> {
        let token = self.token.as_ref().context("not authenticated")?;
        let mut files = Vec::new();
        let mut page = 1u32;
        while files.len() < MAX_FILES {
            let page_s = page.to_string();
            let v = self
                .api_call(
                    token,
                    "files.list",
                    &[("count", "100"), ("page", page_s.as_str())],
                )
                .await?;
            if v.get("ok").and_then(|b| b.as_bool()) != Some(true) {
                break;
            }
            let Some(list) = v.get("files").and_then(|f| f.as_array()) else {
                break;
            };
            if list.is_empty() {
                break;
            }
            files.extend(list.iter().cloned());
            let pages = v
                .get("paging")
                .and_then(|p| p.get("pages"))
                .and_then(|p| p.as_u64())
                .unwrap_or(1);
            if page as u64 >= pages {
                break;
            }
            page += 1;
        }
        if files.len() > MAX_FILES {
            files.truncate(MAX_FILES);
        }
        Ok(files)
    }

    pub async fn download_file(&self, url: &str, path: &Path, token: &str) -> Result<u64> {
        let resp = self.http.get(url).bearer_auth(token).send().await?;
        if !resp.status().is_success() {
            bail!("file download HTTP {}", resp.status());
        }
        let bytes = resp.bytes().await?;
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut f = fs::File::create(path).await?;
        f.write_all(&bytes).await?;
        Ok(bytes.len() as u64)
    }
}

fn resolve_api_token(username: &str, password: &str) -> Option<String> {
    if looks_like_slack_token(password) {
        return Some(password.to_string());
    }
    if looks_like_slack_token(username) {
        return Some(username.to_string());
    }
    None
}

fn looks_like_slack_token(s: &str) -> bool {
    looks_like_slack_api_token(s)
}

fn collect_signin_teams(find: &Value) -> Vec<(String, Option<String>)> {
    let mut out = Vec::new();
    let mut push = |team: &Value| {
        let id = team.get("id").and_then(|v| v.as_str())?;
        if out.iter().any(|(existing, _)| existing == id) {
            return Some(());
        }
        let domain = team.get("domain").and_then(|d| d.as_str()).map(str::to_string);
        out.push((id.to_string(), domain));
        Some(())
    };
    if let Some(team) = find.get("team") {
        let _ = push(team);
    }
    if let Some(teams) = find.get("teams").and_then(|t| t.as_array()) {
        for team in teams {
            let _ = push(team);
        }
    }
    out
}

fn sort_teams_for_workspace(teams: &mut [(String, Option<String>)], workspace_host: &str) {
    let host = workspace_host.to_ascii_lowercase();
    let Some(sub) = host.strip_suffix(".slack.com") else {
        return;
    };
    if sub.is_empty() || sub == "app" {
        return;
    }
    teams.sort_by(|a, b| {
        let a_match = a.1.as_deref() == Some(sub);
        let b_match = b.1.as_deref() == Some(sub);
        b_match.cmp(&a_match)
    });
}

fn push_slack_api_note(notes: &mut Vec<String>, step: &str, body: &Value) {
    let err = body
        .get("error")
        .and_then(|e| e.as_str())
        .unwrap_or("unknown");
    let msg = format!("{step}: {err}");
    if notes.iter().any(|n| n == &msg) {
        return;
    }
    notes.push(msg);
}

fn team_workspace_url(team: &Value) -> Option<Url> {
    if let Some(url) = team.get("url").and_then(|v| v.as_str()) {
        if let Ok(parsed) = Url::parse(url) {
            return Some(parsed);
        }
    }
    team.get("domain")
        .and_then(|d| d.as_str())
        .and_then(|domain| Url::parse(&format!("https://{domain}.slack.com/")).ok())
}

fn extract_token(v: &Value) -> Result<Option<String>> {
    for key in ["token", "api_token", "user_token", "access_token"] {
        if let Some(t) = v.get(key).and_then(|x| x.as_str()) {
            if looks_like_slack_token(t) {
                return Ok(Some(t.to_string()));
            }
        }
    }
    if let Some(t) = find_xox_token_value(v) {
        return Ok(Some(t));
    }
    Ok(None)
}

fn find_xox_token_value(v: &Value) -> Option<String> {
    match v {
        Value::String(s) if looks_like_slack_token(s) => Some(s.clone()),
        Value::Object(map) => {
            for val in map.values() {
                if let Some(t) = find_xox_token_value(val) {
                    return Some(t);
                }
            }
            None
        }
        Value::Array(items) => {
            for val in items {
                if let Some(t) = find_xox_token_value(val) {
                    return Some(t);
                }
            }
            None
        }
        _ => None,
    }
}

fn extract_team_id_from_html(body: &str) -> Option<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        Regex::new(r#""team_id"\s*:\s*"(T[A-Z0-9]{6,})""#).expect("team_id regex")
    });
    re.captures(body)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn extract_boot_token_from_html(body: &str) -> Option<String> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        Regex::new(r#""(?:api_)?token"\s*:\s*"(xoxc-[^"]+)""#).expect("boot token regex")
    });
    re.captures(body)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn synthetic_workspace_email(workspace_url: &str, username: &str) -> Option<String> {
    let url = Url::parse(workspace_url).ok()?;
    let host = url.host_str()?.to_ascii_lowercase();
    if !host.ends_with(".slack.com") || host == "app.slack.com" {
        return None;
    }
    let subdomain = host.strip_suffix(".slack.com")?;
    if subdomain.is_empty() {
        return None;
    }
    Some(format!("{username}@{subdomain}.slack.com"))
}

#[cfg(test)]
mod slack_signin_tests {
    use super::*;

    #[test]
    fn parses_team_id_from_boot_json() {
        let html = r#"{"team_id":"T024BE7LR","something":1}"#;
        assert_eq!(
            extract_team_id_from_html(html).as_deref(),
            Some("T024BE7LR")
        );
    }

    #[test]
    fn team_url_from_domain() {
        let team = serde_json::json!({"domain": "acme", "id": "T024BE7LR"});
        let url = team_workspace_url(&team).unwrap();
        assert_eq!(url.host_str(), Some("acme.slack.com"));
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

fn preview(body: &str) -> String {
    body.chars().take(180).collect::<String>().replace('\n', " ")
}

fn render_messages_html(
    team_url: &Url,
    user: &str,
    prefix: &str,
    sections: &[(SlackChannel, Vec<Value>)],
) -> String {
    let mut body = String::new();
    body.push_str("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Slack export</title></head><body>\n");
    body.push_str(&format!(
        "<h1>Slack messages</h1><p>team={} user={} prefix={}</p>\n",
        team_url.host_str().unwrap_or(""),
        html_escape(user),
        html_escape(prefix),
    ));
    for (ch, msgs) in sections {
        body.push_str(&format!(
            "<h2>#{} ({})</h2><pre>",
            html_escape(&ch.name),
            html_escape(&ch.id),
        ));
        for msg in msgs.iter().take(500) {
            let text = msg.get("text").and_then(|t| t.as_str()).unwrap_or("");
            let user = msg.get("user").and_then(|u| u.as_str()).unwrap_or("?");
            body.push_str(&format!(
                "[{}] {}: {}\n",
                html_escape(msg.get("ts").and_then(|t| t.as_str()).unwrap_or("")),
                html_escape(user),
                html_escape(text),
            ));
        }
        body.push_str("</pre>\n");
    }
    body.push_str("</body></html>");
    body
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

pub async fn download_slack_exports(
    cred: &Credential,
    config: &SlackClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(SlackAccountStats, Vec<(SlackChannel, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_slack_exports_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_slack_exports_once(
    cred: Credential,
    config: &SlackClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(SlackAccountStats, Vec<(SlackChannel, PathBuf, u64)>)> {
    let mut client = SlackClient::new(
        cred.url.clone(),
        &cred.username,
        &cred.password,
        config,
    )?;
    if !client.detect().await? {
        bail!(
            "{} is not a Slack workspace (hostname should be *.slack.com)",
            cred.url.host_str().unwrap_or("host")
        );
    }

    let session_user = client
        .authenticate()
        .await
        .with_context(|| format!("Slack login failed for {}", cred.display_line()))?;

    if !download_files {
        return Ok((
            SlackAccountStats {
                username: session_user,
                channels: 0,
                messages_exported: 0,
                files: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let channels = client.list_channels().await.unwrap_or_default();
    let channel_count = channels.len();
    let files_meta = client.list_files().await.unwrap_or_default();
    let file_count = files_meta.len();

    let site_dir = cred.site_output_dir(output_dir, "slack");
    let prefix = cred.account_file_prefix();
    let token = client
        .api_token()
        .context("missing token after auth")?
        .to_string();

    let mut written = Vec::new();
    let mut messages_total = 0usize;
    let mut files_downloaded = 0usize;
    let mut total_bytes = 0u64;
    let mut file_bytes_account = 0u64;
    let mut export_sections = Vec::new();

    for channel in channels.iter().take(MAX_CHANNELS) {
        match client.export_channel_messages(channel).await {
            Ok(msgs) => {
                messages_total += msgs.len();
                if !msgs.is_empty() {
                    export_sections.push((channel.clone(), msgs));
                }
            }
            Err(err) => warn!("Slack channel {} history: {err}", channel.name),
        }
    }

    if !export_sections.is_empty() {
        let html_leaf = format!("{prefix}__messages.html");
        let html_path = output_file_path(&site_dir, &html_leaf);
        let html = render_messages_html(&cred.url, &session_user, &prefix, &export_sections);
        if let Some(parent) = html_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        fs::write(&html_path, html.as_bytes()).await?;
        let bytes = html.len() as u64;
        total_bytes += bytes;
        written.push((
            SlackChannel {
                id: "HTML".into(),
                name: "messages.html".into(),
            },
            html_path,
            bytes,
        ));
    }

    for file in files_meta {
        if files_downloaded >= MAX_FILES {
            break;
        }
        let name = file
            .get("name")
            .and_then(|n| n.as_str())
            .unwrap_or("file");
        if is_excluded_media_filename(name) {
            continue;
        }
        let size = file.get("size").and_then(|s| s.as_u64()).unwrap_or(0);
        if size > MAX_FILE_BYTES {
            continue;
        }
        if file_bytes_account + size > MAX_FILES_TOTAL_BYTES {
            break;
        }
        let url = file
            .get("url_private_download")
            .or_else(|| file.get("url_private"))
            .and_then(|u| u.as_str());
        let Some(url) = url else {
            continue;
        };
        let id = file.get("id").and_then(|i| i.as_str()).unwrap_or("file");
        let leaf = format!(
            "{}__{}__{}",
            prefix,
            Credential::safe_path_component(id),
            Credential::safe_path_component(name),
        );
        let path = output_file_path(&site_dir, &leaf);
        match client.download_file(url, &path, &token).await {
            Ok(bytes) => {
                files_downloaded += 1;
                file_bytes_account += bytes;
                total_bytes += bytes;
                debug!("Slack file {name} ({bytes} bytes)");
            }
            Err(err) => warn!("Slack download {name}: {err}"),
        }
    }

    Ok((
        SlackAccountStats {
            username: session_user,
            channels: channel_count,
            messages_exported: messages_total,
            files: file_count,
            downloaded: written.len() + files_downloaded,
            bytes: total_bytes,
        },
        written,
    ))
}
