use crate::note_app_common::{download_note_app_account, NoteAppAccountStats, NoteAppSpec};
use anyhow::Result;
use pma_core::Credential;
use std::path::{Path, PathBuf};

pub use crate::note_app_common::NoteAppClientConfig as SecondbrainClientConfig;

const SPEC: NoteAppSpec = NoteAppSpec {
    service_label: "The Second Brain",
    output_slug: "secondbrain",
    user_agent: "phpmyadmin-rs-secondbrain/0.1",
    login_paths: &["login", "auth/login", ""],
    post_paths: &["api/auth/login", "login"],
    json_login_paths: &["api/auth/login", "api/login"],
    success_probe_paths: &["api/user", "app", "dashboard", ""],
    inventory_api_paths: &["api/notes", "api/items"],
};

pub async fn download_secondbrain_account(
    cred: &Credential,
    config: &SecondbrainClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    download_note_app_account(cred, config, output_dir, download_files, &SPEC).await
}
