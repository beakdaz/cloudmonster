//! Atlassian Bamboo, S3 storage (`storage-bamboo.*`), and generic Bamboo hosts.

#[path = "bamboo_s3.rs"]
mod bamboo_s3;
use anyhow::{bail, Context, Result};
use bamboo_s3::{get_object, list_buckets, list_object_keys, looks_like_s3_access_key};
use pma_core::{is_excluded_media_filename, output_file_path, Credential};
use reqwest::{Client, Url};
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;
use tracing::{debug, warn};

const MAX_PLANS: usize = 50;
const MAX_ARTIFACTS_PER_PLAN: usize = 20;
const MAX_ARTIFACT_BYTES: u64 = 100 * 1024 * 1024;
const MAX_ARTIFACTS_TOTAL_BYTES: u64 = 1024 * 1024 * 1024;
const MAX_S3_OBJECTS: usize = 200;
const MAX_S3_BYTES: u64 = 512 * 1024 * 1024;

#[derive(Debug, Clone)]
pub struct BambooClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for BambooClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(120),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct BambooAccountStats {
    pub username: String,
    pub backend: String,
    pub plans: usize,
    pub artifacts: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl BambooAccountStats {
    pub fn detail_line(&self) -> String {
        let check_metric = self.plans.saturating_add(self.artifacts);
        let files = crate::stats_display::file_count(self.downloaded, check_metric);
        format!(
            "user={} backend={} plans={} artifacts={} files={files} ({})",
            self.username,
            self.backend,
            self.plans,
            self.artifacts,
            format_bytes(self.bytes),
        )
    }
}

/// S3-compatible Bamboo artifact storage hostnames (not Atlassian REST).
pub fn is_bamboo_s3_storage_host(url: &Url) -> bool {
    let host = url.host_str().unwrap_or("").to_ascii_lowercase();
    host.starts_with("storage-bamboo.")
        || host.starts_with("storage-bamboo-")
        || host.contains(".storage-bamboo.")
        || host.starts_with("storage.bamboo.")
        || host.contains(".storage.bamboo.")
        || host.contains("bamboo-storage.")
        || host.contains("-storage-bamboo.")
}

/// Any line in a Bamboo list already has `bamboo` in the hostname; S3 when keys look like AWS or host is storage-style.
fn should_try_s3_storage(cred: &Credential) -> bool {
    is_bamboo_s3_storage_host(&cred.url) || looks_like_s3_access_key(&cred.username)
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

fn build_http(config: &BambooClientConfig) -> Result<Client> {
    let mut builder = Client::builder()
        .cookie_store(true)
        .redirect(reqwest::redirect::Policy::limited(10))
        .timeout(config.timeout)
        .user_agent("phpmyadmin-rs-bamboo/0.1");
    if config.insecure {
        builder = builder.danger_accept_invalid_certs(true);
    }
    builder.build().context("HTTP client")
}

struct AtlassianBamboo {
    http: Client,
    base: Url,
    username: String,
    password: String,
}

impl AtlassianBamboo {
    fn new(cred: &Credential, config: &BambooClientConfig) -> Result<Self> {
        Ok(Self {
            http: build_http(config)?,
            base: cred.url.clone(),
            username: cred.username.clone(),
            password: cred.password.clone(),
        })
    }

    fn authed(&self, b: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        b.basic_auth(&self.username, Some(self.password.as_str()))
    }

    async fn detect(&self) -> Result<bool> {
        let url = self
            .base
            .join("rest/api/latest/info")
            .context("info url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            return Ok(false);
        }
        let v: serde_json::Value = resp.json().await.context("Bamboo info JSON")?;
        Ok(v.get("version")
            .and_then(|x| x.as_str())
            .is_some_and(|s| !s.is_empty()))
    }

    async fn current_user_name(&self) -> Result<String> {
        let url = self
            .base
            .join("rest/api/latest/currentUser")
            .context("currentUser url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("Bamboo authentication failed (HTTP {})", resp.status());
        }
        let v: serde_json::Value = resp.json().await?;
        Ok(v.get("name")
            .and_then(|n| n.as_str())
            .unwrap_or(&self.username)
            .to_string())
    }

    async fn authenticate(&self) -> Result<String> {
        self.current_user_name().await
    }

    async fn list_plan_keys(&self) -> Result<Vec<String>> {
        let url = self
            .base
            .join("rest/api/latest/plan?max-results=100")
            .context("plan url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("Bamboo plan list HTTP {}", resp.status());
        }
        let v: serde_json::Value = resp.json().await?;
        let mut keys = Vec::new();
        if let Some(plans) = v.get("plans").and_then(|p| p.as_array()) {
            for p in plans {
                if let Some(k) = p.get("key").and_then(|k| k.as_str()) {
                    keys.push(k.to_string());
                }
            }
        }
        Ok(keys)
    }

    async fn export_plan_json(&self, plan_key: &str) -> Result<Vec<u8>> {
        let path = format!("rest/api/latest/plan/{plan_key}.json");
        let url = self.base.join(&path).context("plan json url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("plan {plan_key} HTTP {}", resp.status());
        }
        Ok(resp.bytes().await?.to_vec())
    }

    async fn download_artifacts_for_plan(
        &self,
        plan_key: &str,
        site_root: &Path,
        prefix: &str,
        total_bytes: &mut u64,
        account_cap: &mut u64,
    ) -> Result<Vec<(String, PathBuf, u64)>> {
        let url = self
            .base
            .join(&format!(
                "rest/api/latest/plan/{plan_key}/results?max-results=3"
            ))
            .context("plan results url")?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            return Ok(Vec::new());
        }
        let v: serde_json::Value = resp.json().await?;
        let mut written = Vec::new();
        let results = v
            .get("results")
            .and_then(|r| r.as_array())
            .cloned()
            .unwrap_or_default();
        for result in results {
            if written.len() >= MAX_ARTIFACTS_PER_PLAN {
                break;
            }
            let result_key = result
                .get("resultKey")
                .or_else(|| result.get("key"))
                .and_then(|k| k.as_str());
            let Some(result_key) = result_key else { continue };
            let art_url = self
                .base
                .join(&format!("rest/api/latest/result/{result_key}?expand=artifacts"))
                .context("result artifacts url")?;
            let resp = self.authed(self.http.get(art_url)).send().await?;
            if !resp.status().is_success() {
                continue;
            }
            let art_v: serde_json::Value = resp.json().await?;
            let artifacts = art_v
                .pointer("/artifacts/artifact")
                .or_else(|| art_v.get("artifacts"))
                .and_then(|a| a.as_array())
                .cloned()
                .unwrap_or_default();
            for att in artifacts {
                if written.len() >= MAX_ARTIFACTS_PER_PLAN {
                    break;
                }
                let name = att
                    .get("name")
                    .and_then(|n| n.as_str())
                    .unwrap_or("artifact");
                if is_excluded_media_filename(name) {
                    continue;
                }
                let link = att
                    .get("link")
                    .and_then(|l| l.get("href"))
                    .or_else(|| att.get("href"))
                    .and_then(|h| h.as_str());
                let Some(link) = link else { continue };
                let download_url = if link.starts_with("http://") || link.starts_with("https://") {
                    Url::parse(link).ok()
                } else {
                    self.base.join(link).ok()
                };
                let Some(download_url) = download_url else { continue };
                let resp = self.authed(self.http.get(download_url)).send().await?;
                if !resp.status().is_success() {
                    continue;
                }
                let bytes = resp.bytes().await?;
                if bytes.len() as u64 > MAX_ARTIFACT_BYTES {
                    continue;
                }
                if *account_cap + bytes.len() as u64 > MAX_ARTIFACTS_TOTAL_BYTES {
                    return Ok(written);
                }
                let leaf = format!(
                    "{}__{}__{}__{}",
                    prefix,
                    safe(plan_key),
                    safe(result_key),
                    safe(name),
                );
                let path = output_file_path(site_root, &leaf);
                write_bytes(&path, &bytes).await?;
                let n = bytes.len() as u64;
                *account_cap += n;
                *total_bytes += n;
                written.push((name.to_string(), path, n));
            }
        }
        Ok(written)
    }
}

pub async fn download_bamboo_account(
    cred: &Credential,
    config: &BambooClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(BambooAccountStats, Vec<(String, PathBuf, u64)>)> {
    crate::http_client::try_http_https_for_cred(cred, |attempt| {
        download_bamboo_account_once(attempt, config, output_dir, download_files)
    })
    .await
}

async fn download_bamboo_account_once(
    cred: Credential,
    config: &BambooClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(BambooAccountStats, Vec<(String, PathBuf, u64)>)> {
    let site_root = cred.site_output_dir(output_dir, "bamboo");
    let prefix = cred.account_file_prefix();

    let atlassian = AtlassianBamboo::new(&cred, config)?;
    if atlassian.detect().await? {
        return run_atlassian_bamboo(&atlassian, &cred, &site_root, &prefix, download_files).await;
    }

    if should_try_s3_storage(&cred) {
        let http = build_http(config)?;
        return download_s3_storage(
            &cred,
            &http,
            &site_root,
            &prefix,
            download_files,
        )
        .await
        .with_context(|| {
            format!(
                "Bamboo S3 storage failed for {}",
                cred.url.host_str().unwrap_or("host")
            )
        });
    }

    bail!(
        "{} is not a Bamboo server (no REST API and not S3 storage; use AKIA… keys for S3 or Atlassian CI URL)",
        cred.url.host_str().unwrap_or("host")
    );
}

async fn run_atlassian_bamboo(
    atlassian: &AtlassianBamboo,
    cred: &Credential,
    site_root: &Path,
    prefix: &str,
    download_files: bool,
) -> Result<(BambooAccountStats, Vec<(String, PathBuf, u64)>)> {
    let session_user = atlassian
        .authenticate()
        .await
        .with_context(|| format!("Bamboo login failed for {}", cred.display_line()))?;
    let plans = atlassian.list_plan_keys().await?;
    let plan_count = plans.len().min(MAX_PLANS);

    if !download_files {
        return Ok((
            BambooAccountStats {
                username: session_user,
                backend: "atlassian".into(),
                plans: plan_count,
                artifacts: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let mut written = Vec::new();
    let mut total_bytes = 0u64;
    let mut artifact_total = 0usize;
    let mut account_cap = 0u64;
    for key in plans.iter().take(MAX_PLANS) {
        match atlassian.export_plan_json(key).await {
            Ok(bytes) => {
                let leaf = format!("{}__plan__{}.json", prefix, safe(key));
                let path = output_file_path(site_root, &leaf);
                write_bytes(&path, &bytes).await?;
                let n = bytes.len() as u64;
                total_bytes += n;
                written.push((key.clone(), path, n));
            }
            Err(err) => warn!("Bamboo plan {key}: {err}"),
        }
        match atlassian
            .download_artifacts_for_plan(key, site_root, prefix, &mut total_bytes, &mut account_cap)
            .await
        {
            Ok(files) => {
                artifact_total += files.len();
                written.extend(files);
            }
            Err(err) => warn!("Bamboo artifacts {key}: {err}"),
        }
    }

    Ok((
        BambooAccountStats {
            username: session_user,
            backend: "atlassian".into(),
            plans: plan_count,
            artifacts: artifact_total,
            downloaded: written.len(),
            bytes: total_bytes,
        },
        written,
    ))
}

async fn download_s3_storage(
    cred: &Credential,
    http: &Client,
    site_root: &Path,
    prefix: &str,
    download_files: bool,
) -> Result<(BambooAccountStats, Vec<(String, PathBuf, u64)>)> {
    let (buckets, region) = list_buckets(http, &cred.url, &cred.username, &cred.password).await?;
    let bucket_count = buckets.len();

    if !download_files {
        return Ok((
            BambooAccountStats {
                username: cred.username.clone(),
                backend: "s3".into(),
                plans: bucket_count,
                artifacts: 0,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let mut written = Vec::new();
    let mut total_bytes = 0u64;
    let mut downloaded = 0usize;

    for bucket in buckets {
        if downloaded >= MAX_S3_OBJECTS {
            break;
        }
        let objects = list_object_keys(
            http,
            &cred.url,
            &cred.username,
            &cred.password,
            &bucket,
            100,
            &region,
        )
        .await
        .unwrap_or_default();
        for (key, _size) in objects {
            if downloaded >= MAX_S3_OBJECTS {
                break;
            }
            if is_excluded_media_filename(&key) {
                continue;
            }
            let data = match get_object(
                http,
                &cred.url,
                &cred.username,
                &cred.password,
                &bucket,
                &key,
                &region,
            )
            .await
            {
                Ok(d) => d,
                Err(err) => {
                    warn!("S3 {bucket}/{key}: {err}");
                    continue;
                }
            };
            if data.len() as u64 > MAX_S3_BYTES {
                continue;
            }
            let leaf = format!(
                "{}__{}__{}",
                prefix,
                safe(&bucket),
                safe(&key),
            );
            let path = output_file_path(site_root, &leaf);
            write_bytes(&path, &data).await?;
            let n = data.len() as u64;
            downloaded += 1;
            total_bytes += n;
            written.push((key.clone(), path, n));
            debug!("S3 saved {bucket}/{key}");
        }
    }

    Ok((
        BambooAccountStats {
            username: cred.username.clone(),
            backend: "s3".into(),
            plans: bucket_count,
            artifacts: downloaded,
            downloaded,
            bytes: total_bytes,
        },
        written,
    ))
}

fn safe(input: &str) -> String {
    Credential::safe_path_component(input)
}

async fn write_bytes(path: &Path, data: &[u8]) -> Result<u64> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(path, data).await?;
    Ok(data.len() as u64)
}

#[cfg(test)]
mod tests {
    use super::*;
    use url::Url;

    #[test]
    fn storage_bamboo_host_detection() {
        let u = Url::parse("https://storage-bamboo.dev.masoffer.tech/").unwrap();
        assert!(is_bamboo_s3_storage_host(&u));
        let u2 = Url::parse("https://agl-bamboo.cloudapp.net/").unwrap();
        assert!(!is_bamboo_s3_storage_host(&u2));
    }

    #[test]
    fn s3_storage_gate() {
        let u = Url::parse("https://storage-bamboo.example.com/").unwrap();
        let cred = Credential {
            url: u,
            username: "not-an-aws-key".into(),
            password: "x".into(),
        };
        assert!(should_try_s3_storage(&cred));
    }
}
