//! Confluence REST: `/wiki/rest/api/user/current`, list spaces, export space list HTML.

use anyhow::{bail, Context, Result};
use pma_core::{output_file_path, Credential};
use reqwest::{Client, Url};
use serde::Deserialize;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::fs;

const MAX_SPACES: usize = 200;

#[derive(Debug, Clone)]
pub struct ConfluenceClientConfig {
    pub timeout: Duration,
    pub insecure: bool,
}

impl Default for ConfluenceClientConfig {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(60),
            insecure: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ConfluenceAccountStats {
    pub username: String,
    pub spaces: usize,
    pub downloaded: usize,
    pub bytes: u64,
}

impl ConfluenceAccountStats {
    pub fn detail_line(&self) -> String {
        let files = crate::stats_display::file_count(self.downloaded, self.spaces);
        format!(
            "user={} spaces={} files={files} ({})",
            self.username,
            self.spaces,
            format_bytes(self.bytes),
        )
    }
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

#[derive(Debug, Deserialize)]
struct ConfluenceUser {
    #[serde(default, rename = "displayName")]
    display_name: Option<String>,
    #[serde(default)]
    username: Option<String>,
    #[serde(default, rename = "email")]
    email: Option<String>,
}

#[derive(Debug, Deserialize)]
struct ConfluenceSpaceList {
    #[serde(default)]
    results: Vec<ConfluenceSpace>,
}

#[derive(Debug, Deserialize)]
struct ConfluenceSpace {
    #[serde(default)]
    key: Option<String>,
    #[serde(default)]
    name: Option<String>,
    #[serde(default, rename = "type")]
    space_type: Option<String>,
}

struct ConfluenceClient {
    http: Client,
    base: Url,
    api_prefix: String,
    username: String,
    password: String,
}

impl ConfluenceClient {
    fn new(base: Url, username: &str, password: &str, config: &ConfluenceClientConfig) -> Result<Self> {
        let mut builder = Client::builder()
            .cookie_store(true)
            .redirect(reqwest::redirect::Policy::limited(10))
            .timeout(config.timeout)
            .user_agent("phpmyadmin-rs-confluence/0.1");
        if config.insecure {
            builder = builder.danger_accept_invalid_certs(true);
        }
        Ok(Self {
            http: builder.build().context("HTTP client")?,
            base,
            api_prefix: "wiki/rest/api".to_string(),
            username: username.to_string(),
            password: password.to_string(),
        })
    }

    fn api_url(&self, path: &str) -> Result<Url> {
        self.base
            .join(&format!("{}/{path}", self.api_prefix.trim_end_matches('/')))
            .context("confluence url join")
    }

    fn authed(&self, builder: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
        builder.basic_auth(&self.username, Some(self.password.as_str()))
    }

    async fn connect(&mut self) -> Result<String> {
        let bases = candidate_bases(&self.base);
        let prefixes = ["wiki/rest/api", "rest/api"];
        let mut last: Option<anyhow::Error> = None;
        for base in bases {
            self.base = base;
            for prefix in prefixes {
                self.api_prefix = prefix.to_string();
                match self.fetch_current_user().await {
                    Ok(name) => return Ok(name),
                    Err(e) => last = Some(e),
                }
            }
        }
        Err(last.unwrap_or_else(|| {
            anyhow::anyhow!(
                "not a Confluence server or login failed for {}",
                self.base
            )
        }))
    }

    async fn fetch_current_user(&self) -> Result<String> {
        let url = self.api_url("user/current")?;
        let resp = self
            .authed(self.http.get(url))
            .header("Accept", "application/json")
            .send()
            .await
            .context("user/current")?;
        if !resp.status().is_success() {
            bail!("Confluence user/current HTTP {}", resp.status());
        }
        let user: ConfluenceUser = resp.json().await.context("current user json")?;
        Ok(user
            .display_name
            .or(user.username)
            .or(user.email)
            .unwrap_or_else(|| self.username.clone()))
    }

    async fn list_spaces(&self) -> Result<Vec<ConfluenceSpace>> {
        let url = self.api_url(&format!("space?limit={MAX_SPACES}"))?;
        let resp = self.authed(self.http.get(url)).send().await?;
        if !resp.status().is_success() {
            bail!("Confluence space list HTTP {}", resp.status());
        }
        let list: ConfluenceSpaceList = resp.json().await.context("space json")?;
        Ok(list.results)
    }
}

fn candidate_bases(base: &Url) -> Vec<Url> {
    let mut out = vec![base.clone()];
    let host = base.host_str().unwrap_or("").to_ascii_lowercase();
    if host.ends_with(".atlassian.net") {
        if let Ok(u) = base.join("/wiki/") {
            if !out.iter().any(|x| x.as_str() == u.as_str()) {
                out.push(u);
            }
        }
    }
    out
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn render_spaces_html(base: &Url, user: &str, spaces: &[ConfluenceSpace]) -> String {
    let mut rows = String::new();
    for sp in spaces {
        let key = sp.key.as_deref().unwrap_or("");
        let name = sp.name.as_deref().unwrap_or(key);
        let ty = sp.space_type.as_deref().unwrap_or("");
        rows.push_str(&format!(
            "<tr><td>{}</td><td>{}</td><td>{}</td></tr>",
            html_escape(key),
            html_escape(name),
            html_escape(ty),
        ));
    }
    format!(
        r#"<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><title>Confluence spaces</title>
<style>table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #ccc;padding:6px}}</style>
</head><body>
<h1>Confluence spaces</h1>
<p>Site: {site}<br/>User: {user}<br/>Count: {count}</p>
<table><thead><tr><th>Key</th><th>Name</th><th>Type</th></tr></thead><tbody>{rows}</tbody></table>
</body></html>"#,
        site = html_escape(base.as_str()),
        user = html_escape(user),
        count = spaces.len(),
        rows = rows,
    )
}

pub async fn download_confluence_account(
    cred: &Credential,
    config: &ConfluenceClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(ConfluenceAccountStats, Vec<(PathBuf, u64)>)> {
    let mut client = ConfluenceClient::new(cred.url.clone(), &cred.username, &cred.password, config)?;
    let session_user = client
        .connect()
        .await
        .with_context(|| format!("Confluence login failed for {}", cred.display_line()))?;

    let spaces = client.list_spaces().await.unwrap_or_default();
    let space_count = spaces.len();

    if !download_files {
        return Ok((
            ConfluenceAccountStats {
                username: session_user,
                spaces: space_count,
                downloaded: 0,
                bytes: 0,
            },
            Vec::new(),
        ));
    }

    let site_dir = cred.site_output_dir(output_dir, "confluence");
    let prefix = cred.account_file_prefix();
    let html = render_spaces_html(&cred.url, &session_user, &spaces);
    let leaf = format!("{prefix}__spaces.html");
    let path = output_file_path(&site_dir, &leaf);
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(&path, &html).await?;
    let bytes = html.len() as u64;
    Ok((
        ConfluenceAccountStats {
            username: session_user,
            spaces: space_count,
            downloaded: 1,
            bytes,
        },
        vec![(path, bytes)],
    ))
}
