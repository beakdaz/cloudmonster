//! MEGA.nz client (Mega v4.6 / mega-rs): login check and optional folder upload.

use anyhow::{bail, Context, Result};
use mega::{Client, Error, ErrorCode, LastModified, NodeKind, Nodes};
use pma_core::{
    is_mega_email_account, output_file_path, output_file_path_in_bucket, CloudDownloadFilter,
    Credential, ScanStatus,
};
use sha2::{Digest, Sha256};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;

type CheckStartedHook = Arc<dyn Fn() + Send + Sync>;
use tokio::fs;
use tokio::sync::Semaphore;
use tracing::debug;
use mega::http::CurlImpersonateClient;

// #region agent log
static AGENT_LOG: std::sync::Mutex<()> = std::sync::Mutex::new(());

fn agent_log(hypothesis_id: &str, location: &str, message: &str, data: serde_json::Value) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let _guard = AGENT_LOG.lock().unwrap_or_else(|e| e.into_inner());
    let line = serde_json::json!({
        "sessionId": "be3b27",
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0),
        "runId": "mega-gui",
    });
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

fn regex_mega_banned(msg: &str) -> bool {
    msg.contains("blocked")
        || msg.contains("EBLOCKED")
        || msg.contains("-16")
        || msg.contains("-26")
        || msg.contains("-28")
        || msg.contains("-27")
}

fn regex_mega_bad(msg: &str) -> bool {
    msg.contains("EKEY")
        || msg.contains("ENOENT")
        || msg.contains("-9")
        || msg.contains("-14")
        || msg.contains("-11")
        || msg.contains("-2")
        || msg.contains("-13")
        || msg.contains("invalid key")
        || msg.contains("does not exist")
}

fn mega_error_code_status(code: ErrorCode) -> Option<ScanStatus> {
    match code {
        // Mega v4.6 banned-like: (-16|-26|-28|-27)
        ErrorCode::EBLOCKED
        | ErrorCode::EMFAREQUIRED
        | ErrorCode::EMASTERONLY
        | ErrorCode::EBUSINESSPASTDUE
        | ErrorCode::EPAYWALL => Some(ScanStatus::InvalidCredentials),
        // Mega v4.6 bad: (-9|-15|-14|-11|-2|-13)
        ErrorCode::ENOENT
        | ErrorCode::EKEY
        | ErrorCode::EACCESS
        | ErrorCode::EINCOMPLETE
        | ErrorCode::EARGS
        | ErrorCode::ESID
        | ErrorCode::EEXIST => Some(ScanStatus::InvalidCredentials),
        _ => None,
    }
}

pub fn mega_is_banned_error(err: &Error) -> bool {
    if let Error::MegaError { code, .. } = err {
        return matches!(
            code,
            ErrorCode::EBLOCKED
                | ErrorCode::EMFAREQUIRED
                | ErrorCode::EMASTERONLY
                | ErrorCode::EBUSINESSPASTDUE
                | ErrorCode::EPAYWALL
        );
    }
    regex_mega_banned(&err.to_string())
}

pub fn mega_is_banned_anyhow(err: &anyhow::Error) -> bool {
    if let Some(e) = err.downcast_ref::<Error>() {
        return mega_is_banned_error(e);
    }
    err.chain().any(|c| c.downcast_ref::<Error>().is_some_and(mega_is_banned_error))
}

pub fn scan_status_for_mega_error(err: &Error) -> ScanStatus {
    if let Error::MegaError { code, .. } = err {
        if let Some(status) = mega_error_code_status(*code) {
            return status;
        }
    }
    match err {
        Error::InvalidResponseFormat
        | Error::InvalidRsaPrivateKeyFormat
        | Error::HmacMismatch { .. } => return ScanStatus::InvalidCredentials,
        _ => {}
    }
    let msg = err.to_string();
    if regex_mega_banned(&msg) {
        return ScanStatus::InvalidCredentials;
    }
    if regex_mega_bad(&msg) {
        return ScanStatus::InvalidCredentials;
    }
    ScanStatus::Error
}

pub fn scan_status_for_mega_anyhow(err: &anyhow::Error) -> ScanStatus {
    if let Some(e) = err.downcast_ref::<Error>() {
        return scan_status_for_mega_error(e);
    }
    for cause in err.chain() {
        if let Some(e) = cause.downcast_ref::<Error>() {
            return scan_status_for_mega_error(e);
        }
    }
    ScanStatus::Error
}

fn mega_error_code(err: &Error) -> Option<String> {
    match err {
        Error::MegaError { code, .. } => Some(format!("{code:?}")),
        _ => None,
    }
}

fn login_retry_delay(attempt: u32) -> Duration {
    let ms = 600_u64.saturating_mul(2_u64.saturating_pow(attempt.min(6)));
    Duration::from_millis(ms.min(12_000))
}

fn is_transient_mega_error(err: &Error) -> bool {
    match err {
        Error::MaxRetriesReached => true,
        Error::InvalidResponseType => true,
        Error::InvalidResponseFormat | Error::InvalidRsaPrivateKeyFormat | Error::HmacMismatch { .. } => {
            false
        }
        Error::CurlImpersonate(_) => false,
        Error::MegaError {
            code:
                ErrorCode::EAGAIN
                | ErrorCode::ERATELIMIT
                | ErrorCode::ETEMPUNAVAIL
                | ErrorCode::ETOOMANY
                | ErrorCode::ETOOMANYCONNECTIONS
                | ErrorCode::EFAILED
                | ErrorCode::EINTERNAL,
            ..
        } => true,
        _ => false,
    }
}

async fn login_with_retry(
    client: &mut Client,
    email: &str,
    password: &str,
    max_attempts: u32,
) -> std::result::Result<(), Error> {
    let mut last: Option<Error> = None;
    for attempt in 0..max_attempts {
        match client.login(email, password, None).await {
            Ok(()) => return Ok(()),
            Err(e) if is_transient_mega_error(&e) => {
                last = Some(e);
                tokio::time::sleep(login_retry_delay(attempt)).await;
            }
            Err(e) => return Err(e),
        }
    }
    Err(last.unwrap_or(Error::MaxRetriesReached))
}

async fn fetch_nodes_with_retry(client: &Client, email: &str, max_attempts: u32) -> Option<Nodes> {
    let mut last: Option<Error> = None;
    for attempt in 0..max_attempts {
        match client.fetch_own_nodes().await {
            Ok(nodes) => {
                agent_log(
                    "H-F",
                    "mega.rs:fetch_nodes_with_retry",
                    "fetch nodes ok",
                    serde_json::json!({ "email": email, "attempt": attempt + 1 }),
                );
                return Some(nodes);
            }
            Err(e) if is_transient_mega_error(&e) && attempt + 1 < max_attempts => {
                agent_log(
                    "H-B",
                    "mega.rs:fetch_nodes_with_retry",
                    "fetch nodes retry",
                    serde_json::json!({
                        "email": email,
                        "attempt": attempt + 1,
                        "mega_code": mega_error_code(&e),
                        "err": format!("{e}"),
                    }),
                );
                last = Some(e);
                tokio::time::sleep(login_retry_delay(attempt)).await;
            }
            Err(e) => {
                agent_log(
                    "H5",
                    "mega.rs:download_mega_account",
                    "fetch nodes failed",
                    serde_json::json!({
                        "email": email,
                        "mega_code": mega_error_code(&e),
                        "err": format!("{e}"),
                        "attempt": attempt + 1,
                    }),
                );
                return None;
            }
        }
    }
    if let Some(e) = last {
        agent_log(
            "H5",
            "mega.rs:download_mega_account",
            "fetch nodes exhausted",
            serde_json::json!({
                "email": email,
                "mega_code": mega_error_code(&e),
                "err": format!("{e}"),
            }),
        );
    }
    None
}

/// Max concurrent MEGA logins (Mega v4.6 `sem_login`).
pub const MEGA_LOGIN_CONCURRENCY: usize = 6;

#[derive(Debug, Clone)]
pub struct MegaClientConfig {
    pub timeout: Duration,
    pub upload_dir: Option<PathBuf>,
    /// One shared pool for all workers (Mega v4.6–style: many threads, one HTTP stack).
    pub http: Arc<CurlImpersonateClient>,
    /// Limits parallel `Client::login` calls (hashcash / rate limits).
    pub login_semaphore: Arc<Semaphore>,
    pub download_from_cloud: bool,
    pub download_filter: CloudDownloadFilter,
}

/// Build curl-impersonate Chrome client for MEGA API (`MEGA_CURL_BIN` or `curl_chrome110` on PATH).
pub fn build_mega_http(_timeout: Duration) -> Result<Arc<CurlImpersonateClient>> {
    Ok(Arc::new(CurlImpersonateClient::new().context(
        "MEGA curl-impersonate (set MEGA_CURL_BIN or install curl_chrome110 on PATH)",
    )?))
}

impl MegaClientConfig {
    pub fn new(
        timeout: Duration,
        upload_dir: Option<PathBuf>,
        checker_threads: usize,
        download_from_cloud: bool,
        download_filter: CloudDownloadFilter,
    ) -> Result<Self> {
        let login_slots = crate::concurrency::megax_mega_login_parallel(checker_threads);
        Ok(Self {
            timeout,
            upload_dir,
            http: build_mega_http(timeout)?,
            login_semaphore: Arc::new(Semaphore::new(login_slots)),
            download_from_cloud,
            download_filter,
        })
    }
}

#[derive(Debug, Clone)]
pub struct MegaAccountStats {
    pub email: String,
    pub used_bytes: u64,
    pub total_bytes: u64,
    /// Files in Cloud Drive (metadata only, no download).
    pub cloud_file_count: usize,
    pub cloud_bytes: u64,
    pub uploaded_files: usize,
    pub uploaded_bytes: u64,
    pub downloaded_files: usize,
    pub downloaded_bytes: u64,
}

impl MegaAccountStats {
    pub fn detail_line(&self) -> String {
        format!(
            "email={} quota={}/{} cloud={} files ({} B) uploaded={} files ({} B) downloaded={} files ({} B)",
            self.email,
            self.used_bytes,
            self.total_bytes,
            self.cloud_file_count,
            self.cloud_bytes,
            self.uploaded_files,
            self.uploaded_bytes,
            self.downloaded_files,
            self.downloaded_bytes,
        )
    }
}

const MAX_CLOUD_LIST_LINES: usize = 20_000;
/// Mega.nz v4.3 cloud inventory folder (same name as original checker).
const MEGA_CONTENTS_DIR: &str = "Содержимое";

fn format_bytes_v43(bytes: u64) -> String {
    const GB: f64 = 1024.0 * 1024.0 * 1024.0;
    const MB: f64 = 1024.0 * 1024.0;
    const KB: f64 = 1024.0;
    let gb = bytes as f64 / GB;
    if gb >= 1.0 {
        return format!("{gb:.2} ГБ");
    }
    let mb = bytes as f64 / MB;
    if mb >= 1.0 {
        return format!("{mb:.2} МБ");
    }
    let kb = bytes as f64 / KB;
    format!("{kb:.2} КБ")
}

/// 8-hex suffix like `CFE5E549` in v4.3 filenames (deterministic from MEGA user id).
fn mega_contents_tag(user_id: &str) -> String {
    let digest = Sha256::digest(user_id.as_bytes());
    format!(
        "{:02X}{:02X}{:02X}{:02X}",
        digest[0], digest[1], digest[2], digest[3]
    )
}

fn mega_contents_leaf_filename(file_count: usize, email: &str, tag: &str) -> String {
    format!("{file_count}_FILES_{email}_{tag}.txt")
}

struct MegaFileEntry {
    path: String,
    name: String,
    size: u64,
    handle: String,
}

fn inventory_cloud_drive(nodes: &Nodes) -> (Vec<String>, Vec<MegaFileEntry>, u64, usize) {
    let mut lines = Vec::new();
    let mut entries = Vec::new();
    let mut total_bytes = 0u64;
    let mut file_count = 0usize;

    fn walk(
        nodes: &Nodes,
        handle: &str,
        prefix: &str,
        lines: &mut Vec<String>,
        entries: &mut Vec<MegaFileEntry>,
        total_bytes: &mut u64,
        file_count: &mut usize,
    ) {
        let Some(node) = nodes.get_node_by_handle(handle) else {
            return;
        };
        for child_handle in node.children() {
            let Some(child) = nodes.get_node_by_handle(child_handle) else {
                continue;
            };
            let path = if prefix.is_empty() {
                child.name().to_string()
            } else {
                format!("{prefix}/{}", child.name())
            };
            match child.kind() {
                NodeKind::File => {
                    *file_count += 1;
                    *total_bytes += child.size();
                    if lines.len() < MAX_CLOUD_LIST_LINES {
                        lines.push(child.name().to_string());
                    }
                    if entries.len() < MAX_CLOUD_LIST_LINES {
                        entries.push(MegaFileEntry {
                            path: path.clone(),
                            name: child.name().to_string(),
                            size: child.size(),
                            handle: child_handle.to_string(),
                        });
                    }
                }
                NodeKind::Folder => {
                    walk(
                        nodes,
                        child_handle,
                        &path,
                        lines,
                        entries,
                        total_bytes,
                        file_count,
                    );
                }
                _ => {}
            }
        }
    }

    if let Some(root) = nodes.cloud_drive() {
        walk(
            nodes,
            root.handle(),
            "",
            &mut lines,
            &mut entries,
            &mut total_bytes,
            &mut file_count,
        );
    }
    lines.sort_unstable();
    (lines, entries, total_bytes, file_count)
}

async fn download_mega_filtered(
    client: &mut Client,
    nodes: &Nodes,
    filter: &CloudDownloadFilter,
    cred: &Credential,
    output_dir: &Path,
    written: &mut Vec<PathBuf>,
) -> Result<(usize, u64)> {
    let (_, entries, _, _) = inventory_cloud_drive(nodes);
    let site_root = output_dir.join(cred.site_dir_name());
    let mut count = 0usize;
    let mut bytes = 0u64;
    for entry in entries {
        if !filter.matches(&entry.path, entry.size) {
            continue;
        }
        let Some(node) = nodes.get_node_by_handle(&entry.handle) else {
            continue;
        };
        let dest = output_file_path(&site_root, &entry.name);
        if let Some(parent) = dest.parent() {
            fs::create_dir_all(parent).await?;
        }
        let mut buf = Vec::new();
        if client.download_node(node, &mut buf).await.is_err() {
            continue;
        }
        if fs::write(&dest, &buf).await.is_err() {
            continue;
        }
        let n = buf.len() as u64;
        count += 1;
        bytes += n;
        written.push(dest);
    }
    Ok((count, bytes))
}

pub async fn download_mega_account(
    cred: &Credential,
    config: &MegaClientConfig,
    output_dir: &Path,
    upload_files: bool,
    on_check_started: Option<CheckStartedHook>,
) -> Result<(MegaAccountStats, Vec<PathBuf>)> {
    if !is_mega_email_account(cred) {
        bail!("not a MEGA email account line");
    }
    let email = cred.username.clone();

    let http = config.http.as_ref().clone();
    let per_request = config.timeout.min(Duration::from_secs(50));
    let mut client = Client::builder()
        .max_retries(8)
        .min_retry_delay(Duration::from_millis(300))
        .max_retry_delay(Duration::from_secs(5))
        .timeout(Some(per_request))
        .build(http)
        .context("mega client build")?;

    let mut written = Vec::new();
    let mut uploaded_files = 0usize;
    let mut uploaded_bytes = 0u64;
    let mut downloaded_files = 0usize;
    let mut downloaded_bytes = 0u64;
    let mut cloud_file_count = 0usize;
    let mut cloud_bytes = 0u64;
    let mut used = 0u64;
    let mut total = 0u64;
    let mut session_nodes: Option<Nodes> = None;

    {
        let sem_wait = std::time::Instant::now();
        let _login_slot = config
            .login_semaphore
            .acquire()
            .await
            .context("MEGA login semaphore")?;
        let login_sem_wait_ms = sem_wait.elapsed().as_millis();
        if login_sem_wait_ms > 100 {
            agent_log(
                "H-A",
                "mega.rs:download_mega_account",
                "login sem wait",
                serde_json::json!({ "login_sem_wait_ms": login_sem_wait_ms }),
            );
        }
        if let Some(hook) = &on_check_started {
            hook();
        }

        agent_log(
            "H1",
            "mega.rs:download_mega_account",
            "login start",
            serde_json::json!({ "email": email, "upload_files": upload_files }),
        );

        let login_t0 = std::time::Instant::now();
        if let Err(e) = login_with_retry(&mut client, &email, &cred.password, 3).await {
            agent_log(
                "H4",
                "mega.rs:download_mega_account",
                "login failed",
                serde_json::json!({
                    "email": email,
                    "mega_code": mega_error_code(&e),
                    "err": format!("{e}"),
                    "login_ms": login_t0.elapsed().as_millis(),
                }),
            );
            return Err(e.into());
        }
        agent_log(
            "H-D",
            "mega.rs:download_mega_account",
            "login ok timing",
            serde_json::json!({
                "login_ms": login_t0.elapsed().as_millis(),
                "login_sem_wait_ms": login_sem_wait_ms,
            }),
        );

        agent_log(
            "H1",
            "mega.rs:download_mega_account",
            "login ok",
            serde_json::json!({ "email": email }),
        );

        let user_info = client
            .get_current_user_info()
            .await
            .map_err(|e| e)
            .context("MEGA session check (ug)")?;
        let contents_tag = mega_contents_tag(&user_info.id);

        let (used_q, total_q) = match client.get_storage_quotas().await {
            Ok(quotas) => (quotas.memory_used, quotas.memory_total),
            Err(e) if scan_status_for_mega_error(&e) == ScanStatus::InvalidCredentials => {
                return Err(e.into());
            }
            Err(e) => {
                agent_log(
                    "H5",
                    "mega.rs:download_mega_account",
                    "quota failed (login still valid)",
                    serde_json::json!({
                        "email": email,
                        "mega_code": mega_error_code(&e),
                        "err": format!("{e}"),
                    }),
                );
                (0, 0)
            }
        };
        used = used_q;
        total = total_q;

        let nodes = fetch_nodes_with_retry(&client, &email, 6).await;
        let (lines, cloud_bytes_inner, cloud_file_count_inner) = if let Some(ref node_tree) = nodes
        {
            let (lines, _entries, bytes, count) = inventory_cloud_drive(node_tree);
            (lines, bytes, count)
        } else {
            (Vec::new(), 0, 0)
        };
        cloud_file_count = cloud_file_count_inner;
        cloud_bytes = cloud_bytes_inner;

        let leaf = mega_contents_leaf_filename(cloud_file_count, &email, &contents_tag);
        let list_path = output_file_path_in_bucket(output_dir, &leaf, MEGA_CONTENTS_DIR);
        if let Some(parent) = list_path.parent() {
            fs::create_dir_all(parent).await?;
        }
        let quota_line = format!(
            "{}/{}",
            format_bytes_v43(used),
            format_bytes_v43(total)
        );
        let mut body = format!(
            "DATA = {email}:{} | FILES = {cloud_file_count} | USED QUOTA = {quota_line} | TARIFF = Free\n\n\n",
            cred.password
        );
        if nodes.is_none() {
            body.push_str("# cloud file list unavailable (fetch nodes failed after retries)\n");
        } else if lines.len() < cloud_file_count {
            body.push_str(&format!(
                "# listed {} of {} files (cap {})\n",
                lines.len(),
                cloud_file_count,
                MAX_CLOUD_LIST_LINES
            ));
        }
        for name in &lines {
            body.push_str(name);
            body.push('\n');
        }
        fs::write(&list_path, body).await?;
        written.push(list_path);
        agent_log(
            "H-v43",
            "mega.rs:contents_list",
            "wrote v4.3 contents file",
            serde_json::json!({
                "leaf": leaf,
                "cloud_file_count": cloud_file_count,
                "cloud_bytes": cloud_bytes,
                "list_lines": lines.len(),
                "nodes_ok": nodes.is_some(),
            }),
        );
        session_nodes = nodes;
    }

    if config.download_from_cloud && !upload_files {
        if let Some(ref nodes) = session_nodes {
            let (n, b) = download_mega_filtered(
                &mut client,
                nodes,
                &config.download_filter,
                cred,
                output_dir,
                &mut written,
            )
            .await?;
            downloaded_files = n;
            downloaded_bytes = b;
        }
    }

    if upload_files {
        let upload_dir = config
            .upload_dir
            .as_ref()
            .context("upload directory not set (MEGA upload mode)")?;
        if !upload_dir.is_dir() {
            bail!("upload directory does not exist: {}", upload_dir.display());
        }
        let nodes = match session_nodes {
            Some(n) => n,
            None => fetch_nodes_with_retry(&client, &email, 3)
                .await
                .context("fetch nodes for upload")?,
        };
        let parent = nodes
            .cloud_drive()
            .context("MEGA cloud drive root missing")?;

        agent_log(
            "H2",
            "mega.rs:upload",
            "upload dir",
            serde_json::json!({ "path": upload_dir.display().to_string() }),
        );

        let mut entries = fs::read_dir(upload_dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            let path = entry.path();
            if !path.is_file() {
                continue;
            }
            let name = path
                .file_name()
                .and_then(|n| n.to_str())
                .unwrap_or("")
                .to_string();
            if name.is_empty() {
                continue;
            }
            let bytes = fs::read(&path).await?;
            let size = bytes.len() as u64;
            client
                .upload_node(
                    parent,
                    &name,
                    size,
                    bytes.as_slice(),
                    LastModified::Now,
                )
                .await
                .with_context(|| format!("upload `{name}` to MEGA"))?;
            uploaded_files += 1;
            uploaded_bytes += size;
            debug!("MEGA uploaded {name} ({size} bytes) for {email}");
        }
    }

    let stats = MegaAccountStats {
        email,
        used_bytes: used,
        total_bytes: total,
        cloud_file_count,
        cloud_bytes,
        uploaded_files,
        uploaded_bytes,
        downloaded_files,
        downloaded_bytes,
    };

    let site_root = output_dir.join(cred.site_dir_name());
    let marker = output_file_path(&site_root, "mega_check.txt");
    if let Some(parent) = marker.parent() {
        fs::create_dir_all(parent).await?;
    }
    fs::write(
        &marker,
        format!(
            "{}\nused={}\ntotal={}\ncloud_files={}\ncloud_bytes={}\nuploaded_files={}\n",
            stats.detail_line(),
            used,
            total,
            cloud_file_count,
            cloud_bytes,
            uploaded_files,
        ),
    )
    .await?;
    written.push(marker);

    agent_log(
        "H3",
        "mega.rs:download_mega_account",
        "done",
        serde_json::json!({
            "uploaded_files": uploaded_files,
            "uploaded_bytes": uploaded_bytes,
            "cloud_files": cloud_file_count,
            "cloud_bytes": cloud_bytes,
            "used": used,
            "total": total,
        }),
    );

    Ok((stats, written))
}
