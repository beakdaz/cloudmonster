use crate::note_app_common::{download_note_app_account, NoteAppAccountStats, NoteAppSpec};
use anyhow::Result;
use pma_core::Credential;
use std::path::{Path, PathBuf};

pub use crate::note_app_common::NoteAppClientConfig as AppflowyClientConfig;

const SPEC: NoteAppSpec = NoteAppSpec {
    service_label: "AppFlowy",
    output_slug: "appflowy",
    user_agent: "phpmyadmin-rs-appflowy/0.1",
    login_paths: &["login", "app", ""],
    post_paths: &["api/auth/sign-in", "api/login", "login"],
    json_login_paths: &["api/auth/sign-in", "api/login", "gotrue/token"],
    success_probe_paths: &["api/workspace", "app", "api/user", ""],
    inventory_api_paths: &["api/workspace", "api/documents"],
};

pub async fn download_appflowy_account(
    cred: &Credential,
    config: &AppflowyClientConfig,
    output_dir: &Path,
    download_files: bool,
) -> Result<(NoteAppAccountStats, Vec<(PathBuf, u64)>)> {
    download_note_app_account(cred, config, output_dir, download_files, &SPEC).await
}
