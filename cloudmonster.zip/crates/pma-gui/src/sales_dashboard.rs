//! Figma «Sales Dashboard (Community)» — dark layout, gradient KPI cards, yellow CTAs.
//! Reference: node 1-4, 1440×900 frame.

#![allow(dead_code)]

use eframe::egui::{
    self, Color32, CursorIcon, FontData, FontDefinitions, FontFamily, FontId, Pos2, Rect,
    Rounding, Sense, Stroke, Ui, Vec2, Visuals,
};
use egui::Align2;
use std::sync::Arc;

/// Bebas (BEBAS___.TTF) — display face for AdminPanel.
const FONT_BEBAS: &str = "bebas";

use crate::PmaApp;
use crate::Stats;

// —— palette (Community file) ——
pub const BG: Color32 = Color32::from_rgb(16, 16, 22);
pub const SHELL: Color32 = Color32::from_rgb(22, 22, 30);
pub const CARD: Color32 = Color32::from_rgb(28, 28, 38);
pub const CARD_SOFT: Color32 = Color32::from_rgb(34, 34, 46);
pub const INPUT: Color32 = Color32::from_rgb(24, 24, 32);
pub const BORDER: Color32 = Color32::from_rgb(42, 42, 56);
pub const TEXT: Color32 = Color32::from_rgb(255, 255, 255);
pub const MUTED: Color32 = Color32::from_rgb(140, 140, 158);
pub const MUTED2: Color32 = Color32::from_rgb(110, 110, 128);

pub const GRAD_CYAN_A: Color32 = Color32::from_rgb(34, 211, 238);
pub const GRAD_CYAN_B: Color32 = Color32::from_rgb(6, 182, 212);
pub const GRAD_GOLD_A: Color32 = Color32::from_rgb(250, 204, 21);
pub const GRAD_GOLD_B: Color32 = Color32::from_rgb(245, 158, 11);
pub const GRAD_PINK_A: Color32 = Color32::from_rgb(236, 72, 153);
pub const GRAD_PINK_B: Color32 = Color32::from_rgb(168, 85, 247);

pub const BTN_YELLOW: Color32 = Color32::from_rgb(250, 204, 21);
pub const BTN_YELLOW_TEXT: Color32 = Color32::from_rgb(24, 24, 32);
pub const ACCENT_PURPLE: Color32 = Color32::from_rgb(167, 139, 250);
pub const ACCENT_CYAN: Color32 = Color32::from_rgb(56, 189, 248);
pub const SUCCESS: Color32 = Color32::from_rgb(74, 222, 128);
pub const DANGER: Color32 = Color32::from_rgb(248, 113, 113);
pub const WARNING: Color32 = Color32::from_rgb(250, 204, 21);

pub const RADIUS_XL: f32 = 28.0;
pub const RADIUS_LG: f32 = 22.0;
pub const RADIUS_MD: f32 = 14.0;
pub const RADIUS_PILL: f32 = 999.0;
pub const NAV_W: f32 = 76.0;
pub const RIGHT_W: f32 = 280.0;
pub const PAD: f32 = 20.0;
pub const CTRL_H: f32 = 40.0;

/// AdminPanel: tighter layout + slightly smaller logical pixels.
pub const ADMIN_PAD: f32 = 12.0;
pub const ADMIN_RIGHT_W: f32 = 220.0;
pub const ADMIN_CTRL_H: f32 = 32.0;

pub fn apply(ctx: &egui::Context) {
    let mut visuals = Visuals::dark();
    visuals.panel_fill = SHELL;
    visuals.window_fill = BG;
    visuals.extreme_bg_color = BG;
    visuals.faint_bg_color = CARD;
    visuals.widgets.noninteractive.bg_fill = CARD;
    visuals.widgets.inactive.bg_fill = INPUT;
    visuals.widgets.hovered.bg_fill = CARD_SOFT;
    visuals.widgets.active.bg_fill = CARD_SOFT;
    visuals.widgets.inactive.fg_stroke = Stroke::new(1.0, TEXT);
    visuals.widgets.inactive.bg_stroke = Stroke::new(1.0, BORDER);
    visuals.window_rounding = Rounding::same(RADIUS_XL);
    visuals.window_stroke = Stroke::NONE;
    ctx.set_visuals(visuals);
    let mut style = (*ctx.style()).clone();
    style.spacing.item_spacing = egui::vec2(10.0, 10.0);
    style.spacing.button_padding = egui::vec2(14.0, 8.0);
    ctx.set_style(style);
}

fn install_bebas_font(ctx: &egui::Context) {
    let mut fonts = FontDefinitions::default();
    fonts.font_data.insert(
        FONT_BEBAS.to_owned(),
        FontData::from_static(include_bytes!("../assets/fonts/BebasNeue.ttf")),
    );
    let bebas_family = FontFamily::Name(Arc::from(FONT_BEBAS));
    fonts
        .families
        .insert(bebas_family.clone(), vec![FONT_BEBAS.to_owned()]);
    if let Some(prop) = fonts.families.get_mut(&FontFamily::Proportional) {
        prop.insert(0, FONT_BEBAS.to_owned());
    }
    ctx.set_fonts(fonts);
}

pub fn font_display(size: f32) -> FontId {
    FontId::new(size, FontFamily::Name(Arc::from(FONT_BEBAS)))
}

/// Note Check / CRM Check: slightly larger chrome (~93% logical scale).
pub const SUITE_GUI_SCALE: f32 = 0.925;

pub fn apply_suite_check(ctx: &egui::Context) {
    apply(ctx);
    install_bebas_font(ctx);
    ctx.set_pixels_per_point(SUITE_GUI_SCALE);
    let mut style = (*ctx.style()).clone();
    style.spacing.item_spacing = egui::vec2(6.0, 5.0);
    style.spacing.button_padding = egui::vec2(10.0, 5.0);
    style.spacing.slider_width = 120.0;
    style.text_styles.insert(egui::TextStyle::Heading, font_display(19.0));
    style.text_styles.insert(egui::TextStyle::Body, font_display(13.0));
    style.text_styles.insert(egui::TextStyle::Button, font_display(13.0));
    style.text_styles.insert(egui::TextStyle::Monospace, FontId::monospace(13.0));
    style.text_styles.insert(egui::TextStyle::Small, font_display(12.0));
    ctx.set_style(style);
}

pub fn apply_adminpanel(ctx: &egui::Context) {
    apply(ctx);
    install_bebas_font(ctx);
    // 90% logical scale — readable; ScrollArea for long cloud forms.
    ctx.set_pixels_per_point(0.9);
    let mut style = (*ctx.style()).clone();
    style.spacing.item_spacing = egui::vec2(5.0, 4.0);
    style.spacing.button_padding = egui::vec2(9.0, 4.0);
    style.spacing.slider_width = 110.0;
    style.text_styles.insert(egui::TextStyle::Heading, font_display(18.0));
    style.text_styles.insert(egui::TextStyle::Body, font_display(12.0));
    style.text_styles.insert(egui::TextStyle::Button, font_display(12.0));
    style.text_styles.insert(egui::TextStyle::Monospace, FontId::monospace(12.0));
    style.text_styles.insert(egui::TextStyle::Small, font_display(11.0));
    ctx.set_style(style);
}

pub fn paint_app_backdrop(ctx: &egui::Context) {
    let rect = ctx.input(|i| i.screen_rect());
    if rect.width() < 1.0 {
        return;
    }
    let p = ctx.layer_painter(egui::LayerId::background());
    p.rect_filled(rect, Rounding::same(RADIUS_XL), BG);
    let inset = rect.shrink(8.0);
    p.rect(
        inset,
        Rounding::same(RADIUS_XL),
        SHELL,
        Stroke::new(1.0, BORDER),
    );
}

pub fn title_bar(ctx: &egui::Context, title: &str) {
    egui::TopBottomPanel::top("sales_chrome")
        .exact_height(40.0)
        .frame(egui::Frame::none().fill(Color32::TRANSPARENT))
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                let (drag_rect, drag) =
                    ui.allocate_exact_size(Vec2::new(ui.available_width() - 36.0, 32.0), Sense::click_and_drag());
                ui.allocate_ui_at_rect(drag_rect, |ui| {
                    ui.label(
                        egui::RichText::new(title)
                            .size(12.0)
                            .color(MUTED),
                    );
                });
                if drag.drag_started() {
                    ctx.send_viewport_cmd(egui::ViewportCommand::StartDrag);
                }
                if drag.hovered() || drag.dragged() {
                    ui.ctx()
                        .output_mut(|o| o.cursor_icon = CursorIcon::Grab);
                }
                if ui
                    .button(egui::RichText::new("✕").color(MUTED))
                    .clicked()
                {
                    ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                }
            });
        });
}

pub fn nav_rail_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(CARD)
        .rounding(Rounding::same(RADIUS_LG))
        .stroke(Stroke::new(1.0, BORDER))
        .inner_margin(egui::Margin::symmetric(12.0, 16.0))
}

pub fn main_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(Color32::TRANSPARENT)
        .inner_margin(egui::Margin::same(PAD))
}

pub fn panel_card_frame() -> egui::Frame {
    egui::Frame::none()
        .fill(CARD)
        .rounding(Rounding::same(RADIUS_LG))
        .stroke(Stroke::new(1.0, BORDER))
        .inner_margin(egui::Margin::same(16.0))
}

fn vertical_gradient(painter: &egui::Painter, rect: Rect, top: Color32, bottom: Color32) {
    let mut mesh = egui::Mesh::default();
    mesh.colored_vertex(rect.left_top(), top);
    mesh.colored_vertex(rect.right_top(), top);
    mesh.colored_vertex(rect.right_bottom(), bottom);
    mesh.colored_vertex(rect.left_bottom(), bottom);
    mesh.add_triangle(0, 1, 2);
    mesh.add_triangle(0, 2, 3);
    painter.add(egui::Shape::mesh(mesh));
}

pub enum KpiGradient {
    Cyan,
    Gold,
    Pink,
    Orange,
    Violet,
}

impl KpiGradient {
    fn colors(self) -> (Color32, Color32) {
        match self {
            Self::Cyan => (GRAD_CYAN_A, GRAD_CYAN_B),
            Self::Gold => (GRAD_GOLD_A, GRAD_GOLD_B),
            Self::Pink => (GRAD_PINK_A, GRAD_PINK_B),
            Self::Orange => (Color32::from_rgb(251, 146, 60), Color32::from_rgb(234, 88, 12)),
            Self::Violet => (Color32::from_rgb(167, 139, 250), Color32::from_rgb(124, 58, 237)),
        }
    }
}

pub fn kpi_card(ui: &mut Ui, title: &str, value: &str, hint: &str, grad: KpiGradient) {
    kpi_card_sized(ui, title, value, hint, grad, 118.0, 28.0, 16.0);
}

pub fn kpi_card_compact(ui: &mut Ui, title: &str, value: &str, hint: &str, grad: KpiGradient) {
    kpi_card_sized(ui, title, value, hint, grad, 78.0, 22.0, 11.0);
}

fn kpi_card_sized(
    ui: &mut Ui,
    title: &str,
    value: &str,
    hint: &str,
    grad: KpiGradient,
    h: f32,
    value_px: f32,
    pad: f32,
) {
    let w = ui.available_width();
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, h), Sense::hover());
    let (a, b) = grad.colors();
    vertical_gradient(ui.painter(), rect, a, b);
    ui.painter().rect(
        rect,
        Rounding::same(RADIUS_LG),
        Color32::TRANSPARENT,
        Stroke::new(1.0, Color32::from_black_alpha(40)),
    );
    let inner = rect.shrink(pad);
    ui.painter().text(
        inner.left_top() + Vec2::new(0.0, 2.0),
        Align2::LEFT_TOP,
        title,
        font_display(12.0),
        Color32::from_white_alpha(230),
    );
    ui.painter().text(
        inner.left_top() + Vec2::new(0.0, value_px * 0.55),
        Align2::LEFT_TOP,
        value,
        font_display(value_px),
        TEXT,
    );
    ui.painter().text(
        inner.left_bottom(),
        Align2::LEFT_BOTTOM,
        hint,
        font_display(10.0),
        Color32::from_white_alpha(180),
    );
}

pub fn search_field(ui: &mut Ui, hint: &str) {
    let w = ui.available_width();
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, CTRL_H), Sense::hover());
    ui.painter().rect(
        rect,
        Rounding::same(RADIUS_PILL),
        INPUT,
        Stroke::new(1.0, BORDER),
    );
    ui.painter().text(
        rect.left_center() + Vec2::new(16.0, 0.0),
        Align2::LEFT_CENTER,
        hint,
        FontId::proportional(13.0),
        MUTED2,
    );
}

pub fn section_heading(ui: &mut Ui, title: &str, script_accent: Option<&str>) {
    ui.horizontal(|ui| {
        ui.label(
            egui::RichText::new(title)
                .size(22.0)
                .strong()
                .color(TEXT),
        );
        if let Some(script) = script_accent {
            ui.label(
                egui::RichText::new(script)
                    .size(22.0)
                    .italics()
                    .color(ACCENT_PURPLE),
            );
        }
    });
}

pub fn yellow_button(ui: &mut Ui, label: &str, width: f32) -> bool {
    ui.add_sized(
        [width, CTRL_H],
        egui::Button::new(
            egui::RichText::new(label)
                .strong()
                .color(BTN_YELLOW_TEXT),
        )
        .fill(BTN_YELLOW)
        .rounding(Rounding::same(RADIUS_MD)),
    )
    .clicked()
}

pub fn dark_button(ui: &mut Ui, label: &str, width: f32) -> bool {
    ui.add_sized(
        [width, CTRL_H],
        egui::Button::new(egui::RichText::new(label).color(TEXT))
            .fill(INPUT)
            .stroke(Stroke::new(1.0, BORDER))
            .rounding(Rounding::same(RADIUS_MD)),
    )
    .clicked()
}

pub fn browse_field(ui: &mut Ui, hint: &str, path: &str, width: f32) -> bool {
    let label = if path.is_empty() {
        hint.to_string()
    } else {
        crate::truncate_middle(path, 48)
    };
    ui.add_sized(
        [width, CTRL_H],
        egui::Button::new(
            egui::RichText::new(format!("📁  {label}"))
                .size(12.5)
                .color(TEXT),
        )
        .fill(INPUT)
        .stroke(Stroke::new(1.0, BORDER))
        .rounding(Rounding::same(RADIUS_MD)),
    )
    .clicked()
}

pub fn nav_icon(ui: &mut Ui, icon: &str, active: bool) -> egui::Response {
    let size = 44.0;
    let (rect, resp) = ui.allocate_exact_size(Vec2::splat(size), Sense::click());
    let fill = if active { CARD_SOFT } else { Color32::TRANSPARENT };
    let stroke = if active {
        Stroke::new(1.5, ACCENT_PURPLE)
    } else {
        Stroke::NONE
    };
    ui.painter()
        .rect(rect, Rounding::same(12.0), fill, stroke);
    ui.painter().text(
        rect.center(),
        Align2::CENTER_CENTER,
        icon,
        FontId::proportional(18.0),
        if active { TEXT } else { MUTED },
    );
    resp
}

pub fn service_tag(ui: &mut Ui, name: &str) {
    service_tag_colored(ui, name, CARD_SOFT, MUTED, 11.0);
}

pub fn service_tag_compact(ui: &mut Ui, name: &str) {
    service_tag_colored(ui, name, CARD_SOFT, MUTED, 10.0);
}

pub fn service_tag_colored(
    ui: &mut Ui,
    name: &str,
    fill: Color32,
    text: Color32,
    text_px: f32,
) {
    ui.add(
        egui::Button::new(
            egui::RichText::new(name)
                .font(font_display(text_px))
                .color(text),
        )
        .fill(fill)
        .stroke(Stroke::new(1.0, fill.gamma_multiply(0.55)))
        .rounding(Rounding::same(10.0)),
    );
}

pub fn metric_row(ui: &mut Ui, label: &str, value: &str, delta: Option<&str>, value_color: Color32) {
    ui.horizontal(|ui| {
        ui.label(
            egui::RichText::new(label)
                .size(13.0)
                .color(MUTED),
        );
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if let Some(d) = delta {
                ui.label(egui::RichText::new(d).size(11.0).color(SUCCESS));
            }
            ui.label(
                egui::RichText::new(value)
                    .size(15.0)
                    .strong()
                    .color(value_color),
            );
        });
    });
    ui.add_space(6.0);
}

pub fn visitor_bar(ui: &mut Ui, label: &str, value: &str, fraction: f32, color: Color32) {
    ui.label(
        egui::RichText::new(label)
            .size(12.0)
            .color(MUTED),
    );
    ui.horizontal(|ui| {
        ui.label(
            egui::RichText::new(value)
                .strong()
                .color(TEXT),
        );
    });
    let w = ui.available_width();
    let h = 8.0;
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, h + 6.0), Sense::hover());
    let track = rect.shrink2(Vec2::new(0.0, 3.0));
    ui.painter()
        .rect_filled(track, Rounding::same(h), INPUT);
    let fill_w = track.width() * fraction.clamp(0.0, 1.0);
    if fill_w > 1.0 {
        ui.painter().rect_filled(
            Rect::from_min_size(track.min, Vec2::new(fill_w, track.height())),
            Rounding::same(h),
            color,
        );
    }
    ui.add_space(8.0);
}

pub fn live_performance_panel(ui: &mut Ui, app: &PmaApp, stats: &Stats) {
    panel_card_frame().show(ui, |ui| {
        live_performance_body(ui, app, stats, true);
    });
}

pub(crate) fn live_performance_body(ui: &mut Ui, app: &PmaApp, stats: &Stats, compact: bool) {
    if compact {
        live_performance_minimal(ui, app, stats);
        return;
    }
    ui.label(
        egui::RichText::new("Live performance")
            .size(16.0)
            .strong()
            .color(TEXT),
    );
    ui.add_space(8.0);
    let cpm = app.run_analytics.current_cpm();
    let peak = app.run_analytics.peak_cpm().max(1.0);
    let hit = stats.hit_rate_pct();
    ui.columns(4, |cols| {
        mini_ring(
            &mut cols[0],
            "CPM",
            &format!("{cpm:.0}"),
            (cpm / peak).clamp(0.0, 1.0),
            ACCENT_CYAN,
            compact,
        );
        mini_ring(
            &mut cols[1],
            "Hit rate",
            &format!("{hit:.0}%"),
            hit / 100.0,
            ACCENT_PURPLE,
            compact,
        );
        cols[2].vertical(|ui| {
            metric_row(ui, "Peak CPM", &format!("{peak:.0}"), None, TEXT);
            metric_row(
                ui,
                "In flight",
                &app.checks_in_flight.to_string(),
                None,
                if app.checks_in_flight > 0 {
                    BTN_YELLOW
                } else {
                    MUTED
                },
            );
        });
        cols[3].vertical(|ui| {
            let p = stats.progress_pct() / 100.0;
            visitor_bar(
                ui,
                "Run progress",
                &format!("{:.0}%", stats.progress_pct()),
                p,
                ACCENT_PURPLE,
            );
        });
    });
    ui.add_space(if compact { 2.0 } else { 6.0 });
    ui.columns(2, |cols| {
        sparkline(
            &mut cols[0],
            app.run_analytics.samples(),
            ACCENT_CYAN,
            "CPM trend",
            compact,
        );
        sparkline(
            &mut cols[1],
            app.run_analytics.hit_rate_samples(),
            ACCENT_PURPLE,
            "Hit rate trend",
            compact,
        );
    });
}

fn live_performance_minimal(ui: &mut Ui, app: &PmaApp, stats: &Stats) {
    let cpm = app.run_analytics.current_cpm();
    let peak = app.run_analytics.peak_cpm().max(1.0);
    let hit = stats.hit_rate_pct();
    ui.horizontal(|ui| {
        ui.label(
            egui::RichText::new("Live")
                .font(font_display(12.0))
                .color(TEXT),
        );
        ui.add_space(6.0);
        stat_inline(ui, "CPM", &format!("{cpm:.0}"), ACCENT_CYAN);
        stat_inline(ui, "Hit", &format!("{hit:.0}%"), ACCENT_PURPLE);
        stat_inline(ui, "Peak", &format!("{peak:.0}"), MUTED);
        stat_inline(
            ui,
            "Flight",
            &app.checks_in_flight.to_string(),
            if app.checks_in_flight > 0 {
                BTN_YELLOW
            } else {
                MUTED
            },
        );
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let w = ui.available_width().min(200.0);
            let p = stats.progress_pct() / 100.0;
            ui.label(
                egui::RichText::new(format!("{:.0}%", stats.progress_pct()))
                    .size(10.0)
                    .color(MUTED),
            );
            let h = 6.0;
            let (rect, _) = ui.allocate_exact_size(Vec2::new(w, h), Sense::hover());
            ui.painter().rect_filled(rect, Rounding::same(h), INPUT);
            let fill_w = rect.width() * p.clamp(0.0, 1.0);
            if fill_w > 0.5 {
                ui.painter().rect_filled(
                    Rect::from_min_size(rect.min, Vec2::new(fill_w, rect.height())),
                    Rounding::same(h),
                    ACCENT_PURPLE,
                );
            }
        });
    });
}

fn stat_inline(ui: &mut Ui, label: &str, value: &str, color: Color32) {
    ui.label(
        egui::RichText::new(format!("{label} "))
            .size(10.0)
            .color(MUTED),
    );
    ui.label(
        egui::RichText::new(value)
            .size(11.0)
            .strong()
            .color(color),
    );
    ui.add_space(10.0);
}

fn mini_ring(ui: &mut Ui, label: &str, value: &str, pct: f32, color: Color32, compact: bool) {
    let size = if compact { 52.0 } else { 76.0 };
    let (rect, _) = ui.allocate_exact_size(Vec2::splat(size), Sense::hover());
    let c = rect.center();
    let r = size * 0.34;
    ui.painter()
        .circle_stroke(c, r, Stroke::new(6.0, INPUT));
    if pct > 0.01 {
        use std::f32::consts::TAU;
        let start = -TAU / 4.0;
        let steps = 48;
        let end = start + TAU * pct;
        let mut prev = None;
        for i in 0..=steps {
            let t = start + (end - start) * (i as f32 / steps as f32);
            let p = c + r * Vec2::new(t.cos(), t.sin());
            if let Some(p0) = prev {
                ui.painter().line_segment([p0, p], Stroke::new(6.0, color));
            }
            prev = Some(p);
        }
    }
    ui.painter().text(
        c,
        Align2::CENTER_CENTER,
        value,
        FontId::proportional(13.0),
        TEXT,
    );
    ui.label(
        egui::RichText::new(label)
            .small()
            .color(MUTED),
    );
}

fn sparkline(ui: &mut Ui, samples: &[f32], color: Color32, title: &str, compact: bool) {
    ui.label(
        egui::RichText::new(title)
            .small()
            .strong()
            .color(MUTED),
    );
    let w = ui.available_width();
    let h = if compact { 36.0 } else { 64.0 };
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, h), Sense::hover());
    ui.painter().rect_filled(rect, Rounding::same(10.0), INPUT);
    if samples.len() < 2 {
        ui.painter().text(
            rect.center(),
            Align2::CENTER_CENTER,
            "Run to chart",
            FontId::proportional(10.0),
            MUTED2,
        );
        return;
    }
    let max = samples.iter().copied().fold(1.0_f32, f32::max).max(0.01);
    let n = samples.len();
    let mut prev = None;
    for (i, v) in samples.iter().enumerate() {
        let t = i as f32 / (n - 1).max(1) as f32;
        let x = rect.left() + rect.width() * t;
        let y = rect.bottom() - rect.height() * (v / max).clamp(0.0, 1.0);
        let p = Pos2::new(x, y);
        if let Some(p0) = prev {
            ui.painter().line_segment([p0, p], Stroke::new(2.0, color));
        }
        prev = Some(p);
    }
}
