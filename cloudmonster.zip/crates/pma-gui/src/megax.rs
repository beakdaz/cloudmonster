//! CloudMonster by Leakbase — gradient dark UI kit (orange accent, soft module boxes).

pub const BRAND_WINDOW_TITLE: &str = "CloudMonster by Leakbase";
const BRAND_NAME: &str = "CloudMonster";
const BRAND_TAGLINE: &str = "by Leakbase";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MegaxProxyProtocol {
    #[default]
    Http,
    Socks5,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MegaxProxyLineFormat {
    #[default]
    HostPort,
    UserPassAtHostPort,
}

/// How checker traffic uses proxies (CloudMonster).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MegaxProxyMode {
    /// Rotate proxies from the selected proxy file.
    #[default]
    ProxyFile,
    /// Use only the single proxy field (no file rotation).
    Single,
    /// Direct connection — no proxy for check / download / upload.
    Direct,
}

impl MegaxProxyMode {
    pub fn label(self) -> &'static str {
        match self {
            Self::ProxyFile => "Proxy file (rotate)",
            Self::Single => "Single proxy",
            Self::Direct => "No proxy (direct)",
        }
    }
}

impl MegaxProxyProtocol {
    pub fn label(self) -> &'static str {
        match self {
            Self::Http => "HTTP",
            Self::Socks5 => "SOCKS5",
        }
    }

    pub fn to_net(self) -> pma_net::ProxyListScheme {
        match self {
            Self::Http => pma_net::ProxyListScheme::Http,
            Self::Socks5 => pma_net::ProxyListScheme::Socks5,
        }
    }
}

impl MegaxProxyLineFormat {
    pub fn label(self) -> &'static str {
        match self {
            Self::HostPort => "ip:port",
            Self::UserPassAtHostPort => "user:pass@ip:port",
        }
    }

    pub fn to_net(self) -> pma_net::ProxyListFormat {
        match self {
            Self::HostPort => pma_net::ProxyListFormat::HostPort,
            Self::UserPassAtHostPort => pma_net::ProxyListFormat::UserPassAtHostPort,
        }
    }
}

use super::{
    format_logs_for_clipboard, harmony, truncate_middle, work_mode_label, PmaApp, Stats, WorkMode,
    WORK_MODES,
};
use crate::megax_profiles;
use crate::megax_session;
use eframe::egui::{self, Align2, Color32, FontId, Frame, Pos2, Rounding, Sense, Shadow, Stroke, Ui, Vec2};
use pma_core::CloudProvider;
use std::f32::consts::TAU;

/// Window / central backdrop (gradient-ui-kit dark).
pub const BG: Color32 = Color32::from_rgb(26, 26, 30);
pub const PANEL: Color32 = Color32::from_rgb(32, 32, 36);
pub const CARD: Color32 = Color32::from_rgb(37, 37, 40);
pub const ACCENT: Color32 = Color32::from_rgb(255, 159, 10);
pub const ACCENT_DIM: Color32 = Color32::from_rgb(210, 120, 8);
pub const CYAN: Color32 = ACCENT;
pub const CYAN_DIM: Color32 = Color32::from_rgb(255, 190, 90);
pub const PURPLE: Color32 = Color32::from_rgb(255, 130, 50);
pub const TEXT: Color32 = Color32::from_rgb(245, 245, 247);
pub const MUTED: Color32 = Color32::from_rgb(140, 140, 148);
pub const GREEN: Color32 = Color32::from_rgb(120, 220, 150);
pub const RED: Color32 = Color32::from_rgb(255, 110, 100);

const BORDER_GLASS: Color32 = Color32::from_rgb(52, 52, 58);
const BORDER_ACTIVE: Color32 = ACCENT;
const BORDER_HI: Color32 = Color32::from_rgb(62, 62, 68);
const BORDER_SHADOW: Color32 = Color32::from_rgb(18, 18, 22);
pub const MODULE_FILL: Color32 = Color32::from_rgb(28, 28, 32);
const INPUT_FILL: Color32 = Color32::from_rgb(22, 22, 26);
const ON_ACCENT_TEXT: Color32 = Color32::from_rgb(22, 22, 24);

const SIDEBAR_W: f32 = 196.0;
const BOTTOM_H: f32 = 46.0;
const PANEL_ROUND: f32 = 18.0;
const MODULE_ROUND: f32 = 14.0;
const CARD_ROUND: f32 = PANEL_ROUND;
const PILL_ROUND: f32 = 999.0;
const CENTRAL_MARGIN: f32 = 10.0;
const LOG_DRAWER_EXPANDED_W: f32 = 300.0;
const LOG_DRAWER_COLLAPSED_W: f32 = 34.0;
/// Rolling CPM samples (1 Hz while a run is active).
#[derive(Default)]
pub(crate) struct RunAnalytics {
    cpm_samples: Vec<f32>,
    hit_rate_samples: Vec<f32>,
    last_sample: Option<std::time::Instant>,
    last_checked: usize,
}

impl RunAnalytics {
    pub fn reset(&mut self) {
        self.cpm_samples.clear();
        self.hit_rate_samples.clear();
        self.last_sample = None;
        self.last_checked = 0;
    }

    pub fn tick(&mut self, checked: usize, hit_rate_pct: f32, running: bool) {
        if !running && self.cpm_samples.is_empty() && self.hit_rate_samples.is_empty() {
            return;
        }
        let now = std::time::Instant::now();
        let sample_due = match self.last_sample {
            None => true,
            Some(t) => t.elapsed() >= std::time::Duration::from_secs(1),
        };
        if !sample_due {
            return;
        }
        let delta = checked.saturating_sub(self.last_checked);
        let cpm = delta as f32 * 60.0;
        self.cpm_samples.push(cpm);
        self.hit_rate_samples.push(hit_rate_pct.clamp(0.0, 100.0));
        const MAX_SAMPLES: usize = 180;
        for buf in [&mut self.cpm_samples, &mut self.hit_rate_samples] {
            if buf.len() > MAX_SAMPLES {
                let drop = buf.len() - MAX_SAMPLES;
                buf.drain(0..drop);
            }
        }
        self.last_checked = checked;
        self.last_sample = Some(now);
    }

    pub fn current_cpm(&self) -> f32 {
        if self.cpm_samples.is_empty() {
            return 0.0;
        }
        let n = self.cpm_samples.len().min(15);
        let slice = &self.cpm_samples[self.cpm_samples.len() - n..];
        slice.iter().sum::<f32>() / n as f32
    }

    pub fn peak_cpm(&self) -> f32 {
        self.cpm_samples.iter().copied().fold(0.0_f32, f32::max)
    }

    pub fn samples(&self) -> &[f32] {
        &self.cpm_samples
    }

    pub fn hit_rate_samples(&self) -> &[f32] {
        &self.hit_rate_samples
    }
}

fn paint_megax_backdrop(ctx: &egui::Context) {
    let rect = ctx.input(|i| i.screen_rect());
    if rect.width() <= 0.0 || rect.height() <= 0.0 {
        return;
    }
    ctx.layer_painter(egui::LayerId::background())
        .rect_filled(rect, 0.0, BG);
}

fn kit_shadow() -> Shadow {
    Shadow {
        offset: Vec2::new(0.0, 4.0),
        blur: 14.0,
        spread: 0.0,
        color: Color32::from_black_alpha(72),
    }
}

fn paint_raised_edge(painter: &egui::Painter, rect: egui::Rect, rounding: f32) {
    let r = Rounding::same(rounding);
    painter.rect_stroke(
        rect.shrink(0.5),
        r,
        Stroke::new(1.0, BORDER_HI),
    );
    let bottom = egui::Rect::from_min_max(
        Pos2::new(rect.left() + rounding, rect.bottom() - 1.5),
        Pos2::new(rect.right() - rounding, rect.bottom()),
    );
    painter.rect_filled(bottom, Rounding::ZERO, Color32::from_black_alpha(28));
}

fn paint_recessed_well(painter: &egui::Painter, rect: egui::Rect, rounding: f32) {
    painter.rect(
        rect,
        Rounding::same(rounding),
        INPUT_FILL,
        Stroke::new(1.0, BORDER_SHADOW),
    );
    painter.line_segment(
        [
            Pos2::new(rect.left() + rounding * 0.5, rect.top() + 1.0),
            Pos2::new(rect.right() - rounding * 0.5, rect.top() + 1.0),
        ],
        Stroke::new(1.0, Color32::from_black_alpha(90)),
    );
}

fn paint_arc(
    painter: &egui::Painter,
    center: Pos2,
    radius: f32,
    stroke: Stroke,
    start: f32,
    end: f32,
) {
    let steps = ((end - start).abs() * radius * 0.35).clamp(12.0, 72.0) as usize;
    let mut prev: Option<Pos2> = None;
    for i in 0..=steps {
        let t = start + (end - start) * (i as f32 / steps as f32);
        let p = center + radius * Vec2::new(t.cos(), t.sin());
        if let Some(p0) = prev {
            painter.line_segment([p0, p], stroke);
        }
        prev = Some(p);
    }
}

fn paint_circular_stat(ui: &mut Ui, label: &str, pct: f32, value: &str, size: f32) {
    let pct = pct.clamp(0.0, 1.0);
    let (rect, _) = ui.allocate_exact_size(Vec2::splat(size), Sense::hover());
    let center = rect.center();
    let radius = size * 0.36;
    let stroke_w = 7.0;
    let track = Color32::from_rgb(20, 20, 24);
    ui.painter()
        .circle_stroke(center, radius, Stroke::new(stroke_w, track));
    if pct > 0.001 {
        let start = -TAU / 4.0;
        let end = start + TAU * pct;
        paint_arc(
            ui.painter(),
            center,
            radius,
            Stroke::new(stroke_w, ACCENT),
            start,
            end,
        );
    }
    ui.painter().text(
        center,
        egui::Align2::CENTER_CENTER,
        value,
        egui::FontId::proportional(13.0),
        ACCENT,
    );
    ui.label(
        egui::RichText::new(label)
            .small()
            .color(MUTED),
    );
}

fn paint_linear_progress(ui: &mut Ui, label: &str, fraction: f32) {
    let fraction = fraction.clamp(0.0, 1.0);
    ui.label(egui::RichText::new(label).small().color(MUTED));
    let w = ui.available_width().max(60.0);
    let track_h = 10.0;
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, track_h + 4.0), Sense::hover());
    let track = rect.shrink2(Vec2::new(0.0, 2.0));
    paint_recessed_well(ui.painter(), track, track_h * 0.5);
    if fraction > 0.0 {
        let fill = egui::Rect::from_min_size(
            track.min,
            Vec2::new(track.width() * fraction, track.height()),
        );
        ui.painter().rect(
            fill,
            Rounding::same(track_h * 0.5),
            ACCENT,
            Stroke::NONE,
        );
    }
}

fn kit_toggle(ui: &mut Ui, on: &mut bool, text: &str) -> egui::Response {
    ui.horizontal(|ui| {
        let (rect, response) = ui.allocate_exact_size(Vec2::new(46.0, 24.0), Sense::click());
        if response.clicked() {
            *on = !*on;
        }
        let track = if *on { ACCENT } else { INPUT_FILL };
        let stroke = if *on {
            Stroke::new(1.0, ACCENT_DIM)
        } else {
            Stroke::new(1.0, BORDER_SHADOW)
        };
        ui.painter().rect(rect, Rounding::same(12.0), track, stroke);
        let handle_r = 8.0;
        let hx = if *on {
            rect.right() - handle_r - 4.0
        } else {
            rect.left() + handle_r + 4.0
        };
        ui.painter().circle_filled(
            Pos2::new(hx, rect.center().y),
            handle_r,
            if *on { ON_ACCENT_TEXT } else { MUTED },
        );
        ui.add_space(8.0);
        ui.label(egui::RichText::new(text).size(12.0).color(TEXT));
        response
    })
    .inner
}

fn info_box(ui: &mut Ui, text: &str, accent: Color32) {
    Frame::none()
        .fill(MODULE_FILL)
        .stroke(Stroke::new(1.0, BORDER_GLASS))
        .rounding(Rounding::same(MODULE_ROUND))
        .inner_margin(egui::Margin::symmetric(10.0, 8.0))
        .show(ui, |ui| {
            ui.horizontal(|ui| {
                let (bar, _) = ui.allocate_exact_size(Vec2::new(3.0, 14.0), Sense::hover());
                ui.painter().rect_filled(bar, Rounding::same(2.0), accent);
                ui.add_space(8.0);
                ui.label(egui::RichText::new(text).small().color(accent));
            });
        });
}

fn panel_shell_frame() -> Frame {
    Frame::none()
        .fill(PANEL)
        .stroke(Stroke::new(1.0, BORDER_GLASS))
        .rounding(Rounding::same(PANEL_ROUND))
        .shadow(kit_shadow())
        .inner_margin(egui::Margin::same(10.0))
}

fn paint_metric_sparkline(
    ui: &mut Ui,
    samples: &[f32],
    height: f32,
    line_color: Color32,
    empty_hint: &str,
    fixed_max: Option<f32>,
) {
    use egui::{Pos2, Sense, Stroke};
    let w = ui.available_width().max(80.0);
    let (rect, _) = ui.allocate_exact_size(egui::vec2(w, height), Sense::hover());
    paint_recessed_well(ui.painter(), rect, MODULE_ROUND);
    if samples.len() < 2 {
        ui.painter().text(
            rect.center(),
            egui::Align2::CENTER_CENTER,
            empty_hint,
            egui::FontId::proportional(10.0),
            MUTED,
        );
        return;
    }
    let max = fixed_max.unwrap_or_else(|| samples.iter().copied().fold(1.0_f32, f32::max));
    let max = max.max(0.01);
    let n = samples.len();
    let mut prev: Option<Pos2> = None;
    for (i, &v) in samples.iter().enumerate() {
        let t = if n <= 1 {
            0.0
        } else {
            i as f32 / (n - 1) as f32
        };
        let x = rect.left() + rect.width() * t;
        let y = rect.bottom() - rect.height() * (v / max).clamp(0.0, 1.0);
        let p = Pos2::new(x, y);
        if let Some(p0) = prev {
            ui.painter().line_segment([p0, p], Stroke::new(1.8, line_color));
        }
        prev = Some(p);
    }
}

pub(crate) fn live_analytics_card(ui: &mut Ui, app: &PmaApp, stats: &Stats) {
    card_frame_show(ui, |ui| {
        card_title(ui, "Live performance");
        let cpm = app.run_analytics.current_cpm();
        let peak = app.run_analytics.peak_cpm().max(1.0);
        let hit = stats.hit_rate_pct();
        ui.horizontal(|ui| {
            ui.vertical(|ui| {
                paint_circular_stat(
                    ui,
                    "CPM",
                    (cpm / peak).clamp(0.0, 1.0),
                    &format!("{cpm:.0}"),
                    88.0,
                );
            });
            ui.add_space(12.0);
            ui.vertical(|ui| {
                paint_circular_stat(
                    ui,
                    "Hit rate",
                    hit / 100.0,
                    &format!("{hit:.0}%"),
                    88.0,
                );
            });
            ui.add_space(16.0);
            ui.vertical(|ui| {
                stat_chip(ui, "Peak CPM", format!("{peak:.0}"), CYAN_DIM);
                stat_chip(
                    ui,
                    "In flight",
                    format!("{}", app.checks_in_flight),
                    if app.checks_in_flight > 0 { ACCENT } else { MUTED },
                );
            });
        });
        ui.add_space(10.0);
        paint_linear_progress(ui, "Run progress", stats.progress_pct() / 100.0);
        ui.add_space(8.0);
        ui.columns(2, |cols| {
            cols[0].vertical(|ui| {
                ui.label(egui::RichText::new("CPM trend").small().strong().color(ACCENT));
                paint_metric_sparkline(
                    ui,
                    app.run_analytics.samples(),
                    72.0,
                    ACCENT,
                    "Run to chart CPM",
                    None,
                );
            });
            cols[1].vertical(|ui| {
                ui.label(
                    egui::RichText::new("Hit rate trend")
                        .small()
                        .strong()
                        .color(CYAN_DIM),
                );
                paint_metric_sparkline(
                    ui,
                    app.run_analytics.hit_rate_samples(),
                    72.0,
                    PURPLE,
                    "Run to chart hits",
                    Some(100.0),
                );
            });
        });
        ui.label(
            egui::RichText::new("Sampled every 1s while a run is active (rolling ~3 min)")
                .small()
                .color(MUTED),
        );
    });
}

fn stat_chip(ui: &mut Ui, label: &str, value: String, color: Color32) {
    ui.vertical(|ui| {
        ui.label(egui::RichText::new(label).small().color(MUTED));
        ui.label(egui::RichText::new(value).size(18.0).strong().color(color));
    });
    ui.add_space(16.0);
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum MegaxNav {
    Checker,
    Platforms,
    Settings,
    Uploader,
    Accounts,
    Help,
    Export,
}

impl MegaxNav {
    fn label(self) -> &'static str {
        match self {
            Self::Checker => "Checker",
            Self::Platforms => "Platforms",
            Self::Settings => "Settings",
            Self::Uploader => "Uploader",
            Self::Accounts => "Results",
            Self::Help => "Help",
            Self::Export => "Export",
        }
    }

    fn icon(self) -> &'static str {
        match self {
            Self::Checker => ">",
            Self::Platforms => "☰",
            Self::Settings => "*",
            Self::Uploader => "^",
            Self::Accounts => "@",
            Self::Help => "?",
            Self::Export => "#",
        }
    }
}


pub fn apply(ctx: &egui::Context) {
    egui_extras::install_image_loaders(ctx);
    harmony::apply(ctx);
    let mut visuals = (*ctx.style()).visuals.clone();
    visuals.panel_fill = PANEL;
    visuals.window_fill = BG;
    visuals.extreme_bg_color = BG;
    visuals.widgets.inactive.bg_fill = INPUT_FILL;
    visuals.widgets.inactive.bg_stroke = Stroke::new(1.0, BORDER_SHADOW);
    visuals.widgets.inactive.fg_stroke = Stroke::new(1.0, TEXT);
    visuals.widgets.inactive.rounding = Rounding::same(MODULE_ROUND);
    visuals.widgets.hovered.bg_fill = MODULE_FILL;
    visuals.widgets.hovered.bg_stroke = Stroke::new(1.0, BORDER_GLASS);
    visuals.widgets.hovered.fg_stroke = Stroke::new(1.0, TEXT);
    visuals.widgets.active.bg_fill = Color32::from_rgba_unmultiplied(255, 159, 10, 40);
    visuals.widgets.active.bg_stroke = Stroke::new(1.0, ACCENT);
    visuals.widgets.active.fg_stroke = Stroke::new(1.0, ACCENT);
    visuals.widgets.noninteractive.bg_fill = MODULE_FILL;
    visuals.widgets.noninteractive.fg_stroke = Stroke::new(1.0, TEXT);
    visuals.override_text_color = Some(TEXT);
    visuals.selection.bg_fill = Color32::from_rgba_unmultiplied(255, 159, 10, 48);
    ctx.set_visuals(visuals);
}

fn card_frame() -> Frame {
    Frame::none()
        .fill(CARD)
        .stroke(Stroke::new(1.0, BORDER_GLASS))
        .rounding(Rounding::same(CARD_ROUND))
        .shadow(kit_shadow())
        .inner_margin(egui::Margin::symmetric(14.0, 12.0))
}

fn card_frame_show(ui: &mut Ui, add_contents: impl FnOnce(&mut Ui)) {
    let response = card_frame().show(ui, add_contents);
    if ui.is_rect_visible(response.response.rect) {
        paint_raised_edge(ui.painter(), response.response.rect, CARD_ROUND);
    }
}

fn card_title(ui: &mut Ui, title: &str) {
    ui.horizontal(|ui| {
        let (bar, _) = ui.allocate_exact_size(Vec2::new(4.0, 18.0), Sense::hover());
        ui.painter().rect_filled(bar, Rounding::same(2.0), ACCENT);
        ui.add_space(10.0);
        ui.label(
            egui::RichText::new(title)
                .size(14.0)
                .strong()
                .color(TEXT),
        );
    });
    ui.add_space(8.0);
    let w = ui.available_width();
    if w > 1.0 {
        let left = ui.cursor().left();
        let y = ui.cursor().top();
        ui.painter().line_segment(
            [Pos2::new(left, y), Pos2::new(left + w, y)],
            Stroke::new(1.0, BORDER_GLASS),
        );
        ui.add_space(8.0);
    }
}

fn field_label(ui: &mut Ui, text: &str) {
    ui.label(egui::RichText::new(text).size(12.0).color(MUTED));
    ui.add_space(4.0);
}

pub(crate) fn browse_row(ui: &mut Ui, hint: &str, path: String, on_click: impl FnOnce()) {
    let label = if path.is_empty() {
        hint.to_string()
    } else {
        truncate_middle(&path, 42)
    };
    if ui
        .add_sized(
            [ui.available_width(), 32.0],
            egui::Button::new(
                egui::RichText::new(format!("[..] {label}"))
                    .size(12.0)
                    .color(TEXT),
            )
            .fill(INPUT_FILL)
            .stroke(Stroke::new(1.0, BORDER_SHADOW))
            .rounding(Rounding::same(PILL_ROUND)),
        )
        .clicked()
    {
        on_click();
    }
}

fn logo_widget(max_h: f32) -> egui::Image<'static> {
    egui::Image::new(egui::include_image!("../assets/app_logo.png")).max_height(max_h)
}

fn brand_sidebar(ui: &mut Ui) {
    ui.horizontal(|ui| {
        ui.add(logo_widget(40.0));
        ui.add_space(10.0);
        ui.vertical(|ui| {
            ui.label(egui::RichText::new(BRAND_NAME).size(17.0).strong().color(TEXT));
            ui.label(egui::RichText::new(BRAND_TAGLINE).size(11.0).color(MUTED));
        });
    });
}

fn brand_title_leading(ui: &mut Ui) {
    ui.add(logo_widget(22.0));
    ui.add_space(8.0);
}

fn nav_button(ui: &mut Ui, nav: MegaxNav, active: MegaxNav) -> bool {
    let selected = nav == active;
    let fill = if selected {
        Color32::from_rgba_unmultiplied(255, 159, 10, 36)
    } else {
        MODULE_FILL
    };
    let stroke = if selected {
        Stroke::new(1.0, ACCENT)
    } else {
        Stroke::new(1.0, BORDER_GLASS)
    };
    let resp = ui.add_sized(
        [ui.available_width(), 40.0],
        egui::Button::new(
            egui::RichText::new(format!("{}  {}", nav.icon(), nav.label()))
                .size(13.0)
                .color(if selected { ACCENT } else { MUTED }),
        )
        .fill(fill)
        .stroke(stroke)
        .rounding(Rounding::same(MODULE_ROUND)),
    );
    resp.clicked()
}

pub fn update(app: &mut PmaApp, ctx: &egui::Context) {
    let stats = Stats::from_results(&app.scan_results, app.target_count.max(app.scan_results.len()));
    app.run_analytics.tick(stats.checked(), stats.hit_rate_pct(), app.busy);

    paint_megax_backdrop(ctx);
    harmony::title_bar_with_leading(ctx, BRAND_WINDOW_TITLE, brand_title_leading);

    egui::TopBottomPanel::bottom("megax_actions")
        .exact_height(BOTTOM_H)
        .frame(
            Frame::none()
                .fill(PANEL)
                .stroke(Stroke::new(1.0, BORDER_GLASS))
                .shadow(kit_shadow())
                .inner_margin(egui::Margin::symmetric(16.0, 8.0)),
        )
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                let w = 120.0;
                if app.busy {
                    if ui
                        .add_sized(
                            [w, 36.0],
                            egui::Button::new(egui::RichText::new("Stop").color(ACCENT))
                                .fill(MODULE_FILL)
                                .stroke(Stroke::new(1.0, ACCENT))
                                .rounding(Rounding::same(PILL_ROUND)),
                        )
                        .on_hover_text("Request stop; waits until workers finish current step")
                        .clicked()
                    {
                        app.stop_work();
                    }
                    if ui
                        .add_sized(
                            [w + 24.0, 36.0],
                            egui::Button::new(egui::RichText::new("Force stop").color(RED))
                                .fill(INPUT_FILL)
                                .stroke(Stroke::new(1.0, RED.linear_multiply(0.7)))
                                .rounding(Rounding::same(PILL_ROUND)),
                        )
                        .on_hover_text("Cancel immediately and unlock Start (no password)")
                        .clicked()
                    {
                        app.megax_force_stop();
                    }
                } else if ui
                    .add_sized(
                        [w, 36.0],
                        egui::Button::new(egui::RichText::new("Start").color(ON_ACCENT_TEXT))
                            .fill(ACCENT)
                            .stroke(Stroke::new(1.0, ACCENT_DIM))
                            .rounding(Rounding::same(PILL_ROUND)),
                    )
                    .clicked()
                {
                    app.start_work();
                }
                if ui
                    .add_sized(
                        [w, 36.0],
                        egui::Button::new(egui::RichText::new("Reset").color(MUTED))
                            .fill(INPUT_FILL)
                            .stroke(Stroke::new(1.0, BORDER_SHADOW))
                            .rounding(Rounding::same(PILL_ROUND)),
                    )
                    .clicked()
                {
                    app.megax_reset();
                }
                let log_label = if app.log_expanded {
                    "Log ◀"
                } else {
                    "Log ▶"
                };
                if ui
                    .add_sized(
                        [72.0, 36.0],
                        egui::Button::new(egui::RichText::new(log_label).size(12.0).color(MUTED))
                            .fill(INPUT_FILL)
                            .stroke(Stroke::new(1.0, BORDER_SHADOW))
                            .rounding(Rounding::same(PILL_ROUND)),
                    )
                    .on_hover_text("Show / hide side log panel")
                    .clicked()
                {
                    app.log_expanded = !app.log_expanded;
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if app.busy {
                        ui.spinner();
                    }
                    ui.label(
                        egui::RichText::new(format!(
                            "CPM {:.0} | Hit {:.1}% | OK {} | Bad {} | Err {} | {}",
                            app.run_analytics.current_cpm(),
                            stats.hit_rate_pct(),
                            stats.valid,
                            stats.invalid,
                            stats.errors,
                            app.elapsed_public()
                        ))
                        .size(12.0)
                        .color(MUTED),
                    );
                });
            });
        });

    megax_log_side_drawer(app, ctx);

    egui::SidePanel::left("megax_sidebar")
        .exact_width(SIDEBAR_W)
        .resizable(false)
        .frame(panel_shell_frame())
        .show(ctx, |ui| {
            brand_sidebar(ui);
            ui.add_space(10.0);
            for item in [
                MegaxNav::Checker,
                MegaxNav::Platforms,
                MegaxNav::Settings,
                MegaxNav::Uploader,
                MegaxNav::Accounts,
                MegaxNav::Help,
                MegaxNav::Export,
            ] {
                if nav_button(ui, item, app.megax_nav) {
                    app.megax_nav = item;
                }
                ui.add_space(4.0);
            }
            ui.with_layout(egui::Layout::bottom_up(egui::Align::LEFT), |ui| {
                ui.label(egui::RichText::new("Version 1.5.1").small().color(MUTED));
                let online = app.megax_session.logged_in;
                let dot = if online { GREEN } else { MUTED };
                let status = if online { "Online" } else { "Offline" };
                ui.horizontal(|ui| {
                    ui.painter().circle_filled(ui.cursor().min + egui::vec2(4.0, 8.0), 4.0, dot);
                    ui.add_space(12.0);
                    ui.label(egui::RichText::new(status).small().color(dot));
                });
                ui.label(
                    egui::RichText::new(app.megax_session.license_label())
                        .small()
                        .color(MUTED),
                );
                ui.label(
                    egui::RichText::new(app.megax_session.login_label())
                        .small()
                        .color(if online { TEXT } else { MUTED }),
                );
            });
        });

    egui::CentralPanel::default()
        .frame(Frame::none().fill(BG).inner_margin(egui::Margin::same(CENTRAL_MARGIN)))
        .show(ctx, |ui| {
            egui::ScrollArea::vertical()
                .auto_shrink([false; 2])
                .show(ui, |ui| {
                    match app.megax_nav {
                        MegaxNav::Checker => checker_page(app, ui, &stats),
                        MegaxNav::Platforms => platforms_page(app, ui),
                        MegaxNav::Settings => settings_page(app, ui),
                        MegaxNav::Uploader => uploader_page(app, ui),
                        MegaxNav::Accounts => results_page(app, ui, &stats),
                        MegaxNav::Help => help_page(ui),
                        MegaxNav::Export => export_page(app, ui),
                    }
                });
        });
}

fn cloud_account_file_help(ui: &mut Ui) {
    ui.collapsing("Format & services", |ui| {
        ui.label(
            egui::RichText::new("One line: email:password (MEGA: also email password; ':' allowed after @).")
                .small()
                .color(MUTED),
        );
        ui.label(
            egui::RichText::new(format!("Checkers: {}", cloud_checker_ready_names()))
                .small()
                .color(CYAN_DIM),
        );
    });
}

fn cloud_ready_checkers_blurb(ui: &mut Ui) {
    ui.label(
        egui::RichText::new("Combo file: one line — email:password (same as Checker).")
            .small()
            .color(MUTED),
    );
    ui.add_space(4.0);
    ui.label(
        egui::RichText::new(format!("Ready checkers: {}", cloud_checker_ready_names()))
            .small()
            .color(CYAN_DIM),
    );
}

fn selected_cloud_account_hint(ui: &mut Ui, provider: CloudProvider) {
    let msg = if provider == CloudProvider::BoxCom {
        format!(
            "{} — email:password или box:TOKEN / box:refresh:TOKEN (+ BOX_OAUTH_* для refresh).",
            provider.label()
        )
    } else if provider == CloudProvider::Riseup {
        format!(
            "{} — user:password или user@riseup.net:password (account.riseup.net, затем webmail).",
            provider.label()
        )
    } else if provider == CloudProvider::Mobidrive {
        format!(
            "{} — не email:password. Combo: email:mobidrive:ACCOUNT_ID:CONNECT_TOKEN или email:mobidrive:jwt:JWT (DevTools → Application → localStorage на mobidrive.com).",
            provider.label()
        )
    } else {
        format!(
            "{} — checker ready; load accounts as email:password above.",
            provider.label()
        )
    };
    info_box(ui, &msg, GREEN);
}

fn cloud_provider_short_label(provider: CloudProvider) -> &'static str {
    match provider {
        CloudProvider::Mega => "MEGA.nz",
        CloudProvider::Filen => "Filen",
        CloudProvider::Degoo => "Degoo",
        CloudProvider::Mediafire => "MediaFire",
        CloudProvider::FourShared => "4shared",
        CloudProvider::Blomp => "Blomp",
        CloudProvider::Filesfm => "Files.fm",
        CloudProvider::Adrive => "ADrive",
        CloudProvider::Terabox => "TeraBox",
        CloudProvider::PixelDrain => "PixelDrain",
        CloudProvider::Raindrop => "Raindrop",
        CloudProvider::InternXt => "InternXt",
        CloudProvider::Remnote => "RemNote",
        CloudProvider::OneDrive => "OneDrive",
        CloudProvider::Wps => "WPS Drive",
        CloudProvider::SyncCom => "Sync.com",
        CloudProvider::Acronis => "Acronis",
        CloudProvider::ZohoNotes => "Zoho Notes",
        CloudProvider::Obsidian => "Obsidian",
        CloudProvider::NimbusNotes => "Nimbus",
        CloudProvider::Dynalist => "Dynalist",
        CloudProvider::Capacities => "Capacities",
        CloudProvider::Gnotes => "GNotes",
        CloudProvider::Joplin => "Joplin",
        CloudProvider::Kortex => "Kortex",
        CloudProvider::Mindlog => "Mindlog",
        CloudProvider::Notejoy => "Notejoy",
        CloudProvider::Notesnook => "Notesnook",
        CloudProvider::StandardNotes => "Std Notes",
        CloudProvider::Todoist => "Todoist",
        CloudProvider::Turtl => "Turtl",
        CloudProvider::Zotero => "Zotero",
        CloudProvider::ProtonDrive => "Proton Drive",
        CloudProvider::Koofr => "Koofr",
        CloudProvider::Upnote => "UpNote",
        CloudProvider::BoxCom => "Box.com",
        CloudProvider::Fex => "FEX.net",
        CloudProvider::FileIo => "file.io",
        CloudProvider::Icedrive => "Icedrive",
        CloudProvider::Mobidrive => "MobiDrive",
        CloudProvider::SecureShare => "SecureShare",
        CloudProvider::ToffeeShare => "ToffeeShare",
        CloudProvider::Workupload => "WorkUpload",
        CloudProvider::Pcloud => "pCloud",
        CloudProvider::Riseup => "Riseup",
    }
}

fn cloud_checker_ready_names() -> String {
    CloudProvider::ALL
        .into_iter()
        .filter(|p| p.is_checker_ready())
        .map(cloud_provider_short_label)
        .collect::<Vec<_>>()
        .join(" · ")
}

struct CloudBrand {
    emoji: &'static str,
    accent: Color32,
}

fn cloud_provider_brand(provider: CloudProvider) -> CloudBrand {
    match provider {
        CloudProvider::Mega => CloudBrand {
            emoji: "◆",
            accent: Color32::from_rgb(211, 45, 58),
        },
        CloudProvider::Filen => CloudBrand {
            emoji: "📁",
            accent: Color32::from_rgb(88, 166, 255),
        },
        CloudProvider::Degoo => CloudBrand {
            emoji: "☁",
            accent: Color32::from_rgb(0, 168, 255),
        },
        CloudProvider::Mediafire => CloudBrand {
            emoji: "🔥",
            accent: Color32::from_rgb(255, 130, 0),
        },
        CloudProvider::FourShared => CloudBrand {
            emoji: "4",
            accent: Color32::from_rgb(76, 175, 80),
        },
        CloudProvider::Blomp => CloudBrand {
            emoji: "🌸",
            accent: Color32::from_rgb(236, 64, 122),
        },
        CloudProvider::Filesfm => CloudBrand {
            emoji: "📂",
            accent: Color32::from_rgb(255, 193, 7),
        },
        CloudProvider::Adrive => CloudBrand {
            emoji: "A",
            accent: Color32::from_rgb(33, 150, 243),
        },
        CloudProvider::Terabox => CloudBrand {
            emoji: "📦",
            accent: Color32::from_rgb(66, 133, 244),
        },
        CloudProvider::PixelDrain => CloudBrand {
            emoji: "⬇",
            accent: Color32::from_rgb(156, 39, 176),
        },
        CloudProvider::Raindrop => CloudBrand {
            emoji: "💧",
            accent: Color32::from_rgb(0, 188, 212),
        },
        CloudProvider::InternXt => CloudBrand {
            emoji: "🔒",
            accent: Color32::from_rgb(103, 58, 183),
        },
        CloudProvider::Remnote => CloudBrand {
            emoji: "📝",
            accent: Color32::from_rgb(63, 81, 181),
        },
        CloudProvider::OneDrive => CloudBrand {
            emoji: "☁",
            accent: Color32::from_rgb(0, 120, 215),
        },
        CloudProvider::Wps => CloudBrand {
            emoji: "W",
            accent: Color32::from_rgb(229, 57, 53),
        },
        CloudProvider::SyncCom => CloudBrand {
            emoji: "⟳",
            accent: Color32::from_rgb(0, 150, 136),
        },
        CloudProvider::Acronis => CloudBrand {
            emoji: "🛡",
            accent: Color32::from_rgb(0, 96, 100),
        },
        CloudProvider::ZohoNotes => CloudBrand {
            emoji: "📓",
            accent: Color32::from_rgb(226, 88, 34),
        },
        CloudProvider::Obsidian => CloudBrand {
            emoji: "◆",
            accent: Color32::from_rgb(124, 77, 255),
        },
        CloudProvider::NimbusNotes => CloudBrand {
            emoji: "✎",
            accent: Color32::from_rgb(3, 169, 244),
        },
        CloudProvider::Dynalist
        | CloudProvider::Capacities
        | CloudProvider::Gnotes
        | CloudProvider::Joplin
        | CloudProvider::Kortex
        | CloudProvider::Mindlog
        | CloudProvider::Notejoy
        | CloudProvider::Notesnook
        | CloudProvider::StandardNotes
        | CloudProvider::Todoist
        | CloudProvider::Turtl
        | CloudProvider::Zotero => CloudBrand {
            emoji: "📒",
            accent: Color32::from_rgb(126, 87, 194),
        },
        CloudProvider::ProtonDrive => CloudBrand {
            emoji: "🔐",
            accent: Color32::from_rgb(109, 74, 255),
        },
        CloudProvider::Koofr => CloudBrand {
            emoji: "K",
            accent: Color32::from_rgb(255, 87, 34),
        },
        CloudProvider::Upnote => CloudBrand {
            emoji: "U",
            accent: Color32::from_rgb(255, 193, 7),
        },
        CloudProvider::BoxCom => CloudBrand {
            emoji: "▣",
            accent: Color32::from_rgb(0, 102, 204),
        },
        CloudProvider::Fex => CloudBrand {
            emoji: "F",
            accent: Color32::from_rgb(244, 67, 54),
        },
        CloudProvider::FileIo => CloudBrand {
            emoji: "📄",
            accent: Color32::from_rgb(96, 125, 139),
        },
        CloudProvider::Icedrive => CloudBrand {
            emoji: "❄",
            accent: Color32::from_rgb(3, 155, 229),
        },
        CloudProvider::Mobidrive => CloudBrand {
            emoji: "M",
            accent: Color32::from_rgb(63, 81, 181),
        },
        CloudProvider::SecureShare => CloudBrand {
            emoji: "🔒",
            accent: Color32::from_rgb(76, 175, 80),
        },
        CloudProvider::ToffeeShare => CloudBrand {
            emoji: "🍬",
            accent: Color32::from_rgb(255, 152, 0),
        },
        CloudProvider::Workupload => CloudBrand {
            emoji: "↑",
            accent: Color32::from_rgb(121, 85, 72),
        },
        CloudProvider::Pcloud => CloudBrand {
            emoji: "P",
            accent: Color32::from_rgb(255, 193, 7),
        },
        CloudProvider::Riseup => CloudBrand {
            emoji: "✊",
            accent: Color32::from_rgb(183, 28, 28),
        },
    }
}

fn cloud_provider_icon(provider: CloudProvider) -> &'static str {
    cloud_provider_brand(provider).emoji
}

const CLOUD_TILE_W: f32 = 176.0;
const CLOUD_TILE_H: f32 = 82.0;

fn cloud_platform_tile(ui: &mut Ui, provider: CloudProvider, selected: bool) -> egui::Response {
    let brand = cloud_provider_brand(provider);
    let title = cloud_provider_short_label(provider);
    let tip = provider.label();
    let fill = if selected {
        Color32::from_rgba_unmultiplied(255, 159, 10, 36)
    } else {
        MODULE_FILL
    };
    let stroke = if selected {
        Stroke::new(1.5, ACCENT)
    } else {
        Stroke::new(1.0, BORDER_GLASS)
    };
    let (rect, response) = ui.allocate_exact_size(
        Vec2::new(CLOUD_TILE_W, CLOUD_TILE_H),
        Sense::click(),
    );
    if ui.is_rect_visible(rect) {
        let painter = ui.painter();
        painter.rect(rect, Rounding::same(MODULE_ROUND), fill, stroke);
        let badge_c = Pos2::new(rect.center().x, rect.top() + 26.0);
        painter.circle_filled(badge_c, 17.0, brand.accent);
        painter.text(
            badge_c,
            Align2::CENTER_CENTER,
            brand.emoji,
            FontId::proportional(15.0),
            Color32::WHITE,
        );
        painter.text(
            Pos2::new(rect.center().x, rect.bottom() - 16.0),
            Align2::CENTER_CENTER,
            title,
            FontId::proportional(11.5),
            if selected { ACCENT } else { TEXT },
        );
    }
    response.on_hover_text(tip)
}

fn work_mode_icon(mode: WorkMode) -> &'static str {
    match mode {
        WorkMode::PhpMyAdmin => "🐬",
        WorkMode::Adminer => "🗄",
        WorkMode::GitLab => "🦊",
        WorkMode::Jenkins => "⚙",
        WorkMode::PhpPgAdmin => "🐘",
        WorkMode::Bitrix => "B",
        WorkMode::Bitbucket => "🪣",
        WorkMode::Jira => "📋",
        WorkMode::Redmine => "🔴",
        WorkMode::Snowflake => "❄",
        WorkMode::Confluence => "📘",
        WorkMode::OpenCart => "🛒",
        WorkMode::Workflowy => "📝",
        WorkMode::RoamResearch => "🧠",
        WorkMode::SecondBrain => "💡",
        WorkMode::AppFlowy => "📋",
        WorkMode::Obsidian => "◆",
        WorkMode::Dynalist => "📋",
        WorkMode::Capacities => "🗂",
        WorkMode::Gnotes => "📒",
        WorkMode::Joplin => "📓",
        WorkMode::Kortex => "🌀",
        WorkMode::Mindlog => "🧩",
        WorkMode::Notejoy => "✨",
        WorkMode::Notesnook => "🔏",
        WorkMode::StandardNotes => "🛡",
        WorkMode::Todoist => "✓",
        WorkMode::Turtl => "🐢",
        WorkMode::Zotero => "📚",
        WorkMode::NoteCheck => "📝",
        WorkMode::XWiki => "📖",
        WorkMode::Bamboo => "🎋",
        WorkMode::Slack => "💬",
        WorkMode::Fortinet => "🛡",
        WorkMode::Citrix => "🖥",
        WorkMode::Mega => "☁",
        WorkMode::Owa => "📧",
        WorkMode::Kibana => "📊",
        WorkMode::Zabbix => "📈",
        WorkMode::Zimbra => "✉",
        WorkMode::Drupal => "🌐",
        WorkMode::Grafana => "📉",
        WorkMode::SonarQube => "🔍",
        WorkMode::Mattermost => "💭",
        WorkMode::CrmCheck => "📇",
        WorkMode::AdminPanel => "🎛",
    }
}

fn platform_tile(
    ui: &mut Ui,
    icon: &str,
    title: &str,
    subtitle: &str,
    selected: bool,
) -> egui::Response {
    let fill = if selected {
        Color32::from_rgba_unmultiplied(255, 159, 10, 32)
    } else {
        MODULE_FILL
    };
    let stroke = if selected {
        Stroke::new(1.5, ACCENT)
    } else {
        Stroke::new(1.0, BORDER_GLASS)
    };
    ui.add_sized(
        [136.0, 72.0],
        egui::Button::new(
            egui::RichText::new(format!("{icon}\n{title}"))
                .size(13.0)
                .color(if selected { ACCENT } else { CYAN_DIM }),
        )
        .fill(fill)
        .stroke(stroke)
        .rounding(Rounding::same(MODULE_ROUND)),
    )
    .on_hover_text(subtitle)
}

fn platforms_page(app: &mut PmaApp, ui: &mut Ui) {
    if app.fixed_mode.is_none() {
        card_frame_show(ui, |ui| {
            card_title(ui, "Pipeline module");
            ui.label(
                egui::RichText::new("Select export / scan backend for this session.")
                    .small()
                    .color(MUTED),
            );
            ui.add_space(8.0);
            egui::Grid::new("mx_work_modes")
                .spacing([8.0, 8.0])
                .show(ui, |ui| {
                    let mut col = 0;
                    for (mode, _label) in WORK_MODES {
                        let selected = app.work_mode == mode;
                        let subtitle = work_mode_label(mode);
                        if platform_tile(
                            ui,
                            work_mode_icon(mode),
                            truncate_middle(subtitle, 14).as_str(),
                            subtitle,
                            selected,
                        )
                        .clicked()
                        {
                            app.work_mode = mode;
                        }
                        col += 1;
                        if col % 4 == 0 {
                            ui.end_row();
                        }
                    }
                });
        });
        ui.add_space(8.0);
    }

    let show_cloud = app.fixed_mode == Some(WorkMode::Mega) || app.work_mode == WorkMode::Mega;
    if show_cloud {
        card_frame_show(ui, |ui| {
            card_title(ui, "Cloud platforms");
            ui.label(
                egui::RichText::new(format!(
                    "Active: {} {}",
                    cloud_provider_icon(app.cloud_provider),
                    app.cloud_provider.label()
                ))
                .color(GREEN),
            );
            ui.add_space(8.0);
            egui::Grid::new("mx_cloud_providers")
                .spacing([10.0, 10.0])
                .show(ui, |ui| {
                    let mut col = 0;
                    for provider in CloudProvider::ALL {
                        let selected = app.cloud_provider == provider;
                        let mut resp = cloud_platform_tile(ui, provider, selected);
                        if app.fixed_cloud_provider.is_some() {
                            resp = resp.on_hover_text("Provider locked for this app");
                        } else if resp.clicked() {
                            app.cloud_provider = provider;
                        }
                        col += 1;
                        if col % 4 == 0 {
                            ui.end_row();
                        }
                    }
                });
            ui.add_space(6.0);
            cloud_ready_checkers_blurb(ui);
        });
    } else {
        card_frame_show(ui, |ui| {
            card_title(ui, "Cloud platforms");
            ui.label(
                egui::RichText::new("Switch pipeline to «☁ Cloud storage» to enable cloud checkers.")
                    .small()
                    .color(MUTED),
            );
        });
    }
}

fn checker_page(app: &mut PmaApp, ui: &mut Ui, stats: &Stats) {
    live_analytics_card(ui, app, stats);
    ui.add_space(8.0);
    ui.columns(2, |cols| {
        cols[0].vertical(|ui| {
            card_frame_show(ui, |ui| {
                card_title(ui, "File Selection");
                field_label(ui, "Account File (email:password)");
                cloud_account_file_help(ui);
                browse_row(ui, "Select Account File", app.input_file.clone(), || app.pick_input_file());
                ui.add_space(6.0);
                let show_proxy_file = app.megax_proxy_mode == MegaxProxyMode::ProxyFile;
                ui.add_enabled_ui(show_proxy_file, |ui| {
                    field_label(ui, "Proxy File");
                    browse_row(ui, "Select Proxy File", app.proxy_list_file.clone(), || {
                        app.pick_proxy_list_file()
                    });
                });
            });
            ui.add_space(8.0);
            card_frame_show(ui, |ui| {
                card_title(ui, "Proxy Configuration");
                field_label(ui, "Proxy mode");
                egui::ComboBox::from_id_salt("mx_proxy_mode")
                    .selected_text(app.megax_proxy_mode.label())
                    .show_ui(ui, |ui| {
                        for mode in [
                            MegaxProxyMode::ProxyFile,
                            MegaxProxyMode::Single,
                            MegaxProxyMode::Direct,
                        ] {
                            if ui
                                .selectable_label(app.megax_proxy_mode == mode, mode.label())
                                .clicked()
                            {
                                app.megax_proxy_mode = mode;
                            }
                        }
                    });
                ui.add_space(6.0);
                let proxy_details = app.megax_proxy_mode != MegaxProxyMode::Direct;
                ui.add_enabled_ui(proxy_details, |ui| {
                    ui.horizontal(|ui| {
                        ui.vertical(|ui| {
                            field_label(ui, "Protocol");
                            egui::ComboBox::from_id_salt("mx_proto")
                                .selected_text(app.megax_proxy_protocol.label())
                                .show_ui(ui, |ui| {
                                    for proto in [MegaxProxyProtocol::Http, MegaxProxyProtocol::Socks5] {
                                        if ui
                                            .selectable_label(
                                                app.megax_proxy_protocol == proto,
                                                proto.label(),
                                            )
                                            .clicked()
                                        {
                                            app.megax_proxy_protocol = proto;
                                        }
                                    }
                                });
                        });
                        ui.add_space(12.0);
                        ui.vertical(|ui| {
                            field_label(ui, "Format");
                            egui::ComboBox::from_id_salt("mx_fmt")
                                .selected_text(app.megax_proxy_line_format.label())
                                .show_ui(ui, |ui| {
                                    for fmt in [
                                        MegaxProxyLineFormat::HostPort,
                                        MegaxProxyLineFormat::UserPassAtHostPort,
                                    ] {
                                        if ui
                                            .selectable_label(
                                                app.megax_proxy_line_format == fmt,
                                                fmt.label(),
                                            )
                                            .clicked()
                                        {
                                            app.megax_proxy_line_format = fmt;
                                        }
                                    }
                                });
                        });
                    });
                    ui.add_space(6.0);
                    kit_toggle(
                        ui,
                        &mut app.megax_skip_proxy_precheck,
                        "Huge Proxy Amount (skip pre-check)",
                    );
                    kit_toggle(
                        ui,
                        &mut app.megax_auto_fetch_proxies,
                        "Auto-fetch proxies from URL",
                    );
                    field_label(ui, "Proxy List URL");
                    ui.add(
                        egui::TextEdit::singleline(&mut app.megax_proxy_list_url)
                            .hint_text("https://...")
                            .desired_width(f32::INFINITY),
                    );
                    ui.horizontal(|ui| {
                        field_label(ui, "Update Interval (minutes)");
                        ui.add(egui::DragValue::new(&mut app.megax_proxy_interval_min).range(1..=120));
                    });
                    ui.add_space(6.0);
                    let show_single = app.megax_proxy_mode == MegaxProxyMode::Single;
                    ui.add_enabled_ui(show_single, |ui| {
                        field_label(ui, "Single proxy");
                        ui.add(
                            egui::TextEdit::singleline(&mut app.proxy)
                                .hint_text(match app.megax_proxy_protocol {
                                    MegaxProxyProtocol::Http => "http://127.0.0.1:8080",
                                    MegaxProxyProtocol::Socks5 => "socks5://127.0.0.1:1080",
                                })
                                .desired_width(f32::INFINITY),
                        );
                    });
                });
                if app.megax_proxy_mode == MegaxProxyMode::Direct {
                    ui.label(
                        egui::RichText::new("Checker uses your direct IP — proxy file and URL are ignored.")
                            .small()
                            .color(MUTED),
                    );
                }
            });
        });
        cols[1].vertical(|ui| {
            card_frame_show(ui, |ui| {
                card_title(ui, "Checker Mode");
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(format!(
                            "{} {}",
                            cloud_provider_icon(app.cloud_provider),
                            app.cloud_provider.label()
                        ))
                        .strong()
                        .color(TEXT),
                    );
                    if ui
                        .small_button("Change…")
                        .on_hover_text("Open Platforms tab")
                        .clicked()
                    {
                        app.megax_nav = MegaxNav::Platforms;
                    }
                });
                selected_cloud_account_hint(ui, app.cloud_provider);
                ui.label(
                    egui::RichText::new("Check account + inventory (Soderzhimoe folder)")
                        .small()
                        .color(MUTED),
                );
            });
            ui.add_space(8.0);
            card_frame_show(ui, |ui| {
                card_title(ui, "Auto Upload Settings");
                let mega_upload =
                    app.cloud_provider == CloudProvider::Mega && app.cloud_provider.supports_upload();
                kit_toggle(
                    ui,
                    &mut app.download_mega,
                    if mega_upload {
                        "Enable Auto Upload to Valid Accounts"
                    } else {
                        "Download / sync files from cloud when valid"
                    },
                );
                kit_toggle(ui, &mut app.megax_upload_no_proxy, "Upload Without Proxy")
                    .on_hover_text("Run without any proxy (same as Proxy mode → No proxy)");
                if mega_upload && app.download_mega {
                    field_label(ui, "Files to Upload");
                    browse_row(ui, "Select Files / Folder", app.mega_upload_dir.clone(), || {
                        app.pick_mega_upload_dir()
                    });
                }
            });
        });
    });

    ui.add_space(6.0);
    card_frame_show(ui, |ui| {
        egui::CollapsingHeader::new(
            egui::RichText::new("Download Settings")
                .size(13.0)
                .strong()
                .color(TEXT),
        )
        .default_open(false)
        .show(ui, |ui| {
            ui.columns(3, |cols| {
                cols[0].vertical(|ui| {
                    let mut no_dl = !app.download_mega;
                    if kit_toggle(ui, &mut no_dl, "No Download").changed() {
                        app.download_mega = !no_dl;
                    }
                    field_label(ui, "File Extensions");
                    ui.add(
                        egui::TextEdit::singleline(&mut app.cloud_filter_extensions)
                            .hint_text(".txt, .pdf, .doc, wallet")
                            .desired_width(f32::INFINITY),
                    );
                });
                cols[1].vertical(|ui| {
                    kit_toggle(ui, &mut app.megax_low_render, "Low Render (anti-lag)");
                    field_label(ui, "Max File Size");
                    ui.horizontal(|ui| {
                        ui.add(
                            egui::DragValue::new(&mut app.cloud_filter_max_mb)
                                .speed(1)
                                .range(0..=1_000_000),
                        );
                        ui.label(egui::RichText::new("MB").small().color(MUTED));
                    });
                    field_label(ui, "Keywords / ключевые слова");
                    ui.add(
                        egui::TextEdit::singleline(&mut app.cloud_filter_keywords)
                            .hint_text("seed, password, backup — через запятую")
                            .desired_width(f32::INFINITY),
                    );
                    ui.label(
                        egui::RichText::new(
                            "Фильтр «Содержимое» и скачивания: любое слово в пути/имени (без учёта регистра).",
                        )
                        .small()
                        .color(MUTED),
                    );
                });
                cols[2].vertical(|ui| {
                    kit_toggle(ui, &mut app.megax_download_no_proxy, "Download without proxy")
                        .on_hover_text("Run without any proxy (same as Proxy mode → No proxy)");
                    field_label(ui, "Min size (KB)");
                    ui.add(
                        egui::DragValue::new(&mut app.cloud_filter_min_kb)
                            .speed(1)
                            .range(0..=10_000_000),
                    );
                    field_label(ui, "Threads");
                    ui.add(egui::DragValue::new(&mut app.threads).range(1..=500));
                    ui.label(
                        egui::RichText::new(
                            "Speed: MEGAX_CURL_PARALLEL (default 32), MEGAX_CLOUD_LOGIN_PARALLEL, MEGAX_CLOUD_WORKERS_MAX.",
                        )
                        .small()
                        .color(MUTED),
                    );
                });
            });
        });
    });

}

fn settings_page(app: &mut PmaApp, ui: &mut Ui) {
    card_frame_show(ui, |ui| {
        card_title(ui, "Account (sidebar)");
        field_label(ui, "Login name");
        ui.add(
            egui::TextEdit::singleline(&mut app.megax_session.login_name)
                .hint_text("Display name in sidebar")
                .desired_width(ui.available_width()),
        );
        field_label(ui, "License until");
        ui.add(
            egui::TextEdit::singleline(&mut app.megax_session.license_until)
                .hint_text("e.g. 2026-12-31")
                .desired_width(ui.available_width()),
        );
        ui.add_space(4.0);
        ui.checkbox(&mut app.megax_session.logged_in, "Logged in (Online)");
        ui.add_space(6.0);
        if ui.button("Save session").clicked() {
            match megax_session::save(&app.megax_session) {
                Ok(()) => app.megax_profile_message = "Session saved (megax-session.json)".into(),
                Err(e) => app.megax_profile_message = e,
            }
        }
        ui.label(
            egui::RichText::new(format!(
                "File: {}",
                megax_session::session_path().display()
            ))
            .small()
            .color(MUTED),
        );
    });
    ui.add_space(8.0);
    card_frame_show(ui, |ui| {
        card_title(ui, "Profiles");
        field_label(ui, "Active profile");
        let names = app.megax_profile_store.profile_names();
        let active = app.megax_profile_store.active.clone();
        egui::ComboBox::from_id_salt("mx_profile_pick")
            .selected_text(active.as_str())
            .show_ui(ui, |ui| {
                for name in &names {
                    if ui.selectable_label(app.megax_profile_store.active == *name, name).clicked() {
                        app.megax_profile_apply_active(name);
                        app.megax_profile_message = format!("Loaded «{name}»");
                    }
                }
            });
        field_label(ui, "Name (save / add)");
        ui.horizontal(|ui| {
            ui.add(
                egui::TextEdit::singleline(&mut app.megax_profile_draft_name)
                    .hint_text("Profile name")
                    .desired_width(ui.available_width() - 280.0),
            );
            if ui.button("Save").on_hover_text("Overwrite or create profile").clicked() {
                let name = app.megax_profile_draft_name.clone();
                match app.megax_profile_save_current(&name) {
                    Ok(()) => app.megax_profile_message = format!("Saved «{name}»"),
                    Err(e) => app.megax_profile_message = e,
                }
            }
            if ui
                .button("+ New")
                .on_hover_text("Save current settings as a new profile")
                .clicked()
            {
                let base = app.megax_profile_draft_name.trim();
                let mut name = if base.is_empty() {
                    "Profile".to_string()
                } else {
                    base.to_string()
                };
                let mut n = 2;
                while app.megax_profile_store.profiles.contains_key(&name) {
                    name = format!("{base} {n}");
                    n += 1;
                }
                app.megax_profile_draft_name = name.clone();
                match app.megax_profile_save_current(&name) {
                    Ok(()) => app.megax_profile_message = format!("Added «{name}»"),
                    Err(e) => app.megax_profile_message = e,
                }
            }
            if ui.button("Delete").clicked() {
                let name = app.megax_profile_store.active.clone();
                match app.megax_profile_delete(&name) {
                    Ok(()) => app.megax_profile_message = format!("Deleted «{name}»"),
                    Err(e) => app.megax_profile_message = e,
                }
            }
        });
        if !app.megax_profile_message.is_empty() {
            ui.label(
                egui::RichText::new(&app.megax_profile_message)
                    .small()
                    .color(GREEN),
            );
        }
        ui.label(
            egui::RichText::new(format!(
                "File: {}",
                megax_profiles::store_path().display()
            ))
            .small()
            .color(MUTED),
        );
    });
    ui.add_space(8.0);
    card_frame_show(ui, |ui| {
        card_title(ui, "Settings");
        egui::Grid::new("mx_settings").num_columns(2).show(ui, |ui| {
            ui.label("Timeout (s):");
            ui.add(egui::DragValue::new(&mut app.timeout).range(5..=300));
            ui.end_row();
            ui.label("Export timeout (s):");
            ui.add(egui::DragValue::new(&mut app.export_timeout).range(10..=600));
            ui.end_row();
            ui.label("Retries:");
            ui.add(egui::DragValue::new(&mut app.retries).range(1..=10));
            ui.end_row();
        });
        kit_toggle(ui, &mut app.insecure, "Allow invalid TLS");
        ui.add_space(8.0);
        field_label(ui, "Output folder");
        browse_row(ui, "Browse output...", app.output_dir.clone(), || app.pick_output_dir());
    });
}

fn uploader_page(app: &mut PmaApp, ui: &mut Ui) {
    card_frame_show(ui, |ui| {
        card_title(ui, "Uploader");
        ui.label(
            egui::RichText::new("MEGA.nz upload from local folder on valid accounts.")
                .color(MUTED),
        );
        ui.add_space(8.0);
        browse_row(ui, "Upload folder", app.mega_upload_dir.clone(), || app.pick_mega_upload_dir());
    });
}

fn results_page(app: &mut PmaApp, ui: &mut Ui, stats: &Stats) {
    card_frame_show(ui, |ui| {
        card_title(ui, "Session results");
        ui.label(
            egui::RichText::new(
                "Accounts checked in the current run (cleared on Start / Reset). \
                 Hits are also written to text files in the output folder.",
            )
            .small()
            .color(MUTED),
        );
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            stat_chip(ui, "OK", format!("{}", stats.valid), GREEN);
            ui.add_space(8.0);
            stat_chip(ui, "Bad", format!("{}", stats.invalid), ACCENT_DIM);
            ui.add_space(8.0);
            stat_chip(ui, "Err", format!("{}", stats.errors), RED);
            ui.add_space(8.0);
            stat_chip(
                ui,
                "Progress",
                format!("{} / {}", stats.checked(), stats.total.max(stats.checked())),
                CYAN_DIM,
            );
        });
        ui.add_space(8.0);
        ui.horizontal(|ui| {
            if ui
                .button("Open output folder")
                .on_hover_text("Good.txt, Bad.txt, Errors.log, Содержимое")
                .clicked()
            {
                app.open_results_folder();
            }
            if ui.button("Clear list").on_hover_text("Clear in-memory results only").clicked() {
                app.megax_clear_results();
            }
        });
    });
    ui.add_space(8.0);
    card_frame_show(ui, |ui| {
        card_title(ui, "Output files (after run)");
        ui.label(
            egui::RichText::new(
                "Good.txt · Bad.txt · Error.txt · CantCheck.txt · Errors.log · folder «Содержимое»",
            )
            .small()
            .color(MUTED),
        );
        if !app.output_dir.trim().is_empty() {
            ui.add_space(4.0);
            browse_row(
                ui,
                "Output",
                app.output_dir.clone(),
                || app.pick_output_dir(),
            );
        }
    });
    ui.add_space(8.0);
    card_frame_show(ui, |ui| {
        card_title(ui, "Checked accounts");
        let results = app.scan_results_ref();
        if results.is_empty() {
            ui.label(
                egui::RichText::new("No results yet — run Checker with an account list.")
                    .small()
                    .color(MUTED),
            );
            return;
        }
        egui::ScrollArea::vertical()
            .max_height(320.0)
            .auto_shrink([false; 2])
            .show(ui, |ui| {
                for r in results.iter().rev().take(500) {
                    let line = r.credential.combo_line();
                    let status = r.status.label();
                    let color = match r.status {
                        pma_core::ScanStatus::Valid => GREEN,
                        pma_core::ScanStatus::InvalidCredentials
                        | pma_core::ScanStatus::NotPhpMyAdmin
                        | pma_core::ScanStatus::Captcha => ACCENT_DIM,
                        pma_core::ScanStatus::Unreachable | pma_core::ScanStatus::Error => RED,
                    };
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new(status).small().strong().color(color));
                        ui.label(
                            egui::RichText::new(truncate_middle(&line, 64))
                                .small()
                                .color(TEXT),
                        );
                    });
                }
            });
    });
}

const USER_MANUAL_MD: &str = include_str!("../../../docs/CLOUDMONSTER_USER_MANUAL.ru.md");

fn help_open_url(ui: &mut Ui, label: &str, url: &str) {
    ui.hyperlink_to(label, url);
}

fn open_embedded_user_manual() {
    let path = std::env::temp_dir().join("CloudMonster_USER_MANUAL.ru.md");
    if std::fs::write(&path, USER_MANUAL_MD).is_ok() {
        let path_str = path.to_string_lossy().to_string();
        #[cfg(windows)]
        {
            let _ = std::process::Command::new("cmd")
                .args(["/C", "start", "", &path_str])
                .spawn();
        }
        #[cfg(target_os = "macos")]
        {
            let _ = std::process::Command::new("open").arg(&path_str).spawn();
        }
        #[cfg(all(unix, not(target_os = "macos")))]
        {
            let _ = std::process::Command::new("xdg-open").arg(&path_str).spawn();
        }
    }
}

fn help_page(ui: &mut Ui) {
    card_frame_show(ui, |ui| {
        card_title(ui, "Справка и установка");
        ui.label(
            egui::RichText::new(
                "CloudMonster не требует Rust, Python или других SDK — только exe и компоненты ниже.",
            )
            .small()
            .color(MUTED),
        );
        ui.add_space(8.0);
        if ui
            .button("Открыть полное руководство (Markdown)")
            .on_hover_text("Файл откроется в редакторе по умолчанию (из встроенной копии)")
            .clicked()
        {
            open_embedded_user_manual();
        }
    });
    ui.add_space(8.0);

    card_frame_show(ui, |ui| {
        card_title(ui, "Что скачать (обязательно на Windows)");
        ui.label(
            egui::RichText::new("1. export-mega-gui.exe — положите в любую папку и запускайте.")
                .small()
                .color(TEXT),
        );
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new(
                "2. curl-impersonate — архив для Windows, распакуйте win\\bin (curl-impersonate.exe, curl_chrome110.bat, DLL).",
            )
            .small()
            .color(TEXT),
        );
        ui.horizontal(|ui| {
            help_open_url(
                ui,
                "Скачать curl-impersonate (GitHub Releases)",
                "https://github.com/lwthiker/curl-impersonate/releases",
            );
        });
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new(
                "3. Visual C++ Redistributable x64 — если exe не стартует или ругается на MSVCR.",
            )
            .small()
            .color(TEXT),
        );
        help_open_url(
            ui,
            "Microsoft VC++ Redistributable (x64)",
            "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
        );
    });
    ui.add_space(8.0);

    card_frame_show(ui, |ui| {
        card_title(ui, "Переменные окружения (curl-impersonate)");
        ui.label(
            egui::RichText::new("Укажите один из вариантов и перезапустите CloudMonster:")
                .small()
                .color(MUTED),
        );
        ui.add_space(6.0);
        ui.monospace("MEGA_CURL_ROOT=D:\\path\\curl-impersonate-2.2.3");
        ui.add_space(4.0);
        ui.monospace("MEGA_CURL_BIN=D:\\path\\...\\win\\bin\\curl_chrome110.bat");
        ui.add_space(4.0);
        ui.label(
            egui::RichText::new("Либо добавьте ...\\win\\bin в системный PATH.")
                .small()
                .color(MUTED),
        );
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new("Проверка в PowerShell:")
                .small()
                .color(MUTED),
        );
        ui.monospace(
            "& \"D:\\...\\win\\bin\\curl_chrome110.bat\" -I https://www.google.com",
        );
    });
    ui.add_space(8.0);

    card_frame_show(ui, |ui| {
        card_title(ui, "Быстрый старт");
        ui.label(
            egui::RichText::new("Platforms → облако · Checker → combo и папка вывода · Proxy mode → No proxy (direct) при тесте без прокси · Start.")
                .small()
                .color(TEXT),
        );
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new("Результаты: Good.txt, Bad.txt, Errors.log, папка «Содержимое». Список сессии — вкладка Results.")
                .small()
                .color(MUTED),
        );
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new("Профили: Settings → Profiles → %LOCALAPPDATA%\\CloudMonster\\profiles.json")
                .small()
                .color(MUTED),
        );
    });
    ui.add_space(8.0);

    card_frame_show(ui, |ui| {
        card_title(ui, "Полезные ссылки");
        help_open_url(ui, "Zoho — App-Specific Passwords", "https://accounts.zoho.com");
        ui.add_space(2.0);
        help_open_url(
            ui,
            "Zoho OAuth (справка, не для mass combo)",
            "https://www.zoho.com/developer/oauth/introduction.html",
        );
        ui.add_space(2.0);
        help_open_url(ui, "pCloud", "https://www.pcloud.com/");
        ui.add_space(2.0);
        help_open_url(
            ui,
            "Rust (только для сборки из исходников)",
            "https://rustup.rs/",
        );
    });
    ui.add_space(8.0);

    card_frame_show(ui, |ui| {
        card_title(ui, "Типичные ошибки");
        egui::Grid::new("help_errors_grid")
            .num_columns(2)
            .spacing([12.0, 6.0])
            .show(ui, |ui| {
                ui.label(egui::RichText::new("curl-impersonate / NETWORK").small().strong());
                ui.label(
                    egui::RichText::new("MEGA_CURL_ROOT, Direct, прокси")
                        .small()
                        .color(MUTED),
                );
                ui.end_row();
                ui.label(egui::RichText::new("Zoho invalid password").small().strong());
                ui.label(
                    egui::RichText::new("App-password для Notebook, не пароль почты")
                        .small()
                        .color(MUTED),
                );
                ui.end_row();
                ui.label(egui::RichText::new("exe не запускается").small().strong());
                ui.label(
                    egui::RichText::new("Установите VC++ Redistributable x64")
                        .small()
                        .color(MUTED),
                );
                ui.end_row();
            });
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new(
                "При багах: провайдер, Proxy mode, 1–2 строки Errors.log (без пароля), версия exe.",
            )
            .small()
            .color(MUTED),
        );
    });
}

fn export_page(app: &mut PmaApp, ui: &mut Ui) {
    card_frame_show(ui, |ui| {
        card_title(ui, "Export");
        browse_row(ui, "Output directory", app.output_dir.clone(), || app.pick_output_dir());
        if ui
            .button("Open results folder")
            .on_hover_text("Open last run output")
            .clicked()
        {
            app.open_results_folder();
        }
    });
}

fn megax_log_side_drawer(app: &mut PmaApp, ctx: &egui::Context) {
    let expanded = app.log_expanded && !app.megax_low_render;
    let width = if expanded {
        LOG_DRAWER_EXPANDED_W
    } else {
        LOG_DRAWER_COLLAPSED_W
    };

    egui::SidePanel::right("megax_log_drawer")
        .exact_width(width)
        .resizable(expanded)
        .frame(
            panel_shell_frame().inner_margin(egui::Margin::symmetric(6.0, 6.0)),
        )
        .show(ctx, |ui| {
            if !expanded {
                ui.vertical_centered_justified(|ui| {
                    if ui
                        .button(
                            egui::RichText::new("Log\n▶")
                                .small()
                                .color(MUTED),
                        )
                        .on_hover_text("Show log panel")
                        .clicked()
                    {
                        app.log_expanded = true;
                    }
                });
                return;
            }

            ui.horizontal(|ui| {
                if ui
                    .small_button("◀")
                    .on_hover_text("Hide log")
                    .clicked()
                {
                    app.log_expanded = false;
                }
                ui.label(egui::RichText::new("Log").strong().color(TEXT));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(
                        egui::RichText::new(format!("{}", app.logs.len()))
                            .small()
                            .color(MUTED),
                    );
                    if !app.logs.is_empty() {
                        if ui.small_button("Clear").clicked() {
                            app.logs.clear();
                        }
                        if ui.small_button("Copy").clicked() {
                            ui.ctx()
                                .copy_text(format_logs_for_clipboard(&app.logs));
                        }
                    }
                });
            });

            if app.megax_low_render && app.log_expanded {
                ui.label(
                    egui::RichText::new("Low Render — log hidden")
                        .italics()
                        .small()
                        .color(MUTED),
                );
                return;
            }

            ui.add_space(4.0);
            Frame::none()
                .fill(INPUT_FILL)
                .stroke(Stroke::new(1.0, BORDER_SHADOW))
                .rounding(Rounding::same(MODULE_ROUND))
                .inner_margin(egui::Margin::same(6.0))
                .show(ui, |ui| {
                    egui::ScrollArea::vertical()
                        .auto_shrink([false, false])
                        .stick_to_bottom(true)
                        .max_height(ui.available_height())
                        .show(ui, |ui| {
                            if app.logs.is_empty() {
                                ui.label(
                                    egui::RichText::new("Start — combo lines only")
                                        .italics()
                                        .small()
                                        .color(MUTED),
                                );
                                return;
                            }
                            ui.set_min_width(ui.available_width());
                            for e in &app.logs {
                                Frame::none()
                                    .fill(MODULE_FILL)
                                    .stroke(Stroke::new(1.0, BORDER_GLASS))
                                    .rounding(Rounding::same(10.0))
                                    .inner_margin(egui::Margin::symmetric(6.0, 4.0))
                                    .show(ui, |ui| {
                                        ui.horizontal(|ui| {
                                            ui.add(
                                                egui::Label::new(
                                                    egui::RichText::new(format!("[{}]", e.status))
                                                        .small()
                                                        .strong()
                                                        .color(megax_log_status_color(&e.status)),
                                                )
                                                .selectable(true),
                                            );
                                            ui.add(
                                                egui::Label::new(
                                                    egui::RichText::new(&e.text)
                                                        .small()
                                                        .color(TEXT),
                                                )
                                                .selectable(true)
                                                .wrap(),
                                            );
                                        });
                                    });
                                ui.add_space(4.0);
                            }
                        });
                });
        });
}

fn megax_log_status_color(status: &str) -> Color32 {
    match status {
        "Good" | "OK" | "Export" => GREEN,
        "NETWORK" => RED,
        "AUTH" | "FAIL" | "Error" | "Bad" => Color32::from_rgb(255, 180, 80),
        "Info" => MUTED,
        _ => TEXT,
    }
}
