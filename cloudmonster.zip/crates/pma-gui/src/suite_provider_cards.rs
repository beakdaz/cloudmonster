//! Card grid for Note Check / CRM Check provider selection.


use crate::sales_dashboard;

use egui::{Align2, Color32, FontId, Pos2, Rounding, Sense, Stroke, Ui, Vec2};

use pma_core::{CrmExportService, NoteExportService};



const TILE_W: f32 = 118.0;

const TILE_H: f32 = 72.0;

const ROUND: f32 = 10.0;

const GRID_GAP: f32 = 8.0;

const SECTION_LABEL_H: f32 = 22.0;



pub fn provider_strip_height(available_width: f32) -> f32 {

    let cols = column_count_expanded(available_width);

    let count = NoteExportService::ALL.len().max(CrmExportService::ALL.len());

    let rows = count.div_ceil(cols);

    SECTION_LABEL_H + rows as f32 * (TILE_H + GRID_GAP) + 4.0

}



pub fn note_provider_cards_expanded(ui: &mut Ui, current: &mut NoteExportService) {

    section_label(ui, "Note provider");

    card_grid_expanded(ui, "note_providers_exp", NoteExportService::ALL.len(), |ui, idx| {

        let service = NoteExportService::ALL[idx];

        tile_select(

            ui,

            note_icon(service),

            service.label(),

            service.output_slug(),

            *current == service,

            true,

            || *current = service,

        )

    });

}



pub fn crm_provider_cards_expanded(ui: &mut Ui, current: &mut CrmExportService) {

    section_label(ui, "CRM provider");

    card_grid_expanded(ui, "crm_providers_exp", CrmExportService::ALL.len(), |ui, idx| {

        let service = CrmExportService::ALL[idx];

        tile_select(

            ui,

            crm_icon(service),

            service.label(),

            service.output_slug(),

            *current == service,

            true,

            || *current = service,

        )

    });

}



fn section_label(ui: &mut Ui, title: &str) {

    ui.label(

        egui::RichText::new(title)

            .font(sales_dashboard::font_display(11.0))

            .color(sales_dashboard::MUTED),

    );

    ui.add_space(4.0);

}



fn card_grid_expanded(

    ui: &mut Ui,

    id: &str,

    count: usize,

    mut tile: impl FnMut(&mut Ui, usize),

) {

    ui.set_width(ui.available_width());

    let cols = column_count_expanded(ui.available_width());

    egui::Grid::new(id)

        .num_columns(cols)

        .spacing([GRID_GAP, GRID_GAP])

        .show(ui, |ui| {

            for i in 0..count {

                tile(ui, i);

                if (i + 1) % cols == 0 {

                    ui.end_row();

                }

            }

            if count % cols != 0 {

                ui.end_row();

            }

        });

}



fn column_count_expanded(available: f32) -> usize {

    ((available / (TILE_W + GRID_GAP)).floor() as usize).clamp(4, 9)

}



fn tile_select(

    ui: &mut Ui,

    icon: &str,

    title: &str,

    slug: &str,

    selected: bool,

    full_title: bool,

    mut on_click: impl FnMut(),

) {

    if provider_tile(ui, icon, title, slug, selected, full_title).clicked() {

        on_click();

    }

}



fn provider_tile(

    ui: &mut Ui,

    icon: &str,

    title: &str,

    slug: &str,

    selected: bool,

    full_title: bool,

) -> egui::Response {

    let fill = if selected {

        Color32::from_rgba_unmultiplied(167, 139, 250, 40)

    } else {

        sales_dashboard::INPUT

    };

    let stroke = if selected {

        Stroke::new(1.5, sales_dashboard::ACCENT_PURPLE)

    } else {

        Stroke::new(1.0, sales_dashboard::BORDER)

    };

    let (rect, response) = ui.allocate_exact_size(Vec2::new(TILE_W, TILE_H), Sense::click());

    if ui.is_rect_visible(rect) {

        let painter = ui.painter();

        painter.rect(rect, Rounding::same(ROUND), fill, stroke);

        painter.text(

            Pos2::new(rect.center().x, rect.top() + 22.0),

            Align2::CENTER_CENTER,

            icon,

            FontId::proportional(18.0),

            sales_dashboard::TEXT,

        );

        let title_short = if full_title {

            title.to_string()

        } else if title.len() > 14 {

            format!("{}…", &title[..13])

        } else {

            title.to_string()

        };

        painter.text(

            Pos2::new(rect.center().x, rect.bottom() - 22.0),

            Align2::CENTER_CENTER,

            title_short,

            sales_dashboard::font_display(10.5),

            if selected {

                sales_dashboard::ACCENT_CYAN

            } else {

                sales_dashboard::TEXT

            },

        );

        painter.text(

            Pos2::new(rect.center().x, rect.bottom() - 8.0),

            Align2::CENTER_CENTER,

            slug,

            FontId::proportional(9.0),

            sales_dashboard::MUTED,

        );

    }

    response.on_hover_text(title)

}



fn note_icon(s: NoteExportService) -> &'static str {

    use NoteExportService as N;

    match s {

        N::Obsidian => "◆",

        N::Dynalist => "≡",

        N::Capacities => "🗂",

        N::Gnotes => "📒",

        N::Joplin => "📓",

        N::Kortex => "🌀",

        N::Mindlog => "🧩",

        N::Notejoy => "✨",

        N::Notesnook => "🔏",

        N::StandardNotes => "🛡",

        N::Todoist => "✓",

        N::Turtl => "🐢",

        N::Zotero => "📚",

    }

}



fn crm_icon(s: CrmExportService) -> &'static str {

    use CrmExportService as C;

    match s {

        C::Trello => "📋",

        C::Hubspot => "🟠",

        C::Pipedrive => "🟢",

        C::Freshworks => "💠",

        C::Insightly => "🔵",

        C::Sugarcrm => "🍬",

        C::Sap => "🏢",

        C::Keap => "⚡",

        C::Nimble => "📇",

        C::Creatio => "◈",

        C::Monday => "📅",

        C::Clickup => "⬆",

        C::Salesforce => "☁",

    }

}


