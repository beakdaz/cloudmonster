//! WorkMode ↔ note-suite export service mapping.

use pma_core::NoteExportService;

use crate::WorkMode;

pub fn note_export_service_for_mode(mode: WorkMode) -> Option<NoteExportService> {
    Some(match mode {
        WorkMode::Obsidian => NoteExportService::Obsidian,
        WorkMode::Dynalist => NoteExportService::Dynalist,
        WorkMode::Capacities => NoteExportService::Capacities,
        WorkMode::Gnotes => NoteExportService::Gnotes,
        WorkMode::Joplin => NoteExportService::Joplin,
        WorkMode::Kortex => NoteExportService::Kortex,
        WorkMode::Mindlog => NoteExportService::Mindlog,
        WorkMode::Notejoy => NoteExportService::Notejoy,
        WorkMode::Notesnook => NoteExportService::Notesnook,
        WorkMode::StandardNotes => NoteExportService::StandardNotes,
        WorkMode::Todoist => NoteExportService::Todoist,
        WorkMode::Turtl => NoteExportService::Turtl,
        WorkMode::Zotero => NoteExportService::Zotero,
        _ => return None,
    })
}

pub fn work_mode_for_note_export(service: NoteExportService) -> WorkMode {
    match service {
        NoteExportService::Obsidian => WorkMode::Obsidian,
        NoteExportService::Dynalist => WorkMode::Dynalist,
        NoteExportService::Capacities => WorkMode::Capacities,
        NoteExportService::Gnotes => WorkMode::Gnotes,
        NoteExportService::Joplin => WorkMode::Joplin,
        NoteExportService::Kortex => WorkMode::Kortex,
        NoteExportService::Mindlog => WorkMode::Mindlog,
        NoteExportService::Notejoy => WorkMode::Notejoy,
        NoteExportService::Notesnook => WorkMode::Notesnook,
        NoteExportService::StandardNotes => WorkMode::StandardNotes,
        NoteExportService::Todoist => WorkMode::Todoist,
        NoteExportService::Turtl => WorkMode::Turtl,
        NoteExportService::Zotero => WorkMode::Zotero,
    }
}
