//! Shared Sales Dashboard shell for all export GUIs (fixed-mode + all-modes).
//! Same layout language as AdminPanel: KPI row, Session rail, Live strip, Run + Log.

use crate::sales_dashboard::{self, KpiGradient};
use crate::megax::{MegaxProxyLineFormat, MegaxProxyMode, MegaxProxyProtocol};
use crate::{work_mode_label, truncate_middle, PmaApp, WorkMode, WORK_MODES};
use super::Stats;
use eframe::egui;

const LIVE_H: f32 = 52.0;
/// Right sidebar action buttons — uniform size.
const SIDEBAR_BTN_H: f32 = 36.0;
const SIDEBAR_BTN_GAP: f32 = 8.0;

pub fn update(app: &mut PmaApp, ctx: &egui::Context) {
    let stats = Stats::from_results(
        app.scan_results_ref(),
        app.target_count.max(app.scan_results_ref().len()),
    );
    app.run_analytics
        .tick(stats.checked(), stats.hit_rate_pct(), app.busy);

    sales_dashboard::paint_app_backdrop(ctx);

    egui::SidePanel::right("export_sales_insights")
        .resizable(false)
        .exact_width(sales_dashboard::ADMIN_RIGHT_W + 8.0)
        .frame(sales_dashboard::panel_card_frame())
        .show(ctx, |ui| {
            session_panel(ui, app, &stats);
        });

    egui::TopBottomPanel::bottom("export_sales_live")
        .exact_height(LIVE_H)
        .frame(
            sales_dashboard::main_frame().inner_margin(egui::Margin::symmetric(
                sales_dashboard::ADMIN_PAD,
                6.0,
            )),
        )
        .show(ctx, |ui| {
            sales_dashboard::live_performance_body(ui, app, &stats, true);
        });

    egui::CentralPanel::default()
        .frame(
            sales_dashboard::main_frame()
                .inner_margin(egui::Margin::same(sales_dashboard::ADMIN_PAD)),
        )
        .show(ctx, |ui| {
            main_dashboard(app, ui, &stats);
        });
}

fn suite_provider_picker(app: &PmaApp) -> bool {
    !app.busy
        && ((app.work_mode == WorkMode::NoteCheck && app.fixed_note_service.is_none())
            || (app.work_mode == WorkMode::CrmCheck && app.fixed_crm_service.is_none()))
}

fn kpi_row(ui: &mut egui::Ui, stats: &Stats, good_hint: &str) {
    ui.columns(5, |cols| {
        sales_dashboard::kpi_card_compact(
            &mut cols[0],
            "Valid",
            &stats.valid.to_string(),
            good_hint,
            KpiGradient::Cyan,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[1],
            "Bad",
            &stats.invalid.to_string(),
            "Bad.txt · AUTH",
            KpiGradient::Gold,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[2],
            "Error",
            &stats.errors.to_string(),
            "Error.txt · NETWORK",
            KpiGradient::Orange,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[3],
            "CantCheck",
            &stats.cant_check.to_string(),
            "CantCheck.txt · ERROR",
            KpiGradient::Pink,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[4],
            "2FA",
            &stats.two_fa.to_string(),
            "2FA.txt · captcha/MFA",
            KpiGradient::Violet,
        );
    });
}

fn main_dashboard(app: &mut PmaApp, ui: &mut egui::Ui, stats: &Stats) {
    ui.add_space(2.0);
    let good_hint = if app.fixed_mode.is_some() {
        "Good.txt"
    } else {
        "Good.txt · Results"
    };
    kpi_row(ui, stats, good_hint);

    ui.add_space(10.0);
    let provider_strip_h = if suite_provider_picker(app) {
        crate::suite_provider_cards::provider_strip_height(ui.available_width())
    } else {
        0.0
    };
    let card_h = (ui.available_height() - provider_strip_h - 8.0).max(140.0);
    ui.with_layout(egui::Layout::left_to_right(egui::Align::TOP), |ui| {
        let gap = 10.0;
        let w = (ui.available_width() - gap) / 2.0;
        ui.vertical(|ui| {
            ui.set_max_width(w);
            ui.set_max_height(card_h);
            run_card(app, ui, w, card_h);
        });
        ui.add_space(gap);
        ui.vertical(|ui| {
            ui.set_max_width(w);
            ui.set_max_height(card_h);
            log_card(app, ui, w, card_h);
        });
    });

    if suite_provider_picker(app) {
        ui.add_space(8.0);
        if app.work_mode == WorkMode::NoteCheck {
            crate::suite_provider_cards::note_provider_cards_expanded(
                ui,
                &mut app.note_service,
            );
        } else {
            crate::suite_provider_cards::crm_provider_cards_expanded(
                ui,
                &mut app.crm_service,
            );
        }
    }
}

fn setting_slider(
    ui: &mut egui::Ui,
    width: f32,
    label: &str,
    value: &mut u32,
    min: u32,
    max: u32,
) {
    ui.horizontal(|ui| {
        ui.set_width(width);
        ui.label(
            egui::RichText::new(label)
                .font(sales_dashboard::font_display(12.0))
                .color(sales_dashboard::MUTED),
        );
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            ui.label(
                egui::RichText::new(value.to_string())
                    .font(sales_dashboard::font_display(13.0))
                    .color(sales_dashboard::TEXT),
            );
        });
    });
    let mut v = (*value).clamp(min, max) as i32;
    ui.add(egui::Slider::new(&mut v, min as i32..=max as i32).show_value(false));
    *value = v.clamp(min as i32, max as i32) as u32;
    ui.add_space(4.0);
}

fn shell_button(ui: &mut egui::Ui, label: &str, width: f32, yellow: bool) -> bool {
    let h = sales_dashboard::ADMIN_CTRL_H;
    if yellow {
        ui.add_sized(
            [width, h],
            egui::Button::new(
                egui::RichText::new(label)
                    .font(sales_dashboard::font_display(14.0))
                    .color(sales_dashboard::BTN_YELLOW_TEXT),
            )
            .fill(sales_dashboard::BTN_YELLOW)
            .rounding(egui::Rounding::same(10.0)),
        )
        .clicked()
    } else {
        ui.add_sized(
            [width, h],
            egui::Button::new(
                egui::RichText::new(label)
                    .font(sales_dashboard::font_display(14.0))
                    .color(sales_dashboard::TEXT),
            )
            .fill(sales_dashboard::INPUT)
            .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
            .rounding(egui::Rounding::same(10.0)),
        )
        .clicked()
    }
}

pub(crate) fn browse_field(ui: &mut egui::Ui, hint: &str, path: &str, width: f32) -> bool {
    let label = if path.is_empty() {
        hint.to_string()
    } else {
        truncate_middle(path, 42)
    };
    ui.add_sized(
        [width, sales_dashboard::ADMIN_CTRL_H],
        egui::Button::new(
            egui::RichText::new(format!("📁  {label}"))
                .font(sales_dashboard::font_display(12.0))
                .color(sales_dashboard::TEXT),
        )
        .fill(sales_dashboard::INPUT)
        .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
        .rounding(egui::Rounding::same(10.0)),
    )
    .clicked()
}

fn run_card(app: &mut PmaApp, ui: &mut egui::Ui, width: f32, card_h: f32) {
    sales_dashboard::panel_card_frame().show(ui, |ui| {
        ui.set_width((width - 32.0).max(160.0));
        ui.set_max_height(card_h);
        let title = if app.fixed_note_service.is_some() {
            format!("Run · {}", app.note_service.label())
        } else if app.work_mode == WorkMode::NoteCheck {
            format!("Run · {}", app.note_service.label())
        } else if app.fixed_crm_service.is_some() {
            format!("Run · {}", app.crm_service.label())
        } else if app.work_mode == WorkMode::CrmCheck {
            format!("Run · {}", app.crm_service.label())
        } else if app.fixed_cloud_provider.is_some() {
            format!("Run · {}", app.cloud_provider.label())
        } else if app.fixed_mode.is_some() {
            format!("Run · {}", work_mode_label(app.work_mode))
        } else {
            "Run export".to_string()
        };
        ui.label(
            egui::RichText::new(title)
                .font(sales_dashboard::font_display(16.0))
                .color(sales_dashboard::TEXT),
        );
        ui.add_space(4.0);

        let scroll_h = (card_h - 36.0).max(120.0);
        egui::ScrollArea::vertical()
            .id_salt("export_shell_run_scroll")
            .auto_shrink([false; 2])
            .max_height(scroll_h)
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                run_card_body(app, ui);
            });
    });
}

fn run_card_body(app: &mut PmaApp, ui: &mut egui::Ui) {
        if app.fixed_mode.is_none() {
            ui.label(
                egui::RichText::new("Mode")
                    .font(sales_dashboard::font_display(12.0))
                    .color(sales_dashboard::MUTED),
            );
            mode_combo(ui, &mut app.work_mode);
            ui.add_space(6.0);
        }

        if app.work_mode == WorkMode::NoteCheck {
            ui.label(
                egui::RichText::new(app.note_service.label())
                    .font(sales_dashboard::font_display(12.0))
                    .color(sales_dashboard::ACCENT_CYAN),
            );
            ui.add_space(4.0);
        }

        if app.work_mode == WorkMode::CrmCheck {
            ui.label(
                egui::RichText::new(app.crm_service.label())
                    .font(sales_dashboard::font_display(12.0))
                    .color(sales_dashboard::ACCENT_CYAN),
            );
            ui.add_space(4.0);
        }
        ui.add_space(4.0);
        setting_slider(ui, ui.available_width(), "Threads", &mut app.threads, 1, 500);
        setting_slider(
            ui,
            ui.available_width(),
            "Timeout (s)",
            &mut app.timeout,
            5,
            300,
        );
        setting_slider(
            ui,
            ui.available_width(),
            "Export (s)",
            &mut app.export_timeout,
            10,
            600,
        );
        setting_slider(ui, ui.available_width(), "Retries", &mut app.retries, 1, 10);

        ui.checkbox(&mut app.insecure, "Allow invalid TLS");
        {
            let label = if is_cloud_mode(app) && app.cloud_provider.supports_upload() {
                "Upload files to valid cloud accounts (off = check only)"
            } else if is_cloud_mode(app) {
                "Download files from cloud (off = check only)"
            } else {
                "Download files (off = check only)"
            };
            ui.checkbox(app.download_files_enabled_mut(), label);
        }

        if app.work_mode == WorkMode::Redmine && app.download_files_enabled() {
            ui.add_space(4.0);
            ui.label(
                egui::RichText::new("Redmine export")
                    .font(sales_dashboard::font_display(11.0))
                    .color(sales_dashboard::MUTED),
            );
            ui.checkbox(&mut app.redmine_export_issues, "Issues (HTML lists)");
            ui.checkbox(&mut app.redmine_export_attachments, "Attachments");
            ui.checkbox(&mut app.redmine_export_wiki, "Wiki pages");
            if !app.redmine_export_options().any_selected() {
                ui.label(
                    egui::RichText::new("Select at least one category to export.")
                        .font(sales_dashboard::font_display(11.0))
                        .color(egui::Color32::from_rgb(220, 120, 80)),
                );
            }
        }

        if app.work_mode == WorkMode::Snowflake && app.download_files_enabled() {
            ui.add_space(4.0);
            ui.label(
                egui::RichText::new("Snowflake export")
                    .font(sales_dashboard::font_display(11.0))
                    .color(sales_dashboard::MUTED),
            );
            ui.checkbox(&mut app.snowflake_export_databases, "Databases & schemas (HTML)");
            ui.checkbox(&mut app.snowflake_export_warehouses, "Warehouses");
            ui.checkbox(&mut app.snowflake_export_roles, "Roles");
            if !app.snowflake_export_options().any_selected() {
                ui.label(
                    egui::RichText::new("Select at least one category to export.")
                        .font(sales_dashboard::font_display(11.0))
                        .color(egui::Color32::from_rgb(220, 120, 80)),
                );
            }
        }

        if is_cloud_mode(app) {
            ui.add_space(6.0);
            cloud_settings(ui, app);
        } else {
            ui.add_space(4.0);
            ui.label(
                egui::RichText::new("Proxy (optional)")
                    .font(sales_dashboard::font_display(11.0))
                    .color(sales_dashboard::MUTED),
            );
            ui.add(
                egui::TextEdit::singleline(&mut app.proxy)
                    .hint_text("socks5://127.0.0.1:1080")
                    .desired_width(ui.available_width()),
            );
        }
}

fn mode_combo(ui: &mut egui::Ui, current: &mut WorkMode) {
    let w = ui.available_width();
    egui::ComboBox::from_id_salt("export_shell_mode")
        .selected_text(
            egui::RichText::new(work_mode_label(*current))
                .font(sales_dashboard::font_display(13.0))
                .color(sales_dashboard::TEXT),
        )
        .width(w)
        .show_ui(ui, |ui| {
            for (mode, label) in WORK_MODES {
                if mode == WorkMode::AdminPanel || mode == WorkMode::CrmCheck || mode == WorkMode::NoteCheck {
                    continue;
                }
                ui.selectable_value(current, mode, label);
            }
        });
}

fn is_cloud_mode(app: &PmaApp) -> bool {
    app.work_mode == WorkMode::Mega
}

fn cloud_proxy_mode_combo(ui: &mut egui::Ui, mode: &mut MegaxProxyMode) {
    egui::ComboBox::from_id_salt("export_shell_mx_proxy_mode")
        .selected_text(mode.label())
        .width(ui.available_width())
        .show_ui(ui, |ui| {
            for v in [
                MegaxProxyMode::ProxyFile,
                MegaxProxyMode::Single,
                MegaxProxyMode::Direct,
            ] {
                ui.selectable_value(mode, v, v.label());
            }
        });
}

fn cloud_proxy_protocol_combo(ui: &mut egui::Ui, proto: &mut MegaxProxyProtocol, width: f32) {
    egui::ComboBox::from_id_salt("export_shell_mx_proxy_proto")
        .selected_text(proto.label())
        .width(width)
        .show_ui(ui, |ui| {
            ui.selectable_value(proto, MegaxProxyProtocol::Http, MegaxProxyProtocol::Http.label());
            ui.selectable_value(
                proto,
                MegaxProxyProtocol::Socks5,
                MegaxProxyProtocol::Socks5.label(),
            );
        });
}

fn cloud_proxy_format_combo(
    ui: &mut egui::Ui,
    fmt: &mut MegaxProxyLineFormat,
    width: f32,
) {
    egui::ComboBox::from_id_salt("export_shell_mx_proxy_format")
        .selected_text(fmt.label())
        .width(width)
        .show_ui(ui, |ui| {
            ui.selectable_value(
                fmt,
                MegaxProxyLineFormat::HostPort,
                MegaxProxyLineFormat::HostPort.label(),
            );
            ui.selectable_value(
                fmt,
                MegaxProxyLineFormat::UserPassAtHostPort,
                MegaxProxyLineFormat::UserPassAtHostPort.label(),
            );
        });
}

fn cloud_profiles_section(ui: &mut egui::Ui, app: &mut PmaApp) {
    if app.fixed_mode != Some(WorkMode::Mega) {
        return;
    }
    if app.fixed_cloud_provider.is_some() {
        ui.add_space(6.0);
        ui.label(
            egui::RichText::new("Profiles disabled — provider is fixed for this app.")
                .font(sales_dashboard::font_display(10.0))
                .color(sales_dashboard::MUTED),
        );
        return;
    }
    ui.add_space(6.0);
    ui.separator();
    ui.add_space(6.0);
    ui.label(
        egui::RichText::new("Profiles")
            .font(sales_dashboard::font_display(12.0))
            .color(sales_dashboard::TEXT),
    );
    let names = app.megax_profile_store.profile_names();
    let active = app.megax_profile_store.active.clone();
    let mut selected: Option<String> = None;
    egui::ComboBox::from_id_salt("export_shell_mx_profile_pick")
        .selected_text(active.as_str())
        .width(ui.available_width())
        .show_ui(ui, |ui| {
            for name in &names {
                if ui.selectable_label(active == *name, name).clicked() {
                    selected = Some(name.clone());
                }
            }
        });
    if let Some(name) = selected {
        app.megax_profile_apply_active(&name);
        app.megax_profile_message = format!("Loaded \"{name}\"");
    }

    ui.add(
        egui::TextEdit::singleline(&mut app.megax_profile_draft_name)
            .hint_text("Profile name")
            .desired_width(ui.available_width()),
    );
    ui.horizontal(|ui| {
        if ui.small_button("Save").clicked() {
            let name = app.megax_profile_draft_name.clone();
            match app.megax_profile_save_current(&name) {
                Ok(()) => app.megax_profile_message = format!("Saved \"{name}\""),
                Err(e) => app.megax_profile_message = e,
            }
        }
        if ui.small_button("+ New").clicked() {
            let base = app.megax_profile_draft_name.trim();
            let base = if base.is_empty() { "Profile" } else { base };
            let existing = app.megax_profile_store.profile_names();
            let mut candidate = base.to_string();
            let mut n = 2usize;
            while existing.iter().any(|x| x == &candidate) {
                candidate = format!("{base} {n}");
                n += 1;
            }
            app.megax_profile_draft_name = candidate.clone();
            match app.megax_profile_save_current(&candidate) {
                Ok(()) => app.megax_profile_message = format!("Added \"{candidate}\""),
                Err(e) => app.megax_profile_message = e,
            }
        }
        if ui.small_button("Delete").clicked() {
            let name = app.megax_profile_store.active.clone();
            match app.megax_profile_delete(&name) {
                Ok(()) => app.megax_profile_message = format!("Deleted \"{name}\""),
                Err(e) => app.megax_profile_message = e,
            }
        }
    });
    if !app.megax_profile_message.is_empty() {
        ui.label(
            egui::RichText::new(&app.megax_profile_message)
                .font(sales_dashboard::font_display(11.0))
                .color(sales_dashboard::SUCCESS),
        );
    }
}

fn cloud_settings(ui: &mut egui::Ui, app: &mut PmaApp) {
    app.enforce_fixed_cloud_provider();
    ui.separator();
    ui.label(
        egui::RichText::new("Cloud / Proxy")
            .font(sales_dashboard::font_display(12.0))
            .color(sales_dashboard::TEXT),
    );
    ui.add_space(4.0);
    if app.fixed_cloud_provider.is_some() {
        ui.label(
            egui::RichText::new(app.cloud_provider.label())
                .font(sales_dashboard::font_display(12.0))
                .color(sales_dashboard::ACCENT_CYAN),
        );
    } else {
        ui.label(
            egui::RichText::new("Cloud provider")
                .font(sales_dashboard::font_display(11.0))
                .color(sales_dashboard::MUTED),
        );
        crate::cloud_provider_combo(ui, &mut app.cloud_provider);
    }

    ui.add_space(4.0);
    ui.label(
        egui::RichText::new("Proxy mode")
            .font(sales_dashboard::font_display(11.0))
            .color(sales_dashboard::MUTED),
    );
    cloud_proxy_mode_combo(ui, &mut app.megax_proxy_mode);
    if app.megax_proxy_mode != MegaxProxyMode::Direct {
        ui.add_space(4.0);
        ui.horizontal(|ui| {
            let w = (ui.available_width() - 8.0) * 0.5;
            cloud_proxy_protocol_combo(ui, &mut app.megax_proxy_protocol, w.max(120.0));
            cloud_proxy_format_combo(ui, &mut app.megax_proxy_line_format, w.max(120.0));
        });

        if app.megax_proxy_mode == MegaxProxyMode::ProxyFile {
            if browse_field(
                ui,
                "Select proxy list…",
                &app.proxy_list_file,
                ui.available_width(),
            ) {
                app.pick_proxy_list_file();
            }
        } else if app.megax_proxy_mode == MegaxProxyMode::Single {
            let hint = match app.megax_proxy_protocol {
                MegaxProxyProtocol::Http => "http://127.0.0.1:8080",
                MegaxProxyProtocol::Socks5 => "socks5://127.0.0.1:1080",
            };
            ui.add(
                egui::TextEdit::singleline(&mut app.proxy)
                    .hint_text(hint)
                    .desired_width(ui.available_width()),
            );
        }

        ui.checkbox(
            &mut app.megax_skip_proxy_precheck,
            "Huge proxy amount (skip pre-check)",
        );
        ui.checkbox(
            &mut app.megax_auto_fetch_proxies,
            "Auto-fetch proxies from URL",
        );
        if app.megax_auto_fetch_proxies {
            ui.add(
                egui::TextEdit::singleline(&mut app.megax_proxy_list_url)
                    .hint_text("https://...")
                    .desired_width(ui.available_width()),
            );
            ui.horizontal(|ui| {
                ui.label(
                    egui::RichText::new("Update interval (min)")
                        .font(sales_dashboard::font_display(11.0))
                        .color(sales_dashboard::MUTED),
                );
                ui.add(egui::DragValue::new(&mut app.megax_proxy_interval_min).range(1..=120));
            });
        }
    } else {
        ui.label(
            egui::RichText::new("No proxy (direct) selected — proxy file / URL are ignored.")
                .font(sales_dashboard::font_display(11.0))
                .color(sales_dashboard::MUTED),
        );
    }

    ui.checkbox(&mut app.megax_upload_no_proxy, "Upload without proxy");
    ui.checkbox(&mut app.megax_download_no_proxy, "Download without proxy");

    let cloud_transfer_enabled = {
        let enabled = app.download_files_enabled_mut();
        *enabled
    };
    let supports_upload = app.cloud_provider.supports_upload();
    if supports_upload && cloud_transfer_enabled {
        ui.add_space(4.0);
        if browse_field(
            ui,
            "Select upload folder…",
            &app.mega_upload_dir,
            ui.available_width(),
        ) {
            app.pick_mega_upload_dir();
        }
    }

    if !supports_upload {
        ui.add_space(4.0);
        ui.label(
            egui::RichText::new("Download filters")
                .font(sales_dashboard::font_display(11.0))
                .color(sales_dashboard::MUTED),
        );
        ui.add(
            egui::TextEdit::singleline(&mut app.cloud_filter_extensions)
                .hint_text(".txt, .pdf, wallet")
                .desired_width(ui.available_width()),
        );
        ui.add(
            egui::TextEdit::singleline(&mut app.cloud_filter_keywords)
                .hint_text("seed, backup, password")
                .desired_width(ui.available_width()),
        );
        ui.horizontal(|ui| {
            ui.label(
                egui::RichText::new("Min KB")
                    .font(sales_dashboard::font_display(11.0))
                    .color(sales_dashboard::MUTED),
            );
            ui.add(egui::DragValue::new(&mut app.cloud_filter_min_kb).range(0..=10_000_000));
            ui.label(
                egui::RichText::new("Max MB")
                    .font(sales_dashboard::font_display(11.0))
                    .color(sales_dashboard::MUTED),
            );
            ui.add(egui::DragValue::new(&mut app.cloud_filter_max_mb).range(0..=1_000_000));
        });
    }

    cloud_profiles_section(ui, app);
}

fn log_card(app: &mut PmaApp, ui: &mut egui::Ui, width: f32, card_h: f32) {
    sales_dashboard::panel_card_frame().show(ui, |ui| {
        ui.set_width((width - 32.0).max(160.0));
        ui.set_max_height(card_h);
        ui.set_min_height((card_h * 0.5).min(280.0).max(120.0));
        ui.horizontal(|ui| {
            ui.label(
                egui::RichText::new("Live log")
                    .font(sales_dashboard::font_display(16.0))
                    .color(sales_dashboard::TEXT),
            );
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.small_button("Clear").clicked() {
                    app.logs.clear();
                }
                if ui.small_button("Copy").clicked() {
                    ui.ctx()
                        .copy_text(crate::format_logs_for_clipboard(&app.logs));
                }
            });
        });
        ui.add_space(6.0);
        let log_scroll_h = (card_h - 52.0).max(80.0);
        egui::ScrollArea::vertical()
            .id_salt("export_shell_log_scroll")
            .stick_to_bottom(true)
            .auto_shrink([false; 2])
            .max_height(log_scroll_h)
            .show(ui, |ui| {
                ui.set_min_width(ui.available_width());
                if app.logs.is_empty() {
                    ui.label(
                        egui::RichText::new("Run to see results…")
                            .color(sales_dashboard::MUTED2),
                    );
                }
                for e in &app.logs {
                    let color = log_status_color(&e.status);
                    ui.horizontal_wrapped(|ui| {
                        ui.label(
                            egui::RichText::new(format!("[{}]", e.status))
                                .font(sales_dashboard::font_display(11.0))
                                .color(color),
                        );
                        ui.label(
                            egui::RichText::new(&e.text)
                                .font(sales_dashboard::font_display(11.0))
                                .color(sales_dashboard::TEXT),
                        );
                    });
                }
            });
    });
}

fn log_status_color(status: &str) -> egui::Color32 {
    match status {
        "Good" | "Export" | "OK" => sales_dashboard::SUCCESS,
        "NETWORK" | "Error" | "Bad" => sales_dashboard::DANGER,
        "AUTH" | "FAIL" | "Captcha" | "2FA" => sales_dashboard::WARNING,
        "Info" => sales_dashboard::MUTED,
        _ => sales_dashboard::MUTED2,
    }
}

fn sidebar_colored_button(
    ui: &mut egui::Ui,
    label: &str,
    width: f32,
    fill: egui::Color32,
    text: egui::Color32,
) -> bool {
    ui.add_sized(
        [width, SIDEBAR_BTN_H],
        egui::Button::new(
            egui::RichText::new(label)
                .font(sales_dashboard::font_display(12.0))
                .color(text),
        )
        .fill(fill)
        .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
        .rounding(egui::Rounding::same(10.0)),
    )
    .clicked()
}

fn session_action_column(ui: &mut egui::Ui, app: &mut PmaApp) {
    let w = ui.available_width();
    ui.label(
        egui::RichText::new("Actions")
            .font(sales_dashboard::font_display(11.0))
            .color(sales_dashboard::MUTED),
    );
    ui.add_space(4.0);

    if app.busy {
        if sidebar_colored_button(
            ui,
            "STOP",
            w,
            sales_dashboard::DANGER,
            sales_dashboard::TEXT,
        ) {
            app.stop_work();
        }
        ui.horizontal(|ui| {
            ui.spinner();
            ui.label(
                egui::RichText::new("Running…")
                    .font(sales_dashboard::font_display(11.0))
                    .color(sales_dashboard::MUTED),
            );
        });
    } else if sidebar_colored_button(
        ui,
        "START",
        w,
        sales_dashboard::BTN_YELLOW,
        sales_dashboard::BTN_YELLOW_TEXT,
    ) {
        app.start_work();
    }
    ui.add_space(SIDEBAR_BTN_GAP);

    if sidebar_colored_button(
        ui,
        "COMBO / LIST FILE",
        w,
        egui::Color32::from_rgb(34, 80, 120),
        sales_dashboard::TEXT,
    ) {
        app.pick_input_file();
    }
    ui.add_space(SIDEBAR_BTN_GAP);

    if sidebar_colored_button(
        ui,
        "OUTPUT FOLDER",
        w,
        egui::Color32::from_rgb(88, 52, 128),
        sales_dashboard::TEXT,
    ) {
        app.pick_output_dir();
    }
    ui.add_space(SIDEBAR_BTN_GAP);

    if sidebar_colored_button(
        ui,
        "OPEN FOLDER",
        w,
        egui::Color32::from_rgb(22, 92, 58),
        sales_dashboard::TEXT,
    ) {
        app.open_results_folder();
    }
    ui.add_space(SIDEBAR_BTN_GAP);

    sidebar_colored_button(
        ui,
        &format!("ELAPSED  {}", app.elapsed_public()),
        w,
        egui::Color32::from_rgb(42, 42, 56),
        sales_dashboard::MUTED,
    );
}

fn session_panel(ui: &mut egui::Ui, app: &mut PmaApp, stats: &Stats) {
    ui.vertical(|ui| {
        ui.label(
            egui::RichText::new("Session")
                .font(sales_dashboard::font_display(15.0))
                .color(sales_dashboard::TEXT),
        );
        ui.add_space(4.0);
        let session_label = if app.fixed_cloud_provider.is_some() {
            app.cloud_provider.label()
        } else if app.work_mode == WorkMode::NoteCheck {
            app.note_service.label()
        } else if app.work_mode == WorkMode::CrmCheck {
            app.crm_service.label()
        } else {
            work_mode_label(app.work_mode)
        };
        ui.label(
            egui::RichText::new(session_label)
                .font(sales_dashboard::font_display(12.0))
                .color(sales_dashboard::ACCENT_CYAN),
        );
        ui.add_space(8.0);
        let checked = stats.checked();
        let total = stats.total.max(1);
        sales_dashboard::metric_row(
            ui,
            "Lines total",
            &stats.total.to_string(),
            None,
            sales_dashboard::TEXT,
        );
        sales_dashboard::metric_row(
            ui,
            "Checked",
            &checked.to_string(),
            None,
            sales_dashboard::ACCENT_CYAN,
        );
        sales_dashboard::metric_row(
            ui,
            "Valid",
            &stats.valid.to_string(),
            None,
            sales_dashboard::SUCCESS,
        );
        sales_dashboard::metric_row(
            ui,
            "Bad (AUTH)",
            &stats.invalid.to_string(),
            None,
            sales_dashboard::WARNING,
        );
        sales_dashboard::metric_row(
            ui,
            "Error (NET)",
            &stats.errors.to_string(),
            None,
            sales_dashboard::DANGER,
        );
        sales_dashboard::metric_row(
            ui,
            "CantCheck",
            &stats.cant_check.to_string(),
            None,
            sales_dashboard::ACCENT_PURPLE,
        );
        sales_dashboard::metric_row(
            ui,
            "2FA / Captcha",
            &stats.two_fa.to_string(),
            None,
            sales_dashboard::GRAD_PINK_A,
        );
        ui.add_space(6.0);
        sales_dashboard::visitor_bar(
            ui,
            "Progress",
            &format!("{}/{}", checked, total),
            stats.progress_pct() / 100.0,
            sales_dashboard::ACCENT_PURPLE,
        );
        sales_dashboard::visitor_bar(
            ui,
            "Hit rate",
            &format!("{:.0}%", stats.hit_rate_pct()),
            stats.hit_rate_pct() / 100.0,
            sales_dashboard::ACCENT_CYAN,
        );

        ui.allocate_ui_with_layout(
            egui::vec2(ui.available_width(), ui.available_height()),
            egui::Layout::bottom_up(egui::Align::LEFT),
            |ui| {
                session_action_column(ui, app);
            },
        );
    });
}
