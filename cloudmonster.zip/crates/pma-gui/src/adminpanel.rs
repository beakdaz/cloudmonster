//! AdminPanel — check-only mixed list, Sales Dashboard (Figma Community) UI.

use crate::sales_dashboard::{self, KpiGradient};
use crate::PmaApp;
use pma_core::MixedService;

use super::Stats;
use eframe::egui;

pub const WINDOW_TITLE: &str = "AdminPanel";

const LIVE_H: f32 = 52.0;

pub fn update(app: &mut PmaApp, ctx: &egui::Context) {
    let stats = Stats::from_results(
        app.scan_results_ref(),
        app.target_count.max(app.scan_results_ref().len()),
    );
    app.run_analytics
        .tick(stats.checked(), stats.hit_rate_pct(), app.busy);

    sales_dashboard::paint_app_backdrop(ctx);

    egui::SidePanel::right("sales_insights")
        .resizable(false)
        .exact_width(sales_dashboard::ADMIN_RIGHT_W + 8.0)
        .frame(sales_dashboard::panel_card_frame())
        .show(ctx, |ui| {
            right_insights(ui, app, &stats);
        });

    egui::TopBottomPanel::bottom("sales_live")
        .exact_height(LIVE_H)
        .frame(
            sales_dashboard::main_frame().inner_margin(egui::Margin::symmetric(
                sales_dashboard::ADMIN_PAD,
                6.0,
            )),
        )
        .show(ctx, |ui| {
            sales_dashboard::live_performance_body(ui, app, &stats, true);
        });

    egui::CentralPanel::default()
        .frame(
            sales_dashboard::main_frame()
                .inner_margin(egui::Margin::same(sales_dashboard::ADMIN_PAD)),
        )
        .show(ctx, |ui| {
            main_dashboard(app, ui, &stats);
        });
}

fn main_dashboard(app: &mut PmaApp, ui: &mut egui::Ui, stats: &Stats) {
    ui.add_space(2.0);
    ui.columns(5, |cols| {
        sales_dashboard::kpi_card_compact(
            &mut cols[0],
            "Valid",
            &stats.valid.to_string(),
            "Good_<Service>.txt",
            KpiGradient::Cyan,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[1],
            "Bad",
            &stats.invalid.to_string(),
            "Bad.txt · AUTH",
            KpiGradient::Gold,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[2],
            "Error",
            &stats.errors.to_string(),
            "Error.txt · NETWORK",
            KpiGradient::Orange,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[3],
            "CantCheck",
            &stats.cant_check.to_string(),
            "CantCheck.txt · ERROR",
            KpiGradient::Pink,
        );
        sales_dashboard::kpi_card_compact(
            &mut cols[4],
            "2FA",
            &stats.two_fa.to_string(),
            "2FA.txt · captcha/MFA",
            KpiGradient::Violet,
        );
    });

    ui.add_space(10.0);
    ui.with_layout(egui::Layout::left_to_right(egui::Align::TOP), |ui| {
        let gap = 10.0;
        let w = (ui.available_width() - gap) / 2.0;
        ui.vertical(|ui| {
            ui.set_max_width(w);
            run_card(app, ui, w);
        });
        ui.add_space(gap);
        ui.vertical(|ui| {
            ui.set_max_width(w);
            services_card(ui, w);
        });
    });
}

fn setting_slider(
    ui: &mut egui::Ui,
    width: f32,
    label: &str,
    value: &mut u32,
    min: u32,
    max: u32,
) {
    ui.horizontal(|ui| {
        ui.set_width(width);
        ui.label(
            egui::RichText::new(label)
                .font(sales_dashboard::font_display(12.0))
                .color(sales_dashboard::MUTED),
        );
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            ui.label(
                egui::RichText::new(value.to_string())
                    .font(sales_dashboard::font_display(13.0))
                    .color(sales_dashboard::TEXT),
            );
        });
    });
    let mut v = (*value).clamp(min, max) as i32;
    ui.add(
        egui::Slider::new(&mut v, min as i32..=max as i32).show_value(false),
    );
    *value = v.clamp(min as i32, max as i32) as u32;
    ui.add_space(4.0);
}

fn admin_button(ui: &mut egui::Ui, label: &str, width: f32, yellow: bool) -> bool {
    let h = sales_dashboard::ADMIN_CTRL_H;
    if yellow {
        ui.add_sized(
            [width, h],
            egui::Button::new(
                egui::RichText::new(label)
                    .font(sales_dashboard::font_display(14.0))
                    .color(sales_dashboard::BTN_YELLOW_TEXT),
            )
            .fill(sales_dashboard::BTN_YELLOW)
            .rounding(egui::Rounding::same(10.0)),
        )
        .clicked()
    } else {
        ui.add_sized(
            [width, h],
            egui::Button::new(
                egui::RichText::new(label)
                    .font(sales_dashboard::font_display(14.0))
                    .color(sales_dashboard::TEXT),
            )
                .fill(sales_dashboard::INPUT)
                .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
                .rounding(egui::Rounding::same(10.0)),
        )
        .clicked()
    }
}

fn admin_browse_field(ui: &mut egui::Ui, hint: &str, path: &str, width: f32) -> bool {
    let label = if path.is_empty() {
        hint.to_string()
    } else {
        crate::truncate_middle(path, 42)
    };
    ui.add_sized(
        [width, sales_dashboard::ADMIN_CTRL_H],
        egui::Button::new(
            egui::RichText::new(format!("📁  {label}"))
                .font(sales_dashboard::font_display(12.0))
                .color(sales_dashboard::TEXT),
        )
        .fill(sales_dashboard::INPUT)
        .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
        .rounding(egui::Rounding::same(10.0)),
    )
    .clicked()
}

fn run_card(app: &mut PmaApp, ui: &mut egui::Ui, width: f32) {
    sales_dashboard::panel_card_frame().show(ui, |ui| {
        ui.set_width(width - 32.0);
        ui.label(
            egui::RichText::new("Run check")
                .font(sales_dashboard::font_display(16.0))
                .color(sales_dashboard::TEXT),
        );
        ui.add_space(6.0);
        if admin_browse_field(
            ui,
            "Select combo file…",
            &app.input_file,
            ui.available_width(),
        ) {
            app.pick_input_file();
        }
        ui.add_space(4.0);
        setting_slider(
            ui,
            ui.available_width(),
            "Threads",
            &mut app.threads,
            1,
            500,
        );
        setting_slider(
            ui,
            ui.available_width(),
            "Timeout (s)",
            &mut app.export_timeout,
            10,
            600,
        );
        ui.checkbox(&mut app.insecure, "Allow invalid TLS");
        ui.add_space(8.0);
        let btn_w = ui.available_width();
        let start = if app.busy { "Stop" } else { "Start check" };
        if app.busy {
            if admin_button(ui, start, btn_w, false) {
                app.stop_work();
            }
        } else if admin_button(ui, start, btn_w, true) {
            app.start_work();
        }
        if app.busy {
            ui.add_space(4.0);
            ui.spinner();
        }
        ui.add_space(6.0);
        if admin_browse_field(
            ui,
            "G:\\RESULTS",
            &app.output_dir,
            ui.available_width(),
        ) {
            app.pick_output_dir();
        }
        ui.horizontal(|ui| {
            ui.label(
                egui::RichText::new(format!("Elapsed: {}", app.elapsed_public()))
                    .small()
                    .color(sales_dashboard::MUTED),
            );
            if ui.button("Open folder").clicked() {
                app.open_results_folder();
            }
        });
        if !app.adminpanel_status.is_empty() {
            ui.add_space(6.0);
            ui.label(
                egui::RichText::new(&app.adminpanel_status)
                    .color(sales_dashboard::DANGER),
            );
        }
    });
}

fn services_card(ui: &mut egui::Ui, width: f32) {
    sales_dashboard::panel_card_frame().show(ui, |ui| {
        let inner_w = (width - 32.0).max(160.0);
        ui.set_width(inner_w);
        ui.label(
            egui::RichText::new("Supported services")
                .font(sales_dashboard::font_display(16.0))
                .color(sales_dashboard::TEXT),
        );
        ui.label(
            egui::RichText::new(format!(
                "{} types · auto-detect from combo line",
                MixedService::ALL.len()
            ))
            .small()
            .color(sales_dashboard::MUTED),
        );
        ui.add_space(4.0);
        ui.horizontal_wrapped(|ui| {
            ui.set_max_width(inner_w);
            ui.spacing_mut().item_spacing = egui::vec2(5.0, 5.0);
            for svc in MixedService::ALL {
                let (r, g, b) = svc.chip_rgb();
                let fill = egui::Color32::from_rgb(r, g, b);
                let text = egui::Color32::from_rgb(255, 255, 255);
                sales_dashboard::service_tag_colored(ui, svc.label(), fill, text, 10.0);
            }
        });
    });
}

fn right_insights(ui: &mut egui::Ui, app: &PmaApp, stats: &Stats) {
    ui.label(
        egui::RichText::new("Session")
            .font(sales_dashboard::font_display(15.0))
            .color(sales_dashboard::TEXT),
    );
    ui.add_space(6.0);
    let checked = stats.checked();
    let total = stats.total.max(1);
    sales_dashboard::metric_row(
        ui,
        "Lines total",
        &stats.total.to_string(),
        None,
        sales_dashboard::TEXT,
    );
    sales_dashboard::metric_row(
        ui,
        "Checked",
        &checked.to_string(),
        None,
        sales_dashboard::ACCENT_CYAN,
    );
    sales_dashboard::metric_row(
        ui,
        "Valid",
        &stats.valid.to_string(),
        None,
        sales_dashboard::SUCCESS,
    );
    sales_dashboard::metric_row(
        ui,
        "Bad (AUTH)",
        &stats.invalid.to_string(),
        None,
        sales_dashboard::WARNING,
    );
    sales_dashboard::metric_row(
        ui,
        "Error (NET)",
        &stats.errors.to_string(),
        None,
        sales_dashboard::DANGER,
    );
    sales_dashboard::metric_row(
        ui,
        "CantCheck",
        &stats.cant_check.to_string(),
        None,
        sales_dashboard::ACCENT_PURPLE,
    );
    sales_dashboard::metric_row(
        ui,
        "2FA / Captcha",
        &stats.two_fa.to_string(),
        None,
        sales_dashboard::GRAD_PINK_A,
    );
    ui.add_space(6.0);
    let prog = stats.progress_pct() / 100.0;
    sales_dashboard::visitor_bar(
        ui,
        "Progress",
        &format!("{}/{}", checked, total),
        prog,
        sales_dashboard::ACCENT_PURPLE,
    );
    let hit = stats.hit_rate_pct() / 100.0;
    sales_dashboard::visitor_bar(
        ui,
        "Hit rate",
        &format!("{:.0}%", stats.hit_rate_pct()),
        hit,
        sales_dashboard::ACCENT_CYAN,
    );
    if app.busy {
        ui.add_space(8.0);
        ui.spinner();
    }
}

pub fn is_adminpanel(app: &PmaApp) -> bool {
    app.fixed_mode == Some(crate::WorkMode::AdminPanel)
}
