//! CloudMonster local session (login display + license), persisted without secrets.

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;

const SESSION_VERSION: u32 = 1;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MegaxSession {
    pub version: u32,
    #[serde(default)]
    pub login_name: String,
    #[serde(default)]
    pub license_until: String,
    #[serde(default)]
    pub logged_in: bool,
}

impl Default for MegaxSession {
    fn default() -> Self {
        Self {
            version: SESSION_VERSION,
            login_name: String::new(),
            license_until: String::new(),
            logged_in: false,
        }
    }
}

pub fn session_path() -> PathBuf {
    if let Ok(local) = std::env::var("LOCALAPPDATA") {
        return PathBuf::from(local)
            .join("CloudMonster")
            .join("megax-session.json");
    }
    PathBuf::from("megax-session.json")
}

pub fn load() -> MegaxSession {
    let mut session = if let Ok(raw) = fs::read_to_string(session_path()) {
        serde_json::from_str(&raw).unwrap_or_default()
    } else {
        MegaxSession::default()
    };
    session.apply_env_overrides();
    session
}

pub fn save(session: &MegaxSession) -> Result<(), String> {
    let path = session_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let mut copy = session.clone();
    copy.version = SESSION_VERSION;
    let json = serde_json::to_string_pretty(&copy).map_err(|e| e.to_string())?;
    fs::write(&path, json).map_err(|e| e.to_string())
}

impl MegaxSession {
    pub fn apply_env_overrides(&mut self) {
        if let Ok(v) = std::env::var("MEGAX_LOGIN_NAME") {
            let t = v.trim();
            if !t.is_empty() {
                self.login_name = t.to_string();
            }
        }
        if let Ok(v) = std::env::var("MEGAX_LICENSE_UNTIL") {
            let t = v.trim();
            if !t.is_empty() {
                self.license_until = t.to_string();
            }
        }
        if let Ok(v) = std::env::var("MEGAX_LOGGED_IN") {
            self.logged_in = matches!(v.trim().to_lowercase().as_str(), "1" | "true" | "yes");
        }
        if self.login_name.is_empty() {
            self.logged_in = false;
        }
    }

    pub fn login_label(&self) -> String {
        if self.login_name.trim().is_empty() {
            "Login: —".to_string()
        } else if self.logged_in {
            format!("Login: {}", self.login_name.trim())
        } else {
            format!("Login: {} (offline)", self.login_name.trim())
        }
    }

    pub fn license_label(&self) -> String {
        let t = self.license_until.trim();
        if t.is_empty() {
            "License until: —".to_string()
        } else {
            format!("License until: {t}")
        }
    }
}
