//! Background proxy list parse (harvest only, no validation) for Note/CRM suite.

use crate::PmaApp;
use eframe::egui;
use pma_net::{run_parse_harvest_blocking, ParseHarvestEvent};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{Receiver, TryRecvError};
use std::sync::Arc;
use std::thread;

pub struct SuiteProxyParseState {
    pub parsed: Arc<Vec<String>>,
    pub busy: bool,
    pub status: String,
    pub kind: String,
    rx: Option<Receiver<ParseHarvestEvent>>,
    cancel: Arc<AtomicBool>,
}

impl Default for SuiteProxyParseState {
    fn default() -> Self {
        Self {
            parsed: Arc::new(Vec::new()),
            busy: false,
            status: String::new(),
            kind: String::new(),
            rx: None,
            cancel: Arc::new(AtomicBool::new(false)),
        }
    }
}

impl PmaApp {
    pub(crate) fn start_proxy_parse(&mut self, protocol: &'static str) {
        if self.suite_parse.busy {
            return;
        }
        self.suite_parse.busy = true;
        self.suite_parse.kind = protocol.to_ascii_uppercase();
        self.suite_parse.status = format!("parse {protocol}…");
        self.suite_parse.cancel = Arc::new(AtomicBool::new(false));
        let (tx, rx) = std::sync::mpsc::channel();
        self.suite_parse.rx = Some(rx);
        let cancel = self.suite_parse.cancel.clone();
        thread::spawn(move || {
            let _ = run_parse_harvest_blocking(protocol, cancel, tx);
        });
    }

}

pub fn poll(app: &mut PmaApp, ctx: &egui::Context) {
    let mut events = Vec::new();
    let mut disconnected = false;
    if let Some(rx) = app.suite_parse.rx.as_ref() {
        loop {
            match rx.try_recv() {
                Ok(e) => events.push(e),
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => {
                    disconnected = true;
                    break;
                }
            }
        }
    } else if !app.suite_parse.busy {
        return;
    }

    let mut repaint = !events.is_empty();
    for evt in events {
        match evt {
            ParseHarvestEvent::Status(s) => app.suite_parse.status = s,
            ParseHarvestEvent::Done { count, proxies } => {
                app.suite_parse.parsed = Arc::new(proxies);
                app.suite_parse.busy = false;
                app.suite_parse.rx = None;
                app.push_log(
                    "Info",
                    format!(
                        "Parsed {} {} proxies (no validation) — used on START",
                        count,
                        app.suite_parse.kind
                    ),
                    None,
                );
            }
        }
    }
    if disconnected {
        app.suite_parse.busy = false;
        app.suite_parse.rx = None;
        repaint = true;
    }
    if repaint {
        ctx.request_repaint();
    }
}
