﻿//! Desktop GUI вЂ” phpMyAdmin / Adminer / GitLab / Jenkins export (Rust port of PhpMyAdmin Export WPF).

mod adminpanel;
mod export_shell;
mod harmony;
mod sales_dashboard;
mod megax;
mod megax_profiles;
mod megax_session;
mod note_export_gui;
mod crm_export_gui;
mod suite_provider_cards;
mod suite_proxy_parse;

use anyhow::{Context, Result};
use eframe::egui;
use egui_extras::{Column, TableBuilder};
use pma_core::AddServiceKind;
use pma_core::NoteExportService;
use pma_core::CrmExportService;
use pma_net::NoteExportClientConfig;
use pma_net::WebappClientConfig;
use pma_app::{
    download_bitbucket_repos, download_bitrix_backups, download_gitlab_projects,
    download_jenkins_jobs, download_jira_exports, download_redmine_exports, download_snowflake_exports, download_xwiki_exports,
    download_confluence_exports, download_opencart_exports, download_workflowy_exports, download_roamresearch_exports,
    download_secondbrain_exports, download_appflowy_exports,
    download_note_export_exports, load_note_export_list_summary,
    download_crm_export_exports, load_crm_export_list_summary,
    download_bamboo_exports,
    download_phppgadmin_dumps, download_phpmyadmin_exports, download_adminer_exports,
    download_fortinet_exports,
    download_citrix_exports,
    download_slack_workspace_exports,
    download_cloud_exports, download_mixed_checks, download_webapp_exports, load_mixed_list_summary,
    load_webapp_list_summary, MixedCheckSettings,
    load_bitbucket_list_summary,
    load_bitrix_list_summary, load_gitlab_list_summary, load_jenkins_list_summary,
    load_phppgadmin_list_summary, load_phpmyadmin_list_summary, load_adminer_list_summary,
    load_jira_list_summary, load_redmine_list_summary, load_snowflake_list_summary, load_xwiki_list_summary, load_bamboo_list_summary, load_fortinet_list_summary, load_citrix_list_summary,
    load_confluence_list_summary, load_opencart_list_summary, load_workflowy_list_summary, load_roamresearch_list_summary,
    load_secondbrain_list_summary, load_appflowy_list_summary,
    load_slack_list_summary, load_cloud_list_summary, ProgressCallback, ProgressEvent,
};
use pma_core::{CloudDownloadFilter, CloudProvider, ScanResult, ScanStatus};
use pma_net::load_proxy_list_with;
use pma_net::normalize_proxy_field;
use pma_net::{
    AdminerClientConfig, BitbucketClientConfig, BitrixClientConfig, BambooClientConfig, GitLabClientConfig, JiraClientConfig, RedmineClientConfig, RedmineExportOptions, SnowflakeClientConfig, SnowflakeExportOptions, XWikiClientConfig,
    ConfluenceClientConfig, OpencartClientConfig, WorkflowyClientConfig, RoamresearchClientConfig, SecondbrainClientConfig, AppflowyClientConfig,
    JenkinsClientConfig, CitrixClientConfig, FortinetClientConfig, MegaClientConfig, PhpMyAdminClientConfig, PhpPgAdminClientConfig, SlackClientConfig,
    build_mega_http, megax_curl_parallel, megax_mega_login_parallel,
};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver, RecvTimeoutError, Sender};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

// #region agent log
pub(crate) fn agent_log_gui(hypothesis_id: &str, location: &str, message: &str, data: serde_json::Value) {
    use std::fs::OpenOptions;
    use std::io::Write;
    let line = serde_json::json!({
        "sessionId": "be3b27",
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0),
        "runId": "mega-gui",
    });
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

/// Which export backend this GUI instance runs (one mode per exe).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum WorkMode {
    PhpMyAdmin,
    Adminer,
    GitLab,
    Jenkins,
    PhpPgAdmin,
    Bitrix,
    Bitbucket,
    Jira,
    Redmine,
    Snowflake,
    Confluence,
    OpenCart,
    Workflowy,
    RoamResearch,
    SecondBrain,
    AppFlowy,
    Obsidian,
    Dynalist,
    Capacities,
    Gnotes,
    Joplin,
    Kortex,
    Mindlog,
    Notejoy,
    Notesnook,
    StandardNotes,
    Todoist,
    Turtl,
    Zotero,
    /// All note-suite providers in one app (`apps/notecheck-gui`).
    NoteCheck,
    XWiki,
    Bamboo,
    Slack,
    Fortinet,
    Citrix,
    Mega,
    Owa,
    Kibana,
    Zabbix,
    Zimbra,
    Drupal,
    Grafana,
    SonarQube,
    Mattermost,
    /// CRM check/export (`apps/crmcheck-gui`); not in all-modes picker.
    CrmCheck,
    /// Mixed check-only (`export-adminpanel-gui`); not in all-modes picker.
    AdminPanel,
}

impl WorkMode {
    pub fn add_service_kind(self) -> Option<pma_core::AddServiceKind> {
        use pma_core::AddServiceKind;
        match self {
            WorkMode::Owa => Some(AddServiceKind::Owa),
            WorkMode::Kibana => Some(AddServiceKind::Kibana),
            WorkMode::Zabbix => Some(AddServiceKind::Zabbix),
            WorkMode::Zimbra => Some(AddServiceKind::Zimbra),
            WorkMode::Drupal => Some(AddServiceKind::Drupal),
            WorkMode::Grafana => Some(AddServiceKind::Grafana),
            WorkMode::SonarQube => Some(AddServiceKind::SonarQube),
            WorkMode::Mattermost => Some(AddServiceKind::Mattermost),
            WorkMode::NoteCheck | WorkMode::CrmCheck | WorkMode::AdminPanel => None,
            _ => None,
        }
    }
}

pub(crate) const WORK_MODES: [(WorkMode, &str); 43] = [
    (WorkMode::PhpMyAdmin, "phpMyAdmin (MySQL)"),
    (WorkMode::Adminer, "Adminer"),
    (WorkMode::GitLab, "GitLab"),
    (WorkMode::Jenkins, "Jenkins"),
    (WorkMode::PhpPgAdmin, "phpPgAdmin (PostgreSQL)"),
    (WorkMode::Bitrix, "Bitrix"),
    (WorkMode::Bitbucket, "Bitbucket"),
    (WorkMode::Jira, "Jira"),
    (WorkMode::Redmine, "Redmine"),
    (WorkMode::Snowflake, "Snowflake"),
    (WorkMode::Confluence, "Confluence"),
    (WorkMode::OpenCart, "OpenCart"),
    (WorkMode::Workflowy, "Workflowy"),
    (WorkMode::RoamResearch, "Roam Research"),
    (WorkMode::SecondBrain, "The Second Brain"),
    (WorkMode::AppFlowy, "AppFlowy"),
    (WorkMode::Obsidian, "Obsidian"),
    (WorkMode::Dynalist, "Dynalist"),
    (WorkMode::Capacities, "Capacities"),
    (WorkMode::Gnotes, "GNotes"),
    (WorkMode::Joplin, "Joplin"),
    (WorkMode::Kortex, "Kortex"),
    (WorkMode::Mindlog, "Mindlog"),
    (WorkMode::Notejoy, "Notejoy"),
    (WorkMode::Notesnook, "Notesnook"),
    (WorkMode::StandardNotes, "Standard Notes"),
    (WorkMode::Todoist, "Todoist"),
    (WorkMode::Turtl, "Turtl"),
    (WorkMode::Zotero, "Zotero"),
    (WorkMode::XWiki, "XWiki"),
    (WorkMode::Bamboo, "Bamboo"),
    (WorkMode::Slack, "Slack"),
    (WorkMode::Fortinet, "Fortinet"),
    (WorkMode::Citrix, "Citrix"),
    (WorkMode::Mega, "Cloud storage"),
    (WorkMode::Owa, "OWA"),
    (WorkMode::Kibana, "Kibana"),
    (WorkMode::Zabbix, "Zabbix"),
    (WorkMode::Zimbra, "Zimbra"),
    (WorkMode::Drupal, "Drupal"),
    (WorkMode::Grafana, "Grafana"),
    (WorkMode::SonarQube, "SonarQube"),
    (WorkMode::Mattermost, "Mattermost"),
];

pub(crate) fn work_mode_label(mode: WorkMode) -> &'static str {
    WORK_MODES
        .iter()
        .find(|(m, _)| *m == mode)
        .map(|(_, label)| *label)
        .unwrap_or("Unknown")
}

pub fn window_title_for_mode(mode: WorkMode) -> &'static str {
    match mode {
        WorkMode::PhpMyAdmin => "phpMyAdmin Export",
        WorkMode::Adminer => "Adminer Export",
        WorkMode::GitLab => "GitLab Export",
        WorkMode::Jenkins => "Jenkins Export",
        WorkMode::PhpPgAdmin => "phpPgAdmin Export",
        WorkMode::Bitrix => "Bitrix Export",
        WorkMode::Bitbucket => "Bitbucket Export",
        WorkMode::Jira => "Jira Export",
        WorkMode::Redmine => "Redmine Export",
        WorkMode::Snowflake => "Snowflake Export",
        WorkMode::Confluence => "Confluence Export",
        WorkMode::OpenCart => "OpenCart Export",
        WorkMode::Workflowy => "Workflowy Export",
        WorkMode::RoamResearch => "Roam Research Export",
        WorkMode::SecondBrain => "The Second Brain Export",
        WorkMode::AppFlowy => "AppFlowy Export",
        WorkMode::Obsidian => "Obsidian Export",
        WorkMode::Dynalist => "Dynalist Export",
        WorkMode::Capacities => "Capacities Export",
        WorkMode::Gnotes => "GNotes Export",
        WorkMode::Joplin => "Joplin Export",
        WorkMode::Kortex => "Kortex Export",
        WorkMode::Mindlog => "Mindlog Export",
        WorkMode::Notejoy => "Notejoy Export",
        WorkMode::Notesnook => "Notesnook Export",
        WorkMode::StandardNotes => "Standard Notes Export",
        WorkMode::Todoist => "Todoist Export",
        WorkMode::Turtl => "Turtl Export",
        WorkMode::Zotero => "Zotero Export",
        WorkMode::NoteCheck => "Note Check",
        WorkMode::XWiki => "XWiki Export",
        WorkMode::Bamboo => "Bamboo Export",
        WorkMode::Slack => "Slack Export",
        WorkMode::Fortinet => "Fortinet Export",
        WorkMode::Citrix => "Citrix Export",
        WorkMode::Mega => "Cloud Export",
        WorkMode::Owa => "OWA Export",
        WorkMode::Kibana => "Kibana Export",
        WorkMode::Zabbix => "Zabbix Export",
        WorkMode::Zimbra => "Zimbra Export",
        WorkMode::Drupal => "Drupal Export",
        WorkMode::Grafana => "Grafana Export",
        WorkMode::SonarQube => "SonarQube Export",
        WorkMode::Mattermost => "Mattermost Export",
        WorkMode::CrmCheck => "CRM Check",
        WorkMode::AdminPanel => adminpanel::WINDOW_TITLE,
    }
}

pub struct LaunchConfig {
    /// When set, mode picker is hidden and only this backend runs.
    pub fixed_mode: Option<WorkMode>,
    pub window_title: Option<&'static str>,
    /// CloudMonster: lock cloud provider (e.g. Zoho-only executable).
    pub fixed_cloud_provider: Option<CloudProvider>,
    /// CRM Check: lock provider in dedicated exe variants.
    pub fixed_crm_service: Option<CrmExportService>,
    /// Note Check: lock provider in dedicated exe variants.
    pub fixed_note_service: Option<NoteExportService>,
}

impl Default for LaunchConfig {
    fn default() -> Self {
        Self {
            fixed_mode: None,
            window_title: None,
            fixed_cloud_provider: None,
            fixed_crm_service: None,
            fixed_note_service: None,
        }
    }
}

/// Note/CRM suite apps (multi + single-provider note exports, CRM check).
pub(crate) fn suite_check_shell(fixed_mode: Option<WorkMode>) -> bool {
    fixed_mode.is_some_and(|m| {
        matches!(m, WorkMode::NoteCheck | WorkMode::CrmCheck)
            || note_export_gui::note_export_service_for_mode(m).is_some()
    })
}

pub(crate) fn show_suite_proxy_parse(app: &PmaApp) -> bool {
    suite_check_shell(app.fixed_mode)
        || matches!(app.work_mode, WorkMode::NoteCheck | WorkMode::CrmCheck)
        || note_export_gui::note_export_service_for_mode(app.work_mode).is_some()
}

/// Start the export GUI. Pass `fixed_mode: Some(...)` for a single-mode executable.
pub fn run(config: LaunchConfig) -> eframe::Result<()> {
    agent_log_gui(
        "H-mega-ui",
        "pma-gui:run",
        "gui launch",
        serde_json::json!({
            "fixed_mode": format!("{:?}", config.fixed_mode),
            "work_modes_count": WORK_MODES.len(),
            "has_mega_in_list": WORK_MODES.iter().any(|(m, _)| *m == WorkMode::Mega),
        }),
    );

    let title = if config.fixed_cloud_provider == Some(CloudProvider::ZohoNotes) {
        "Export · Zoho Notes".to_string()
    } else if config.fixed_cloud_provider == Some(CloudProvider::Wps) {
        "Export · WPS Drive".to_string()
    } else if config.fixed_cloud_provider == Some(CloudProvider::Terabox) {
        "Export · TeraBox".to_string()
    } else if matches!(config.fixed_mode, Some(WorkMode::Mega)) {
        megax::BRAND_WINDOW_TITLE.to_string()
    } else if matches!(config.fixed_mode, Some(WorkMode::AdminPanel)) {
        adminpanel::WINDOW_TITLE.to_string()
    } else if matches!(config.fixed_mode, Some(WorkMode::CrmCheck)) {
        config
            .window_title
            .unwrap_or("CRM Check")
            .to_string()
    } else if matches!(config.fixed_mode, Some(WorkMode::NoteCheck)) {
        config
            .window_title
            .unwrap_or("Note Check")
            .to_string()
    } else {
        config
            .window_title
            .or_else(|| config.fixed_mode.map(window_title_for_mode))
            .unwrap_or("Export (all modes)")
            .to_string()
    };

    let fixed_mode = config.fixed_mode;
    let fixed_cloud_provider = config.fixed_cloud_provider;
    let fixed_crm_service = config.fixed_crm_service;
    let fixed_note_service = config.fixed_note_service;
    let mut viewport = egui::ViewportBuilder::default()
        .with_inner_size([1440.0, 720.0])
        .with_min_inner_size([1200.0, 620.0])
        .with_title(title.clone())
        .with_decorations(false)
        .with_transparent(true);
    if matches!(fixed_mode, Some(WorkMode::AdminPanel)) {
        viewport = viewport
            .with_inner_size([1360.0, 780.0])
            .with_min_inner_size([1180.0, 700.0])
            .with_decorations(true)
            .with_transparent(false);
    } else if suite_check_shell(fixed_mode) {
        // ~92.5% of 1560x880 design frame; room for provider grid + sidebar actions.
        viewport = viewport
            .with_inner_size([1444.0, 814.0])
            .with_min_inner_size([1280.0, 720.0])
            .with_decorations(true)
            .with_transparent(false);
    } else {
        // Export modules + all-modes (+ CloudMonster): same sales-dashboard chrome.
        viewport = viewport
            .with_inner_size([1360.0, 780.0])
            .with_min_inner_size([1180.0, 700.0])
            .with_decorations(true)
            .with_transparent(false);
    }
    if matches!(fixed_mode, Some(WorkMode::Mega)) {
        if let Ok(icon) = eframe::icon_data::from_png_bytes(include_bytes!("../assets/app_logo.png"))
        {
            viewport = viewport.with_icon(std::sync::Arc::new(icon));
        }
    }
    let native_options = eframe::NativeOptions {
        viewport,
        ..Default::default()
    };

    eframe::run_native(
        &title,
        native_options,
        Box::new(move |cc| {
            if suite_check_shell(fixed_mode) {
                sales_dashboard::apply_suite_check(&cc.egui_ctx);
            } else {
                sales_dashboard::apply_adminpanel(&cc.egui_ctx);
            }
            Ok(Box::new(PmaApp::new(
                fixed_mode,
                fixed_cloud_provider,
                fixed_crm_service,
                fixed_note_service,
            )))
        }),
    )
}

/// AdminPanel: mixed list, check-only, no log (separate from Export GUI with mode + log).
pub fn run_adminpanel() -> eframe::Result<()> {
    run(LaunchConfig {
        fixed_mode: Some(WorkMode::AdminPanel),
        window_title: Some(adminpanel::WINDOW_TITLE),
        fixed_cloud_provider: None,
        fixed_crm_service: None,
        fixed_note_service: None,
    })
}

/// Note Check — 13 providers, email:password lists (`apps/notecheck-gui`).
pub fn run_notecheck() -> eframe::Result<()> {
    run(LaunchConfig {
        fixed_mode: Some(WorkMode::NoteCheck),
        window_title: Some("Note Check"),
        fixed_cloud_provider: None,
        fixed_crm_service: None,
        fixed_note_service: None,
    })
}

/// CRM Check — 13 providers, same list format as note suite (`apps/crmcheck-gui`).
pub fn run_crmcheck() -> eframe::Result<()> {
    run(LaunchConfig {
        fixed_mode: Some(WorkMode::CrmCheck),
        window_title: Some("CRM Check"),
        fixed_cloud_provider: None,
        fixed_crm_service: None,
        fixed_note_service: None,
    })
}

/// Convenience entry for per-mode binaries (`apps/export-*-gui`).
pub fn run_fixed(mode: WorkMode) -> eframe::Result<()> {
    run(LaunchConfig {
        fixed_mode: Some(mode),
        window_title: None,
        fixed_cloud_provider: None,
        fixed_crm_service: None,
        fixed_note_service: None,
    })
}

/// CloudMonster with a single locked provider (`apps/export-zoho-gui`, …).
pub fn run_fixed_cloud(mode: WorkMode, provider: CloudProvider) -> eframe::Result<()> {
    run(LaunchConfig {
        fixed_mode: Some(mode),
        window_title: None,
        fixed_cloud_provider: Some(provider),
        fixed_crm_service: None,
        fixed_note_service: None,
    })
}

/// Zoho Notebook checker GUI (CloudMonster shell, provider fixed).
pub fn run_zoho_notes_gui() -> eframe::Result<()> {
    run_fixed_cloud(WorkMode::Mega, CloudProvider::ZohoNotes)
}

/// WPS Drive checker GUI (`apps/export-wps-gui`).
pub fn run_wps_gui() -> eframe::Result<()> {
    run_fixed_cloud(WorkMode::Mega, CloudProvider::Wps)
}

/// TeraBox checker GUI (`apps/export-terabox-gui`).
pub fn run_terabox_gui() -> eframe::Result<()> {
    run_fixed_cloud(WorkMode::Mega, CloudProvider::Terabox)
}

/// CloudMonster shell locked to one note-suite provider (email:password lists).
pub fn run_fixed_note_cloud(service: NoteExportService) -> eframe::Result<()> {
    run_fixed_cloud(WorkMode::Mega, service.cloud_provider())
}

#[derive(Clone)]
struct LogEntry {
    status: String,
    text: String,
    received: Option<u64>,
}

pub(crate) struct Stats {
    valid: usize,
    /// AUTH в†’ Bad.txt
    invalid: usize,
    /// NETWORK в†’ Error.txt
    errors: usize,
    /// ERROR / unclassified в†’ CantCheck.txt
    cant_check: usize,
    /// CAPTCHA / 2FA в†’ 2FA.txt
    two_fa: usize,
    total: usize,
}

impl Stats {
    fn from_results(results: &[ScanResult], total_targets: usize) -> Self {
        let mut s = Self {
            valid: 0,
            invalid: 0,
            errors: 0,
            cant_check: 0,
            two_fa: 0,
            total: total_targets,
        };
        for r in results {
            match r.status {
                ScanStatus::Valid => s.valid += 1,
                ScanStatus::InvalidCredentials => s.invalid += 1,
                ScanStatus::Unreachable => s.errors += 1,
                ScanStatus::Captcha => s.two_fa += 1,
                ScanStatus::Error | ScanStatus::NotPhpMyAdmin => s.cant_check += 1,
            }
        }
        s
    }

    fn progress_pct(&self) -> f32 {
        if self.total == 0 {
            0.0
        } else {
            self.checked() as f32 / self.total as f32 * 100.0
        }
    }

    fn checked(&self) -> usize {
        self.valid + self.invalid + self.errors + self.cant_check + self.two_fa
    }

    fn hit_rate_pct(&self) -> f32 {
        let n = self.checked();
        if n == 0 {
            0.0
        } else {
            self.valid as f32 / n as f32 * 100.0
        }
    }
}

struct QueuedJob {
    run_id: u64,
    cmd: WorkerCommand,
}

#[derive(Clone)]
struct RunUi {
    run_id: u64,
    tx: Sender<UiMessage>,
}

impl RunUi {
    fn progress_bridge(&self, cancel: Arc<AtomicBool>) -> ProgressCallback {
        let run_id = self.run_id;
        let tx = self.tx.clone();
        Arc::new(move |event| {
            if cancel.load(Ordering::Relaxed) {
                return;
            }
            let _ = tx.send(UiMessage::Progress {
                run_id,
                event,
            });
        })
    }

    fn loaded_targets(&self, count: usize, skipped: usize) {
        let _ = self.tx.send(UiMessage::LoadedTargets {
            run_id: self.run_id,
            count,
            skipped,
        });
    }

    fn results_dir(&self, path: PathBuf) {
        let _ = self.tx.send(UiMessage::ResultsDir {
            run_id: self.run_id,
            path,
        });
    }

    fn worker_error(&self, err: impl Into<String>) {
        let _ = self.tx.send(UiMessage::Error {
            run_id: self.run_id,
            text: err.into(),
        });
    }

    fn worker_done(&self) {
        let _ = self.tx.send(UiMessage::WorkerDone {
            run_id: self.run_id,
        });
    }
}

enum WorkerCommand {
    GitLab {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Jenkins {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    PhpMyAdmin {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        proxy: Option<String>,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Adminer {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        proxy: Option<String>,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    PhpPgAdmin {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        proxy: Option<String>,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Bitrix {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Bitbucket {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Jira {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Redmine {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        export_options: RedmineExportOptions,
        cancel: Arc<AtomicBool>,
    },
    Snowflake {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        export_options: SnowflakeExportOptions,
        cancel: Arc<AtomicBool>,
    },
    Confluence {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    OpenCart {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Workflowy {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    RoamResearch {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    SecondBrain {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    AppFlowy {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    NoteExport {
        service: NoteExportService,
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        proxy: Option<String>,
        proxy_list: Option<Arc<Vec<String>>>,
        cancel: Arc<AtomicBool>,
    },
    CrmExport {
        service: CrmExportService,
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        proxy: Option<String>,
        proxy_list: Option<Arc<Vec<String>>>,
        cancel: Arc<AtomicBool>,
    },
    WebApp {
        kind: AddServiceKind,
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    XWiki {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Bamboo {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Slack {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Fortinet {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        proxy: Option<String>,
        proxy_list: Option<Arc<Vec<String>>>,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Citrix {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        proxy: Option<String>,
        proxy_list: Option<Arc<Vec<String>>>,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
    Mega {
        provider: CloudProvider,
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        proxy: Option<String>,
        proxy_list: Option<Arc<Vec<String>>>,
        upload_dir: Option<PathBuf>,
        upload_files: bool,
        download_from_cloud: bool,
        download_filter: CloudDownloadFilter,
        cancel: Arc<AtomicBool>,
    },
    AdminPanel {
        input: PathBuf,
        output: PathBuf,
        threads: usize,
        export_timeout: u64,
        insecure: bool,
        download_files: bool,
        cancel: Arc<AtomicBool>,
    },
}

enum UiMessage {
    Progress {
        run_id: u64,
        event: ProgressEvent,
    },
    LoadedTargets {
        run_id: u64,
        count: usize,
        skipped: usize,
    },
    ResultsDir {
        run_id: u64,
        path: PathBuf,
    },
    Error {
        run_id: u64,
        text: String,
    },
    WorkerDone {
        run_id: u64,
    },
}

pub(crate) struct PmaApp {
    pub(crate) input_file: String,
    pub(crate) output_dir: String,
    pub(crate) threads: u32,
    pub(crate) timeout: u32,
    pub(crate) export_timeout: u32,
    pub(crate) retries: u32,
    pub(crate) insecure: bool,
    pub(crate) adminpanel_status: String,
    pub(crate) proxy: String,
    pub(crate) proxy_list_file: String,
    pub(crate) work_mode: WorkMode,
    pub(crate) fixed_mode: Option<WorkMode>,
    pub(crate) fixed_cloud_provider: Option<CloudProvider>,
    pub(crate) fixed_crm_service: Option<CrmExportService>,
    pub(crate) crm_service: CrmExportService,
    pub(crate) fixed_note_service: Option<NoteExportService>,
    pub(crate) note_service: NoteExportService,
    download_phpmyadmin: bool,
    download_adminer: bool,
    download_gitlab: bool,
    download_jenkins: bool,
    download_phppgadmin: bool,
    download_bitrix: bool,
    download_bitbucket: bool,
    download_jira: bool,
    download_redmine: bool,
    pub(crate) redmine_export_issues: bool,
    pub(crate) redmine_export_attachments: bool,
    pub(crate) redmine_export_wiki: bool,
    download_snowflake: bool,
    pub(crate) snowflake_export_databases: bool,
    pub(crate) snowflake_export_warehouses: bool,
    pub(crate) snowflake_export_roles: bool,
    download_confluence: bool,
    download_opencart: bool,
    download_workflowy: bool,
    download_roamresearch: bool,
    download_secondbrain: bool,
    download_appflowy: bool,
    download_note_export: bool,
    download_crm_export: bool,
    download_xwiki: bool,
    download_bamboo: bool,
    download_slack: bool,
    download_fortinet: bool,
    download_citrix: bool,
    download_mega: bool,
    download_webapp: bool,
    pub(crate) cloud_provider: CloudProvider,
    pub(crate) mega_upload_dir: String,
    pub(crate) cloud_filter_extensions: String,
    pub(crate) cloud_filter_keywords: String,
    pub(crate) cloud_filter_min_kb: u32,
    pub(crate) cloud_filter_max_mb: u32,
    megax_nav: megax::MegaxNav,
    pub(crate) megax_skip_proxy_precheck: bool,
    pub(crate) megax_auto_fetch_proxies: bool,
    pub(crate) megax_proxy_list_url: String,
    pub(crate) megax_proxy_interval_min: u32,
    pub(crate) megax_upload_no_proxy: bool,
    pub(crate) megax_download_no_proxy: bool,
    pub(crate) megax_low_render: bool,
    pub(crate) megax_proxy_protocol: megax::MegaxProxyProtocol,
    pub(crate) megax_proxy_line_format: megax::MegaxProxyLineFormat,
    pub(crate) megax_proxy_mode: megax::MegaxProxyMode,
    pub(crate) suite_parse: suite_proxy_parse::SuiteProxyParseState,
    pub(crate) target_count: usize,
    pub(crate) checks_in_flight: usize,
    pub(crate) scan_results: Vec<ScanResult>,
    pub(crate) logs: Vec<LogEntry>,
    log_expanded: bool,
    pub(crate) megax_profile_store: megax_profiles::MegaxProfileStore,
    pub(crate) megax_profile_draft_name: String,
    pub(crate) megax_profile_message: String,
    megax_session: megax_session::MegaxSession,
    pub(crate) busy: bool,
    active_run_id: u64,
    cancel_flag: Arc<AtomicBool>,
    started_at: Option<Instant>,
    pub(crate) run_analytics: megax::RunAnalytics,
    last_results_dir: Option<PathBuf>,
    cmd_tx: Sender<QueuedJob>,
    worker_abort_tx: Sender<()>,
    msg_rx: Receiver<UiMessage>,
}

impl PmaApp {
    fn new(
        fixed_mode: Option<WorkMode>,
        fixed_cloud_provider: Option<CloudProvider>,
        fixed_crm_service: Option<CrmExportService>,
        fixed_note_service: Option<NoteExportService>,
    ) -> Self {
        let (cmd_tx, cmd_rx) = mpsc::channel();
        let (abort_tx, abort_rx) = mpsc::channel();
        let (msg_tx, msg_rx) = mpsc::channel();
        thread::spawn(move || worker_loop(cmd_rx, abort_rx, msg_tx));

        let work_mode = fixed_mode.unwrap_or(WorkMode::PhpMyAdmin);
        let crm_service = fixed_crm_service.unwrap_or(CrmExportService::Pipedrive);
        let note_service = fixed_note_service.unwrap_or(NoteExportService::Obsidian);
        let default_threads = if matches!(fixed_mode, Some(WorkMode::Mega)) {
            64
        } else if matches!(fixed_mode, Some(WorkMode::AdminPanel)) {
            250
        } else {
            250
        };
        let default_output = if matches!(fixed_mode, Some(WorkMode::AdminPanel)) {
            r"G:\RESULTS".to_string()
        } else {
            String::new()
        };

        let mut app = Self {
            input_file: String::new(),
            output_dir: default_output,
            threads: if fixed_cloud_provider.is_some() {
                16
            } else {
                default_threads
            },
            timeout: 30,
            export_timeout: 120,
            retries: 2,
            insecure: false,
            adminpanel_status: String::new(),
            proxy: String::new(),
            proxy_list_file: String::new(),
            work_mode,
            fixed_mode,
            fixed_cloud_provider,
            fixed_crm_service,
            crm_service,
            fixed_note_service,
            note_service,
            download_phpmyadmin: true,
            download_adminer: true,
            download_gitlab: true,
            download_jenkins: true,
            download_phppgadmin: true,
            download_bitrix: true,
            download_bitbucket: true,
            download_jira: true,
            download_redmine: true,
            redmine_export_issues: true,
            redmine_export_attachments: true,
            redmine_export_wiki: true,
            download_snowflake: true,
            snowflake_export_databases: true,
            snowflake_export_warehouses: true,
            snowflake_export_roles: true,
            download_confluence: true,
            download_opencart: true,
            download_workflowy: true,
            download_roamresearch: true,
            download_secondbrain: true,
            download_appflowy: true,
            download_note_export: true,
            download_crm_export: true,
            download_xwiki: true,
            download_bamboo: true,
            download_slack: false,
            download_fortinet: true,
            download_citrix: false,
            download_mega: true,
            download_webapp: true,
            cloud_provider: fixed_cloud_provider.unwrap_or(CloudProvider::Mega),
            mega_upload_dir: String::new(),
            cloud_filter_extensions: String::new(),
            cloud_filter_keywords: String::new(),
            cloud_filter_min_kb: 0,
            cloud_filter_max_mb: 0,
            megax_nav: megax::MegaxNav::Checker,
            megax_skip_proxy_precheck: false,
            megax_auto_fetch_proxies: false,
            megax_proxy_list_url: String::new(),
            megax_proxy_interval_min: 2,
            megax_upload_no_proxy: false,
            megax_download_no_proxy: false,
            megax_low_render: false,
            megax_proxy_protocol: megax::MegaxProxyProtocol::default(),
            megax_proxy_line_format: megax::MegaxProxyLineFormat::default(),
            megax_proxy_mode: if fixed_cloud_provider.is_some() {
                megax::MegaxProxyMode::Direct
            } else {
                megax::MegaxProxyMode::default()
            },
            suite_parse: suite_proxy_parse::SuiteProxyParseState::default(),
            target_count: 0,
            checks_in_flight: 0,
            scan_results: Vec::new(),
            logs: Vec::new(),
            log_expanded: false,
            megax_profile_store: megax_profiles::MegaxProfileStore::default(),
            megax_profile_draft_name: megax_profiles::DEFAULT_PROFILE_NAME.to_string(),
            megax_profile_message: String::new(),
            megax_session: megax_session::load(),
            busy: false,
            active_run_id: 0,
            cancel_flag: Arc::new(AtomicBool::new(false)),
            started_at: None,
            run_analytics: megax::RunAnalytics::default(),
            last_results_dir: None,
            cmd_tx,
            worker_abort_tx: abort_tx,
            msg_rx,
        };
        app.megax_profiles_init();
        app
    }

    pub(crate) fn push_log(&mut self, status: &str, text: impl Into<String>, received: Option<u64>) {
        self.logs.push(LogEntry {
            status: status.to_string(),
            text: text.into(),
            received,
        });
    }

    fn poll_messages(&mut self, ctx: &egui::Context) {
        let mut got = false;
        let active = self.active_run_id;
        while let Ok(msg) = self.msg_rx.try_recv() {
            got = true;
            match msg {
                UiMessage::Progress { run_id, event } if run_id == active => {
                    self.handle_progress(event)
                }
                UiMessage::LoadedTargets {
                    run_id,
                    count,
                    skipped: _,
                } if run_id == active => {
                    self.target_count = count;
                }
                UiMessage::ResultsDir { run_id, path } if run_id == active => {
                    self.last_results_dir = Some(path);
                }
                UiMessage::Error { run_id, text } if run_id == active => {
                    if adminpanel::is_adminpanel(self) {
                        self.adminpanel_status = text;
                    } else {
                        self.push_log("Error", text, None);
                    }
                }
                UiMessage::WorkerDone { run_id } if run_id == active => {
                    self.busy = false;
                    self.started_at = None;
                }
                UiMessage::Progress { .. }
                | UiMessage::LoadedTargets { .. }
                | UiMessage::ResultsDir { .. }
                | UiMessage::Error { .. }
                | UiMessage::WorkerDone { .. } => {}
            }
        }
        if got {
            ctx.request_repaint();
        }
    }

    fn handle_progress(&mut self, event: ProgressEvent) {
        if self.fixed_mode == Some(WorkMode::Mega) {
            self.handle_progress_megax(event);
            return;
        }
        if adminpanel::is_adminpanel(self) {
            self.handle_progress_adminpanel(event);
            return;
        }
        match event {
            ProgressEvent::Good {
                target,
                detail,
                bytes,
            } => {
                self.push_log("Good", format!("{target} вЂ” {detail}"), bytes);
            }
            ProgressEvent::ScanResult(result) => {
                self.checks_in_flight = self.checks_in_flight.saturating_sub(1);
                agent_log_gui(
                    "H-B",
                    "pma-gui:handle_progress",
                    "scan result",
                    serde_json::json!({
                        "status": format!("{:?}", result.status),
                        "checks_in_flight": self.checks_in_flight,
                    }),
                );
                if let Some(pos) = self
                    .scan_results
                    .iter()
                    .position(|r| r.credential.display_line() == result.credential.display_line())
                {
                    self.scan_results[pos] = result;
                } else {
                    self.scan_results.push(result);
                }
            }
            ProgressEvent::DumpFailed { .. } => {
                self.checks_in_flight = self.checks_in_flight.saturating_sub(1);
            }
            ProgressEvent::DumpStarted { .. } => {
                self.checks_in_flight = self.checks_in_flight.saturating_add(1);
                agent_log_gui(
                    "H-B",
                    "pma-gui:handle_progress",
                    "dump started",
                    serde_json::json!({ "checks_in_flight": self.checks_in_flight }),
                );
            }
            ProgressEvent::Log(line) => {
                self.push_log("Info", line, None);
            }
            ProgressEvent::ScanComplete { .. }
            | ProgressEvent::DumpComplete { .. }
            | ProgressEvent::AllComplete => {
                // Visible log is Good-only for successes; failures also logged above.
            }
        }
    }

    /// AdminPanel: update counters only вЂ” no on-screen log.
    fn handle_progress_adminpanel(&mut self, event: ProgressEvent) {
        match event {
            ProgressEvent::ScanResult(result) => {
                self.checks_in_flight = self.checks_in_flight.saturating_sub(1);
                if let Some(pos) = self
                    .scan_results
                    .iter()
                    .position(|r| r.credential.display_line() == result.credential.display_line())
                {
                    self.scan_results[pos] = result;
                } else {
                    self.scan_results.push(result);
                }
            }
            ProgressEvent::DumpFailed { .. } => {
                self.checks_in_flight = self.checks_in_flight.saturating_sub(1);
            }
            ProgressEvent::DumpStarted { .. } => {
                self.checks_in_flight = self.checks_in_flight.saturating_add(1);
            }
            ProgressEvent::Good { .. }
            | ProgressEvent::Log(_)
            | ProgressEvent::ScanComplete { .. }
            | ProgressEvent::DumpComplete { .. }
            | ProgressEvent::AllComplete => {}
        }
    }

    /// MEGA / CloudMonster GUI log: combo line only (details stay in Errors.log on disk).
    fn handle_progress_megax(&mut self, event: ProgressEvent) {
        match event {
            ProgressEvent::Good { target, bytes, .. } => {
                self.push_log("Good", target, bytes);
            }
            ProgressEvent::ScanResult(result) => {
                self.checks_in_flight = self.checks_in_flight.saturating_sub(1);
                if let Some(pos) = self
                    .scan_results
                    .iter()
                    .position(|r| r.credential.display_line() == result.credential.display_line())
                {
                    self.scan_results[pos] = result;
                } else {
                    self.scan_results.push(result);
                }
            }
            ProgressEvent::DumpFailed { target, error, .. } => {
                self.checks_in_flight = self.checks_in_flight.saturating_sub(1);
                let tag = cloud_log_tag(&error);
                self.push_log(tag, target, None);
            }
            ProgressEvent::DumpStarted { .. } => {
                self.checks_in_flight = self.checks_in_flight.saturating_add(1);
            }
            ProgressEvent::Log(line) => {
                if line.starts_with("Error log:") {
                    return;
                }
                self.push_log("Info", line, None);
            }
            ProgressEvent::ScanComplete { .. }
            | ProgressEvent::DumpComplete { .. }
            | ProgressEvent::AllComplete => {}
        }
    }

    pub(crate) fn pick_proxy_list_file(&mut self) {
        if let Some(path) = rfd::FileDialog::new()
            .add_filter("Text", &["txt"])
            .pick_file()
        {
            self.proxy_list_file = path.display().to_string();
        }
    }

    pub(crate) fn pick_input_file(&mut self) {
        if let Some(path) = rfd::FileDialog::new()
            .add_filter("Text lists", &["txt"])
            .pick_file()
        {
            self.input_file = path.display().to_string();
        }
    }

    pub(crate) fn pick_output_dir(&mut self) {
        if let Some(path) = rfd::FileDialog::new().pick_folder() {
            self.output_dir = path.display().to_string();
        }
    }

    pub(crate) fn redmine_export_options(&self) -> RedmineExportOptions {
        RedmineExportOptions {
            issues: self.redmine_export_issues,
            attachments: self.redmine_export_attachments,
            wiki: self.redmine_export_wiki,
        }
    }

    pub(crate) fn snowflake_export_options(&self) -> SnowflakeExportOptions {
        SnowflakeExportOptions {
            databases: self.snowflake_export_databases,
            warehouses: self.snowflake_export_warehouses,
            roles: self.snowflake_export_roles,
        }
    }

    fn download_files_enabled(&self) -> bool {
        if self.work_mode == WorkMode::NoteCheck {
            return self.download_note_export;
        }
        if self.work_mode == WorkMode::CrmCheck {
            return self.download_crm_export;
        }
        if note_export_gui::note_export_service_for_mode(self.work_mode).is_some() {
            return self.download_note_export;
        }
        match self.work_mode {
            WorkMode::PhpMyAdmin => self.download_phpmyadmin,
            WorkMode::Adminer => self.download_adminer,
            WorkMode::GitLab => self.download_gitlab,
            WorkMode::Jenkins => self.download_jenkins,
            WorkMode::PhpPgAdmin => self.download_phppgadmin,
            WorkMode::Bitrix => self.download_bitrix,
            WorkMode::Bitbucket => self.download_bitbucket,
            WorkMode::Jira => self.download_jira,
            WorkMode::Redmine => self.download_redmine,
            WorkMode::Snowflake => self.download_snowflake,
            WorkMode::Confluence => self.download_confluence,
            WorkMode::OpenCart => self.download_opencart,
            WorkMode::Workflowy => self.download_workflowy,
            WorkMode::RoamResearch => self.download_roamresearch,
            WorkMode::SecondBrain => self.download_secondbrain,
            WorkMode::AppFlowy => self.download_appflowy,
            WorkMode::XWiki => self.download_xwiki,
            WorkMode::Bamboo => self.download_bamboo,
            WorkMode::Slack => self.download_slack,
            WorkMode::Fortinet => self.download_fortinet,
            WorkMode::Citrix => self.download_citrix,
            WorkMode::Mega => self.download_mega,
            WorkMode::Owa
            | WorkMode::Kibana
            | WorkMode::Zabbix
            | WorkMode::Zimbra
            | WorkMode::Drupal
            | WorkMode::Grafana
            | WorkMode::SonarQube
            | WorkMode::Mattermost => self.download_webapp,
            WorkMode::AdminPanel => false,
            WorkMode::NoteCheck => self.download_note_export,
            WorkMode::CrmCheck => self.download_crm_export,
            WorkMode::Obsidian
            | WorkMode::Dynalist
            | WorkMode::Capacities
            | WorkMode::Gnotes
            | WorkMode::Joplin
            | WorkMode::Kortex
            | WorkMode::Mindlog
            | WorkMode::Notejoy
            | WorkMode::Notesnook
            | WorkMode::StandardNotes
            | WorkMode::Todoist
            | WorkMode::Turtl
            | WorkMode::Zotero => self.download_note_export,
        }
    }

    pub(crate) fn download_files_enabled_mut(&mut self) -> &mut bool {
        if self.work_mode == WorkMode::NoteCheck {
            return &mut self.download_note_export;
        }
        if self.work_mode == WorkMode::CrmCheck {
            return &mut self.download_crm_export;
        }
        if note_export_gui::note_export_service_for_mode(self.work_mode).is_some() {
            return &mut self.download_note_export;
        }
        match self.work_mode {
            WorkMode::PhpMyAdmin => &mut self.download_phpmyadmin,
            WorkMode::Adminer => &mut self.download_adminer,
            WorkMode::GitLab => &mut self.download_gitlab,
            WorkMode::Jenkins => &mut self.download_jenkins,
            WorkMode::PhpPgAdmin => &mut self.download_phppgadmin,
            WorkMode::Bitrix => &mut self.download_bitrix,
            WorkMode::Bitbucket => &mut self.download_bitbucket,
            WorkMode::Jira => &mut self.download_jira,
            WorkMode::Redmine => &mut self.download_redmine,
            WorkMode::Snowflake => &mut self.download_snowflake,
            WorkMode::Confluence => &mut self.download_confluence,
            WorkMode::OpenCart => &mut self.download_opencart,
            WorkMode::Workflowy => &mut self.download_workflowy,
            WorkMode::RoamResearch => &mut self.download_roamresearch,
            WorkMode::SecondBrain => &mut self.download_secondbrain,
            WorkMode::AppFlowy => &mut self.download_appflowy,
            WorkMode::XWiki => &mut self.download_xwiki,
            WorkMode::Bamboo => &mut self.download_bamboo,
            WorkMode::Slack => &mut self.download_slack,
            WorkMode::Fortinet => &mut self.download_fortinet,
            WorkMode::Citrix => &mut self.download_citrix,
            WorkMode::Mega => &mut self.download_mega,
            WorkMode::Owa
            | WorkMode::Kibana
            | WorkMode::Zabbix
            | WorkMode::Zimbra
            | WorkMode::Drupal
            | WorkMode::Grafana
            | WorkMode::SonarQube
            | WorkMode::Mattermost => &mut self.download_webapp,
            WorkMode::AdminPanel => &mut self.download_phpmyadmin,
            WorkMode::NoteCheck => &mut self.download_note_export,
            WorkMode::CrmCheck => &mut self.download_crm_export,
            WorkMode::Obsidian
            | WorkMode::Dynalist
            | WorkMode::Capacities
            | WorkMode::Gnotes
            | WorkMode::Joplin
            | WorkMode::Kortex
            | WorkMode::Mindlog
            | WorkMode::Notejoy
            | WorkMode::Notesnook
            | WorkMode::StandardNotes
            | WorkMode::Todoist
            | WorkMode::Turtl
            | WorkMode::Zotero => &mut self.download_note_export,
        }
    }

    pub(crate) fn pick_mega_upload_dir(&mut self) {
        if let Some(path) = rfd::FileDialog::new().pick_folder() {
            self.mega_upload_dir = path.display().to_string();
        }
    }

    pub(crate) fn start_work(&mut self) {
        if self.busy {
            return;
        }
        self.enforce_fixed_cloud_provider();
        self.enforce_fixed_crm_service();
        self.enforce_fixed_note_service();

        let input = match self.input_path() {
            Ok(p) => p,
            Err(err) => {
                self.report_run_error(err);
                return;
            }
        };

        let output = match self.output_path() {
            Ok(p) => p,
            Err(err) => {
                self.report_run_error(err);
                return;
            }
        };

        if self.work_mode == WorkMode::Redmine
            && self.download_files_enabled()
            && !self.redmine_export_options().any_selected()
        {
            self.report_run_error(
                "Select at least one Redmine export: issues, attachments, or wiki".to_string(),
            );
            return;
        }

        if self.work_mode == WorkMode::Snowflake
            && self.download_files_enabled()
            && !self.snowflake_export_options().any_selected()
        {
            self.report_run_error(
                "Select at least one Snowflake export: databases, warehouses, or roles"
                    .to_string(),
            );
            return;
        }

        self.adminpanel_status.clear();
        self.scan_results.clear();
        self.checks_in_flight = 0;
        self.run_analytics.reset();
        self.active_run_id = self.active_run_id.wrapping_add(1);
        let run_id = self.active_run_id;
        self.cancel_flag = Arc::new(AtomicBool::new(false));
        self.busy = true;
        self.started_at = Some(Instant::now());

        let threads = self.threads as usize;
        let export_timeout = self.export_timeout as u64;
        let insecure = self.insecure;
        let use_megax_proxy = self.fixed_mode == Some(WorkMode::Mega) || self.work_mode == WorkMode::Mega;
        let proxy_scheme = if use_megax_proxy {
            self.megax_proxy_protocol.to_net()
        } else {
            pma_net::ProxyListScheme::Socks5
        };
        let proxy_format = if use_megax_proxy {
            self.megax_proxy_line_format.to_net()
        } else {
            pma_net::ProxyListFormat::HostPort
        };
        let mut proxy = if use_megax_proxy {
            normalize_proxy_field(&self.proxy, proxy_scheme, proxy_format)
        } else {
            optional_proxy(&self.proxy)
        };
        let mut proxy_list = match load_gui_proxy_list(&self.proxy_list_file, proxy_scheme, proxy_format)
        {
            Ok(list) => list,
            Err(err) => {
                self.push_log("Error", format!("{err:#}"), None);
                self.busy = false;
                self.started_at = None;
                return;
            }
        };
        if use_megax_proxy {
            if self.fixed_cloud_provider.is_some()
                && matches!(self.megax_proxy_mode, megax::MegaxProxyMode::ProxyFile)
                && self.proxy_list_file.trim().is_empty()
            {
                self.megax_proxy_mode = megax::MegaxProxyMode::Direct;
                self.push_log(
                    "Info",
                    "Dedicated app: proxy file empty — using direct connection".to_string(),
                    None,
                );
            }
            match self.megax_proxy_mode {
                megax::MegaxProxyMode::Direct => {
                    proxy = None;
                    proxy_list = None;
                }
                megax::MegaxProxyMode::Single => {
                    proxy_list = None;
                }
                megax::MegaxProxyMode::ProxyFile => {
                    proxy = None;
                }
            }
            if matches!(self.megax_proxy_mode, megax::MegaxProxyMode::ProxyFile)
                && self.proxy_list_file.trim().is_empty()
            {
                self.push_log(
                    "Error",
                    "Proxy mode is В«fileВ» вЂ” select a proxy list file, or choose В«No proxy (direct)В»",
                    None,
                );
                self.busy = false;
                self.started_at = None;
                return;
            }
            if matches!(self.megax_proxy_mode, megax::MegaxProxyMode::Single)
                && proxy.as_ref().is_none_or(|p| p.trim().is_empty())
            {
                self.push_log(
                    "Error",
                    "Proxy mode is В«singleВ» вЂ” enter a proxy URL, or choose В«No proxy (direct)В»",
                    None,
                );
                self.busy = false;
                self.started_at = None;
                return;
            }
            if self.megax_upload_no_proxy || self.megax_download_no_proxy {
                proxy = None;
                proxy_list = None;
            }
        }
        let download_files = self.download_files_enabled();
        let cancel = self.cancel_flag.clone();

        if self.work_mode == WorkMode::NoteCheck {
            let (note_proxy, note_proxy_list) = match self.suite_proxies_for_run() {
                Ok(v) => v,
                Err(err) => {
                    self.push_log("Error", format!("{err:#}"), None);
                    self.busy = false;
                    self.started_at = None;
                    return;
                }
            };
            let _ = self.cmd_tx.send(QueuedJob {
                run_id,
                cmd: WorkerCommand::NoteExport {
                    service: self.note_service,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    proxy: note_proxy,
                    proxy_list: note_proxy_list,
                    cancel,
                },
            });
            return;
        }

        if self.work_mode == WorkMode::CrmCheck {
            let (crm_proxy, crm_proxy_list) = match self.suite_proxies_for_run() {
                Ok(v) => v,
                Err(err) => {
                    self.push_log("Error", format!("{err:#}"), None);
                    self.busy = false;
                    self.started_at = None;
                    return;
                }
            };
            let _ = self.cmd_tx.send(QueuedJob {
                run_id,
                cmd: WorkerCommand::CrmExport {
                    service: self.crm_service,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    proxy: crm_proxy,
                    proxy_list: crm_proxy_list,
                    cancel,
                },
            });
            return;
        }

        if let Some(service) = note_export_gui::note_export_service_for_mode(self.work_mode) {
            let _ = self.cmd_tx.send(QueuedJob {
                run_id,
                cmd: WorkerCommand::NoteExport {
                    service,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    proxy: None,
                    proxy_list: None,
                    cancel,
                },
            });
            return;
        }

        match self.work_mode {
            WorkMode::PhpMyAdmin => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::PhpMyAdmin {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Adminer => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Adminer {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::GitLab => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::GitLab {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Jenkins => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Jenkins {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::PhpPgAdmin => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::PhpPgAdmin {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Bitrix => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Bitrix {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Bitbucket => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Bitbucket {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Jira => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Jira {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Redmine => {
                let export_options = self.redmine_export_options();
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Redmine {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    export_options,
                    cancel,
                    },
                });
            }
            WorkMode::Snowflake => {
                let export_options = self.snowflake_export_options();
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Snowflake {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    export_options,
                    cancel,
                    },
                });
            }
            WorkMode::Confluence => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Confluence {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::OpenCart => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::OpenCart {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::Workflowy => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Workflowy {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::RoamResearch => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::RoamResearch {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::SecondBrain => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::SecondBrain {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::AppFlowy => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::AppFlowy {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::XWiki => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::XWiki {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Bamboo => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Bamboo {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Slack => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Slack {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Fortinet => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Fortinet {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy: proxy.clone(),
                    proxy_list: proxy_list.clone(),
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Citrix => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Citrix {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    proxy_list,
                    download_files,
                    cancel,
                    },
                });
            }
            WorkMode::Owa
            | WorkMode::Kibana
            | WorkMode::Zabbix
            | WorkMode::Zimbra
            | WorkMode::Drupal
            | WorkMode::Grafana
            | WorkMode::SonarQube
            | WorkMode::Mattermost => {
                let kind = self.work_mode.add_service_kind().expect("webapp kind");
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::WebApp {
                        kind,
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                    },
                });
            }
            WorkMode::AdminPanel => {
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::AdminPanel {
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files: false,
                        cancel,
                    },
                });
            }
            WorkMode::Obsidian
            | WorkMode::Dynalist
            | WorkMode::Capacities
            | WorkMode::Gnotes
            | WorkMode::Joplin
            | WorkMode::Kortex
            | WorkMode::Mindlog
            | WorkMode::Notejoy
            | WorkMode::Notesnook
            | WorkMode::StandardNotes
            | WorkMode::Todoist
            | WorkMode::Turtl
            | WorkMode::Zotero
            | WorkMode::NoteCheck
            | WorkMode::CrmCheck => {}
            WorkMode::Mega => {
                let upload_files = download_files && self.cloud_provider.supports_upload();
                let download_from_cloud = download_files && !upload_files;
                let download_filter = CloudDownloadFilter::from_gui(
                    self.cloud_filter_min_kb as u64,
                    self.cloud_filter_max_mb as u64,
                    &self.cloud_filter_extensions,
                    &self.cloud_filter_keywords,
                );
                let upload_dir = if upload_files {
                    if self.mega_upload_dir.trim().is_empty() {
                        self.push_log(
                            "Error",
                            "Select folder with files to upload to MEGA".to_string(),
                            None,
                        );
                        self.busy = false;
                        self.started_at = None;
                        return;
                    }
                    Some(PathBuf::from(self.mega_upload_dir.trim()))
                } else {
                    None
                };
                let _ = self.cmd_tx.send(QueuedJob {
                    run_id,
                    cmd: WorkerCommand::Mega {
                    provider: self.effective_cloud_provider(),
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    proxy_list,
                    upload_dir,
                    upload_files,
                    download_from_cloud,
                    download_filter,
                    cancel,
                    },
                });
            }
        }
    }

    pub(crate) fn stop_work(&mut self) {
        if self.busy {
            self.cancel_flag.store(true, Ordering::Relaxed);
        }
    }

    fn report_run_error(&mut self, err: String) {
        if adminpanel::is_adminpanel(self) {
            self.adminpanel_status = err;
        } else {
            self.push_log("Error", err, None);
        }
    }

    fn signal_worker_abort(&self) {
        let _ = self.worker_abort_tx.send(());
    }

    /// Cancel worker and unlock UI immediately (worker may still finish in background).
    pub(crate) fn megax_force_stop(&mut self) {
        if !self.busy {
            return;
        }
        self.cancel_flag.store(true, Ordering::Relaxed);
        self.signal_worker_abort();
        self.active_run_id = self.active_run_id.wrapping_add(1);
        self.busy = false;
        self.checks_in_flight = 0;
        self.started_at = None;
        self.push_log("Info", "Force stop вЂ” run cancelled", None);
    }

    fn input_path(&self) -> Result<PathBuf, String> {
        if self.input_file.trim().is_empty() {
            return Err("Select a target list file".into());
        }
        Ok(PathBuf::from(&self.input_file))
    }

    fn output_path(&self) -> Result<PathBuf, String> {
        if self.output_dir.trim().is_empty() {
            return Err("Select an output directory".into());
        }
        Ok(PathBuf::from(&self.output_dir))
    }

    fn elapsed(&self) -> String {
        match self.started_at {
            Some(t) => format_duration(t.elapsed()),
            None => "00:00:00".into(),
        }
    }

    pub(crate) fn elapsed_public(&self) -> String {
        self.elapsed()
    }

    pub(crate) fn megax_reset(&mut self) {
        if self.busy {
            self.stop_work();
            self.signal_worker_abort();
        }
        self.logs.clear();
        self.scan_results.clear();
        self.checks_in_flight = 0;
        self.started_at = None;
        self.run_analytics.reset();
    }

    pub(crate) fn scan_results_ref(&self) -> &[ScanResult] {
        &self.scan_results
    }

    pub(crate) fn megax_clear_results(&mut self) {
        self.scan_results.clear();
        self.target_count = 0;
        self.checks_in_flight = 0;
    }

    pub(crate) fn open_results_folder(&self) {
        let path = self
            .last_results_dir
            .clone()
            .or_else(|| self.output_path().ok())
            .unwrap_or_else(|| PathBuf::from("."));
        open_folder(&path);
    }
}

impl eframe::App for PmaApp {
    fn clear_color(&self, _visuals: &egui::Visuals) -> [f32; 4] {
        [0.0, 0.0, 0.0, 0.0]
    }

    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.poll_messages(ctx);
        suite_proxy_parse::poll(self, ctx);

        if self.busy {
            ctx.request_repaint_after(Duration::from_millis(800));
        }

        if self.fixed_mode == Some(WorkMode::AdminPanel) {
            adminpanel::update(self, ctx);
            return;
        }

        export_shell::update(self, ctx);
        self.enforce_fixed_cloud_provider();
    }
}

fn cloud_log_tag(error: &str) -> &'static str {
    let lower = error.to_lowercase();
    if lower.contains("cloud rate limit")
        || lower.contains("cloud network:")
        || lower.contains("429")
        || lower.contains("cloudflare")
        || lower.contains("unreachable")
        || lower.contains("timeout")
        || lower.contains("connect")
    {
        "NETWORK"
    } else if lower.contains("cloud format") {
        "FORMAT"
    } else if lower.contains("cloud auth") {
        "AUTH"
    } else {
        "FAIL"
    }
}

fn status_color(status: &str) -> egui::Color32 {
    match status {
        "Good" | "Export" | "OK" => harmony::SUCCESS,
        "NETWORK" => harmony::DANGER,
        "FORMAT" => harmony::MUTED,
        "AUTH" | "FAIL" => harmony::PRIMARY_LIGHT,
        "Error" | "Bad" => harmony::DANGER,
        "Info" => harmony::SECONDARY,
        "Captcha" => harmony::PRIMARY_LIGHT,
        _ => harmony::MUTED,
    }
}

pub(crate) fn format_logs_for_clipboard(logs: &[LogEntry]) -> String {
    logs.iter()
        .map(|e| {
            let recv = e
                .received
                .map(format_bytes)
                .unwrap_or_else(|| "вЂ”".to_string());
            format!("{}\t{}\t{}", e.status, e.text, recv)
        })
        .collect::<Vec<_>>()
        .join("\n")
}

pub(crate) fn cloud_provider_combo(ui: &mut egui::Ui, current: &mut CloudProvider) {
    let label = current.label();
    egui::ComboBox::from_id_salt("cloud_provider")
        .selected_text(label)
        .width(ui.available_width())
        .show_ui(ui, |ui| {
            for provider in CloudProvider::ALL {
                ui.selectable_value(current, provider, provider.label());
            }
        });
}

pub(crate) fn note_service_combo(ui: &mut egui::Ui, current: &mut NoteExportService) {
    let label = current.label();
    egui::ComboBox::from_id_salt("note_service")
        .selected_text(label)
        .width(ui.available_width())
        .show_ui(ui, |ui| {
            for service in NoteExportService::ALL {
                ui.selectable_value(current, service, service.label());
            }
        });
}

pub(crate) fn crm_service_combo(ui: &mut egui::Ui, current: &mut CrmExportService) {
    let label = current.label();
    egui::ComboBox::from_id_salt("crm_service")
        .selected_text(label)
        .width(ui.available_width())
        .show_ui(ui, |ui| {
            for service in CrmExportService::ALL {
                ui.selectable_value(current, service, service.label());
            }
        });
}

fn mode_picker_combo(ui: &mut egui::Ui, current: &mut WorkMode) {
    let w = ui.available_width();
    egui::ComboBox::from_id_salt("work_mode_combo")
        .selected_text(
            egui::RichText::new(work_mode_label(*current))
                .color(harmony::TEXT),
        )
        .width(w)
        .show_ui(ui, |ui| {
            for (mode, label) in WORK_MODES {
                ui.selectable_value(current, mode, label);
            }
        });
}

pub(crate) fn truncate_middle(s: &str, max: usize) -> String {
    if s.len() <= max {
        return s.to_string();
    }
    let keep = max.saturating_sub(3) / 2;
    format!("{}...{}", &s[..keep], &s[s.len() - keep..])
}

fn load_gui_proxy_list(
    path: &str,
    scheme: pma_net::ProxyListScheme,
    format: pma_net::ProxyListFormat,
) -> Result<Option<Arc<Vec<String>>>> {
    let t = path.trim();
    if t.is_empty() {
        return Ok(None);
    }
    Ok(Some(Arc::new(load_proxy_list_with(
        Path::new(t),
        scheme,
        format,
    )?)))
}

fn optional_proxy(s: &str) -> Option<String> {
    let t = s.trim();
    if t.is_empty() {
        None
    } else {
        Some(t.to_string())
    }
}

fn format_duration(d: Duration) -> String {
    let secs = d.as_secs();
    format!(
        "{:02}:{:02}:{:02}",
        secs / 3600,
        (secs % 3600) / 60,
        secs % 60
    )
}

fn format_bytes(n: u64) -> String {
    if n >= 1_048_576 {
        format!("{:.1} MB", n as f64 / 1_048_576.0)
    } else if n >= 1024 {
        format!("{:.1} KB", n as f64 / 1024.0)
    } else {
        format!("{n} B")
    }
}

fn open_folder(path: &Path) {
    let path_str = path.display().to_string();
    #[cfg(target_os = "windows")]
    let _ = std::process::Command::new("explorer").arg(path_str).spawn();
    #[cfg(target_os = "macos")]
    let _ = std::process::Command::new("open").arg(path_str).spawn();
    #[cfg(target_os = "linux")]
    let _ = std::process::Command::new("xdg-open").arg(path_str).spawn();
}

struct RunningJob {
    handle: tokio::task::JoinHandle<()>,
    run_id: u64,
}

fn abort_running_job(
    current: &mut Option<RunningJob>,
    msg_tx: &Sender<UiMessage>,
) {
    if let Some(running) = current.take() {
        running.handle.abort();
        let _ = msg_tx.send(UiMessage::WorkerDone {
            run_id: running.run_id,
        });
    }
}

fn worker_loop(
    cmd_rx: Receiver<QueuedJob>,
    abort_rx: Receiver<()>,
    msg_tx: Sender<UiMessage>,
) {
    let rt = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .expect("tokio runtime");

    let mut current: Option<RunningJob> = None;

    loop {
        match cmd_rx.recv_timeout(Duration::from_millis(100)) {
            Err(RecvTimeoutError::Timeout) => {
                if abort_rx.try_recv().is_ok() {
                    abort_running_job(&mut current, &msg_tx);
                }
            }
            Err(RecvTimeoutError::Disconnected) => break,
            Ok(job) => {
                // РЎР±СЂРѕСЃ СЃС‚Р°СЂС‹С… abort РѕС‚ Force stop вЂ” РёРЅР°С‡Рµ СѓР±РёРІР°СЋС‚ С‚РѕР»СЊРєРѕ С‡С‚Рѕ Р·Р°РїСѓС‰РµРЅРЅС‹Р№ run.
                while abort_rx.try_recv().is_ok() {}
                abort_running_job(&mut current, &msg_tx);
                let run_id = job.run_id;
                let ui_done = RunUi {
                    run_id,
                    tx: msg_tx.clone(),
                };
                let handle = rt.spawn(async move {
                    let ui = ui_done.clone();
                    let result = async {
                        match job.cmd {
                WorkerCommand::GitLab {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_gitlab(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Jenkins {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_jenkins(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::PhpMyAdmin {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    download_files,
                    cancel,
                } => {
                    run_phpmyadmin(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        proxy,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Adminer {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    download_files,
                    cancel,
                } => {
                    run_adminer(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        proxy,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::PhpPgAdmin {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    download_files,
                    cancel,
                } => {
                    run_phppgadmin(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        proxy,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Bitrix {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_bitrix(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Bitbucket {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_bitbucket(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Jira {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_jira(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Redmine {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    export_options,
                    cancel,
                } => {
                    run_redmine(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        export_options,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Snowflake {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    export_options,
                    cancel,
                } => {
                    run_snowflake(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        export_options,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Confluence {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_confluence(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::OpenCart {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_opencart(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Workflowy {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_workflowy(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::RoamResearch {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_roamresearch(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::SecondBrain {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_secondbrain(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::AppFlowy {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_appflowy(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::NoteExport {
                    service,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    proxy,
                    proxy_list,
                    cancel,
                } => {
                    run_note_export(
                        service,
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        proxy,
                        proxy_list,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::CrmExport {
                    service,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    proxy,
                    proxy_list,
                    cancel,
                } => {
                    run_crm_export(
                        service,
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        proxy,
                        proxy_list,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::WebApp {
                    kind,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_webapp(
                        kind,
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::XWiki {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_xwiki(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Bamboo {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_bamboo(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Slack {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_slack(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Fortinet {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    proxy_list,
                    download_files,
                    cancel,
                } => {
                    run_fortinet(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        proxy,
                        proxy_list,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Citrix {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    proxy_list,
                    download_files,
                    cancel,
                } => {
                    run_citrix(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        proxy,
                        proxy_list,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::Mega {
                    provider,
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    proxy,
                    proxy_list,
                    upload_dir,
                    upload_files,
                    download_from_cloud,
                    download_filter,
                    cancel,
                } => {
                    run_cloud(
                        provider,
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        proxy,
                        proxy_list,
                        upload_dir,
                        upload_files,
                        download_from_cloud,
                        download_filter,
                        cancel,
                        &ui,
                    )
                    .await
                }
                WorkerCommand::AdminPanel {
                    input,
                    output,
                    threads,
                    export_timeout,
                    insecure,
                    download_files,
                    cancel,
                } => {
                    run_adminpanel_job(
                        input,
                        output,
                        threads,
                        export_timeout,
                        insecure,
                        download_files,
                        cancel,
                        &ui,
                    )
                    .await
                }
                        }
                    }
                    .await;

                    if let Err(err) = result {
                        ui_done.worker_error(format!("{err:#}"));
                    }
                    ui_done.worker_done();
                });
                current = Some(RunningJob { handle, run_id });
            }
        }
    }
}

async fn run_adminpanel_job(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_mixed_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    let work_total = summary.targets.len() + summary.unclassified_lines.len();
    ui.loaded_targets(work_total, summary.skipped.saturating_sub(summary.unclassified));
    ui.results_dir(output.clone());

    let settings = MixedCheckSettings {
        export_timeout_secs: export_timeout,
        insecure,
        download_files,
    };
    download_mixed_checks(
        summary.targets,
        summary.unclassified_lines,
        output,
        settings,
        threads,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_jenkins(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_jenkins_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_jenkins,
    );

    let config = Arc::new(JenkinsClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_jenkins_jobs(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_phppgadmin(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    proxy: Option<String>,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_phppgadmin_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_pgadmin,
    );

    let config = Arc::new(PhpPgAdminClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
        proxy,
    });
    ui.results_dir(output.clone());
    download_phppgadmin_dumps(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_phpmyadmin(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    proxy: Option<String>,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_phpmyadmin_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(summary.credentials.len(), summary.skipped);

    let config = Arc::new(PhpMyAdminClientConfig {
        timeout: Duration::from_secs(export_timeout),
        export_timeout: Duration::from_secs(export_timeout),
        user_agent: None,
        insecure,
        login_retries: 3,
        proxy,
    });
    ui.results_dir(output.clone());
    download_phpmyadmin_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_adminer(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    proxy: Option<String>,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_adminer_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_adminer,
    );

    let config = Arc::new(AdminerClientConfig {
        timeout: Duration::from_secs(export_timeout),
        export_timeout: Duration::from_secs(export_timeout),
        insecure,
        proxy,
    });
    ui.results_dir(output.clone());
    download_adminer_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_bitrix(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_bitrix_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_bitrix,
    );

    let config = Arc::new(BitrixClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_bitrix_backups(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_bitbucket(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_bitbucket_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_bitbucket + summary.filtered_cloud,
    );

    let config = Arc::new(BitbucketClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_bitbucket_repos(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_jira(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_jira_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_jira,
    );

    let config = Arc::new(JiraClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_jira_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_webapp(
    kind: AddServiceKind,
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_webapp_list_summary(kind, &input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_target,
    );
    let config = Arc::new(WebappClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_webapp_exports(
        kind,
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_redmine(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    export_options: RedmineExportOptions,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_redmine_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_redmine,
    );

    let config = Arc::new(RedmineClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_redmine_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        export_options,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_snowflake(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    export_options: SnowflakeExportOptions,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_snowflake_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_snowflake,
    );

    let config = Arc::new(SnowflakeClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_snowflake_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        export_options,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_confluence(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_confluence_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_confluence,
    );
    let config = Arc::new(ConfluenceClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_confluence_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_opencart(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_opencart_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_opencart,
    );
    let config = Arc::new(OpencartClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_opencart_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_workflowy(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_workflowy_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_workflowy,
    );
    let config = Arc::new(WorkflowyClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_workflowy_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_roamresearch(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_roamresearch_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_roam,
    );
    let config = Arc::new(RoamresearchClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_roamresearch_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_secondbrain(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_secondbrain_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_secondbrain,
    );
    let config = Arc::new(SecondbrainClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_secondbrain_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_appflowy(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_appflowy_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_appflowy,
    );
    let config = Arc::new(AppflowyClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_appflowy_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_note_export(
    service: NoteExportService,
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_note_export_list_summary(service, &input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_wrong_host,
    );
    let config = Arc::new(NoteExportClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_note_export_exports(
        service,
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        proxy,
        proxy_list,
        Some(ui.progress_bridge(cancel.clone())),
        None,
        Some(cancel),
    )
    .await
}

async fn run_crm_export(
    service: CrmExportService,
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    let summary = load_crm_export_list_summary(service, &input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_wrong_host,
    );
    let config = Arc::new(NoteExportClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_crm_export_exports(
        service,
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        proxy,
        proxy_list,
        Some(ui.progress_bridge(cancel.clone())),
        None,
        Some(cancel),
    )
    .await
}

async fn run_xwiki(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_xwiki_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_xwiki,
    );

    let config = Arc::new(XWikiClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_xwiki_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_bamboo(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_bamboo_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_bamboo,
    );

    let config = Arc::new(BambooClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_bamboo_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_gitlab(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_gitlab_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_gitlab,
    );

    let config = Arc::new(GitLabClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_gitlab_projects(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_slack(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_slack_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_slack,
    );

    let config = Arc::new(SlackClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
    });
    ui.results_dir(output.clone());
    download_slack_workspace_exports(
        summary.credentials,
        output,
        config,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_fortinet(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_fortinet_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(summary.credentials.len(), summary.skipped);

    let config = Arc::new(FortinetClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
        proxy,
    });
    ui.results_dir(output.clone());
    download_fortinet_exports(
        summary.credentials,
        output,
        config,
        proxy_list,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_citrix(
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    download_files: bool,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    let summary = load_citrix_list_summary(&input)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(
        summary.credentials.len(),
        summary.skipped + summary.filtered_non_vpn,
    );

    let config = Arc::new(CitrixClientConfig {
        timeout: Duration::from_secs(export_timeout),
        insecure,
        proxy,
    });
    ui.results_dir(output.clone());
    download_citrix_exports(
        summary.credentials,
        output,
        config,
        proxy_list,
        threads,
        download_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}

async fn run_cloud(
    provider: CloudProvider,
    input: PathBuf,
    output: PathBuf,
    threads: usize,
    export_timeout: u64,
    insecure: bool,
    proxy: Option<String>,
    proxy_list: Option<Arc<Vec<String>>>,
    upload_dir: Option<PathBuf>,
    upload_files: bool,
    download_from_cloud: bool,
    download_filter: CloudDownloadFilter,
    cancel: Arc<AtomicBool>,
    ui: &RunUi,
) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        return Ok(());
    }

    agent_log_gui(
        "H-cloud-ui",
        "pma-gui:run_cloud",
        "worker limits",
        serde_json::json!({
            "provider": provider.label(),
            "threads_ui": threads,
            "curl_parallel": megax_curl_parallel(),
            "mega_login_parallel": if provider == CloudProvider::Mega {
                megax_mega_login_parallel(threads)
            } else {
                0usize
            },
        }),
    );

    agent_log_gui(
        "H-cloud-ui",
        "pma-gui:run_cloud",
        "worker start",
        serde_json::json!({
            "provider": provider.label(),
            "upload_files": upload_files,
        }),
    );

    let summary = load_cloud_list_summary(&input, provider)
        .await
        .with_context(|| format!("load {}", input.display()))?;
    ui.loaded_targets(summary.credentials.len(), summary.skipped);

    let timeout = Duration::from_secs(export_timeout);
    let proxy_opt = proxy.filter(|p| !p.trim().is_empty());
    let mega_config = if provider == CloudProvider::Mega {
        let http = build_mega_http(timeout).with_context(|| "MEGA shared HTTP client")?;
        let login_slots = megax_mega_login_parallel(threads);
        Some(Arc::new(MegaClientConfig {
            timeout,
            upload_dir,
            http,
            login_semaphore: Arc::new(tokio::sync::Semaphore::new(login_slots)),
            download_from_cloud,
            download_filter: download_filter.clone(),
        }))
    } else {
        None
    };
    let cloud_config = if provider == CloudProvider::Mega {
        None
    } else {
        Some(Arc::new(
            pma_net::CloudClientConfig::build(
                provider,
                timeout,
                insecure,
                proxy_opt.clone(),
                threads,
                download_from_cloud,
                download_filter,
            )
            .with_context(|| format!("HTTP client for {}", provider.label()))?,
        ))
    };

    ui.results_dir(output.clone());
    download_cloud_exports(
        provider,
        summary.credentials,
        output,
        mega_config,
        cloud_config,
        proxy_list,
        threads,
        upload_files,
        Some(ui.progress_bridge(cancel.clone())),
        Some(cancel),
    )
    .await
}
