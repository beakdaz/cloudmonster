//! ProxyScraper-style panel for Note Check / CRM Check (from ProxyScraper.exe UI spec).

use crate::export_shell;
use crate::sales_dashboard;
use crate::PmaApp;
use crate::WorkMode;
use anyhow::Result;
use eframe::egui;
use egui_extras::{Column, TableBuilder};
use pma_net::{
    export_lines, load_proxy_list_with, run_scrape_blocking, write_export_csv, write_export_json,
    write_export_txt, ProxyListFormat, ProxyListScheme, ProxyScrapeResult, ScrapeConfig, ScrapeEvent,
};
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{Receiver, TryRecvError};
use std::sync::Arc;
use std::thread;

// ProxyScraper.exe palette
mod theme {
    use egui::Color32;
    pub const FG_DIM: Color32 = Color32::from_rgb(0x3a, 0x55, 0x78);
    pub const FG_MID: Color32 = Color32::from_rgb(0x6e, 0xa8, 0xd8);
    pub const FG_BRIGHT: Color32 = Color32::from_rgb(0xb5, 0xdc, 0xff);
    pub const ACCENT: Color32 = Color32::from_rgb(0x1f, 0x6f, 0xeb);
    pub const ACCENT_HI: Color32 = Color32::from_rgb(0x3b, 0x8c, 0xff);
    pub const SUCCESS: Color32 = Color32::from_rgb(0x2e, 0xa0, 0x43);
    pub const DANGER: Color32 = Color32::from_rgb(0xda, 0x36, 0x33);
    pub const VALID: Color32 = Color32::from_rgb(0x4a, 0xde, 0x80);
    pub const FAIL: Color32 = Color32::from_rgb(0xf8, 0x71, 0x71);
    pub const PANEL: Color32 = Color32::from_rgb(0x07, 0x0b, 0x16);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SuiteExportFormat {
    Txt,
    Json,
    Csv,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SortCol {
    Protocol,
    Address,
    Latency,
    Status,
    Endpoint,
}

pub struct SuiteProxyScraperState {
    pub proto_http: bool,
    pub proto_socks4: bool,
    pub proto_socks5: bool,
    pub output_with_protocol: bool,
    pub export_format: SuiteExportFormat,
    pub workers: u32,
    pub validate_timeout: u32,
    pub status: String,
    pub progress: f32,
    pub harvested: u32,
    pub tested: u32,
    pub valid: u32,
    pub failed: u32,
    pub avg_latency_ms: Option<f64>,
    pub results: Vec<ProxyScrapeResult>,
    pub scraping: bool,
    /// Account check without proxy (ProxyScraper «direct» for checker).
    pub check_direct: bool,
    sort_col: SortCol,
    sort_rev: bool,
    scrape_cancel: Arc<AtomicBool>,
    scrape_rx: Option<Receiver<ScrapeEvent>>,
}

impl Default for SuiteProxyScraperState {
    fn default() -> Self {
        Self {
            proto_http: false,
            proto_socks4: false,
            proto_socks5: false,
            output_with_protocol: true,
            export_format: SuiteExportFormat::Txt,
            workers: 20,
            validate_timeout: 10,
            status: "ready – select protocols to begin".to_string(),
            progress: 0.0,
            harvested: 0,
            tested: 0,
            valid: 0,
            failed: 0,
            avg_latency_ms: None,
            results: Vec::new(),
            scraping: false,
            check_direct: true,
            sort_col: SortCol::Latency,
            sort_rev: false,
            scrape_cancel: Arc::new(AtomicBool::new(false)),
            scrape_rx: None,
        }
    }
}

pub fn is_suite_check_app(app: &PmaApp) -> bool {
    matches!(app.work_mode, WorkMode::NoteCheck | WorkMode::CrmCheck)
        || app.fixed_note_service.is_some()
        || app.fixed_crm_service.is_some()
}

pub fn poll(app: &mut PmaApp, ctx: &egui::Context) {
    if !is_suite_check_app(app) {
        return;
    }
    let mut events = Vec::new();
    let mut disconnected = false;
    if let Some(rx) = app.suite_proxy.scrape_rx.as_ref() {
        loop {
            match rx.try_recv() {
                Ok(e) => events.push(e),
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => {
                    disconnected = true;
                    break;
                }
            }
        }
    } else {
        return;
    }

    let mut repaint = !events.is_empty();
    for evt in events {
        match evt {
            ScrapeEvent::Status(s) => app.suite_proxy.status = s,
            ScrapeEvent::Progress {
                harvested,
                tested,
                valid,
                failed,
                fraction,
            } => {
                app.suite_proxy.harvested = harvested;
                app.suite_proxy.tested = tested;
                app.suite_proxy.valid = valid;
                app.suite_proxy.failed = failed;
                app.suite_proxy.progress = fraction;
            }
            ScrapeEvent::Valid(r) => app.suite_proxy.results.push(r),
            ScrapeEvent::Finished {
                avg_latency_ms,
                elapsed_secs: _,
            } => {
                app.suite_proxy.avg_latency_ms = avg_latency_ms;
                app.suite_proxy.scraping = false;
                app.suite_proxy.scrape_rx = None;
                if app.suite_proxy.valid > 0 && app.suite_proxy.check_direct {
                    app.suite_proxy.check_direct = false;
                }
            }
        }
    }
    if disconnected {
        app.suite_proxy.scraping = false;
        app.suite_proxy.scrape_rx = None;
        repaint = true;
    }
    if repaint {
        ctx.request_repaint();
    }
}

pub fn resolve_check_proxies(
    app: &PmaApp,
) -> Result<(Option<String>, Option<Arc<Vec<String>>>)> {
    if app.suite_proxy.check_direct {
        return Ok((None, None));
    }
    let valid: Vec<String> = app
        .suite_proxy
        .results
        .iter()
        .filter(|r| r.latency_ms.is_some())
        .map(|r| r.reqwest_proxy_url())
        .collect();
    if !valid.is_empty() {
        return Ok((None, Some(Arc::new(valid))));
    }
    let path = app.proxy_list_file.trim();
    if !path.is_empty() {
        let list = load_proxy_list_with(
            Path::new(path),
            ProxyListScheme::Socks5,
            ProxyListFormat::HostPort,
        )?;
        if !list.is_empty() {
            return Ok((None, Some(Arc::new(list))));
        }
    }
    let single = app.proxy.trim();
    if !single.is_empty() {
        return Ok((Some(single.to_string()), None));
    }
    Ok((None, None))
}

pub fn dashboard_panel(app: &mut PmaApp, ui: &mut egui::Ui, ctx: &egui::Context) {
    let w = ui.available_width();
    egui::Frame::none()
        .fill(theme::PANEL)
        .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
        .rounding(egui::Rounding::same(12.0))
        .inner_margin(egui::Margin::same(12.0))
        .show(ui, |ui| {
            ui.set_width(w);
            header(ui);
            ui.add_space(8.0);
            controls_row(app, ui, ctx);
            ui.add_space(8.0);
            stats_row(app, ui);
            ui.add_space(6.0);
            progress_status(app, ui);
            ui.add_space(6.0);
            check_connection_row(app, ui);
            ui.add_space(6.0);
            results_table(app, ui);
        });
}

fn header(ui: &mut egui::Ui) {
    ui.horizontal(|ui| {
        let (rect, _) = ui.allocate_exact_size(egui::vec2(4.0, 28.0), egui::Sense::hover());
        ui.painter().rect_filled(rect, egui::Rounding::ZERO, theme::ACCENT);
        ui.add_space(6.0);
        ui.vertical(|ui| {
            ui.label(
                egui::RichText::new("PROXY SCRAPER")
                    .font(sales_dashboard::font_display(16.0))
                    .color(theme::FG_BRIGHT),
            );
            ui.label(
                egui::RichText::new("scrape  ·  validate  ·  measure  ·  export")
                    .font(sales_dashboard::font_display(11.0))
                    .color(theme::FG_DIM),
            );
        });
    });
    ui.add_space(4.0);
    ui.separator();
}

fn section_label(ui: &mut egui::Ui, text: &str) {
    ui.label(
        egui::RichText::new(text)
            .font(sales_dashboard::font_display(10.0))
            .color(theme::FG_DIM),
    );
}

fn toggle_chip(ui: &mut egui::Ui, label: &str, on: &mut bool) {
    let fill = if *on {
        theme::ACCENT
    } else {
        sales_dashboard::INPUT
    };
    let stroke = if *on {
        egui::Stroke::new(1.5, theme::ACCENT_HI)
    } else {
        egui::Stroke::new(1.0, sales_dashboard::BORDER)
    };
    if ui
        .add(
            egui::Button::new(
                egui::RichText::new(label)
                    .font(sales_dashboard::font_display(11.0))
                    .color(if *on { theme::FG_BRIGHT } else { theme::FG_MID }),
            )
            .fill(fill)
            .stroke(stroke)
            .rounding(egui::Rounding::same(8.0))
            .min_size(egui::vec2(72.0, 28.0)),
        )
        .clicked()
    {
        *on = !*on;
    }
}

fn glow_button(ui: &mut egui::Ui, label: &str, fill: egui::Color32, enabled: bool) -> bool {
    ui.add_enabled(
        enabled,
        egui::Button::new(
            egui::RichText::new(label)
                .font(sales_dashboard::font_display(11.0))
                .color(theme::FG_BRIGHT),
        )
        .fill(fill)
        .stroke(egui::Stroke::new(1.0, theme::ACCENT_HI))
        .rounding(egui::Rounding::same(8.0))
        .min_size(egui::vec2(72.0, 32.0)),
    )
    .clicked()
}

fn controls_row(app: &mut PmaApp, ui: &mut egui::Ui, ctx: &egui::Context) {
    ui.horizontal_wrapped(|ui| {
        ui.vertical(|ui| {
            section_label(ui, "PROTOCOLS");
            ui.horizontal(|ui| {
                toggle_chip(ui, "HTTP", &mut app.suite_proxy.proto_http);
                toggle_chip(ui, "SOCKS4", &mut app.suite_proxy.proto_socks4);
                toggle_chip(ui, "SOCKS5", &mut app.suite_proxy.proto_socks5);
            });
        });
        ui.add_space(12.0);
        ui.vertical(|ui| {
            section_label(ui, "OUTPUT FORMAT");
            ui.horizontal(|ui| {
                radio_chip(
                    ui,
                    "protocol://ip:port",
                    &mut app.suite_proxy.output_with_protocol,
                    true,
                );
                radio_chip(
                    ui,
                    "ip:port",
                    &mut app.suite_proxy.output_with_protocol,
                    false,
                );
            });
        });
        ui.add_space(12.0);
        ui.vertical(|ui| {
            section_label(ui, "EXPORT FORMAT");
            ui.horizontal(|ui| {
                export_fmt_chip(ui, &mut app.suite_proxy.export_format, SuiteExportFormat::Txt);
                export_fmt_chip(ui, &mut app.suite_proxy.export_format, SuiteExportFormat::Json);
                export_fmt_chip(ui, &mut app.suite_proxy.export_format, SuiteExportFormat::Csv);
            });
        });
        ui.add_space(12.0);
        ui.vertical(|ui| {
            section_label(ui, "TUNING");
            ui.horizontal(|ui| {
                ui.label(
                    egui::RichText::new("workers")
                        .font(sales_dashboard::font_display(10.0))
                        .color(theme::FG_MID),
                );
                ui.add(
                    egui::DragValue::new(&mut app.suite_proxy.workers)
                        .range(1..=500)
                        .speed(0.5),
                );
                ui.add_space(8.0);
                ui.label(
                    egui::RichText::new("timeout")
                        .font(sales_dashboard::font_display(10.0))
                        .color(theme::FG_MID),
                );
                ui.add(
                    egui::DragValue::new(&mut app.suite_proxy.validate_timeout)
                        .range(1..=120)
                        .suffix("s"),
                );
            });
        });
        ui.add_space(12.0);
        ui.vertical(|ui| {
            section_label(ui, "ACTIONS");
            ui.horizontal(|ui| {
                let scraping = app.suite_proxy.scraping;
                if glow_button(ui, "SCRAPE", theme::ACCENT, !scraping && !app.busy) {
                    start_scrape(app, ctx);
                }
                if glow_button(
                    ui,
                    "CANCEL",
                    Color32_danger(),
                    scraping,
                ) {
                    app.suite_proxy.scrape_cancel.store(true, Ordering::Relaxed);
                }
                let can_export = !app.suite_proxy.results.is_empty() && !scraping;
                if glow_button(ui, "EXPORT", Color32_success(), can_export) {
                    export_results(app, ctx);
                }
            });
        });
    });
}

fn Color32_danger() -> egui::Color32 {
    egui::Color32::from_rgb(0x5a, 0x1a, 0x1a)
}

fn Color32_success() -> egui::Color32 {
    egui::Color32::from_rgb(0x0f, 0x3d, 0x1f)
}

fn radio_chip(ui: &mut egui::Ui, label: &str, value: &mut bool, set: bool) {
    let selected = *value == set;
    if ui
        .selectable_label(selected, egui::RichText::new(label).font(sales_dashboard::font_display(10.0)))
        .clicked()
    {
        *value = set;
    }
}

fn export_fmt_chip(ui: &mut egui::Ui, current: &mut SuiteExportFormat, fmt: SuiteExportFormat) {
    let label = match fmt {
        SuiteExportFormat::Txt => "txt",
        SuiteExportFormat::Json => "json",
        SuiteExportFormat::Csv => "csv",
    };
    if ui
        .selectable_label(*current == fmt, egui::RichText::new(label).font(sales_dashboard::font_display(10.0)))
        .clicked()
    {
        *current = fmt;
    }
}

fn stat_pill(ui: &mut egui::Ui, caption: &str, value: &str, value_color: egui::Color32) {
    egui::Frame::none()
        .fill(sales_dashboard::INPUT)
        .stroke(egui::Stroke::new(1.0, sales_dashboard::BORDER))
        .rounding(egui::Rounding::same(8.0))
        .inner_margin(egui::Margin::symmetric(10.0, 6.0))
        .show(ui, |ui| {
            ui.vertical(|ui| {
                ui.label(
                    egui::RichText::new(caption)
                        .font(sales_dashboard::font_display(9.0))
                        .color(theme::FG_DIM),
                );
                ui.label(
                    egui::RichText::new(value)
                        .font(sales_dashboard::font_display(13.0))
                        .color(value_color),
                );
            });
        });
}

fn stats_row(app: &PmaApp, ui: &mut egui::Ui) {
    let avg = app
        .suite_proxy
        .avg_latency_ms
        .map(|v| format!("{v:.0} ms"))
        .unwrap_or_else(|| "— ms".to_string());
    ui.horizontal(|ui| {
        stat_pill(
            ui,
            "harvested",
            &app.suite_proxy.harvested.to_string(),
            theme::FG_BRIGHT,
        );
        stat_pill(
            ui,
            "tested",
            &app.suite_proxy.tested.to_string(),
            theme::FG_BRIGHT,
        );
        stat_pill(
            ui,
            "valid",
            &app.suite_proxy.valid.to_string(),
            theme::VALID,
        );
        stat_pill(
            ui,
            "failed",
            &app.suite_proxy.failed.to_string(),
            theme::FAIL,
        );
        stat_pill(ui, "avg latency", &avg, theme::FG_MID);
    });
}

fn progress_status(app: &PmaApp, ui: &mut egui::Ui) {
    ui.add(
        egui::ProgressBar::new(app.suite_proxy.progress)
            .show_percentage()
            .animate(app.suite_proxy.scraping),
    );
    ui.label(
        egui::RichText::new(&app.suite_proxy.status)
            .font(sales_dashboard::font_display(11.0))
            .color(theme::FG_MID),
    );
}

fn check_connection_row(app: &mut PmaApp, ui: &mut egui::Ui) {
    ui.horizontal(|ui| {
        section_label(ui, "CHECK");
        ui.add_space(4.0);
        toggle_chip(ui, "DIRECT", &mut app.suite_proxy.check_direct);
        if !app.suite_proxy.check_direct {
            ui.label(
                egui::RichText::new(format!(
                    "rotate {} valid proxies",
                    app.suite_proxy.valid
                ))
                .font(sales_dashboard::font_display(10.0))
                .color(theme::FG_MID),
            );
        }
    });
    ui.add_space(4.0);
    ui.collapsing("Manual proxy (file / single)", |ui| {
        if export_shell::browse_field(
            ui,
            "Select proxy list…",
            &app.proxy_list_file,
            ui.available_width(),
        ) {
            app.pick_proxy_list_file();
        }
        ui.add(
            egui::TextEdit::singleline(&mut app.proxy)
                .hint_text("socks5://127.0.0.1:1080")
                .desired_width(ui.available_width()),
        );
    });
}

fn results_table(app: &mut PmaApp, ui: &mut egui::Ui) {
    section_label(ui, "RESULTS");
    let mut rows: Vec<(String, String, String, String, String)> = app
        .suite_proxy
        .results
        .iter()
        .filter(|r| r.latency_ms.is_some())
        .map(|r| {
            (
                r.protocol.to_uppercase(),
                r.addr(),
                r.latency_ms
                    .map(|v| v.to_string())
                    .unwrap_or_else(|| "—".to_string()),
                r.status.clone(),
                r.endpoint.clone(),
            )
        })
        .collect();
    sort_rows(&mut rows, app.suite_proxy.sort_col, app.suite_proxy.sort_rev);

    egui::ScrollArea::vertical()
        .max_height(160.0)
        .show(ui, |ui| {
            TableBuilder::new(ui)
                .striped(true)
                .cell_layout(egui::Layout::left_to_right(egui::Align::Center))
                .column(Column::auto().at_least(70.0))
                .column(Column::auto().at_least(120.0))
                .column(Column::auto().at_least(80.0))
                .column(Column::auto().at_least(60.0))
                .column(Column::remainder().at_least(120.0))
                .header(22.0, |mut header| {
                    sort_header(&mut header, "PROTOCOL", SortCol::Protocol, app);
                    sort_header(&mut header, "ADDRESS", SortCol::Address, app);
                    sort_header(&mut header, "LATENCY (MS)", SortCol::Latency, app);
                    sort_header(&mut header, "HTTP", SortCol::Status, app);
                    sort_header(&mut header, "ENDPOINT", SortCol::Endpoint, app);
                })
                .body(|mut body| {
                    for (proto, addr, lat, status, endpoint) in rows {
                        body.row(20.0, |mut row| {
                            row.col(|ui| {
                                ui.label(
                                    egui::RichText::new(proto)
                                        .font(egui::FontId::monospace(10.0))
                                        .color(theme::FG_MID),
                                );
                            });
                            row.col(|ui| {
                                ui.label(
                                    egui::RichText::new(addr)
                                        .font(egui::FontId::monospace(10.0))
                                        .color(theme::FG_BRIGHT),
                                );
                            });
                            row.col(|ui| {
                                ui.label(
                                    egui::RichText::new(lat)
                                        .font(egui::FontId::monospace(10.0))
                                        .color(theme::FG_MID),
                                );
                            });
                            row.col(|ui| {
                                ui.label(
                                    egui::RichText::new(status)
                                        .font(egui::FontId::monospace(10.0))
                                        .color(theme::FG_MID),
                                );
                            });
                            row.col(|ui| {
                                ui.label(
                                    egui::RichText::new(endpoint)
                                        .font(egui::FontId::monospace(9.0))
                                        .color(theme::FG_DIM),
                                );
                            });
                        });
                    }
                });
        });
}

fn sort_header(
    header: &mut egui_extras::TableRow<'_, '_>,
    text: &str,
    col: SortCol,
    app: &mut PmaApp,
) {
    header.col(|ui| {
        if ui
            .button(
                egui::RichText::new(text)
                    .font(sales_dashboard::font_display(9.0))
                    .color(theme::FG_DIM),
            )
            .clicked()
        {
            if app.suite_proxy.sort_col == col {
                app.suite_proxy.sort_rev = !app.suite_proxy.sort_rev;
            } else {
                app.suite_proxy.sort_col = col;
                app.suite_proxy.sort_rev = false;
            }
        }
    });
}

fn sort_rows(rows: &mut [(String, String, String, String, String)], col: SortCol, rev: bool) {
    rows.sort_by(|a, b| {
        let ord = match col {
            SortCol::Protocol => a.0.cmp(&b.0),
            SortCol::Address => a.1.cmp(&b.1),
            SortCol::Latency => a.2.cmp(&b.2),
            SortCol::Status => a.3.cmp(&b.3),
            SortCol::Endpoint => a.4.cmp(&b.4),
        };
        if rev {
            ord.reverse()
        } else {
            ord
        }
    });
}

fn start_scrape(app: &mut PmaApp, ctx: &egui::Context) {
    if !app.suite_proxy.proto_http
        && !app.suite_proxy.proto_socks4
        && !app.suite_proxy.proto_socks5
    {
        app.suite_proxy.status = "select at least one protocol".to_string();
        return;
    }
    app.suite_proxy.scrape_cancel = Arc::new(AtomicBool::new(false));
    app.suite_proxy.scraping = true;
    app.suite_proxy.results.clear();
    app.suite_proxy.harvested = 0;
    app.suite_proxy.tested = 0;
    app.suite_proxy.valid = 0;
    app.suite_proxy.failed = 0;
    app.suite_proxy.progress = 0.0;
    app.suite_proxy.avg_latency_ms = None;
    app.suite_proxy.status = "starting…".to_string();

    let (tx, rx) = std::sync::mpsc::channel();
    app.suite_proxy.scrape_rx = Some(rx);
    let cancel = app.suite_proxy.scrape_cancel.clone();
    let config = ScrapeConfig {
        http: app.suite_proxy.proto_http,
        socks4: app.suite_proxy.proto_socks4,
        socks5: app.suite_proxy.proto_socks5,
        workers: app.suite_proxy.workers as usize,
        timeout_secs: u64::from(app.suite_proxy.validate_timeout),
    };
    thread::spawn(move || {
        let _ = run_scrape_blocking(config, cancel, tx);
    });
    ctx.request_repaint();
}

fn export_results(app: &mut PmaApp, ctx: &egui::Context) {
    let valid: Vec<_> = app
        .suite_proxy
        .results
        .iter()
        .filter(|r| r.latency_ms.is_some())
        .cloned()
        .collect();
    if valid.is_empty() {
        app.push_log("Error", "Nothing to export — run a scrape first.".to_string(), None);
        return;
    }
    let ext = match app.suite_proxy.export_format {
        SuiteExportFormat::Txt => "txt",
        SuiteExportFormat::Json => "json",
        SuiteExportFormat::Csv => "csv",
    };
    let path = rfd::FileDialog::new()
        .set_file_name(format!("suite_proxies_.{ext}"))
        .add_filter(ext, &[ext])
        .save_file();
    let Some(path) = path else {
        return;
    };
    let with_proto = app.suite_proxy.output_with_protocol;
    let result = match app.suite_proxy.export_format {
        SuiteExportFormat::Txt => {
            let lines = export_lines(&valid, with_proto);
            write_export_txt(&path, &lines)
        }
        SuiteExportFormat::Json => write_export_json(&path, &valid),
        SuiteExportFormat::Csv => write_export_csv(&path, &valid),
    };
    match result {
        Ok(()) => {
            app.suite_proxy.status = format!("exported {} → {}", valid.len(), path.display());
            app.push_log(
                "Info",
                format!("Exported {} proxies to {}", valid.len(), path.display()),
                None,
            );
        }
        Err(err) => {
            app.push_log("Error", format!("{err:#}"), None);
        }
    }
    ctx.request_repaint();
}
