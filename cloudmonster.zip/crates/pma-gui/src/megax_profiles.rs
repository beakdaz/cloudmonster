//! Named CloudMonster settings profiles (JSON in local app data).

use super::{PmaApp, WorkMode};
use crate::megax::{MegaxProxyLineFormat, MegaxProxyMode, MegaxProxyProtocol};
use pma_core::CloudProvider;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::fs;
use std::path::PathBuf;

const STORE_VERSION: u32 = 1;
pub const DEFAULT_PROFILE_NAME: &str = "Default";
const DEFAULT_PROFILE: &str = DEFAULT_PROFILE_NAME;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MegaxProfile {
    pub input_file: String,
    pub output_dir: String,
    pub threads: u32,
    pub timeout: u32,
    pub export_timeout: u32,
    pub retries: u32,
    pub insecure: bool,
    pub proxy: String,
    pub proxy_list_file: String,
    pub download_mega: bool,
    pub cloud_provider: CloudProvider,
    pub mega_upload_dir: String,
    pub cloud_filter_extensions: String,
    pub cloud_filter_keywords: String,
    pub cloud_filter_min_kb: u32,
    pub cloud_filter_max_mb: u32,
    pub megax_skip_proxy_precheck: bool,
    pub megax_auto_fetch_proxies: bool,
    pub megax_proxy_list_url: String,
    pub megax_proxy_interval_min: u32,
    pub megax_upload_no_proxy: bool,
    pub megax_download_no_proxy: bool,
    pub megax_low_render: bool,
    pub megax_proxy_protocol: MegaxProxyProtocol,
    pub megax_proxy_line_format: MegaxProxyLineFormat,
    #[serde(default)]
    pub megax_proxy_mode: MegaxProxyMode,
    pub log_expanded: bool,
}

impl Default for MegaxProfile {
    fn default() -> Self {
        Self {
            input_file: String::new(),
            output_dir: String::new(),
            threads: 16,
            timeout: 30,
            export_timeout: 120,
            retries: 2,
            insecure: false,
            proxy: String::new(),
            proxy_list_file: String::new(),
            download_mega: true,
            cloud_provider: CloudProvider::Mega,
            mega_upload_dir: String::new(),
            cloud_filter_extensions: String::new(),
            cloud_filter_keywords: String::new(),
            cloud_filter_min_kb: 0,
            cloud_filter_max_mb: 0,
            megax_skip_proxy_precheck: false,
            megax_auto_fetch_proxies: false,
            megax_proxy_list_url: String::new(),
            megax_proxy_interval_min: 2,
            megax_upload_no_proxy: false,
            megax_download_no_proxy: false,
            megax_low_render: false,
            megax_proxy_protocol: MegaxProxyProtocol::default(),
            megax_proxy_line_format: MegaxProxyLineFormat::default(),
            megax_proxy_mode: MegaxProxyMode::default(),
            log_expanded: false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MegaxProfileStore {
    pub version: u32,
    pub active: String,
    pub profiles: BTreeMap<String, MegaxProfile>,
}

impl Default for MegaxProfileStore {
    fn default() -> Self {
        let mut profiles = BTreeMap::new();
        profiles.insert(DEFAULT_PROFILE.to_string(), MegaxProfile::default());
        Self {
            version: STORE_VERSION,
            active: DEFAULT_PROFILE.to_string(),
            profiles,
        }
    }
}

impl MegaxProfileStore {
    pub fn profile_names(&self) -> Vec<String> {
        self.profiles.keys().cloned().collect()
    }

    pub fn ensure_default(&mut self) {
        if self.profiles.is_empty() {
            self.profiles
                .insert(DEFAULT_PROFILE.to_string(), MegaxProfile::default());
            self.active = DEFAULT_PROFILE.to_string();
        }
        if !self.profiles.contains_key(&self.active) {
            self.active = self
                .profiles
                .keys()
                .next()
                .cloned()
                .unwrap_or_else(|| DEFAULT_PROFILE.to_string());
        }
    }
}

pub fn store_path() -> PathBuf {
    if let Ok(local) = std::env::var("LOCALAPPDATA") {
        return PathBuf::from(local)
            .join("CloudMonster")
            .join("profiles.json");
    }
    PathBuf::from("cloudmonster-profiles.json")
}

pub fn load() -> MegaxProfileStore {
    let path = store_path();
    let Ok(raw) = fs::read_to_string(&path) else {
        return MegaxProfileStore::default();
    };
    match serde_json::from_str::<MegaxProfileStore>(&raw) {
        Ok(mut store) => {
            store.ensure_default();
            store
        }
        Err(_) => MegaxProfileStore::default(),
    }
}

pub fn save(store: &MegaxProfileStore) -> Result<(), String> {
    let path = store_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let mut store = store.clone();
    store.version = STORE_VERSION;
    store.ensure_default();
    let json = serde_json::to_string_pretty(&store).map_err(|e| e.to_string())?;
    fs::write(&path, json).map_err(|e| e.to_string())
}

impl PmaApp {
    pub(crate) fn capture_megax_profile(&self) -> MegaxProfile {
        MegaxProfile {
            input_file: self.input_file.clone(),
            output_dir: self.output_dir.clone(),
            threads: self.threads,
            timeout: self.timeout,
            export_timeout: self.export_timeout,
            retries: self.retries,
            insecure: self.insecure,
            proxy: self.proxy.clone(),
            proxy_list_file: self.proxy_list_file.clone(),
            download_mega: self.download_mega,
            cloud_provider: self.effective_cloud_provider(),
            mega_upload_dir: self.mega_upload_dir.clone(),
            cloud_filter_extensions: self.cloud_filter_extensions.clone(),
            cloud_filter_keywords: self.cloud_filter_keywords.clone(),
            cloud_filter_min_kb: self.cloud_filter_min_kb,
            cloud_filter_max_mb: self.cloud_filter_max_mb,
            megax_skip_proxy_precheck: self.megax_skip_proxy_precheck,
            megax_auto_fetch_proxies: self.megax_auto_fetch_proxies,
            megax_proxy_list_url: self.megax_proxy_list_url.clone(),
            megax_proxy_interval_min: self.megax_proxy_interval_min,
            megax_upload_no_proxy: self.megax_upload_no_proxy,
            megax_download_no_proxy: self.megax_download_no_proxy,
            megax_low_render: self.megax_low_render,
            megax_proxy_protocol: self.megax_proxy_protocol,
            megax_proxy_line_format: self.megax_proxy_line_format,
            megax_proxy_mode: self.megax_proxy_mode,
            log_expanded: self.log_expanded,
        }
    }

    pub(crate) fn apply_megax_profile(&mut self, profile: &MegaxProfile) {
        self.input_file = profile.input_file.clone();
        self.output_dir = profile.output_dir.clone();
        self.threads = profile.threads;
        self.timeout = profile.timeout;
        self.export_timeout = profile.export_timeout;
        self.retries = profile.retries;
        self.insecure = profile.insecure;
        self.proxy = profile.proxy.clone();
        self.proxy_list_file = profile.proxy_list_file.clone();
        self.download_mega = profile.download_mega;
        self.cloud_provider = profile.cloud_provider;
        self.mega_upload_dir = profile.mega_upload_dir.clone();
        self.cloud_filter_extensions = profile.cloud_filter_extensions.clone();
        self.cloud_filter_keywords = profile.cloud_filter_keywords.clone();
        self.cloud_filter_min_kb = profile.cloud_filter_min_kb;
        self.cloud_filter_max_mb = profile.cloud_filter_max_mb;
        self.megax_skip_proxy_precheck = profile.megax_skip_proxy_precheck;
        self.megax_auto_fetch_proxies = profile.megax_auto_fetch_proxies;
        self.megax_proxy_list_url = profile.megax_proxy_list_url.clone();
        self.megax_proxy_interval_min = profile.megax_proxy_interval_min;
        self.megax_upload_no_proxy = profile.megax_upload_no_proxy;
        self.megax_download_no_proxy = profile.megax_download_no_proxy;
        self.megax_low_render = profile.megax_low_render;
        self.megax_proxy_protocol = profile.megax_proxy_protocol;
        self.megax_proxy_line_format = profile.megax_proxy_line_format;
        self.megax_proxy_mode = profile.megax_proxy_mode;
        self.log_expanded = profile.log_expanded;
        self.enforce_fixed_cloud_provider();
    }

    pub(crate) fn enforce_fixed_cloud_provider(&mut self) {
        if let Some(p) = self.fixed_cloud_provider {
            self.cloud_provider = p;
        }
    }

    pub(crate) fn enforce_fixed_crm_service(&mut self) {
        if let Some(s) = self.fixed_crm_service {
            self.crm_service = s;
        }
    }

    pub(crate) fn enforce_fixed_note_service(&mut self) {
        if let Some(s) = self.fixed_note_service {
            self.note_service = s;
        }
    }

    pub(crate) fn effective_cloud_provider(&self) -> CloudProvider {
        self.fixed_cloud_provider
            .unwrap_or(self.cloud_provider)
    }

    pub(crate) fn megax_profiles_init(&mut self) {
        if self.fixed_mode != Some(WorkMode::Mega) {
            return;
        }
        if self.fixed_cloud_provider.is_some() {
            // Dedicated export-*-gui: do not load Mega/Icedrive profile (proxy file / wrong provider).
            self.megax_proxy_mode = MegaxProxyMode::Direct;
            self.proxy_list_file.clear();
            self.proxy.clear();
            self.enforce_fixed_cloud_provider();
            self.megax_profile_message.clear();
            return;
        }
        let store = load();
        self.megax_profile_store = store.clone();
        self.megax_profile_draft_name = store.active.clone();
        if let Some(profile) = store.profiles.get(&store.active) {
            self.apply_megax_profile(profile);
        } else {
            self.enforce_fixed_cloud_provider();
        }
        self.megax_profile_message.clear();
    }

    pub(crate) fn megax_profile_apply_active(&mut self, name: &str) {
        let Some(profile) = self.megax_profile_store.profiles.get(name).cloned() else {
            return;
        };
        self.apply_megax_profile(&profile);
        self.megax_profile_store.active = name.to_string();
        self.megax_profile_draft_name = name.to_string();
        let _ = save(&self.megax_profile_store);
    }

    pub(crate) fn megax_profile_save_current(&mut self, name: &str) -> Result<(), String> {
        let name = name.trim();
        if name.is_empty() {
            return Err("Profile name is empty".into());
        }
        let snapshot = self.capture_megax_profile();
        self.megax_profile_store
            .profiles
            .insert(name.to_string(), snapshot);
        self.megax_profile_store.active = name.to_string();
        self.megax_profile_draft_name = name.to_string();
        save(&self.megax_profile_store)
    }

    pub(crate) fn megax_profile_delete(&mut self, name: &str) -> Result<(), String> {
        if self.megax_profile_store.profiles.len() <= 1 {
            return Err("Cannot delete the last profile".into());
        }
        if !self.megax_profile_store.profiles.remove(name).is_some() {
            return Err("Profile not found".into());
        }
        if self.megax_profile_store.active == name {
            self.megax_profile_store.active = self
                .megax_profile_store
                .profiles
                .keys()
                .next()
                .cloned()
                .unwrap_or_else(|| DEFAULT_PROFILE.to_string());
        }
        let active = self.megax_profile_store.active.clone();
        if let Some(profile) = self.megax_profile_store.profiles.get(&active).cloned() {
            self.apply_megax_profile(&profile);
            self.megax_profile_draft_name = active;
        }
        save(&self.megax_profile_store)
    }
}
