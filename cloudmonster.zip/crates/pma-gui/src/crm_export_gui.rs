//! CRM Check GUI — provider picker for `WorkMode::CrmCheck`.

use pma_core::CrmExportService;

use crate::WorkMode;

pub fn crm_export_service_for_fixed_mode(
    mode: WorkMode,
    service: CrmExportService,
) -> Option<CrmExportService> {
    if mode == WorkMode::CrmCheck {
        Some(service)
    } else {
        None
    }
}
