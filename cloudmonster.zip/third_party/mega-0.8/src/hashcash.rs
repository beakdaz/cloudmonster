//! MEGA X-Hashcash proof-of-work (HTTP 402). Port of go-mega / Mega v4.6.

use base64::prelude::{Engine, BASE64_URL_SAFE_NO_PAD};
use sha2::{Digest, Sha256};

const NUM_REPLICATIONS: usize = 262_144;
const TOKEN_SLOT_SIZE: usize = 48;

fn pad_aes_block(mut data: Vec<u8>) -> Vec<u8> {
    let rem = data.len() % 16;
    if rem != 0 {
        data.extend(std::iter::repeat_n(0u8, 16 - rem));
    }
    data
}

fn threshold(easiness: u8) -> u32 {
    let e = u32::from(easiness);
    (((e & 63) << 1) + 1) << ((e >> 6) * 7 + 3)
}

/// Parse `1:easiness:…:token` from `X-Hashcash` header value (token may contain `:`).
pub fn parse_hashcash(header: &str) -> Option<(u8, String)> {
    let mut parts = header.splitn(4, ':');
    if parts.next()? != "1" {
        return None;
    }
    let easiness: u8 = parts.next()?.parse().ok()?;
    let _middle = parts.next()?;
    let token = parts.next()?.to_string();
    Some((easiness, token))
}

const MAX_HASH_ITERATIONS: u64 = 2_000_000;

/// Solve challenge; returns value for `X-Hashcash` request header (nonce, base64url).
pub fn solve_hashcash(token_b64: &str, easiness: u8) -> Option<String> {
    let mut token_bytes = BASE64_URL_SAFE_NO_PAD.decode(token_b64).ok()?;
    token_bytes = pad_aes_block(token_bytes);

    let mut buffer = vec![0u8; 4 + NUM_REPLICATIONS * TOKEN_SLOT_SIZE];
    for i in 0..NUM_REPLICATIONS {
        let off = 4 + i * TOKEN_SLOT_SIZE;
        let n = token_bytes.len().min(buffer.len().saturating_sub(off));
        if n == 0 {
            break;
        }
        buffer[off..off + n].copy_from_slice(&token_bytes[..n]);
    }

    let thr = threshold(easiness);
    for _ in 0..MAX_HASH_ITERATIONS {
        for j in 0..4 {
            buffer[j] = buffer[j].wrapping_add(1);
            if buffer[j] != 0 {
                break;
            }
            if j == 3 {
                return None;
            }
        }
        let hash = Sha256::digest(&buffer);
        let hash_value = u32::from_be_bytes([hash[0], hash[1], hash[2], hash[3]]);
        if hash_value <= thr {
            return Some(BASE64_URL_SAFE_NO_PAD.encode(&buffer[..4]));
        }
    }
    None
}
