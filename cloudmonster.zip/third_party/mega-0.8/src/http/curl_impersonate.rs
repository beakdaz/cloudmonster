//! MEGA API HTTP via curl-impersonate (Chrome TLS) — Mega v4.6 / curl_cffi parity.

use std::path::{Path, PathBuf};
use std::pin::Pin;
use std::sync::atomic::Ordering;
use std::sync::{Arc, LazyLock};
use std::time::Duration;

use async_trait::async_trait;
use curl_impersonate_cli::{Fingerprint, Request};
use futures::io::AsyncRead;
use json::Value;
use secrecy::ExposeSecret;
use tokio::sync::Semaphore;
use url::Url;

use crate::error::{Error, Result};
use crate::hashcash::{parse_hashcash, solve_hashcash};
use crate::http::HttpClient;
use crate::protocol::commands::{Request as MegaRequest, Response};
use crate::{ClientState, ErrorCode};

static HASHCASH_SLOTS: LazyLock<Arc<Semaphore>> =
    LazyLock::new(|| Arc::new(Semaphore::new(4)));
/// Limit parallel curl subprocesses — MEGA returns `EAGAIN` when too many TLS sessions hit `/cs`.
static CURL_SLOTS: LazyLock<Arc<Semaphore>> = LazyLock::new(|| {
    let n = std::env::var("MEGAX_CURL_PARALLEL")
        .ok()
        .and_then(|s| s.trim().parse::<usize>().ok())
        .map(|v| v.clamp(1, 128))
        .unwrap_or(8);
    // #region agent log
    debug_log(
        "H-curl-cap",
        "curl_impersonate.rs:CURL_SLOTS",
        "curl parallel limit",
        &format!(r#"{{"megax_curl_parallel":{n}}}"#),
    );
    // #endregion
    Arc::new(Semaphore::new(n))
});
const HASHCASH_SOLVE_TIMEOUT: Duration = Duration::from_secs(25);
const MAX_HASHCASH_ROUNDS: u32 = 4;
const EAGAIN_BACKOFF: Duration = Duration::from_millis(250);

// #region agent log
fn debug_log(hypothesis_id: &str, location: &str, message: &str, data_json: &str) {
    use std::fs::OpenOptions;
    use std::io::Write;
    use std::sync::Mutex;
    static LOCK: Mutex<()> = Mutex::new(());
    let _g = LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let line = format!(
        r#"{{"sessionId":"be3b27","hypothesisId":"{hypothesis_id}","location":"{location}","message":"{message}","data":{data_json},"timestamp":{ts},"runId":"mega-debug"}}"#
    );
    if let Ok(mut f) = OpenOptions::new()
        .create(true)
        .append(true)
        .open(r"C:\Users\beakd\Documents\MEGA\1\debug-be3b27.log")
    {
        let _ = writeln!(f, "{line}");
    }
}
// #endregion

/// Chrome110 wrapper from curl-impersonate (byte-accurate TLS like Mega v4.6).
#[derive(Debug, Clone)]
pub struct CurlImpersonateClient {
    bin: PathBuf,
    /// Set when using `curl-impersonate.exe` + `--impersonate chrome110` (Windows `.bat` layout).
    fingerprint: Option<Fingerprint>,
}

impl CurlImpersonateClient {
    pub fn new() -> Result<Self> {
        let (bin, fingerprint) = resolve_curl_bin()?;
        Ok(Self { bin, fingerprint })
    }

    pub fn with_bin(bin: impl Into<PathBuf>) -> Self {
        Self {
            bin: bin.into(),
            fingerprint: None,
        }
    }

    pub fn bin_path(&self) -> &Path {
        &self.bin
    }

    /// Generic GET/POST for non-MEGA APIs (Chrome TLS fingerprint).
    pub async fn impersonate_http(
        &self,
        method: curl_impersonate_cli::Method,
        url: &str,
        body: Option<Vec<u8>>,
        headers: &[(&str, &str)],
        timeout: Duration,
        follow_redirects: bool,
        proxy: Option<&str>,
        insecure: bool,
    ) -> Result<(u16, String, Vec<String>)> {
        let wait_t0 = std::time::Instant::now();
        let _curl_slot = CURL_SLOTS
            .acquire()
            .await
            .expect("curl concurrency semaphore");
        let wait_ms = wait_t0.elapsed().as_millis();
        if wait_ms >= 100 {
            debug_log(
                "H-curl-queue",
                "curl_impersonate.rs:impersonate",
                "waited for curl slot",
                &format!(r#"{{"wait_ms":{wait_ms}}}"#),
            );
        }

        let mut req = match method {
            curl_impersonate_cli::Method::Get => Request::get(&self.bin, url),
            curl_impersonate_cli::Method::Post => Request::post(&self.bin, url),
        };
        for (k, v) in headers {
            req = req.header(*k, *v);
        }
        if let Some(b) = body {
            req = req.body(b);
        }
        if let Some(fp) = &self.fingerprint {
            req = req.fingerprint(fp.clone());
        }
        req = req.timeout_secs(timeout.as_secs_f64().max(5.0));
        req = req.follow_redirects(follow_redirects);
        req = req.insecure(insecure);
        if let Some(raw) = proxy {
            let trimmed = raw.trim();
            if !trimmed.is_empty() {
                req = req.proxy(Some(curl_impersonate_cli::ProxySpec {
                    url: trimmed.to_string(),
                }));
            }
        }
        let resp = req
            .send()
            .await
            .map_err(|e| Error::CurlImpersonate(e.to_string()))?;
        Ok((resp.status, resp.body, resp.set_cookies))
    }

    /// Arbitrary HTTP verb (e.g. WebDAV `PROPFIND`) with optional body.
    pub async fn impersonate_http_verb(
        &self,
        verb: &str,
        url: &str,
        body: Option<Vec<u8>>,
        headers: &[(&str, &str)],
        timeout: Duration,
        follow_redirects: bool,
        proxy: Option<&str>,
        insecure: bool,
    ) -> Result<(u16, String, Vec<String>)> {
        let wait_t0 = std::time::Instant::now();
        let _curl_slot = CURL_SLOTS
            .acquire()
            .await
            .expect("curl concurrency semaphore");
        let wait_ms = wait_t0.elapsed().as_millis();
        if wait_ms >= 100 {
            debug_log(
                "H-curl-queue",
                "curl_impersonate.rs:impersonate_http_verb",
                "waited for curl slot",
                &format!(r#"{{"wait_ms":{wait_ms}}}"#),
            );
        }

        let fp_args = match &self.fingerprint {
            Some(fp) => fp.to_args().map_err(|e| Error::CurlImpersonate(e.to_string()))?,
            None => Vec::new(),
        };

        let mut argv: Vec<String> = vec![
            "-i".into(),
            "-sS".into(),
            "--compressed".into(),
            "--max-time".into(),
            format!("{}", timeout.as_secs_f64().max(5.0)),
        ];
        argv.extend(fp_args);
        if follow_redirects {
            argv.push("-L".into());
        }
        if insecure {
            argv.push("-k".into());
        }
        argv.push("-X".into());
        argv.push(verb.to_string());
        for (k, v) in headers {
            argv.push("-H".into());
            argv.push(format!("{k}: {v}"));
        }
        let has_body = body.is_some();
        if has_body {
            argv.push("--data-binary".into());
            argv.push("@-".into());
        }
        argv.push("--".into());
        argv.push(url.to_string());

        let mut cmd = tokio::process::Command::new(&self.bin);
        cmd.args(&argv);
        match proxy {
            Some(raw) if !raw.trim().is_empty() => {
                cmd.env("ALL_PROXY", raw.trim());
            }
            _ => {
                for var in [
                    "ALL_PROXY",
                    "all_proxy",
                    "HTTP_PROXY",
                    "http_proxy",
                    "HTTPS_PROXY",
                    "https_proxy",
                    "NO_PROXY",
                    "no_proxy",
                ] {
                    cmd.env_remove(var);
                }
            }
        }
        cmd.stdin(if has_body {
            std::process::Stdio::piped()
        } else {
            std::process::Stdio::null()
        })
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped());

        let mut child = cmd
            .spawn()
            .map_err(|e| Error::CurlImpersonate(format!("spawn {}: {e}", self.bin.display())))?;

        if let Some(body) = body {
            if let Some(mut stdin) = child.stdin.take() {
                use tokio::io::AsyncWriteExt;
                let _ = stdin.write_all(&body).await;
            }
        }

        let out = child
            .wait_with_output()
            .await
            .map_err(|e| Error::CurlImpersonate(format!("curl wait: {e}")))?;
        if !out.status.success() {
            let stderr = String::from_utf8_lossy(&out.stderr);
            return Err(Error::CurlImpersonate(format!(
                "{} exited {:?}: {}",
                self.bin.display(),
                out.status.code(),
                stderr.trim()
            )));
        }

        let (status, body, set_cookies) = parse_curl_i_response(&out.stdout)
            .map_err(|e| Error::CurlImpersonate(e))?;
        Ok((status, body, set_cookies))
    }
}

fn parse_curl_i_response(stdout: &[u8]) -> std::result::Result<(u16, String, Vec<String>), String> {
    let text = String::from_utf8_lossy(stdout);
    let mut rest: &str = &text;
    let mut last_head = "";
    let mut set_cookies: Vec<String> = Vec::new();
    while rest.starts_with("HTTP/") {
        let Some(end) = curl_header_block_end(rest) else {
            break;
        };
        let head = &rest[..end];
        set_cookies.extend(
            head.lines()
                .filter_map(|l| l.split_once(':'))
                .filter(|(k, _)| k.trim().eq_ignore_ascii_case("set-cookie"))
                .map(|(_, v)| v.trim().to_string()),
        );
        last_head = head;
        rest = &rest[end..];
    }
    if last_head.is_empty() {
        return Err("no HTTP status in curl output".into());
    }
    let status_line = last_head.lines().next().unwrap_or_default();
    let status = status_line
        .split_whitespace()
        .find_map(|tok| tok.parse::<u16>().ok())
        .ok_or_else(|| format!("bad status line: {status_line}"))?;
    Ok((status, rest.to_string(), set_cookies))
}

fn curl_header_block_end(s: &str) -> Option<usize> {
    s.find("\r\n\r\n")
        .map(|i| i + 4)
        .or_else(|| s.find("\n\n").map(|i| i + 2))
}

fn is_bat(path: &Path) -> bool {
    path.extension()
        .and_then(|e| e.to_str())
        .is_some_and(|e| e.eq_ignore_ascii_case("bat") || e.eq_ignore_ascii_case("cmd"))
}

fn curl_impersonate_exe_in_dir(dir: &Path) -> Option<PathBuf> {
    let direct = dir.join("curl-impersonate.exe");
    if direct.is_file() {
        return Some(direct);
    }
    let read_dir = std::fs::read_dir(dir).ok()?;
    for entry in read_dir.flatten() {
        let name = entry.file_name();
        let name = name.to_string_lossy();
        if name.starts_with("curl-impersonate") && name.ends_with(".exe") {
            let path = entry.path();
            if path.is_file() {
                return Some(path);
            }
        }
    }
    None
}

fn chrome110_from_bat(bat: &Path) -> Result<(PathBuf, Fingerprint)> {
    let Some(dir) = bat.parent() else {
        return Err(Error::CurlImpersonate(format!(
            "invalid MEGA curl wrapper path: {}",
            bat.display()
        )));
    };
    let exe = curl_impersonate_exe_in_dir(dir).ok_or_else(|| {
        Error::CurlImpersonate(format!(
            "curl-impersonate.exe not next to {} (expected in {}). \
             Fix MEGA_CURL_BIN to full path, e.g. D:\\Mega\\curl-impersonate-2.2.3\\win\\bin\\curl_chrome110.bat \
             (broken User env often looks like \\win\\bin\\curl_chrome110.bat when MEGA_CURL_ROOT is empty).",
            bat.display(),
            dir.display()
        ))
    })?;
    let fingerprint = Fingerprint::builder().base_target("chrome110").build();
    Ok((exe, fingerprint))
}

fn try_wrapper_path(path: &Path) -> Option<Result<(PathBuf, Option<Fingerprint>)>> {
    if !path.is_file() {
        return None;
    }
    if is_bat(path) {
        return Some(chrome110_from_bat(path).map(|(exe, fp)| (exe, Some(fp))));
    }
    Some(Ok((path.to_path_buf(), None)))
}

const DEFAULT_CURL_BATS: &[&str] = &[
    r"D:\Mega\curl-impersonate-2.2.3\win\bin\curl_chrome110.bat",
    r"G:\cloudmonster\source_mega_d\curl-impersonate-2.2.3\win\bin\curl_chrome110.bat",
    r"G:\cloudmonster\curl-impersonate-2.2.3\win\bin\curl_chrome110.bat",
    r"D:\Mega\curl-impersonate-2.2.3\bin\curl_chrome110",
    r"D:\Mega\curl-impersonate-v2.2.3.arm64-win32.tar\curl_chrome110.bat",
    r"G:\cloudmonster\source_mega_d\curl-impersonate-v2.2.3.x86_64-win32.tar\curl_chrome110.bat",
];

fn wrapper_names() -> &'static [&'static str] {
    &[
        "curl_chrome110.bat",
        "curl_chrome110.cmd",
        "curl_chrome110.exe",
        "curl_chrome110",
        "curl_chrome116.bat",
        "curl_chrome116.exe",
        "curl_chrome116",
    ]
}

fn resolve_curl_bin() -> Result<(PathBuf, Option<Fingerprint>)> {
    if let Ok(p) = std::env::var("MEGA_CURL_BIN") {
        let trimmed = p.trim();
        if !trimmed.is_empty() {
            let path = PathBuf::from(trimmed);
            if let Some(Ok(res)) = try_wrapper_path(&path) {
                return Ok(res);
            }
            // Ignore broken MEGA_CURL_BIN (e.g. "\win\bin\curl_chrome110.bat") and fall through.
        }
    }

    if let Ok(root) = std::env::var("MEGA_CURL_ROOT") {
        let trimmed = root.trim();
        if !trimmed.is_empty() {
            let root = PathBuf::from(trimmed);
            if let Some(path) = find_curl_wrapper(&root) {
                return resolved_wrapper(path);
            }
        }
    }

    if let Ok(exe_dir) = std::env::current_exe()
        .ok()
        .and_then(|path| path.parent().map(Path::to_path_buf))
        .ok_or(())
    {
        for root in [exe_dir.clone(), exe_dir.join("curl-impersonate-2.2.3")] {
            if let Some(path) = find_curl_wrapper(&root) {
                return resolved_wrapper(path);
            }
        }
    }

    if let Some(path_env) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path_env) {
            for name in wrapper_names() {
                let candidate = dir.join(name);
                if let Some(Ok(res)) = try_wrapper_path(&candidate) {
                    return Ok(res);
                }
            }
        }
    }

    for default in DEFAULT_CURL_BATS {
        let default_bat = PathBuf::from(default);
        if let Some(Ok(res)) = try_wrapper_path(&default_bat) {
            return Ok(res);
        }
    }

    Err(Error::CurlImpersonate(
        "curl_chrome110 not found. Set MEGA_CURL_BIN to curl_chrome110.bat (Windows) or the wrapper on PATH. \
         Example: D:\\Mega\\curl-impersonate-2.2.3\\win\\bin\\curl_chrome110.bat \
         or set MEGA_CURL_ROOT=D:\\Mega\\curl-impersonate-2.2.3"
            .into(),
    ))
}

fn find_curl_wrapper(root: &Path) -> Option<PathBuf> {
    for sub in [
        Path::new("win\\bin\\curl_chrome110.bat"),
        Path::new("bin\\curl_chrome110.bat"),
        Path::new("curl_chrome110.bat"),
        Path::new("curl-impersonate.exe"),
    ] {
        let candidate = root.join(sub);
        if candidate.is_file() {
            return Some(candidate);
        }
    }
    None
}

fn resolved_wrapper(path: PathBuf) -> Result<(PathBuf, Option<Fingerprint>)> {
    if is_bat(&path) {
        let (exe, fp) = chrome110_from_bat(&path)?;
        Ok((exe, Some(fp)))
    } else {
        Ok((path, None))
    }
}

fn header_value<'a>(headers: &'a [(String, String)], name: &str) -> Option<&'a str> {
    headers.iter().find_map(|(k, v)| {
        if k.eq_ignore_ascii_case(name) {
            Some(v.as_str())
        } else {
            None
        }
    })
}

async fn post_cs_curl(
    bin: &Path,
    fingerprint: Option<&Fingerprint>,
    url: &str,
    json_body: &str,
    timeout: Duration,
) -> Result<Vec<u8>> {
    let wait_start = std::time::Instant::now();
    let _curl_slot = CURL_SLOTS
        .acquire()
        .await
        .expect("curl concurrency semaphore");
    let curl_wait_ms = wait_start.elapsed().as_millis();
    if curl_wait_ms > 50 {
        debug_log(
            "H-A",
            "curl_impersonate:post_cs_curl",
            "curl slot wait",
            &format!(r#"{{"curl_wait_ms":{curl_wait_ms}}}"#),
        );
    }

    let mut hashcash_header: Option<String> = None;
    let mut hashcash_rounds = 0u32;

    loop {
        let mut req = Request::post(bin, url)
            .header("Content-Type", "application/json")
            .header("Accept", "*/*")
            .header("Origin", "https://mega.nz")
            .header("Referer", "https://mega.nz/")
            .header("Sec-Fetch-Site", "same-site")
            .header("Sec-Fetch-Mode", "cors")
            .header("Sec-Fetch-Dest", "empty")
            .timeout_secs(timeout.as_secs_f64().max(5.0))
            .body(json_body.as_bytes().to_vec());
        if let Some(fp) = fingerprint {
            req = req.fingerprint(fp.clone());
        }

        if let Some(hc) = hashcash_header.as_deref() {
            req = req.header("X-Hashcash", hc);
        }

        let resp = req.send().await.map_err(|e| Error::CurlImpersonate(e.to_string()))?;

        if resp.status == 402 {
            hashcash_rounds += 1;
            if hashcash_rounds > MAX_HASHCASH_ROUNDS {
                return Err(Error::CurlImpersonate(
                    "MEGA HTTP 402: too many hashcash rounds".into(),
                ));
            }
            if let Some(challenge) = header_value(&resp.headers, "X-Hashcash") {
                if let Some((easiness, token)) = parse_hashcash(challenge) {
                    let token_for_header = token.clone();
                    let slots = HASHCASH_SLOTS.clone();
                    let _slot = slots.acquire().await.expect("hashcash semaphore");
                    let solve_fut =
                        tokio::task::spawn_blocking(move || solve_hashcash(&token, easiness));
                    let solution = match tokio::time::timeout(HASHCASH_SOLVE_TIMEOUT, solve_fut)
                        .await
                    {
                        Ok(Ok(Some(sol))) => Some(sol),
                        Ok(Ok(None)) | Ok(Err(_)) => None,
                        Err(_) => None,
                    };
                    if let Some(sol) = solution {
                        hashcash_header = Some(format!("1:{token_for_header}:{sol}"));
                        debug_log(
                            "H-HC",
                            "curl_impersonate:post_cs_curl",
                            "hashcash solved",
                            &format!(
                                r#"{{"round":{},"easiness":{},"token_len":{}}}"#,
                                hashcash_rounds,
                                easiness,
                                token_for_header.len()
                            ),
                        );
                        continue;
                    }
                }
            }
            return Err(Error::CurlImpersonate(
                "MEGA HTTP 402 without solvable X-Hashcash".into(),
            ));
        }

        if resp.status >= 400 {
            return Err(Error::CurlImpersonate(format!(
                "MEGA HTTP {}: {}",
                resp.status,
                truncate(&resp.body, 200)
            )));
        }

        return Ok(resp.body.into_bytes());
    }
}

fn truncate(s: &str, max: usize) -> String {
    if s.len() <= max {
        s.to_string()
    } else {
        format!("{}…", &s[..max])
    }
}

#[async_trait]
impl HttpClient for CurlImpersonateClient {
    async fn send_requests(
        &self,
        state: &ClientState,
        requests: &[MegaRequest],
        query_params: &[(&str, &str)],
    ) -> Result<Vec<Response>> {
        let url = {
            let mut url = state.origin.join("/cs")?;
            let mut qs = url.query_pairs_mut();
            let id_counter = state.id_counter.fetch_add(1, Ordering::SeqCst);
            qs.append_pair("id", id_counter.to_string().as_str());
            if let Some(session) = state.session.as_ref() {
                qs.append_pair("sid", session.expose_secret().sid.as_str());
            }
            qs.extend_pairs(query_params);
            qs.finish();
            drop(qs);
            url
        };

        let json_body = json::to_string(requests)?;
        let timeout = state.timeout.unwrap_or(Duration::from_secs(50));

        let mut delay = state.min_retry_delay;
        let mut last_curl_msg: Option<String> = None;
        for attempt in 1..=state.max_retries {
            if attempt > 1 {
                tokio::time::sleep(delay).await;
                delay = (delay * 2).min(state.max_retry_delay);
            }

            match post_cs_curl(
                &self.bin,
                self.fingerprint.as_ref(),
                url.as_str(),
                &json_body,
                timeout,
            )
            .await
            {
                Ok(response) => {
                    if let Ok(code) = json::from_slice::<ErrorCode>(&response) {
                        if code == ErrorCode::EAGAIN {
                            tracing::debug!(?attempt, "MEGA EAGAIN, backing off");
                            tokio::time::sleep(EAGAIN_BACKOFF.saturating_mul(attempt as u32)).await;
                            continue;
                        }
                        if code != ErrorCode::OK {
                            return Err(Error::from(code));
                        }
                    }

                    let responses: Vec<Value> = json::from_slice(&response).map_err(|e| {
                        Error::CurlImpersonate(format!("invalid MEGA JSON: {e}"))
                    })?;

                    return requests
                        .iter()
                        .zip(responses)
                        .map(|(request, response)| request.parse_response_data(response))
                        .collect();
                }
                Err(Error::CurlImpersonate(msg))
                    if (msg.contains("402") || msg.contains("hashcash") || msg.contains("HTTP 5"))
                        && !msg.contains("too many hashcash rounds") =>
                {
                    last_curl_msg = Some(msg.clone());
                    tracing::debug!(?attempt, %msg, "MEGA curl retry");
                    continue;
                }
                Err(Error::CurlImpersonate(msg)) => {
                    last_curl_msg = Some(msg.clone());
                    return Err(Error::CurlImpersonate(msg));
                }
                Err(e) => return Err(e),
            }
        }

        if let Some(msg) = last_curl_msg {
            tracing::warn!(%msg, "MEGA /cs exhausted retries");
            debug_log(
                "H-D",
                "curl_impersonate:send_requests",
                "max retries",
                &format!(
                    r#"{{"max_retries":{},"last_curl_msg":"{}"}}"#,
                    state.max_retries,
                    msg.replace('\\', "\\\\").replace('"', "\\\"").chars().take(120).collect::<String>()
                ),
            );
        } else {
            debug_log(
                "H-D",
                "curl_impersonate:send_requests",
                "max retries",
                &format!(r#"{{"max_retries":{},"reason":"eagain_or_empty"}}"#, state.max_retries),
            );
        }
        Err(Error::MaxRetriesReached)
    }

    async fn get(&self, _url: Url) -> Result<Pin<Box<dyn AsyncRead + Send>>> {
        Err(Error::CurlImpersonate(
            "MEGA GET via curl-impersonate not used in check mode".into(),
        ))
    }

    async fn post(
        &self,
        _url: Url,
        _body: Pin<Box<dyn AsyncRead + Send + Sync>>,
        _content_length: Option<u64>,
    ) -> Result<Pin<Box<dyn AsyncRead + Send>>> {
        Err(Error::CurlImpersonate(
            "MEGA file upload via curl-impersonate not implemented; use check-only mode".into(),
        ))
    }
}
