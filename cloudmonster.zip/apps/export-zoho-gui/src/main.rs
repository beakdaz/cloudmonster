fn main() {
    if let Err(err) = pma_gui::run_zoho_notes_gui() {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
