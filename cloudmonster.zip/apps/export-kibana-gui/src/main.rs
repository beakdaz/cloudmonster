﻿fn main() {
    if let Err(err) = pma_gui::run_fixed(pma_gui::WorkMode::Kibana) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
