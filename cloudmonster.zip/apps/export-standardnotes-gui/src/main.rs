﻿fn main() {
    if let Err(err) = pma_gui::run_fixed(pma_gui::WorkMode::StandardNotes) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
