fn main() {
    if let Err(err) = pma_gui::run_wps_gui() {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
