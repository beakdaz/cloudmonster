﻿fn main() {
    if let Err(err) = pma_gui::run_fixed(pma_gui::WorkMode::GitLab) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
