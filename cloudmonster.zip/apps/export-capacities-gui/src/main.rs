﻿fn main() {
    if let Err(err) = pma_gui::run_fixed(pma_gui::WorkMode::Capacities) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
