﻿fn main() {
    if let Err(err) = pma_gui::run_fixed(pma_gui::WorkMode::Obsidian) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
