﻿fn main() {
    if let Err(err) = pma_gui::run_fixed(pma_gui::WorkMode::Kortex) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
