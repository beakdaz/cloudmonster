fn main() {
    if let Err(err) = pma_gui::run_adminpanel() {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
