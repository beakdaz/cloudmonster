fn main() {
    if let Err(err) = pma_gui::run_crmcheck() {
        eprintln!("{err}");
        std::process::exit(1);
    }
}
