from pathlib import Path

p = Path(r"C:\Users\beakd\Documents\MEGA\1\phpmyadmin-rs\crates\app\src\lib.rs")
text = p.read_text(encoding="utf-8")

insert_path = Path(__file__).with_name("app_sql_insert.rs")
insert = insert_path.read_text(encoding="utf-8")

def find(marker: str, start: int = 0) -> int:
    idx = text.find(marker, start)
    if idx == -1:
        raise SystemExit(f"marker not found: {marker}")
    return idx

sendsecure = find("pub async fn load_sendsecure_list_summary")
slack = find("pub async fn load_slack_list_summary")
n8n = find("pub async fn load_n8n_list_summary")
citrix = find("pub async fn load_citrix_list_summary")
fortinet = find("pub async fn load_fortinet_list_summary")
onenote = find("pub async fn load_onenote_list_summary")
format_scan = find("fn format_scan_log")

new_text = (
    text[:sendsecure]
    + insert
    + text[slack:n8n]
    + text[citrix:fortinet]
    + text[fortinet:onenote]
    + text[format_scan:]
)

p.write_text(new_text, encoding="utf-8")
print("patched", p, "len", len(new_text))
