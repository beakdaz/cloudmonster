# MEGAX visual layout workflow

## What you have

| Tool | Role |
|------|------|
| **Cursor Canvas** [`megax-layout.canvas.tsx`](file:///C:/Users/beakd/.cursor/projects/c-Users-beakd-Documents-MEGA-1/canvases/megax-layout.canvas.tsx) | Live mockup + numeric fields + drag sidebar/bottom bar |
| **UICanvas extension** (markvely.uicanvas) | Figma-like HTML artboards in VS Code when MCP works (`open_canvas` → `init_project` → `create_artboard` → `write_html`) |
| **egui app** `crates/pma-gui/src/megax.rs` | Real UI — only changes here affect the shipped GUI |

## Honest limit

There is **no** bidirectional Figma ↔ egui bridge. egui lays out at runtime with Rust code; neither Cursor Canvas nor UICanvas edits `megax.rs` automatically unless you sync.

**Best loop:** mockup → export constants → patch Rust → `cargo run -p pma-gui`.

## Cursor Canvas (recommended now)

1. Open the canvas file beside chat (link from agent message).
2. Drag handles or edit number fields.
3. Click **Prepare JSON export**, copy JSON into `tools/megax-layout.json`.
4. Run from repo root:

   ```powershell
   powershell -File phpmyadmin-rs/tools/apply_megax_layout.ps1
   ```

5. Rebuild the GUI crate and visually confirm.

The apply script today patches: `SIDEBAR_W`, `BOTTOM_H`, `CARD_ROUND`, `CENTRAL_MARGIN`.

## UICanvas (when MCP is healthy)

1. Open a **VS Code / Cursor window** with UICanvas panel active (extension starts HTTP + WebSocket).
2. In agent chat, MCP tools should appear: `open_canvas`, `init_project`, `finalize_design_spec`, `create_artboard`, `write_html`, `update_styles`, `get_screenshot`, etc.
3. Build artboard **1280×800** with MEGAX colors from `megax.rs` (`#0C0D10` bg, `#00D2FF` accent).
4. Export layout measurements manually or via `get_styles` → update `megax-layout.json`.

If MCP shows *"failed during live tool discovery"*: Reload Window, ensure UICanvas panel was opened once, retry `mcp_auth` for `user-uicanvas`.

## megax.rs layout map (Checker)

- `harmony::title_bar` — window chrome (outside megax panels)
- `TopBottomPanel::bottom` — `BOTTOM_H`, Start/Stop/Reset + stats
- `SidePanel::left` — `SIDEBAR_W`, logo, nav, footer status
- `CentralPanel` — 16px margin, grid background (`GRID_STEP` 48), page content
- Checker: 2 columns of cards, full-width Download Settings (3 columns), optional log panel (`LOG_MIN_H` 220)

## After visual edits

Tell the agent: *"Apply megax-layout.json to megax.rs and hoist remaining inline sizes into consts"* — or paste the Rust snippet from the canvas.
