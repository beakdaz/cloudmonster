# OpenBullet / LoliScript — черновики по модулям CloudMonster

Один файл **`.loli`** на облачный сервис. Формат как у **MediaFire Capture** (блок `[SETTINGS]` + `[SCRIPT]`).

| Поле | Значение |
|------|----------|
| Wordlist | `MailPass` → `email:password`, если не указано иное |
| Плейсхолдеры | `<USER>`, `<PASS>`, при необходимости `<AGENT>` |
| Код Rust | `crates/net/src/cloud/providers/<service>.rs` |

**Не готовые конфиги:** заготовки под правку. Логика в exe уже в Rust; здесь — чтобы сверять шаги с OpenBullet/SilverBullet.

## Файлы

| Файл | Сервис | Combo |
|------|--------|-------|
| `mega.loli` | MEGA | `email:password` |
| `filen.loli` | Filen | mail:pass + PBKDF2 (см. комментарии) |
| `degoo.loli` | Degoo | mail:pass |
| `mediafire.loli` | MediaFire | mail:pass (полный пример) |
| `four_shared.loli` | 4shared | mail:pass |
| `blomp.loli` | Blomp | mail:pass |
| `filesfm.loli` | Files.fm | mail:pass |
| `adrive.loli` | ADrive | mail:pass (WebDAV) |
| `terabox.loli` | TeraBox | mail:pass |
| `pixeldrain.loli` | PixelDrain | mail:pass |
| `raindrop.loli` | Raindrop | mail:pass |
| `internxt.loli` | Internxt | mail:pass |
| `remnote.loli` | RemNote | mail:pass + Firebase key |
| `onedrive.loli` | OneDrive | mail:pass |
| `wps.loli` | WPS Drive | mail:pass |
| `sync_com.loli` | Sync.com | mail:pass |
| `acronis.loli` | Acronis | mail:pass |
| `zoho_notes.loli` | Zoho Notes | app-password |
| `obsidian.loli` | Obsidian | mail:pass / token |
| `nimbus_notes.loli` | Nimbus | mail:pass |
| `proton_drive.loli` | Proton Drive | не combo (SRP) |
| `koofr.loli` | Koofr | mail:pass |
| `upnote.loli` | UpNote | `upnote:TOKEN` |
| `box_com.loli` | Box | mail:pass |
| `fex.loli` | FEX | mail:pass |
| `file_io.loli` | file.io | `fileio:API_KEY` |
| `icedrive.loli` | Icedrive | mail:pass |
| `mobidrive.loli` | MobiDrive | `mobidrive:…` |
| `secureshare.loli` | SecureShare | `secureshare:COOKIE` |
| `toffeeshare.loli` | ToffeeShare | не mail:pass |
| `workupload.loli` | WorkUpload | mail:pass + captcha |
| `pcloud.loli` | pCloud | mail:pass |

Скопируйте `_settings.snippet.json` в `[SETTINGS]` при создании нового конфига (поле `"Name"`).

**Пересоздать черновики** (кроме вручную сохранённого `mediafire.loli` — не трогайте, если правили):

```powershell
python tools/lolicfg/generate_drafts.py
```

После правки `generate_drafts.py` можно снова прогнать скрипт; `mediafire.loli` в списке генератора **нет**, чтобы не затереть полный пример.
