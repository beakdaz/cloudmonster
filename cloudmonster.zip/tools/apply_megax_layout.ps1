# Applies megax-layout.json numeric tokens into megax.rs (selected const replacements).
param(
  [string]$JsonPath = (Join-Path $PSScriptRoot "megax-layout.json"),
  [string]$MegaxRs = (Join-Path $PSScriptRoot "..\crates\pma-gui\src\megax.rs")
)

$MegaxRs = (Resolve-Path $MegaxRs).Path
if (-not (Test-Path $JsonPath)) { throw "Missing $JsonPath" }
if (-not (Test-Path $MegaxRs)) { throw "Missing megax.rs at $MegaxRs" }

$cfg = Get-Content $JsonPath -Raw | ConvertFrom-Json
$layout = $cfg.layout
$text = Get-Content $MegaxRs -Raw
$inv = [System.Globalization.CultureInfo]::InvariantCulture

function Set-Const([ref]$blob, [string]$name, [double]$val) {
  $num = $val.ToString("0.0", $inv)
  $blob.Value = [regex]::Replace(
    $blob.Value,
    "(?m)^const $name`: f32 = [0-9]+(?:[.,][0-9]+)?;\s*$",
    "const ${name}: f32 = ${num};"
  )
}

$textRef = [ref]$text
Set-Const $textRef "SIDEBAR_W" ([double]$layout.SIDEBAR_W)
Set-Const $textRef "BOTTOM_H" ([double]$layout.BOTTOM_H)
Set-Const $textRef "CARD_ROUND" ([double]$layout.CARD_ROUND)
if ($layout.PSObject.Properties.Name.Contains("CENTRAL_MARGIN")) {
  Set-Const $textRef "CENTRAL_MARGIN" ([double]$layout.CENTRAL_MARGIN)
}
$text = $textRef.Value

[System.IO.File]::WriteAllText($MegaxRs, $text)
Write-Host "Updated $MegaxRs"
Write-Host "Rebuild: cargo run -p pma-gui"
