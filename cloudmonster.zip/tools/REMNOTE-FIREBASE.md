# RemNote checker — Firebase apiKey

RemNote логинится через Google **Identity Toolkit** (`signInWithPassword`). Чекеру нужен публичный **Web API key** (`AIzaSy…`) — тот же, что в браузере. Это **не** пароль.

Старый URL `__/firebase/init.json` на remnote.com **больше не отдаёт JSON** (открывается HTML). Ключ лежит в JS-бандлах сайта. CloudMonster **пытается скачать их сам**; если не вышло (прокси, блок) — ключ задаётся вручную.

## Способ 1 — поиск в коде страницы (проще всего)

1. Открой **https://www.remnote.com/sign_in** в Chrome.
2. **F12** → вкладка **Sources** (Источники).
3. **Ctrl+Shift+F** (глобальный поиск по всем файлам).
4. Ищи: `apiKey`
5. Найди строку вида `"apiKey":"AIzaSy…………"` — скопируй значение **без кавычек**.

Если поиск ничего не даёт — дождись полной загрузки (лоадер пропал), обнови страницу и повтори.

## Способ 2 — Network при входе

1. **https://www.remnote.com/sign_in** → F12 → **Network**.
2. Включи **Preserve log**.
3. Введи email/пароль и нажми Sign in.
4. В фильтре введи: `signInWithPassword` или `identitytoolkit`.
5. Открой запрос → в **Request URL** найди `?key=AIzaSy…` — это и есть ключ.

Если запросов нет: блокировщик, другой способ входа (Google) — используй способ 1.

## Способ 3 — переменная окружения

```powershell
[System.Environment]::SetEnvironmentVariable("REMNOTE_FIREBASE_API_KEY", "AIzaSy...", "User")
```

Перезапусти терминал и `export-mega-gui.exe`.

На одну сессию:

```powershell
$env:REMNOTE_FIREBASE_API_KEY = "AIzaSy..."
```

## Smoke test

```powershell
$tmpdir = Join-Path $env:TEMP "pma-remnote-smoke"
New-Item -ItemType Directory -Path $tmpdir -Force | Out-Null
Set-Content -Path (Join-Path $tmpdir "combo.txt") -Value "email@example.com:password" -NoNewline
$env:REMNOTE_TEST_COMBO = Join-Path $tmpdir "combo.txt"
$env:REMNOTE_FIREBASE_API_KEY = "AIzaSy..."
Set-Location C:\Users\beakd\Documents\MEGA\1\phpmyadmin-rs
cargo test -p pma-net remnote_local_smoke -- --ignored --nocapture
```

Не коммить combo и apiKey в git.
