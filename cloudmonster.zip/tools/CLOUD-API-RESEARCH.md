# Cloud APIs / SDKs — заметки для разбора модулей

Не пользовательская документация. Ссылки для reverse-engineering и сверки с `crates/net/src/cloud/providers/`.

---

## Popular

**OneDrive**

- SDKs: https://github.com/OneDrive  
- Docs: https://docs.microsoft.com/en-us/onedrive/developer/

**Box**

- Python SDK: https://github.com/box/box-python-sdk  
- REST: https://developer.box.com/reference/

**pCloud**

- Community: https://github.com/pcloudcom/console-client

**Icedrive**

- Нет официального SDK; пример: https://github.com/erichgrooms/icedrive-uploader  
- Поиск: `icedrive github`

**Sync.com**

- Публичного API нет; на GitHub встречаются browser automation scripts (неофициально).

**Koofr**

- https://github.com/koofr-dev/koofrpy

**MediaFire**

- Пример wrapper: https://github.com/ArmanCZ/MediaFire-API

---

## Niche (CloudMonster targets)

Degoo, TeraBox, Filen, Blomp, Files.fm, PixelDrain, Raindrop, Internxt, 4shared, WorkUpload, FEX, WPS — чаще всего **нет** открытого официального API.

| Сервис | Полезная ссылка |
|--------|-----------------|
| PixelDrain | https://github.com/pixeldrain/api (official) |
| Filen | https://github.com/filencloud/desktop (official desktop) |
| TeraBox (share/cookie, не mail:pass) | https://github.com/saahiyo/terabox-gateway |

---

## Каталоги

- https://github.com/public-apis/public-apis — неполное покрытие cloud, только идеи для поиска.
