@echo off
rem Скрипты перенесены в scripts\ — см. README.ru.md
explorer "%~dp0scripts"
start "" "%~dp0scripts\README.ru.md"
