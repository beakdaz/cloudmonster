# CloudMonster — статус облачных модулей

Код: **`crates/net/src/cloud/providers/<service>.rs`** (общее: `cloud/common.rs`, `config.rs`, `curl_http.rs`). GUI: один `export-mega-gui.exe`, сервис — Platforms.

| Сервис | `email:password` | Список файлов | Примечание |
|--------|------------------|---------------|------------|
| MEGA | да | да | отдельный стек |
| Filen, Degoo, MediaFire, 4shared, Blomp, Files.fm | да | да | curl-impersonate |
| ADrive | да | WebDAV | нужен платный WebDAV |
| TeraBox, PixelDrain, Raindrop, InternXt | да | да | |
| RemNote | да | только login/uid | публичного list API нет |
| OneDrive, WPS, Sync.com | да | да | |
| Acronis | да | нет | только password grant (Valid) |
| Zoho Notes | app-password | да | Notebook IAM |
| Obsidian | да* | vault* | `ob` CLI или `OBSIDIAN_AUTH_TOKEN` |
| Nimbus | да | заметки | API после web login |
| Proton Drive | нет | — | SRP/2FA, не в «Ready» |
| Koofr, Box, FEX, Icedrive, pCloud | да | да | |
| file.io | `fileio:KEY` | да | не mail:pass |
| MobiDrive | `mobidrive:…` | да | reCAPTCHA на сайте |
| SecureShare | `secureshare:COOKIE` | shares | 2FA на сайте |
| ToffeeShare | — | — | P2P, не облако |
| WorkUpload | да | да | PoW captcha |
| UpNote | `upnote:TOKEN` | notes | не mail:pass |

\* Obsidian: combo через локальный `obsidian-headless`, не HTTP mail:pass.

**Ready checkers** в UI = `CloudProvider::is_checker_ready()` (исключены Proton Drive и ToffeeShare).
