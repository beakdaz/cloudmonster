# CloudMonster / MEGAX — руководство пользователя

Проверка облачных аккаунтов (login + список файлов / «Содержимое»). Используйте только на системах, где у вас есть право тестирования.

Полная копия встроена в программу: вкладка **Help** → «Открыть руководство (Markdown)».

---

## 0. Чеклист: что установить (обычный пользователь)

Отдельные «библиотеки» Rust/Python **не нужны** — только готовый exe и два компонента Windows ниже.

| № | Что скачать | Зачем | Ссылка |
|---|-------------|--------|--------|
| 1 | **CloudMonster** `export-mega-gui.exe` | основная программа | от поставщика или сборка из `phpmyadmin-rs` |
| 2 | **curl-impersonate** (папка `win\bin` с `.exe`, `.bat`, `.dll`) | HTTPS/TLS для облачных чекеров (MEGA, TeraBox, Zoho, pCloud, MediaFire, …) | [Releases на GitHub](https://github.com/lwthiker/curl-impersonate/releases) |
| 3 | **Microsoft Visual C++ Redistributable (x64)** | runtime для exe на Rust | [VC++ Redistributable](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist) |
| 4 | Файл прокси (текст) | только если не режим **No proxy (direct)** | свой список `host:port` |

**Для разработчиков** (сборка из исходников): [Rust toolchain](https://rustup.rs/), Visual Studio Build Tools (C++), затем `cargo build -p export-mega-gui --release`. curl-impersonate всё равно нужен при запуске exe.

---

## 1. Что скачать и установить (Windows)

### 1.1 Программа

Сборка разработчика или готовый **`export-mega-gui.exe`** (CloudMonster).  
Положите exe в любую папку, например `C:\Tools\CloudMonster\`.

### 1.2 curl-impersonate (обязательно для облачных чекеров)

MEGA, TeraBox, MediaFire, Zoho, pCloud и большинство cloud-модулей ходят в сеть через **curl-impersonate** (Chrome TLS), а не через обычный браузер.

1. Скачайте архив для Windows:  
   [curl-impersonate — Releases](https://github.com/lwthiker/curl-impersonate/releases)  
   (файл вида `curl-impersonate-*-win*.tar.gz` или готовая папка `win\bin`).

2. Распакуйте, например в:  
   `D:\Mega\curl-impersonate-2.2.3\win\bin\`

3. В папке **`bin`** должны быть:
   - `curl-impersonate.exe`
   - `curl_chrome110.bat` (или `curl_chrome110.cmd`)
   - сопутствующие `.dll` из архива (не удаляйте)

4. Укажите путь одним из способов:

   **Вариант A — переменная окружения (рекомендуется)**  
   ```text
   MEGA_CURL_ROOT=D:\Mega\curl-impersonate-2.2.3
   ```
   Программа ищет `win\bin/curl_chrome110.bat` внутри этой папки.

   **Вариант B — прямой путь к bat**  
   ```text
   MEGA_CURL_BIN=D:\Mega\curl-impersonate-2.2.3\win\bin\curl_chrome110.bat
   ```

   **Вариант C — PATH**  
   Добавьте `...\win\bin` в системный PATH (там должен лежать `curl_chrome110.bat`).

5. Проверка в PowerShell:
   ```powershell
   & "D:\Mega\curl-impersonate-2.2.3\win\bin\curl_chrome110.bat" -I https://www.google.com
   ```
   Должен вернуть HTTP-заголовки без ошибки «file not found».

Ошибки в логе вида **`curl-impersonate.exe exited`** / **`cloud curl-impersonate`** — почти всегда неверный путь или неполная распаковка архива.

### 1.3 Microsoft Visual C++ Redistributable

Rust/GUI exe часто требует актуальный runtime:

- [Latest supported VC++ Redistributable (x64)](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist)

Установите **x64**, перезапустите CloudMonster.

### 1.4 Прокси (опционально)

Файл прокси — по одной строке на прокси. В GUI: **Proxy mode** → *Proxy file (rotate)* / *Single* / *No proxy (direct)*.

---

## 2. Быстрый старт в GUI

1. Запустите **`export-mega-gui.exe`**.  
2. **Platforms** → выберите облако (MEGA, Zoho Notes, pCloud, …).  
3. **Checker** → файл combo **`email:password`**, папка вывода.  
4. **Proxy mode** → при тесте без прокси выберите **No proxy (direct)**.  
5. **Start** → результаты в папке вывода: **`Good.txt`**, **`Bad.txt`**, **`Errors.log`**, папка **`Содержимое`**.  
6. **Results** — список проверенных строк в текущей сессии.

Профили: **Settings → Profiles** → `%LOCALAPPDATA%\CloudMonster\profiles.json`.

---

## 3. Формат combo

| Режим | Пример |
|--------|--------|
| Обычный | `user@mail.com:password` |
| MEGA (пробел) | `email password` |
| Zoho Notebook | app-specific password Zoho, не пароль почты |
| pCloud token | `user@mail.com:pcloud:TOKEN` |
| Box.com | `email:password` (OAuth v2 login) или `box:ACCESS_TOKEN` / `box:refresh:TOKEN` (+ env `BOX_OAUTH_CLIENT_ID` / `BOX_OAUTH_CLIENT_SECRET`, redirect `http://127.0.0.1:53682/`) |
| Icedrive cookie | `user@mail.com:icedrive:COOKIE_VALUE` |
| MobiDrive session | `user@mail.com:mobidrive:ACCOUNT_ID:CONNECT_TOKEN` или `…:mobidrive:jwt:JWT` (не email:password) |
| file.io | `user:fileio:API_KEY` |
| WorkUpload | `user:workupload:COOKIE` (combo часто блокируется captcha) |

Подсказки по сервисам — вкладка **Platforms** (hover на плитке) и **Checker → Format & services**.

---

## 4. Фильтры и скачивание

- **Keywords** — фильтр имён и (где поддерживается) текста заметок; OR по словам.  
- **Download / sync files from cloud** — скачивание файлов после Valid (не все облака).  
- **Содержимое** — текстовый инвентарь; фильтр ключей применяется и к списку.

---

## 5. Полезные ссылки

| Тема | URL |
|------|-----|
| curl-impersonate | https://github.com/lwthiker/curl-impersonate |
| Zoho OAuth (не для mass combo) | https://www.zoho.com/developer/oauth/introduction.html |
| Zoho app passwords | https://accounts.zoho.com → Security → App-Specific Passwords |
| pCloud | https://www.pcloud.com/ |
| Microsoft VC++ Redist | https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist |

---

## 6. Типичные ошибки

| Симптом | Что делать |
|---------|------------|
| `curl-impersonate` / NETWORK | Путь `MEGA_CURL_ROOT`, прокси, Direct |
| Zoho `invalid password` | Новый app-password для Notebook |
| `NOT_ZOHO` / account not registered | Email не в Zoho |
| pCloud download пусто | Скачивать с той же машины, что чек (IP link) |

При багах присылайте: провайдер, Proxy mode, 1–2 строки **Errors.log** (без пароля), версию exe.
